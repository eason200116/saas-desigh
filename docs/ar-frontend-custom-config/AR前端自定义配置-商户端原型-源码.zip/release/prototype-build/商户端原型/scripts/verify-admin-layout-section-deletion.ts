import assert from 'node:assert/strict';
import { createSemanticDraft } from '../src/views/config/frontendCustom/AdminLayoutEditor/semanticFixture.ts';
import {
  aggregatePage,
  previewSections,
} from '../src/views/config/frontendCustom/AdminLayoutEditor/semanticResolver.ts';
import { removeContentSection } from '../src/views/config/frontendCustom/AdminLayoutEditor/sectionDeletion.ts';

const draft = createSemanticDraft('layout-bc-game');
const sections = aggregatePage(draft).sections;
const originalIds = sections.map((item) => item.id);

const protectedNavigation = removeContentSection(
  sections,
  'section-navigation',
  'section-navigation',
);
assert.equal(
  protectedNavigation.removed,
  false,
  'navigation cannot be removed by the data operation',
);
assert.deepEqual(
  sections.map((item) => item.id),
  originalIds,
  'navigation rejection keeps order unchanged',
);

const firstCollectionId = sections[1].id;
const nextCollectionId = sections[2].id;
const selectedRemoval = removeContentSection(sections, firstCollectionId, firstCollectionId);
assert.equal(selectedRemoval.removed, true, 'collection section is removable');
assert.equal(
  selectedRemoval.selectedSectionId,
  nextCollectionId,
  'selected removal prefers the next section',
);
assert.ok(
  !previewSections(draft).some((item) => item.id === firstCollectionId),
  'preview derives immediately from the updated section order',
);

let selectedId = removeContentSection(sections, nextCollectionId, nextCollectionId).selectedSectionId;
while (sections.filter((item) => item.type !== 'navigationRef').length > 1) {
  const removal = removeContentSection(sections, selectedId, selectedId);
  assert.equal(removal.removed, true, 'remaining content section is removable');
  selectedId = removal.selectedSectionId;
}
const finalCollectionId = sections[1].id;
const finalRemoval = removeContentSection(sections, finalCollectionId, finalCollectionId);
assert.equal(finalRemoval.selectedSectionId, sections[0].id,
  'last selected content falls back to navigation');
assert.deepEqual(
  sections.map((item) => item.id),
  [sections[0].id],
);

console.log('semantic section deletion verification: passed');
