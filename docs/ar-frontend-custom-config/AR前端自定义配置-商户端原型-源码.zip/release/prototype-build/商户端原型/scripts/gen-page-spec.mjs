// 由「探针 ground-truth + 字段词典」生成单页规范 pages/<name>.json（R53：键=真实列key，带 align/mask provenance + 矛盾门）
// 用法: node scripts/gen-page-spec.mjs <groundSlug> <glossRoute> <outName> <registryMatch>
import fs from 'node:fs';
const [slug, glossRoute, outName, match] = process.argv.slice(2);
const ground = JSON.parse(fs.readFileSync(`/tmp/claude-501/ground/${slug}.json`,'utf8'));
const g = fs.readFileSync('docs/migration/14-anchor-new-field-glossary.html','utf8');
// 词典该 route 段：key -> {name, def, intro}
const gi = {};
{ const s=g.indexOf(`route:'${glossRoute}'`); const n=g.indexOf("route:'",s+10);
  const sec=s>=0?g.slice(s,n>0?n:s+8000):'';
  for(const r of sec.match(/\[\s*'(?:[^'\\]|\\.)*'(?:\s*,\s*'(?:[^'\\]|\\.)*')*\s*\]/g)||[]){
    const v=(r.match(/'((?:[^'\\]|\\.)*)'/g)||[]).map(x=>x.slice(1,-1)); if(v.length<5)continue;
    for(const k of (v[1]||'').split('/').map(s=>s.trim()).filter(Boolean)) if(!gi[k]) gi[k]={name:v[3]||v[2]||'',def:v[4]||'',intro:v[5]||''};
  }
}
// 人工证据覆盖（矛盾/缺失时据真实渲染补写）：键 "<glossRoute>::<key>"
const ovPath='src/components/DevLocator/spec-data/_page-overrides.json';
const ov = fs.existsSync(ovPath) ? JSON.parse(fs.readFileSync(ovPath,'utf8')) : {};
// 词典全库兜底（本页段缺时按 key/中文名跨段取，仍为文档原文）
const gAll={byKey:{},byName:{}};
for(const r of g.match(/\[\s*'(?:[^'\\]|\\.)*'(?:\s*,\s*'(?:[^'\\]|\\.)*')*\s*\]/g)||[]){
  const v=(r.match(/'((?:[^'\\]|\\.)*)'/g)||[]).map(x=>x.slice(1,-1)); if(v.length<5)continue;
  const def=v[4]||'',intro=v[5]||'',nm=v[3]||v[2]||'';
  for(const k of (v[1]||'').split('/').map(s=>s.trim()).filter(Boolean)) if(!gAll.byKey[k]&&def)gAll.byKey[k]={def,intro};
  if(nm&&def&&!gAll.byName[nm])gAll.byName[nm]={def,intro};
}
const out={}; const issues=[]; const blocked=[]; let globalFill=0;
for(const c of ground.columns){
  const isNew=/新$/.test(c.label);
  const name=c.label.replace(/新$/,'').trim();
  let glo=gi[c.key]||null;
  let fromGlobal=false;
  if(!glo){ const gg=gAll.byKey[c.key]||gAll.byName[name]; if(gg){ glo=gg; fromGlobal=true; globalFill++; } }
  const o=ov[`${glossRoute}::${c.key}`];
  let def=glo?glo.def:''; let intro=glo?glo.intro:''; let authored=false;
  if(o){ def=o.fieldDef??def; intro=o.intro??intro; authored=true; }
  // 矛盾门：定义说脱敏但真值未脱敏，且未被 override 修正 → 拦下，不发布该矛盾定义
  if(!authored && /脱敏|打码|掩码/.test(def) && !c.masked){
    issues.push(`${c.key}: 定义称脱敏但真值未脱敏("${c.sample}")`); blocked.push(c.key); def=''; intro='';
  }
  out[c.key]={ field:c.key, name, type:'static', fieldDef:def, intro,
    isNew, ...(authored?{authored:true}:{}),
    provenance:{ align:c.align, masked:c.masked, sample:c.sample,
      defSource: authored?'人工据真值补写':(fromGlobal?'词典(跨段全库)':(glo?`词典${glossRoute}`:'无(待补)')), ...(blocked.includes(c.key)?{conflict:true}:{}) } };
}
// 合并 extras（弹窗控件/按钮/搜索等非列控件，从交互文档锚定，按中文名兜底匹配）
const exPath='src/components/DevLocator/spec-data/_page-extras.json';
let extraCount=0;
if(fs.existsSync(exPath)){
  const ex=(JSON.parse(fs.readFileSync(exPath,'utf8'))||{})[outName]||{};
  for(const k in ex){ if(!out[k]){ out[k]=ex[k]; extraCount++; } }
}
fs.mkdirSync('src/components/DevLocator/spec-data/pages',{recursive:true});
fs.writeFileSync(`src/components/DevLocator/spec-data/pages/${outName}.json`,JSON.stringify(out,null,2));
// 注册表
const regPath='src/components/DevLocator/spec-data/_registry.json';
const reg=JSON.parse(fs.readFileSync(regPath,'utf8'));
if(!reg.find(r=>r.spec===outName)) reg.push({match, spec:outName, mode:'key'});
fs.writeFileSync(regPath,JSON.stringify(reg,null,2));
const withDef=Object.values(out).filter(e=>e.fieldDef).length;
console.log(`✅ ${outName}.json: 总控件${Object.keys(out).length}(列${ground.columns.length}+extras${extraCount}) 有定义${withDef} 新列${Object.values(out).filter(e=>e.isNew).length}`);
console.log(`   矛盾门: ${issues.length?issues.join(' ; '):'0 通过'}`);
console.log(`   注册: match="${match}" mode=key`);
