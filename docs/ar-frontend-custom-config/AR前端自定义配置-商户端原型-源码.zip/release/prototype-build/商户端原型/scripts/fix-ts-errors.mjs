#!/usr/bin/env node
/**
 * M4 typecheck 批量修复脚本
 * 策略：在 reactive() 调用上加 <Record<string, any>> 类型参数
 */
import { readFileSync, writeFileSync } from 'node:fs';
import { glob } from 'glob';

const files = await glob('src/**/*.{vue,ts}', {
  cwd: '/Users/seven/Desktop/seven/Ar_V3_LottoPlatformDesign',
  absolute: true,
});

let modified = 0;
for (const f of files) {
  let c = readFileSync(f, 'utf8');
  const before = c;

  // 把 reactive({ 改为 reactive<Record<string, any>>({
  // 但避免已经有泛型参数的情况
  c = c.replace(/\breactive\(\s*\{/g, (match) => {
    // 已经有泛型不处理
    return match;
  });
  // 实际替换：reactive({ → reactive<Record<string, any>>({
  c = c.replace(/\breactive\(\{/g, 'reactive<Record<string, any>>({');
  c = c.replace(/\breactive\(\s*\n\s*\{/g, 'reactive<Record<string, any>>(\n  {');
  // 处理 reactive(createXxx()) 的模式：
  // reactive(createModalFormData(...)) → reactive<Record<string, any>>(createModalFormData(...))
  // 这个需要谨慎，只处理 reactive(create... 形式
  // 不处理，避免破坏

  if (c !== before) {
    writeFileSync(f, c);
    modified++;
  }
}
console.log('Modified files:', modified);
