#!/usr/bin/env node
/**
 * lint-ui-rules.mjs —— 机器能查的 UI 规则扫描器（试点版，只扫 2 个页面）
 *
 * 目的：替代烧 token 的 agent 人工检查。机械规则（列顺序/命名/对齐/控件类型/i18n 对称）
 * 交给这个脚本秒级出报告；agent/人只处理机器查不了的交互逻辑与语义判断。
 *
 * 范围硬编码为 PILOT_PAGES 里的 2 个页面，不做 src/views/** 通配符扫描 —— 这是本轮
 * 「只试跑不铺全站」要求的机械兜底，不是"暂时忘了改"，全站扫描是下一轮任务。
 *
 * 只读不写：本脚本绝不修改任何 src/views/** 业务文件，只打印报告到 stdout。
 *
 * 已知实现限制（写在这里而非事后找borland）：
 * 1. 列/搜索列提取是正则 + 括号计数的启发式解析，不是真 AST，遇到非常规写法可能漏报/误报。
 * 2. 有些页面的列表最终顺序由数组字面量之后的 .sort() 二次重排决定（如 member/user 的
 *    H_COL_ORDER），字面量顺序 ≠ 真实渲染顺序。检测到这种 .sort() 时，R82/R60 的顺序判断
 *    会降级为「低置信度」提示，而不是断言违规。
 * 3. R63/R20 等规则涉及语义判断，用的是关键词启发式，误报率天然更高，报告里已标severity。
 */

import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const PROJ_ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');

// ============================================================
// 0. 试点页面配置（本轮范围到此为止，全站扫描是下一轮任务）
// ============================================================
const PILOT_PAGES = [
  { name: 'member/user', dir: path.join(PROJ_ROOT, 'src/views/member/user') },
  { name: 'game/subgame', dir: path.join(PROJ_ROOT, 'src/views/game/subgame') },
];

// ============================================================
// 1. 列 / 搜索列提取引擎
// ============================================================

/** 从 .vue 模板里找 :columns="xxx" / :search-columns="yyy" 绑定的标识符名 */
function findBoundIdentifiers(vueFilePath) {
  const src = fs.readFileSync(vueFilePath, 'utf8');
  const colM = src.match(/:columns\s*=\s*"([A-Za-z0-9_]+)"/);
  const searchM = src.match(/:search-columns\s*=\s*"([A-Za-z0-9_]+)"/);
  return {
    columnsVar: colM ? colM[1] : null,
    searchColumnsVar: searchM ? searchM[1] : null,
  };
}

/**
 * 若 text[i] 正处在注释（// 或 /* ) 或字符串字面量（' " ` ）的起点，跳过整段并返回结束后的下标；
 * 否则原样返回 i。这段代码里到处是大段中文注释，注释文字本身完全可能含有 {}/[]/()/, 这类字符
 * （举例说明代码写法时尤其常见）——括号计数/顶层逗号切分若不跳过注释和字符串，会被这些"假"符号
 * 带偏，静默数错深度或错切元素。
 */
function skipCommentOrString(text, i) {
  const c = text[i];
  if (c === '/' && text[i + 1] === '/') {
    const nl = text.indexOf('\n', i);
    return nl === -1 ? text.length : nl + 1;
  }
  if (c === '/' && text[i + 1] === '*') {
    const end = text.indexOf('*/', i + 2);
    return end === -1 ? text.length : end + 2;
  }
  if (c === '`' || c === "'" || c === '"') {
    const quote = c;
    let j = i + 1;
    while (j < text.length) {
      if (text[j] === '\\') {
        j += 2;
        continue;
      }
      if (text[j] === quote) return j + 1;
      j++;
    }
    return text.length;
  }
  return i;
}

/** 括号深度计数：从 startIdx（必须是 '[' 或 '{'）找到匹配的闭合位置（含）。跳过注释/字符串。 */
function matchBracket(text, startIdx) {
  const open = text[startIdx];
  const close = open === '[' ? ']' : open === '(' ? ')' : '}';
  let depth = 0;
  for (let i = startIdx; i < text.length; ) {
    const skip = skipCommentOrString(text, i);
    if (skip !== i) {
      i = skip;
      continue;
    }
    const c = text[i];
    if (c === open) depth++;
    else if (c === close) {
      depth--;
      if (depth === 0) return i;
    }
    i++;
  }
  return -1;
}

/** 剥掉文本最前面的空白 + 连续的 //行注释 / *块注释（不碰内部内容，只为了分类判断"这段究竟是不是
 *  以 { 或 ... 开头"——顶层数组元素前常有整段说明性注释，不剥掉会让 startsWith('{') 误判失败，
 *  导致带注释的列/搜索项被静默漏掉，这类漏报比误报更危险）。 */
function stripLeadingCommentsAndSpace(text) {
  let s = text;
  for (;;) {
    const t = s.replace(/^\s+/, '');
    if (t.startsWith('//')) {
      const nl = t.indexOf('\n');
      s = nl === -1 ? '' : t.slice(nl + 1);
      continue;
    }
    if (t.startsWith('/*')) {
      const end = t.indexOf('*/');
      s = end === -1 ? '' : t.slice(end + 2);
      continue;
    }
    return t;
  }
}

/** 把正则的所有匹配收集成数组（用于「取最靠近调用点之前一次声明」而非「文件里第一次出现」） */
function findAllMatches(re, text) {
  const withG = new RegExp(re.source, re.flags.includes('g') ? re.flags : re.flags + 'g');
  const out = [];
  let m;
  while ((m = withG.exec(text))) {
    out.push(m);
    if (m[0].length === 0) withG.lastIndex++; // 防零宽匹配死循环
  }
  return out;
}

/**
 * 从 pos 起反复跳过形如 `IDENT<可选泛型>(` 或紧跟的 `() =>` 这类"包装调用"开头，直到遇到真正的
 * 载荷起点 `[` 或 `{` 为止。这段代码里给数组套一层小工具函数是常见风格——
 * `computed<ProColumn[]>(() => ...)`、`withColKeys([...])`、`withSearchAnchors([...])`——
 * 硬编码认 computed 一种会漏掉其它几种（实测踩过 withColKeys，整条 allColumns 链路因此断掉）。
 * 最多跳 4 层，防止认不出的写法把它带到天涯海角。
 */
function skipWrapperCalls(text, pos) {
  let i = pos;
  for (let guard = 0; guard < 4; guard++) {
    while (/\s/.test(text[i])) i++;
    if (text[i] === '[' || text[i] === '{') return i;
    const callRe = /^[A-Za-z_$][\w$]*\s*(?:<[^>(]*(?:<[^>]*>)?[^>(]*>)?\s*\(\s*(?:\(\)\s*=>\s*)?/;
    const m = callRe.exec(text.slice(i, i + 200));
    if (!m) return null;
    i += m[0].length;
  }
  return null;
}

/**
 * 在 sourceText 里找 `const <varName> = <可能套若干层包装调用>(...)` 最终指向的数组/块体，
 * 返回 { arrayText, arrayAbsStart, hasPostSort, matchIndex }。
 * 支持两种箭头函数体：直接返回数组 `() => [...]`，或块体 `() => { ... return [...]; }`。
 *
 * beforeIndex：只考虑「声明位置 < beforeIndex」的匹配，并取其中最靠后（最贴近调用点）的一个。
 * ⚠️ 这不是可选的美化——像 `base`/`options` 这类泛用名，同一个大文件里很可能被复用在完全不相关的
 * 局部作用域，若不限定"必须在引用点之前、且取最近的"，会静默抓到风马牛不相及的另一处声明
 * （实测踩过：member/user 的 useUserPage.ts 里 `base` 在别处另有一次声明，不加此限定会抓错）。
 */
function findArrayDeclaration(sourceText, varName, beforeIndex = Infinity) {
  const declRe = new RegExp(`const\\s+${varName}\\s*=\\s*`, 'gm');
  const matches = findAllMatches(declRe, sourceText).filter((mm) => mm.index < beforeIndex);
  if (!matches.length) return null;
  const m = matches[matches.length - 1];
  const payloadStart = skipWrapperCalls(sourceText, m.index + m[0].length);
  if (payloadStart === null) return null;
  let i = payloadStart;

  let blockStart = -1;
  let blockEnd = -1;
  if (sourceText[i] === '{') {
    // 块体箭头函数：找函数体范围 + 内部的 return 语句。return 后面可能直接是 `[`，也可能先套一层
    // 包装函数调用再是 `[`（如 `return withSearchAnchors([...])`——member/user 的 searchColumns
    // 就是这种写法，最初漏了这种形态导致整段搜索项提取全军覆没）。
    blockStart = i;
    blockEnd = matchBracket(sourceText, i);
    if (blockEnd === -1) return null;
    const body = sourceText.slice(i, blockEnd + 1);
    const retRe = /return\s+(?:[A-Za-z_$][\w$]*\s*\()*\s*\[/;
    const rm = retRe.exec(body);
    if (!rm) return null;
    i = blockStart + rm.index + rm[0].length - 1; // 指向函数体内 return 后的 '['
  }
  if (sourceText[i] !== '[') return null;
  const arrEnd = matchBracket(sourceText, i);
  if (arrEnd === -1) return null;
  const arrayAbsStart = i;
  const arrayText = sourceText.slice(i, arrEnd + 1);

  // 探测 .sort( 二次重排：数组字面量结束 到 （块体结束 或 紧跟的 `);`） 之间
  const tailEnd = blockEnd !== -1 ? blockEnd : Math.min(sourceText.length, arrEnd + 200);
  const tail = sourceText.slice(arrEnd + 1, tailEnd);
  const hasPostSort = /\.sort\(/.test(tail);

  return { arrayText, arrayAbsStart, hasPostSort, matchIndex: m.index, searchFrom: arrEnd + 1 };
}

/** 深度感知地切出数组字面量里的「顶层元素」：{...} 对象 原样保留；...ident 展开式单独一条。
 *  同时带上每个元素在 arrayText 里的绝对起始 offset（供调用方换算出在 sourceText 里的绝对位置，
 *  这样解析 `...base` 这类展开引用时才能正确限定"必须在这次引用之前声明"）。 */
function splitTopLevelElements(arrayText) {
  const inner = arrayText.slice(1, -1);
  const elements = [];
  let depth = 0;
  let start = 0;
  const pushPiece = (rawPiece, rawStart) => {
    const piece = rawPiece.trim();
    if (!piece) return;
    const contentOffsetInPiece = rawPiece.indexOf(piece);
    // 分类判据用「剥掉开头注释后」的文本，但 el.text 仍保留原文（含注释）供字段正则提取用
    const classify = stripLeadingCommentsAndSpace(piece);
    elements.push({ text: piece, classify, offset: rawStart + contentOffsetInPiece });
  };
  for (let i = 0; i < inner.length; ) {
    const skip = skipCommentOrString(inner, i);
    if (skip !== i) {
      i = skip;
      continue;
    }
    const c = inner[i];
    if (c === '{' || c === '[' || c === '(') depth++;
    else if (c === '}' || c === ']' || c === ')') depth--;
    else if (c === ',' && depth === 0) {
      pushPiece(inner.slice(start, i), start);
      start = i + 1;
    }
    i++;
  }
  pushPiece(inner.slice(start), start);
  return elements;
}

/** 从形如 `NAME` 或 `cond ? A.value : B.value` 的展开表达式里，提取候选标识符列表 */
function extractSpreadCandidates(exprText) {
  const ids = new Set();
  const re = /([A-Za-z_$][\w$]*)(?:\.value)?/g;
  let m;
  while ((m = re.exec(exprText))) {
    if (m[1] !== 'value') ids.add(m[1]);
  }
  return [...ids];
}

/** 找 `const IDENT = <expr>;`（不要求 computed/不要求以 [ 开头的一般赋值），返回 { expr, matchIndex }。
 *  同 findArrayDeclaration：按 beforeIndex 限定只找调用点之前、且取最靠后（最近）的一次声明。 */
function findGenericConstExpr(sourceText, varName, beforeIndex = Infinity) {
  const re = new RegExp(`const\\s+${varName}\\s*=\\s*`, 'gm');
  const matches = findAllMatches(re, sourceText).filter((mm) => mm.index < beforeIndex);
  if (!matches.length) return null;
  const m = matches[matches.length - 1];
  const i = m.index + m[0].length;
  let depth = 0;
  let j = i;
  for (; j < sourceText.length; j++) {
    const c = sourceText[j];
    if (c === '(' || c === '[' || c === '{') depth++;
    else if (c === ')' || c === ']' || c === '}') depth--;
    else if (c === ';' && depth === 0) break;
  }
  return { expr: sourceText.slice(i, j), matchIndex: m.index };
}

/**
 * 递归把一个标识符解析成它最终指向的「对象文本」数组，返回 { objs, hasPostSort }。
 * 支持三种情况：① computed(()=>[...]) 或 computed(()=>{...return [...]}) ② 直接数组字面量
 * ③ 间接赋值，如 `const base = vertical ? verticalColumns.value : allColumns.value;`——
 * 这种情况取表达式里出现的候选标识符中「递归解析后对象数最多」的一支（三元表达式在静态分析下
 * 无法判断实际走哪支，用对象数量做启发式代理：字面量意义上更完整的候选更可能是主列表）。
 * 深度限制 4 层，防止链路异常长或自引用死循环。
 *
 * hasPostSort 全程往上冒泡：真实顺序检查关心的是「链路上任何一层是否被 .sort() 二次重排过」，
 * 不只是最外层——member/user 就是典型例子：`columns` 自己没 sort，但它间接指向的 `allColumns`
 * 末尾有 `.sort()`，这层信息如果在递归中丢了，顺序检查会对着字面量顺序断言违规，而真实渲染顺序
 * 其实是被排过的、跟字面量顺序不一样。
 *
 * beforeIndex 全程传递：每层递归都只在「上一层声明位置之前」找，避免抓到同名但语义完全不同的
 * 另一处声明（大文件里泛用变量名如 base/options 被复用是常态）。
 */
function resolveIdentifierToObjects(ident, sourceText, depth = 0, beforeIndex = Infinity) {
  if (depth > 4) return { objs: [], hasPostSort: false };
  const decl = findArrayDeclaration(sourceText, ident, beforeIndex);
  if (decl) {
    const r = resolveObjectTexts(decl.arrayText, decl.arrayAbsStart, sourceText, depth);
    return { objs: r.objs, hasPostSort: r.hasPostSort || decl.hasPostSort };
  }
  const gen = findGenericConstExpr(sourceText, ident, beforeIndex);
  if (!gen) return { objs: [], hasPostSort: false };
  const candidates = extractSpreadCandidates(gen.expr).filter((c) => c !== ident);
  let best = { objs: [], hasPostSort: false };
  for (const cand of candidates) {
    const resolved = resolveIdentifierToObjects(cand, sourceText, depth + 1, gen.matchIndex);
    // 对象数更多者优先；数量打平时优先选「带 hasPostSort 信号」的一支——宁可谨慎降级成低置信度，
    // 也不要因为凑巧撞上另一支同样数量的候选（如 member/user 的 verticalColumns 跟 allColumns
    // 撞了个正好都是 40 项）而把 .sort() 二次重排的信号弄丢，导致顺序检查错误地给出高置信度断言。
    if (
      resolved.objs.length > best.objs.length ||
      (resolved.objs.length === best.objs.length && resolved.hasPostSort && !best.hasPostSort)
    ) {
      best = resolved;
    }
  }
  return best;
}

/**
 * 解析数组文本，展开 spread 引用，返回 { objs, hasPostSort }（顶层对象文本列表 + 链路上是否
 * 出现过 .sort() 二次重排，见上方 resolveIdentifierToObjects 的说明）。
 * 遇到 `...IDENT` 展开：递归解析 IDENT 最终指向的对象数组。
 *
 * arrayAbsStart：本数组字面量在 sourceText 里的绝对起始位置（即那个 `[` 的下标）。用它 + 每个
 * 顶层元素在数组内的相对 offset，算出「这次 `...ident` 引用本身」的绝对位置，作为「ident 必须
 * 声明在此之前」的边界——不能直接拿"外层 computed 声明的起点"当边界，因为像 `base` 这种局部变量
 * 是在同一个 computed 的函数体内、比其自己的 `const columns = computed(...)` 起点更靠后的地方
 * 声明的（先 `const base = ...`，然后函数体末尾才 `return [...base, ...]`）。
 */
function resolveObjectTexts(arrayText, arrayAbsStart, sourceText, depth = 0) {
  const elements = splitTopLevelElements(arrayText);
  const objs = [];
  let hasPostSort = false;
  for (const el of elements) {
    const elAbsPos = arrayAbsStart + 1 + el.offset; // +1 跳过数组自己的开头 '['
    if (el.classify.startsWith('{')) {
      objs.push(el.text);
    } else if (el.classify.startsWith('...') && depth < 4) {
      const expr = el.classify.slice(3).trim();
      const candidates = extractSpreadCandidates(expr);
      let best = { objs: [], hasPostSort: false };
      for (const cand of candidates) {
        const resolved = resolveIdentifierToObjects(cand, sourceText, depth + 1, elAbsPos);
        // 对象数更多者优先；数量打平时优先选「带 hasPostSort 信号」的一支——宁可谨慎降级成低置信度，
    // 也不要因为凑巧撞上另一支同样数量的候选（如 member/user 的 verticalColumns 跟 allColumns
    // 撞了个正好都是 40 项）而把 .sort() 二次重排的信号弄丢，导致顺序检查错误地给出高置信度断言。
    if (
      resolved.objs.length > best.objs.length ||
      (resolved.objs.length === best.objs.length && resolved.hasPostSort && !best.hasPostSort)
    ) {
      best = resolved;
    }
      }
      objs.push(...best.objs);
      hasPostSort = hasPostSort || best.hasPostSort;
    }
    // 其它顶层元素（比如裸变量名不是spread、条件表达式等）直接忽略，非本工具目标
  }
  return { objs, hasPostSort };
}

/** 从对象文本里做字段级正则提取（启发式，非真 AST） */
function extractFields(objText, sourceText = null) {
  const grab = (text, re) => {
    const m = text.match(re);
    return m ? m[1] : null;
  };
  const key = grab(objText, /\bkey:\s*'([^']+)'/) || grab(objText, /\bpath:\s*'([^']+)'/);
  const isMerchantCol = /merchantSearchColumn\(/.test(objText) || /\.\.\.merchantCol\b/.test(objText);

  // 商户搜索项常见写法是 `{...merchantCol, render:..., rules:[...]}`——multiple/showRequireMark
  // 实际写在构造 merchantCol 那次 `merchantSearchColumn({...})` 调用的参数里，不在这个展开合并对象
  // 自己的文本里。若本对象文本里找不到，且能在 sourceText 里定位到那次调用，就去调用参数里补找，
  // 否则 R63 会因为看不到 multiple:false 而误报「商户项没设单选」（明明设了，只是写在别处）。
  let extraText = '';
  if (isMerchantCol && sourceText && !/\bmultiple:\s*(true|false)\b/.test(objText)) {
    const callRe = /merchantSearchColumn\(\s*\{/;
    const cm = callRe.exec(sourceText);
    if (cm) {
      const braceStart = sourceText.indexOf('{', cm.index);
      const braceEnd = matchBracket(sourceText, braceStart);
      if (braceEnd !== -1) extraText = sourceText.slice(braceStart, braceEnd + 1);
    }
  }
  const combined = objText + ' ' + extraText;

  // R47 判据（有无 NTag/NSwitch/NRadio）只看本对象自己的文本会漏报：很多状态列的 render 是
  // `render(row) { return renderStatusTag(...); }` 这种委托给同文件辅助函数的写法（真实存在，
  // member/user 的 status 列就是这样，辅助函数内部用 NTag，但列对象自己的文本里看不到 NTag 字样）。
  // 若本对象带 render 且能在 sourceText 里找到被调用的辅助函数定义，把辅助函数体也纳入检测范围，
  // 减少「实际是 Tag/Switch 却因为委托了一层就没查到」的漏报。
  let controlText = objText;
  if (sourceText && /\brender\b/.test(objText)) {
    const renderTail = objText.slice(objText.search(/\brender\b/));
    const nameRe = /\b([A-Za-z_$][\w$]*)\s*\(/g;
    const skip = new Set(['h', 'row', 'render', 'return', 'require']);
    let nm;
    while ((nm = nameRe.exec(renderTail))) {
      const name = nm[1];
      if (skip.has(name)) continue;
      const fnRe = new RegExp(`function\\s+${name}\\s*\\(|const\\s+${name}\\s*=\\s*\\(`, 'm');
      const fm = fnRe.exec(sourceText);
      if (!fm) continue;
      // 参数列表可能是 TS 多行签名（每个参数带类型注解另起一行），"函数体开始的 {" 离函数名可能
      // 隔着上百个字符——不能靠字符距离猜，必须先用括号计数正确跳过整段参数列表，再找它后面第一个
      // {（中间可能还有 `): ReturnType` 这样的返回类型标注）。
      const openParen = sourceText.indexOf('(', fm.index);
      if (openParen === -1) continue;
      const closeParen = matchBracket(sourceText, openParen);
      if (closeParen === -1) continue;
      const afterParams = sourceText.slice(closeParen + 1, closeParen + 160);
      const braceRel = afterParams.indexOf('{');
      if (braceRel === -1) continue;
      const braceStart = closeParen + 1 + braceRel;
      const braceEnd = matchBracket(sourceText, braceStart);
      if (braceEnd !== -1) controlText += ' ' + sourceText.slice(braceStart, braceEnd + 1);
    }
  }

  return {
    raw: objText,
    key,
    path: grab(objText, /\bpath:\s*'([^']+)'/),
    titleKey: grab(objText, /\btitle:\s*t\(\s*['"]([^'"]+)['"]/),
    labelKey: grab(objText, /\blabel:\s*t\(\s*['"]([^'"]+)['"]/),
    align: grab(objText, /\balign:\s*'(\w+)'/),
    valueType: grab(objText, /\bvalueType:\s*'([\w-]+)'/),
    multiple: /\bmultiple:\s*false\b/.test(combined)
      ? false
      : /\bmultiple:\s*true\b/.test(combined)
        ? true
        : null,
    hasRequireMark:
      /showRequireMark/.test(combined) || /requiredRule/.test(combined) || /\brules:\s*\[/.test(objText),
    hasSwitch: /NSwitch|n-switch|ConfirmSwitch/i.test(controlText),
    hasTag: /NTag|n-tag/i.test(controlText),
    hasRadio: /NRadio|n-radio/i.test(controlText),
    isMerchantCol,
  };
}

/**
 * 定位页面某个绑定标识符（如 columns/tableColumns/searchColumns）的真实列对象数组。
 * 先试 .vue 同文件，找不到再试同目录 use*.ts composable 文件。
 * 展开 spread 后若对象数仍然可疑地少（<3），标 lowConfidence，供报告层提示人工核对。
 */
function locateColumnObjects(pageDir, varName) {
  if (!varName) return { objects: [], hasPostSort: false, file: null, lowConfidence: true };
  const candidates = [path.join(pageDir, 'index.vue')];
  if (fs.existsSync(pageDir)) {
    for (const f of fs.readdirSync(pageDir)) {
      if (/^use.*\.ts$/.test(f)) candidates.push(path.join(pageDir, f));
    }
  }
  for (const file of candidates) {
    if (!fs.existsSync(file)) continue;
    const src = fs.readFileSync(file, 'utf8');
    const decl = findArrayDeclaration(src, varName);
    if (!decl) continue;
    const resolved = resolveObjectTexts(decl.arrayText, decl.arrayAbsStart, src);
    const objects = resolved.objs.map((t) => extractFields(t, src));
    return {
      objects,
      hasPostSort: decl.hasPostSort || resolved.hasPostSort,
      file,
      lowConfidence: objects.length < 3,
    };
  }
  return { objects: [], hasPostSort: false, file: null, lowConfidence: true };
}

// ============================================================
// 2. i18n key 解析
// ============================================================
const localeCache = {};
/**
 * 加载某个 i18n namespace 文件并按 t('ns.a.b') 的寻址口径「解开」。
 * ⚠️ 实测全部 namespace 文件（game.json/common.json/member.json/components.json...）
 * 顶层都自包一个与文件同名的外层 key（如 game.json 顶层是 { game: {...} }，
 * common.json 顶层是 { common: {...}, user: {...} }），不是直接就是内容本身。
 * 不解开这层会导致所有 t('ns.xxx') key 解析全部失败（曾经的真实 bug，R31/R82 命名检查
 * 曾因此静默漏报）。若某 namespace 文件不带这层包裹（未观察到，但防御性兜底），回退用原始 json。
 */
function loadLocaleNs(ns, locale) {
  const cacheKey = `${locale}/${ns}`;
  if (cacheKey in localeCache) return localeCache[cacheKey];
  const p = path.join(PROJ_ROOT, 'src/i18n/locales', locale, `${ns}.json`);
  let json = null;
  try {
    const raw = JSON.parse(fs.readFileSync(p, 'utf8'));
    json = raw && typeof raw === 'object' && ns in raw ? raw[ns] : raw;
  } catch {
    json = null;
  }
  localeCache[cacheKey] = json;
  return json;
}
function resolveI18nText(key, locale = 'zh') {
  if (!key || !key.includes('.')) return null;
  const [ns, ...rest] = key.split('.');
  const json = loadLocaleNs(ns, locale);
  if (!json) return null;
  let cur = json;
  for (const seg of rest) {
    if (cur == null || typeof cur !== 'object') return null;
    cur = cur[seg];
  }
  return typeof cur === 'string' ? cur : null;
}

// ============================================================
// 3. 规则检查器
// ============================================================

// ---- R82：末尾列相对顺序 + 固定命名 ----
const R82_ORDER = ['state', 'creator', 'createTime', 'lastModifyUser', 'lastUpdateTime', 'remark'];
const R82_SEMANTIC_ALIASES = {
  state: ['state', 'status', 'userState', 'merchantState'],
  creator: ['creator'],
  createTime: ['createTime'],
  lastModifyUser: ['operator', 'lastModifier', 'updateUser', 'modifyUser'],
  lastUpdateTime: ['lastUpdateTime', 'updateTime'],
  remark: ['remark'],
};
const WRONG_NAMING = {
  creator: { bad: ['创建者', '建立人'], good: '创建人' },
  createTime: { bad: ['新建时间'], good: '创建时间' },
  lastModifyUser: { bad: ['操作人', '修改人', '最后操作人'], good: '最后修改人' },
  lastUpdateTime: { bad: ['更新时间'], good: '最后修改时间' },
};
function semanticSlotOf(col) {
  for (const [slot, aliases] of Object.entries(R82_SEMANTIC_ALIASES)) {
    if (aliases.includes(col.key)) return slot;
  }
  return null;
}
function checkR82(columns, hasPostSort, pageName) {
  const findings = [];
  const present = columns.map((c, idx) => ({ ...c, idx, slot: semanticSlotOf(c) })).filter((c) => c.slot);

  const order = present.map((c) => c.slot);
  const expectedOrder = R82_ORDER.filter((s) => order.includes(s));
  const actualFiltered = order.filter((s) => expectedOrder.includes(s));
  const orderOk = JSON.stringify(actualFiltered) === JSON.stringify(expectedOrder);
  if (!orderOk && expectedOrder.length >= 2) {
    findings.push({
      rule: 'R82',
      severity: hasPostSort ? 'low' : 'high',
      page: pageName,
      location: `末尾列相对顺序：实际 [${actualFiltered.join('→')}]`,
      message: hasPostSort
        ? `该列表在字面量之后还有 .sort() 二次重排，字面量顺序仅供参考，需人工核对真实渲染顺序是否为 [${expectedOrder.join('→')}]`
        : `应为 [${expectedOrder.join('→')}]，实际是 [${actualFiltered.join('→')}]`,
      suggestion: '调整这几列在数组中的先后位置，使其符合「状态→创建人→创建时间→最后修改人→最后修改时间→备注」的相对顺序',
    });
  }

  for (const c of present) {
    const rule = WRONG_NAMING[c.slot];
    const zhText = c.titleKey ? resolveI18nText(c.titleKey, 'zh') : null;
    if (rule && zhText && rule.bad.includes(zhText)) {
      findings.push({
        rule: 'R82',
        severity: 'high',
        page: pageName,
        location: `列 key='${c.key}'（i18n key: ${c.titleKey}）`,
        message: `列文案是"${zhText}"，应统一叫"${rule.good}"`,
        suggestion: `把 ${c.titleKey} 对应的 zh 文案改成"${rule.good}"`,
      });
    }
    if (c.slot === 'lastModifyUser' && c.titleKey) {
      if (c.titleKey === 'common.operator') {
        findings.push({
          rule: 'R82',
          severity: 'high',
          page: pageName,
          location: `列 key='${c.key}'`,
          message: `该列语义是"最后修改人"，但 title 直接引用共享键 common.operator（文案是"操作人"）`,
          suggestion: `不能直接改 common.operator 的值（会影响全站其它用到"操作人"语义的地方，且会泄漏到商户端），只改这一列的 title 引用，指向 common.last_modify_user`,
        });
      } else if (c.titleKey !== 'common.last_modify_user' && zhText === '最后修改人') {
        findings.push({
          rule: 'R82',
          severity: 'low',
          page: pageName,
          location: `列 key='${c.key}'（i18n key: ${c.titleKey}）`,
          message: `文案已经是"最后修改人"（没错），但引用的是页面自建 key 而非共享键 common.last_modify_user`,
          suggestion: '非必须；如需全站统一引用同一个共享键，可改指向 common.last_modify_user（低优先级规范建议，不是文案错误）',
        });
      }
    }
  }
  return findings;
}

// ---- R16 / R41 / R61：对齐 ----
// wallet/钱包/红包 系已实测踩过漏报：member/user 的 strategyWallet（策略钱包余额，源码注释明确写了
// 「金额列居左（R61）」）字段名不含 amount/balance 等词根，之前会被误判成"该居中但没居中"。
const AMOUNT_HINT = /(amount|flow|balance|wallet|余额|金额|流水|充值|钱包|红包)/i;
const COUNT_HINT = /(count|times|次数|个数|计数)/i;
// 操作/操作列：本站两种实现方式对默认对齐的约定不同——走共享组件 createActionColumn 的默认居中
// （见 src/components/Table/src/createActionColumn.ts:128），但像 member/user 这种手写多按钮
// 操作列有意用 align:'left'（源码注释：多按钮横排更好读，titleAlign 仍居中）。这是「操作列该不该
// 套用 R16 默认居中」的开放问题、不是本工具能单方面拍板的交互细节，故直接跳过不查，留给人工判断。
const ACTION_COLUMN_KEY = /^(operations?|actions?)$/i;
function checkAlignment(columns, pageName) {
  const findings = [];
  for (const c of columns) {
    if (!c.key || !c.align) continue;
    if (ACTION_COLUMN_KEY.test(c.key)) continue;
    const isAmount = AMOUNT_HINT.test(c.key) && !COUNT_HINT.test(c.key);
    const hasWrapText = /lineClamp|renderRichText/.test(c.raw);
    let expected = 'center';
    let ruleTag = 'R16';
    let reason = '默认应居中';
    if (isAmount) {
      expected = 'left';
      ruleTag = 'R61';
      reason = '字段名含金额/流水类关键词';
    } else if (hasWrapText) {
      expected = 'left';
      ruleTag = 'R41';
      reason = '含多行渲染(lineClamp/renderRichText)';
    }
    if (c.align !== expected) {
      findings.push({
        rule: ruleTag,
        severity: 'medium',
        page: pageName,
        location: `列 key='${c.key}'`,
        message: `align='${c.align}'，按启发式判断应为 '${expected}'（${reason}）`,
        suggestion: `把该列 align 改成 '${expected}'；如果是计数类字段被误判成金额，或者多行判断误触发，请忽略本条`,
      });
    }
  }
  return findings;
}

// ---- R47：状态列必须用开关（支持豁免清单） ----
function loadExemptions() {
  const p = path.join(PROJ_ROOT, 'scripts/lint-exemptions.json');
  try {
    return JSON.parse(fs.readFileSync(p, 'utf8'));
  } catch {
    return [];
  }
}
function isExempt(exemptions, pageName, columnKey, rule) {
  return exemptions.some(
    (e) => e.rule === rule && e.page === pageName && (e.columnKey === columnKey || e.columnKey === '*'),
  );
}
function checkR47(columns, pageName, exemptions) {
  const findings = [];
  for (const c of columns) {
    if (!c.key) continue;
    if (!/^(state|status|merchantState|vendorState|userState)$/i.test(c.key)) continue;
    if (isExempt(exemptions, pageName, c.key, 'R47')) continue;
    if (c.hasTag && !c.hasSwitch) {
      findings.push({
        rule: 'R47',
        severity: 'medium',
        page: pageName,
        location: `列 key='${c.key}'`,
        message: '状态列渲染为只读 Tag，未用开关(Switch)',
        suggestion: `改成 Switch 控件；如果这是已拍板的既定例外，把 {page:'${pageName}', columnKey:'${c.key}', rule:'R47', reason:'...'} 加进 scripts/lint-exemptions.json`,
      });
    } else if (c.hasRadio) {
      findings.push({
        rule: 'R47',
        severity: 'medium',
        page: pageName,
        location: `列 key='${c.key}'`,
        message: '状态用单选(radio)，未用开关(Switch)',
        suggestion: '同上，改 Switch 或登记进豁免清单',
      });
    }
  }
  return findings;
}

// ---- R63：商户 + 会员ID 共存必须单选必填 ----
const MEMBER_ID_HINT = /^(memberId|userId)$/i;
function checkR63(searchColumns, pageName) {
  const findings = [];
  const merchantCol = searchColumns.find((c) => c.isMerchantCol);
  const memberIdCol = searchColumns.find((c) => c.path && MEMBER_ID_HINT.test(c.path));
  if (!merchantCol || !memberIdCol) return findings;
  if (merchantCol.multiple !== false) {
    findings.push({
      rule: 'R63',
      severity: 'high',
      page: pageName,
      location: `搜索项：商户筛选 + ${memberIdCol.path}`,
      message: `商户筛选与会员ID筛选共存，但商户项 multiple !== false（当前:${merchantCol.multiple}）`,
      suggestion: '商户筛选项设为单选 multiple:false',
    });
  }
  if (!merchantCol.hasRequireMark) {
    findings.push({
      rule: 'R63',
      severity: 'high',
      page: pageName,
      location: `搜索项：商户筛选 + ${memberIdCol.path}`,
      message: '商户筛选与会员ID筛选共存，但商户项未见必填标记(showRequireMark/rules)',
      suggestion: '商户筛选项加 formItemProps.showRequireMark:true + 必填校验规则',
    });
  }
  return findings;
}

// ---- R60：查询项顺序与列表列序一致 ----
function checkR60(columns, searchColumns, pageName, hasPostSort) {
  const colKeys = columns.map((c) => c.key).filter(Boolean);
  const searchPaths = searchColumns.map((c) => c.path).filter(Boolean);
  const both = colKeys.filter((k) => searchPaths.includes(k));
  if (both.length < 2) return [];
  const searchOrderOfBoth = searchPaths.filter((p) => both.includes(p));
  if (JSON.stringify(searchOrderOfBoth) !== JSON.stringify(both)) {
    return [
      {
        rule: 'R60',
        // 同 R82：列表列序如果是字面量之后又被 .sort() 重排过的，这里比对用的"列表列顺序"就不一定
        // 是真实渲染顺序，判定要降级成低置信度而不是断言违规。
        severity: hasPostSort ? 'low' : 'medium',
        page: pageName,
        location: `既是列又是查询项的字段：[${both.join(', ')}]`,
        message: hasPostSort
          ? `查询项顺序 [${searchOrderOfBoth.join('→')}]，但列表列顺序 [${both.join('→')}] 取自可能被 .sort() 二次重排过的数据，需人工核对真实列序后再判断是否真的不一致`
          : `查询项顺序 [${searchOrderOfBoth.join('→')}] 与列表列顺序 [${both.join('→')}] 不一致`,
        suggestion: '调整搜索表单里这几项的先后位置，使其跟列表列顺序一致；调列表列序时记得同步问一下搜索项是否要跟着调（R60 必问条款）',
      },
    ];
  }
  return [];
}

// ---- R20："端" 该是 "设备" 的术语检查 ----
const R20_LEGIT_DUAN = ['总控端', '商户端', '客户端', 'PC端', '移动端', '前端', '后端', '服务端', 'H5端'];
const R20_DEVICE_HINT_KEY = /(device|client|phonetype|terminal)/i;
function checkR20(textEntries, pageName) {
  const findings = [];
  for (const { key, zhText } of textEntries) {
    if (!zhText || !zhText.includes('端')) continue;
    if (R20_LEGIT_DUAN.some((w) => zhText.includes(w))) continue;
    if (R20_DEVICE_HINT_KEY.test(key)) {
      findings.push({
        rule: 'R20',
        severity: 'low',
        page: pageName,
        location: `i18n key: ${key}`,
        message: `文案"${zhText}"含"端"字，字段语义像是设备(device/client)，疑似应改用"设备"术语`,
        suggestion: '人工确认：若说的是"登录设备/注册设备"这类 7 种设备场景，应把"端"改成"设备"；若是总控端/商户端角色语境，忽略本条',
      });
    }
  }
  return findings;
}

// ---- R31：i18n zh/en 对称（限定本页用到的 key） ----
function collectUsedI18nKeys(sourceTexts) {
  const keys = new Set();
  const re = /\bt\(\s*['"]([\w.]+)['"]/g;
  for (const src of sourceTexts) {
    if (!src) continue;
    let m;
    while ((m = re.exec(src))) keys.add(m[1]);
  }
  return [...keys];
}
function checkR31(usedKeys, pageName) {
  const findings = [];
  const byNs = {};
  for (const k of usedKeys) {
    const ns = k.split('.')[0];
    (byNs[ns] = byNs[ns] || new Set()).add(k);
  }
  for (const [ns, keySet] of Object.entries(byNs)) {
    const zhJson = loadLocaleNs(ns, 'zh');
    if (!zhJson) continue;
    for (const key of keySet) {
      const zhVal = resolveI18nText(key, 'zh');
      if (zhVal == null) continue;
      const enVal = resolveI18nText(key, 'en');
      if (enVal == null) {
        findings.push({
          rule: 'R31',
          severity: 'medium',
          page: pageName,
          location: `i18n key: ${key}`,
          message: `zh 有该 key（"${zhVal}"），en/${ns}.json 缺对应 key`,
          suggestion: `在 src/i18n/locales/en/${ns}.json 补上对应英文翻译`,
        });
      }
    }
  }
  return findings;
}

// ============================================================
// 4. 报告渲染
// ============================================================
const SEVERITY_RANK = { high: 0, medium: 1, low: 2 };
const SEVERITY_LABEL = { high: '[严重]', medium: '[一般]', low: '[提示]' };

function renderReport(findingsByPage, meta) {
  const lines = [];
  lines.push('='.repeat(72));
  lines.push('AR V3 · UI 规则扫描报告（机械检查，仅供参考，不代替人工复核）');
  lines.push('='.repeat(72));
  let total = 0;
  for (const [page, findings] of Object.entries(findingsByPage)) {
    lines.push('');
    lines.push(`【页面】${page}（共 ${findings.length} 条）`);
    if (meta[page]?.lowConfidenceColumns) {
      lines.push('  [警告] 列提取数量偏少，解析器可能没找全表格列定义，以下结果置信度降低，建议人工核对。');
    }
    if (meta[page]?.lowConfidenceSearch) {
      lines.push('  [警告] 搜索项提取数量偏少，解析器可能没找全搜索表单定义，以下结果置信度降低，建议人工核对。');
    }
    if (findings.length === 0) {
      lines.push('  未发现问题。');
      continue;
    }
    const sorted = [...findings].sort((a, b) => SEVERITY_RANK[a.severity] - SEVERITY_RANK[b.severity]);
    for (const f of sorted) {
      total++;
      lines.push(`  ${SEVERITY_LABEL[f.severity]} [${f.rule}] ${f.location}`);
      lines.push(`      问题：${f.message}`);
      lines.push(`      建议：${f.suggestion}`);
    }
  }
  lines.push('');
  lines.push('-'.repeat(72));
  lines.push(`总计 ${total} 条（不代表都是真问题，误报很正常，人工过一遍再动手改）`);
  lines.push('本轮试点范围：' + Object.keys(findingsByPage).join(' / ') + '（全站扫描是下一轮任务，未经确认不会自动扩大）');
  return lines.join('\n');
}

// ============================================================
// 5. 主流程
// ============================================================
function lintPage(pageDef) {
  const vueFile = path.join(pageDef.dir, 'index.vue');
  const { columnsVar, searchColumnsVar } = findBoundIdentifiers(vueFile);

  const colResult = locateColumnObjects(pageDef.dir, columnsVar);
  const searchResult = locateColumnObjects(pageDef.dir, searchColumnsVar);
  const exemptions = loadExemptions();

  const findings = [
    ...checkR82(colResult.objects, colResult.hasPostSort, pageDef.name),
    ...checkAlignment(colResult.objects, pageDef.name),
    ...checkR47(colResult.objects, pageDef.name, exemptions),
    ...checkR63(searchResult.objects, pageDef.name),
    ...checkR60(colResult.objects, searchResult.objects, pageDef.name, colResult.hasPostSort),
  ];

  const sourceTexts = [...colResult.objects, ...searchResult.objects].map((o) => o.raw);
  const usedKeys = collectUsedI18nKeys(sourceTexts);
  const textEntries = usedKeys.map((k) => ({ key: k, zhText: resolveI18nText(k, 'zh') }));
  findings.push(...checkR20(textEntries, pageDef.name));
  findings.push(...checkR31(usedKeys, pageDef.name));

  return {
    findings,
    meta: {
      lowConfidenceColumns: colResult.lowConfidence,
      lowConfidenceSearch: searchResult.lowConfidence,
      columnCount: colResult.objects.length,
      searchCount: searchResult.objects.length,
    },
  };
}

function main() {
  const byPage = {};
  const meta = {};
  for (const p of PILOT_PAGES) {
    const { findings, meta: pageMeta } = lintPage(p);
    byPage[p.name] = findings;
    meta[p.name] = pageMeta;
  }
  console.log(renderReport(byPage, meta));
}

main();
