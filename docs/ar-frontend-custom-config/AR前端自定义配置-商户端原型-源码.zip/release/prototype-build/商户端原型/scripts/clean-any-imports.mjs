#!/usr/bin/env node
// Clean up import statements that have 'any' as an import name
// (result of type replacement). Also fix the specific patterns:
//   import { foo, any, bar } from './data' → import { foo, bar } from './data'
//   import { any } from './data' → (remove entire line)

import { readFileSync, writeFileSync } from 'node:fs';
import { glob } from 'glob';

const files = await glob('src/views/**/*.{vue,ts}', { absolute: true });

let modified = 0;

for (const f of files) {
  let content = readFileSync(f, 'utf8');
  const before = content;

  // Remove 'any' from import lists (value position)
  // Pattern: import { ..., any, ... } from '...'
  // We need to handle: any at start, middle, or end of list
  content = content.replace(
    /^(\s*import\s+\{)([^}]+)(\}\s+from\s+['"]\.[^'"]*['"];?\s*)$/gm,
    (match, pre, members, post) => {
      const cleaned = members
        .split(',')
        .map(m => m.trim())
        .filter(m => m !== 'any' && m !== '')
        .join(', ');
      if (!cleaned) return ''; // all removed, delete line
      return `${pre}${cleaned}${post}`;
    },
  );

  // Remove empty import lines (could happen if all members were 'any')
  content = content.replace(/^\s*import\s+\{\s*\}\s+from\s+['"]\.[^'"]*['"];?\s*$\n?/gm, '');

  if (content !== before) {
    writeFileSync(f, content);
    modified++;
    console.log(`[cleaned] ${f.replace(process.cwd() + '/', '')}`);
  }
}

console.log(`\nTotal files cleaned: ${modified}`);
