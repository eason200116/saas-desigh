#!/usr/bin/env node
import { readFileSync, writeFileSync } from 'node:fs';
import { glob } from 'glob';

const files = await glob('src/views/**/*.{vue,ts}', { absolute: true });

let modified = 0;
for (const f of files) {
  let content = readFileSync(f, 'utf8');
  const before = content;

  // 删除 type-only import: import type { ... } from './data';
  content = content.replace(
    /^\s*import\s+type\s+\{[^}]*\}\s+from\s+(['"])\.\/data\1;?\s*$\n?/gm,
    '',
  );

  if (content !== before) {
    writeFileSync(f, content);
    modified++;
    console.log(`[stripped] ${f.replace(process.cwd() + '/', '')}`);
  }
}
console.log(`\nTotal stripped: ${modified}`);
