import assert from 'node:assert/strict';
import { createSemanticDraft, initialLayoutIdForRoute } from '../src/views/config/frontendCustom/AdminLayoutEditor/semanticFixture.ts';
import { activateLayout } from '../src/views/config/frontendCustom/AdminLayoutEditor/useSemanticEditor.ts';
import { switchSemanticLayout } from '../src/views/config/frontendCustom/AdminLayoutEditor/semanticLayoutState.ts';
import { templateDefinitionFor } from '../src/views/config/frontendCustom/AdminLayoutEditor/templateRenderer.ts';
import { applySectionPresentationPatch } from '../src/views/config/frontendCustom/AdminLayoutEditor/semanticPresentation.ts';
import { activePage, aggregatePage, applyDestination, contentSignature,
  drawerCollectionIdForSection, navigationGroup, previewSections,
} from '../src/views/config/frontendCustom/AdminLayoutEditor/semanticResolver.ts';

const draft = createSemanticDraft('layout-ar777');
const originalContentSignature = contentSignature(draft);
const arHome = aggregatePage(draft);
const arTemplate = templateDefinitionFor('layout-ar777');
const featured = arHome.sections.find((item) => item.refId === 'collection-featured')!;
const top = arHome.sections.find((item) => item.refId === 'collection-top')!;
const hot = arHome.sections.find((item) => item.refId === 'collection-hot')!;
const arOrder = arHome.sections.map((item) => item.type === 'collectionRef' ? item.refId : item.type);
const topCollection = draft.content.gameCollections.find((item) => item.id === top.refId)!;
const pinnedTopCollection = draft.content.gameCollections.find((item) => item.id === top.pinnedRefId)!;

assert.equal(topCollection.purpose, 'custom');
assert.equal(pinnedTopCollection.purpose, 'pinned');
assert.notEqual(topCollection.id, pinnedTopCollection.id,
  'Custom and pinned game collections must not share state');
assert.equal(drawerCollectionIdForSection(top), topCollection.id,
  'Custom selection opens the custom collection drawer');
top.presentation.gameSelectionMode = 'data-driven';
top.presentation.sortMetric = 'custom';
top.presentation.sortDirection = 'asc';
assert.equal(drawerCollectionIdForSection(top), undefined,
  'Data-driven selection with custom ordering has no drawer');
top.presentation.sortMetric = 'online-count';
top.presentation.sortDirection = 'desc';
assert.equal(drawerCollectionIdForSection(top), pinnedTopCollection.id,
  'Data sorting opens only the pinned collection drawer');
top.presentation.gameSelectionMode = 'custom';
top.presentation.sortMetric = 'custom';
top.presentation.sortDirection = 'asc';

assert.equal(initialLayoutIdForRoute('layout-public5-default'), 'layout-ar777');
assert.equal(initialLayoutIdForRoute('layout-redhome-default'), 'layout-red1');
assert.equal(initialLayoutIdForRoute('layout-bc-game'), 'layout-bc-game');
const pageStableDraft = createSemanticDraft('layout-ar777');
pageStableDraft.layouts.find((item) => item.id === 'layout-bc-game')!.draft.view = {
  mode: 'full', collectionId: 'collection-originals',
};
assert.ok(activateLayout(pageStableDraft, 'layout-bc-game'));
assert.equal(pageStableDraft.view.mode, 'aggregate',
  'Switching templates must keep the current preview page instead of restoring the target template page');
assert.deepEqual(arOrder, ['collection-featured', 'collection-top',
  'collection-hot', 'navigationRef', 'collection-originals', 'collection-slots']);
assert.deepEqual(arTemplate.slots.map((item) => item.type), ['banner', 'quickEntries']);
assert.equal(arTemplate.chrome.showBottomNav, true);
assert.equal(arHome.sections.every((item) => ['navigationRef', 'collectionRef'].includes(item.type)), true,
  'Template chrome and slots must not enter Page.sections');
assert.deepEqual([featured.presentation.displayMode, featured.presentation.rows,
  featured.presentation.columns, featured.presentation.displayCount], ['recommendation', 1, 1, 1]);
assert.equal(featured.presentation.recommendation?.mainGameId, 'g-crash',
  'Recommendation placement references one primary gameId');
assert.equal(drawerCollectionIdForSection(featured), undefined,
  'Recommendation uses its dedicated single-game picker, not the shared collection drawer');
const recommendationLock = applySectionPresentationPatch(featured.presentation,
  { rows: 9, columns: 8, displayCount: 60, sortMetric: 'online-count', sortDirection: 'desc' }, 'g-crash');
assert.deepEqual([recommendationLock.rows, recommendationLock.columns,
  recommendationLock.displayCount, recommendationLock.sortMetric,
  recommendationLock.sortDirection], [1, 1, 1, 'custom', 'desc']);
assert.deepEqual([top.presentation.rows, top.presentation.columns, top.presentation.displayCount], [1, 5, 5]);
assert.deepEqual([hot.presentation.rows, hot.presentation.columns, hot.presentation.displayCount], [1, 2, 2]);
assert.ok(!arHome.sections.some((item) => arTemplate.slots.some((slot) => slot.id === item.refId)),
  'Template slots must remain outside sortable Page.sections');

applyDestination(draft, { kind: 'openCollection', collectionId: 'collection-top', mode: 'full' });
assert.equal(activePage(draft).level, 'secondary', 'AR777 More maps to an independent level-2 page');
assert.equal(activePage(draft).route, '/ar777/category/top');
top.presentation.displayMode = 'vendor-group';
assert.equal(previewSections(draft).find((item) => item.refId === 'collection-top')
  ?.presentation.displayMode, 'vendor-group',
  'Route-based full collection preview must reuse the edited collection presentation');
top.presentation.displayMode = 'standard-grid';
top.styleSlot = 'ar777-top-private-test';
featured.presentation.recommendation!.mainGameId = 'g-wheel';
featured.presentation.recommendation!.ctaLabel = 'AR777 遊玩';
draft.workflow = 'previewed'; draft.savedRevision = 2;
draft.layouts[0].draft.dirty = true;

assert.ok(switchSemanticLayout(draft, 'layout-bc-game'));
assert.equal(draft.view.mode, 'aggregate');
const bcHome = aggregatePage(draft);
const bcFeatured = bcHome.sections.find((item) => item.refId === 'collection-featured')!;
assert.equal(bcFeatured.presentation.recommendation?.mainGameId, 'g-limbo');
bcFeatured.presentation.recommendation!.mainGameId = 'g-mines';
bcFeatured.presentation.recommendation!.showRank = false;
const bcHot = bcHome.sections.find((item) => item.refId === 'collection-hot')!;
bcHot.presentation.columns = 4;
applyDestination(draft, { kind: 'openCollection', collectionId: 'collection-originals', mode: 'full' });
draft.workflow = 'published'; draft.savedRevision = 4;
assert.equal(activePage(draft).level, 'tertiary', 'BC.Game maps More to level-3');

assert.ok(switchSemanticLayout(draft, 'layout-red1'));
const redHome = aggregatePage(draft);
const redFeatured = redHome.sections.find((item) => item.refId === 'collection-featured')!;
assert.equal(redFeatured.presentation.recommendation?.mainGameId, 'g-gates');
redHome.sections.push(redHome.sections.shift()!);
applyDestination(draft, { kind: 'openCollection', collectionId: 'collection-originals', mode: 'full' });
draft.workflow = 'draft'; draft.savedRevision = 1;
assert.equal(activePage(draft).level, 'secondary', 'Red1 keeps full collection on level-2');
assert.ok(previewSections(draft).some((item) => item.refId === 'collection-originals'));

assert.ok(switchSemanticLayout(draft, 'layout-ar777'));
assert.equal(draft.view.collectionId, 'collection-top');
assert.equal(draft.workflow, 'previewed');
assert.equal(draft.savedRevision, 2);
assert.equal(aggregatePage(draft).sections.find((item) => item.refId === 'collection-top')?.styleSlot,
  'ar777-top-private-test');
assert.deepEqual([top.presentation.columns, hot.presentation.columns], [5, 2]);
assert.deepEqual([featured.presentation.recommendation?.mainGameId,
  featured.presentation.recommendation?.ctaLabel], ['g-wheel', 'AR777 遊玩']);

assert.ok(switchSemanticLayout(draft, 'layout-bc-game'));
assert.equal(draft.view.collectionId, 'collection-originals');
assert.equal(draft.workflow, 'published');
assert.equal(draft.savedRevision, 4);
assert.equal(aggregatePage(draft).sections.find((item) => item.refId === 'collection-hot')
  ?.presentation.columns, 4);
assert.deepEqual([bcFeatured.presentation.recommendation?.mainGameId,
  bcFeatured.presentation.recommendation?.showRank], ['g-mines', false]);

assert.ok(switchSemanticLayout(draft, 'layout-red1'));
assert.equal(draft.view.collectionId, 'collection-originals');
assert.equal(aggregatePage(draft).sections.at(-1)?.type, 'navigationRef');
assert.equal(redFeatured.presentation.recommendation?.mainGameId, 'g-gates');
assert.equal(contentSignature(draft), originalContentSignature,
  'Layout switching and private placement edits cannot rewrite shared content');

assert.ok(switchSemanticLayout(draft, 'layout-ar777'));
assert.equal(activePage(draft).route, '/ar777/category/top');
const restored = JSON.parse(JSON.stringify(draft));
assert.equal(restored.layouts.find((item: { id: string }) => item.id === 'layout-bc-game')
  .pages[0].sections.find((item: { refId: string }) => item.refId === 'collection-hot')
  .presentation.columns, 4, 'Serialized layout-private settings must survive restoration');

const noCategory = createSemanticDraft('layout-ar777');
noCategory.content.sitePages[0].primaryNavigationIds = [];
assert.deepEqual(navigationGroup(noCategory)?.items, []);
assert.ok(previewSections(noCategory).length > 0, 'A homepage without category navigation still renders');
console.log('semantic layout verification: passed');
