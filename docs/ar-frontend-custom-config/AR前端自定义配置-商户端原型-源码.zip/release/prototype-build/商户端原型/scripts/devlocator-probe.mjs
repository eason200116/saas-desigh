// 真实点击探针：登录→抓页面级列真值(key/表头/对齐/样例值/脱敏)+逐个交互抓弹窗控件。R53 以真实渲染为准。
// 用法: node scripts/devlocator-probe.mjs <url1> <url2> ...   输出 JSON 到 /tmp/claude-501/ground/<slug>.json
import { chromium } from 'playwright';
import fs from 'node:fs';
const URLS = process.argv.slice(2);
if(!URLS.length){console.log('需传入至少一个 URL');process.exit(1);}
fs.mkdirSync('/tmp/claude-501/ground',{recursive:true});
const b = await chromium.launch();
const pg = await b.newPage({ viewport:{width:1680,height:950} });
const T=`el=>((el&&el.textContent)||'').replace(/\\s+/g,' ').trim()`;
async function login(){
  await pg.goto('http://localhost:3100/login',{waitUntil:'networkidle'}).catch(()=>{});
  await pg.waitForTimeout(900);
  const inp=pg.locator('input:visible');
  if(await inp.count()>=2){await inp.nth(0).fill('admin');await inp.nth(1).fill('123456');}
  await pg.locator('button:visible:has-text("登录")').first().click().catch(()=>{});
  await pg.waitForTimeout(1600);
}
async function pageLevel(){
  return await pg.evaluate((TS)=>{
    const t=eval(TS);
    // 列：表头 th[data-col-key] + 首行同 key 单元格的对齐/样例
    const ths=[...document.querySelectorAll('.n-data-table-th')];
    const cols=ths.map(th=>{
      const key=th.getAttribute('data-col-key')||'';
      const label=t(th);
      const cell=document.querySelector(`.n-data-table-td[data-col-key="${key}"]`);
      let align='',sample='';
      if(cell){align=getComputedStyle(cell).textAlign; sample=t(cell).slice(0,20);}
      const masked=/\*{2,}|·{2,}|•{2,}/.test(sample);
      return {key,label,align,sample,masked};
    }).filter(c=>c.key&&c.label);
    // 搜索项 label
    const search=[...new Set([...document.querySelectorAll('.pro-search-form-item .n-form-item-label__text,.n-form-item-label__text')].map(t).filter(Boolean))];
    // 工具栏按钮
    const btns=[...new Set([...document.querySelectorAll('button')].filter(x=>x.offsetParent).map(t).filter(x=>x&&x.length<=10))];
    return {cols,search,btns};
  },T);
}
async function capture(){
  return await pg.evaluate((TS)=>{
    const t=eval(TS);
    const ns=[...document.querySelectorAll('.n-modal,.n-drawer')].filter(m=>m.querySelector('.n-card,.n-drawer-content,.n-card-header,.n-drawer-header'));
    const m=ns[ns.length-1]; if(!m)return null;
    const title=t(m.querySelector('.n-card-header__main,.n-drawer-header__main,.n-card-header,.n-drawer-header__main'))||'(无标题)';
    const labels=[...new Set([...m.querySelectorAll('.n-form-item-label__text,.n-form-item-label')].map(t).filter(Boolean))];
    const ctrls=m.querySelectorAll('input,textarea,.n-base-selection,.n-radio,.n-switch,.n-checkbox,.n-input-number').length;
    return {title,labels,ctrls};
  },T);
}
await login();
for(const URL of URLS){
  const slug=URL.replace(/^https?:\/\/[^/]+\//,'').replace(/[^a-zA-Z0-9]+/g,'_');
  await pg.goto(URL,{waitUntil:'networkidle'}).catch(()=>{});
  await pg.waitForTimeout(2200);
  const base=await pageLevel();
  const found=[];
  const cands=[...new Set([...base.btns.filter(x=>x.length<=6&&!/集团|切换|今天|昨天|本周|上周|本月|上月|所有|竖版|搜索|重置|导出|登录/.test(x))])];
  const rowActs=await pg.evaluate((TS)=>{const t=eval(TS);return [...new Set([...document.querySelectorAll('.n-data-table-td--fixed-right button,tbody tr:first-child td:last-child button')].map(t).filter(Boolean))];},T);
  async function clickCap(desc,fn){ await pg.goto(URL,{waitUntil:'networkidle'}).catch(()=>{}); await pg.waitForTimeout(1600); try{await fn();await pg.waitForTimeout(900);const s=await capture();if(s)found.push({trigger:desc,...s});}catch(e){} }
  for(const lb of cands) await clickCap('工具:'+lb, async()=>{await pg.locator(`button:visible:has-text("${lb}")`).first().click({timeout:2000});});
  for(const lb of rowActs) await clickCap('行:'+lb, async()=>{await pg.locator(`.n-data-table-td--fixed-right button:has-text("${lb}"),tbody tr:first-child button:has-text("${lb}")`).first().click({timeout:2000});});
  const out={url:URL, columns:base.cols, search:base.search, buttons:base.btns, modals:found};
  fs.writeFileSync(`/tmp/claude-501/ground/${slug}.json`,JSON.stringify(out,null,2));
  console.log(`\n===== ${URL} =====`);
  console.log(`列${base.cols.length} | 搜索${base.search.length} | 按钮${base.btns.length} | 弹窗${found.length}`);
  const bad=base.cols.filter(c=>c.masked);
  if(bad.length)console.log('  脱敏列(真值带*):',bad.map(c=>c.label+'('+c.key+')').join(','));
  console.log('  列对齐样例:',base.cols.slice(0,6).map(c=>`${c.label}:${c.align}`).join(' '));
  found.forEach(f=>console.log(`  ▶[${f.trigger}]→「${f.title}」控件${f.ctrls} ${f.labels.slice(0,8).join('/')}`));
}
await b.close();
