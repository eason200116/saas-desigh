#!/usr/bin/env node
// 分析 src/views 文件中 import { functionOrType } from './data' 的具体成员，
// 对比 data.ts 实际导出，为缺失的非 api/http 成员在 data.ts 追加占位 export。

import { readFileSync, writeFileSync } from 'node:fs';
import { execSync } from 'node:child_process';
import { glob } from 'glob';
import { dirname, resolve } from 'node:path';

// 1. 收集每个目录的 data.ts 路径
const viewFiles = await glob('src/views/**/*.{vue,ts}', { absolute: true });

// Map: dir → Set<memberName>
const dirMissingMembers = new Map();

for (const f of viewFiles) {
  const content = readFileSync(f, 'utf8');
  const dir = dirname(f);
  const dataPath = resolve(dir, 'data.ts');

  // Find all: import { foo, bar } from './data'  (non-type imports)
  const importRegex = /^import\s+\{([^}]+)\}\s+from\s+(['"])\.\/data\2/gm;
  let match;
  while ((match = importRegex.exec(content)) !== null) {
    const members = match[1].split(',').map(m => m.trim()).filter(Boolean);
    for (const member of members) {
      // skip 'api', 'http', and type-only keywords
      const name = member.replace(/^type\s+/, '').trim();
      if (name === 'api' || name === 'http') continue;
      if (!dirMissingMembers.has(dataPath)) {
        dirMissingMembers.set(dataPath, new Set());
      }
      dirMissingMembers.get(dataPath).add(name);
    }
  }
}

// 2. For each data.ts, check what's already exported
let totalAdded = 0;

for (const [dataPath, neededMembers] of dirMissingMembers) {
  let dataContent = '';
  try {
    dataContent = readFileSync(dataPath, 'utf8');
  } catch {
    console.warn(`[skip] data.ts not found: ${dataPath}`);
    continue;
  }

  const toAdd = [];
  for (const member of neededMembers) {
    // Check if already exported
    if (new RegExp(`\\bexport\\b[^;\\n]*\\b${member}\\b`).test(dataContent)) {
      continue;
    }
    toAdd.push(member);
  }

  if (toAdd.length === 0) continue;

  // Generate stubs
  const stubs = toAdd.map(name => {
    // Could be a function, type alias, or constant
    // For safety, export as any (covers all cases)
    return `export const ${name}: any = async (..._args: any[]) => {
  console.warn('[data placeholder] ${name} not implemented');
  return { code: 0, result: true, data: null, msg: 'placeholder' };
};`;
  }).join('\n');

  const appendContent = `\n// Auto-generated named exports for view-layer imports\n${stubs}\n`;
  writeFileSync(dataPath, dataContent + appendContent);
  totalAdded += toAdd.length;
  console.log(`[${dataPath.replace(process.cwd() + '/', '')}] added: ${toAdd.join(', ')}`);
}

console.log(`\nTotal named stubs added: ${totalAdded}`);
