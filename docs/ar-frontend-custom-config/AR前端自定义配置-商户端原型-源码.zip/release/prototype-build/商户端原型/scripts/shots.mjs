// 活截图脚本（方案 B）：连接运行中的 3100 原型，按清单逐页截图，覆盖交互介绍文档的 img/spec-*.png。
// 用法：
//   pnpm shots            # 全量重拍
//   pnpm shots member     # 只拍 file 名里含 "member" 的
// 前置：3100 dev server 必须在跑；文档图目录在隔壁 saas-desigh 仓库。
//
// 认证/角色：原型无后端，靠 localStorage 假 token + app:role。脚本在导航前注入：
//   ACCESS-TOKEN（storage 工具包装格式 {value,expire}，key 被 getKey() 大写）
//   app:role（角色 store 直接读 localStorage，小写 key）

import { chromium } from 'playwright';
import { fileURLToPath } from 'node:url';
import { dirname, resolve } from 'node:path';
import { existsSync } from 'node:fs';

const __dirname = dirname(fileURLToPath(import.meta.url));
const BASE = process.env.SHOTS_BASE || 'http://localhost:3100';
// 文档图目录（隔壁 saas-desigh 仓库）；可用 SHOTS_OUT 覆盖
const OUT_DIR =
  process.env.SHOTS_OUT || resolve(__dirname, '../../saas-desigh/docs/img');

// ── 截图清单：file=输出文件名，route=路由，role=角色，actions=拍前的交互（开弹窗等），clip=只截某元素 ──
const SHOTS = [
  // 会员管理
  { file: 'spec-member-list.png', route: '/member/user' },
  {
    file: 'spec3-detail-full.png',
    route: '/member/user',
    actions: [{ click: '.n-data-table-td a, .n-data-table-td .n-button' }, { wait: 900 }],
    clip: '.n-modal, .n-drawer',
    note: '需打开会员详情弹窗，选择器可能要按实际微调',
  },
  { file: 'spec-user-group.png', route: '/member/groupManage' },
  { file: 'spec-login-log.png', route: '/member/loginLog' },
  { file: 'spec-sms-code.png', route: '/member/smsCode' },
  // 运营管理
  // 站内消息 3 子 Tab：默认=弹窗消息；另拍 滚动消息 / 推送消息（点 n-tabs 对应 tab 后截）
  { file: 'spec-inbox-message.png', route: '/operations/inboxMessage', note: '弹窗消息tab(默认)' },
  {
    file: 'spec-inbox-message-scroll.png',
    route: '/operations/inboxMessage',
    actions: [{ click: '.n-tabs-tab:has-text("滚动消息")' }, { wait: 900 }],
    note: '站内消息·滚动消息tab',
  },
  {
    file: 'spec-inbox-message-push.png',
    route: '/operations/inboxMessage',
    actions: [{ click: '.n-tabs-tab:has-text("推送消息")' }, { wait: 900 }],
    note: '站内消息·推送消息tab',
  },
  { file: 'spec-banner-mgmt.png', route: '/operations/banner' },
  { file: 'spec-channel-config.png', route: '/operations/channelConfig' },
  { file: 'spec-domain-mgmt.png', route: '/operations/domainMgmt' },
  { file: 'spec-domain-rescue.png', route: '/operations/domainRescue' },
  { file: 'spec-domain-resolve-log.png', route: '/operations/domainResolveLog' },
  { file: 'spec-member-rebate-level.png', route: '/operations/memberRebateLevel' },
  { file: 'spec-agent-audit.png', route: '/operations/agentAudit' },
  { file: 'spec-vip-reward-log.png', route: '/operations/vipRewardLog' },
  { file: 'spec-vip-level-count.png', route: '/operations/vipLevelCount' },
  { file: 'spec-vip-op-log.png', route: '/operations/vipOpLog' },
  // 运营配置·消息通道 3 页（2026-06-24 多商户+验证类型）。列表态 tenant 视角；
  // admin 端多商户列需 /operations 父路由对 admin 开放后再补 admin 视角截图。
  { file: 'spec-sms-config.png', route: '/operations/smsConfig' },
  { file: 'spec-email-config.png', route: '/operations/emailConfig' },
  { file: 'spec-message-template.png', route: '/config-center/messageTemplate', role: 'tenant' },
  // 报表管理
  { file: 'spec-rebate-report.png', route: '/report/rebateReport' },
  { file: 'spec-rebate-level-yesterday.png', route: '/report/rebateLevelYesterday' },
  // 风控管理
  { file: 'spec-abnormal-member.png', route: '/risk-control/abnormalMember' },
  { file: 'spec-same-ip.png', route: '/risk-control/sameIp' },
  // 配置中心（VIP/返佣 各 2 子页签：默认=等级；另拍 经验值 / 费率，点 ConfigSubTabs 对应项后截）
  { file: 'spec-vip-level-config.png', route: '/config-center/vipConfig', note: 'VIP等级配置子页签(默认)' },
  {
    file: 'spec-vip-exp-config.png',
    route: '/config-center/vipConfig',
    actions: [{ click: '.cfg-subtabs__item:has-text("经验值")' }, { wait: 800 }],
    note: 'VIP配置·经验值配置子页签',
  },
  { file: 'spec-rebate-level.png', route: '/config-center/rebateConfig', note: '返佣等级管理子页签(默认)' },
  {
    file: 'spec-rebate-rate-config.png',
    route: '/config-center/rebateConfig',
    actions: [{ click: '.cfg-subtabs__item:has-text("费率")' }, { wait: 800 }],
    note: '返佣配置·返佣费率配置子页签',
  },
  // 系统管理
  {
    file: 'spec-ip-blacklist-batch.png',
    route: '/system/ipBlacklist',
    actions: [{ click: 'button:has-text("批量")' }, { wait: 700 }],
    note: '需打开批量导入弹窗',
  },
];

const W = Number(process.env.SHOTS_W) || 1440;
const H = Number(process.env.SHOTS_H) || 900;

function seedScript(role) {
  // 在每个页面加载最前注入：写入假登录态 + 角色 + 抑制角色浮窗提示
  return `(() => {
    try {
      const exp = Date.now() + 7 * 24 * 3600 * 1000;
      localStorage.setItem('ACCESS-TOKEN', JSON.stringify({ value: 'prototype-token', expire: exp }));
      localStorage.setItem('app:role', '${role}');
      localStorage.setItem('app:role-switcher-hint-seen', '1');
    } catch (e) { /* ignore */ }
  })()`;
}

async function run() {
  const filter = process.argv[2];
  const list = filter ? SHOTS.filter((s) => s.file.includes(filter)) : SHOTS;
  if (!existsSync(OUT_DIR)) {
    console.error(`✗ 输出目录不存在：${OUT_DIR}（用 SHOTS_OUT 指定）`);
    process.exit(1);
  }
  const browser = await chromium.launch();
  const results = [];
  for (const shot of list) {
    const role = shot.role || 'tenant';
    const ctx = await browser.newContext({ viewport: { width: W, height: H } });
    await ctx.addInitScript(seedScript(role));
    const page = await ctx.newPage();
    try {
      // 默认 dev 为 history 模式：直接深链到路由（addInitScript 已先种好登录态，不会被守卫弹回登录）
      await page.goto(`${BASE}${shot.route}`, { waitUntil: 'load', timeout: 30000 });
      await page.waitForLoadState('networkidle').catch(() => {});
      await page.waitForTimeout(shot.wait || 1400);
      for (const a of shot.actions || []) {
        if (a.click) await page.locator(a.click).first().click({ timeout: 4000 }).catch(() => {});
        if (a.wait) await page.waitForTimeout(a.wait);
      }
      const out = resolve(OUT_DIR, shot.file);
      if (shot.clip) {
        const el = page.locator(shot.clip).first();
        await el.screenshot({ path: out });
      } else {
        await page.screenshot({ path: out });
      }
      console.log(`✓ ${shot.file}  ←  ${shot.route}${shot.note ? '  (' + shot.note + ')' : ''}`);
      results.push({ file: shot.file, ok: true });
    } catch (e) {
      console.log(`✗ ${shot.file}  ←  ${shot.route}   ${String(e).split('\n')[0]}`);
      results.push({ file: shot.file, ok: false, err: String(e).split('\n')[0] });
    } finally {
      await ctx.close();
    }
  }
  await browser.close();
  const ok = results.filter((r) => r.ok).length;
  console.log(`\n完成：${ok}/${results.length} 张成功，输出目录 ${OUT_DIR}`);
}

run();
