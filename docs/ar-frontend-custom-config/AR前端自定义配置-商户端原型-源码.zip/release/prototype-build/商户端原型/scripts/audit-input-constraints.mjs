#!/usr/bin/env node
/**
 * 全站文本输入框「输入约束」覆盖审计。
 * 扫 src/views 下所有 <n-input>（排除 input-number）与 h(NInput，
 * 报告其附近 400 字内是否已有 maxlength / allow-input / allowInput / inputProps。
 * 用法：node scripts/audit-input-constraints.mjs
 */
import { readFileSync, readdirSync, statSync } from 'fs';
import { join } from 'path';

const ROOT = 'src/views';

function walk(dir) {
  const out = [];
  for (const name of readdirSync(dir)) {
    const p = join(dir, name);
    const st = statSync(p);
    if (st.isDirectory()) out.push(...walk(p));
    else if (/\.(vue|ts)$/.test(name)) out.push(p);
  }
  return out;
}

const CONSTRAINT = /maxlength|allow-input|allowInput|inputProps|onlyDigits/;
const files = walk(ROOT);
const miss = [];

for (const f of files) {
  const s = readFileSync(f, 'utf8');
  // 模板 <n-input ...>（排除 <n-input-number>）
  const tplRe = /<n-input(?!-number)(?![\w-])/g;
  let m;
  while ((m = tplRe.exec(s))) {
    const chunk = s.slice(m.index, m.index + 400);
    if (!CONSTRAINT.test(chunk)) {
      const line = s.slice(0, m.index).split('\n').length;
      miss.push(`${f}:${line}  <n-input>`);
    }
  }
  // render h(NInput ...)（排除 NInputNumber）
  const rndRe = /h\(\s*NInput(?!Number)\b/g;
  while ((m = rndRe.exec(s))) {
    const chunk = s.slice(m.index, m.index + 400);
    if (!CONSTRAINT.test(chunk)) {
      const line = s.slice(0, m.index).split('\n').length;
      miss.push(`${f}:${line}  h(NInput)`);
    }
  }
}

console.log(`扫描 ${files.length} 文件；未覆盖候选 ${miss.length} 处：`);
for (const x of miss) console.log('  ', x);
