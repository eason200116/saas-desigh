// 从交互文档某章节抽取动态控件(弹窗/按钮/搜索)→ _page-extras.json[outName]。R53锚交互文档。
// 用法: node scripts/gen-extras.mjs <groundSlug> <interSectionId> <outName>
import fs from 'node:fs';
const [slug, secId, outName] = process.argv.slice(2);
const h=fs.readFileSync("/Users/eason/v1/saas-desigh/docs/interaction-rules-2.0.html","utf8");
const s=h.indexOf(`id="${secId}"`);
if(s<0){console.log(`⚠️ 交互文档无章节 ${secId} → 该页动态控件无文档,待V1/自定义`); process.exit(0);}
const e=h.indexOf('id="p-',s+10); const sec=h.slice(s,e>0?e:s+18000);
const strip=x=>(x||'').replace(/<[^>]*>/g,'').replace(/&nbsp;/g,' ').replace(/&amp;/g,'&').replace(/&gt;/g,'>').replace(/&lt;/g,'<').replace(/\s+/g,' ').trim();
const BTN=/save|edit|del|add|confirm|publish|apply|create|reset|export|import|submit|保存|编辑|删除|新增|确认|发布|应用|新建|重置|导出|导入|提交|上架|下架|查看/i;
const ground=fs.existsSync(`/tmp/claude-501/ground/${slug}.json`)?JSON.parse(fs.readFileSync(`/tmp/claude-501/ground/${slug}.json`,'utf8')):{columns:[]};
const colKeys=new Set(ground.columns.map(c=>c.key));
const extras={};
for(const row of sec.match(/<tr>[\s\S]*?<\/tr>/g)||[]){
  if(row.includes('<th'))continue;
  const km=row.match(/<span class="k">([^<]*)<\/span>/); if(!km)continue;
  const tds=row.match(/<td[^>]*>[\s\S]*?<\/td>/g)||[];
  const name=strip((tds[0]||'').match(/<b>([\s\S]*?)<\/b>/)?.[1]||'');
  const def=strip(tds[1]), spec=strip(tds[2]), logic=strip(tds[3]);
  for(const k0 of km[1].split('/').map(x=>x.trim()).filter(Boolean)){
    const key=colKeys.has(k0)?('m_'+k0):k0;
    const type=BTN.test(k0)||BTN.test(name)?'button':'input';
    const e={field:k0,name,type,provenance:{source:`interaction-rules-2.0#${secId}`,docKey:k0}};
    if(def)e.fieldDef=def;
    if(type==='button')e.logic=logic||spec||''; else e.spec=spec||'';
    if(!extras[key])extras[key]=e;
  }
}
const p='src/components/DevLocator/spec-data/_page-extras.json';
const all=fs.existsSync(p)?JSON.parse(fs.readFileSync(p,'utf8')):{};
all[outName]={...(all[outName]||{}),...extras};
fs.writeFileSync(p,JSON.stringify(all,null,2));
console.log(`✅ extras[${outName}]: ${Object.keys(extras).length} 控件 ← ${secId}`);
