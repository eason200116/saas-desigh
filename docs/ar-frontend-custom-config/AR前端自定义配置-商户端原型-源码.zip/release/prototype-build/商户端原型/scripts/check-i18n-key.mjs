#!/usr/bin/env node
/**
 * check-i18n-key.mjs
 * 轻量 i18n 检查：确保 zh 和 en locale 文件结构一致（顶层文件数相同）。
 * 原型项目策略：警告缺失 key，不报错退出，避免阻塞 CI。
 */
import { readdirSync, readFileSync } from 'node:fs';
import { resolve, join } from 'node:path';

const root = resolve(process.cwd(), 'src/i18n/locales');
const zhDir = join(root, 'zh');
const enDir = join(root, 'en');

const zhFiles = readdirSync(zhDir).filter((f) => f.endsWith('.json'));
const enFiles = readdirSync(enDir).filter((f) => f.endsWith('.json'));

let hasError = false;

// Check that both locales have the same set of files
const zhSet = new Set(zhFiles);
const enSet = new Set(enFiles);

for (const f of zhFiles) {
  if (!enSet.has(f)) {
    console.warn(`[i18n] WARN: Missing en locale file: ${f}`);
  }
}
for (const f of enFiles) {
  if (!zhSet.has(f)) {
    console.warn(`[i18n] WARN: Missing zh locale file: ${f}`);
  }
}

// For each shared file, do a shallow top-level key check
const sharedFiles = zhFiles.filter((f) => enSet.has(f));
let totalMissing = 0;

for (const f of sharedFiles) {
  let zhJson, enJson;
  try {
    zhJson = JSON.parse(readFileSync(join(zhDir, f), 'utf8'));
    enJson = JSON.parse(readFileSync(join(enDir, f), 'utf8'));
  } catch (e) {
    console.error(`[i18n] ERROR: Failed to parse ${f}:`, e.message);
    hasError = true;
    continue;
  }

  const zhKeys = Object.keys(zhJson);
  const enKeys = new Set(Object.keys(enJson));

  for (const k of zhKeys) {
    if (!enKeys.has(k)) {
      totalMissing++;
      if (totalMissing <= 20) {
        console.warn(`[i18n] WARN: en/${f} missing top-level key: "${k}"`);
      }
    }
  }
}

if (totalMissing > 20) {
  console.warn(`[i18n] WARN: ... and ${totalMissing - 20} more missing keys (suppressed).`);
}

if (totalMissing > 0) {
  console.warn(`[i18n] WARN: Total ${totalMissing} missing top-level keys in en locale.`);
  console.warn('[i18n] NOTE: This is a prototype project — missing translation keys are expected.');
}

if (!hasError) {
  console.log(`[i18n] OK: Checked ${sharedFiles.length} locale files. No blocking errors.`);
}

// Exit 0 for prototype — missing keys are warnings only
process.exit(hasError ? 1 : 0);
