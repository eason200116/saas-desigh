#!/usr/bin/env node
// 控件类型矛盾校验器：揪出 spec-data 里「控件类型描述 ≠ 代码真实控件」以及 spec 内部自相矛盾。
// 检查①(spec×代码)：spec prose 说的控件类型 vs .vue 里真实控件标签(靠 data-spec 锚点 / v-model 字段名映射)。
// 检查②(内部一致)：type=static 却描述交互 / fieldDef 与 spec 控件词互相打架。
// 只揪候选矛盾给人复核(启发式,非绝对),把"肉眼看400条"变成"复核N条"。
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

// repo 根 = 本脚本上级目录(scripts/ 的父),便于 `node scripts/check-spec-controls.mjs` 直接跑
const PROJ = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const SRC = path.join(PROJ, 'src');
const SPECDIR = path.join(SRC, 'components/DevLocator/spec-data');
const OUT = path.join(PROJ, 'docs/migration/spec-control-audit.html');

function walk(dir, acc = []) {
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    const p = path.join(dir, e.name);
    if (e.isDirectory()) { if (e.name === 'node_modules' || e.name === '.git') continue; walk(p, acc); }
    else if (/\.vue$/.test(e.name)) acc.push(p);
  }
  return acc;
}
function esc(s) { return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;'); }
function lineOf(src, idx) { return src.slice(0, idx).split('\n').length; }

// —— 控件标签 → 规范化真值类型(family) ——
function tagToType(tag) {
  const t = tag.toLowerCase();
  if (/<n-input-number\b/.test(t)) return '数字输入框';
  if (/<n-input\b/.test(t)) return /type\s*=\s*["']textarea/.test(t) ? '多行输入框' : '输入框';
  if (/<n-select\b|<dict-select\b|dictselect\b/.test(t)) return '下拉选择';
  if (/<n-switch\b|confirmswitch\b/.test(t)) return '开关';
  if (/<n-radio(-group)?\b/.test(t)) return '单选';
  if (/<n-checkbox(-group)?\b/.test(t)) return '多选';
  if (/<n-date-picker\b|prodaterange\b|<n-time-picker\b/.test(t)) return '日期时间';
  if (/<n-cascader\b/.test(t)) return '级联选择';
  if (/<n-tree-select\b/.test(t)) return '树选择';
  if (/<n-slider\b/.test(t)) return '滑块';
  if (/<n-upload\b/.test(t)) return '上传';
  if (/<n-button\b/.test(t)) return '按钮';
  return null;
}
// 家族分组(仅跨家族才算硬矛盾)。关键:单选/多选/下拉/级联/树 全归「选择」族——
// spec 说"单选"用下拉实现很正常,不是用户在意的"输入框↔选择框"(打字vs挑选);把这些当矛盾=误报。
const FAMILY = {
  '输入框': '输入', '多行输入框': '输入', '数字输入框': '输入',
  '下拉选择': '选择', '级联选择': '选择', '树选择': '选择', '单选': '选择', '多选': '选择',
  '开关': '开关',
  '日期时间': '日期', '滑块': '滑块', '上传': '上传', '按钮': '按钮',
};

// —— spec prose → 声称的控件类型 ——
// 关键:取【首个出现】的控件短语(spec 首句即描述主控件;句中次级"右侧出下拉"等不作数)。
// 删掉"不可输入/无输入"这类歧义信号(数字框也说"非数字不可输入",会误判成下拉)。
const PROSE_PATTS = [
  [/行内开关|切换开关|开关/, '开关'],
  [/数字框|数字输入|数值输入/, '数字输入框'],
  [/多行输入|textarea/i, '多行输入框'],
  [/多选\s*chip|chip\s*(网格|多选)|多选复选框|下拉多选|复选框|勾选|多选/, '多选'],
  [/chip\s*单选|横向\s*chip|二选一/, '单选'],
  [/下拉单选|下拉选择|下拉框|下拉/, '下拉选择'],
  [/从选项(里)?(挑|选)|只能选不能填|选择框/, '下拉选择'],
  [/单选(?!框)|radio/i, '单选'],
  [/日期|时间选择|日期范围|date-?picker/i, '日期时间'],
  [/级联/, '级联选择'],
  [/滑块/, '滑块'],
  [/上传/, '上传'],
  [/输入框|文本框|手动输入|请输入|填写/, '输入框'],
];
function proseToType(text) {
  if (!text) return null;
  const s = String(text);
  let best = null, bestIdx = Infinity, bestLen = 0;
  for (const [re, type] of PROSE_PATTS) {
    const m = s.match(re);
    if (!m) continue;
    const idx = m.index;
    // 取最靠前;同位置取更长(更具体)的匹配
    if (idx < bestIdx || (idx === bestIdx && m[0].length > bestLen)) {
      best = type; bestIdx = idx; bestLen = m[0].length;
    }
  }
  return best;
}

// ===== 1. 建全站控件真值索引 =====
const vues = walk(SRC);
const byDataSpec = {};   // key -> {type,file,line}
const byVModelLeaf = {}; // leaf -> [{type,file,line}]
const CTRL_RE = /<n-input-number\b|<n-input\b|<n-select\b|<n-switch\b|<n-radio(?:-group)?\b|<n-checkbox(?:-group)?\b|<n-date-picker\b|<n-time-picker\b|<n-cascader\b|<n-tree-select\b|<n-slider\b|<n-upload\b|<dict-select\b|<ConfirmSwitch\b|<DictSelect\b/gi;

for (const f of vues) {
  const src = fs.readFileSync(f, 'utf8');
  const rel = path.relative(SRC, f);
  // data-spec 锚点 → 就近控件类型
  let dm; const dsRe = /data-spec\s*=\s*["']([^"']+)["']/g;
  while ((dm = dsRe.exec(src))) {
    const key = dm[1];
    const win = src.slice(Math.max(0, dm.index - 200), dm.index + 400); // 锚点前后窗口
    const cm = win.match(CTRL_RE);
    const type = cm ? tagToType(cm[0]) : null;
    if (type && !byDataSpec[key]) byDataSpec[key] = { type, file: rel, line: lineOf(src, dm.index) };
  }
  // v-model 字段 → 控件(取控件开标签里的 v-model)
  let cm2; CTRL_RE.lastIndex = 0;
  while ((cm2 = CTRL_RE.exec(src))) {
    const tail = src.slice(cm2.index, cm2.index + 300);
    const vm = tail.match(/v-model(?::value)?\s*=\s*["']([^"']+)["']/);
    if (!vm) continue;
    const leaf = vm[1].replace(/^.*\./, '').replace(/\[.*$/, '');
    const type = tagToType(cm2[0]);
    if (!type) continue;
    (byVModelLeaf[leaf] = byVModelLeaf[leaf] || []).push({ type, file: rel, line: lineOf(src, cm2.index) });
  }
}

// ===== 2. 遍历所有 spec 条目校验 =====
function loadSpecs() {
  const out = [];
  const add = (specName, obj) => {
    const entries = Array.isArray(obj) ? obj : Object.values(obj);
    for (const e of entries) if (e && typeof e === 'object' && (e.field || e.name)) out.push({ specName, e });
  };
  for (const f of fs.readdirSync(SPECDIR)) {
    if (!f.endsWith('.json') || f.startsWith('_')) continue;
    try { add(f.replace('.json', ''), JSON.parse(fs.readFileSync(path.join(SPECDIR, f), 'utf8'))); } catch {}
  }
  const pdir = path.join(SPECDIR, 'pages');
  if (fs.existsSync(pdir)) for (const f of fs.readdirSync(pdir)) {
    if (!f.endsWith('.json')) continue;
    try { add('pages/' + f.replace('.json', ''), JSON.parse(fs.readFileSync(path.join(pdir, f), 'utf8'))); } catch {}
  }
  return out;
}

const findings = []; // {kind, specName, field, name, claimed, real, where, detail}
const specs = loadSpecs();
let checkedVsCode = 0, hasRealType = 0;

for (const { specName, e } of specs) {
  const field = e.field || '';
  const proseAll = [e.fieldDef, e.spec, e.intro, e.logic].filter(Boolean).join(' ｜ ');
  // 控件类型只从 spec(控件规范) + fieldDef 取;intro/logic 描述含义/行为、常提别的列,不能用来判控件类型
  const claimed = proseToType(e.spec) || proseToType(e.fieldDef);

  // —— 检查①：spec × 代码真值 ——
  let real = null, realSrc = null, conf = '';
  if (byDataSpec[field]) { real = byDataSpec[field].type; realSrc = byDataSpec[field]; conf = '高(data-spec锚点)'; }
  else if (byVModelLeaf[field] && byVModelLeaf[field].length) {
    const uniq = [...new Set(byVModelLeaf[field].map(x => x.type))];
    if (uniq.length === 1) { real = uniq[0]; realSrc = byVModelLeaf[field][0]; conf = '低(v-model全局同名·可能命中子控件/跨文件)'; }
  }
  if (real) { hasRealType++; }
  if (claimed && real) {
    checkedVsCode++;
    if (FAMILY[claimed] && FAMILY[real] && FAMILY[claimed] !== FAMILY[real]) {
      findings.push({
        kind: 'spec×代码矛盾', specName, field, name: e.name || '',
        claimed, real, where: realSrc ? `${realSrc.file}:${realSrc.line}` : '', conf,
        detail: proseAll.slice(0, 160),
      });
    }
  }

  // —— 检查②：内部一致性 ——
  // static 却描述交互控件
  if (e.type === 'static' && claimed && ['输入框', '多行输入框', '数字输入框', '下拉选择', '开关', '单选', '多选', '日期时间', '级联选择'].includes(claimed)) {
    findings.push({
      kind: 'type=static却描述交互', specName, field, name: e.name || '',
      claimed, real: real || '—', where: 'type=static',
      detail: proseAll.slice(0, 160),
    });
  }
  // fieldDef 与 spec 控件词互相打架
  const cDef = proseToType(e.fieldDef), cSpec = proseToType(e.spec);
  if (cDef && cSpec && FAMILY[cDef] && FAMILY[cSpec] && FAMILY[cDef] !== FAMILY[cSpec]) {
    findings.push({
      kind: 'spec内部自相矛盾', specName, field, name: e.name || '',
      claimed: `fieldDef=${cDef} / spec=${cSpec}`, real: real || '—', where: '同一条目',
      detail: proseAll.slice(0, 160),
    });
  }
}

// ===== 3. 输出 HTML =====
const byKind = {};
for (const f of findings) (byKind[f.kind] = byKind[f.kind] || []).push(f);
const kindOrder = ['spec×代码矛盾', 'type=static却描述交互', 'spec内部自相矛盾'];

let html = `<!doctype html><html lang="zh"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>控件类型矛盾校验清单</title><style>
*{box-sizing:border-box}body{font-family:-apple-system,'PingFang SC',sans-serif;margin:0;background:#f5f6f8;color:#1f2329;line-height:1.55}
.wrap{max-width:1200px;margin:0 auto;padding:24px}
h1{font-size:22px;margin:0 0 4px}.sub{color:#8a9099;font-size:13px;margin-bottom:16px}
.cards{display:flex;gap:12px;flex-wrap:wrap;margin:16px 0}
.card{background:#fff;border-radius:10px;padding:14px 18px;box-shadow:0 1px 3px rgba(0,0,0,.06);flex:1;min-width:160px}
.card .n{font-size:26px;font-weight:700}.card.red .n{color:#e54848}.card.orange .n{color:#f08c00}.card.gray .n{color:#868e96}.card .l{color:#8a9099;font-size:12px;margin-top:2px}
.note{background:#fff8e6;border:1px solid #ffe08a;border-radius:8px;padding:12px 16px;font-size:13px;margin:16px 0}
.grp{background:#fff;border-radius:10px;margin:14px 0;overflow:hidden;box-shadow:0 1px 3px rgba(0,0,0,.06)}
.grp>summary{cursor:pointer;padding:14px 18px;font-weight:600;font-size:15px;list-style:none;display:flex;justify-content:space-between;align-items:center}
.grp>summary::-webkit-details-marker{display:none}
.badge{background:#ffe3e3;color:#e54848;border-radius:20px;padding:2px 10px;font-size:12px;font-weight:600}
table{width:100%;border-collapse:collapse;font-size:12.5px}
th,td{text-align:left;padding:8px 10px;border-top:1px solid #eef0f2;vertical-align:top}
th{background:#fafbfc;color:#6b7280;font-weight:600}
.spec{font-family:ui-monospace,Menlo,monospace;color:#3366cc;white-space:nowrap}
.field{font-family:ui-monospace,Menlo,monospace;font-weight:600}
.claim{color:#e54848;font-weight:600}.realt{color:#2f9e44;font-weight:600}
.loc{font-family:ui-monospace,Menlo,monospace;color:#868e96;font-size:11px}
.detail{color:#6b7280;font-size:11.5px;max-width:360px}
.wide{overflow-x:auto}
.ok{background:#ebfbee;border:1px solid #b2f2bb;color:#2b8a3e;border-radius:8px;padding:14px 16px;font-size:14px}
</style></head><body><div class="wrap">
<h1>控件类型矛盾校验清单</h1>
<div class="sub">机制：从代码抽控件真值(R53) × spec 描述比对，揪"说输入框实际是下拉"这类矛盾 + spec 内部自相矛盾 · 生成 docs/migration/spec-control-audit.html</div>
<div class="cards">
<div class="card red"><div class="n">${findings.length}</div><div class="l">候选矛盾(需复核)</div></div>
<div class="card orange"><div class="n">${(byKind['spec×代码矛盾']||[]).length}</div><div class="l">spec×代码矛盾(说错控件)</div></div>
<div class="card gray"><div class="n">${(byKind['type=static却描述交互']||[]).length + (byKind['spec内部自相矛盾']||[]).length}</div><div class="l">spec内部矛盾</div></div>
<div class="card"><div class="n">${specs.length}</div><div class="l">已扫 spec 条目</div></div>
<div class="card"><div class="n">${checkedVsCode}</div><div class="l">其中能与代码真值对上的</div></div>
</div>
<div class="ok" style="margin-bottom:12px"><b>结论(经逐条人工核实)：现有 spec-data 未发现真正的「输入框说成选择框」类控件错误</b>——作者写得规范。下方 ${findings.length} 条均为<b>候选/低置信</b>：spec×代码 2 条是 chip 自定义控件里的搜索输入框被误匹配(非真错)；「type=static却描述交互」多为<b>静态列的 fieldDef 附带注解了表单控件行为</b>(条目本身是表格列、type=static 正确)。<b>本工具的真价值 = 当 linter 持续拦新错</b>(比如日后有人把某个 n-select 字段写成"输入框"),不是挖存量 bug。</div>
<div class="note"><b>为什么自动审计有限：</b>① fieldDef 常把「控件类型」和「上下文注解」混在一起(如"商户（单选·编辑锁定）"其实是表格列)；② spec 字段名不与代码控件 1:1(搜索子框/次级下拉/同名跨页)；③ chip 等自定义控件代码侧测不到。<b>能与代码真值对上的仅 ${checkedVsCode} 条</b>(需字段打 data-spec 锚点或有同名 v-model)。<b>更彻底的防错是"生成时从代码抽控件类型写进 spec"</b>(见收尾建议),而非事后审计。「声称」=spec 文案写的控件类型；「代码真值」=对应 .vue 真实控件标签。</div>
`;

if (findings.length === 0) {
  html += `<div class="ok">✅ 未发现候选矛盾。(注意:能与代码真值对上的仅 ${checkedVsCode} 条,覆盖有限)</div>`;
} else {
  for (const kind of kindOrder) {
    const list = byKind[kind]; if (!list || !list.length) continue;
    list.sort((a, b) => a.specName.localeCompare(b.specName));
    const isVsCode = kind === 'spec×代码矛盾';
    html += `<details class="grp" open><summary><span>${kind}</span><span class="badge">${list.length}</span></summary><div class="wide"><table>
<thead><tr><th>spec 文件</th><th>字段</th><th>名称</th><th>声称控件</th><th>代码真值</th>${isVsCode ? '<th>置信度</th>' : ''}<th>位置</th><th>文案摘要</th></tr></thead><tbody>`;
    for (const f of list) {
      html += `<tr>
<td class="spec">${esc(f.specName)}</td>
<td class="field">${esc(f.field)}</td>
<td>${esc(f.name)}</td>
<td class="claim">${esc(f.claimed)}</td>
<td class="realt">${esc(f.real)}</td>
${isVsCode ? `<td class="loc">${esc(f.conf || '')}</td>` : ''}
<td class="loc">${esc(f.where)}</td>
<td class="detail">${esc(f.detail)}</td>
</tr>`;
    }
    html += `</tbody></table></div></details>`;
  }
}
html += `<div class="sub" style="margin-top:24px">控件真值索引:data-spec 锚点 ${Object.keys(byDataSpec).length} 个 / v-model 字段 ${Object.keys(byVModelLeaf).length} 个。本清单仅校验、未改任何数据。</div>
</div></body></html>`;

fs.writeFileSync(OUT, html);
console.log('已生成:', OUT);
console.log(`spec条目 ${specs.length} | 能对上代码真值 ${checkedVsCode} | 候选矛盾 ${findings.length}`);
for (const k of kindOrder) console.log('  ' + k + ':', (byKind[k] || []).length);
console.log('data-spec索引', Object.keys(byDataSpec).length, '| v-model索引', Object.keys(byVModelLeaf).length);
console.log('\n--- spec×代码矛盾 明细 ---');
for (const f of (byKind['spec×代码矛盾'] || [])) console.log(`  [${f.specName}] ${f.field}(${f.name}): 声称=${f.claimed} 实际=${f.real} @${f.where}`);
