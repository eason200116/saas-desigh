/**
 * gen-devlocator-spec.mjs — 生成 DevLocator 悬停规范数据（多页）。
 * 数据源：
 *   ① 交互规范文档 saas-desigh/docs/interaction-rules-2.0.html（各页 <section id> 的 <table class="ct">）
 *      → 字段定义(名称定义) / 交互规范(控件规范) / 控件逻辑 / 边界情况 / Toast
 *   ② 字段词典 docs/migration/14-anchor-new-field-glossary.html（可选，按 route 匹配，覆盖字段定义）
 * 产物：src/components/DevLocator/spec-data/<out>（本仓库自足，dev-only）
 * 用法：node scripts/gen-devlocator-spec.mjs
 * 缺失字段一律留空串，不臆造（红线6 / R45）。
 */
import fs from 'node:fs';
import path from 'node:path';

const REPO = process.cwd();
const INTER = '/Users/eason/v1/saas-desigh/docs/interaction-rules-2.0.html';
const GLOSS = path.join(REPO, 'docs/migration/14-anchor-new-field-glossary.html');
const OUTDIR = path.join(REPO, 'src/components/DevLocator/spec-data');

// 各页配置：docAnchor=章节 id 前缀，docEnd=下一章节 id（截断），glossRoute=词典 route（可空）
const PAGES = [
  {
    // 交互模式：交互文档控件表 → 交互规范/逻辑/边界
    out: 'vipConfig.json',
    mode: 'interaction',
    docAnchor: 'id="p-config-vipConfig"',
    docEnd: 'id="p-config-rebateConfig"',
    glossRoute: "route:'/config-center/vipConfig'",
  },
  {
    // 合并模式：字段词典(静态展示列:字段定义+介绍) + 交互文档(交互控件:控件规范/逻辑/边界)
    out: 'memberUser.json',
    mode: 'merge',
    glossRoute: "route:'/member/user'",
    docAnchor: 'id="p-member-user"',
    docEnd: 'id="p-member-groupManage"',
    // 竖版分组列有、但不在 /member/user 词典段的字段 → 从词典全库按 key 补齐；无定义者据实仅留字段名(R45)
    extraKeys: [
      // mobile：词典原文是短信页语境(脱敏)，与会员列表不符——列表全额展示且兼登录账号。据实改写(用户授权自定义)
      {
        key: 'mobile',
        name: '手机',
        fieldDef: '会员手机号：既是登录账号之一，也用于接收短信验证码。列表/详情按全额展示（非脱敏）。',
        intro: '会员的手机号，能当账号登录、也用来收短信验证码，这里完整显示不打码。',
      },
      { key: 'email', name: '邮箱', fieldDef: '会员绑定邮箱：可作登录账号之一，也用于接收邮件验证码/找回。', intro: '会员的邮箱，能当账号登录、收邮件验证码。' },
    ],
  },
];

// 词典全库：key → { name, fieldDef, intro }（供 extraKeys 跨段补齐；单字段不按 · 拆）
function buildGlobalGlossaryIndex(g) {
  const idx = {};
  const rows = g.match(/\[\s*'(?:[^'\\]|\\.)*'(?:\s*,\s*'(?:[^'\\]|\\.)*')*\s*\]/g) || [];
  for (const r of rows) {
    const v = (r.match(/'((?:[^'\\]|\\.)*)'/g) || []).map((s) => s.slice(1, -1));
    if (v.length < 5) continue;
    const keys = (v[1] || '').split('/').map((s) => s.trim()).filter(Boolean);
    for (const k of keys) {
      if (!idx[k]) idx[k] = { name: v[3] || v[2] || '', fieldDef: v[4] || '', intro: v[5] || '' };
    }
  }
  return idx;
}

// 词典字段模式：解析词典某 route 段的字段行 → { key: {field, fieldDef(定义), intro(大白话)} }
function parseGlossaryFields(g, glossRoute) {
  const out = {};
  if (!glossRoute) return out;
  const start = g.indexOf(glossRoute);
  if (start < 0) return out;
  const nextRoute = g.indexOf("route:'", start + 10);
  const sec = g.slice(start, nextRoute > 0 ? nextRoute : start + 20000);
  const rows = sec.match(/\[\s*'(?:[^'\\]|\\.)*'(?:\s*,\s*'(?:[^'\\]|\\.)*')*\s*\]/g) || [];
  for (const row of rows) {
    const vals = (row.match(/'((?:[^'\\]|\\.)*)'/g) || []).map((s) => s.slice(1, -1));
    if (vals.length < 5) continue;
    // 列序：[0]status [1]key [2]变更前 [3]现中文 [4]定义 [5]大白话介绍 [6]flag(可空)
    const keys = (vals[1] || '').split('/').map((s) => s.trim()).filter(Boolean);
    const defs = (vals[4] || '').split('·').map((s) => s.trim());
    const intros = (vals[5] || '').split('·').map((s) => s.trim());
    const name = vals[3] || vals[2] || ''; // 现中文=控件名称
    keys.forEach((k, i) => {
      out[k] = {
        field: k,
        name,
        type: 'static', // 列表静态列
        fieldDef: defs[i] || defs[0] || '',
        intro: intros[i] || intros[0] || '',
      };
    });
  }
  return out;
}

function stripTags(s) {
  return (s || '')
    .replace(/<[^>]*>/g, '')
    .replace(/&nbsp;/g, ' ')
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&middot;/g, '·')
    .replace(/&hellip;/g, '…')
    .replace(/&rarr;/g, '→')
    .replace(/\s+/g, ' ')
    .trim();
}

// 确认类按钮(C)：保存/编辑/确认/发布/删除等最终确认动作
const BTN_RE =
  /save|edit|confirm|publish|delete|apply|create|onOk|startEdit|openSave|保存|编辑|确认|发布|删除|应用|新增模板|新建/i;
function classify(key, name) {
  return BTN_RE.test(key) || BTN_RE.test(name) ? 'button' : 'input';
}

function parseInteraction(html, docAnchor, docEnd) {
  const base = {};
  const start = html.indexOf(docAnchor);
  if (start < 0) return base;
  const end = html.indexOf(docEnd, start);
  const sec = html.slice(start, end > 0 ? end : undefined);
  const rows = sec.match(/<tr>[\s\S]*?<\/tr>/g) || [];
  for (const row of rows) {
    if (row.includes('<th')) continue;
    const keyM = row.match(/<span class="k">([^<]*)<\/span>/);
    if (!keyM) continue;
    const tds = row.match(/<td[^>]*>[\s\S]*?<\/td>/g) || [];
    // 控件名称：nm 单元格里的 <b>...</b>
    const nameM = (tds[0] || '').match(/<b>([\s\S]*?)<\/b>/);
    const name = nameM ? stripTags(nameM[1]) : '';
    const fieldDef = stripTags(tds[1]);
    const spec = stripTags(tds[2]);
    const logic = stripTags(tds[3]);
    const toast = stripTags(tds[4]);
    const boundary = stripTags(tds[5]);
    const keys = keyM[1].split('/').map((s) => s.trim()).filter(Boolean);
    for (const k of keys) {
      base[k] = { field: k, name, type: classify(k, name), fieldDef, spec, logic, boundary, toast };
    }
  }
  return base;
}

function parseGlossary(g, glossRoute) {
  const defs = {};
  if (!glossRoute) return defs;
  const start = g.indexOf(glossRoute);
  if (start < 0) return defs;
  const nextRoute = g.indexOf("route:'", start + 10);
  const sec = g.slice(start, nextRoute > 0 ? nextRoute : start + 8000);
  const re = /\['([^']*)','([^']*)','([^']*)'/g;
  let m;
  while ((m = re.exec(sec))) {
    const keys = m[2].split('/').map((s) => s.trim()).filter(Boolean);
    const names = m[3].split('·').map((s) => s.trim());
    keys.forEach((k, i) => (defs[k] = names[i] || names[0] || ''));
  }
  return defs;
}

const interHtml = fs.existsSync(INTER) ? fs.readFileSync(INTER, 'utf8') : '';
const glossHtml = fs.existsSync(GLOSS) ? fs.readFileSync(GLOSS, 'utf8') : '';
if (!interHtml) console.warn('⚠️ 交互文档不存在：', INTER);

fs.mkdirSync(OUTDIR, { recursive: true });

for (const page of PAGES) {
  let out = {};
  if (page.mode === 'glossaryFields' || page.mode === 'merge') {
    // 字段词典：静态展示列（字段定义+介绍，type=static）
    out = parseGlossaryFields(glossHtml, page.glossRoute);
    let interactive = 0;
    if (page.mode === 'merge') {
      // 交互文档：交互控件（控件名称/规范/逻辑/边界，type=input/button）——同 key 以交互文档为准
      const inter = parseInteraction(interHtml, page.docAnchor, page.docEnd);
      for (const k in inter) {
        out[k] = { ...(out[k] || {}), ...inter[k] }; // 交互控件覆盖：带 name/type/spec/logic
        interactive++;
      }
      // extraKeys：竖版有、词典本段无的字段 → 词典全库按 key 补齐（静态展示列）
      if (page.extraKeys && page.extraKeys.length) {
        const gidx = buildGlobalGlossaryIndex(glossHtml);
        for (const ek of page.extraKeys) {
          const spec = typeof ek === 'string' ? { key: ek } : ek;
          if (out[spec.key]) continue;
          const g = gidx[spec.key] || {};
          out[spec.key] = {
            field: spec.key,
            name: spec.name ?? g.name ?? spec.key,
            type: 'static',
            fieldDef: spec.fieldDef ?? g.fieldDef ?? '',
            intro: spec.intro ?? g.intro ?? '',
          };
        }
      }
    }
    fs.writeFileSync(path.join(OUTDIR, page.out), JSON.stringify(out, null, 2), 'utf8');
    const withIntro = Object.values(out).filter((e) => e.intro).length;
    const withSpec = Object.values(out).filter((e) => e.spec).length;
    console.log(`✅ ${page.out}(${page.mode}): 控件 ${Object.keys(out).length}；静态定义 ${Object.values(out).filter((e) => e.fieldDef).length}；介绍 ${withIntro}；交互控件 ${interactive}(其中有规范 ${withSpec})`);
    continue;
  }
  const base = parseInteraction(interHtml, page.docAnchor, page.docEnd);
  const glossDef = parseGlossary(glossHtml, page.glossRoute);
  const allKeys = new Set([...Object.keys(base), ...Object.keys(glossDef)]);
  for (const k of allKeys) {
    const b = base[k] || {};
    out[k] = {
      field: k,
      name: b.name || '',
      type: b.type || 'input',
      fieldDef: glossDef[k] || b.fieldDef || '',
      spec: b.spec || '',
      logic: b.logic || '',
      boundary: b.boundary || '',
      toast: b.toast || '',
    };
  }
  fs.writeFileSync(path.join(OUTDIR, page.out), JSON.stringify(out, null, 2), 'utf8');
  console.log(`✅ ${page.out}(交互文档): 控件 ${allKeys.size}；有交互规范 ${Object.values(out).filter((e) => e.spec).length}；有字段定义 ${Object.values(out).filter((e) => e.fieldDef).length}`);
}
