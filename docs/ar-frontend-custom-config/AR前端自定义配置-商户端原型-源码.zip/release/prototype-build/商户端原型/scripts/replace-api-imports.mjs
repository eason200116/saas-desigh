#!/usr/bin/env node
// 一次性脚本：把 src/views/**/*.{vue,ts} 里 @/api 引用全部替换为同目录的 ./data。
// 同时为每个引用了 ./data 的视图目录创建占位 data.ts（空 api 对象）。

import { readFileSync, writeFileSync, existsSync, mkdirSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import { glob } from 'glob';

const files = await glob('src/views/**/*.{vue,ts}', { absolute: true });

let modified = 0;
const touchedDirs = new Set();
for (const f of files) {
  let content = readFileSync(f, 'utf8');
  const before = content;

  // 形态 1: from '@/api'  → from './data'
  content = content.replace(/from\s+(['"])@\/api\1/g, `from './data'`);
  // 形态 2: from '@/api/xxx[/yyy...]'  → from './data'
  content = content.replace(/from\s+(['"])@\/api\/[^'"]+\1/g, `from './data'`);
  // 形态 3: from '@/utils/http' → 删除整行（视图层不应再 import http）
  content = content.replace(/^\s*import\s+[^;]*?from\s+(['"])@\/utils\/http\1;?\s*$\n?/gm, '');

  if (content !== before) {
    writeFileSync(f, content);
    modified++;
    touchedDirs.add(dirname(f));
    console.log(`[modified] ${f.replace(process.cwd() + '/', '')}`);
  }
}

// 为每个被 touched 的目录创建占位 data.ts（如果不存在）
const placeholder = `// 占位 data.ts —— Unit 8/9 将填充本页所需的列表数据与 api 命名空间
// 视图层调用形态保持源项目一致：const { data, result } = await api.<module>.<method>(req);
// 这里先导出空 api 与可调用的 dynamic proxy，避免 typecheck/运行时报缺失。
export const api: any = new Proxy(
  {},
  {
    get(_t, mod: string) {
      return new Proxy(
        {},
        {
          get(_, method: string) {
            return async (..._args: any[]) => {
              console.warn('[data placeholder] api.' + mod + '.' + method + ' not implemented');
              return { code: 0, result: true, data: null, msg: 'placeholder' };
            };
          },
        },
      );
    },
  },
);
`;

let createdPlaceholders = 0;
for (const dir of touchedDirs) {
  const dataPath = resolve(dir, 'data.ts');
  if (!existsSync(dataPath)) {
    writeFileSync(dataPath, placeholder);
    createdPlaceholders++;
    console.log(`[placeholder] ${dataPath.replace(process.cwd() + '/', '')}`);
  }
}

console.log(`\nTotal files modified: ${modified}`);
console.log(`Total data.ts placeholders created: ${createdPlaceholders}`);
console.log('Unit 8/9 将把对应模块的占位 data.ts 替换为真实数据 + api 命名空间。');
