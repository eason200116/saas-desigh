/**
 * gen-memberdetail-spec.mjs — 生成「会员详情·基本信息」悬停规范数据 memberDetail.json。
 * 数据源（严格按需求：交互规则 + 字段词典）：
 *   ① 字段词典 docs/migration/14-anchor-new-field-glossary.html（全库按“中文名”匹配 → 字段定义 + 大白话介绍）
 *   ② 交互规则 saas-desigh/docs/interaction-rules-2.0.html（member 段控件，按中文名兜底交互控件规范）
 * 字段清单来源：buildDetailData.ts 的 label t(key) + zh/member.json 中文名（保序去重）。
 * 分类：详情页以静态展示为主（type=static）；带 stateSwitch/actionKey/headerSwitches 的为交互控件（input）。
 * 缺失一律留空串，不臆造（红线6 / R45）。两文档均写明“会员详情弹窗不展开/无结构化字段”，故仅能按中文名跨库对齐。
 * 用法：node scripts/gen-memberdetail-spec.mjs
 */
import fs from 'node:fs';
import path from 'node:path';

const REPO = process.cwd();
const GLOSS = path.join(REPO, 'docs/migration/14-anchor-new-field-glossary.html');
const INTER = '/Users/eason/v1/saas-desigh/docs/interaction-rules-2.0.html';
const BUILD = path.join(REPO, 'src/components/MemberDetail/basic/buildDetailData.ts');
const ZH = path.join(REPO, 'src/i18n/locales/zh/member.json');
const OUT = path.join(REPO, 'src/components/DevLocator/spec-data/memberDetail.json');

const zh = JSON.parse(fs.readFileSync(ZH, 'utf8'));
function tv(key) {
  let o = zh;
  for (const p of key.split('.')) o = o && o[p];
  return typeof o === 'string' ? o : null;
}

// —— 1) 详情基本信息字段清单（label key，保序去重）+ 交互标记 ——
const src = fs.readFileSync(BUILD, 'utf8');
const labelKeys = [...src.matchAll(/label:\s*t\('([^']+)'\)/g)].map((m) => m[1]);
const seen = new Set();
const orderedKeys = [];
for (const k of labelKeys) {
  if (seen.has(k)) continue;
  seen.add(k);
  orderedKeys.push(k);
}
// 交互控件：带开关/行内按钮的 label key（就近块判定）
const INTERACTIVE = new Set();
for (const m of src.matchAll(/label:\s*t\('([^']+)'\)[\s\S]{0,320}?(stateSwitch:\s*true|actionKey:\s*')/g)) {
  INTERACTIVE.add(m[1]);
}
// 分区头开关（领取返佣 / 对上级返佣）
for (const m of src.matchAll(/headerSwitches:\s*\[([\s\S]*?)\]/g)) {
  for (const lm of m[1].matchAll(/label:\s*t\('([^']+)'\)/g)) INTERACTIVE.add(lm[1]);
}

// —— 2) 字段词典全库：中文名 → { key, def, intro } ——
const g = fs.readFileSync(GLOSS, 'utf8');
const rows = g.match(/\[\s*'(?:[^'\\]|\\.)*'(?:\s*,\s*'(?:[^'\\]|\\.)*')*\s*\]/g) || [];
const gloByName = {};
for (const r of rows) {
  const v = (r.match(/'((?:[^'\\]|\\.)*)'/g) || []).map((s) => s.slice(1, -1));
  if (v.length < 5) continue;
  const key = (v[1] || '').split('/')[0].trim();
  const def = (v[4] || '').split('·')[0].trim();
  const intro = (v[5] || '').split('·')[0].trim();
  for (const nm of [v[3], v[2]]) {
    if (nm && !gloByName[nm]) gloByName[nm] = { key, def, intro };
  }
}

// —— 3) 交互规则 member 段：中文名 → 控件规范/逻辑（供交互控件兜底）——
function stripTags(s) {
  return (s || '').replace(/<[^>]*>/g, '').replace(/&nbsp;/g, ' ').replace(/&amp;/g, '&').replace(/\s+/g, ' ').trim();
}
const interHtml = fs.existsSync(INTER) ? fs.readFileSync(INTER, 'utf8') : '';
const interByName = {};
{
  const s = interHtml.indexOf('id="p-member-user"');
  const e = interHtml.indexOf('id="p-member-groupManage"', s);
  const sec = s >= 0 ? interHtml.slice(s, e > 0 ? e : undefined) : '';
  for (const row of sec.match(/<tr>[\s\S]*?<\/tr>/g) || []) {
    if (row.includes('<th')) continue;
    const tds = row.match(/<td[^>]*>[\s\S]*?<\/td>/g) || [];
    const nm = ((tds[0] || '').match(/<b>([\s\S]*?)<\/b>/) || [])[1];
    const name = stripTags(nm);
    if (!name) continue;
    interByName[name] = { spec: stripTags(tds[2]), logic: stripTags(tds[3]) };
  }
}

// —— 4) 组装 memberDetail.json（键=中文名，DevLocator 按 label 匹配）——
const out = {};
let hit = 0;
let missList = [];
for (const lk of orderedKeys) {
  const name = tv(lk);
  if (!name) continue;
  const field = lk.split('.').pop(); // i18n 末段作字段标识（稳定、有意义）
  const glo = gloByName[name] || null;
  const isInter = INTERACTIVE.has(lk);
  const entry = {
    field,
    name,
    type: isInter ? 'input' : 'static',
    fieldDef: glo?.def || '',
    intro: glo?.intro || '',
    spec: '',
    logic: '',
    boundary: '',
  };
  if (isInter && interByName[name]) {
    entry.spec = interByName[name].spec || '';
    entry.logic = interByName[name].logic || '';
  }
  if (glo) hit++;
  else missList.push(name);
  // 同名以首个为准（详情内少数重名如「注册时间」出现在多区）
  if (!out[name]) out[name] = entry;
}

fs.writeFileSync(OUT, JSON.stringify(out, null, 2), 'utf8');
const total = Object.keys(out).length;
const withDef = Object.values(out).filter((e) => e.fieldDef).length;
const inter = Object.values(out).filter((e) => e.type !== 'static').length;
console.log(`✅ memberDetail.json: 字段 ${total}；有定义 ${withDef}；交互控件 ${inter}；静态 ${total - inter}`);
console.log(`   命中词典中文名 ${hit}/${orderedKeys.length}；无定义 ${missList.length}: ${missList.join(' · ')}`);
