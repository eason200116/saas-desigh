#!/usr/bin/env node
/**
 * 扫描 src/views/**\/*.vue|.ts，识别每个页面目录调用的 api.<module>.<method>(req) 列表，
 * 自动为对应目录的 data.ts 生成「带启发式数据的 api 命名空间」，替换 Proxy 占位。
 *
 * 启发式分类：
 *   - 函数名含 list/page/records/items + (get|query|fetch) 前缀 → 返回 10 条随机数据
 *   - 函数名含 detail/info + (get|query|fetch) 前缀  → 返回单个对象
 *   - 函数名含 (add|create|insert)  → 成功 + 带新 id
 *   - 函数名含 (update|edit|modify|delete|remove|disable|enable|state|toggle|reset|set|sort|sync|export|import|approve|reject|audit|publish) → 成功
 *   - 函数名含 (select|option|dict|enum|type|category|tree)  → 返回 5 个选项
 *   - 函数名含 (count|total|sum|stat|trend|summary)  → 返回单个数字 / 对象
 *   - 函数名含 (download|file|excel)  → 返回 string url
 *   - 默认 → 成功 + data:null
 */

import { readFileSync, writeFileSync, existsSync } from 'node:fs';
import { dirname, resolve, basename } from 'node:path';
import { glob } from 'glob';

// 收集每个 view dir 下的 api 调用
const files = await glob('src/views/**/*.{vue,ts}', {
  cwd: process.cwd(),
  absolute: true,
});
const dirCalls = new Map(); // dirPath -> Set<"module.method">

for (const f of files) {
  const c = readFileSync(f, 'utf8');
  const dir = dirname(f);
  // 跳过 data.ts 自身
  if (basename(f) === 'data.ts') continue;
  for (const m of c.matchAll(/api\.(\w+)\.(\w+)/g)) {
    if (!dirCalls.has(dir)) dirCalls.set(dir, new Set());
    dirCalls.get(dir).add(`${m[1]}.${m[2]}`);
  }
}

function classify(method) {
  const m = method.toLowerCase();

  // 精确 pagelist 形态
  if (/(pagelist|paging|pagedlist|recordslist|tablelist)/i.test(method)) return 'list';
  // getXxxList / queryXxxList
  if (/^(get|query|fetch|search|list)\w*list$/i.test(method)) return 'list';
  // getXxxPage
  if (/^(get|query|fetch|search)\w*page$/i.test(method)) return 'list';
  // getXxxRecords / getXxxItems
  if (/^(get|query|fetch|search)\w*(records?|items?|table)$/i.test(method)) return 'list';
  // homeBasic / dashboard / stat
  if (/(homebasic|dashboard|statistic|summary|overview|metric|kpi|chart|trend|count|total|sum|stat)/i.test(method)) return 'stat';
  // detail/info
  if (/(detail|info|byid|bykey|bycode)/i.test(method) && /^(get|query|fetch)/i.test(method)) return 'detail';
  // tree / hierarchical
  if (/(tree|hierarch)/i.test(method) && /^(get|query|fetch|list)/i.test(method)) return 'tree';
  // option/select/dict
  if (/(selectlist|selectdata|options?|dict|enum|category|typeslist)/i.test(method) && /^(get|query|fetch|list)/i.test(method)) return 'options';
  if (/^(get|query|fetch|list)\w*options?$/i.test(method)) return 'options';
  if (/^(get|query|fetch|list)\w*select(data|list)?$/i.test(method)) return 'options';
  // download
  if (/(download|export|excel|csv|pdf)/i.test(method)) return 'download';
  // write actions
  if (/^(add|create|insert|save|new)/i.test(method)) return 'create';
  if (/^(update|edit|modify|set|toggle|enable|disable|state|sort|sync|reset|approve|reject|audit|publish|cancel|confirm|verify|check|markread|mark|clear|refresh|run|pause|resume|register)/i.test(method)) return 'success';
  if (/^(delete|remove|destroy)/i.test(method)) return 'success';
  // manual/admin action verbs
  if (/^(manual|admin|submit)/i.test(method)) return 'success';
  // generic get fallback
  if (/^(get|query|fetch|list|search)/i.test(method)) return 'detail';
  return 'success';
}

function genMethodImpl(method, mod) {
  const kind = classify(method);
  switch (kind) {
    case 'list':
      return `async function ${method}(req) {
    const total = 38;
    const pageSize = Number(req && req.pageSize) || 20;
    const pageNo = Number(req && (req.pageNo || req.page)) || 1;
    const start = (pageNo - 1) * pageSize;
    const count = Math.min(pageSize, Math.max(0, total - start));
    const list = Array.from({ length: count }).map((_, i) => {
      const idx = start + i + 1;
      return {
        id: idx,
        ${mod}Id: '${mod.toUpperCase().slice(0, 2)}' + (100000 + idx),
        name: '示例 ${mod} ' + idx,
        code: '${mod.toUpperCase().slice(0, 3)}-' + String(idx).padStart(4, '0'),
        title: '${mod} 标题示例 ' + idx,
        status: idx % 3 === 0 ? 0 : 1,
        state: idx % 3 === 0 ? 0 : 1,
        type: ['A', 'B', 'C'][idx % 3],
        amount: 100 + idx * 13,
        balance: 1000 + idx * 67,
        userName: 'user_' + idx,
        nickName: '会员_' + idx,
        memberName: '会员_' + idx,
        phone: '13' + String(100000000 + idx),
        email: 'user' + idx + '@example.com',
        remark: idx % 4 === 0 ? '示例备注' : '',
        creator: 'admin',
        tenantName: '示例商户 ' + ((idx % 5) + 1),
        currency: ['CNY', 'USD', 'EUR'][idx % 3],
        orderNo: 'ORD' + String(20260000 + idx).padStart(10, '0'),
        createTime: '2026-0' + ((idx % 9) + 1) + '-' + String((idx % 27) + 1).padStart(2, '0') + ' 10:23:00',
        updateTime: '2026-0' + ((idx % 9) + 1) + '-' + String((idx % 27) + 1).padStart(2, '0') + ' 15:30:00',
      };
    });
    return { code: 0, result: true, data: { list, records: list, rows: list, total, pageNo, pageSize }, msg: 'success' };
  }`;

    case 'detail':
      return `async function ${method}(req) {
    return { code: 0, result: true, data: {
      id: (req && req.id) || 1,
      ${mod}Id: '${mod.toUpperCase().slice(0, 2)}100001',
      name: '示例 ${mod} 详情',
      code: '${mod.toUpperCase().slice(0, 3)}-0001',
      status: 1,
      state: 1,
      amount: 1234,
      balance: 5678,
      userName: 'demo_user',
      nickName: '演示用户',
      remark: '原型阶段示例详情数据',
      creator: 'admin',
      createTime: '2026-05-18 10:23:00',
      updateTime: '2026-05-19 15:30:00',
    }, msg: 'success' };
  }`;

    case 'tree':
      return `async function ${method}(_req) {
    const data = Array.from({ length: 3 }).map((_, i) => ({
      id: i + 1,
      name: '顶级节点 ' + (i + 1),
      label: '顶级节点 ' + (i + 1),
      value: i + 1,
      children: Array.from({ length: 2 }).map((__, j) => ({
        id: (i + 1) * 10 + j,
        name: '子节点 ' + (j + 1),
        label: '子节点 ' + (j + 1),
        value: (i + 1) * 10 + j,
        children: [],
      })),
    }));
    return { code: 0, result: true, data, msg: 'success' };
  }`;

    case 'options':
      return `async function ${method}(_req) {
    const data = [
      { value: 1, label: '选项一', code: 'A', name: '选项一', id: 1 },
      { value: 2, label: '选项二', code: 'B', name: '选项二', id: 2 },
      { value: 3, label: '选项三', code: 'C', name: '选项三', id: 3 },
      { value: 4, label: '选项四', code: 'D', name: '选项四', id: 4 },
      { value: 5, label: '选项五', code: 'E', name: '选项五', id: 5 },
    ];
    return { code: 0, result: true, data, msg: 'success' };
  }`;

    case 'stat':
      return `async function ${method}(_req) {
    return { code: 0, result: true, data: {
      total: 12450,
      count: 12450,
      todayCount: 86,
      yesterdayCount: 79,
      weekCount: 543,
      monthCount: 2304,
      amount: 2368900,
      todayAmount: 56320,
      growth: 12.3,
      registerCount: 320,
      activeCount: 1280,
      rechargeAmount: 980000,
      withdrawAmount: 740000,
      trend: Array.from({ length: 7 }).map((_, i) => ({
        date: '2026-05-' + String(12 + i).padStart(2, '0'),
        value: 30000 + i * 3500,
        count: 50 + i * 12,
        amount: 100000 + i * 15000,
      })),
    }, msg: 'success' };
  }`;

    case 'download':
      return `async function ${method}(_req) {
    return { code: 0, result: true, data: { url: '/cdn/export/demo.xlsx', fileName: '示例导出.xlsx' }, msg: 'success' };
  }`;

    case 'create':
      return `async function ${method}(req) {
    return { code: 0, result: true, data: { id: Date.now(), ...(req || {}) }, msg: 'success' };
  }`;

    case 'success':
    default:
      return `async function ${method}() {
    return { code: 0, result: true, data: null, msg: 'success' };
  }`;
  }
}

let upgraded = 0;
let skipped = 0;

for (const [dir, calls] of dirCalls.entries()) {
  const dataPath = resolve(dir, 'data.ts');
  if (!existsSync(dataPath)) continue;

  const current = readFileSync(dataPath, 'utf8');
  // 跳过已经手工填充的（不含 Proxy 占位特征）
  if (!current.includes('new Proxy(') && current.length > 400) {
    skipped++;
    continue;
  }

  // 按 module 分组
  const modGroups = new Map();
  for (const call of calls) {
    const [mod, method] = call.split('.');
    if (!mod || !method) continue;
    if (!modGroups.has(mod)) modGroups.set(mod, new Set());
    modGroups.get(mod).add(method);
  }

  if (modGroups.size === 0) {
    skipped++;
    continue;
  }

  // 先收集所有函数定义
  const funcDefs = [];
  const apiExportLines = [];

  for (const [mod, methods] of modGroups.entries()) {
    const methodLines = [];
    for (const method of methods) {
      funcDefs.push(genMethodImpl(method, mod));
      methodLines.push(`    ${method},`);
    }
    apiExportLines.push(`  ${mod}: {\n${methodLines.join('\n')}\n  },`);
  }

  // 组装新 data.ts（函数在顶层，export const api 在底部）
  let out = `// 启发式生成的 data.ts —— 让本页有数据可看
// 视图调用：const { data, result } = await api.<module>.<method>(req);
// 函数按函数名启发式分类（list/detail/options/stat/create/success 等）
// 真实数据需手动覆盖：直接编辑本文件即可。

`;

  for (const funcDef of funcDefs) {
    out += funcDef + '\n\n';
  }

  out += `export const api: any = {\n${apiExportLines.join('\n')}\n};\n`;

  // 兼容直接 import http 的组件
  out += `
export const http: any = new Proxy(
  {},
  {
    get(_t: any, _method: string) {
      return async (..._args: any[]) => ({ code: 0, result: true, data: null, msg: 'success' });
    },
  },
);
`;

  writeFileSync(dataPath, out);
  upgraded++;
  const relPath = dataPath.replace(process.cwd() + '/', '');
  console.log(`[upgraded] ${relPath} (${calls.size} methods from ${modGroups.size} modules)`);
}

console.log(`\nTotal upgraded: ${upgraded}`);
console.log(`Total skipped (already populated or no api calls): ${skipped}`);
