#!/usr/bin/env node
import { readFileSync, writeFileSync, existsSync } from 'node:fs';
import { dirname, resolve, relative } from 'node:path';
import { glob } from 'glob';

const files = await glob('src/components/**/*.{vue,ts}', { absolute: true, cwd: process.cwd() });

const placeholder = `// 占位 data.ts —— components 层占位，UI 跑得起来不报模块缺失
// 视图调用形态保持源项目一致：const { data, result } = await api.<module>.<method>(req);
export const api: any = new Proxy(
  {},
  {
    get(_t, mod: string) {
      return new Proxy(
        {},
        {
          get(_, method: string) {
            return async (..._args: any[]) => {
              console.warn('[component data placeholder] api.' + mod + '.' + method + ' not implemented');
              return { code: 0, result: true, data: null, msg: 'placeholder' };
            };
          },
        },
      );
    },
  },
);

// 兼容：组件如直接 import http
export const http: any = new Proxy(
  {},
  {
    get(_t, method: string) {
      return async (..._args: any[]) => {
        console.warn('[component http placeholder] http.' + method + ' not implemented');
        return { code: 0, result: true, data: null, msg: 'placeholder' };
      };
    },
  },
);
`;

// 找到「最近的组件根目录」：从文件向上找第一个含 .vue 或 index.ts 的目录
function findComponentRoot(filePath) {
  let dir = dirname(filePath);
  const componentsRoot = resolve(process.cwd(), 'src/components');
  while (dir.startsWith(componentsRoot) && dir !== componentsRoot) {
    // 当前层下如果有同名 .vue 或 index.ts，认为是组件根
    // 简单判断：当前目录是不是 components 的一级子目录（src/components/Xxx/）
    const parentIsComponentsRoot = dirname(dir) === componentsRoot;
    if (parentIsComponentsRoot) return dir;
    dir = dirname(dir);
  }
  return null;
}

let modified = 0;
const touchedRoots = new Set();
for (const f of files) {
  let content = readFileSync(f, 'utf8');
  const before = content;

  const root = findComponentRoot(f);
  if (!root) continue;

  // 计算从当前文件到组件根 data.ts 的相对路径
  const dataPath = resolve(root, 'data');
  let rel = relative(dirname(f), dataPath).replace(/\\/g, '/');
  if (!rel.startsWith('.')) rel = './' + rel;

  // 删除 type-only import from @/api...
  content = content.replace(
    /^\s*import\s+type\s+\{[^}]*\}\s+from\s+(['"])@\/api(\/[^'"]+)?\1;?\s*$\n?/gm,
    '',
  );

  // 普通 import from '@/api' or '@/api/...'  → from '<rel-to-component-root>/data'
  content = content.replace(
    /from\s+(['"])@\/api(\/[^'"]+)?\1/g,
    `from '${rel}'`,
  );

  // 顺手删 @/utils/http import 行
  content = content.replace(
    /^\s*import\s+[^;]*?from\s+(['"])@\/utils\/http\1;?\s*$\n?/gm,
    '',
  );

  if (content !== before) {
    writeFileSync(f, content);
    modified++;
    touchedRoots.add(root);
    console.log(`[modified] ${f.replace(process.cwd() + '/', '')} -> ${rel}`);
  }
}

let placeholderCount = 0;
for (const root of touchedRoots) {
  const dataPath = resolve(root, 'data.ts');
  if (!existsSync(dataPath)) {
    writeFileSync(dataPath, placeholder);
    placeholderCount++;
    console.log(`[placeholder] ${dataPath.replace(process.cwd() + '/', '')}`);
  }
}

console.log(`\nTotal files modified: ${modified}`);
console.log(`Total placeholders created: ${placeholderCount}`);
