#!/usr/bin/env node
// 给所有视图目录的占位 data.ts 追加 http stub export，
// 让那些视图文件 import { http } from './data' 能正常解析。

import { readFileSync, writeFileSync } from 'node:fs';
import { glob } from 'glob';

const httpStub = `
// http stub —— 视图层直接调 http 时从 ./data import，Unit 8/9 替换为真实实现
export const http: any = {
  post: async (_url: string, _body?: any, _cfg?: any) => ({ data: null, code: 0, msg: 'placeholder' }),
  get: async (_url: string, _params?: any, _cfg?: any) => ({ data: null, code: 0, msg: 'placeholder' }),
};
`;

const dataFiles = await glob('src/views/**/data.ts', { absolute: true });

let modified = 0;
for (const f of dataFiles) {
  const content = readFileSync(f, 'utf8');
  if (!content.includes('export const http')) {
    writeFileSync(f, content + httpStub);
    modified++;
  }
}

console.log(`Added http stub to ${modified} data.ts files`);
