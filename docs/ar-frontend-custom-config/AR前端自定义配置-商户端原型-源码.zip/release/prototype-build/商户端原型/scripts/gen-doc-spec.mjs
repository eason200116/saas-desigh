#!/usr/bin/env node
/**
 * gen-doc-spec.mjs —— 悬停定位规范「文档抽取」试验脚本
 *
 * 目标：把「交互规则」+「字段词典」两个文档里对应控件的内容抽出来，
 * 生成 DevLocator 悬停用的 doc-index（机器生成，勿手改）。
 * 以后只维护那两个文档，悬停内容自动跟着变。
 *
 *  - 控件名称/规范/逻辑/Toast/边界  ← 交互规则 interaction-rules-2.0.html
 *  - 字段 + 字段定义                ← 字段词典 14-anchor-new-field-glossary.html
 *
 * 试验范围：仅「会员管理-登录记录」一页。跑：node scripts/gen-doc-spec.mjs
 */
import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = dirname(fileURLToPath(import.meta.url));
const REPO = resolve(__dirname, '..');

const INTERACTION = '/Users/eason/v1/saas-desigh/docs/interaction-rules-2.0.html';
const GLOSSARY = resolve(REPO, 'docs/migration/14-anchor-new-field-glossary.html');
const OUT_DIR = resolve(REPO, 'src/components/DevLocator/spec-data/doc-index');

// 页配置：spec 名 → 交互规则 section id + 字段词典 route
// route = 该页真实 app 路由(用作 __meta.route,DevLocator 按它命中)；
// glossaryRoute = 字段词典里的 route 键(缺省=route)。二者不一致时两者都填(如 IP黑名单:
// app 在 /operations/ipBlacklist,词典键却是 /system/ipBlacklist)。
const PAGES = [
  { spec: 'memberLoginLog', section: 'p-member-loginLog', route: '/member/loginLog' },
  { spec: 'memberSmsCode', section: 'p-member-smsCode', route: '/member/smsCode' },
  { spec: 'memberGroupManage', section: 'p-member-groupManage', route: '/member/groupManage' },
  { spec: 'memberUser', section: 'p-member-user', route: '/member/user' },
  // 运营管理·新入口 干净列表页（5）
  { spec: 'opsMemberRebateLevel', section: 'p-operations-memberRebateLevel', route: '/operations/memberRebateLevel' },
  { spec: 'opsEmailConfig', section: 'p-operations-emailConfig', route: '/operations/emailConfig' },
  { spec: 'opsIpBlacklist', section: 'p-system-ipBlacklist', route: '/operations/ipBlacklist', glossaryRoute: '/system/ipBlacklist' },
  { spec: 'opsVipLevelCount', section: 'p-operations-vipLevelCount', route: '/operations/vipLevelCount' },
  { spec: 'opsRebateLevelYesterday', section: 'p-operations-rebateLevelYesterday', route: '/operations/rebateLevelYesterday' },
  // 全站铺开(批2) 干净列表页（9）
  { spec: 'opsChannelConfig', section: 'p-operations-channelConfig', route: '/operations/channelConfig' },
  { spec: 'opsBanner', section: 'p-operations-banner', route: '/operations/banner' },
  { spec: 'opsSmsConfig', section: 'p-operations-smsConfig', route: '/operations/smsConfig' },
  { spec: 'reportAgentReport', section: 'p-report-agentReport', route: '/report/agentReport' },
  { spec: 'reportChannelAlert', section: 'p-report-channelAlert', route: '/report/channel-alert' },
  { spec: 'riskAbnormalMember', section: 'p-risk-abnormalMember', route: '/risk-control/abnormalMember' },
  { spec: 'riskSameIp', section: 'p-risk-sameIp', route: '/risk-control/sameIp' },
  { spec: 'sysPlatformLog', section: 'p-system-platformLog', route: '/system/platform-log' },
  { spec: 'sysRole', section: 'p-system-role', route: '/system/role' },
  // 配置表单页（B·4）——表单控件靠 data-spec 锚点命中 controls；switchParam 词典无 route(fields空)
  { spec: 'cfgRegisterManage', section: 'p-config-registerManage', route: '/config-center/registerManage' },
  { spec: 'cfgLanguageConfig', section: 'p-config-languageConfig', route: '/config-center/languageConfig' },
  { spec: 'cfgSwitchParam', section: 'p-config-switchParam', route: '/config-center/switchParam' },
  { spec: 'opsAgreementMgmt', section: 'p-operations-agreementMgmt', route: '/operations/agreementMgmt' },
  // ⤵ 悬停铺开·收口 5 页（2026-07-03）
  // 返佣报表：父壳三页签(流水/报表/层级)，字段词典按 tab 分 route，故 glossaryRoutes 合并三 tab
  {
    spec: 'reportRebateReport',
    section: 'p-report-rebateReport',
    route: '/report/rebateReport',
    glossaryRoutes: [
      '/report/rebateReport/flow',
      '/report/rebateReport/report',
      '/report/rebateReport/level',
    ],
  },
  { spec: 'opsInboxMessage', section: 'p-operations-inboxMessage', route: '/operations/inboxMessage' },
  // VIP记录：父壳复用 vipRewardLog + vipOpLog 两页，activeTab 走 query 不改 route，
  // route 恒为 /operations/vipRecord → 合并两 section + 两 tab 词典 route
  {
    spec: 'opsVipRecord',
    sections: ['p-operations-vipRewardLog', 'p-operations-vipOpLog'],
    route: '/operations/vipRecord',
    glossaryRoutes: [
      '/operations/vipRecord (reward页签)',
      '/operations/vipRecord (levelChange页签)',
    ],
  },
  // 系统参数配置 / 开关配置：均被融合页「开关参数配置」(switchParam) 取代(hidden 直达)，
  // 渲染同一批开关/参数控件，复用其交互规则 section p-config-switchParam(generic 占位 key)
  { spec: 'cfgSysParam', section: 'p-config-switchParam', route: '/config-center/sysParam' },
  { spec: 'cfgConfigSwitch', section: 'p-config-switchParam', route: '/config-center/configSwitch' },
];

// ---------- 工具 ----------
function decodeEntities(s) {
  return s
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&amp;/g, '&')
    .replace(/&#39;/g, "'")
    .replace(/&quot;/g, '"')
    .replace(/&nbsp;/g, ' ');
}
function stripTags(s) {
  return decodeEntities(String(s).replace(/<[^>]+>/g, ' ')).replace(/\s+/g, ' ').trim();
}

// 取某 section 的 HTML（从它前面最近的 <section 到下一个 </section>）
function sectionHtml(html, id) {
  const at = html.indexOf(`id="${id}"`);
  if (at < 0) return '';
  const start = html.lastIndexOf('<section', at);
  const end = html.indexOf('</section>', at);
  return html.slice(start < 0 ? at : start, end < 0 ? html.length : end);
}

// 解析 section 内所有 <table class="ct"> → { key: entry }
function parseSection(secHtml) {
  // 分两类：controls=搜索/筛选控件（每段第一个「控件名称」表）；
  //         actions=列交互(可点列链接)/按钮(动作表 + 其后的「控件名称」表)
  const controls = {};
  const actions = {};
  const tables = secHtml.match(/<table class="ct">[\s\S]*?<\/table>/g) || [];
  let sawSearch = false;
  for (const tbl of tables) {
    const rows = tbl.match(/<tr>[\s\S]*?<\/tr>/g) || [];
    if (rows.length < 2) continue;
    const headerCells = (rows[0].match(/<t[hd][^>]*>[\s\S]*?<\/t[hd]>/g) || []).map(stripTags);
    const isAction = /动作/.test(headerCells[0] || '');
    // 分类：动作表→actions(button)；首个控件名称表→controls(搜索,input)；其后控件名称表→actions(列交互,input)
    let target, defaultType;
    if (isAction) {
      target = actions;
      defaultType = 'button';
    } else if (!sawSearch) {
      target = controls;
      defaultType = 'input';
      sawSearch = true;
    } else {
      target = actions;
      defaultType = 'input';
    }
    const colMap = headerCells.map((h) => {
      if (/动作|控件名称/.test(h)) return 'name';
      if (/名称定义/.test(h)) return 'nameDef';
      if (/控件规范/.test(h)) return 'spec';
      if (/控件逻辑/.test(h)) return 'logic';
      if (/Toast/i.test(h)) return 'toast';
      if (/边界/.test(h)) return 'boundary';
      return null;
    });
    for (let i = 1; i < rows.length; i++) {
      const cells = rows[i].match(/<t[dh][^>]*>[\s\S]*?<\/t[hd]>/g) || [];
      if (!cells.length) continue;
      const keyM = rows[i].match(/<span class="k">([^<]+)<\/span>/);
      const nameM = cells[0].match(/<b>([\s\S]*?)<\/b>/);
      // key 可能带中文注解如「timeRange（写入 startTime/endTime）」→ 剥掉括号注解取纯 key
      const key = keyM ? keyM[1].trim().split(/[（(]/)[0].trim() : '';
      const name = nameM ? stripTags(nameM[1]) : '';
      if (!key && !name) continue;
      const e = { field: key || name, name, type: defaultType };
      cells.forEach((c, idx) => {
        const f = colMap[idx];
        if (!f || f === 'name') return;
        const v = stripTags(c);
        if (!v || v === '—') return;
        if (f === 'nameDef') e.fieldDef = v; // 名称定义 → 字段定义(交互口径，词典有则覆盖)
        else e[f] = v;
      });
      target[key || name] = e;
    }
  }
  return { controls, actions };
}

// 解析字段词典 → { route: { key: {name, def, plain} } }
// 词典是 JS 对象数组，页块形如 {m:'',p:'',route:'/x',fields:[ ['状态','key','旧名','新名','定义','大白话','flag'], ... ]}
// 注意：字段行用单引号，字符串可能含单/双引号混用。
function parseGlossary(html) {
  const byRoute = {};
  // 按 route 分块：每个页块从它的 route 到下一个 route(或结尾)；块内用方括号平衡取 fields 数组，
  // 避免超长 pageNote/嵌套引号把非贪婪正则搞乱(旧写法对 groupManage 失效)。
  const routeRe = /route:\s*'([^']*)'/g;
  const marks = [];
  let m;
  while ((m = routeRe.exec(html))) marks.push({ route: m[1], idx: m.index });
  for (let i = 0; i < marks.length; i++) {
    const start = marks[i].idx;
    const end = i + 1 < marks.length ? marks[i + 1].idx : html.length;
    const block = html.slice(start, end);
    const fi = block.indexOf('fields:[');
    if (fi < 0) continue;
    // 从 fields:[ 起做方括号平衡，取整个 fields 数组内容
    let depth = 0;
    let body = '';
    for (let j = fi + 'fields:'.length; j < block.length; j++) {
      const ch = block[j];
      if (ch === '[') {
        depth++;
        if (depth === 1) continue;
      } else if (ch === ']') {
        depth--;
        if (depth === 0) break;
      }
      if (depth >= 1) body += ch;
    }
    const rows = body.match(/\[[^\]]*\]/g) || [];
    const map = (byRoute[marks[i].route] = byRoute[marks[i].route] || {});
    for (const r of rows) {
      const cells = [...r.matchAll(/'((?:[^'\\]|\\.)*)'|"((?:[^"\\]|\\.)*)"/g)].map((x) =>
        x[1] !== undefined ? x[1] : x[2],
      );
      if (cells.length < 6) continue; // 跳过 ['grp','段标题'] 这类 2 元素分节行
      const [, keyCell, , newName, def, plain] = cells;
      if (!keyCell) continue;
      // 词典 key 约定：①「旧名→新名」取箭头后的新名(当前列 key)；②「keyA/keyB」= 一行覆盖多列(如
      // creator/lastUpdateMan、teamCount/teamRecharge),拆成每个 key 各挂同一份定义。
      const afterArrow = String(keyCell).split('→').pop().trim();
      const keys = afterArrow.split('/').map((s) => s.trim()).filter(Boolean);
      // 首现优先：同一 route 块内 key 重复时(如 role 的 name 既是「角色名称」又在权限树分节里是
      // 「节点名称」)保留先出现的那条(列表字段在前、弹窗/树字段在后),避免后者覆盖前者。
      for (const kk of keys) if (!map[kk]) map[kk] = { name: newName || '', def: def || '', plain: plain || '' };
    }
  }
  return byRoute;
}

// ---------- 主流程 ----------
const interactionHtml = readFileSync(INTERACTION, 'utf-8');
const glossary = parseGlossary(readFileSync(GLOSSARY, 'utf-8'));
mkdirSync(OUT_DIR, { recursive: true });

for (const page of PAGES) {
  const { spec, route, glossaryRoute } = page;
  // 支持单页多 section 合并(如 VIP记录=vipRewardLog+vipOpLog、融合页复用 switchParam)：
  // 逐 section 各自 parseSection(保持「首个控件名称表=搜索」分类正确)，再按层合并。
  const sectionIds = page.sections || [page.section];
  const controls = {};
  const actions = {};
  let anyFound = false;
  for (const sid of sectionIds) {
    const sec = sectionHtml(interactionHtml, sid);
    if (!sec) {
      console.warn(`⚠ 找不到 section ${sid}`);
      continue;
    }
    anyFound = true;
    // controls=搜索/筛选控件；actions=列交互(可点列)/按钮。字段定义都以词典为准
    const p = parseSection(sec);
    Object.assign(controls, p.controls);
    Object.assign(actions, p.actions);
  }
  if (!anyFound) continue;
  const section = sectionIds.join(' + ');
  // 字段词典字段：支持多 route 合并(如返佣报表按 tab 分 route、VIP记录两页签各一 route)
  const glossaryRoutes = page.glossaryRoutes || [glossaryRoute || route];
  const gfields = {};
  for (const gr of glossaryRoutes) Object.assign(gfields, glossary[gr] || {});
  for (const map of [controls, actions]) {
    for (const k of Object.keys(map)) {
      const g = gfields[k];
      if (g) {
        if (g.def) map[k].fieldDef = g.def;
        if (g.plain) map[k].intro = g.plain;
      }
    }
  }
  // 确认控件：确认/保存/提交/发布/应用/确定等「最终操作」——普通控件内容 + 额外「校验枚举」
  const CONFIRM_RE = /确认|保存|提交|发布|应用|确定|下发|套用/;
  for (const map of [controls, actions]) {
    for (const k of Object.keys(map)) {
      if (CONFIRM_RE.test(map[k].name || '')) {
        map[k].type = 'confirm';
        // 校验枚举来源：交互文档「控件规范(能输什么·限制·输错怎么提醒)」= 保存前的校验；无则待文档补
        if (map[k].spec) {
          map[k].checkEnum = map[k].spec;
          delete map[k].spec;
        }
      }
    }
  }
  // fields：词典里的静态字段（纯展示列等），全部 static，只显字段+定义+大白话
  const fields = {};
  for (const k of Object.keys(gfields)) {
    const g = gfields[k];
    fields[k] = {
      field: k,
      name: g.name || k,
      type: 'static',
      fieldDef: g.def || '',
      intro: g.plain || '',
    };
  }
  const out = {
    __meta: {
      generated: true,
      note: '机器生成·勿手改。controls=交互规则搜索项，actions=交互规则列交互/按钮，fields=字段词典静态列。改内容请改文档后重跑 node scripts/gen-doc-spec.mjs',
      section,
      route,
    },
    controls,
    actions,
    fields,
  };
  const file = resolve(OUT_DIR, `${spec}.json`);
  writeFileSync(file, JSON.stringify(out, null, 2) + '\n', 'utf-8');
  console.log(
    `✓ ${spec}: 搜索控件 ${Object.keys(controls).length} + 列交互/按钮 ${Object.keys(actions).length} + 静态字段 ${Object.keys(fields).length} → ${file}`,
  );
}
