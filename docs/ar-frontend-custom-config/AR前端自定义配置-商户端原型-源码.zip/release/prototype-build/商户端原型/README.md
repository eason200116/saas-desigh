# AR 原型项目（V3）

基于 Vue 3 + Naive UI + ProCrudTable 的**原型应用**——UI 真、数据假，用于产品演示与功能讨论。

## 特点

- **企业级架构**：Vite + TS + Pinia + Vue Router + i18n + Tailwind v4
- **零网络层**：无 axios / 无 mock adapter / 无字典中心；每页 `data.ts` 提供本地数据
- **单包双角色**：右下角浮窗在「商户端」与「总控端」之间切换（默认进入商户端）
- **中英双语**：runtime 模式 + namespace 懒加载
- **每页活文档**：每个页面同目录配套 `.md`，描述字段含义与业务规则
- **代码规范**：oxlint + Prettier + Husky + commitlint（中文提交）

## 启动

```bash
pnpm install
pnpm dev
```

浏览器打开 http://localhost:3100，账号密码随便填即可进入。默认进商户端，右下角浮窗点击切换到总控端（会刷新页面）。

## 添加新页面（项目内开发）

1. 在 `src/router/modules/<module>.ts` 添加路由（meta 含 `roles: ['admin'] / ['admin','tenant']`）
2. 创建 `src/views/<module>/<page>/index.vue`（参考已有页面，用 `ProCrudTable`）
3. 创建同目录 `data.ts`（导出 `api` 命名空间 + 列表 / 选项 / 操作函数）
4. 跑校验 `pnpm typecheck && pnpm lint && pnpm build`

## 命令

| 命令             | 说明                        |
| ---------------- | --------------------------- |
| `pnpm dev`       | 启动开发服务器（端口 3100） |
| `pnpm build`     | 生产构建                    |
| `pnpm preview`   | 预览构建产物                |
| `pnpm typecheck` | 类型检查                    |
| `pnpm lint`      | oxlint + 自动修复           |
| `pnpm lint:i18n` | 检查 i18n key 缺失          |

## 目录速览

```
src/
├── App.vue / main.ts
├── config/runtime.ts          # 全局常量唯一来源
├── components/                # 业务组件（含 RoleSwitcher / ProComponents）
├── layout/                    # 主布局
├── router/                    # 路由（modules 按角色 visibleFor 过滤）
├── store/                     # Pinia（含 role / user / notification）
├── i18n/                      # 中英文 i18n
├── utils/                     # 工具（含 dataHelpers：localPaginate / fuzzyFilter / ok）
├── views/                     # 页面（每页：index.vue + data.ts）
└── theme/ styles/ enums/ hooks/ directives/ plugins/ assets/
```

## 设计文档

- 设计稿：`docs/superpowers/specs/2026-05-20-prototype-scaffold-design.md`
- 实施计划：`docs/superpowers/plans/2026-05-20-prototype-scaffold-plan.md`

## License

私有项目，仅供内部使用。
