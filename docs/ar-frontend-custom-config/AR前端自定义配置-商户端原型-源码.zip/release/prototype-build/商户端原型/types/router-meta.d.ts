// vue-router RouteMeta augmentation
// 顶部 `import 'vue-router'` 让本文件成为 module，使 `declare module` 走 augmentation 路径
// （在 ambient script 里写 `declare module 'vue-router'` 会覆盖真实导出）。
import 'vue-router';

declare module 'vue-router' {
  interface RouteMeta {
    // 基础导航字段
    title?: string;
    icon?: any;
    hidden?: boolean;
    affix?: boolean;
    // 权限与角色
    permissions?: string[];
    ignoreAuth?: boolean;
    roles?: import('@/config/runtime').AppRole[];
    // 缓存与排序
    keepAlive?: boolean;
    noKeepAlive?: boolean;
    sort?: number;
    // 内嵌 iframe
    frameSrc?: string;
    externalLink?: string;
    // 菜单激活状态
    activeMenu?: string;
    alwaysShow?: boolean;
    // 子类型分组（菜单里把同一主类型下的页面按 group 归到分组头；值为 i18n key，如 menu.group.memberAccount）
    group?: string;
    // 迁移期标识：true=本次新增/改造的页面（菜单大菜单里标「新」），否则标「原」
    isNew?: boolean;
    // 迁移期标识：true=从其它板块迁移过来的页面（菜单大菜单里标「移」）；优先级低于 isNew
    isMoved?: boolean;
    // i18n 命名空间懒加载
    i18nNamespace?: string | string[];
    // 页内 Tab 配置
    tabs?: import('@/router/types').RouteTabMeta[];
    tabIgnoreQueryKeys?: string[];
  }
}
