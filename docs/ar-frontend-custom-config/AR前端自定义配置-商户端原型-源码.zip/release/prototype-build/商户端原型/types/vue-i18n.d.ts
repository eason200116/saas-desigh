/**
 * @description vue-i18n 类型拓展：把 `src/i18n/locales/zh/*.json` 的结构注入 DefineLocaleMessage，让 `t('namespace.foo.bar')` 获得 key 自动补全与错误提示。zh 作为规范语种，en 侧只需保证同构；新增 namespace JSON 时在下方追加一行 import 即可，不影响运行时。
 * @author
 * @date 2026-04-21
 * @scope 被 vue-tsc / 编辑器 LSP 消费，纯类型声明，不参与打包
 */
import type common from '../src/i18n/locales/zh/common.json';
import type menu from '../src/i18n/locales/zh/menu.json';
import type components from '../src/i18n/locales/zh/components.json';
import type dashboard from '../src/i18n/locales/zh/dashboard.json';
import type account from '../src/i18n/locales/zh/account.json';
import type agent from '../src/i18n/locales/zh/agent.json';
import type finance from '../src/i18n/locales/zh/finance.json';
import type game from '../src/i18n/locales/zh/game.json';
import type operations from '../src/i18n/locales/zh/operations.json';
import type erde from '../src/i18n/locales/zh/erde.json';
import type member from '../src/i18n/locales/zh/member.json';
import type tenant from '../src/i18n/locales/zh/tenant.json';
import type report from '../src/i18n/locales/zh/report.json';
import type analytics from '../src/i18n/locales/zh/analytics.json';
import type hubConfig from '../src/i18n/locales/zh/hubConfig.json';
import type productNav from '../src/i18n/locales/zh/productNav.json';
import type system from '../src/i18n/locales/zh/system.json';

/**
 * 项目消息总结构：每个 namespace 是 JSON 文件在运行时被 `mergeLocaleMessage` 合并到顶层后的形态。
 * namespace JSON 的顶层 key 保留在合并后的结构中，因此 DefineLocaleMessage 直接展开各 JSON 即可。
 */
export type ProjectLocaleMessage = typeof common &
  typeof menu &
  typeof components &
  typeof dashboard &
  typeof account &
  typeof agent &
  typeof finance &
  typeof game &
  typeof operations &
  typeof erde &
  typeof member &
  typeof tenant &
  typeof report &
  typeof analytics &
  typeof hubConfig &
  typeof productNav &
  typeof system;

declare module 'vue-i18n' {
  // 保守拓展：只为 DefineLocaleMessage 补默认形状，让 `t()` 签名在调用点获得推断；
  // 不锁死 DefineDateTimeFormat / DefineNumberFormat，避免和 naive-ui 的 date locale 冲突。
  export interface DefineLocaleMessage extends ProjectLocaleMessage {}
}
