export interface ProjectSettingState {
  //导航模式
  navMode: string;
  //导航风格
  navTheme: string;
  //顶部设置
  headerSetting: object;
  //菜单设置
  menuSetting: object;
  //多标签
  multiTabsSetting: object;
  //面包屑
  crumbsSetting: object;
  //外观配置
  appearance: ProjectAppearanceSetting;
  //布局配置
  layout: ProjectLayoutSetting;
  //通用配置
  general: ProjectGeneralSetting;
  //预设配置
  preset: ProjectPresetSetting;
}

/**
 * 主题模式
 */
export type ProjectThemeScheme = 'light' | 'dark' | 'auto';

/**
 * 导航主题
 */
export type ProjectNavigationTheme = 'light' | 'dark';

/**
 * 主题预设键
 */
export type ProjectThemePresetKey = 'ar-default' | 'soybean-classic' | 'soybean-compact';

/**
 * 外观配置
 */
export interface ProjectAppearanceSetting {
  /**
   * 品牌主题色
   */
  themeColor: string;
  /**
   * 主题模式
   */
  themeScheme: ProjectThemeScheme;
  /**
   * 是否启用灰阶模式
   */
  grayscale: boolean;
  /**
   * 是否启用色弱模式
   */
  colorWeakness: boolean;
  /**
   * 是否启用紧凑模式
   */
  compactMode: boolean;
  /**
   * 全局圆角尺寸
   */
  borderRadius: number;
}

/**
 * 布局配置
 */
export interface ProjectLayoutSetting {
  /**
   * 导航模式
   */
  navigationMode: string;
  /**
   * 导航风格
   */
  navigationTheme: ProjectNavigationTheme;
  /**
   * 是否启用混合菜单
   */
  mixMenu: boolean;
  /**
   * 菜单展开宽度
   */
  menuWidth: number;
  /**
   * 菜单折叠宽度
   */
  minMenuWidth: number;
  /**
   * 移动端触发宽度
   */
  mobileWidth: number;
}

/**
 * 通用配置
 */
export interface ProjectGeneralSetting {
  /**
   * 是否显示刷新按钮
   */
  showReload: boolean;
  /**
   * 是否显示标签页
   */
  showTabs: boolean;
  /**
   * 标签页是否固定
   */
  fixedTabs: boolean;
  /**
   * 是否显示面包屑
   */
  showBreadcrumb: boolean;
  /**
   * 是否显示面包屑图标
   */
  showBreadcrumbIcon: boolean;
  /**
   * 是否同步主题 CSS 变量
   */
  syncThemeCssVars: boolean;
  /**
   * 是否同步动态 favicon
   */
  syncDynamicFavicon: boolean;
}

/**
 * 预设配置
 */
export interface ProjectPresetSetting {
  /**
   * 当前预设键
   */
  activePreset: ProjectThemePresetKey;
  /**
   * 是否锁定预设
   */
  lockPreset: boolean;
}

export interface IBodySetting {
  fixed: boolean;
}

export interface IHeaderSetting {
  isReload: boolean;
}

export interface IMenuSetting {
  minMenuWidth: number;
  menuWidth: number;
  mixMenu: boolean;
  collapsed: boolean;
  mobileWidth: number;
}

export interface ICrumbsSetting {
  show: boolean;
  showIcon: boolean;
}

export interface IMultiTabsSetting {
  fixed: boolean;
  show: boolean;
}
export interface GlobConfig {
  title: string;
  apiUrl: string;
  shortName: string;
  urlPrefix?: string;
  uploadUrl?: string;
  prodMock: boolean;
  imgUrl?: string;
}

export interface GlobEnvConfig {
  // 标题
  VITE_GLOB_APP_TITLE: string;
  // 接口地址
  VITE_GLOB_API_URL: string;
  // 接口前缀
  VITE_GLOB_API_URL_PREFIX?: string;
  // Project abbreviation
  VITE_GLOB_APP_SHORT_NAME: string;
  // 图片上传地址
  VITE_GLOB_UPLOAD_URL?: string;
  //图片前缀地址
  VITE_GLOB_IMG_URL?: string;
  //生产环境开启mock
  VITE_GLOB_PROD_MOCK: boolean;
}
