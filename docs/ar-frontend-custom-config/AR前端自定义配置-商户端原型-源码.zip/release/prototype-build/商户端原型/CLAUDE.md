# CLAUDE.md — AR 原型项目（V3）开发规范

> 本文件是**所有使用 Claude 打开此项目的人都必须遵守的开发规范**。在做任何修改前，先读完本文件。本文件中的「红线」具有最高优先级，覆盖任何默认行为。

---

## 一、项目定位

「AR 原型项目（V3）」是一个**独立的原型应用**，用于产品演示和功能讨论。

| 维度       | 说明                                                                   |
| ---------- | ---------------------------------------------------------------------- |
| 用途       | 演示原型 / 验证 UI / 与产品讨论                                        |
| 数据       | 100% 本地 mock，无任何真实 HTTP 请求                                   |
| 后端       | **无** —— 不要假设存在后端服务                                         |
| 类型检查   | 接受 `any`，typecheck 残留错误不阻塞，但 **build 必须通过**            |
| 主要技术栈 | Vue 3 + TS + Vite + Naive UI + Pinia + Vue Router + i18n + Tailwind v4 |
| 双角色     | `admin`（总控端）/ `tenant`（商户端），右下角浮窗切换                  |

---

## 二、红线（NEVER）

**违反任何一条都会破坏原型可用性，必须严格遵守：**

> **【核心 · 元规则】NEVER 跳过任何规则。** 每个任务从开工到收尾，必须**完整过一遍所有适用规则**（本文件红线 + 全局/个人规则 R1–R51 + 基本规则），**逐条核对、不遗漏，绝不因"看着简单 / 需求明确 / 赶时间 / 自认为懂了"就省略任何一条**。收尾须写明"本任务命中并执行了哪些规则"，做到可核查。某规则本任务**确不适用可不执行，但"不适用 ≠ 跳过"**——判定不适用要有依据，拿不准就执行或问用户。此条统管其余所有规则的执行态度：**规则是用来执行的，不是参考**；不改变各规则间既有优先级（红线 > 我的规则 > 基本规则 > 个人习惯）。

1. **NEVER** 调用真实 HTTP 接口、引入 axios / fetch / mock adapter
2. **NEVER** 删除 `src/api/index.ts` —— 它是让旧代码能编译的全局 stub（Proxy）
3. **NEVER** 修改 `src/components/ProComponents/` 的核心逻辑
4. **NEVER** 在 i18n JSON 值里写 HTML 标签（`<br/>` / `<span>` 等会导致 build 报错）
5. **NEVER** 起 dev server 用浏览器调试问题 —— **优先看代码定位**（用户明确反馈过）
6. **NEVER** 在没读过消费方 `.vue` 实际字段时，凭空臆造 mock 数据字段
7. **NEVER** 在 router 模块里漏掉 `meta.roles`
8. **NEVER** 改了页面（`src/views/**/*.vue` 或 `data.ts`）却不走 **R62 收尾强制流程**就收尾/定稿 —— 必须逐步反补①交互规则+悬停 ②字段词典+悬停 ③修改记录 ④反查一致性 ⑤PRD修改日志 ⑦输出验收清单 ⑧用户确认。Stop 钩子会硬拦（`.claude/hooks/page-doc-gate.mjs`），详见 [`docs/migration/27-页面改动收尾强制流程-R62.md`](docs/migration/27-页面改动收尾强制流程-R62.md)；逃生舱 `SKIP_PAGE_DOC_GATE=1`

---

## 三、目录结构与文件职责

```
src/
├── api/index.ts                # 全局 API stub（Proxy + 覆盖表），让旧 hook 能跑
├── config/runtime.ts           # 全局常量唯一来源
├── components/
│   ├── ProComponents/          # ProCrudTable / ProField / ProSearchForm（不要改核心）
│   ├── DictSelect/data.ts      # 动态字典 mock（dictionarySource=dynamic 时用）
│   └── RoleSwitcher/           # 右下角角色切换浮窗
├── router/
│   ├── modules/                # 路由按业务模块拆分，每条带 meta.roles
│   ├── role-filter.ts          # 按 meta.roles 过滤路由树
│   ├── admin-routes.ts         # 总控端聚合
│   └── tenant-routes.ts        # 商户端聚合
├── store/modules/
│   ├── user.ts                 # 登录态 + UserInfo（含 orgList / tenantList）
│   ├── role.ts                 # 当前角色（admin / tenant）
│   └── adminWs.ts              # 业务推送事件占位（lastBusinessEvent 等）
├── views/<module>/<page>/
│   ├── index.vue               # 视图，import { api } from './data'
│   └── data.ts                 # 本页 mock（返回 envelope）
└── i18n/locales/{zh,en}/*.json # i18n（namespace 拆分，懒加载）
```

**每个页面的两件套是硬性约定：**

```
src/views/<module>/<page>/
├── index.vue   # 视图
└── data.ts     # 同目录 mock（缺一不可）
```

子组件/弹窗如果自带数据，放在 `components/data.ts`，由子组件自己 import `./data`。

---

## 四、添加新页面流程

```
1. 在 src/router/modules/<module>.ts 添加路由
   - meta.roles: ['admin'] 仅总控端 | ['tenant'] 仅商户端 | ['admin','tenant'] 双端
   - meta.title: i18n key（如 'routes.system.user'）
   - meta.keepAlive: 列表页加上以保留滚动/筛选状态

2. 创建 src/views/<module>/<page>/index.vue
   - 使用 ProCrudTable 组件（参考 src/views/finance/rechargeOrder/index.vue）
   - import { api } from './data'

3. 创建 src/views/<module>/<page>/data.ts
   - 导出 api 命名空间，方法返回 envelope { code, result, data, msg }

4. 加 i18n key
   - src/i18n/locales/zh/<ns>.json 和 en/<ns>.json 同步加

5. 校验
   pnpm typecheck && pnpm lint && pnpm lint:i18n && pnpm build

6. 收尾走 R62 强制流程（改页面必做，Stop 钩子硬拦）
   ① 反补交互规则(saas interaction-rules-2.0.html) + 同步悬停(DevLocator spec-data)
   ② 反补字段词典(docs/migration/14-anchor-...html) + 同步悬停
   ③ 反补修改记录 src/components/ChangeLogFab/data.ts
   ④ 反查 原型↔文档词典↔悬停 三方一致（双向）
   ⑤ 反补 PRD 修改日志 saas-phase2-prd-full.html
   ⑦ 输出验收清单（每条含 路径+修改内容）
   ⑧ 用户逐条验收确认 → 才算定稿
   详见 docs/migration/27-页面改动收尾强制流程-R62.md
```

---

## 五、data.ts 编写规范

### 5.1 标准 envelope 格式

**所有 mock 方法必须返回**：

```ts
return { code: 0, result: true, data: <payload>, msg: 'success' };
```

`code=0` 表示成功；列表型 payload 形如 `{ list, total, totalCount, pageNo, pageSize }`。

### 5.2 分页模板

```ts
async function getPageList(req?: any) {
  const pageSize = Number(req?.pageSize) || 20;
  const pageNo = Number(req?.pageNo || req?.page) || 1;
  const start = (pageNo - 1) * pageSize;
  const list = ALL_LIST.slice(start, start + pageSize);
  return {
    code: 0,
    result: true,
    data: { list, total: ALL_LIST.length, totalCount: ALL_LIST.length, pageNo, pageSize },
    msg: 'success',
  };
}
```

### 5.3 字段对齐方法（**最关键**）

**写 mock 数据前必须先打开消费方 `.vue` / 子组件，逐字段确认实际访问的 path。**

常见对齐错误（这次会话踩过）：

| 错误 | 后果 | 修复 |
| --- | --- | --- |
| `getUserDetail` 返回扁平对象 | 弹窗 `userInfo.xxx` 取不到 | 嵌套成 `{ userInfo, withdrawConfig, approvalConfig }` |
| `getDetailRecord` 缺 `bankCardDetail` 子结构 | 详情弹窗显示「无数据」 | 加上 `bankCardDetail` / `thirdPartyDetail` 嵌套对象 |
| 字典返回 `null` | 表格状态/类型列显示 `--` | 在 `src/api/index.ts` 的 `V1_DICTIONARY` / `COMMON_DICTIONARY` 加项 |
| `organizationGetSelectList` 缺 override | `useTenantOptions` load 失败死循环，整页卡死 | 在 `src/api/index.ts` 加 `tenantOverride` |

**字段对齐检查清单：**

- [ ] 列定义 `key` 在 mock 数据每条记录上都有对应字段
- [ ] 子组件 props 接收的字段都在 mock 中
- [ ] 详情弹窗读取的嵌套对象（`row.bankCardDetail`、`row.userInfo` 等）都构造完整
- [ ] 状态字段（`state` / `status` / `type`）和字典 id 对得上

### 5.4 导出 http stub

**所有 `data.ts` 末尾保留 http Proxy stub**，让旧代码能编译：

```ts
export const http: any = new Proxy(
  {},
  {
    get(_t: any, _method: string) {
      return async (..._args: any[]) => ({ code: 0, result: true, data: null, msg: 'success' });
    },
  },
);
```

---

## 六、全局 API stub（src/api/index.ts）

**这是整个项目的全局 mock 中枢**，被 `useUser` / `useTenantOptions` / `useDictionary` 等老 hook 使用。

### 6.1 工作机制

- 默认通过 Proxy 拦截 `api.<ns>.<method>(...)` 调用，返回空 envelope
- 通过 `xxxOverride` 表为特定方法提供真实 mock 数据
- 字典通过 `V1_DICTIONARY` / `COMMON_DICTIONARY` 常量集中维护

### 6.2 何时需要修改 src/api/index.ts

下列情况修改它，**而不是改页面的 data.ts**：

| 场景                                  | 修改位置                                   |
| ------------------------------------- | ------------------------------------------ |
| 全局字典缺项（表格/表单显示 `--`）    | `V1_DICTIONARY` / `COMMON_DICTIONARY`      |
| `useTenantOptions` 没数据             | `tenantOverride.organizationGetSelectList` |
| `useUser` 详情接口                    | `v1platformOverride.getUserDetail` 等      |
| 组件级 hook（如 `useUserWallet`）数据 | 对应 ns 的 override 表                     |

### 6.3 添加 override 模板

```ts
const myOverride: Record<string, AnyFn> = {
  getSomething: async () => ({ code: 0, result: true, data: { ... }, msg: 'success' }),
};

// 在 Proxy 的 get 里加分支：
if (ns === 'myNamespace') {
  return myOverride[method] || defaultEmpty;
}
```

---

## 七、字典体系

| 字典源 | 文件 | 用途 |
| --- | --- | --- |
| `v1` / `common` | `src/api/index.ts` 的 DICTIONARY 常量 | 老式 `useDictionary({ source: 'v1' })` |
| `dynamic` | `src/components/DictSelect/data.ts` 的 `FULL_DICT` | `DictSelect` / `ProField type=dict-select` |
| `platform` / `group` | 同上，`v1platformOverride.getDictionary` | 平台级、集团级字典 |

**字典缺失症状：** 状态列显示原始数字 / 下拉框为空 / 列显示 `--`。 **修复路径：** 找到调用源（grep `useDictionary` 或 `dictionarySource`），在对应字典常量里加 key。

---

## 八、路由角色规范

### 8.1 meta.roles 约定

```ts
{
  path: '/finance/rechargeOrder',
  meta: {
    title: 'routes.finance.rechargeOrder',
    roles: ['admin', 'tenant'],   // 必填
    keepAlive: true,              // 列表页建议加
  },
}
```

| roles 值              | 含义                   |
| --------------------- | ---------------------- |
| `['admin']`           | 仅总控端可见           |
| `['tenant']`          | 仅商户端可见           |
| `['admin', 'tenant']` | 双端可见               |
| `[]` 或缺失           | 两端都看不到（仅占位） |

### 8.2 角色与后端 `category` 字段映射

后端菜单 JSON 的 `category` 字段：

- `[1]` → `roles: ['admin']`
- `[2]` → `roles: ['tenant']`
- `[1, 2]` → `roles: ['admin', 'tenant']`

### 8.3 路由过滤逻辑

入口在 `src/router/role-filter.ts`：

- 按 `meta.roles` 过滤
- 删掉所有子节点都不可见的空父节点（除非父节点自己有 `redirect`）

---

## 九、视图层常见陷阱与正确写法

### 9.1 ProField 的 options 必须用函数形式

**错（会导致响应式失效或卡死）：**

```ts
{ valueType: 'select', componentProps: { options: organizationOptions.value } }
```

**对：**

```ts
{
  valueType: 'select',
  componentProps: () => ({ options: organizationOptions.value, placeholder: '...' }),
}
```

### 9.2 tableColumns / searchColumns 含响应式数据时必须 computed

**错：**

```ts
const tableColumns: ProColumn[] = [
  { key: 'tenantId', render: (row) => tenantMap.value[row.tenantId] },
];
```

**对：**

```ts
const tableColumns = computed<ProColumn[]>(() => [
  { key: 'tenantId', render: (row) => tenantMap.value[row.tenantId] },
]);
```

### 9.3 useTenantOptions / useUser 等老 hook

它们走全局 `@/api` stub，**对应的 override 没加 → load 失败 → loaded=false → 每次 ProField 挂载都重试 → 死循环**。

**解决：** 缺数据时**不要**改 hook 本身，而是去 `src/api/index.ts` 加 override。

### 9.4 router meta.keepAlive

列表页加 `keepAlive: true` 保留滚动/筛选；详情/表单页**不要加**，避免脏数据。

---

## 十、调试与排错约定

### 10.1 用户明确反馈：不要开浏览器调试

> 「不要开浏览器去调试，跟你说了进页面点就卡死，肯定是代码问题，检查字典定义这些。」

**调试顺序：**

1. **先看代码** —— 卡死/白屏/无限循环优先看：
   - 字典是否缺项（→ `src/api/index.ts`）
   - 全局 hook 用的 override 是否缺（→ `src/api/index.ts`）
   - 列定义 / 搜索表单 options 是否用了 `.value` 直接展开（→ 改函数形式）
   - 表格列是否包含响应式数据但没 computed
2. **看路由层** —— 路径配置、meta.roles、嵌套关系
3. **看消费字段** —— 打开 `.vue` 看 row.xxx 访问，对照 mock
4. **build 通过 = 成功底线**，typecheck 报错只要不影响 build 可忽略

### 10.2 常见症状速查

| 症状 | 大概率原因 |
| --- | --- |
| 进页面卡死 / CPU 飙高 | 全局 hook override 缺失导致 reload 死循环（如 `tenant.organizationGetSelectList`） |
| 状态列显示 `--` | 字典缺项 |
| 详情弹窗显示「无数据」 | mock 嵌套结构不对（`bankCardDetail` 等） |
| 左上角集团/商户为空 | `userStore.getInfo()` 没返回 `orgList` / `tenantList` |
| `[Vue warn] Invalid watch source: undefined` | watch 的字段不在 store state 上 → 补到 state 默认值 |
| 编辑/详情按钮点击后报「加载失败」 | 对应 `getXxxDetail` 没在 override 里实现 |

---

## 十一、子组件/弹窗的数据嵌套约定

**详情弹窗、抽屉、表单的 mock 数据嵌套结构必须严格按消费方拆分：**

```ts
// system/user 编辑商户用户：modal 需要嵌套
getTenantUserDetail: async (req) => ({
  code: 0, result: true,
  data: {
    userInfo: { id, account, ... },
    withdrawConfig: { ... },
    approvalConfig: { ... },
  },
});

// finance/withdrawOrder/workbench 查看详情：bankCard / thirdParty 分开
getDetailRecord: async (req) => ({
  code: 0, result: true,
  data: {
    orderNo, amount, status, ...,
    bankCardDetail: { bankName, cardNo, holderName, ... },
    thirdPartyDetail: { merchantName, channelType, ... },
  },
});
```

**先打开消费方 vue 文件看它如何解构数据，再构造 mock。**

---

## 十二、Store 维护要点

### 12.1 user store

`getInfo()` 必须返回完整 `UserInfoType`，包括：

```ts
{
  userId, account, userName, avatar,
  orgId, orgName,
  orgList: [{ id, name, tenantList: [...] }],   // 集团选择器用
  tenantList: [...],                            // 商户选择器用
  isSuperAuthUser: role === 'admin',
  // ... 角色不同字段不同
}
```

写入存储用 `storage.set(CURRENT_USER, info)` + `ACCESS_TOKEN` 常量。

### 12.2 adminWs store

`lastBusinessEvent` 等 watch 源**必须**在 state 默认值里有占位（`null`），否则 watch 会报 `Invalid watch source: undefined`。

### 12.3 role store

切换角色后**整页刷新**重置状态（包括路由）。

---

## 十三、i18n 规范

- key 走 namespace：`<ns>.<module>.<field>`，例如 `routes.finance.rechargeOrder`
- `src/i18n/locales/zh/<ns>.json` 与 `en/<ns>.json` **必须同步**
- **JSON 值里不能写 HTML 标签**（`<br/>` 会让 build 报错）
- 漏 key 用 `pnpm lint:i18n` 校验

---

## 十四、提交规范

```
<type>: <chinese subject>

[optional body]
```

`type`: `feat | fix | refactor | docs | test | chore | perf | ci`

- 主题行用中文
- attribution 已全局关闭
- 提交前跑过 `pnpm typecheck && pnpm lint && pnpm build`

---

## 十五、Claude 工作流约束

### 15.1 新功能开发：必须走 superpowers

**任何"新增 / 新建 / 开发一个 \_\_\_" 的请求，必须使用 superpowers skill 链路：**

```
brainstorming → planning → TDD/实现 → code-review
```

- 触发场景：新页面、新模块、新 hook、新组件、新 store、新 i18n namespace 等
- **不能跳过 skill 直接动手**，要先调相关 skill 厘清范围与产出
- 不确定范围时优先调 `brainstorming` skill

### 15.2 维护性修改：常规流程

下列**维护性任务**走常规流程即可，不强制 superpowers：

- 改 bug / 字段对齐 / 补 mock 数据 / 修字典缺项
- 调整文案 / 改 i18n key / 改样式
- 调整 hook override / 删多余代码

常规流程顺序：

1. **读 CLAUDE.md（本文件）** —— 任何修改前必读
2. **任务理解** —— 用户的请求是什么、目标是什么、影响范围
3. **代码定位** —— 用 grep / Read 而非 Bash 探索，遵循"先看代码再说"
4. **设计修改方案** —— 优先复用现有模式（参考 `src/views/finance/rechargeOrder/index.vue`）
5. **执行修改** —— 编辑而非新建，小文件优先
6. **校验** —— `pnpm typecheck && pnpm lint && pnpm build`
7. **总结** —— 1-2 句话说改了什么，不要长篇报告

### 15.3 禁止行为

- 新功能直接动手写代码，不走 superpowers
- 没读消费方代码就写 mock
- 用浏览器调试可以从代码看出来的问题
- 把 build 失败当作"原型可以接受"
- 修改 ProComponents 内部
- 调真实 HTTP 接口
- 不加 `meta.roles` 就建路由

---

## 十六、参考链接

- 设计稿：`docs/superpowers/specs/2026-05-20-prototype-scaffold-design.md`
- 实施计划：`docs/superpowers/plans/2026-05-20-prototype-scaffold-plan.md`
- ProCrudTable 用法：`src/components/ProComponents/COMPARISON.md`
- 标杆页面：`src/views/finance/rechargeOrder/index.vue`（参照此页结构）
- 全局 stub 中枢：`src/api/index.ts`
- 动态字典 mock：`src/components/DictSelect/data.ts`
- i18n namespace：`src/i18n/locales/zh/` 各 JSON 文件
