import { computed } from 'vue';
import { useProjectSettingStore } from '@/store/modules';
import { themeConfig } from './useGlobSetting';

export function useProjectSetting() {
  const projectStore = useProjectSettingStore();
  const themeColor = computed(() => projectStore.appearance.themeColor);
  const themeColorOptions = computed(() => themeConfig.brandColors);
  const navMode = computed(() => projectStore.navMode);
  const navTheme = computed(() => projectStore.navTheme);
  const isMobile = computed(() => projectStore.isMobile);
  const headerSetting = computed(() => projectStore.headerSetting);
  const multiTabsSetting = computed(() => projectStore.multiTabsSetting);
  const menuSetting = computed(() => projectStore.menuSetting);
  const crumbsSetting = computed(() => projectStore.crumbsSetting);
  const appearanceSetting = computed(() => projectStore.appearance);
  const layoutSetting = computed(() => projectStore.layout);
  const generalSetting = computed(() => projectStore.general);
  const presetSetting = computed(() => projectStore.preset);

  return {
    navMode,
    navTheme,
    isMobile,
    headerSetting,
    multiTabsSetting,
    menuSetting,
    crumbsSetting,
    appearanceSetting,
    layoutSetting,
    generalSetting,
    presetSetting,
    themeColor,
    themeColorOptions,
  };
}
