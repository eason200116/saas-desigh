import type {
  ProjectAppearanceSetting,
  ProjectGeneralSetting,
  ProjectLayoutSetting,
  ProjectPresetSetting,
} from '/#/config';
import { APP_CONFIG } from '@/config/runtime';
import { i18n } from '@/i18n';
import loginImage from '@/assets/icons/ar-logo.svg';

// 必须用函数式 alias 而非顶层读 i18n.global.t —— Rolldown manualChunks 拆分下，
// 业务 chunk 反向 import @/i18n 可能触发 ESM 循环 + TDZ，顶层访问 .global 会得到 undefined。
const t = (key: string): string => i18n.global.t(key);

/**
 * 全局配置读取 hook
 * 历史上从 import.meta.env.VITE_GLOB_XXX 读取；
 * 现在统一来自 src/config/runtime.ts 的 APP_CONFIG。
 * 对外签名不变，所有调用方零修改。
 */
export const useGlobSetting = () => ({
  apiUrl: '',
  uploadUrl: APP_CONFIG.uploadUrl,
  imgUrl: APP_CONFIG.imgUrl,
  urlPrefix: '',
  title: APP_CONFIG.title,
  shortName: '',
  prodMock: false,
});

const buildWebsiteConfig = () =>
  Object.freeze({
    title: 'AR',
    logo: loginImage,
    loginImage,
    get loginDesc() {
      return t('common.settings.website.loginDesc');
    },
  });

// 获取网站配置的函数
export const getWebsiteConfig = () => buildWebsiteConfig();

// 惰性导出：保持 `websiteConfig.xxx` 外部访问 API 不变；
// 但不要缓存翻译结果，避免 switchLocale 后仍读到旧文案。
export const websiteConfig = new Proxy({} as ReturnType<typeof buildWebsiteConfig>, {
  get(_, key: string | symbol) {
    const currentConfig = buildWebsiteConfig();
    return currentConfig[key as keyof ReturnType<typeof buildWebsiteConfig>];
  },
});

/**
 * 组件配置
 */
export const componentSetting = {
  table: {
    apiSetting: {
      // 当前页的字段名
      pageField: 'pageNo',
      // 每页数量字段名
      sizeField: 'pageSize',
      // 接口返回的数据字段名
      listField: 'list',
      // 接口返回总页数字段名
      totalField: 'totalPage',
      //总数字段名
      countField: 'totalCount',
    },
    //默认分页数量
    defaultPageSize: 20,
    //可切换每页数量集合
    pageSizes: [10, 20, 30, 50, 100, 200, 500],
  },
  upload: {
    //考虑接口规范不同
    apiSetting: {
      // 集合字段名
      infoField: 'data',
      // 图片地址字段名
      imgField: 'photo',
    },
    //最大上传图片大小
    maxSize: 2,
    //图片上传类型
    fileType: [
      'image/png',
      'image/jpg',
      'image/jpeg',
      'image/svg',
      'image/svg+xml',
      'image/gif',
      'image/webp',
    ],
  },
};

const defaultThemeColor = '#009688';

const brandColors = [
  '#2d8cf0',
  defaultThemeColor,
  '#0084f4',
  '#536dfe',
  '#ff5c93',
  '#ee4f12',
  '#0096c7',
  '#9c27b0',
  '#ff9800',
  '#FF3D68',
  '#00C1D4',
  '#71EFA3',
  '#171010',
  '#78DEC7',
  '#1768AC',
  '#FB9300',
  '#FC5404',
];

export const themeConfig = Object.freeze({
  defaultThemeColor,
  brandColors: [...brandColors],
});

/**
 * 外观配置默认值
 */
const defaultAppearanceSetting: ProjectAppearanceSetting = {
  themeColor: themeConfig.defaultThemeColor,
  themeScheme: 'light',
  grayscale: false,
  colorWeakness: false,
  compactMode: false,
  borderRadius: 8,
};

/**
 * 布局配置默认值
 */
const defaultLayoutSetting: ProjectLayoutSetting = {
  navigationMode: 'horizontal',
  navigationTheme: 'dark',
  mixMenu: false,
  menuWidth: 240,
  minMenuWidth: 64,
  mobileWidth: 800,
};

/**
 * 通用配置默认值
 */
const defaultGeneralSetting: ProjectGeneralSetting = {
  showReload: true,
  showTabs: true,
  fixedTabs: true,
  showBreadcrumb: true,
  showBreadcrumbIcon: false,
  syncThemeCssVars: true,
  syncDynamicFavicon: true,
};

/**
 * 预设配置默认值
 */
const defaultPresetSetting: ProjectPresetSetting = {
  activePreset: 'ar-default',
  lockPreset: false,
};

export const projectSetting = {
  /**
   * 外观配置
   */
  appearance: defaultAppearanceSetting,
  /**
   * 布局配置
   */
  layout: defaultLayoutSetting,
  /**
   * 通用配置
   */
  general: defaultGeneralSetting,
  /**
   * 预设配置
   */
  preset: defaultPresetSetting,
  //导航模式 vertical 左侧菜单模式 horizontal 顶部菜单模式
  navMode: defaultLayoutSetting.navigationMode,
  //导航风格 dark 暗色侧边栏 light 白色侧边栏 header-dark 暗色顶栏
  navTheme: defaultLayoutSetting.navigationTheme,
  // 是否处于移动端模式
  isMobile: false,
  //顶部
  headerSetting: {
    //显示重载按钮
    isReload: defaultGeneralSetting.showReload,
  },
  //多标签
  multiTabsSetting: {
    //是否显示
    show: defaultGeneralSetting.showTabs,
    //固定多标签
    fixed: defaultGeneralSetting.fixedTabs,
  },
  //菜单
  menuSetting: {
    //最小宽度
    minMenuWidth: defaultLayoutSetting.minMenuWidth,
    //菜单宽度
    menuWidth: defaultLayoutSetting.menuWidth,
    //分割菜单
    mixMenu: defaultLayoutSetting.mixMenu,
    //触发移动端侧边栏的宽度
    mobileWidth: defaultLayoutSetting.mobileWidth,
    // 折叠菜单
    collapsed: false,
  },
  //面包屑
  crumbsSetting: {
    //是否显示
    show: defaultGeneralSetting.showBreadcrumb,
    //显示图标
    showIcon: defaultGeneralSetting.showBreadcrumbIcon,
  },
};
