/**
 * @description 语言切换 Hook：暴露当前语言 / 语言下拉选项 / 切换动作。切换走 `switchLocale`（幂等重载已用 namespace + 同步 i18n / html lang），不再 `window.location.reload()`，因此所有依赖 `t()` 的页面级数据必须是 computed / reactive，才能在切换后立刻刷新。
 * @author
 * @date 2026-04-21
 * @scope 顶部导航栏语言切换、登录页语言切换
 */
import { computed, h, reactive, ref } from 'vue';
import { DEFAULT_LOCALE, switchLocale } from '@/i18n';
import { api } from '@/api';
import { useUserStore } from '@/store/modules/user';
import { storage } from '@/utils';
import { ACCESS_TOKEN, CURRENT_LANG } from '@/store/mutation-types';
import Zh from '@/assets/icons/languages/zh.png';
import En from '@/assets/icons/languages/en.png';
// import Vi from '@/assets/icons/languages/vi.png'; // 暂时移除：越南语
// import Id from '@/assets/icons/languages/id.png'; // 暂时移除：印尼语

export const useLang = () => {
  const currentLang = ref(storage.get(CURRENT_LANG) || DEFAULT_LOCALE);

  // 暂时只暴露 zh / en，保留 vi / id 在 SUPPORT_LOCALES 中以便已选用户的偏好不报错
  const localeList = reactive([
    {
      name: 'zh',
      label: '简体中文',
      icon: Zh,
      lang: 1,
    },
    {
      name: 'en',
      label: 'English',
      icon: En,
      lang: 2,
    },
    // {
    //   name: 'vi',
    //   label: 'Tiếng Việt',
    //   icon: Vi,
    //   lang: 3,
    // },
    // {
    //   name: 'id',
    //   label: 'Bahasa Indonesia',
    //   icon: Id,
    //   lang: 4,
    // },
  ]);

  const currentLangIcon = computed(
    () => localeList.find((item) => item.name === currentLang.value)?.icon,
  );

  const langOptions = computed(() =>
    localeList.map((item) => ({
      label: item.label,
      key: item.name,
      icon: () =>
        h('img', {
          src: item.icon,
          class: 'ml-4 w-[20px] h-[20px] mr-3 rounded-full',
        }),
    })),
  );

  const getLang = (locale: string) => {
    const lang = localeList.find((item) => item.name === locale);
    if (lang) {
      return {
        ...lang,
        icon: lang.icon,
      };
    }
    return null;
  };

  /**
   * 核心切换动作：持久化 → 重新加载所有 namespace → 更新 i18n locale + html lang。
   * 不再整页 reload，组件侧使用 computed 依赖 t() 即可在切换后自动更新。
   */
  const changeLang = async (locale: string) => {
    storage.set(CURRENT_LANG, locale);
    await switchLocale(locale);
    // 仅登录后才同步语言偏好到后端，登录页切换语言只做本地切换
    if (storage.get(ACCESS_TOKEN)) {
      const userStore = useUserStore();
      await api.system.changeLanguage().catch(() => {});
      await Promise.allSettled([
        userStore.initDictionaries(),
        // 平台字典仅在已加载过的会话里重刷，按需模块未进入时不主动拉取
        userStore.getPlatformDic ? userStore.loadPlatformDic() : Promise.resolve(),
      ]);
    }
  };

  const handleLang = async (key: string) => {
    await changeLang(key);
    currentLang.value = key;
  };

  return {
    getLang,
    handleLang,
    langOptions,
    localeList,
    changeLang,
    currentLang,
    currentLangIcon,
  };
};
