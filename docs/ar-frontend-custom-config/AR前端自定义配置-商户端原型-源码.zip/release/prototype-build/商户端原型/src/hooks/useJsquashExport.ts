const DEFAULT_QUALITY = 92;
export type JsquashMimeType = 'image/jpeg' | 'image/webp' | 'image/png';

type JsquashEncodeParams = {
  source: Blob;
  mimeType: JsquashMimeType;
  quality?: number | null;
};

let jpegModulePromise: Promise<typeof import('@jsquash/jpeg')> | null = null;
let webpModulePromise: Promise<typeof import('@jsquash/webp')> | null = null;
let oxipngModulePromise: Promise<typeof import('@jsquash/oxipng')> | null = null;

function clamp(value: number, min: number, max: number) {
  return Math.min(Math.max(value, min), max);
}

function normalizeQuality(value: number | null | undefined) {
  const raw = typeof value === 'number' && Number.isFinite(value) ? value : DEFAULT_QUALITY;
  return clamp(Math.round(raw), 1, 100);
}

async function loadJpegModule() {
  jpegModulePromise ??= import('@jsquash/jpeg');
  return await jpegModulePromise;
}

async function loadWebpModule() {
  webpModulePromise ??= import('@jsquash/webp');
  return await webpModulePromise;
}

async function loadOxipngModule() {
  oxipngModulePromise ??= import('@jsquash/oxipng');
  return await oxipngModulePromise;
}

async function blobToImageData(source: Blob): Promise<ImageData> {
  if (typeof createImageBitmap === 'function') {
    const bitmap = await createImageBitmap(source);
    try {
      const canvas = document.createElement('canvas');
      canvas.width = Math.max(bitmap.width, 1);
      canvas.height = Math.max(bitmap.height, 1);
      const context = canvas.getContext('2d', { willReadFrequently: true });
      if (!context) {
        throw new Error('Canvas 2D context is unavailable.');
      }
      context.drawImage(bitmap, 0, 0);
      return context.getImageData(0, 0, canvas.width, canvas.height);
    } finally {
      bitmap.close?.();
    }
  }

  const objectUrl = URL.createObjectURL(source);
  try {
    const imageElement = await new Promise<HTMLImageElement>((resolve, reject) => {
      const image = new Image();
      image.onload = () => resolve(image);
      image.onerror = () => reject(new Error('Failed to decode image blob.'));
      image.src = objectUrl;
    });

    const canvas = document.createElement('canvas');
    canvas.width = Math.max(imageElement.naturalWidth, 1);
    canvas.height = Math.max(imageElement.naturalHeight, 1);
    const context = canvas.getContext('2d', { willReadFrequently: true });
    if (!context) {
      throw new Error('Canvas 2D context is unavailable.');
    }
    context.drawImage(imageElement, 0, 0);
    return context.getImageData(0, 0, canvas.width, canvas.height);
  } finally {
    URL.revokeObjectURL(objectUrl);
  }
}

async function encodeWithQuality(
  imageData: ImageData,
  mimeType: 'image/jpeg' | 'image/webp',
  quality: number,
): Promise<Blob> {
  if (mimeType === 'image/jpeg') {
    const { encode } = await loadJpegModule();
    const encodedBuffer = await encode(imageData, { quality });
    return new Blob([encodedBuffer], { type: 'image/jpeg' });
  }

  const { encode } = await loadWebpModule();
  const encodedBuffer = await encode(imageData, { quality });
  return new Blob([encodedBuffer], { type: 'image/webp' });
}

async function optimisePng(source: Blob) {
  const { optimise } = await loadOxipngModule();
  const sourceBuffer = await source.arrayBuffer();
  const outputBuffer = await optimise(sourceBuffer, {
    level: 2,
  });
  return new Blob([outputBuffer], { type: 'image/png' });
}

/**
 * 使用 jSquash 按导出格式自动懒加载对应编码器。
 * - JPEG: @jsquash/jpeg
 * - WebP: @jsquash/webp
 * - PNG: @jsquash/oxipng
 */
export async function encodeImageWithJsquash({
  source,
  mimeType,
  quality,
}: JsquashEncodeParams): Promise<Blob> {
  if (mimeType === 'image/png') {
    return await optimisePng(source);
  }

  const imageData = await blobToImageData(source);
  const normalizedQuality = normalizeQuality(quality);
  return await encodeWithQuality(imageData, mimeType, normalizedQuality);
}
