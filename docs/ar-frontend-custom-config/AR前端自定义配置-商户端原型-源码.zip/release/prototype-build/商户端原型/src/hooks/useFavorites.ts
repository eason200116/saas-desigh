import { ref } from 'vue';

// ============ 类型定义 ============
export interface FavoriteItem {
  path: string;
  name: string;
  title: string;
}

export interface FavoriteRecord {
  id: string;
  items: FavoriteItem[];
  updatedAt: number;
}

// ============ IndexedDB 存储 ============
const DB_NAME = 'FavoritesDB';
const DB_VERSION = 1;
const STORE_NAME = 'favorites';

let dbInstance: IDBDatabase | null = null;

function initDB(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (dbInstance) {
      resolve(dbInstance);
      return;
    }

    const request = indexedDB.open(DB_NAME, DB_VERSION);

    request.onerror = () => {
      console.error('FavoritesDB 打开失败:', request.error);
      reject(request.error);
    };

    request.onsuccess = () => {
      dbInstance = request.result;
      resolve(dbInstance);
    };

    request.onupgradeneeded = (event) => {
      const db = (event.target as IDBOpenDBRequest).result;
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        db.createObjectStore(STORE_NAME, { keyPath: 'id' });
      }
    };
  });
}

async function withStore<T>(
  mode: IDBTransactionMode,
  callback: (store: IDBObjectStore) => IDBRequest<T>,
): Promise<T> {
  const db = await initDB();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction(STORE_NAME, mode);
    const store = transaction.objectStore(STORE_NAME);
    const request = callback(store);

    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

export async function loadFavoritesFromDB(userId: string): Promise<FavoriteItem[]> {
  const result = await withStore<FavoriteRecord | undefined>('readonly', (store) =>
    store.get(userId),
  );
  return result?.items ?? [];
}

export async function saveFavoritesToDB(userId: string, items: FavoriteItem[]): Promise<void> {
  const record: FavoriteRecord = {
    id: userId,
    items: items.map(({ path, name, title }) => ({ path, name, title })),
    updatedAt: Date.now(),
  };
  await withStore('readwrite', (store) => store.put(record));
}

// ============ Composable ============
const favorites = ref<FavoriteItem[]>([]);
let currentUserId: string | null = null;

export function useFavorites() {
  async function loadFavorites(userId: string) {
    currentUserId = userId;
    try {
      favorites.value = await loadFavoritesFromDB(userId);
    } catch (e) {
      console.error('加载收藏列表失败:', e);
      favorites.value = [];
    }
  }

  async function persist() {
    if (!currentUserId) return;
    try {
      await saveFavoritesToDB(currentUserId, favorites.value);
    } catch (e) {
      console.error('保存收藏列表失败:', e);
    }
  }

  function addFavorite(route: { fullPath: string; name: string; meta: { title?: string } }) {
    const exists = favorites.value.some((item) => item.path === route.fullPath);
    if (exists) return;

    favorites.value = [
      ...favorites.value,
      {
        path: route.fullPath,
        name: route.name as string,
        title: (route.meta?.title as string) || route.name,
      },
    ];
    persist();
  }

  function removeFavorite(path: string) {
    favorites.value = favorites.value.filter((item) => item.path !== path);
    persist();
  }

  function isFavorite(path: string): boolean {
    return favorites.value.some((item) => item.path === path);
  }

  return {
    favorites,
    loadFavorites,
    addFavorite,
    removeFavorite,
    isFavorite,
  };
}
