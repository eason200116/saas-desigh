/**
 * 原型项目：权限 hook 降级，所有判断返回 true。
 */
export function usePermission() {
  function hasPermission(_accesses?: string[]): boolean {
    return true;
  }

  function hasEveryPermission(_accesses?: string[]): boolean {
    return true;
  }

  function hasSomePermission(_accesses?: string[]): boolean {
    return true;
  }

  function hasFirstPermission(accesses?: string[]): string | undefined {
    return accesses?.[0];
  }

  return { hasPermission, hasEveryPermission, hasSomePermission, hasFirstPermission };
}
