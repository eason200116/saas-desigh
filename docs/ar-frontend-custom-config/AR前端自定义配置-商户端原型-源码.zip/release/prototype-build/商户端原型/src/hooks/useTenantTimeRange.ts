/**
 * @description 列表页商户时区时间通用 hook：统一「读搜索区商户 → 单元格格式化 → 时间范围 UTC 转换」三件事，避免在多个页面重复手写。
 * @author Shaba River
 * @date 2026-04-18
 * @scope 入款记录、本地待入款、后续 withdrawOrder 等带商户时区时间列的 ProCrudTable 列表页。
 */
import { unref, type ComputedRef, type Ref } from 'vue';
import type { ProCrudTableInstance, Recordable } from '@/components';
import { useTenantOptions } from './useTenantOptions';

export interface UseTenantTimeRangeOptions {
  /** ProCrudTable 实例引用，用于即时读取搜索区参数 */
  tableRef: Ref<ProCrudTableInstance<Recordable> | null>;
  /** 搜索区未选中商户时的回退值，通常传 useTenantOptions().defaultTenantId */
  defaultTenantId?: Ref<number | null | undefined> | ComputedRef<number | null | undefined>;
  /** 搜索区商户字段名，规范 §6.2 方式二自定义来源时使用，默认 'tenantId' */
  searchTenantIdKey?: string;
  /** 单元格格式化默认模板，默认 'yyyy-MM-dd HH:mm:ss' */
  format?: string;
  /** 无值时的占位文本，默认 '----' */
  fallback?: string;
}

export interface UseTenantTimeRangeReturn {
  /** 读当前搜索区商户 id（按 searchTenantIdKey + defaultTenantId 回退） */
  getSearchTenantId: () => number | undefined;
  /** 单元格 render 使用：按当前搜索商户时区输出字符串 */
  formatSearchTenantDateTime: (value: unknown, overrideFormat?: string) => string;
  /** 单值转换：picker 本地 wall-clock ms → 商户时区真 UTC ms */
  toTenantUtcMs: (value: unknown) => number | undefined;
  /**
   * 批量转换时间范围为 UTC 请求对象，配合对象扩展使用：
   *   ...(toTenantUtcRange(params.timeRange, 'startTime', 'endTime') ?? {})
   * 若 range 为空/非法，返回 undefined
   */
  toTenantUtcRange: <S extends string, E extends string>(
    range: unknown,
    startKey: S,
    endKey: E,
  ) => Partial<Record<S | E, number>> | undefined;
}

function normalizeTenantId(value: unknown): number | undefined {
  if (value == null || value === '') return undefined;
  const numericValue = Number(value);
  return Number.isFinite(numericValue) ? numericValue : undefined;
}

export function useTenantTimeRange(options: UseTenantTimeRangeOptions): UseTenantTimeRangeReturn {
  const { formatTenantDateTime, toTenantUtcTimestamp } = useTenantOptions();
  const {
    tableRef,
    defaultTenantId,
    searchTenantIdKey = 'tenantId',
    format: defaultFormat = 'yyyy-MM-dd HH:mm:ss',
    fallback = '----',
  } = options;

  function getSearchTenantId(): number | undefined {
    const searchParams = tableRef.value?.getSearchParams?.();
    return (
      normalizeTenantId(searchParams?.[searchTenantIdKey]) ??
      normalizeTenantId(unref(defaultTenantId))
    );
  }

  function formatSearchTenantDateTime(value: unknown, overrideFormat?: string): string {
    return formatTenantDateTime(
      value as Parameters<typeof formatTenantDateTime>[0],
      getSearchTenantId(),
      overrideFormat ?? defaultFormat,
      fallback,
    );
  }

  function toTenantUtcMs(value: unknown): number | undefined {
    return (
      toTenantUtcTimestamp(
        value as Parameters<typeof toTenantUtcTimestamp>[0],
        getSearchTenantId(),
      ) ?? undefined
    );
  }

  function toTenantUtcRange<S extends string, E extends string>(
    range: unknown,
    startKey: S,
    endKey: E,
  ): Partial<Record<S | E, number>> | undefined {
    if (!Array.isArray(range) || range.length !== 2) return undefined;
    const startMs = toTenantUtcMs(range[0]);
    const endMs = toTenantUtcMs(range[1]);
    if (startMs == null && endMs == null) return undefined;
    const result: Partial<Record<S | E, number>> = {};
    if (startMs != null) result[startKey] = startMs;
    if (endMs != null) result[endKey] = endMs;
    return result;
  }

  return {
    getSearchTenantId,
    formatSearchTenantDateTime,
    toTenantUtcMs,
    toTenantUtcRange,
  };
}
