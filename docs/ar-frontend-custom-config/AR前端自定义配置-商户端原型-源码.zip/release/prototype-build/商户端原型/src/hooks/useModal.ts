import { ref, h } from 'vue';
import type { Component, VNodeChild } from 'vue';
import { NButton, NIcon, useModal, useMessage } from 'naive-ui';
import { FullscreenOutlined, FullscreenExitOutlined } from '@vicons/antd';

/**
 * 公共 modal 打开辅助。
 *
 * 当前保留两套能力：
 * - openModal: 兼容既有页面的 card modal 打开方式
 * - openCardModal: 新增的 card modal 提交态控制能力
 *
 * 推荐场景：
 * - 旧页面继续使用 openModal，不做破坏式迁移
 * - 新页面或体验优化页优先使用 openCardModal，在页面层统一控制提交中禁关
 */
export interface ModalOptions {
  width?: string;
  title?: string;
  zIndex?: number;
}

export interface CardModalOptions {
  title?: string;
  width?: string;
  zIndex?: number;
  closable?: boolean;
  maskClosable?: boolean;
  closeOnEsc?: boolean;
  /**
   * 内容渲染函数。
   * destroy: 主动关闭弹窗
   * setSubmitting: 切换提交态，提交中会禁用 card modal 的关闭入口
   */
  content: (helpers: {
    destroy: () => void;
    setSubmitting: (submitting: boolean) => void;
  }) => VNodeChild;
  /**
   * 弹窗退场动画完全结束后触发；覆盖关闭按钮 / X / Esc / 遮罩 / 主动 destroy 全部路径。
   * 用途：当 modal 被嵌套在 NPopover 等需要锁定 clickoutside 的容器内时，
   * 需要在确认 modal 彻底离开 DOM 后再解锁，避免触发外层 clickoutside 关闭。
   */
  onAfterLeave?: () => void;
}

export function useModalHelper() {
  const modal = useModal();
  const message = useMessage();

  function openModal(
    component: Component,
    props: Record<string, any> = {},
    options: ModalOptions = {},
  ) {
    const isFullscreen = ref(false);
    const defaultWidth = options.width || '500px';
    let inst: any;

    function toggle() {
      isFullscreen.value = !isFullscreen.value;
      inst.style = isFullscreen.value
        ? { width: '100vw', height: '100vh', maxWidth: '100vw', margin: 0, borderRadius: 0 }
        : { width: defaultWidth };
      inst.contentStyle = isFullscreen.value
        ? { maxHeight: 'calc(100vh - 60px)', overflow: 'auto' }
        : { maxHeight: '90vh', overflow: 'auto' };
    }

    inst = modal.create({
      preset: 'card',
      bordered: false,
      closable: true,
      maskClosable: true,
      zIndex: options.zIndex,
      style: { width: defaultWidth },
      contentStyle: { maxHeight: '90vh', overflow: 'auto' },
      title: () =>
        h('div', { style: 'display: flex; align-items: center; gap: 8px;' }, [
          h('span', null, options.title || ''),
          h(
            NButton,
            { quaternary: true, circle: true, size: 'small', onClick: toggle },
            {
              icon: () =>
                h(NIcon, { size: 16 }, () =>
                  h(isFullscreen.value ? FullscreenExitOutlined : FullscreenOutlined),
                ),
            },
          ),
        ]),
      content: () =>
        h(component, {
          ...props,
          onClose: () => inst.destroy(),
          onSave: (...args: any[]) => {
            if (props?.onSave) props.onSave(...args);
            message.success('保存成功');
            inst.destroy();
          },
        }),
    });

    return inst;
  }

  function openCardModal(options: CardModalOptions) {
    const defaultWidth = options.width || '500px';
    const baseClosable = options.closable ?? true;
    const baseMaskClosable = options.maskClosable ?? false;
    const baseCloseOnEsc = options.closeOnEsc ?? true;
    let inst: any;

    // 统一 card modal 的提交中交互，避免页面重复手写 closable / esc / mask 控制。
    function setSubmitting(submitting: boolean) {
      if (!inst) return;
      inst.closable = submitting ? false : baseClosable;
      inst.maskClosable = submitting ? false : baseMaskClosable;
      inst.closeOnEsc = submitting ? false : baseCloseOnEsc;
    }

    inst = modal.create({
      preset: 'card',
      title: options.title,
      bordered: false,
      closable: baseClosable,
      maskClosable: baseMaskClosable,
      closeOnEsc: baseCloseOnEsc,
      zIndex: options.zIndex,
      style: { width: defaultWidth },
      content: () =>
        options.content({
          destroy: () => inst.destroy(),
          setSubmitting,
        }),
      onAfterLeave: options.onAfterLeave,
    });

    return {
      inst,
      destroy: () => inst.destroy(),
      setSubmitting,
    };
  }

  return { openModal, openCardModal, message };
}
