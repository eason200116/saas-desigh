import { inject, provide, ref, type InjectionKey, type Ref } from 'vue';
import { useI18n } from 'vue-i18n';
import { useUserStore } from '@/store/modules/user';
import { useDictionary } from '@/components/DictSelect/useDictionary';
import type { SelectOption } from '@/components/DictSelect/useDictionary';
import { useMessage } from 'naive-ui';
import { api } from '@/api';
import { useMemberDetailModal } from './useMemberDetailModal';

/**
 * 用法：在跨商户上下文（如 MemberDetailShell）的 setup 内调用 provideTenantOverride
 */
const TENANT_OVERRIDE_KEY: InjectionKey<Ref<number | string | null | undefined>> =
  Symbol('useUser:tenantOverride');

/**
 * 在跨商户场景注入"覆盖 tenantId"。
 */
export function provideTenantOverride(tenantIdRef: Ref<number | string | null | undefined>) {
  provide(TENANT_OVERRIDE_KEY, tenantIdRef);
}

/**
 * 独立接口枚举缓存（按 tenantId 缓存，避免重复请求）
 * 这三个枚举从独立接口获取，不走字典
 * 后期如果合并回字典，只需删除此处逻辑，改回 getOptions 即可
 */
const enumCache = new Map<
  string,
  { channelList: SelectOption[]; vipLevelList: SelectOption[]; userGroupList: SelectOption[] }
>();
const channelListRef = ref<SelectOption[]>([]);
const vipLevelListRef = ref<SelectOption[]>([]);
const userGroupListRef = ref<SelectOption[]>([]);

// 会员最后提现时间缓存（按 memberId）
const lastWithdrawTimeCache = new Map<string, string>();

async function loadEnumsByTenant(tenantId?: number) {
  const key = String(tenantId ?? '');
  if (enumCache.has(key)) {
    const cached = enumCache.get(key)!;
    channelListRef.value = cached.channelList;
    vipLevelListRef.value = cached.vipLevelList;
    userGroupListRef.value = cached.userGroupList;
    return;
  }
  try {
    const params = { tenantId };
    const [channelRaw, vipRaw, groupRaw] = await Promise.all([
      api.v1platform.getChannelList(params).catch(() => ({ data: [] })),
      api.v1platform.getVipLevelList(params).catch(() => ({ data: [] })),
      api.v1platform.getUserGroupList(params).catch(() => ({ data: [] })),
    ]);
    const toOptions = (data: any[], labelField = 'name', valueField = 'id'): SelectOption[] =>
      (data || []).map((item) => ({
        label: String(item[labelField] ?? ''),
        value: item[valueField],
      }));

    // 渠道列表：label 用 name 显示，value 用 code（渠道ID）传参
    channelListRef.value = toOptions(channelRaw?.data ?? [], 'name', 'code');
    vipLevelListRef.value = toOptions(vipRaw?.data ?? []);
    userGroupListRef.value = toOptions(groupRaw?.data ?? []);

    enumCache.set(key, {
      channelList: channelListRef.value,
      vipLevelList: vipLevelListRef.value,
      userGroupList: userGroupListRef.value,
    });
  } catch (e) {
    console.error('加载枚举列表失败', e);
  }
}

export function useUser() {
  const message = useMessage();
  const { openMemberDetail, openBettingOrderDetail } = useMemberDetailModal();
  const { t } = useI18n();
  const userStore = useUserStore();
  const {
    getOptions: _dictGetOptions,
    findLabel: _dictFindLabel,
    getOptionMap: _dictGetOptionMap,
  } = useDictionary({ source: 'v1' });

  const tenantOverride = inject(TENANT_OVERRIDE_KEY, null);
  const getTenantId = () => {
    const overridden = tenantOverride?.value;
    if (overridden != null && overridden !== '') return Number(overridden);
    return userStore.getActiveTenantId ?? userStore.info?.tenantList?.[0]?.id;
  };

  // 首次调用时加载独立接口枚举
  loadEnumsByTenant(getTenantId());

  // 独立接口枚举 key 映射
  const ENUM_KEYS = {
    channelList: channelListRef,
    vipLevelList: vipLevelListRef,
    userGroupList: userGroupListRef,
  };

  /**
   * 获取选项列表
   * channelList/vipLevelList/userGroupList 从独立接口获取
   * 其余从 v1 字典获取
   */
  const getOptions = (key: string, config: any = {}): SelectOption[] => {
    if (key in ENUM_KEYS) return ENUM_KEYS[key].value;
    return _dictGetOptions(key, config);
  };

  const findLabel = (key: string, value: any, config: any = {}): string => {
    if (key in ENUM_KEYS) {
      const opt = ENUM_KEYS[key].value.find((o) => o.value === value);
      return opt?.label ?? String(value ?? '');
    }
    return _dictFindLabel(key, value, config);
  };

  const getOptionMap = (key: string, config: any = {}) => {
    if (key in ENUM_KEYS) {
      return new Map(ENUM_KEYS[key].value.map((o) => [o.value, o]));
    }
    return _dictGetOptionMap(key, config);
  };

  // ============ 时间解析工具 ============

  /**
   * 解析后端时间字符串为时间戳
   * 兼容 "2026/2/10 16:25:13"、"2026-2-10 16:25:13"、"2026-02-10" 等格式
   * @returns 时间戳(ms) 或 null
   */
  const parseTimeStr = (v: string | number | Date | null | undefined): number | null => {
    if (v == null) return null;
    if (v instanceof Date) return isNaN(v.getTime()) ? null : v.getTime();
    if (typeof v === 'number') return v;
    const normalized = String(v).replace(/\//g, '-');
    const match = normalized.match(
      /^(\d{4})-(\d{1,2})-(\d{1,2})(?:\s+(\d{1,2}):(\d{1,2}):(\d{1,2}))?/,
    );
    if (!match) return null;
    const [, y, m, d2, h = '0', mi = '0', s = '0'] = match;
    const d = new Date(+y, +m - 1, +d2, +h, +mi, +s);
    return isNaN(d.getTime()) ? null : d.getTime();
  };

  /**
   * 将时间值格式化为 yyyy-MM-dd HH:mm:ss 字符串
   * 支持时间戳、Date、字符串输入
   */
  const formatDateTimeStr = (v: string | number | Date | null | undefined): string | undefined => {
    if (v == null) return undefined;
    // 字符串输入：尝试直接解析
    if (typeof v === 'string' && /^\d{4}[-/]/.test(v)) {
      const normalized = v.replace(/\//g, '-');
      const match = normalized.match(
        /^(\d{4})-(\d{1,2})-(\d{1,2})(?:\s+(\d{1,2}):(\d{1,2}):(\d{1,2}))?/,
      );
      if (match) {
        const [, y, m, d2, h = '0', mi = '0', s = '0'] = match;
        return `${y}-${m.padStart(2, '0')}-${d2.padStart(2, '0')} ${h.padStart(2, '0')}:${mi.padStart(2, '0')}:${s.padStart(2, '0')}`;
      }
    }
    const d = v instanceof Date ? v : new Date(v);
    if (isNaN(d.getTime())) return undefined;
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')} ${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}:${String(d.getSeconds()).padStart(2, '0')}`;
  };

  /**
   * 设置指定会员的最后提现时间
   */
  const setLastWithdrawTime = (memberId: string | number, val: string) => {
    lastWithdrawTimeCache.set(String(memberId), val || '');
  };

  /**
   * 获取指定会员的最后提现时间
   */
  const getLastWithdrawTime = (memberId: string | number): string => {
    return lastWithdrawTimeCache.get(String(memberId)) || '';
  };

  // ============ 会员接口请求封装 ============

  /**
   * 获取会员详情
   * @param params.tenantId 嵌入弹窗时传订单商户，未传 fallback 到 getTenantId()
   */
  const fetchMemberDetail = async (
    userId: number | string,
    params?: { startTime?: string; endTime?: string; tenantId?: number | null },
  ) => {
    const tenantId = params?.tenantId ?? getTenantId();
    const reqParams: any = { userId: Number(userId), tenantId };
    if (params?.startTime) reqParams.startTime = params.startTime;
    if (params?.endTime) reqParams.endTime = params.endTime;
    const { data } = await api.v1platform.getUserDetail(reqParams);
    if (data?.lastWithdrawTime) {
      setLastWithdrawTime(userId, data.lastWithdrawTime);
    }
    return data;
  };

  /**
   * 获取会员钱包信息
   * @param tenantIdOverride 嵌入到出款详情等弹窗时传入订单商户，覆盖默认激活商户
   */
  const fetchWalletInfo = async (userId: number | string, tenantIdOverride?: number | null) => {
    const tenantId = tenantIdOverride ?? getTenantId();
    const { data } = await api.v1platform.getUserWalletInfo({ userId: Number(userId), tenantId });
    return data;
  };

  /**
   * 修改会员备注
   * @param tenantIdOverride 嵌入弹窗时传入订单商户
   */
  const updateMemberRemark = async (
    userId: number | string,
    remark: string,
    tenantIdOverride?: number | null,
  ) => {
    return api.v1platform.usersUpdateRemark({
      userId: Number(userId),
      remark,
      tenantId: tenantIdOverride ?? getTenantId(),
    });
  };

  /**
   * 修改会员打码量
   * @param tenantIdOverride 嵌入弹窗时传入订单商户
   */
  const updateMemberBetAmount = async (
    userId: number | string,
    amountofCode: number,
    tenantIdOverride?: number | null,
  ) => {
    return api.v1platform.updateActualCoding({
      userId: Number(userId),
      amountofCode,
      tenantId: tenantIdOverride ?? getTenantId(),
    });
  };

  /**
   * 修改会员状态
   * @param tenantIdOverride 嵌入弹窗时传入订单商户
   */
  const updateMemberState = async (
    userId: number | string,
    state: number,
    tenantIdOverride?: number | null,
  ) => {
    return api.v1platform.setBatchUserState({
      userIds: [Number(userId)],
      state,
      tenantId: tenantIdOverride ?? getTenantId(),
    });
  };

  /**
   * 修改会员积分（源站 updateintegral 权限）
   * @param tenantIdOverride 嵌入弹窗时传入订单商户
   */
  const updateMemberIntegral = async (
    userId: number | string,
    integral: number,
    tenantIdOverride?: number | null,
  ) => {
    return api.v1platform.setUserIntegral({
      userId: Number(userId),
      integral,
      tenantId: tenantIdOverride ?? getTenantId(),
    });
  };

  /**
   * 修改账变备注
   * @param tenantIdOverride 嵌入弹窗时传入订单商户
   */
  const updateFinanceRemark = async (
    finanID: number,
    remark: string,
    tenantIdOverride?: number | null,
  ) => {
    return api.v1platform.financeUpdateRemark({
      finanID,
      remark,
      tenantId: tenantIdOverride ?? getTenantId(),
    });
  };

  /**
   * 获取会员投注统计
   * params.tenantId 优先（嵌入弹窗时传订单商户）；未传时 fallback 到 getTenantId()
   */
  const fetchUserBetTotal = async (params: {
    userId: number | string;
    tenantId?: number | null;
    startTime?: string;
    endTime?: string;
    sinceLastWithdraw?: boolean;
    pageNo?: number;
    pageSize?: number;
    sortField?: string;
    orderBy?: string;
  }) => {
    const reqParams: any = {
      userId: Number(params.userId),
      tenantId: params.tenantId ?? getTenantId(),
      pageNo: params.pageNo ?? 1,
      pageSize: params.pageSize ?? 10,
      orderBy: params.orderBy ?? 'Desc',
    };
    if (params.startTime) reqParams.startTime = params.startTime;
    if (params.endTime) reqParams.endTime = params.endTime;
    if (params.sinceLastWithdraw) reqParams.sinceLastWithdraw = true;
    if (params.sortField) reqParams.sortField = params.sortField;
    const { data } = await api.v1platform.getUserBetTotal(reqParams);
    return data;
  };

  /**
   * 获取账变记录分页
   */
  const fetchFinanceRecordPageList = async (params: any) => {
    const reqParams = { tenantId: getTenantId(), ...params };
    const { data } = await api.v1platform.getFinanceRecordPageList(reqParams);
    return data;
  };

  /**
   * 账变记录导出接口：返回原始 blob 响应，下载交由调用方处理。
   * 不在此内联 downloadApiResponse——消费方统一走 useTableExport（其内部已调 downloadApiResponse），
   * 若此处再包一层会形成双重下载：文件已落地，但外层对 undefined 取 .data 抛错，导致「下载成功却误报失败」。
   */
  const exportFinanceRecord = (params: any) =>
    api.v1platform.getFinanceRecordPageListExport(params);

  /**
   * 获取操作日志分页
   * params.tenantId 优先（嵌入弹窗时传订单商户）；未传时 fallback 到 getTenantId()
   */
  const fetchWebLogPageList = async (params: any) => {
    const reqParams = { tenantId: getTenantId(), ...params };
    const { data } = await api.v1platform.getWebLogPageList(reqParams);
    return data;
  };

  /**
   * 获取下级会员列表分页
   */
  const fetchSubsetUserPageList = async (params: any) => {
    // 否则用户在页面切换商户后，请求依旧会被 getTenantId() 强制改回当前激活商户
    const reqParams = { tenantId: getTenantId(), ...params };
    const { data } = await api.v1platform.getSubsetUserPageList(reqParams);
    return data;
  };

  /**
   * 获取游戏大类（厂商）列表
   * @param tenantIdOverride 嵌入弹窗时传订单商户
   */
  const fetchGameCategoryList = async (categoryType: number, tenantIdOverride?: number | null) => {
    const { data } = await api.v1platform.getGameCategoryList({
      category: categoryType,
      tenantId: tenantIdOverride ?? getTenantId(),
    });
    return (data || []).map((v) => ({ label: v.vendorName, value: v.vendorCode }));
  };

  /**
   * 获取子游戏列表
   * @param tenantIdOverride 嵌入弹窗时传订单商户
   */
  const fetchGameList = async (vendorCode: string, tenantIdOverride?: number | null) => {
    const { data } = await api.v1platform.getGameList({
      vendorCode,
      tenantId: tenantIdOverride ?? getTenantId(),
    });
    return (data || []).map((g) => ({ label: g.gameName, value: g.gameCode }));
  };

  /**
   * 获取彩票类型选项（彩种类型 / 期号类型）
   * @param tenantIdOverride 嵌入弹窗时传订单商户
   */
  const fetchLotteryIssueTypes = async (
    isNewLottery: boolean,
    lotteryCategory?: number | null,
    tenantIdOverride?: number | null,
  ) => {
    const tenantId = tenantIdOverride ?? getTenantId();
    let data: any[];
    if (isNewLottery) {
      const res = await api.v1platform.getLotteryGameCategoryList({ tenantId });
      data = res.data || [];
    } else if (lotteryCategory) {
      const apiFnMap = {
        1: api.v1platform.getGameIssueTypeWinList,
        2: api.v1platform.getGameIssueType5DList,
        3: api.v1platform.getGameIssueTypeK3List,
        4: api.v1platform.getGameIssueTypeTrxWinList,
      };
      const fn = apiFnMap[lotteryCategory];
      if (!fn) return [];
      const res = await fn({ tenantId });
      data = res.data || [];
    } else {
      return [];
    }
    // 新彩种 / 普通彩种均使用 id 作为选项值，接口统一通过 TypeId 过滤
    return data.map((item) => ({
      label: item.name,
      value: item.id,
    }));
  };

  const openMemberDetailModal = (
    memberId: string | number,
    tenantId: number | string,
    tenantLabel?: string | null,
  ) => {
    openMemberDetail(memberId, tenantId, tenantLabel);
  };

  const openBettingOrderDetailModal = (row: Record<string, string | number | null | undefined>) => {
    openBettingOrderDetail(
      {
        gameType: row.gameType,
        memberId: row.memberId,
        // 会员/订单所属商户，用于嵌入投注详情弹窗时锁定搜索表单的商户
        tenantId: row.tenantId,
        subGameName: row.subGameName,
        subGameId: row.subGameId,
        vendorCode: row.vendorCode,
        gameCategory: row.gameCategory,
        categoryType: row.categoryType,
        lotteryGameType: row.lotteryGameType,
        startTime: row.startTime,
        endTime: row.endTime,
      },
      t('member.detail.bettingOrder.detailTitle', {
        name: row.subGameName || row.gameType,
      }),
    );
  };

  return {
    message,
    getTenantId,
    getOptions,
    findLabel,
    getOptionMap,
    openMemberDetailModal,
    openBettingOrderDetailModal,
    // 时间解析工具
    parseTimeStr,
    formatDateTimeStr,
    // lastWithdrawTime 缓存
    setLastWithdrawTime,
    getLastWithdrawTime,
    // 会员接口请求
    fetchMemberDetail,
    fetchWalletInfo,
    updateMemberRemark,
    updateMemberBetAmount,
    updateMemberState,
    updateMemberIntegral,
    updateFinanceRemark,
    fetchUserBetTotal,
    fetchFinanceRecordPageList,
    exportFinanceRecord,
    fetchWebLogPageList,
    fetchSubsetUserPageList,
    // 游戏相关接口
    fetchGameCategoryList,
    fetchGameList,
    fetchLotteryIssueTypes,
  };
}
