/**
 * @description ProCrudTable 列表导出公开 hook：页面在 #table-header 插槽自渲染导出按钮，
 * 调用本 hook 拿到 { exportLoading, handleExport }。按 tableRef 暴露的「显隐+排序后列」自动拼
 * exportTitle（所见即所得），合并导出标志后走 downloadApiResponse；承载时区、loading、错误处理。
 * 权限不在此处理：由页面按钮上的 v-permission 指令控制显隐。
 */
import { ref, type Ref } from 'vue';
import { useI18n } from 'vue-i18n';
import { useMessage } from 'naive-ui';
import { downloadApiResponse, ExportError } from '@/utils/downloadFile';
import { parseTimeOffset } from '@/utils/dateUtil';
import type { ProColumn, ProCrudTableInstance, CrudRequestParams, Recordable } from '@/components';
import { useTenantOptions } from './useTenantOptions';

/** 页面侧导出配置（auth 不在此声明，改由按钮 v-permission 指令控制显隐） */
export interface UseTableExportOptions {
  /** ...Export API 方法；返回原始响应 promise，交给 downloadApiResponse */
  request: (params: Recordable) => Promise<unknown>;
  /** 导出文件名（i18n 文案）；传 getter 可随语言切换保持响应式 */
  fileName: string | (() => string);
  /**
   * 复用页面列表查询参数构建器。
   * 省略时回退复用表格 `beforeRequest`（列表与导出共用一份参数构建，即 tableRef.resolveRequestParams）；
   * 两者都没有时直接用原始搜索参数。
   */
  buildParams?: (searchParams: CrudRequestParams) => Recordable | Promise<Recordable>;
  /** 导出条数上限，默认 10000 */
  pageSize?: number;
  /** 时区小时偏移覆盖；省略则按 tenantId 解析 */
  exportTimeZone?: number;
}

/** 列标题转字符串：string 直接取；VNode 函数取 columnSettingTitle；都无则空串（跳过该列） */
function resolveColumnTitle(col: ProColumn<Recordable>): string {
  if (typeof col.title === 'string') return col.title;
  if (col.columnSettingTitle) return col.columnSettingTitle;
  return '';
}

/**
 * 按列顺序遍历构建 exportTitle 映射：后端字段名 → 列标题（带时区后缀）。
 */
function buildExportTitle(
  columns: ProColumn<Recordable>[],
  tzLabel: string,
): Record<string, string> {
  const title: Record<string, string> = {};

  /** 如果该列开启了时区展示，则在标题后追加时区标签 */
  const withTz = (label: string, col: ProColumn<Recordable>) =>
    col.showTenantTimeZone && tzLabel ? `${label}(${tzLabel})` : label;

  for (const col of columns) {
    // 「自定义列」隐藏的列不导出（settledColumns 保留隐藏列并打 hideInTable 标记，需在此跳过）
    if (col.hideInTable === true) continue;
    const meta = col.export;
    if (meta === false) continue;

    // 复合/嵌套列：拆成多列写入
    if (Array.isArray(meta)) {
      for (const entry of meta) {
        const entryTitle = entry.title ?? resolveColumnTitle(col);
        if (!entryTitle) continue;
        title[entry.key] = withTz(entryTitle, col);
      }
      continue;
    }

    const colTitle = resolveColumnTitle(col);
    if (!colTitle) continue;

    if (typeof meta === 'string') {
      // 后端字段名与列 key 不一致时，用 meta 作为真实字段名
      title[meta] = withTz(colTitle, col);
    } else {
      // meta 省略，用 dataIndex 或 key 作为字段名
      const key = String(col.dataIndex ?? col.key);
      title[key] = withTz(colTitle, col);
    }
  }
  return title;
}

/** 导出最小 loading 时长（ms）：极快返回时补足，避免 loading 闪烁；同时配合防重点击给用户明确反馈 */
const MIN_EXPORT_LOADING_MS = 1500;

export function useTableExport<T extends Recordable = Recordable>(
  tableRef: Ref<ProCrudTableInstance<T> | null>,
  options: UseTableExportOptions,
) {
  const { t } = useI18n();
  const message = useMessage();
  const { getTenantTimeZoneLabel } = useTenantOptions();

  const exportLoading = ref(false);

  /** 触发导出：构建参数 → 调用 request → downloadApiResponse */
  async function handleExport() {
    // 防重点击：上一次导出尚未结束时，直接吞掉本次触发
    if (exportLoading.value) return;
    const instance = tableRef.value;
    if (!instance) return;
    exportLoading.value = true;
    const startedAt = Date.now();
    try {
      // 参数构建优先级：options.buildParams → 表格 beforeRequest（resolveRequestParams）→ 原始搜索参数。
      const baseParams = options.buildParams
        ? await options.buildParams(instance.getSearchParams() as CrudRequestParams)
        : await instance.resolveRequestParams();
      const tzLabel = getTenantTimeZoneLabel((baseParams as Recordable).tenantId);
      const exportTimeZone = options.exportTimeZone ?? parseTimeOffset(tzLabel) ?? undefined;
      // settledColumns：列设置（显隐+排序）应用后的数据列，保证导出"所见即所得"
      const columns = instance.getSettledColumns();
      const fileName =
        typeof options.fileName === 'function' ? options.fileName() : options.fileName;
      const params: Recordable = {
        ...baseParams,
        pageNo: 1,
        pageSize: options.pageSize ?? 10000,
        isExport: true,
        exportFileName: fileName,
        exportTitle: buildExportTitle(columns, tzLabel),
      };
      if (exportTimeZone != null) params.exportTimeZone = exportTimeZone;
      await downloadApiResponse(options.request(params));
      message.success(t('common.download.exportSuccess'));
    } catch (error) {
      if (error instanceof ExportError) {
        if (error.message) message.error(error.message);
      } else if (error != null) {
        message.error(t('common.download.exportFailed'));
      }
    } finally {
      // 最小 loading 时长：极快返回时补足到 MIN_EXPORT_LOADING_MS，避免 loading 一闪而过
      const elapsed = Date.now() - startedAt;
      if (elapsed < MIN_EXPORT_LOADING_MS) {
        await new Promise((resolve) => setTimeout(resolve, MIN_EXPORT_LOADING_MS - elapsed));
      }
      exportLoading.value = false;
    }
  }

  return { exportLoading, handleExport };
}
