export const useGame = () => {
  const typeMap = {
    0: {
      label: '电子游戏',
      value: 0,
      type: 'Electronic',
    },
    1: {
      label: '真人视讯',
      value: 1,
      type: 'Video',
    },
    2: {
      label: '体育竞技',
      value: 2,
      type: 'Sports',
    },
    3: {
      label: '彩票',
      value: 3,
      type: 'Lottery',
    },
    4: {
      label: '棋牌',
      value: 4,
      type: 'ChessCard',
    },
  };
  const lotteryMap = {
    Num: '数字',
    Color: '颜色',
    Green: '绿色',
    Red: '红色',
    Violet: '紫色',
    BigSmall: '大小',
    Small: '小',
    Big: '大',
    Even: '偶数',
    Odd: '奇数',
    SumNum: '总和',
    //k3
    SumBigSmall: '总和大小',
    SumOddEven: '总和单双',
    NumSame2: '二同号单选',
    NumSame2Mult: '二同号复选',
    NumSame3: '三同号单选',
    NumSame3All: '三同号通选',
    NumDiff3: '三不同',
    NumNear3All: '三连号通选',
    NumDiff2: '二不同号',
    // 5d
    FirstNum: '第一位数字',
    FirstBigSmall: '第一位大小',
    FirstOddEven: '第一位单双',
    SecondNum: '第二位数字',
    SecondBigSmall: '第二位大小',
    SecondOddEven: '第二位单双',
    ThirdNum: '第三位数字',
    ThirdBigSmall: '第三位大小',
    ThirdOddEven: '第三位单双',
    FourthNum: '第四位数字',
    FourthBigSmall: '第四位大小',
    FourthOddEven: '第四位单双',
    FifthNum: '第五位数字',
    FifthBigSmall: '第五位大小',
    FifthOddEven: '第五位单双',
    D5_SumBigSmall: '和值大小',
    D5_SumOddEven: '和值单双',
  };
  const formatLotteryBet = (item: Record<string, string>) => {
    const betContent = item.betContent;
    const playType = item.playType;
    const bet = betContent.replace(playType + '_', '');
    if (item.gameCode.includes('D5')) return lotteryMap[`D5_${bet}`] || lotteryMap[bet] || bet;
    return lotteryMap[bet] || bet;
  };
  const statusMap = {
    0: {
      label: '禁用',
      value: 0,
      type: 'error',
    },
    1: {
      label: '启用',
      value: 1,
      type: 'success',
    },
    2: {
      label: '维护中',
      value: 2,
      type: 'warning',
    },
  };
  const financialMap = {
    TransIn: {
      label: '商户转入(上分)',
      value: 'TransIn',
    },
    TransOut: {
      label: '商户转出(下分)',
      value: 'TransOut',
    },
    TransReturn: {
      label: '商户转账退回',
      value: 'TransReturn',
    },
    GameBet: {
      label: '下注',
      value: 'GameBet',
    },
    GameEnd: {
      label: '结算',
      value: 'GameEnd',
    },
    GameTransIn: {
      label: '游戏上分',
      value: 'GameTransIn',
    },
    GameTransOut: {
      label: '游戏下分',
      value: 'GameTransOut',
    },
    GameReduce: {
      label: '游戏扣款',
      value: 'GameReduce',
    },
    GamePlus: {
      label: '游戏补款',
      value: 'GamePlus',
    },
    GameActivityPlus: {
      label: '游戏活动奖励',
      value: 'GameActivityPlus',
    },
    GameReturn: {
      label: '游戏退款',
      value: 'GameReturn',
    },
    GameCombineEnd: {
      label: '合并结算',
      value: 'GameCombineEnd',
    },
    GameCancel: {
      label: '游戏撤销',
      value: 'GameCancel',
    },
  };
  const typeMapList = Object.values(typeMap);
  const statusMapList = Object.values(statusMap);
  const financialMapList = Object.values(financialMap);
  return {
    typeMap,
    typeMapList,
    statusMap,
    statusMapList,
    financialMap,
    financialMapList,
    lotteryMap,
    formatLotteryBet,
  };
};
