import { ref, type Ref } from 'vue';
import { ACCESS_TOKEN } from '@/store/mutation-types';
import { storage } from '@/utils/Storage';

// ─── Types ────────────────────────────────────────────────
export interface SSEStreamOptions {
  /** 请求地址（相对或绝对） */
  url: string;
  /** HTTP 方法，默认 POST */
  method?: 'GET' | 'POST';
  /** 请求体（POST 时自动 JSON.stringify） */
  body?: Record<string, any>;
  /** 额外请求头 */
  headers?: Record<string, string>;
  /** 是否自动注入 Authorization Bearer token，默认 true */
  withToken?: boolean;
  /** 空闲超时（ms），默认 45_000 */
  idleTimeout?: number;
  /** 最大缓冲区大小（byte），默认 1 MB */
  maxBufferSize?: number;
}

export interface SSEEvent {
  [key: string]: any;
}

export interface SSEStreamCallbacks<T extends SSEEvent = SSEEvent> {
  /** 收到一个 SSE 事件（已解析为 JSON） */
  onEvent?: (event: T) => void;
  /** 流结束 */
  onDone?: () => void;
  /** 流出错（网络错误、HTTP 错误、超时等） */
  onError?: (error: SSEStreamError) => void;
}

export interface SSEStreamError {
  message: string;
  code?: string;
  retryable?: boolean;
  httpStatus?: number;
}

export interface UseSSEStreamReturn {
  /** 是否正在流式传输 */
  isStreaming: Ref<boolean>;
  /** 启动流 */
  start: <T extends SSEEvent = SSEEvent>(
    options: SSEStreamOptions,
    callbacks: SSEStreamCallbacks<T>,
  ) => Promise<void>;
  /** 中止当前流 */
  stop: () => void;
}

// ─── Constants ────────────────────────────────────────────
const DEFAULT_IDLE_TIMEOUT = 45_000;
const DEFAULT_MAX_BUFFER_SIZE = 1024 * 1024; // 1 MB
const SSE_BLOCK_DELIMITER = /\r?\n\r?\n/;

const HTTP_ERROR_MESSAGES: Record<number, string> = {
  400: '请求参数错误',
  401: '登录已过期，请重新登录',
  403: '无权限访问',
  404: '服务不可用',
  429: '请求过于频繁，请稍后再试',
  500: '服务器内部错误',
  502: '服务暂时不可用',
  503: '服务维护中',
  504: '请求超时',
};

// ─── Helpers ──────────────────────────────────────────────
function parseSSEBlock(block: string): SSEEvent | null {
  const lines = block.split(/\r?\n/);
  const dataLines: string[] = [];

  for (const rawLine of lines) {
    const line = rawLine.trimEnd();
    if (!line || line.startsWith(':')) continue;
    if (line.startsWith('data:')) {
      dataLines.push(line.slice(5).trimStart());
    }
  }

  if (!dataLines.length) return null;

  const data = dataLines.join('\n').trim();
  if (!data) return null;

  try {
    return JSON.parse(data);
  } catch {
    console.warn('[SSE] JSON parse failed, discarding:', data.slice(0, 100));
    return null;
  }
}

function getHttpErrorMessage(status: number): string {
  return HTTP_ERROR_MESSAGES[status] || `请求失败 (${status})`;
}

// ─── Composable ───────────────────────────────────────────
export function useSSEStream(): UseSSEStreamReturn {
  const isStreaming = ref(false);
  let abortController: AbortController | null = null;

  function stop() {
    abortController?.abort();
    abortController = null;
    isStreaming.value = false;
  }

  async function start<T extends SSEEvent = SSEEvent>(
    options: SSEStreamOptions,
    callbacks: SSEStreamCallbacks<T>,
  ): Promise<void> {
    if (isStreaming.value) return;

    isStreaming.value = true;
    abortController = new AbortController();

    const idleTimeout = options.idleTimeout ?? DEFAULT_IDLE_TIMEOUT;
    const maxBufferSize = options.maxBufferSize ?? DEFAULT_MAX_BUFFER_SIZE;
    let streamTimedOut = false;
    let idleTimer: number | null = null;

    const resetIdleTimer = () => {
      if (idleTimer) window.clearTimeout(idleTimer);
      idleTimer = window.setTimeout(() => {
        streamTimedOut = true;
        abortController?.abort();
      }, idleTimeout);
    };

    const clearIdleTimer = () => {
      if (idleTimer) {
        window.clearTimeout(idleTimer);
        idleTimer = null;
      }
    };

    try {
      resetIdleTimer();

      // Build headers
      const headers: Record<string, string> = {
        ...options.headers,
      };
      if (options.method !== 'GET') {
        headers['Content-Type'] = 'application/json';
      }
      if (options.withToken !== false) {
        const token = storage.get(ACCESS_TOKEN);
        if (token) {
          headers.Authorization = `Bearer ${token}`;
        }
      }

      // Build fetch init
      const fetchInit: RequestInit = {
        method: options.method || 'POST',
        headers,
        signal: abortController.signal,
      };
      if (options.body && options.method !== 'GET') {
        fetchInit.body = JSON.stringify(options.body);
      }

      const response = await fetch(options.url, fetchInit);

      if (!response.ok) {
        callbacks.onError?.({
          message: getHttpErrorMessage(response.status),
          httpStatus: response.status,
          retryable: response.status >= 500 || response.status === 429,
        });
        return;
      }

      const reader = response.body?.getReader();
      if (!reader) {
        throw new Error('Response body is not readable');
      }

      const decoder = new TextDecoder();
      let buffer = '';

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        resetIdleTimer();
        buffer += decoder.decode(value, { stream: true });

        // Buffer overflow protection
        if (buffer.length > maxBufferSize) {
          console.error('[SSE] Buffer overflow, aborting stream');
          abortController?.abort();
          break;
        }

        // Split on double-newline SSE block delimiter
        const blocks = buffer.split(SSE_BLOCK_DELIMITER);
        buffer = blocks.pop() || '';

        for (const block of blocks) {
          const event = parseSSEBlock(block);
          if (event) {
            callbacks.onEvent?.(event as T);
          }
        }
      }

      // Process remaining buffer
      if (buffer.trim()) {
        const event = parseSSEBlock(buffer);
        if (event) {
          callbacks.onEvent?.(event as T);
        }
      }

      callbacks.onDone?.();
    } catch (e) {
      if ((e as Error).name === 'AbortError') {
        if (streamTimedOut) {
          callbacks.onError?.({
            message: 'AI 响应超时，请稍后重试',
            code: 'timeout',
            retryable: true,
          });
        }
        // User-initiated abort — no error callback
        return;
      }

      const isNetworkError = e instanceof TypeError && (e as TypeError).message.includes('fetch');
      callbacks.onError?.({
        message: isNetworkError ? '网络连接失败，请检查网络' : (e as Error).message || '请求失败',
        retryable: isNetworkError,
      });
    } finally {
      clearIdleTimer();
      isStreaming.value = false;
      abortController = null;
    }
  }

  return { isStreaming, start, stop };
}
