import { computed, h, ref, type ComputedRef, type Ref, type VNode } from 'vue';
import { api } from '@/api';
import type { TenantInfoRsp } from '@/api/admin';
import type { IdNameRsp, OrganizationSelectRsp } from '@/api/tenant/types';
import { useUserStore, type UserTenantItem } from '@/store/modules/user';
import {
  convertLocalWallClockToZoneUtc,
  formatToTimeZone,
  getTimeZoneOffsetLabel,
} from '@/utils/dateUtil';

/**
 * 统一的商户选项结构，供查询下拉、标签展示和时区格式化等场景复用。
 */
export interface TenantOption {
  /**
   * 商户展示标签，默认格式为 `(id)name`，适合直接用于下拉文案或表格回显。
   */
  label: string;

  /**
   * 选项值，等同于商户 id，供 `NSelect` 等表单组件绑定。
   */
  value: number;

  /**
   * 商户 id。
   */
  id: number;

  /**
   * 商户名称。
   */
  name: string;

  /**
   * 所属组织 id。
   */
  orgId: number;

  /**
   * 所属组织名称。
   */
  orgName: string;

  /**
   * 商户时区标识，例如 `Asia/Shanghai`。
   */
  timeZone: string;

  /**
   * 商户时区展示文案，例如 `UTC+08:00`。
   */
  timeZoneLabel: string;

  /**
   * 用户信息中的原始商户对象，保留完整后端字段，便于特殊场景向下透传。
   */
  raw: UserTenantItem | null;

  /**
   * 允许在构建选项对象时扩展附加字段。
   */
  [key: string]: unknown;
}

interface TenantOptionsSharedState {
  tenantList: ComputedRef<UserTenantItem[]>;
  tenantMap: ComputedRef<Record<number, UserTenantItem>>;
  tenantNameMap: ComputedRef<Record<number, string>>;
  tenantLabelMap: ComputedRef<Record<number, string>>;
  tenantTimeZoneMap: ComputedRef<Record<number, string>>;
  tenantTimeZoneLabelMap: ComputedRef<Record<number, string>>;
  tenantOptions: ComputedRef<TenantOption[]>;
  tenantOptionMap: ComputedRef<Map<number, TenantOption>>;
}

export interface TenantCascaderOption {
  label: string;
  value: number | string;
  orgId: number;
  orgName: string;
  tenantId?: number;
  tenantName?: string;
  children?: TenantCascaderOption[];
}

/**
 * 审批商户下拉项（人工充值/审核场景使用）。
 * 仅保留 select 必备字段，避免外部误用为完整 TenantOption。
 */
export interface ApprovalTenantOption {
  label: string;
  value: number;
  id: number;
  name: string;
}

interface TenantOptionsAdminSharedState {
  organizationList: Ref<OrganizationSelectRsp[]>;
  /** 扁平化后的总控端商户列表（defaultTenantId 兜底 / 各页查询回退用）。此前工厂算出却漏挂到共享态，导致外部读 undefined.value 崩溃。 */
  adminTenantList: ComputedRef<AdminTenantFlatItem[]>;
  tenantNameMap: ComputedRef<Record<number, string>>;
  tenantLabelMap: ComputedRef<Record<number, string>>;
  orgNameMap: ComputedRef<Record<number, string>>;
  tenantOptions: ComputedRef<TenantOption[]>;
  tenantOptionMap: ComputedRef<Map<number, TenantOption>>;
  tenantCascaderOptions: ComputedRef<TenantCascaderOption[]>;
  loading: Ref<boolean>;
  loaded: Ref<boolean>;
  load: (force?: boolean) => Promise<void>;
  refresh: () => Promise<void>;
}

/**
 * `useTenantOptions()` 对外暴露的完整能力集合。
 *
 * 该接口用于：
 * - 为调用方提供统一且可悬浮查看的属性/方法说明
 * - 明确哪些字段适合直接用于表单、展示、时区处理和快速索引
 */
export interface UseTenantOptionsReturn {
  /**
   * 当前激活商户的完整信息。
   *
   * 来源于 `userStore.getActiveTenantId` 对应的商户映射；
   * 当用户尚未选中商户或当前 id 在列表中不存在时，值为 `null`。
   */
  activeTenant: ComputedRef<UserTenantItem | null>;

  /**
   * 当前激活商户 id。
   *
   * 该值直接来自用户状态，用于查询默认值、表格上下文和详情页联动。
   */
  activeTenantId: ComputedRef<number | null>;

  /**
   * 默认商户 id。
   *
   * 取值优先级：
   * - 当前激活商户 id
   * - 商户列表第一个商户 id
   * - `null`
   */
  defaultTenantId: ComputedRef<number | null>;

  /**
   * 当前登录用户可访问的商户扁平列表。
   *
   * 适合用于需要遍历原始商户数据的场景，例如批量映射、自定义过滤或复杂展示。
   */
  tenantList: ComputedRef<UserTenantItem[]>;

  /**
   * 以商户 id 为 key 的原始商户对象映射。
   *
   * 适合在页面逻辑里通过 id 快速读取完整商户信息，避免多次遍历 `tenantList`。
   */
  tenantMap: ComputedRef<Record<number, UserTenantItem>>;

  /**
   * 以商户 id 为 key 的商户名称映射。
   *
   * 适合仅需要纯名称回显的轻量场景。
   */
  tenantNameMap: ComputedRef<Record<number, string>>;

  /**
   * 以商户 id 为 key 的商户标签映射。
   *
   * 标签格式与 `formatTenantLabel()` 保持一致，适合表格列和详情文案直接回显。
   */
  tenantLabelMap: ComputedRef<Record<number, string>>;

  /**
   * 以商户 id 为 key 的时区字符串映射。
   *
   * 值为标准时区标识，例如 `Asia/Shanghai`。
   */
  tenantTimeZoneMap: ComputedRef<Record<number, string>>;

  /**
   * 以商户 id 为 key 的时区展示文案映射。
   *
   * 值为适合直接展示给用户的时区偏移文案，例如 `UTC+08:00`。
   */
  tenantTimeZoneLabelMap: ComputedRef<Record<number, string>>;

  /**
   * 适合直接绑定到下拉选择组件的商户选项列表。
   *
   * 每一项都包含商户标签、id、名称、组织信息、时区信息和原始对象。
   */
  tenantOptions: ComputedRef<TenantOption[]>;

  /**
   * 总控模式下可直接绑定到级联选择组件的集团/商户选项树。
   *
   * 普通商户模式下返回空数组。
   */
  tenantCascaderOptions: ComputedRef<TenantCascaderOption[]>;

  /**
   * 以商户 id 为 key 的商户选项映射。
   *
   * 适合通过 id 快速读取 `TenantOption`，避免从 `tenantOptions` 中重复查找。
   */
  tenantOptionMap: ComputedRef<Map<number, TenantOption>>;

  /**
   * 审批商户原始列表（人工充值入款 / 审核 / 审核记录三类页面共用）。
   *
   * 数据源：`userStore.info.approvalTenantList`，是 `tenantList` 的子集。
   * 命名沿用后端字段 `approvalTenantList`，避免出现"同一份数据多套别名"。
   */
  approvalTenantList: ComputedRef<TenantInfoRsp[]>;

  /**
   * 审批商户下拉选项。
   *
   * 与 `tenantOptions` 的区别：仅含 approvalTenantList 范围内的商户。
   */
  approvalTenantOptions: ComputedRef<ApprovalTenantOption[]>;

  /**
   * 审批场景下的默认商户 id。
   *
   * 取值规则（与全局商户上下文对齐）：
   * 1. 取全局默认商户 id (`defaultTenantId`，含 active → tenantList[0] 兜底链)
   * 2. 若该 id 出现在 `approvalTenantList` 中 → 用它
   * 3. 否则取 `approvalTenantList` 第 0 项的 id
   * 4. 都没有 → `0`
   */
  defaultApprovalTenantId: ComputedRef<number>;

  /**
   * 总控商户范围是否正在加载。
   */
  loading: ComputedRef<boolean>;

  /**
   * 总控商户范围是否已完成至少一次成功加载。
   */
  loaded: ComputedRef<boolean>;

  /**
   * 按需加载总控集团/商户范围。
   */
  load: (force?: boolean) => Promise<void>;

  /**
   * 强制刷新总控集团/商户范围。
   */
  refresh: () => Promise<void>;

  /**
   * 根据商户 id 读取原始商户对象。
   *
   * @param tenantId 商户 id，仅接受数值型 id
   * @returns 命中时返回原始商户对象，未命中或参数无效时返回 `null`
   */
  getTenant(tenantId?: number | null): UserTenantItem | null;

  /**
   * 根据商户 id 读取格式化后的商户选项对象。
   *
   * @param tenantId 商户 id，仅接受数值型 id
   * @returns 命中时返回 `TenantOption`，未命中时返回 `undefined`
   */
  getTenantOption(tenantId?: number | null): TenantOption | undefined;

  /**
   * 根据商户 id 获取商户名称。
   *
   * @param tenantId 商户 id
   * @param fallback 未命中时返回的兜底文案，默认 `-`
   * @returns 商户名称或兜底文案
   */
  getTenantName(tenantId?: number | null, fallback?: string): string;

  /**
   * 根据商户 id 获取商户支持的系统币种。
   *
   * @param tenantId 商户 id，允许传入字符串或数字
   * @param fallback 未命中时返回的兜底文案，默认空字符串
   * @returns 商户系统币种或兜底文案
   */
  getTenantCurrency(tenantId?: string | number | null, fallback?: string): string;

  /**
   * 根据商户 id 获取商户时区标识。
   *
   * @param tenantId 商户 id，允许传入字符串或数字
   * @param fallback 未命中时返回的兜底文案，默认空字符串
   * @returns 时区字符串，例如 `Asia/Shanghai`
   */
  getTenantTimeZone(tenantId?: string | number | null, fallback?: string): string;

  /**
   * 根据商户 id 获取商户时区展示文案。
   *
   * @param tenantId 商户 id，允许传入字符串或数字
   * @param fallback 未命中时返回的兜底文案，默认空字符串
   * @returns 时区展示文案，例如 `UTC+08:00`
   */
  getTenantTimeZoneLabel(tenantId?: string | number | null, fallback?: string): string;

  /**
   * 为文本列标题拼接商户时区标识。
   *
   * @param title 原始标题文案
   * @param tenantId 商户 id，允许传入字符串或数字
   * @param fallbackTimeZoneLabel 当商户 id 无法解析时使用的备用时区文案
   * @returns 若存在时区文案则返回 `标题 (时区)`，否则返回原始标题
   */
  getTenantDateTimeColumnTitle(
    title: string,
    tenantId?: string | number | null,
    fallbackTimeZoneLabel?: string,
  ): string;

  /**
   * 返回可用于表格列头的标题渲染结果，并在视觉上附加时区文案。
   *
   * @param title 原始标题文本或标题渲染函数
   * @param tenantId 商户 id，允许传入字符串或数字
   * @param fallbackTimeZoneLabel 当商户 id 无法解析时使用的备用时区文案
   * @returns 无时区时返回原值；有时区时返回一个 `VNode` 渲染函数
   */
  renderTenantDateTimeColumnTitle(
    title: string | (() => VNode),
    tenantId?: string | number | null,
    fallbackTimeZoneLabel?: string,
  ): string | (() => VNode);

  /**
   * 按商户时区格式化时间值。
   *
   * @param value 待格式化的时间值，支持时间戳、字符串、`Date`
   * @param tenantId 商户 id，允许传入字符串或数字
   * @param formatStr 可选的时间格式模板
   * @param fallback 无法格式化时返回的兜底文案，默认 `--`
   * @returns 已转换到商户时区的时间字符串
   */
  formatTenantDateTime(
    value: number | string | Date | null | undefined,
    tenantId?: string | number | null,
    formatStr?: string,
    fallback?: string,
  ): string;

  /**
   * 把浏览器本地 wall-clock 时间戳，按商户时区解释为真 UTC 时间戳。
   *
   * 用于搜索区日期选择器 → 商户时区范围查询场景，与表头 / 单元格的 UTC 展示保持同源。
   * 传入的 `value` 为 picker 发射的本地 ms，`tenantId` 缺省时返回原值。
   *
   * @param value 浏览器本地 wall-clock 时间戳、字符串或 `Date`
   * @param tenantId 商户 id，允许传入字符串或数字
   * @returns 对应商户时区的真 UTC 毫秒时间戳；值无效时返回 `null`
   */
  toTenantUtcTimestamp(
    value: number | string | Date | null | undefined,
    tenantId?: string | number | null,
  ): number | null;

  /**
   * 获取用于展示的商户标签。
   *
   * 优先级：
   * - 若显式传入 `tenantName`，优先使用传入名称
   * - 否则根据 `tenantId` 从共享商户列表中回填名称
   * - 若都不可用，则返回 `fallback`
   *
   * @param tenantId 商户 id，允许传入字符串或数字
   * @param tenantName 可选的商户名称，存在时优先使用
   * @param fallback 当 id 和名称都不可用时返回的兜底文案，默认 `-`
   * @returns 统一格式的商户标签
   */
  getTenantLabel(
    tenantId?: string | number | null,
    tenantName?: string | null,
    fallback?: string,
  ): string;

  /**
   * 根据集团 id 获取集团名称。
   *
   * @param orgId 集团 id
   * @param fallback 未命中时返回的兜底文案，默认 `-`
   * @returns 集团名称或兜底文案
   */
  getOrgName(orgId?: string | number | null, fallback?: string): string;
}

// 复用同一批 computed 映射，避免多个调用方重复构建商户索引。
let sharedState: TenantOptionsSharedState | null = null;
let adminSharedState: TenantOptionsAdminSharedState | null = null;
let adminPendingRequest: Promise<void> | null = null;

/**
 * 将商户 id 与名称格式化为统一展示文案。
 *
 * 规则：
 * - 同时存在有效 id 和名称时，返回 `(id)name`
 * - 只有名称时，返回名称
 * - 只有有效 id 时，返回 id
 * - 都无效时，返回 fallback
 */
export function formatTenantLabel(
  tenantId?: string | number | null,
  tenantName?: string | null,
  fallback = '-',
) {
  const normalizedName = String(tenantName ?? '').trim();
  const normalizedIdText = String(tenantId ?? '').trim();

  if (!normalizedIdText || normalizedIdText === '0') {
    return normalizedName || fallback;
  }

  const normalizedId = Number(normalizedIdText);
  if (Number.isFinite(normalizedId) && normalizedId <= 0) {
    return normalizedName || fallback;
  }

  const displayId = Number.isFinite(normalizedId) ? String(normalizedId) : normalizedIdText;
  return normalizedName ? `(${displayId})${normalizedName}` : displayId;
}

interface AdminTenantFlatItem {
  id: number;
  name: string;
  orgId: number;
  orgName: string;
}

function normalizeAdminTenantList(
  organizationList: OrganizationSelectRsp[],
): AdminTenantFlatItem[] {
  return organizationList.flatMap((organization) =>
    (organization.tenantList ?? [])
      .filter((tenant): tenant is IdNameRsp & { id: number; name: string } => {
        return typeof tenant?.id === 'number' && Number.isFinite(tenant.id);
      })
      .map((tenant) => ({
        id: tenant.id,
        name: String(tenant.name ?? '').trim(),
        orgId: organization.id,
        orgName: String(organization.name ?? '').trim(),
      })),
  );
}

function createTenantOptionRecord(
  tenant: Pick<AdminTenantFlatItem, 'id' | 'name' | 'orgId' | 'orgName'>,
  rawTenant?: UserTenantItem | null,
): TenantOption {
  const timeZone = String(rawTenant?.timeZone ?? '').trim();

  return {
    label: formatTenantLabel(tenant.id, tenant.name),
    value: tenant.id,
    id: tenant.id,
    name: tenant.name,
    orgId: tenant.orgId,
    orgName: tenant.orgName,
    timeZone,
    timeZoneLabel: getTimeZoneOffsetLabel(timeZone),
    raw: rawTenant ?? null,
  };
}

function ensureTenantOptionsSharedState(
  userStore: ReturnType<typeof useUserStore>,
): TenantOptionsSharedState {
  if (sharedState) return sharedState;

  const tenantList = computed(() => userStore.getTenantFlatList);
  const tenantMap = computed<Record<number, UserTenantItem>>(() =>
    tenantList.value.reduce<Record<number, UserTenantItem>>((accumulator, tenant) => {
      accumulator[tenant.id] = tenant;
      return accumulator;
    }, {}),
  );

  const tenantNameMap = computed<Record<number, string>>(() =>
    tenantList.value.reduce<Record<number, string>>((accumulator, tenant) => {
      accumulator[tenant.id] = tenant.name;
      return accumulator;
    }, {}),
  );

  const tenantLabelMap = computed<Record<number, string>>(() =>
    tenantList.value.reduce<Record<number, string>>((accumulator, tenant) => {
      accumulator[tenant.id] = formatTenantLabel(tenant.id, tenant.name);
      return accumulator;
    }, {}),
  );

  const tenantTimeZoneMap = computed<Record<number, string>>(() =>
    tenantList.value.reduce<Record<number, string>>((accumulator, tenant) => {
      accumulator[tenant.id] = String(tenant.timeZone ?? '').trim();
      return accumulator;
    }, {}),
  );

  const tenantTimeZoneLabelMap = computed<Record<number, string>>(() =>
    tenantList.value.reduce<Record<number, string>>((accumulator, tenant) => {
      accumulator[tenant.id] = getTimeZoneOffsetLabel(tenant.timeZone);
      return accumulator;
    }, {}),
  );

  const tenantOptions = computed<TenantOption[]>(() =>
    tenantList.value.map((tenant) => ({
      label: formatTenantLabel(tenant.id, tenant.name),
      value: tenant.id,
      id: tenant.id,
      name: tenant.name,
      orgId: tenant.orgId,
      orgName: tenant.orgName,
      timeZone: String(tenant.timeZone ?? '').trim(),
      timeZoneLabel: getTimeZoneOffsetLabel(tenant.timeZone),
      raw: tenant,
    })),
  );

  const tenantOptionMap = computed<Map<number, TenantOption>>(
    () => new Map(tenantOptions.value.map((option) => [option.value, option])),
  );

  sharedState = {
    tenantList,
    tenantMap,
    tenantNameMap,
    tenantLabelMap,
    tenantTimeZoneMap,
    tenantTimeZoneLabelMap,
    tenantOptions,
    tenantOptionMap,
  };

  return sharedState;
}

function ensureAdminTenantOptionsSharedState(
  userStore: ReturnType<typeof useUserStore>,
): TenantOptionsAdminSharedState {
  if (adminSharedState) return adminSharedState;

  const baseState = ensureTenantOptionsSharedState(userStore);
  const organizationList = ref<OrganizationSelectRsp[]>([]);
  const loading = ref(false);
  const loaded = ref(false);

  const adminTenantList = computed<AdminTenantFlatItem[]>(() =>
    normalizeAdminTenantList(organizationList.value),
  );

  const tenantNameMap = computed<Record<number, string>>(() =>
    adminTenantList.value.reduce<Record<number, string>>((accumulator, tenant) => {
      accumulator[tenant.id] = tenant.name;
      return accumulator;
    }, {}),
  );

  const tenantLabelMap = computed<Record<number, string>>(() =>
    adminTenantList.value.reduce<Record<number, string>>((accumulator, tenant) => {
      accumulator[tenant.id] = formatTenantLabel(tenant.id, tenant.name);
      return accumulator;
    }, {}),
  );

  const orgNameMap = computed<Record<number, string>>(() =>
    organizationList.value.reduce<Record<number, string>>((accumulator, organization) => {
      accumulator[organization.id] = String(organization.name ?? '').trim();
      return accumulator;
    }, {}),
  );

  const tenantOptions = computed<TenantOption[]>(() =>
    adminTenantList.value.map((tenant) =>
      createTenantOptionRecord(tenant, baseState.tenantMap.value[tenant.id] ?? null),
    ),
  );

  const tenantOptionMap = computed<Map<number, TenantOption>>(
    () => new Map(tenantOptions.value.map((option) => [option.value, option])),
  );

  const tenantCascaderOptions = computed<TenantCascaderOption[]>(() =>
    organizationList.value
      .filter(
        (organization) => Array.isArray(organization.tenantList) && organization.tenantList.length,
      )
      .map((organization) => ({
        label: String(organization.name ?? '').trim() || String(organization.id),
        value: `org:${organization.id}`,
        orgId: organization.id,
        orgName: String(organization.name ?? '').trim(),
        children: (organization.tenantList ?? [])
          .filter((tenant): tenant is IdNameRsp & { id: number; name: string } => {
            return typeof tenant?.id === 'number' && Number.isFinite(tenant.id);
          })
          .map((tenant) => ({
            label: formatTenantLabel(tenant.id, tenant.name),
            value: tenant.id,
            orgId: organization.id,
            orgName: String(organization.name ?? '').trim(),
            tenantId: tenant.id,
            tenantName: String(tenant.name ?? '').trim(),
          })),
      })),
  );

  async function load(force = false) {
    if (!userStore.isSuperAuthUser) {
      organizationList.value = [];
      loaded.value = true;
      return;
    }

    if (loaded.value && !force) return;
    if (adminPendingRequest && !force) {
      await adminPendingRequest;
      return;
    }

    adminPendingRequest = (async () => {
      loading.value = true;
      try {
        const { data, result } = await api.tenant.organizationGetSelectList();
        if (result && Array.isArray(data)) {
          organizationList.value = data;
          loaded.value = true;
          return;
        }

        organizationList.value = [];
        loaded.value = false;
      } catch {
        organizationList.value = [];
        loaded.value = false;
      } finally {
        loading.value = false;
        adminPendingRequest = null;
      }
    })();

    await adminPendingRequest;
  }

  adminSharedState = {
    organizationList,
    adminTenantList,
    tenantNameMap,
    tenantLabelMap,
    orgNameMap,
    tenantOptions,
    tenantOptionMap,
    tenantCascaderOptions,
    loading,
    loaded,
    load,
    refresh: () => load(true),
  };

  return adminSharedState;
}

/**
 * 提供当前登录用户可访问商户的共享选项、映射和格式化能力。
 *
 * 适用场景：
 * - 查询表单中的商户下拉选项
 * - 表格中的商户名称/标签回显
 * - 依商户时区生成列标题与时间格式化结果
 *
 * 返回值说明：
 * - `tenantList`、`tenantMap`、`tenantOptionMap`：原始列表及快速索引
 * - `tenantOptions`、`tenantLabelMap`：供下拉与展示文案直接使用
 * - `activeTenant`、`defaultTenantId`：当前激活商户及默认商户
 * - `getTenant*`、`formatTenantDateTime`：常用读取与格式化辅助方法
 */
export function useTenantOptions(): UseTenantOptionsReturn {
  const userStore = useUserStore();
  const state = ensureTenantOptionsSharedState(userStore);
  const adminState = ensureAdminTenantOptionsSharedState(userStore);
  const isSuperAuthUser = computed(() => userStore.isSuperAuthUser);

  if (isSuperAuthUser.value && !adminState.loaded.value && !adminState.loading.value) {
    void adminState.load();
  }

  const activeTenantId = computed(() => userStore.getActiveTenantId);
  // 默认商户（2026-07-16 用户定「商户下拉必须有默认商户，多选也要」）：
  // 商户端 = 激活商户 → tenantList[0] 兜底；总控端原恒 null（无默认，tenantSelect 预填/查询回退在 3200 全部空转），
  // 现同样兜底到 adminTenantList[0]，使 tenantSelect 预填 / MerchantFilterSelect 空值写回 / 各页查询回退 双端行为一致。
  const defaultTenantId = computed<number | null>(() =>
    isSuperAuthUser.value
      ? // adminTenantList 现已挂进共享态（见工厂 return / 类型声明）。此前它被漏挂 → adminState.adminTenantList
        // 恒 undefined → 裸取 .value 抛 TypeError，硬加载(直接刷新/URL 首屏)进 admin proDateRange 页时在首屏
        // 同步渲染阶段崩溃整个 app(白屏)。触发链：proDateRange → useDateRange 解析商户时区 → 读本 computed。
        // 保留 ?. 作为额外防御（数据未加载时返回 []，本值 null；加载后自动重算）。
        (adminState.adminTenantList?.value?.[0]?.id ?? null)
      : (activeTenantId.value ?? state.tenantList.value[0]?.id ?? null),
  );
  const activeTenant = computed<UserTenantItem | null>(() => {
    const tenantId = activeTenantId.value;
    return typeof tenantId === 'number' ? (state.tenantMap.value[tenantId] ?? null) : null;
  });

  // 商户「显示名解析」恒以全量主数据（16 家，与角色无关）为底，
  // 保证任意角色（含商户端只可见本集团）下，列表里出现的任何商户号都能解析成 `(商户号)商户名`，不退化成裸号。
  const masterTenantNameMap = computed<Record<number, string>>(() =>
    userStore.getMasterTenantFlatList.reduce<Record<number, string>>((accumulator, tenant) => {
      accumulator[tenant.id] = tenant.name;
      return accumulator;
    }, {}),
  );
  const masterTenantLabelMap = computed<Record<number, string>>(() =>
    userStore.getMasterTenantFlatList.reduce<Record<number, string>>((accumulator, tenant) => {
      accumulator[tenant.id] = formatTenantLabel(tenant.id, tenant.name);
      return accumulator;
    }, {}),
  );

  // 在主数据之上叠加 store 商户列表，总控模式再叠加 admin 异步拉到的 organizationGetSelectList。
  const resolvedTenantNameMap = computed(() =>
    isSuperAuthUser.value
      ? {
          ...masterTenantNameMap.value,
          ...state.tenantNameMap.value,
          ...adminState.tenantNameMap.value,
        }
      : { ...masterTenantNameMap.value, ...state.tenantNameMap.value },
  );
  const resolvedTenantLabelMap = computed(() =>
    isSuperAuthUser.value
      ? {
          ...masterTenantLabelMap.value,
          ...state.tenantLabelMap.value,
          ...adminState.tenantLabelMap.value,
        }
      : { ...masterTenantLabelMap.value, ...state.tenantLabelMap.value },
  );
  const resolvedTenantOptions = computed(() =>
    isSuperAuthUser.value ? adminState.tenantOptions.value : state.tenantOptions.value,
  );
  const resolvedTenantOptionMap = computed(() =>
    isSuperAuthUser.value ? adminState.tenantOptionMap.value : state.tenantOptionMap.value,
  );
  const tenantCascaderOptions = computed(() =>
    isSuperAuthUser.value ? adminState.tenantCascaderOptions.value : [],
  );
  const loading = computed(() => (isSuperAuthUser.value ? adminState.loading.value : false));
  const loaded = computed(() => (isSuperAuthUser.value ? adminState.loaded.value : true));

  /**
   * 根据商户 id 读取原始商户信息。
   */
  function getTenant(tenantId?: number | null) {
    return typeof tenantId === 'number' ? (state.tenantMap.value[tenantId] ?? null) : null;
  }

  /**
   * 根据商户 id 读取格式化后的商户选项对象。
   */
  function getTenantOption(tenantId?: number | null) {
    return typeof tenantId === 'number' ? resolvedTenantOptionMap.value.get(tenantId) : undefined;
  }

  /**
   * 根据商户 id 获取商户名称，未命中时返回 fallback。
   */
  function getTenantName(tenantId?: number | null, fallback = '-') {
    if (typeof tenantId !== 'number') return fallback;
    return (
      resolvedTenantNameMap.value[tenantId]?.trim() || getTenant(tenantId)?.name?.trim() || fallback
    );
  }

  /**
   * 根据商户 id 获取商户支持的系统币种。
   */
  function getTenantCurrency(tenantId?: string | number | null, fallback = '') {
    const id = Number(tenantId);
    return Number.isFinite(id) ? getTenant(id)?.supportSysCurrency || fallback : fallback;
  }

  /**
   * 根据商户 id 获取商户时区字符串。
   */
  function getTenantTimeZone(tenantId?: string | number | null, fallback = '') {
    const id = Number(tenantId);
    return Number.isFinite(id) ? state.tenantTimeZoneMap.value[id] || fallback : fallback;
  }

  /**
   * 根据商户 id 获取商户时区展示文案，例如 `UTC+08:00`。
   */
  function getTenantTimeZoneLabel(tenantId?: string | number | null, fallback = '') {
    const id = Number(tenantId);
    return Number.isFinite(id) ? state.tenantTimeZoneLabelMap.value[id] || fallback : fallback;
  }

  /**
   * 为列表列标题追加商户时区标识。
   */
  function getTenantDateTimeColumnTitle(
    title: string,
    tenantId?: string | number | null,
    fallbackTimeZoneLabel = '',
  ) {
    const timeZoneLabel = getTenantTimeZoneLabel(tenantId, fallbackTimeZoneLabel);
    return timeZoneLabel ? `${title} (${timeZoneLabel})` : title;
  }

  /**
   * 返回带时区标识的列标题渲染函数，适用于 Naive UI 表格头部。
   */
  function renderTenantDateTimeColumnTitle(
    title: string | (() => VNode),
    tenantId?: string | number | null,
    fallbackTimeZoneLabel = '',
  ): string | (() => VNode) {
    const timeZoneLabel = getTenantTimeZoneLabel(tenantId, fallbackTimeZoneLabel);
    if (!timeZoneLabel) return title;

    const titleContent = typeof title === 'function' ? title : () => title;

    return () =>
      h(
        'span',
        {
          style:
            'display:inline-flex;align-items:baseline;gap:4px;white-space:nowrap;line-height:1.4;',
        },
        [
          titleContent(),
          h(
            'span',
            {
              style: 'font-size:12px;font-weight:400;color:var(--n-text-color-3);line-height:1.4;',
            },
            `(${timeZoneLabel})`,
          ),
        ],
      );
  }

  /**
   * 按商户时区格式化时间值，统一复用时区转换逻辑。
   */
  function formatTenantDateTime(
    value: number | string | Date | null | undefined,
    tenantId?: string | number | null,
    formatStr?: string,
    fallback = '--',
  ) {
    const timeZone = getTenantTimeZone(tenantId);
    return formatToTimeZone(value, timeZone, formatStr, fallback);
  }

  /**
   * 把浏览器本地 wall-clock 时间戳，按商户时区解释为真 UTC 时间戳。
   * 用于搜索时间范围 → 商户时区查询场景，保证与表头/单元格 UTC 展示同源。
   */
  function toTenantUtcTimestamp(
    value: number | string | Date | null | undefined,
    tenantId?: string | number | null,
  ): number | null {
    const timeZone = getTenantTimeZone(tenantId);
    return convertLocalWallClockToZoneUtc(value, timeZone);
  }

  /**
   * 根据集团 id 获取集团名称。
   */
  function getOrgName(orgId?: string | number | null, fallback = '-'): string {
    const id = Number(orgId);
    if (!Number.isFinite(id) || id <= 0) return fallback;
    if (isSuperAuthUser.value) {
      return adminState.orgNameMap.value[id]?.trim() || fallback;
    }
    const tenant = state.tenantList.value.find((t) => t.orgId === id);
    return tenant?.orgName?.trim() || fallback;
  }

  async function load(force = false) {
    if (!isSuperAuthUser.value) return;
    await adminState.load(force);
  }

  async function refresh() {
    if (!isSuperAuthUser.value) return;
    await adminState.refresh();
  }

  /**
   * 获取商户展示标签。
   *
   * 若显式传入 `tenantName`，优先使用传入名称；
   * 否则根据商户 id 从共享商户列表中回填名称。
   */
  function getTenantLabel(
    tenantId?: string | number | null,
    tenantName?: string | null,
    fallback = '-',
  ) {
    const normalizedName = String(tenantName ?? '').trim();
    if (normalizedName) {
      return formatTenantLabel(tenantId, normalizedName, fallback);
    }

    const normalizedTenantId = Number(tenantId);
    const resolvedTenantName = Number.isFinite(normalizedTenantId)
      ? getTenantName(normalizedTenantId, '')
      : '';

    return formatTenantLabel(tenantId, resolvedTenantName, fallback);
  }

  // ─── 审批商户派生（人工充值入款 / 审核 / 审核记录共用） ───
  // 数据源限定在 `approvalTenantList`（当前用户可审批的商户子集），与 `tenantOptions` 的全量区分；
  // 默认选中走"全局激活商户 → 审批列表命中校验 → 0"三段式
  const approvalTenantList = computed<TenantInfoRsp[]>(() => {
    const list = userStore.info?.approvalTenantList;
    return Array.isArray(list) ? list : [];
  });

  const approvalTenantOptions = computed<ApprovalTenantOption[]>(() =>
    approvalTenantList.value
      .filter(
        (tenant): tenant is TenantInfoRsp & { id: number } =>
          typeof tenant?.id === 'number' && Number.isFinite(tenant.id),
      )
      .map((tenant) => ({
        label: formatTenantLabel(tenant.id, tenant.name),
        value: tenant.id,
        id: tenant.id,
        name: String(tenant.name ?? '').trim(),
      })),
  );

  const defaultApprovalTenantId = computed<number>(() => {
    // 先复用全局 defaultTenantId（含 active → tenantList[0] 的兜底链）
    const globalDefault = defaultTenantId.value;
    if (
      typeof globalDefault === 'number' &&
      Number.isFinite(globalDefault) &&
      approvalTenantList.value.some((tenant) => tenant.id === globalDefault)
    ) {
      return globalDefault;
    }
    // 全局默认不在审批列表里：退回审批列表第 0 项；空列表才落 0
    return approvalTenantList.value[0]?.id ?? 0;
  });

  return {
    activeTenant,
    activeTenantId,
    defaultTenantId,
    tenantList: state.tenantList,
    tenantMap: state.tenantMap,
    tenantNameMap: resolvedTenantNameMap,
    tenantLabelMap: resolvedTenantLabelMap,
    tenantTimeZoneMap: state.tenantTimeZoneMap,
    tenantTimeZoneLabelMap: state.tenantTimeZoneLabelMap,
    tenantOptions: resolvedTenantOptions,
    tenantCascaderOptions,
    tenantOptionMap: resolvedTenantOptionMap,
    approvalTenantList,
    approvalTenantOptions,
    defaultApprovalTenantId,
    loading,
    loaded,
    load,
    refresh,
    getTenant,
    getTenantOption,
    getTenantName,
    getTenantLabel,
    getOrgName,
    getTenantCurrency,
    getTenantTimeZone,
    getTenantTimeZoneLabel,
    getTenantDateTimeColumnTitle,
    renderTenantDateTimeColumnTitle,
    formatTenantDateTime,
    toTenantUtcTimestamp,
  };
}
