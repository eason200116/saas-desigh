import type { VNodeChild } from 'vue';
import { useDialog } from 'naive-ui';

type ConfirmDialogType = 'warning' | 'info' | 'success' | 'error';

/**
 * 统一确认弹窗中的异步提交态。
 *
 * 适用：
 * - 删除
 * - 停用/启用
 * - 重置
 * - 其他需要二次确认的危险操作
 *
 * 提供能力：
 * - 确认按钮 loading
 * - 防重复点击
 * - 可选的提交中文案切换
 *
 * 兼容策略：
 * - 旧页面可继续直接使用 useDialog
 * - 这里是增量推荐能力，不替换既有调用
 */
export interface ConfirmActionOptions {
  title: string;
  /**
   * 弹窗正文。
   * - 传 string：纯文本，直接交给 Naive UI 渲染
   * - 传工厂函数：返回 VNodeChild，用于在弹窗内嵌备注输入、表单等组件
   */
  content: string | (() => VNodeChild);
  positiveText: string;
  negativeText: string;
  submittingPositiveText?: string;
  type?: ConfirmDialogType;
  /**
   * 防重复点击最小冷却时长（ms）。
   * - 未传或 ≤0：跟随 onPositiveClick 实际返回时间（默认行为）
   * - 传 3500：接口快速返回时仍保持 loading 至少 3.5 秒再关闭弹窗，避免用户在 dialog 关闭瞬间连点表格行按钮造成二次提交
   */
  minLoadingMs?: number;
  onPositiveClick: () => boolean | void | Promise<boolean | void>;
}

export function useConfirmAction() {
  const dialog = useDialog();

  function openConfirmAction(options: ConfirmActionOptions) {
    const { type = 'warning' } = options;
    let submitting = false;
    let inst: ReturnType<typeof dialog.warning>;

    inst = dialog[type]({
      title: options.title,
      content: options.content,
      positiveText: options.positiveText,
      negativeText: options.negativeText,
      onPositiveClick: async () => {
        // 避免用户在同一确认弹窗里重复点击确认，导致危险操作并发提交。
        if (submitting) return false;

        submitting = true;
        inst.loading = true;
        if (options.submittingPositiveText) {
          inst.positiveText = options.submittingPositiveText;
        }
        const startedAt = Date.now();
        try {
          return await options.onPositiveClick();
        } finally {
          // minLoadingMs 兜底：接口比冷却期更快返回时，补齐剩余时长再解锁，
          // 避免 dialog 关闭瞬间用户连点表格行按钮触发二次提交。
          const minLoadingMs = options.minLoadingMs ?? 0;
          if (minLoadingMs > 0) {
            const elapsed = Date.now() - startedAt;
            const remaining = minLoadingMs - elapsed;
            if (remaining > 0) {
              await new Promise<void>((resolve) => setTimeout(resolve, remaining));
            }
          }
          submitting = false;
          inst.loading = false;
          inst.positiveText = options.positiveText;
        }
      },
    });

    return inst;
  }

  return {
    openConfirmAction,
  };
}
