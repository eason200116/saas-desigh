import { h, ref, readonly, defineAsyncComponent } from 'vue';
import { useMessage, useModal, type ModalReactive } from 'naive-ui';
import { NButton, NIcon, NTag } from 'naive-ui';
import { FullscreenOutlined, FullscreenExitOutlined } from '@vicons/antd';
import { useI18n } from 'vue-i18n';
import { getLocale, loadNamespace, i18n } from '@/i18n';
import MemberDetailShell from '@/components/MemberDetail/MemberDetailShell.vue';
import { useTenantOptions } from '@/hooks/useTenantOptions';

// 懒加载：避免公共 hook 静态 bundle 整个 betRecord 模块（5 Tabs + shared 链路）
const BettingOrderDetailModal = defineAsyncComponent(
  () => import('@/views/game/betRecord/components/BettingOrderDetailModal.vue'),
);

// 会员详情全局状态
const memberId = ref<string | number>('');
const currentTenantId = ref<number | null>(null);
const currentTenantLabel = ref<string>('');

// 投注详情全局状态
const bettingVisible = ref(false);
const bettingProps = ref<Record<string, any>>({});
const bettingTitle = ref('');

const DEFAULT_WIDTH = 'min(1500px, 100vw)';

/**
 * 会员详情 / 投注详情属于"二级钻取弹窗"——可能在任意业务弹窗（审核订单详情、出款工作台详情等）
 * 的会员 ID 链接上被点开。Naive UI NModal 默认 zIndex 是 4000，业务弹窗大多沿用默认值，
 * 因此这里把会员详情显式抬到 6000、投注详情抬到 7000，保证：
 *   业务弹窗（默认 4000） < 会员详情（6000） < 投注详情（7000）
 * 投注详情高于会员详情：从会员详情内的投注列表再钻一层时，投注详情要在会员详情之上。
 */
const MEMBER_DETAIL_Z_INDEX = 6000;
const BETTING_DETAIL_Z_INDEX = 7000;

let memberModalInst: ModalReactive | null = null;
let bettingModalInst: ModalReactive | null = null;
let memberFullscreen = false;
let bettingFullscreen = false;

/**
 * 全局会员详情 / 投注详情弹窗状态管理（命令式）
 * 通过 useModal().create() 创建弹窗，不再需要声明式 <n-modal> 组件
 */
export function useMemberDetailModal() {
  const modal = useModal();
  const message = useMessage();
  const { t } = useI18n();
  const { getTenantLabel } = useTenantOptions();

  // ─── 会员详情弹窗 ───

  function getCurrentTenantLabel() {
    return currentTenantLabel.value || getTenantLabel(currentTenantId.value, undefined, '');
  }

  function renderMemberTitle() {
    const tenantLabel = getCurrentTenantLabel();
    return h('div', { style: 'display:flex;align-items:center;gap:8px' }, [
      h('span', t('member.detail.title', { id: memberId.value })),
      tenantLabel
        ? h(NTag, { size: 'small', bordered: true, type: 'info' }, { default: () => tenantLabel })
        : null,
      h(
        NButton,
        { quaternary: true, circle: true, size: 'small', onClick: toggleMemberFullscreen },
        {
          icon: () =>
            h(NIcon, { size: 16 }, () =>
              h(memberFullscreen ? FullscreenExitOutlined : FullscreenOutlined),
            ),
        },
      ),
    ]);
  }

  async function openMemberDetail(
    id: string | number,
    tenantId: number | string,
    tenantLabel?: string | null,
  ) {
    // tenantId 必须显式传"会员所属商户"——这是契约。
    const numericTenantId = Number(tenantId);
    if (
      tenantId == null ||
      tenantId === '' ||
      !Number.isFinite(numericTenantId) ||
      numericTenantId <= 0
    ) {
      message.error(t('member.detail.invalidTenantId'));
      return;
    }

    memberId.value = id;
    currentTenantId.value = numericTenantId;
    const normalizedTenantLabel = String(tenantLabel ?? '').trim();
    currentTenantLabel.value =
      normalizedTenantLabel && normalizedTenantLabel !== '-' && normalizedTenantLabel !== '--'
        ? normalizedTenantLabel
        : '';
    memberFullscreen = false;

    // 确保 member namespace 已加载（从非 /member 路由打开时按需加载）
    await loadNamespace(getLocale(i18n), 'member');

    // 关闭已有实例
    if (memberModalInst) {
      memberModalInst.destroy();
      memberModalInst = null;
    }

    memberModalInst = modal.create({
      preset: 'card',
      bordered: false,
      closable: true,
      maskClosable: true,
      style: getMemberStyle(),
      contentStyle: getMemberContentStyle(),
      zIndex: MEMBER_DETAIL_Z_INDEX,
      title: renderMemberTitle,
      content: () =>
        h(MemberDetailShell, {
          memberId: memberId.value,
          tenantId: currentTenantId.value ?? undefined,
          mode: 'modal',
          'onChange:member-id': setMemberDetailId,
        }),
      onUpdateShow: (show: boolean) => {
        if (!show) closeMemberDetail();
      },
    });
  }

  function setMemberDetailId(id: string | number) {
    memberId.value = id;
    // 更新弹窗标题
    if (memberModalInst) {
      memberModalInst.title = renderMemberTitle;
    }
  }

  function closeMemberDetail() {
    if (memberModalInst) {
      memberModalInst.destroy();
      memberModalInst = null;
    }
    memberFullscreen = false;
  }

  function toggleMemberFullscreen() {
    memberFullscreen = !memberFullscreen;
    if (memberModalInst) {
      memberModalInst.style = getMemberStyle();
      memberModalInst.contentStyle = getMemberContentStyle();
      // 重新渲染标题以切换图标
      setMemberDetailId(memberId.value);
    }
  }

  function getMemberStyle() {
    if (memberFullscreen) {
      return { width: '100vw', height: '100vh', maxWidth: '100vw', margin: '0', borderRadius: '0' };
    }
    // 【已铺开·2026-07-16 用户确认】弹窗加大(宽上限 1500→2000px、高 90→95vh)原为样板 1100002 试点，
    // 随数据统计卡片化重排一并对全部会员生效。收回方式：改回 Number(memberId.value) === 1100002。
    const isOnePagePilot = true;
    return isOnePagePilot
      ? { width: 'min(2000px, 100vw)', height: '95vh' }
      : { width: DEFAULT_WIDTH, height: '90vh' };
  }

  function getMemberContentStyle() {
    return memberFullscreen
      ? { maxHeight: 'calc(100vh - 60px)', overflow: 'auto' }
      : { flex: '1', overflow: 'auto' };
  }

  // ─── 投注详情弹窗 ───

  function openBettingOrderDetail(row: Record<string, any>, title: string) {
    bettingProps.value = row;
    bettingTitle.value = title;
    bettingVisible.value = true;
    bettingFullscreen = false;

    if (bettingModalInst) {
      bettingModalInst.destroy();
      bettingModalInst = null;
    }

    bettingModalInst = modal.create({
      preset: 'card',
      bordered: false,
      closable: true,
      maskClosable: true,
      style: getBettingStyle(),
      contentStyle: getBettingContentStyle(),
      zIndex: BETTING_DETAIL_Z_INDEX,
      title: () =>
        h('div', { style: 'display:flex;align-items:center;gap:8px' }, [
          h('span', bettingTitle.value),
          h(
            NButton,
            { quaternary: true, circle: true, size: 'small', onClick: toggleBettingFullscreen },
            {
              icon: () =>
                h(NIcon, { size: 16 }, () =>
                  h(bettingFullscreen ? FullscreenExitOutlined : FullscreenOutlined),
                ),
            },
          ),
        ]),
      content: () =>
        h(BettingOrderDetailModal, {
          ...bettingProps.value,
          gameType: bettingProps.value.gameType ?? '',
          onClose: closeBettingOrderDetail,
        } as any),
      onUpdateShow: (show: boolean) => {
        if (!show) closeBettingOrderDetail();
      },
    });
  }

  function closeBettingOrderDetail() {
    if (bettingModalInst) {
      bettingModalInst.destroy();
      bettingModalInst = null;
    }
    bettingVisible.value = false;
    bettingFullscreen = false;
  }

  function toggleBettingFullscreen() {
    bettingFullscreen = !bettingFullscreen;
    if (bettingModalInst) {
      bettingModalInst.style = getBettingStyle();
      bettingModalInst.contentStyle = getBettingContentStyle();
      // 重新渲染标题以切换图标
      bettingModalInst.title = () =>
        h('div', { style: 'display:flex;align-items:center;gap:8px' }, [
          h('span', bettingTitle.value),
          h(
            NButton,
            { quaternary: true, circle: true, size: 'small', onClick: toggleBettingFullscreen },
            {
              icon: () =>
                h(NIcon, { size: 16 }, () =>
                  h(bettingFullscreen ? FullscreenExitOutlined : FullscreenOutlined),
                ),
            },
          ),
        ]);
    }
  }

  function getBettingStyle() {
    return bettingFullscreen
      ? { width: '100vw', height: '100vh', maxWidth: '100vw', margin: '0', borderRadius: '0' }
      : { width: DEFAULT_WIDTH, height: '90vh' };
  }

  function getBettingContentStyle() {
    return bettingFullscreen
      ? { maxHeight: 'calc(100vh - 60px)', overflow: 'auto' }
      : { flex: '1', overflow: 'auto' };
  }

  return {
    // 会员详情
    memberDetailVisible: readonly(ref(false)), // 保留兼容，不再使用
    memberDetailId: readonly(memberId),
    memberDetailTenantId: readonly(currentTenantId),
    openMemberDetail,
    setMemberDetailId,
    closeMemberDetail,
    // 投注详情
    bettingDetailVisible: readonly(bettingVisible),
    bettingDetailProps: readonly(bettingProps),
    bettingDetailTitle: readonly(bettingTitle),
    openBettingOrderDetail,
    closeBettingOrderDetail,
  };
}
