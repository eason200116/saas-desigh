/**
 * Hook for managing tab state with URL query parameter synchronization
 * Enables deep linking to specific tabs via URL query params (e.g., ?tab=wallet)
 */
import { ref, watch, onMounted, onUnmounted } from 'vue';
import { useRoute } from 'vue-router';
import type { Ref } from 'vue';

export interface UseTabQueryOptions {
  /** Query parameter name, defaults to 'tab' */
  queryKey?: string;
  /** Whether to replace history instead of push */
  replace?: boolean;
}

export interface UseTabQueryReturn {
  /** Current active tab */
  activeTab: Ref<string>;
  /** Set active tab (updates URL) */
  setTab: (tab: string) => void;
  /** Check if tab matches query */
  isFromQuery: Ref<boolean>;
}

/**
 * Manage tab state with URL query parameter sync
 *
 * @param defaultTab - Default tab key when no query param present
 * @param options - Configuration options
 * @returns Tab state and methods
 *
 * @example
 * ```vue
 * <script setup>
 * import { useTabQuery } from '@/hooks/web/useTabQuery';
 *
 * const { activeTab, setTab } = useTabQuery('info');
 * </script>
 *
 * <template>
 *   <n-tabs v-model:value="activeTab">
 *     <n-tab-pane name="info" tab="Basic Info">...</n-tab-pane>
 *     <n-tab-pane name="wallet" tab="Wallet">...</n-tab-pane>
 *   </n-tabs>
 * </template>
 * ```
 */
export function useTabQuery(
  defaultTab: string,
  options: UseTabQueryOptions = {},
): UseTabQueryReturn {
  const { queryKey = 'tab', replace = true } = options;

  const route = useRoute();

  // Get initial tab from URL query or use default
  const getInitialTab = (): string => {
    const queryTab = route.query[queryKey];
    if (typeof queryTab === 'string' && queryTab) {
      return queryTab;
    }
    return defaultTab;
  };

  const activeTab = ref(getInitialTab());
  const isFromQuery = ref(!!route.query[queryKey]);

  // 切 tab 后同步浏览器地址栏 query。
  // 用 History API 直接改 URL，绕过 vue-router 响应式，避免和组件内 v-model 形成回环。
  const updateQuery = (tab: string) => {
    // 真值取自浏览器 URL，不用 route.path —— 后者在 KeepAlive 切回、嵌套 redirect、
    // 缓存页激活等场景可能与实际地址栏不一致，会导致 replaceState 写到错误的 path
    const pathname = window.location.pathname;
    const params = new URLSearchParams(window.location.search);

    // 与当前 URL 已一致则不再写
    if ((params.get(queryKey) ?? '') === (tab === defaultTab ? '' : tab)) return;

    // 默认 tab 显式移除参数，不用空串占位
    if (tab === defaultTab) {
      params.delete(queryKey);
    } else {
      params.set(queryKey, tab);
    }

    const queryString = params.toString();
    const newUrl = queryString ? `${pathname}?${queryString}` : pathname;

    if (replace) {
      window.history.replaceState(window.history.state, '', newUrl);
    } else {
      window.history.pushState({}, '', newUrl);
    }
  };

  // Set tab programmatically
  const setTab = (tab: string) => {
    activeTab.value = tab;
  };

  // Watch for tab changes and update URL
  watch(activeTab, (newTab) => {
    updateQuery(newTab);
  });

  // 响应编程式路由导航（router.push 改 query）：popstate 只覆盖浏览器前进后退，
  // 对 router.push 不生效；此处补齐 query 响应式，保证外部调用也能切 tab。
  // 不会循环：updateQuery 用 history.replaceState 直接改 URL，绕过 Vue Router 响应式。
  watch(
    () => route.query[queryKey],
    (newValue) => {
      const next = typeof newValue === 'string' && newValue ? newValue : defaultTab;
      if (next !== activeTab.value) {
        activeTab.value = next;
        isFromQuery.value = !!newValue;
      }
    },
  );

  // Handle browser back/forward via popstate (since we use History API directly)
  const handlePopState = () => {
    const params = new URLSearchParams(window.location.search);
    const newQueryTab = params.get(queryKey);
    if (newQueryTab && newQueryTab !== activeTab.value) {
      activeTab.value = newQueryTab;
      isFromQuery.value = true;
    } else if (!newQueryTab && activeTab.value !== defaultTab) {
      activeTab.value = defaultTab;
      isFromQuery.value = false;
    }
  };

  onMounted(() => {
    // Initialize from URL query (handle SSR/hydration)
    const queryTab = route.query[queryKey];
    if (typeof queryTab === 'string' && queryTab) {
      activeTab.value = queryTab;
      isFromQuery.value = true;
    }
    // Listen for browser back/forward
    window.addEventListener('popstate', handlePopState);
  });

  onUnmounted(() => {
    window.removeEventListener('popstate', handlePopState);
  });

  return {
    activeTab,
    setTab,
    isFromQuery,
  };
}
