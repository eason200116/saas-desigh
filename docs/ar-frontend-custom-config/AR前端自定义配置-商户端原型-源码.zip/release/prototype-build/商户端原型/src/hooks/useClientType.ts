import { computed } from 'vue';
import { useI18n } from 'vue-i18n';

export type ClientType = 'web' | 'h5' | 'ios' | 'android' | 'app' | 'public';

export interface ClientTypeOption {
  label: string;
  value: ClientType;
  [key: string]: unknown;
}

export interface ClientTypeMapItem {
  label: string;
  type: 'info' | 'success' | 'warning' | 'error' | 'default';
}

export function useClientTypeOptions() {
  const { t } = useI18n();

  const options = computed<ClientTypeOption[]>(() => [
    { label: t('tenant.styleManage.clientWeb'), value: 'web' },
    { label: t('tenant.styleManage.clientH5'), value: 'h5' },
    { label: t('tenant.styleManage.clientIos'), value: 'ios' },
    { label: t('tenant.styleManage.clientAndroid'), value: 'android' },
    { label: t('tenant.styleManage.clientApp'), value: 'app' },
    { label: t('tenant.styleManage.clientPublic'), value: 'public' },
  ]);

  const map = computed<Record<ClientType, ClientTypeMapItem>>(() => ({
    web: { label: t('tenant.styleManage.clientWeb'), type: 'info' },
    h5: { label: t('tenant.styleManage.clientH5'), type: 'success' },
    ios: { label: t('tenant.styleManage.clientIos'), type: 'warning' },
    android: { label: t('tenant.styleManage.clientAndroid'), type: 'success' },
    app: { label: t('tenant.styleManage.clientApp'), type: 'default' },
    public: { label: t('tenant.styleManage.clientPublic'), type: 'default' },
  }));

  return {
    options,
    map,
  };
}
