/**
 * 表单校验助手（会员控件落地 Step 2 · 校验红框基线）。
 * naive `n-form` 的 rules + `validate()` 天然在对应 n-form-item 显示红框反馈；
 * 本文件统一"校验通过才提交"的调用方式与常用 rule 工厂，供各弹窗复用（[[save-validation-redbox]]）。
 */
import type { Ref } from 'vue';
import type { FormInst, FormItemRule } from 'naive-ui';

/** 校验通过才执行 run；失败时 naive 自动在对应 n-form-item 显示红框反馈并阻断提交 */
export async function validateThenRun(
  formRef: Ref<FormInst | null | undefined>,
  run: () => void | Promise<void>,
): Promise<void> {
  const inst = formRef.value;
  if (!inst) {
    await run();
    return;
  }
  try {
    await inst.validate();
  } catch {
    return; // 校验失败：naive 已红框标错字段，阻断提交
  }
  await run();
}

/**
 * 必填。用通用非空 `validator`（而非仅 `required:true`）判空——
 * 原因：requiredRule 带了 `trigger` 键后，async-validator 不再走「纯 required 校验」，
 * 会退回按默认 `type:'string'` 校验；商户等**数字型下拉值(tenantId=1050)** 非字符串 →
 * 被判类型不符 → 选了值仍报必填红框、且换任何商户都是数字永远过不了（会员列表/在线人数踩坑）。
 * 提供 `validator` 后 async-validator 只跑它，数字/字符串/数组都能正确判空。
 * trigger 含 'change'：下拉框(n-select)选中触发的是 change 而非 input，缺它则 blur 才清红框。
 */
export const requiredRule = (message: string): FormItemRule => ({
  required: true,
  validator(_rule, value) {
    const empty =
      value === null ||
      value === undefined ||
      value === '' ||
      (Array.isArray(value) && value.length === 0);
    return empty ? new Error(message) : true;
  },
  message,
  trigger: ['blur', 'input', 'change'],
});

/** 必须为正数（>0） */
export const positiveNumberRule = (message: string): FormItemRule => ({
  validator: (_r, v) => v != null && v !== '' && Number(v) > 0,
  message,
  trigger: ['blur', 'input'],
});

/** 最小长度 */
export const minLenRule = (n: number, message: string): FormItemRule => ({
  validator: (_r, v) => typeof v === 'string' && v.length >= n,
  message,
  trigger: ['blur', 'input'],
});
