/**
 * 本地数据工具：分页、模糊过滤、envelope 包装
 * 供每页 data.ts 使用，不引入任何 HTTP 概念。
 */

export interface LocalPageResult<T> {
  list: T[];
  total: number;
}

export interface Envelope<T> {
  code: number;
  result: boolean;
  data: T;
  msg: string;
}

export function localPaginate<T>(list: T[], page = 1, pageSize = 20): LocalPageResult<T> {
  const p = Number(page) || 1;
  const ps = Number(pageSize) || 20;
  const start = (p - 1) * ps;
  return { list: list.slice(start, start + ps), total: list.length };
}

export function fuzzyFilter<T>(list: T[], keyword: string | undefined, fields: (keyof T)[]): T[] {
  if (!keyword) return list;
  const kw = String(keyword).toLowerCase();
  return list.filter((item) =>
    fields.some((f) =>
      String(item[f] ?? '')
        .toLowerCase()
        .includes(kw),
    ),
  );
}

export function ok<T>(data: T, msg = 'success'): Envelope<T> {
  return { code: 0, result: true, data, msg };
}

export function okNull(msg = 'success'): Envelope<null> {
  return { code: 0, result: true, data: null, msg };
}
