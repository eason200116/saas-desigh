/**
 * * base64图片转换为File对象
 * @param {string} dataurl - base64字符串
 * @param {string} filename - 文件名
 * @return {File} - 返回File对象
 */
export function dataURLtoFile(dataurl, filename) {
  var arr = dataurl.split(','),
    mime = arr[0].match(/:(.*?);/)[1],
    bstr = atob(arr[1]),
    n = bstr.length,
    u8arr = new Uint8Array(n);
  while (n--) {
    u8arr[n] = bstr.charCodeAt(n);
  }
  return new File([u8arr], filename, { type: mime });
}

/**
 * 下载 Blob 文件
 * @param {Blob} blob - Blob 数据
 * @param {string} filename - 文件名
 */
export function downloadblob(blob: Blob, filename: string) {
  const url = window.URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = `${filename}.xlsx`;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  window.URL.revokeObjectURL(url);
}

/**
 * 通过 URL 下载文件
 * @param {string} url - 文件 URL
 * @param {string} filename - 可选文件名
 */
export function downloadUrl(url: string, filename?: string) {
  const link = document.createElement('a');
  link.href = url;
  if (filename) {
    link.download = filename;
  }
  link.target = '_blank';
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}
