/**
 * @function configToOptions 将数据配置转换为Select组件可用的options配置
 * @param {Array<any>} config 需要处理的数据
 * @param {{ label: string, value: string }} keyVal 源数据需要取出的label和value字段
 * @return SelectProps.options
 * */
export const configToOptions = (config, keyVal = { value: 'id', label: 'name' }) => {
  const options: Array<{ label: string; value: string | number }> = [{ label: '全部', value: '' }];

  config.forEach((e) => {
    const { label, value } = keyVal;

    options.push({
      label: e[label],
      value: e[value],
    });
  });

  return options;
};
// 根据值获取相应数组中标签
export const getLabelByValue = (list: any[], value: number) => {
  if (!list || list.length === 0) return '';
  console.log('list', list, value);
  const item = list.find((item) => item.value === value);
  return item ? item.label : '';
};

export const getLanguageText = (langText) => {
  return langText.map((item) => `${item.language}：${item.name}`).join(',');
};

/**
 * 将字符串中的英文/中文逗号替换为换行符
 * @param {string} str - 输入字符串
 * @param {boolean} useBr - 是否使用 <br>（默认 false，使用 \n）
 * @returns {string} - 格式化后的字符串
 */
export const formatWithLineBreaks = (str) => {
  if (!str) return '';
  const regex = /,|，/;
  // 没有逗号，直接返回原字符串
  if (!regex.test(str)) {
    return str;
  }
  return str.replace(/,|，/g, '\n');
};

/**
 * n-input 的 allow-input 校验器：只允许输入正整数数字字符（空串放行以便清空）
 * 用法：<n-input :allow-input="onlyDigits" /> 或 componentProps: { allowInput: onlyDigits }
 */
export const onlyDigits = (value: string): boolean => value === '' || /^\d+$/.test(value);

/**
 * n-input 的 allow-input 校验器：只允许数字和空格（支持多ID以空格分隔的查询）
 */
export const onlyDigitsWithSpace = (value: string): boolean =>
  value === '' || /^[\d ]*$/.test(value);
