// 货币过滤器
import { useUserStore } from '@/store/modules';
import { isArray, isObject } from './is';
import DOMPurify from 'dompurify';
import { i18n } from '@/i18n';

// 必须用函数式 alias 而非顶层解构 i18n.global —— Rolldown 在 manualChunks 拆分下，
// 业务 chunk 反向 import @/i18n 容易触发 ESM 循环 + TDZ，顶层读 .global 会得到 undefined。
const t = (key: string): string => i18n.global.t(key);
const CURRENCY_GROUPING_REGEXP = /\B(?=(\d{3})+(?!\d))/g;

/**
 * 格式化货币金额。
 *
 * @param value 金额值，支持数字、数字字符串、null、undefined
 * @param _currency 货币符号，不传时默认读取 sessionStorage 中的 `dollarSign`
 * @param decimals 小数位数，默认保留 2 位
 * @param useGrouping 是否显示千分位分隔符，默认显示
 * @returns 格式化后的货币字符串；当输入无法解析为数字时返回空字符串
 */
export const currency = (
  value: number | string | null | undefined,
  _currency = '',
  decimals = 2,
  useGrouping = true,
) => {
  const parsed = parseFloat(String(value ?? 0));
  if (!isFinite(parsed)) return '';
  const currencySymbol = _currency || sessionStorage.getItem('dollarSign') || ''; //加默认值是因为如果没有获取到后台数据会显示null
  const precision = Number.isFinite(Number(decimals)) ? Math.max(0, Number(decimals)) : 2;
  const stringified = Math.abs(parsed).toFixed(precision);
  const [integerPart, decimalPart] = stringified.split('.');
  const groupedIntegerPart = useGrouping
    ? integerPart.replace(CURRENCY_GROUPING_REGEXP, ',')
    : integerPart;
  const sign = parsed < 0 ? '-' : '';
  const fractionPart = precision > 0 ? `.${decimalPart ?? ''}` : '';
  return `${sign}${currencySymbol}${groupedIntegerPart}${fractionPart}`;
};

// 判断对象中每个属性是否为空或undefined或null，是就删除此属性，返回其余的属性
export const removeEmptyOrNullProperties = (obj: any) => {
  if (obj === null || obj === undefined) {
    return obj;
  }
  const newObj = {};
  for (const key in obj) {
    if (obj.hasOwnProperty(key) && obj[key] !== null && obj[key] !== undefined && obj[key] !== '') {
      newObj[key] = obj[key];
    }
  }
  return newObj;
};

/*导出表头处理转换*/
export const createExportTitleList = (columns: Array<{ key?: string; title: string }>) => {
  const titleList: Record<string, string> = {};
  columns.forEach((item: any) => {
    if (item.key) {
      titleList[item.key] = item.title;
    }
    if (item.children && item.children.length > 0) {
      item.children.forEach((child) => {
        if (child.key) {
          titleList[child.key] = `${item.title}-${child.title}`;
        }
      });
    }
  });
  return titleList;
};

// 惰性初始化：原本 rechargeType 是顶层对象字面量，会在模块初始化时调用 6 次 t(...)，
// 一旦该模块在 ESM 循环路径上就会触发与 i18n 之间的 TDZ。改成首次访问时才求值，并 memoize 结果。
const buildRechargeTypeMap = () => ({
  ManualRecharge: { label: t('common.rechargeType.manualRecharge'), value: 'ManualRecharge' },
  LocalBank: { label: t('common.rechargeType.localBank'), value: 'LocalBank' },
  LocalUSDT: { label: t('common.rechargeType.localUSDT'), value: 'LocalUSDT' },
  LocalEWallet: { label: t('common.rechargeType.localEWallet'), value: 'LocalEWallet' },
  LocalUPI: { label: t('common.rechargeType.localUPI'), value: 'LocalUPI' },
  ThirdRecharge: { label: t('common.rechargeType.thirdRecharge'), value: 'ThirdRecharge' },
});
let rechargeTypeCache: ReturnType<typeof buildRechargeTypeMap> | null = null;
export const rechargeType = new Proxy({} as ReturnType<typeof buildRechargeTypeMap>, {
  get(_, key: string | symbol) {
    rechargeTypeCache ??= buildRechargeTypeMap();
    return rechargeTypeCache[key as keyof ReturnType<typeof buildRechargeTypeMap>];
  },
});
// 完整图片路径
export const getFullImageUrl = (shortPath: string): string => {
  if (!shortPath) return '';
  if (shortPath.startsWith('http')) return shortPath;

  const baseUrl = useUserStore().getV3OssImageUrl.replace(/\/$/, '');
  if (!baseUrl) return shortPath;

  return `${baseUrl}${shortPath.startsWith('/') ? '' : '/'}${shortPath}`;
};

export function sortObject(obj: any) {
  const sortedObj: any = {};
  const keys = Object.keys(obj)
    .filter((key) => {
      return !(isArray(obj[key]) || obj[key] === '');
    })
    .sort();
  keys.forEach((key) => {
    if (obj[key] !== null && obj[key] !== '') {
      if (isObject(obj[key])) {
        sortedObj[key] = sortObject(obj[key]);
      } else {
        sortedObj[key] = obj[key] === 0.0 ? 0.0 : obj[key];
      }
    }
  });
  return sortedObj;
}

export const delay = (time: number) => {
  return new Promise((resolve) => setTimeout(resolve, time));
};

/** * 解码 HTML 实体
 * @param html - 包含 HTML 实体的字符串
 * @return 解码后的字符串
 */
export function decodeHtml(html: string) {
  const txt = document.createElement('textarea');
  txt.innerHTML = html;
  // 第一次解码：将 &lt; 转换为 <
  const firstPass = txt.value;
  txt.innerHTML = firstPass;
  // 第二次解码
  return txt.value;
}

/**
 * 编码 HTML 实体
 * @param str - 普通字符串
 * @return 编码后的 HTML 字符串
 */
export function encodeHtml(str: string): string {
  const txt = document.createElement('textarea');
  txt.textContent = str;
  return txt.innerHTML;
}

/**
 * @param html
 * @return 过滤掉不安全的 HTML 标签和属性
 */
export function getSafeHtml(html: string): string {
  if (!html) return '';
  const decodeHtmlText = decodeHtml(html);
  const safeHtml = DOMPurify.sanitize(decodeHtmlText, {
    FORBID_TAGS: ['iframe', 'object', 'link', 'style', 'script'],
  });
  return safeHtml;
}

/**
 * 富文本 HTML 转纯文本（去标签 + 合并空白）。
 * 用于列表/摘要处只展示纯文本、以及判断富文本是否为空（空编辑器 `<p></p>` → ''）。
 */
export function htmlToPlainText(html: string): string {
  if (!html) return '';
  const el = document.createElement('div');
  el.innerHTML = getSafeHtml(html);
  return (el.textContent || '').replace(/\s+/g, ' ').trim();
}
