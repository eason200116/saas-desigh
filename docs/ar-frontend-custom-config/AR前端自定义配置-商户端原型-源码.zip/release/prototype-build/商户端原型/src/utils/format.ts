/**
 * @description 报表与 KPI 通用数值格式化工具：分母为 0 / null / NaN 的安全除法、0~1 比率转百分比、环比同比变化率，避免 NaN%、Infinity、0% 等口径污染。
 * @date.  26-05-01
 * @scope src/utils/format.ts，KPI / 报表 / 数据看板共用
 */

/**
 * 把任意值转为有限数字；不能解析时返回 null（区分 0）。
 */
function toFiniteNumber(value: unknown): number | null {
  if (value === null || value === undefined || value === '') return null;
  const parsed = typeof value === 'number' ? value : Number(value);
  return Number.isFinite(parsed) ? parsed : null;
}

/**
 * 安全除法：分母为 0 / null / NaN 时返回 fallback；分子为 0 时返回 0（保留可计算语义）。
 *
 * 适用：成功率、达成率、占比等需要"分母 0 不展示 0%/NaN%"的场景。
 *
 * @example
 * safeDivide(0, 0) // → '--'
 * safeDivide(8, 10) // → 0.8
 * safeDivide(0, 100) // → 0
 */
export function safeDivide(
  numerator: unknown,
  denominator: unknown,
  fallback: string = '--',
): number | string {
  const num = toFiniteNumber(numerator);
  const den = toFiniteNumber(denominator);
  if (den === null || den === 0) return fallback;
  if (num === null) return fallback;
  return num / den;
}

/**
 * 0~1 比率转百分比字符串。null / 非数 / 字符串 '--' → fallback。
 *
 * @example
 * formatRate(0.9543) // → '95.43%'
 * formatRate(null)   // → '--'
 * formatRate('--')   // → '--'
 */
export function formatRate(value: unknown, decimals: number = 2, fallback: string = '--'): string {
  if (typeof value === 'string' && value.trim() === '--') return fallback;
  const parsed = toFiniteNumber(value);
  if (parsed === null) return fallback;
  return `${(parsed * 100).toFixed(decimals)}%`;
}

/**
 * 已经是百分数（如 95.43）时直接格式化为百分比字符串，不再 ×100。
 *
 * @example
 * formatPercent(95.43) // → '95.43%'
 */
export function formatPercent(
  value: unknown,
  decimals: number = 2,
  fallback: string = '--',
): string {
  const parsed = toFiniteNumber(value);
  if (parsed === null) return fallback;
  return `${parsed.toFixed(decimals)}%`;
}

/**
 * 环比 / 同比变化率：(curr - prev) / prev × 100%。prev=0 / null → fallback；
 * 返回 { rate, label, type }，由调用方决定上升下降图标和颜色。
 *
 * @example
 * formatCompare(120, 100) // → { rate: 0.2, label: '+20.00%', type: 'up' }
 * formatCompare(80, 100)  // → { rate: -0.2, label: '-20.00%', type: 'down' }
 * formatCompare(100, 0)   // → { rate: null, label: '--', type: 'flat' }
 */
export interface CompareResult {
  /** 变化率（0~1 / 可负），无法计算时为 null */
  rate: number | null;
  /** 已带 +/- 号与百分号的展示文案 */
  label: string;
  /** 上升 / 下降 / 持平（含无法计算情况） */
  type: 'up' | 'down' | 'flat';
}

export function formatCompare(
  curr: unknown,
  prev: unknown,
  decimals: number = 2,
  fallback: string = '--',
): CompareResult {
  const c = toFiniteNumber(curr);
  const p = toFiniteNumber(prev);
  if (c === null || p === null || p === 0) {
    return { rate: null, label: fallback, type: 'flat' };
  }
  const rate = (c - p) / p;
  const sign = rate > 0 ? '+' : rate < 0 ? '' : '';
  const label = `${sign}${(rate * 100).toFixed(decimals)}%`;
  const type = rate > 0 ? 'up' : rate < 0 ? 'down' : 'flat';
  return { rate, label, type };
}

/**
 * 当输入已经是后端返回的同比变化率（0~1，可负，已经表示百分比的小数形式），
 * 直接转成 +/- 标签 + 上升下降类型。用于 GetRealtimeSummary 的 netChangeRate / changeRate。
 *
 * @example
 * formatChangeRate(0.062)  // → { rate: 0.062, label: '+6.20%', type: 'up' }
 * formatChangeRate(-0.021) // → { rate: -0.021, label: '-2.10%', type: 'down' }
 * formatChangeRate(null)   // → { rate: null, label: '--', type: 'flat' }
 */
export function formatChangeRate(
  value: unknown,
  decimals: number = 2,
  fallback: string = '--',
): CompareResult {
  const parsed = toFiniteNumber(value);
  if (parsed === null) return { rate: null, label: fallback, type: 'flat' };
  const sign = parsed > 0 ? '+' : parsed < 0 ? '' : '';
  const label = `${sign}${(parsed * 100).toFixed(decimals)}%`;
  const type = parsed > 0 ? 'up' : parsed < 0 ? 'down' : 'flat';
  return { rate: parsed, label, type };
}
