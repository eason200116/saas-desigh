import { VNodeChild, StyleValue } from 'vue';
import { toValidableType } from 'vue-types';

export type VueNode = VNodeChild | JSX.Element;

export class propTypes {
  static get style() {
    return toValidableType<StyleValue>('style', {
      type: [String, Object],
      default: undefined,
    });
  }
  static get VNodeChild() {
    return toValidableType<VueNode>('VNodeChild', {
      type: undefined,
    });
  }
  static get bool() {
    return toValidableType<VueNode>('bool', {
      type: Boolean,
    });
  }
  static get number() {
    return toValidableType<VueNode>('number', {
      type: Number,
    });
  }
}
