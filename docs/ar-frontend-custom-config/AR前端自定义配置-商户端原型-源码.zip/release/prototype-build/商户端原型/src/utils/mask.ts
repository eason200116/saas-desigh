/**
 * 敏感信息脱敏工具（全站统一）
 *
 * 仅用于「展示脱敏」——只改变列表/详情里渲染出来的文本，不改动底层数据；
 * 搜索框、编辑弹窗等仍使用完整值。
 *
 * - maskEmail：本地名保留前 3 位 + **** + @域名（不足 3 位则有几位显示几位，不补位）
 *     例：member12@example.com → mem****@example.com
 * - maskPhone：保留「+区号」前缀 + 号码主体前 3 位 + **** + 后 4 位（号码主体不足 8 位时仅前 3 位 + ****）
 *     例：+86 13800138000 → +86 138****8000 ；13800138000 → 138****8000（无区号向后兼容）
 * - maskId：会员ID/用户ID 保留前 3 位 + 后 3 位，中间逐位打星，星号个数 = 总长 − 6，总位数不变
 *     例：123456789 → 123***789 ；88012345 → 880**345
 */

export function maskEmail(email?: string | number | null): string {
  const s = email == null ? '' : String(email).trim();
  if (!s) return '';
  const at = s.indexOf('@');
  // 无 @ 或 @ 在首位：非法邮箱，原样返回不臆造
  if (at <= 0) return s;
  return `${s.slice(0, 3)}****${s.slice(at)}`;
}

export function maskPhone(phone?: string | number | null): string {
  const s = phone == null ? '' : String(phone).trim();
  if (!s) return '';
  // 拆出「+区号」前缀（如 "+86 138…" / "+855 12…"）；无区号则整串按号码主体（向后兼容）
  const m = s.match(/^(\+\d{1,4})[\s-]*(.*)$/);
  const cc = m ? m[1] : '';
  const num = (m ? m[2] : s).replace(/\s+/g, '');
  // 号码主体太短（<8 位）无法「前3+后4」，仅保留前 3 位，其余遮蔽
  const masked =
    num.length <= 7 ? `${num.slice(0, 3)}****` : `${num.slice(0, 3)}****${num.slice(-4)}`;
  return cc ? `${cc} ${masked}` : masked;
}

export function maskId(id?: string | number | null): string {
  const s = id == null ? '' : String(id).trim();
  const n = s.length;
  if (!n) return '';
  // 短于 7 位无法「前3+后3」不重叠：退化为保留首尾各 1 位、中间打星（仍保持总位数不变）；
  // 本系统会员ID为 8 位起，正常走下方 slice 分支。
  if (n <= 6) {
    if (n <= 2) return '*'.repeat(n);
    return `${s[0]}${'*'.repeat(n - 2)}${s[n - 1]}`;
  }
  return `${s.slice(0, 3)}${'*'.repeat(n - 6)}${s.slice(-3)}`;
}
