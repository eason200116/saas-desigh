/**
 * 原型项目：权限码 → 页面标题反查工具降级为 no-op。
 * 保留导出签名以兼容视图层已有引用（system/log），避免编译错误。
 */

export function initPermissionLabelMap(): void {
  // no-op
}

export function getPermissionTitleKey(code: string): string {
  return code;
}

export function getPermissionLabelMap(): ReadonlyMap<string, string> {
  return new Map();
}

export function getReferencedNamespaces(): string[] {
  return [];
}

/**
 * 把 menuRoute（形如 `Module:Sub:Page:Action`）拆成"操作前的层级列表"。
 * 降级实现：直接返回原始 segment 字符串作为占位（log 页面会以 t(key) 翻译，
 * 翻译不到时会原样显示 segment，比返回空数组更易于 debug）。
 */
export function resolveMenuRouteTitleKeys(menuRoute?: string | null): string[] {
  const segments = String(menuRoute || '')
    .split(':')
    .map((s) => s.trim())
    .filter(Boolean);
  if (segments.length <= 1) return segments;
  return segments.slice(0, -1);
}
