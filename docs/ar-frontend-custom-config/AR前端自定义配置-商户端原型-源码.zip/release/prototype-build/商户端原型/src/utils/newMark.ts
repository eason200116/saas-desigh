import { h, type VNode } from 'vue';
import { i18n } from '@/i18n';

// 「新」标文案跟随语言（中文「新」/ 英文「New」）；在渲染时取值，切换语言即刷新
const newText = () => i18n.global.t('common.newBadge');

/**
 * 迁移期临时「新」标记工具。
 *
 * 用途：把本轮"新增"的列 / 功能在页面上标「新」，方便研发区分「新增」与「原有」。
 * 视觉：刻意低调——小字 + 低饱和琥珀色 + 极浅底，不抢眼但仍可区分（与 MegaMenu 新/原/移 一致）。
 *
 * 批量去除（迁移收尾时）：
 *  1. 一键隐藏全部「新」标 —— 把 {@link NEW_MARK_ENABLED} 置为 false；
 *  2. 彻底清理 —— 全局搜索 `markNewTitle` / `renderNewBadge` 删除调用，再删除本文件。
 */
export const NEW_MARK_ENABLED = true;

/**
 * 低调「新」标内联样式 —— 与 MegaMenu `.mega-tag--new` 视觉统一。
 */
export const NEW_MARK_STYLE =
  'display:inline-flex;align-items:center;font-size:10px;line-height:15px;padding:0 5px;border-radius:3px;color:#c08a4a;background:#faf4ec;font-weight:400;letter-spacing:.5px;';

/**
 * 列标题加「新」小标。
 * 传入标题字符串，返回可直接作为 ProColumn.title 的渲染函数；关闭标记时回退为原字符串。
 */
export function markNewTitle(title: string): string | (() => VNode) {
  if (!NEW_MARK_ENABLED) return title;
  return () =>
    h('span', { style: 'display:inline-flex;align-items:center;gap:4px;white-space:nowrap;' }, [
      title,
      h('span', { style: NEW_MARK_STYLE }, newText()),
    ]);
}

/**
 * 行内「新」小标，给按钮 / 功能入口等用；关闭标记时返回 null。
 */
export function renderNewBadge(): VNode | null {
  if (!NEW_MARK_ENABLED) return null;
  return h('span', { style: NEW_MARK_STYLE }, newText());
}
