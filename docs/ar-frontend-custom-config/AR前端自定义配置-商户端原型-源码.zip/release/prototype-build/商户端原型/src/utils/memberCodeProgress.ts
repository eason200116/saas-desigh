// 会员「打码进度」共享数据（会员列表 ↔ 会员详情 保持一致）
//
// 口径（用户确认）：以【会员列表 amountOfCode 枚举】为标准——
//   · 列表渲染时按 userId 把 amountOfCode 播种进 store（首次为准，不覆盖已编辑值）；
//   · 需要打码量 = 播种时 已完成 × 列表系数枚举 [1,1.3,2,4][userId%4] 定初值，之后可被详情编辑覆盖；
//   · 会员详情按同一 userId 读同样的 已完成/需要，两处必然一致；
//   · 编辑「需要打码量」→ setCodeNeed 只改「需要」，「已完成」按列表标准不动，仅重算进度 = 已完成 ÷ 需要；
//   · 列表 + 详情下次读都拿新「需要」→ 两处进度条一并更新。
// 参照 src/api/index.ts 的 memberIntegralStore（可编辑持久 mock）模式，纯前端内存态、无后端。

const doneStore = new Map<number, number>();
const needStore = new Map<number, number>();

/** 列表系数枚举：需要打码量 = 已完成打码量 × 此系数（按 userId % 4 稳定取样，R32 多样） */
export const CODE_FACTORS = [1, 1.3, 2, 4];

function factorOf(userId: number | string): number {
  const id = Math.abs(Number(userId) || 0);
  return CODE_FACTORS[id % CODE_FACTORS.length];
}

/** 播种：首次见到该会员，用（列表 amountOfCode）定 已完成(标准) + 需要(=已完成×系数，固定)；已存在则保留、不覆盖编辑值 */
export function seedCode(userId: number | string, done: number): void {
  const id = Number(userId);
  const d = Number(done) || 0;
  if (!doneStore.has(id)) doneStore.set(id, d);
  if (!needStore.has(id)) needStore.set(id, d * factorOf(id));
}

/** 读已完成打码量：优先 store（列表标准/编辑后值），否则用兜底值 */
export function getCodeDone(userId: number | string, fallback = 0): number {
  const id = Number(userId);
  return doneStore.has(id) ? (doneStore.get(id) as number) : Number(fallback) || 0;
}

/** 写已完成打码量（编辑用）：只改「已完成」，「需要」不动；列表 + 详情下次读都拿新值 */
export function setCodeDone(userId: number | string, done: number): void {
  doneStore.set(Number(userId), Number(done) || 0);
}

/** 读需要打码量：优先 store（播种初值或编辑后值）；未播种时兜底 = fallbackDone × 系数 */
export function getCodeNeed(userId: number | string, fallbackDone = 0): number {
  const id = Number(userId);
  return needStore.has(id) ? (needStore.get(id) as number) : (Number(fallbackDone) || 0) * factorOf(id);
}

/** 写需要打码量（编辑用）：只改「需要」，「已完成」不动；列表 + 详情下次读都拿新值 */
export function setCodeNeed(userId: number | string, need: number): void {
  needStore.set(Number(userId), Number(need) || 0);
}

/** 打码进度% = 已完成 ÷ 需要 × 100（封顶 100；需要=0 → 100） */
export function getCodePct(done: number, need: number): number {
  return need > 0 ? Math.max(0, Math.min(100, Math.round((Number(done) / need) * 100))) : 100;
}
