import { isPromise, isAsyncFunction } from './is';

export type Interceptor = (...args: any[]) => Promise<boolean> | boolean | undefined | void;
const noop = () => {};
export function callInterceptor(
  interceptor: Interceptor | undefined,
  {
    args = [],
    done,
    canceled,
    error,
  }: {
    args?: unknown[];
    done: () => void;
    canceled?: () => void;
    error?: () => void;
  },
) {
  if (interceptor) {
    // eslint-disable-next-line prefer-spread
    const returnVal = interceptor.apply(null, args);
    if (isPromise(interceptor) || isAsyncFunction(interceptor)) {
      //@ts-ignore
      returnVal
        .then((value) => {
          if (value) {
            done();
          } else if (canceled) {
            canceled();
          }
        })
        .catch(error || noop);
    } else if (returnVal) {
      done();
    } else if (canceled) {
      canceled();
    }
  } else {
    done();
  }
}
