import { h, unref } from 'vue';
import type { App, Plugin, Component } from 'vue';
import { NIcon } from 'naive-ui';
import { cloneDeep } from 'lodash-es';
import { PageEnum } from '@/enums';
import { isObject } from './is';
import { i18n } from '@/i18n';
/**
 * render 图标
 * */
export function renderIcon(icon) {
  return () => h(NIcon, null, { default: () => h(icon) });
}

/**
 * 子类型分组：把已生成的菜单项里带 `group`（i18n key）的同组项归入 `type:'group'` 分组头，
 * 不带 group 的保持平铺。分组头按"首次出现"顺序排列。无任何分组项时原样返回。
 *
 * 用 `type:'group'`（而非"带 children 的子菜单"）：下拉一打开即把"子类型标题 + 其下所有页面入口"
 * 平铺直接显示，操作人员一目了然，无需再悬停二级 fly-out。分组头无 path、不可点、不触发导航。
 */
function applyGroups(items: Array<any>) {
  if (!items.some((it) => it && it.group)) return items;
  const t = i18n.global.t;
  const result: any[] = [];
  const groupMap = new Map<string, any>();
  items.forEach((it) => {
    const g = it && it.group;
    if (!g) {
      result.push(it);
      return;
    }
    let node = groupMap.get(g);
    if (!node) {
      node = { type: 'group', label: t(g), key: `group-${g}`, children: [] };
      groupMap.set(g, node);
      result.push(node);
    }
    node.children.push(it);
  });
  return result;
}

/**
 * 递归组装菜单格式
 */
export function generatorMenu(routerMap: Array<any>) {
  return filterRouter(routerMap).map((item) => {
    const isRoot = isRootRouter(item);
    const t = i18n.global.t;
    const info = item;
    const currentMenu = {
      ...info,
      ...info.meta,
      label: info.meta?.title ? t(info.meta?.title) : info.meta?.title,
      key: info.name,
      icon: isRoot ? item.meta?.icon : info.meta?.icon,
    };
    if (info.meta?.title) {
      currentMenu.title = t(info.meta?.title);
    }
    // 是否有子菜单，并递归处理（子级按 group 归入子类型分组头）
    if (info.children && info.children.length > 0) {
      // Recursion
      currentMenu.children = applyGroups(generatorMenu(info.children));
    }
    return currentMenu;
  });
}

/**
 * 混合菜单
 * */
export function generatorMenuMix(routerMap: Array<any>, routerName: string, location: string) {
  const cloneRouterMap = cloneDeep(routerMap);
  const newRouter = filterRouter(cloneRouterMap);
  const t = i18n.global.t;
  if (location === 'header') {
    const firstRouter: any[] = [];
    newRouter.forEach((item) => {
      const isRoot = isRootRouter(item);
      const info = isRoot ? item.children[0] : item;
      info.children = undefined;
      const rawTitle = info.meta?.title;
      const translated = rawTitle ? t(rawTitle) : rawTitle;
      const currentMenu = {
        ...info,
        ...info.meta,
        label: translated,
        title: translated,
        key: info.name,
      };
      firstRouter.push(currentMenu);
    });
    return firstRouter;
  } else {
    return getChildrenRouter(newRouter.filter((item) => item.name === routerName));
  }
}

/**
 * 递归组装子菜单
 * */
export function getChildrenRouter(routerMap: Array<any>) {
  const t = i18n.global.t;
  return filterRouter(routerMap).map((item) => {
    const isRoot = isRootRouter(item);
    const info = isRoot ? item.children[0] : item;
    const translated = info.meta?.title ? t(info.meta.title) : info.meta?.title;
    const currentMenu = {
      ...info,
      ...info.meta,
      label: translated,
      title: translated,
      key: info.name,
    };
    // 是否有子菜单，并递归处理（子级按 group 归入子类型分组头）
    if (info.children && info.children.length > 0) {
      // Recursion
      currentMenu.children = applyGroups(getChildrenRouter(info.children));
    }
    return currentMenu;
  });
}

/**
 * 判断根路由 Router
 * */
export function isRootRouter(item) {
  return (
    item.meta?.alwaysShow != true &&
    item?.children?.filter((item) => !item?.meta?.hidden)?.length === 1
  );
}

/**
 * 排除Router
 * */
export function filterRouter(routerMap: Array<any>) {
  return routerMap.filter((item) => {
    return (
      (item.meta?.hidden || false) != true &&
      !['/:path(.*)*', '/', PageEnum.REDIRECT, PageEnum.BASE_LOGIN].includes(item.path)
    );
  });
}

export const withInstall = <T extends Component>(component: T, alias?: string) => {
  const comp = component as any;
  comp.install = (app: App) => {
    app.component(comp.name || comp.displayName, component);
    if (alias) {
      app.config.globalProperties[alias] = component;
    }
  };
  return component as T & Plugin;
};
export function filterMenu(tree: any[], isDisabled = false) {
  tree.forEach((node) => {
    if (isDisabled) node.disabled = node.menuType !== 3;
    if (node.children && node.children.length > 0) {
      filterMenu(node.children, isDisabled);
    } else {
      delete node.children;
    }
  });
  return tree as any[];
}
export function flattenTree(tree: any[], result: any[] = []) {
  tree.forEach((node) => {
    const { children, ...rest } = node;
    result.push(rest);
    if (children && children.length > 0) {
      flattenTree(children, result);
    }
  });
  return result;
}
export function getTreeKey(tree: any[], key = 'id') {
  const keys: string[] = [];
  const mapTree = (list: any[], arr: string[]) => {
    list.forEach((node) => {
      arr.push(node[key]);
      if (node.children && node.children.length > 0) {
        mapTree(node.children, arr);
      }
    });
  };
  mapTree(tree, keys);
  return keys;
}
/**
 *  找到对应的节点
 * */
export function getTreeItem(data: any[], key?: string | number): any {
  for (const item of data) {
    if (item.id === key) {
      return item;
    }

    if (item.children && item.children.length) {
      const child = getTreeItem(item.children, key);
      if (child) {
        return child;
      }
    }
  }

  return null;
}

/**
 *  找到所有节点
 * */

export function getTreeAll(list: any[], isMenu = false): any[] {
  const treeAll: any[] = [];
  const deep = (data: any[]) => {
    data.map((item) => {
      if (isMenu) {
        if (item.menuType != 3) {
          treeAll.push(item.id);
        }
      } else {
        treeAll.push(item.id);
      }
      if (item.children && item.children.length) {
        deep(item.children);
      }
    });
  };
  deep(list);
  return treeAll;
}

// dynamic use hook props
export function getDynamicProps<T extends {}, U>(props: T): Partial<U> {
  const ret: Recordable = {};

  Object.keys(props).map((key) => {
    ret[key] = unref((props as Recordable)[key]);
  });

  return ret as Partial<U>;
}

export function deepMerge<T = any>(src: any = {}, target: any = {}): T {
  let key: string;
  for (key in target) {
    src[key] = isObject(src[key]) ? deepMerge(src[key], target[key]) : (src[key] = target[key]);
  }
  return src;
}

/**
 * Sums the passed percentage to the R, G or B of a HEX color
 * @param {string} color The color to change
 * @param {number} amount The amount to change the color by
 * @returns {string} The processed part of the color
 */
function addLight(color: string, amount: number) {
  const cc = parseInt(color, 16) + amount;
  const c = cc > 255 ? 255 : cc;
  return c.toString(16).length > 1 ? c.toString(16) : `0${c.toString(16)}`;
}

/**
 * Lightens a 6 char HEX color according to the passed percentage
 * @param {string} color The color to change
 * @param {number} amount The amount to change the color by
 * @returns {string} The processed color represented as HEX
 */
export function lighten(color: string, amount: number) {
  color = color.indexOf('#') >= 0 ? color.substring(1, color.length) : color;
  amount = Math.trunc((255 * amount) / 100);
  return `#${addLight(color.substring(0, 2), amount)}${addLight(
    color.substring(2, 4),
    amount,
  )}${addLight(color.substring(4, 6), amount)}`;
}
