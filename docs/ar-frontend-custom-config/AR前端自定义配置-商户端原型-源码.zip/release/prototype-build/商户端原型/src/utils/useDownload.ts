import { ref } from 'vue';
import { downloadblob } from './file';

type DownloadApiFn = (params: Record<string, unknown>) => Promise<Blob>;

interface DownloadOptions {
  fileName: string;
  params: Record<string, unknown>;
}

/**
 * 下载文件的 composable hook
 * @returns downLoading - 下载状态
 * @returns downLoad - 下载方法
 */
export function useDownload() {
  const downLoading = ref(false);

  const downLoad = async (apiFn: DownloadApiFn, options: DownloadOptions) => {
    downLoading.value = true;
    try {
      const blob = await apiFn(options.params);
      downloadblob(blob, options.fileName);
    } finally {
      downLoading.value = false;
    }
  };

  return {
    downLoading,
    downLoad,
  };
}
