/**
 * withSearchAnchors —— 给 ProCrudTable 的搜索列批量注入 DevLocator 悬停锚点。
 *
 * 悬停定位规范按 key 匹配搜索控件（而非中文标签，避免"登录IP"≠文档"IP"这类错配）。
 * 本助手把每个搜索列的 `path` 写进 `formItemProps['data-spec']`，
 * ProSearchBar → ProField → ProFormItem → n-form-item(v-bind) 透传到 DOM，
 * DevLocator `el.closest('[data-spec]')` 即可按 key 命中交互规则。
 *
 * 仅 dev 生效（生产返回原列，不加任何属性）。用法：
 *   const searchColumns = computed(() => withSearchAnchors([...列定义], 'm_', 'rec_'));
 *
 * @param cols 搜索列定义
 * @param prefix 规范表 key 前缀。搜索项 path 常与表格列 key 同名（如 tenantId），
 *   不加前缀时两者会撞进同一条规范；传 `'m_'` 让搜索项走 `m_<path>` 独立条目
 *   （搜索项=控件规范 spec、列=字段定义 fieldDef，语义本就不同）。默认空串保持既有页面行为不变。
 */
export function withSearchAnchors<T extends { path?: string; formItemProps?: any }>(
  cols: T[],
  prefix = '',
  manualPrefix?: string,
): T[] {
  const devOn = import.meta.env.DEV || import.meta.env.VITE_DEV_LOCATOR === '1';
  // manualPrefix 走 PageManual（正式面板、生产也显示），不受 dev 开关约束
  if (!devOn && !manualPrefix) return cols;
  return cols.map((c) => {
    if (!c || !c.path) return c;
    const formItemProps: Record<string, unknown> = { ...c.formItemProps };
    if (devOn) formItemProps['data-spec'] = `${prefix}${c.path}`;
    if (manualPrefix) formItemProps['data-manual'] = `${manualPrefix}${c.path}`;
    return { ...c, formItemProps };
  });
}

/**
 * withColKeys —— 给 ProCrudTable 的表格列批量注入 DevLocator 单元格锚点。
 *
 * naive n-data-table 默认不给 <td> 打列标识，DevLocator 的「按列 key 匹配字段词典」
 * 分支（el.closest('[data-col-key]')）因此对所有表格单元格整体失效——悬停只能取到
 * 单元格里的值文本，匹配必然落空、卡片全空白。
 *
 * 本助手把每列 `key` 写进该列 `cellProps` 返回的 `data-col-key`，naive 透传到每个 <td>，
 * DevLocator 即可按列 key（经 alias 桥接 + 交互性判定）命中 字段词典/交互规则。
 * 合并而非覆盖已有 cellProps；含 children 的分组列递归下钻到叶子列。
 *
 * 仅 dev 生效（生产返回原列，不加任何属性、零开销）。用法：
 *   const tableColumns = computed(() => withColKeys([...列定义]));
 */
export function withColKeys<T extends Record<string, any>>(cols: T[], manualPrefix?: string): T[] {
  const devOn = import.meta.env.DEV || import.meta.env.VITE_DEV_LOCATOR === '1';
  // manualPrefix 走 PageManual（正式面板、生产也显示），不受 dev 开关约束
  if (!devOn && !manualPrefix) return cols;
  const wrap = (c: any): any => {
    if (!c) return c;
    if (Array.isArray(c.children) && c.children.length) {
      return { ...c, children: c.children.map(wrap) };
    }
    if (c.key == null) return c;
    const key = String(c.key);
    const prev = c.cellProps;
    return {
      ...c,
      cellProps: (rowData: any, rowIndex: number) => {
        const props: Record<string, unknown> = {
          ...(typeof prev === 'function' ? prev(rowData, rowIndex) : prev || {}),
        };
        if (devOn) props['data-col-key'] = key;
        if (manualPrefix) props['data-manual'] = `${manualPrefix}col_${key}`;
        return props;
      },
    };
  };
  return cols.map(wrap);
}
