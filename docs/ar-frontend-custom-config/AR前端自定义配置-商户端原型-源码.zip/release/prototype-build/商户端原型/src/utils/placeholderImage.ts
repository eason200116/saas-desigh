// 自包含占位图（SVG data URI），无网络依赖 —— 供原型「示例图」使用。
// 用途：mock 数据里需要展示一张图但又不依赖外网时（如 logo、图标、封面占位）。
// 颜色按 label 取自固定调色板，保证同一 label 稳定、不同 label 多样（满足列表数据多样化）。

const PALETTE = [
  '#4f46e5',
  '#0891b2',
  '#16a34a',
  '#d97706',
  '#dc2626',
  '#7c3aed',
  '#0ea5e9',
  '#db2777',
];

function hashString(input: string): number {
  let h = 0;
  for (let i = 0; i < input.length; i++) h = (h * 31 + input.charCodeAt(i)) >>> 0;
  return h;
}

export function placeholderImage(
  label: string,
  opts: { w?: number; h?: number; bg?: string; fg?: string } = {},
): string {
  const w = opts.w ?? 320;
  const h = opts.h ?? 120;
  const fg = opts.fg ?? '#ffffff';
  const bg = opts.bg ?? PALETTE[hashString(label || '?') % PALETTE.length];
  const text = (label || '?').replace(/[-_]/g, ' ').trim().slice(0, 8);
  const fontSize = Math.max(10, Math.round(Math.min(w, h) / 3));
  const svg =
    `<svg xmlns="http://www.w3.org/2000/svg" width="${w}" height="${h}">` +
    `<rect width="100%" height="100%" rx="8" fill="${bg}"/>` +
    `<text x="50%" y="50%" dominant-baseline="central" text-anchor="middle" ` +
    `font-family="system-ui,Arial,sans-serif" font-size="${fontSize}" fill="${fg}">${text}</text>` +
    `</svg>`;
  return `data:image/svg+xml,${encodeURIComponent(svg)}`;
}
