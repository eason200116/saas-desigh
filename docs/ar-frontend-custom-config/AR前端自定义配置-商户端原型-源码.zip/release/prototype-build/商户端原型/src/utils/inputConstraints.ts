/**
 * 全站输入框约束预设注册表（唯一来源）。
 * 每个预设 = 输入上限 maxlength + 字符限制 allowInput（naive `n-input` 的 allow-input 校验器）。
 * allow-input 语义：返回 true 放行、false 拦截；空串一律放行以便清空/退格。
 *
 * 用法：
 *   模板  <n-input :maxlength="INPUT_PRESETS.name.maxlength" :allow-input="INPUT_PRESETS.name.allowInput" />
 *   render h(NInput, { value, 'onUpdate:value': set, ...inputProps('remark') })
 *   ProField { valueType:'input', componentProps: () => ({ ...inputProps('searchKw') }) }
 */
import { onlyDigits } from './form';

export type InputConstraint = {
  maxlength: number;
  allowInput: (v: string) => boolean;
  tip: string;
};

// —— 字符级校验器（空串一律放行，便于清空/退格）——
export const allowAccount = (v: string): boolean => v === '' || /^[A-Za-z0-9_]*$/.test(v);
export const allowPassword = (v: string): boolean => v === '' || /^[\x21-\x7e]*$/.test(v); // 可见 ASCII，无空格
export const allowAmount = (v: string): boolean => v === '' || /^\d*\.?\d{0,2}$/.test(v); // 数字+至多一个小数点、两位小数
export const allowCode = (v: string): boolean => v === '' || /^[A-Za-z0-9]*$/.test(v);
export const allowUrl = (v: string): boolean => v === '' || /^[\x21-\x7e]*$/.test(v); // URL 用 ASCII 可见字符
export const allowIp = (v: string): boolean => v === '' || /^[0-9a-fA-F.:]*$/.test(v);
export const allowEmail = (v: string): boolean => v === '' || /^[A-Za-z0-9._%+\-@]*$/.test(v); // 邮箱可见字符
// 任意文本：仅拦控制字符（含中文/符号照常输入）
export const allowText = (v: string): boolean => v === '' || !/[\x00-\x1f]/.test(v);

export const INPUT_PRESETS = {
  account: { maxlength: 20, allowInput: allowAccount, tip: '仅字母数字下划线' },
  password: { maxlength: 20, allowInput: allowPassword, tip: '仅可见字符，不含空格' },
  phone: { maxlength: 15, allowInput: onlyDigits, tip: '仅数字' },
  email: { maxlength: 40, allowInput: allowEmail, tip: '邮箱字符' },
  amount: { maxlength: 12, allowInput: allowAmount, tip: '数字，至多两位小数' },
  intNum: { maxlength: 9, allowInput: onlyDigits, tip: '仅整数' },
  name: { maxlength: 50, allowInput: allowText, tip: '不超过 50 字' },
  remark: { maxlength: 200, allowInput: allowText, tip: '不超过 200 字' },
  code: { maxlength: 32, allowInput: allowCode, tip: '仅字母数字' },
  url: { maxlength: 200, allowInput: allowUrl, tip: '合法 URL 字符' },
  searchKw: { maxlength: 50, allowInput: allowText, tip: '不超过 50 字' },
  ip: { maxlength: 45, allowInput: allowIp, tip: '数字、点、冒号、十六进制' },
} as const satisfies Record<string, InputConstraint>;

export type PresetKey = keyof typeof INPUT_PRESETS;

export function inputProps(key: PresetKey): {
  maxlength: number;
  allowInput: (v: string) => boolean;
} {
  const p = INPUT_PRESETS[key];
  return { maxlength: p.maxlength, allowInput: p.allowInput };
}
