import { useTimestamp } from '@vueuse/core';
import {
  differenceInDays,
  endOfDay,
  endOfMonth,
  endOfWeek,
  format,
  isAfter,
  isBefore,
  isSameDay,
  lastDayOfWeek,
  startOfDay,
  startOfMonth,
  startOfWeek,
  subDays,
  subMonths,
  subWeeks,
} from 'date-fns';
import { formatToCurrentZone, formatZoneTimeToLocal } from './dateUtil';

export const useUtils = () => {
  const timestamp = useTimestamp();
  const today = new Date();
  const yesterday = subDays(today, 1).getTime();
  const weekFirstDay = startOfWeek(today, { weekStartsOn: 1 }).getTime();
  const thisWeekEndDay = endOfWeek(today, { weekStartsOn: 1 }).getTime();
  const weekEndDay = isBefore(today, thisWeekEndDay) ? endOfDay(today).getTime() : thisWeekEndDay;
  const startWeekDay = startOfWeek(subWeeks(today, 1), { weekStartsOn: 1 }).getTime();
  const endWeekDay = new Date(
    format(lastDayOfWeek(subWeeks(today, 1), { weekStartsOn: 1 }), 'yyyy-MM-dd 23:59:59'),
  ).getTime();
  const mouthFirstDay = startOfMonth(today).getTime();
  const naturalMonthEnd = endOfMonth(today);
  const isLastDayOfMonth = today.getDate() === naturalMonthEnd.getDate();
  const mouthEndDay =
    isLastDayOfMonth || isBefore(today, naturalMonthEnd)
      ? endOfDay(today).getTime()
      : naturalMonthEnd.getTime();
  const startOfMonthDay = startOfMonth(subMonths(today, 1)).getTime();
  const endOfMonthDay = endOfMonth(subMonths(today, 1)).getTime();
  const isFirstDayOfMonth = isSameDay(startOfMonth(today), startOfDay(today));
  const todayStart = new Date(format(today, 'yyyy-MM-dd 00:00:00')).getTime();
  const todayEnd = new Date(format(today, 'yyyy-MM-dd 23:59:59')).getTime();
  const yesterdayStart = new Date(format(subDays(today, 1), 'yyyy-MM-dd 00:00:00')).getTime();
  const yesterdayEnd = new Date(format(subDays(today, 1), 'yyyy-MM-dd 23:59:59')).getTime();
  const recentWeekDay = subDays(today, 7).getTime();
  const dayTime = new Date().getTime();

  const validator = (_rule, value: number[]) => {
    if (value === null) return true;
    if (value && value.length !== 2) return new Error('请选择查询时间');
    const daysDifference = differenceInDays(value[1], value[0]);
    if (isAfter(value[1], endOfDay(new Date(formatToCurrentZone(Date.now(), true)).getTime()))) {
      return new Error(
        '结束时间不能大于' + format(endOfDay(new Date().getTime()), 'yyyy-MM-dd HH:mm:ss'),
      );
    }
    if (daysDifference > 30) {
      return new Error('请选择一个月内时间进行查询');
    }
    return true;
  };

  const dateDisabledExceedsDays = (days = 180) => {
    return (ts: number, type: 'start' | 'end', range: [number, number] | null) => {
      if (ts > endOfDay(today).getTime()) return true;
      if (type === 'start' && range !== null) {
        return (
          differenceInDays(new Date(formatToCurrentZone(Date.now(), true)).getTime(), ts) >= days
        );
      }
      if (type === 'end' && range !== null) {
        return ts > endOfDay(today).getTime();
      }
      return false;
    };
  };

  const isDateTimeDisabled = (ts: number) => {
    return ts > formatZoneTimeToLocal(timestamp.value);
  };

  const isDateDisabled = (ts: number) => {
    return ts > endOfDay(formatToCurrentZone(new Date().getTime())).getTime();
  };

  const isDatePreviousDisabled = (ts: number) => {
    return ts < startOfDay(formatToCurrentZone(new Date().getTime())).getTime();
  };

  const isDateNextDisabled = (ts: number) => {
    return ts <= endOfDay(formatToCurrentZone(new Date().getTime())).getTime();
  };

  const getNowTime = () => {
    return formatToCurrentZone(Date.now());
  };

  return {
    yesterdayStart,
    yesterdayEnd,
    todayStart,
    todayEnd,
    yesterday,
    weekFirstDay,
    weekEndDay,
    startWeekDay,
    endWeekDay,
    mouthFirstDay,
    mouthEndDay,
    startOfMonthDay,
    endOfMonthDay,
    isFirstDayOfMonth,
    dayTime,
    isDateDisabled,
    getNowTime,
    isDateTimeDisabled,
    isDatePreviousDisabled,
    recentWeekDay,
    validator,
    dateDisabledExceedsDays,
    isDateNextDisabled,
  };
};
