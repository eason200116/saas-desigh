/** 导出业务错误（后端返回 JSON 而非文件） */
export class ExportError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'ExportError';
  }
}

/**
 * 从 Content-Disposition 解析文件名。
 * 优先取 RFC-5987 `filename*`（charset'lang'percent-encoded），其次取 `filename=`（可带引号）。
 *
 * 兼容点：
 * - charset 任意（非 UTF-8 时不解码、保留原文，避免 mojibake）
 * - lang 段可空（`UTF-8''abc` 与 `UTF-8'en'abc` 都支持）
 * - decodeURIComponent 失败时返回原始字符串（不让下载流程被异常 filename 中断）
 * - legacy 仅剥外层引号；filename 自身可能含 `"`，不再 replace-all
 * - legacy 不再误用 decodeURIComponent（老协议本来就是字面值）
 */
function parseFilename(disposition: string): string | null {
  if (!disposition) return null;

  // RFC 5987：filename* = charset 'lang' value
  const rfc5987 = disposition.match(/filename\*\s*=\s*([^']+)'([^']*)'([^;]+)/i);
  if (rfc5987) {
    const charset = rfc5987[1].trim().toLowerCase();
    const raw = rfc5987[3].trim();
    if (charset === 'utf-8' || charset === 'utf8') {
      try {
        return decodeURIComponent(raw);
      } catch {
        return raw;
      }
    }
    return raw;
  }

  // 老协议：filename=value 或 filename="value"
  const legacy = disposition.match(/filename\s*=\s*("([^"]*)"|([^;]+))/i);
  if (legacy) {
    return (legacy[2] ?? legacy[3] ?? '').trim();
  }

  return null;
}

/**
 * 将 blob AxiosResponse 解析为错误或触发文件下载。
 * 所有导出场景的唯一 blob 处理入口。
 *
 * @example
 * // 配合 gen:api 生成的 Export 函数使用
 * await downloadApiResponse(api.v1platform.getFinanceRecordPageListExport(req));
 */
export async function downloadApiResponse(
  responsePromise: Promise<any>,
  options: { filename?: string; fallbackFilename?: string } = {},
): Promise<void> {
  const { filename: forceFilename, fallbackFilename = 'download' } = options;

  let res: any;
  try {
    res = await responsePromise;
  } catch (e: any) {
    // responseInterceptorsCatch 以 Promise.reject(blob) 形式传出 JSON 错误
    const blob: Blob | null = e instanceof Blob ? e : e?.data instanceof Blob ? e.data : null;
    if (blob?.type.includes('application/json')) {
      const text = await blob.text();
      let json: any;
      try {
        json = JSON.parse(text);
      } catch {
        throw new ExportError('Export failed');
      }
      throw new ExportError(json.msg || '');
    }
    throw e;
  }

  // 兜底：响应 blob 类型为 json 时视为错误
  if (res.data instanceof Blob && res.data.type.includes('application/json')) {
    const text = await res.data.text();
    let json: any;
    try {
      json = JSON.parse(text);
    } catch {
      throw new ExportError('Export failed');
    }
    throw new ExportError(json.msg || '');
  }
  const disposition = res.headers?.['content-disposition'] || '';
  const filename = forceFilename || parseFilename(disposition) || fallbackFilename;

  const blobUrl = window.URL.createObjectURL(res.data);
  const link = document.createElement('a');
  link.href = blobUrl;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  window.URL.revokeObjectURL(blobUrl);
}

/**
 * 下载模板文件
 */
export function downloadTemplate(templateUrl?: string) {
  if (!templateUrl) {
    console.warn('downloadTemplate: No template URL provided');
    return;
  }
  const link = document.createElement('a');
  link.href = templateUrl;
  link.download = templateUrl.split('/').pop() || 'template.xlsx';
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

/**
 * 通过 API 接口下载文件（占位实现，AR prototype 阶段直接用 URL 下载）
 */
export async function downloadByApi(options: {
  url: string;
  method?: string;
  params?: Record<string, any>;
  filename?: string;
}): Promise<void> {
  const { url, filename } = options;
  downloadFile(url, filename);
}

/**
 * 直接用 URL 下载文件（无需 token）
 */
export function downloadFile(url: string, filename?: string) {
  const link = document.createElement('a');
  link.href = url;
  if (filename) link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}
