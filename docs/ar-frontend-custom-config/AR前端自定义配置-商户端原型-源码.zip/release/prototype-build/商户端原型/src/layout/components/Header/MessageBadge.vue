/** * @description 头部导航「出入款统计」入口：消费 adminWs 推送的 RechargeWithdrawWaitCount， *
按集团 → 商户两级展示「三方待入款 / 本地待入款 / 待出款」三独立计数； * 顶栏 Badge
显示三项总和；popover 头部按业务维度拆双行汇总（待入款 / 待出款）。 * 数据全量来自 WS
推送（每次整体替换），按对接文档 §5 / §6 服务端已按权限裁剪到当前用户可见。 * @date 26-05-04 *
@author fifty-nine * @scope ar_platform_admin v1.9.1 · Header MessageBadge */

<template>
  <n-popover
    trigger="hover"
    placement="bottom-end"
    :show-arrow="false"
    :style="{ padding: 0 }"
    content-style="padding: 0;"
    raw
  >
    <template #trigger>
      <div
        class="msg-badge__trigger layout-header-trigger layout-header-trigger-min layout-header-trigger--badge"
      >
        <n-badge :value="totalCount" :max="999" :show-zero="true">
          <div class="trigger-badge-content">
            <n-icon size="18">
              <component :is="MoneyIcon" />
            </n-icon>
            <span class="trigger-badge-text">{{ t('common.header.messageCenter.trigger') }}</span>
          </div>
        </n-badge>
      </div>
    </template>

    <div class="msg-panel">
      <div class="msg-panel__header">
        <span class="msg-panel__title">{{ t('common.header.messageCenter.title') }}</span>
        <div class="msg-panel__summary">
          <i18n-t
            keypath="common.header.messageCenter.summaryDeposit"
            tag="span"
            class="msg-panel__summary-line"
            scope="global"
          >
            <template #total>
              <strong class="msg-panel__summary-num msg-panel__summary-num--deposit">{{
                totalDeposit
              }}</strong>
            </template>
          </i18n-t>
          <i18n-t
            keypath="common.header.messageCenter.summaryWithdraw"
            tag="span"
            class="msg-panel__summary-line"
            scope="global"
          >
            <template #total>
              <strong class="msg-panel__summary-num msg-panel__summary-num--withdraw">{{
                totalWithdraw
              }}</strong>
            </template>
          </i18n-t>
        </div>
      </div>

      <div class="msg-panel__body">
        <div v-for="group in groups" :key="group.groupId" class="msg-panel__group-block">
          <div class="msg-panel__group-name">
            <span class="msg-panel__group-dot" />
            {{ group.groupName }}
          </div>

          <div
            v-for="merchant in group.merchants"
            :key="merchant.merchantId"
            class="msg-panel__merchant"
          >
            <span class="msg-panel__merchant-chip">{{ merchant.merchantName }}</span>

            <div class="msg-panel__merchant-actions">
              <button
                class="msg-panel__action-btn msg-panel__action-btn--deposit"
                :disabled="!canThirdDeposit"
                @click="goThirdDeposit(merchant)"
              >
                <span class="msg-panel__action-label">{{
                  t('common.header.messageCenter.actionThirdDeposit')
                }}</span>
                <span class="msg-panel__action-count msg-panel__action-count--deposit">
                  {{ merchant.thirdRechargeCount }}
                </span>
              </button>

              <span class="msg-panel__action-divider" />

              <button
                class="msg-panel__action-btn msg-panel__action-btn--deposit"
                :disabled="!canLocalDeposit"
                @click="goLocalDeposit(merchant)"
              >
                <span class="msg-panel__action-label">{{
                  t('common.header.messageCenter.actionLocalDeposit')
                }}</span>
                <span class="msg-panel__action-count msg-panel__action-count--deposit">
                  {{ merchant.localRechargeCount }}
                </span>
              </button>

              <span class="msg-panel__action-divider" />

              <button
                class="msg-panel__action-btn msg-panel__action-btn--withdraw"
                :disabled="!canWithdraw"
                @click="goWithdraw(merchant)"
              >
                <span class="msg-panel__action-label">{{
                  t('common.header.messageCenter.actionWithdraw')
                }}</span>
                <span class="msg-panel__action-count msg-panel__action-count--withdraw">
                  {{ merchant.withdrawCount }}
                </span>
              </button>
            </div>
          </div>
        </div>

        <div v-if="!groups.length" class="msg-panel__empty">
          {{ t('common.header.messageCenter.empty') }}
        </div>
      </div>
    </div>
  </n-popover>
</template>

<script setup lang="ts">
  import { computed } from 'vue';
  import { NBadge, NIcon, NPopover } from 'naive-ui';
  import { useI18n } from 'vue-i18n';
  import { useRouter } from 'vue-router';
  import { MoneyCollectOutlined as MoneyIcon } from '@vicons/antd';
  const { t } = useI18n();
  const canThirdDeposit = computed(() => true);
  const canLocalDeposit = computed(() => true);
  const canWithdraw = computed(() => true);

  interface MessageMerchant {
    merchantId: string;
    /** 形如 "(1050) daman" 的展示名 —— 原型规定括号在前 */
    merchantName: string;
    /** 三方待入款 */
    thirdRechargeCount: number;
    /** 本地待入款 */
    localRechargeCount: number;
    /** 待出款 */
    withdrawCount: number;
  }

  interface MessageGroup {
    groupId: string;
    groupName: string;
    merchants: MessageMerchant[];
  }

  const props = withDefaults(
    defineProps<{
      groups?: MessageGroup[];
    }>(),
    {
      groups: () => [],
    },
  );

  const router = useRouter();

  /** 待入款合计（三方 + 本地）—— 原型右上角第一行 */
  const totalDeposit = computed(() =>
    props.groups.reduce(
      (sum, group) =>
        sum +
        group.merchants.reduce(
          (m, x) => m + (x.thirdRechargeCount || 0) + (x.localRechargeCount || 0),
          0,
        ),
      0,
    ),
  );

  /** 待出款合计 —— 原型右上角第二行 */
  const totalWithdraw = computed(() =>
    props.groups.reduce(
      (sum, group) => sum + group.merchants.reduce((m, x) => m + (x.withdrawCount || 0), 0),
      0,
    ),
  );

  /** 顶栏 Badge 总数：三项相加 */
  const totalCount = computed(() => totalDeposit.value + totalWithdraw.value);

  // 无权限时按钮已 :disabled，这里再兜底一层。
  // 跳转必须带商户筛选条件，目标页面读 URL query 后注入搜索表单并触发首次查询，
  // 让用户从 popover 行 → 直接看到该商户的列表，无需手动再选商户、点查询。
  // 入款侧搜索字段是 tenantId（单选 tenantSelect），URL key 用 tenantId；
  // 出款侧 OrderPanel 是 tenantIds（多选 tenantSelect），URL key 用 tenantIds。
  function goThirdDeposit(merchant: MessageMerchant) {
    if (!canThirdDeposit.value) return;
    router.push({
      path: '/finance/rechargeOrder',
      query: { tab: 'thirdPartyPending', tenantId: merchant.merchantId },
    });
  }

  function goLocalDeposit(merchant: MessageMerchant) {
    if (!canLocalDeposit.value) return;
    router.push({
      path: '/finance/rechargeOrder',
      query: { tab: 'bankUpiDeposit', tenantId: merchant.merchantId },
    });
  }

  function goWithdraw(merchant: MessageMerchant) {
    if (!canWithdraw.value) return;
    // 主 tab 直接落到 records（提现记录主列表），跳过 dashboard 看板中转；
    // sub=orders 保留：用户从 records 切回 dashboard 时让 dashboard 子 tab 落到 orders 面板。
    router.push({
      path: '/finance/withdrawOrder',
      query: { sub: 'orders', tenantIds: merchant.merchantId, tab: 'records' },
    });
  }
</script>

<style lang="less" scoped>
  .msg-badge__trigger {
    cursor: pointer;
  }

  .layout-header-trigger {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    height: 44px;
    margin: 0 2px;
    padding: 0 10px;
    border: 0;
    border-radius: 6px;
    background: transparent;
    color: rgb(255 255 255 / 0.86);
    transition:
      background-color 0.2s cubic-bezier(0.4, 0, 0.2, 1),
      color 0.2s cubic-bezier(0.4, 0, 0.2, 1);
  }

  .layout-header-trigger:hover {
    background: rgb(255 255 255 / 0.12);
    color: #fff;
  }

  .layout-header-trigger--badge {
    min-width: 54px;
  }

  .trigger-badge-content {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    gap: 2px;
  }

  .trigger-badge-text {
    font-size: 12px;
    line-height: 1.1;
    color: rgb(255 255 255 / 0.72);
    white-space: nowrap;
  }

  .msg-panel {
    width: 380px;
    background: var(--ui-bg-popover);
    border: 1px solid var(--ui-border-default);
    border-radius: var(--ui-radius-card);
    box-shadow: var(--ui-shadow-popover);
    overflow: hidden;
  }

  .msg-panel__header {
    display: flex;
    align-items: flex-start;
    justify-content: space-between;
    gap: 12px;
    padding: 12px 16px 10px;
    border-bottom: 1px solid var(--ui-divider);
  }

  .msg-panel__title {
    font-size: 14px;
    font-weight: 600;
    color: var(--ui-text-primary);
    flex-shrink: 0;
  }

  .msg-panel__summary {
    display: flex;
    flex-direction: column;
    align-items: flex-end;
    gap: 2px;
    flex: 1;
    min-width: 0;
  }

  .msg-panel__summary-line {
    font-size: 12px;
    color: var(--ui-text-tertiary);
    white-space: nowrap;
  }

  .msg-panel__summary-num {
    margin: 0 2px;
    font-weight: 700;
  }

  .msg-panel__summary-num--deposit {
    color: var(--ui-info-solid);
  }

  .msg-panel__summary-num--withdraw {
    color: var(--ui-warning-solid);
  }

  .msg-panel__body {
    max-height: 420px;
    overflow-y: auto;
    padding: 8px 0 4px;
  }

  .msg-panel__group-block {
    margin-bottom: 4px;
  }

  .msg-panel__group-name {
    display: flex;
    align-items: center;
    gap: 6px;
    padding: 6px 16px 4px;
    font-size: 12px;
    font-weight: 700;
    color: var(--ui-text-secondary);
    letter-spacing: 0.02em;
  }

  .msg-panel__group-dot {
    width: 6px;
    height: 6px;
    border-radius: 50%;
    background: var(--ui-info-solid);
    flex-shrink: 0;
  }

  .msg-panel__merchant {
    display: flex;
    align-items: center;
    justify-content: flex-start;
    flex-wrap: wrap;
    gap: 6px 8px;
    padding: 6px 16px 8px 28px;
    transition: background 0.15s;
  }

  .msg-panel__merchant:hover {
    background: var(--ui-fill-hover);
  }

  // 商户名 chip：原型蓝底蓝字胶囊 (1050) daman
  .msg-panel__merchant-chip {
    display: inline-flex;
    align-items: center;
    height: 22px;
    padding: 0 10px;
    border-radius: 11px;
    background: var(--ui-info-soft);
    color: var(--ui-info-solid);
    font-size: 12px;
    font-weight: 500;
    line-height: 1;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    max-width: 100%;
  }

  .msg-panel__merchant-actions {
    display: flex;
    align-items: center;
    gap: 0;
    flex-shrink: 0;
    flex-wrap: wrap;
  }

  .msg-panel__action-btn {
    display: flex;
    align-items: center;
    gap: 4px;
    padding: 3px 8px;
    border: none;
    background: transparent;
    cursor: pointer;
    border-radius: 4px;
    transition: background 0.15s;
  }

  .msg-panel__action-btn:hover:not(:disabled) {
    background: var(--ui-fill-hover);
  }

  .msg-panel__action-btn:disabled {
    cursor: not-allowed;
    opacity: 0.5;
  }

  .msg-panel__action-label {
    font-size: 12px;
    color: var(--ui-text-secondary);
    white-space: nowrap;
  }

  .msg-panel__action-btn--deposit:hover:not(:disabled) .msg-panel__action-label {
    color: var(--ui-info-solid);
  }

  .msg-panel__action-btn--withdraw:hover:not(:disabled) .msg-panel__action-label {
    color: #d97706;
  }

  .msg-panel__action-count {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    min-width: 20px;
    height: 18px;
    padding: 0 5px;
    border-radius: 9px;
    font-size: 11px;
    font-weight: 700;
    line-height: 1;
  }

  .msg-panel__action-count--deposit {
    background: var(--ui-info-soft);
    color: var(--ui-info-solid);
  }

  .msg-panel__action-count--withdraw {
    background: var(--ui-warning-soft);
    color: var(--ui-warning-solid);
  }

  .msg-panel__action-divider {
    width: 1px;
    height: 14px;
    background: var(--ui-divider);
    margin: 0 2px;
  }

  .msg-panel__empty {
    padding: 24px 16px;
    text-align: center;
    font-size: 13px;
    color: var(--ui-text-disabled);
  }
</style>
