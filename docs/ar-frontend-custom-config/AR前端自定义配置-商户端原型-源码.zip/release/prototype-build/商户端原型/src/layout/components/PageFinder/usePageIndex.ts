import { computed, type ComputedRef } from 'vue';
import { useI18n } from 'vue-i18n';
import { useAsyncRouteStore } from '@/store/modules';

// 找页面抽屉：可搜索的叶子页条目（name=路由名、title=中文标题、mainType=所属主类型中文名）。
export interface PageEntry {
  name: string;
  title: string;
  mainType: string;
}

/**
 * 收集某主类型下的「菜单页」。口径对齐 MegaMenu：一个节点只要「有 name + meta.title」就是一个可导航菜单页，
 * 直接收录、**不再深入它的子路由**（页面的 tab 子路由多为无 name，不是菜单项，深入会把页面本身漏掉）。
 * 只有「无 name 的纯分组节点」才继续往下钻。
 */
function collectLeaves(nodes: any[], t: (k: string) => string, mainType: string, out: PageEntry[]) {
  (nodes || []).forEach((n) => {
    if (n?.meta?.hidden === true) return;
    if (n.name && n.meta?.title) {
      out.push({ name: n.name as string, title: t(n.meta.title), mainType });
      return; // 已是菜单页，不钻其 tab 子路由
    }
    const kids = (n.children || []).filter((c: any) => c?.meta?.hidden !== true);
    if (kids.length > 0) collectLeaves(kids, t, mainType, out);
  });
}

export function usePageIndex() {
  const { t } = useI18n();
  const asyncRouteStore = useAsyncRouteStore();

  // 权限过滤后的菜单树（asyncRouteStore.getMenus，与 MegaMenu 同源）→ 拍平成叶子页。
  const pages: ComputedRef<PageEntry[]> = computed(() => {
    const out: PageEntry[] = [];
    (asyncRouteStore.getMenus as any[])
      .filter((m) => m.meta?.hidden !== true)
      .forEach((m) => {
        const mainType = m.meta?.title ? t(m.meta.title) : (m.name as string);
        collectLeaves(Array.isArray(m.children) ? m.children : [m], t, mainType, out);
      });
    return out;
  });

  /** 模糊搜索：按中文标题或主类型名的小写子串匹配；空关键词返回 []。 */
  function search(kw: string): PageEntry[] {
    const q = kw.trim().toLowerCase();
    if (!q) return [];
    return pages.value.filter(
      (p) => p.title.toLowerCase().includes(q) || p.mainType.toLowerCase().includes(q),
    );
  }

  return { pages, search };
}
