<template>
  <div class="header-logo" :title="t('common.header.goToHome')" @click="handleClick">
    <img v-if="logoSrc" :src="logoSrc" :alt="altText" class="header-logo__img" />
    <ArLogo v-else :size="32" :label="altText" :decorative="false" class="header-logo__img" />
  </div>
</template>

<script lang="ts" setup>
  import { computed } from 'vue';
  import { useRouter } from 'vue-router';
  import { useI18n } from 'vue-i18n';
  import ArLogo from '@/components/Brand/ArLogo.vue';
  import { PageEnum } from '@/enums/pageEnum';

  // ============ Props ============
  const props = withDefaults(
    defineProps<{
      /** 自定义 logo 地址，不传则使用系统配置 */
      src?: string;
      /** alt 文本 */
      alt?: string;
      /** 点击是否跳转首页 */
      clickable?: boolean;
    }>(),
    {
      clickable: true,
    },
  );

  // ============ Emits ============
  const emit = defineEmits<{
    click: [];
  }>();

  // ============ 依赖 ============
  const { t } = useI18n();
  const router = useRouter();

  // ============ 计算属性 ============
  const logoSrc = computed(() => props.src || '');
  const altText = computed(() => props.alt || t('common.header.logo'));

  // ============ 事件处理 ============
  function handleClick() {
    emit('click');
    if (props.clickable) {
      void router.push(PageEnum.BASE_HOME_REDIRECT);
    }
  }
</script>

<style lang="less" scoped>
  .header-logo {
    display: flex;
    align-items: center;
    justify-content: center;
    height: 100%;
    padding: 0 12px;
    cursor: pointer;
    transition: opacity 0.2s;

    &:hover {
      opacity: 0.85;
    }

    &__img {
      width: auto;
      height: 32px;
      display: block;
      object-fit: contain;
    }
  }
</style>
