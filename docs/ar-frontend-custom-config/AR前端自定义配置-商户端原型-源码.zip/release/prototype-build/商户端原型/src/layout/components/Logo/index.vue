<template>
  <div class="logo">
    <ArLogo :size="32" :class="{ 'mr-2': !collapsed }" />
    <h2 v-show="!collapsed" class="title">{{ websiteConfig.title }}</h2>
  </div>
</template>

<script lang="ts">
  import { defineComponent } from 'vue';
  import { websiteConfig } from '@/hooks/setting';
  import ArLogo from '@/components/Brand/ArLogo.vue';

  export default defineComponent({
    name: 'Index',
    components: { ArLogo },
    props: {
      collapsed: {
        type: Boolean,
      },
    },
    data() {
      return {
        websiteConfig,
      };
    },
  });
</script>

<style lang="less" scoped>
  .logo {
    display: flex;
    align-items: center;
    justify-content: center;
    height: 64px;
    line-height: 64px;
    overflow: hidden;
    white-space: nowrap;
    border-bottom: 1px solid rgba(127, 127, 127, 0.15);

    .title {
      margin: 0;
    }
  }
</style>
