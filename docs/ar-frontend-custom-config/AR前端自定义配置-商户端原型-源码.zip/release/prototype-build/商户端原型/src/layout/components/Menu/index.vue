<template>
  <NMenu
    :options="menus"
    :inverted="inverted"
    :mode="mode"
    :collapsed="collapsed"
    :collapsed-width="64"
    :collapsed-icon-size="20"
    :indent="18"
    :render-label="renderMenuLabel"
    :expanded-keys="openKeys"
    :value="getSelectedKeys"
    @update:value="clickMenuItem"
    @update:expanded-keys="menuExpanded"
  />
</template>

<script lang="ts">
  import {
    defineComponent,
    h,
    ref,
    onMounted,
    reactive,
    computed,
    watch,
    toRefs,
    unref,
  } from 'vue';
  import { NEllipsis } from 'naive-ui';
  import type { MenuOption, MenuGroupOption } from 'naive-ui';
  import { useRoute, useRouter } from 'vue-router';
  import { useI18n } from 'vue-i18n';
  import { generatorMenu, generatorMenuMix } from '@/utils';
  import { useProjectSettingStore, useAsyncRouteStore } from '@/store/modules';
  import { useProjectSetting } from '@/hooks/setting';
  import { useRoleStore } from '@/store/modules/role';
  import type { AppRole } from '@/config/runtime';

  export default defineComponent({
    name: 'AppMenu',
    props: {
      mode: {
        // 菜单模式
        type: String,
        default: 'vertical',
      },
      collapsed: {
        // 侧边栏菜单是否收起
        type: Boolean,
      },
      //位置
      location: {
        type: String,
        default: 'left',
      },
    },
    emits: ['update:collapsed', 'clickMenuItem'],
    setup(props, { emit }) {
      // 当前路由
      const currentRoute = useRoute();
      const router = useRouter();
      const asyncRouteStore = useAsyncRouteStore();
      const settingStore = useProjectSettingStore();
      const roleStore = useRoleStore();
      const menus = ref<any[]>([]);

      function filterByRole<T extends { meta?: any; children?: T[] }>(items: T[]): T[] {
        const role: AppRole = roleStore.role;
        return items
          .filter((r) => {
            const roles = r.meta?.roles as AppRole[] | undefined;
            if (!roles) return true;
            return roles.includes(role);
          })
          .map((r) =>
            r.children && r.children.length ? { ...r, children: filterByRole(r.children) } : r,
          );
      }
      const selectedKeys = ref<string>(currentRoute.name as string);
      const headerMenuSelectKey = ref<string>('');

      const { navMode } = useProjectSetting();

      // 获取当前打开的子菜单
      const matched = currentRoute.matched;

      const getOpenKeys = matched && matched.length ? matched.map((item) => item.name) : [];

      const state = reactive({
        openKeys: getOpenKeys,
      });

      const inverted = computed(() => {
        return ['dark', 'header-dark'].includes(settingStore.navTheme);
      });

      const getSelectedKeys = computed(() => {
        // 左侧栏按当前页面高亮；顶部主类型横条（含 horizontal，已剥离 children）按主类型高亮
        return props.location === 'left' ? unref(selectedKeys) : unref(headerMenuSelectKey);
      });

      // 监听分割菜单
      watch(
        () => settingStore.menuSetting.mixMenu,
        () => {
          updateMenu();
          if (props.collapsed) {
            emit('update:collapsed', !props.collapsed);
          }
        },
      );

      // 跟随页面路由变化，切换菜单选中状态
      watch(
        () => currentRoute.fullPath,
        () => {
          updateMenu();
        },
      );

      // 语言切换时，menu 的 label 是用 i18n.global.t 一次性生成的字符串，
      // 不会随 i18n.locale 响应式更新 — 必须手动重建。
      const { locale } = useI18n();
      watch(locale, () => {
        updateMenu();
      });

      function updateSelectedKeys() {
        const matched = currentRoute.matched;
        state.openKeys = matched.map((item) => item.name);
        const activeMenu: string = (currentRoute.meta?.activeMenu as string) || '';
        selectedKeys.value = activeMenu ? (activeMenu as string) : (currentRoute.name as string);
      }

      function updateMenu() {
        if (!settingStore.menuSetting.mixMenu) {
          let generated = generatorMenu(filterByRole(asyncRouteStore.getMenus));
          // 顶部主类型横条：剥离 children，不展开长下拉（子类型由二级横向子类条 SubTypeBar 承担）
          if (props.location === 'header') {
            generated = generated.map((it: any) => ({ ...it, children: undefined }));
            const firstRouteName = (currentRoute.matched[0]?.name as string) || '';
            const activeMenu = currentRoute.matched[0]?.meta?.activeMenu as string;
            headerMenuSelectKey.value = (activeMenu ? activeMenu : firstRouteName) || '';
          }
          menus.value = generated;
        } else {
          //混合菜单
          const firstRouteName: string = (currentRoute.matched[0].name as string) || '';
          menus.value = generatorMenuMix(
            filterByRole(asyncRouteStore.getMenus),
            firstRouteName,
            props.location,
          );
          const activeMenu: string = currentRoute?.matched[0].meta?.activeMenu as string;
          headerMenuSelectKey.value = (activeMenu ? activeMenu : firstRouteName) || '';
        }
        updateSelectedKeys();
      }

      // 点击菜单
      function clickMenuItem(key: string) {
        if (/http(s)?:/.test(key)) {
          window.open(key);
        } else if (props.location === 'header' && settingStore.menuSetting.mixMenu) {
          // 混合模式 header：导航到第一个可访问的子路由，避免 redirect 到无权限页面
          const parentRoute = asyncRouteStore.getMenus.find((r: any) => r.name === key);
          const visibleChildren = (parentRoute?.children || []).filter((c: any) => !c.meta?.hidden);
          if (visibleChildren.length) {
            router.push({ name: visibleChildren[0].name as string });
          } else {
            router.push({ name: key });
          }
        } else {
          router.push({ name: key });
        }
        emit('clickMenuItem' as any, key);
      }

      //展开菜单
      function menuExpanded(openKeys: string[]) {
        if (!openKeys) return;
        const latestOpenKey = openKeys.find((key) => state.openKeys.indexOf(key) === -1);
        const isExistChildren = findChildrenLen(latestOpenKey as string);
        state.openKeys = isExistChildren ? (latestOpenKey ? [latestOpenKey] : []) : openKeys;
      }

      //查找是否存在子路由
      function findChildrenLen(key: string) {
        if (!key) return false;
        const subRouteChildren: string[] = [];
        for (const { children, key } of unref(menus)) {
          if (children && children.length) {
            subRouteChildren.push(key as string);
          }
        }
        return subRouteChildren.includes(key);
      }

      // 垂直模式下用 NEllipsis + tooltip 包装 label，悬停展示完整文字；
      // 水平模式保持原文本（顶部菜单自带 dropdown，避免重复 tooltip）。
      function renderMenuLabel(option: MenuOption | MenuGroupOption) {
        const raw = option.label;
        const text = typeof raw === 'function' ? raw() : raw;
        if (props.mode === 'horizontal') return text;
        return h(NEllipsis, { tooltip: { placement: 'right' } }, { default: () => text });
      }

      onMounted(() => {
        updateMenu();
      });

      return {
        ...toRefs(state),
        inverted,
        menus,
        selectedKeys,
        headerMenuSelectKey,
        getSelectedKeys,
        clickMenuItem,
        menuExpanded,
        renderMenuLabel,
      };
    },
  });
</script>

<style lang="less" scoped>
  // 仅作用于左侧垂直菜单，避免影响顶部 header 的 horizontal 菜单
  // （顶部菜单在 Header/index.vue 有独立的 ::after 底部横线样式）
  // 注：Naive UI NMenu 在 inverted 模式下已用 ::before 做整块主色背景选中态，
  //     视觉焦点已足够强，这里只做 hover/active 平滑过渡与图标微交互。
  ::v-deep(.n-menu--vertical) {
    .n-menu-item-content {
      transition:
        background-color 0.2s ease,
        color 0.2s ease;

      .n-menu-item-content__icon {
        transition:
          color 0.2s ease,
          transform 0.2s ease;
      }

      &:hover:not(.n-menu-item-content--selected) .n-menu-item-content__icon {
        transform: translateX(1px);
      }
    }
  }
</style>
