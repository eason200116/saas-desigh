<template>
  <div class="page-footer">
    <div class="page-footer-link">
      <a href="https://github.com/jekip/naive-ui-admin" target="_blank">
        {{ t('common.footer.official') }}
      </a>
      <a href="https://github.com/jekip/naive-ui-admin" target="_blank">
        {{ t('common.footer.community') }}
      </a>
      <a href="https://github.com/jekip/naive-ui-admin/issues" target="_blank">
        {{ t('common.footer.discussion') }}
      </a>
    </div>
    <div class="copyright"> naive-ui-admin 1.4 · Made by Ah jung </div>
  </div>
</template>

<script setup lang="ts">
  import { useI18n } from 'vue-i18n';

  defineOptions({ name: 'PageFooter' });

  defineProps<{
    collapsed?: boolean;
  }>();

  const { t } = useI18n();
</script>

<style lang="less" scoped>
  .page-footer {
    //margin: 28px 0 24px 0;
    padding: 0 16px;
    text-align: center;

    a {
      font-size: 14px;
      color: var(--ui-text-tertiary);
      -webkit-transition: all 0.2s ease-in-out;
      transition: all 0.2s ease-in-out;

      &:hover {
        color: var(--ui-text-secondary);
      }
    }

    &-link {
      display: flex;
      justify-content: center;
      margin-bottom: 8px;

      a:not(:last-child) {
        margin-right: 40px;
      }
    }

    .copyright {
      color: var(--ui-text-tertiary);
      font-size: 14px;
    }
  }
</style>
