import { ref } from 'vue';

// 找页面抽屉：最近访问过的页面（title 存 i18n key，展示时用 t() 解析）。
export interface RecentItem {
  name: string;
  title: string;
}

const MAX = 5;
const recent = ref<RecentItem[]>([]);
let currentKey: string | null = null;

function storageKey(userId: string) {
  return `pageFinder:recent:${userId}`;
}

export function useRecentVisits() {
  function load(userId: string) {
    currentKey = storageKey(userId);
    try {
      const stored = JSON.parse(localStorage.getItem(currentKey) || '[]');
      // 读取时也裁到 MAX：历史里已存的更长列表（如旧上限 10 条）立即收敛到最多 MAX 条。
      recent.value = Array.isArray(stored) ? stored.slice(0, MAX) : [];
    } catch {
      recent.value = [];
    }
  }
  function record(item: RecentItem) {
    if (!item.name || !item.title) return;
    const next = [item, ...recent.value.filter((r) => r.name !== item.name)].slice(0, MAX);
    recent.value = next;
    if (currentKey) localStorage.setItem(currentKey, JSON.stringify(next));
  }
  function clear() {
    recent.value = [];
    if (currentKey) localStorage.removeItem(currentKey);
  }
  return { recent, load, record, clear };
}
