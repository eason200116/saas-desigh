/**
 * @description 站内信消息类型文案解析 hook：以 `api/Common/GetDictionary` 的 `warningTypeList` 为单一真值源，按当前激活语言渲染消息类型显示文案；字典缺失时回退本地 i18n key，保证联调期 / 字典加载窗口期的健壮性。
 * @date 2026-05-07

 * @scope src/layout/components/Header/NotificationBadge.vue 与 NotificationDetailModal.vue 共用
 */
import { computed } from 'vue';
import { useI18n } from 'vue-i18n';
import { useDictionary } from '@/components/DictSelect';
import type { NotificationItem } from '@/store/modules/notification';

type LabelInput = Pick<NotificationItem, 'messageTypeId' | 'messageType'>;

export function useNotificationLabel() {
  const { t } = useI18n();
  // source='common' 默认走 userStore.dictionary，切语言时由 useLang().handleLang 重拉，computed 自动重算
  const { getOptionMap } = useDictionary();
  const warningTypeMap = computed(() => getOptionMap('warningTypeList'));

  /**
   * 显示文案优先级（v2.5 收紧裸数字兜底）：
   * 1. 字典 warningTypeList[messageTypeId].name（已按当前 locale 服务端渲染；含 id=0「系统消息」/ 509「出款订单」等）
   * 2. i18n messageTypes.{messageType}（字典加载窗口期或 v1 字符串枚举的兼容兜底）
   * 3. 字典 id=0「系统消息」（未知业务行为枚举 / messageTypeId=null 统一归类，不再裸露数字）
   * 4. 字典未加载完成 → '--'
   */
  function resolveLabel(item: LabelInput): string {
    if (item.messageTypeId != null) {
      const fromDict = warningTypeMap.value.get(item.messageTypeId)?.label;
      if (fromDict) return fromDict;
    }
    if (item.messageType) {
      const i18nKey = `common.header.notification.messageTypes.${item.messageType}`;
      const text = t(i18nKey);
      if (text && text !== i18nKey) return text;
    }
    const systemLabel = warningTypeMap.value.get(0)?.label;
    if (systemLabel) return systemLabel;
    return '--';
  }

  return { resolveLabel };
}
