<template>
  <!-- 左侧常驻开关把手：抽屉关闭时挂在左边缘，点击重新打开（关了也永远找得到入口）-->
  <div v-if="!show" class="pf-handle" :title="t('common.pageFinder.title')" @click="open">
    <n-icon :component="SearchOutlined" :size="16" />
  </div>
  <n-drawer
    v-model:show="show"
    resizable
    :default-width="300"
    placement="left"
    :trap-focus="false"
    :mask-closable="true"
    to="body"
  >
    <n-drawer-content :title="t('common.pageFinder.title')" body-content-style="padding:12px">
      <n-input
        v-model:value="keyword"
        clearable
        size="small"
        :placeholder="t('common.pageFinder.searchPlaceholder')"
      >
        <template #prefix><n-icon :component="SearchOutlined" /></template>
      </n-input>

      <!-- 搜索结果（有关键词时）-->
      <div v-if="keyword.trim()" class="pf-section">
        <div class="pf-section__title">{{ t('common.pageFinder.results') }}</div>
        <div v-if="results.length === 0" class="pf-empty">
          {{ t('common.pageFinder.emptyResult') }}
        </div>
        <div v-for="p in results" :key="p.name" class="pf-item" @click="go(p.name)">
          <span class="pf-item__label"
            ><b>{{ p.mainType }}</b> › {{ p.title }}</span
          >
          <n-icon
            class="pf-item__star"
            :class="{ 'is-on': isFav(p.name) }"
            @click.stop="toggleFav(p.name, p.title)"
          >
            <Star v-if="isFav(p.name)" /><StarOutline v-else />
          </n-icon>
        </div>
      </div>

      <!-- 收藏 + 最近（无关键词时）-->
      <template v-else>
        <div class="pf-section">
          <div class="pf-section__title">
            <n-icon :component="Star" :size="14" class="pf-section__icon pf-section__icon--fav" />
            {{ t('common.pageFinder.favorites') }}
          </div>
          <div v-if="visibleFavorites.length === 0" class="pf-empty">
            {{ t('common.pageFinder.emptyFavorites') }}
          </div>
          <div v-for="f in visibleFavorites" :key="f.name" class="pf-item" @click="go(f.name)">
            <span class="pf-item__label">{{ t(f.title) }}</span>
            <n-icon class="pf-item__star is-on" @click.stop="removeFavorite(f.path)"><Star /></n-icon>
          </div>
        </div>
        <div class="pf-section">
          <div class="pf-section__title">
            <n-icon :component="TimeOutline" :size="14" class="pf-section__icon" />
            {{ t('common.pageFinder.recent') }}
            <span
              v-if="visibleRecent.length > 0"
              class="pf-section__clear"
              :title="t('common.pageFinder.clearRecent')"
              @click="clearRecent"
            >
              {{ t('common.pageFinder.clearRecent') }}
            </span>
          </div>
          <div v-if="visibleRecent.length === 0" class="pf-empty">
            {{ t('common.pageFinder.emptyRecent') }}
          </div>
          <div v-for="r in visibleRecent" :key="r.name" class="pf-item" @click="go(r.name)">
            <span class="pf-item__label">{{ t(r.title) }}</span>
            <n-icon
              class="pf-item__star"
              :class="{ 'is-on': isFav(r.name) }"
              @click.stop="toggleFav(r.name, r.title)"
            >
              <Star v-if="isFav(r.name)" /><StarOutline v-else />
            </n-icon>
          </div>
        </div>
      </template>
    </n-drawer-content>
  </n-drawer>
</template>

<script lang="ts" setup>
  import { ref, computed, watch } from 'vue';
  import { NDrawer, NDrawerContent, NInput, NIcon } from 'naive-ui';
  import { SearchOutline as SearchOutlined, Star, StarOutline, TimeOutline } from '@vicons/ionicons5';
  import { useI18n } from 'vue-i18n';
  import { useRouter } from 'vue-router';
  import { useFavorites } from '@/hooks/useFavorites';
  import { useUserStore } from '@/store/modules';
  import { usePageIndex } from './usePageIndex';
  import { useRecentVisits } from './useRecentVisits';
  import { usePageFinder } from './usePageFinder';

  defineOptions({ name: 'PageFinder' });

  const { t } = useI18n();
  const router = useRouter();
  const userStore = useUserStore();
  const { show, open, close } = usePageFinder();
  const { search, pages } = usePageIndex();
  const { favorites, addFavorite, removeFavorite, isFavorite, loadFavorites } = useFavorites();
  const { recent, clear: clearRecent } = useRecentVisits();

  const keyword = ref('');
  const results = computed(() => search(keyword.value));

  // 只展示当前「可见页面」（未 meta.hidden、仍在菜单里）：过滤掉已隐藏 / 已失效的收藏与最近项。
  // 搜索本就走 usePageIndex.pages（已排除隐藏），这里给「收藏 / 最近」两个展示区补同一层过滤。
  const visibleNames = computed(() => new Set(pages.value.map((p) => p.name)));
  const visibleFavorites = computed(() =>
    favorites.value.filter((f) => visibleNames.value.has(f.name)),
  );
  const visibleRecent = computed(() => recent.value.filter((r) => visibleNames.value.has(r.name)));

  loadFavorites(String(userStore.info?.userId ?? 'anon'));

  // 收藏 path 统一用「真实路由 fullPath」（router.resolve），与标签栏 TagsView 存的 fullPath 一致，
  // 三方（顶部子类型星 / 标签栏星 / 左侧收藏）才认同一条、真正联动。name 兜底兼容历史存的 '/'+name。
  function resolveFavPath(name: string): string {
    try {
      return router.resolve({ name }).fullPath;
    } catch {
      return '/' + name;
    }
  }
  function isFav(name: string) {
    return isFavorite(resolveFavPath(name)) || favorites.value.some((f) => f.name === name);
  }
  function go(name: string) {
    router.push({ name }).catch(() => {});
    keyword.value = '';
    close();
  }
  function toggleFav(name: string, title: string) {
    const existing = favorites.value.find((f) => f.name === name);
    if (existing) removeFavorite(existing.path);
    else addFavorite({ fullPath: resolveFavPath(name), name, meta: { title } });
  }
  // 关闭时清空搜索，下次打开是干净态
  watch(show, (v) => {
    if (!v) keyword.value = '';
  });
</script>

<style scoped>
  .pf-section {
    margin-top: 14px;
  }
  .pf-section__title {
    display: flex;
    align-items: center;
    gap: 5px;
    font-size: 12px;
    color: #64748b;
    font-weight: 600;
    margin-bottom: 6px;
  }
  .pf-section__icon {
    color: #94a3b8;
  }
  .pf-section__icon--fav {
    color: #f59e0b;
  }
  /* 「清空」最近访问：标题行右侧文字按钮，非跳转 → 中性灰(R65)，hover 加深提示可点 */
  .pf-section__clear {
    margin-left: auto;
    font-weight: 500;
    color: #94a3b8;
    cursor: pointer;
    padding: 0 2px;
  }
  .pf-section__clear:hover {
    color: #64748b;
  }
  .pf-item {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 7px 8px;
    border-radius: 6px;
    cursor: pointer;
    font-size: 13px;
    color: #1f2328;
  }
  .pf-item:hover {
    background: #f1f5f9;
  }
  .pf-item__label {
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
  .pf-item__star {
    color: #cbd5e1;
    flex: 0 0 auto;
    margin-left: 8px;
  }
  .pf-item__star.is-on {
    color: #f59e0b;
  }
  .pf-item:hover .pf-item__star {
    color: #94a3b8;
  }
  .pf-item:hover .pf-item__star.is-on {
    color: #f59e0b;
  }
  .pf-empty {
    font-size: 12px;
    color: #94a3b8;
    padding: 4px 8px;
  }
  /* 左侧常驻开关把手（抽屉关闭时显示）*/
  .pf-handle {
    position: fixed;
    left: 0;
    top: 50%;
    transform: translateY(-50%);
    z-index: 8000;
    width: 24px;
    height: 52px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: #009688;
    color: #fff;
    border-radius: 0 10px 10px 0;
    cursor: pointer;
    box-shadow: 2px 0 10px rgba(0, 0, 0, 0.18);
    transition:
      background 0.15s,
      width 0.15s;
  }
  .pf-handle:hover {
    background: #00796b;
    width: 28px;
  }
</style>
