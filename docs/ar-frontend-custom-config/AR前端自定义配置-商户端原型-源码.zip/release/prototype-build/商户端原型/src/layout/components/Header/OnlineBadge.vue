/** * @description 头部导航「在线人数统计」入口：消费 adminWs 推送的 OnlineUserCount， * 按集团 →
商户两级展示在线人数与商户币种 chip。 * 数据全量来自 WS 集团广播 `/AdminApi/{orgId}/all`（对接文档
§5.4）； * 服务端不做权限裁剪（§6.1），由 adminWs.filterTenantScopedList 在前端按用户可见商户过滤。
* @date 26-05-04 * @author fifty-nine * @scope ar_platform_admin v1.9.1 · Header OnlineBadge */

<template>
  <n-popover
    trigger="hover"
    placement="bottom-end"
    :show-arrow="false"
    :style="{ padding: 0 }"
    content-style="padding: 0;"
    raw
  >
    <template #trigger>
      <div
        class="online-badge__trigger layout-header-trigger layout-header-trigger-min layout-header-trigger--badge"
        @click="goToOnlineUsers()"
      >
        <n-badge :value="currentCount" :max="99999" :show-zero="true">
          <div class="trigger-badge-content">
            <n-icon size="18">
              <PeopleOutline />
            </n-icon>
            <span class="trigger-badge-text">{{ t('common.header.onlineStatus') }}</span>
          </div>
        </n-badge>
      </div>
    </template>

    <div class="online-panel">
      <div class="online-panel__header">
        <span class="online-panel__title">{{ t('common.header.online.title') }}</span>
      </div>

      <div class="online-panel__body">
        <div v-for="group in groups" :key="group.groupId" class="online-panel__group-block">
          <div class="online-panel__group-name">
            <span class="online-panel__group-dot" />
            {{ group.groupName }}
          </div>

          <div
            v-for="merchant in group.merchants"
            :key="merchant.merchantId"
            class="online-panel__merchant online-panel__merchant--clickable"
            @click="goToOnlineUsers(merchant.merchantId)"
          >
            <span class="online-panel__merchant-name">{{ merchant.merchantName }}</span>
            <n-tag
              v-if="merchant.currencyCode"
              size="small"
              type="success"
              class="online-panel__currency-tag"
            >
              {{ merchant.currencyCode }}
            </n-tag>
            <span class="online-panel__merchant-count">
              {{ merchant.onlineCount }}{{ unitPeople }}
            </span>
          </div>
        </div>

        <div v-if="!groups.length" class="online-panel__empty">
          {{ t('common.header.online.empty') }}
        </div>
      </div>
    </div>
  </n-popover>
</template>

<script setup lang="ts">
  import { computed } from 'vue';
  import { useRouter } from 'vue-router';
  import { NBadge, NIcon, NPopover, NTag, useMessage } from 'naive-ui';
  import { useI18n } from 'vue-i18n';
  import { PeopleOutline } from '@vicons/ionicons5';

  const { t } = useI18n();
  const router = useRouter();
  const message = useMessage();

  // 在线人数明细路由名（与 src/router/modules/member.ts 的 onlineUsers 子路由 name 一致）。
  // generator.ts 会按用户权限码过滤路由表：当账号缺少 `Member:Users:UserList:GetOnlineUserPageList`
  // 权限时，该路由不会注册，router.push(name) 会抛 `No match`。跳转前用 router.hasRoute 守卫。
  const ONLINE_USERS_ROUTE_NAME = 'member_online_users';

  interface OnlineMerchant {
    merchantId: string;
    /** 形如 "(1050) daman" 的展示名 —— 原型规定括号在前 */
    merchantName: string;
    /** 商户支持币种（如 INR / VND）；空串时不渲染绿色 chip */
    currencyCode: string;
    onlineCount: number;
  }

  interface OnlineGroup {
    groupId: string;
    groupName: string;
    merchants: OnlineMerchant[];
  }

  // groups: popover 列表展示集团下所有商户（运营对比/切换上下文用）
  // currentCount: 顶栏角标只显示「当前激活商户」的在线人数，由 Header 适配层根据
  //   userStore.getActiveTenantId 在 onlineUserCountList 里查得后传入，与 HeaderTenant 同源
  // currentTenantId: trigger 点击跳转时携带的 siteId；与 currentCount 同源
  const props = withDefaults(
    defineProps<{
      groups?: OnlineGroup[];
      currentCount?: number;
      currentTenantId?: number | null;
    }>(),
    {
      groups: () => [],
      currentCount: 0,
      currentTenantId: null,
    },
  );

  // 单位字符（中文「人」，英文环境为空串避免 "5000" 拼接出 "5000people"）
  const unitPeople = computed(() => t('common.header.online.unitPeople'));

  /**
   * 跳转到在线用户明细页：
   * - 来自 trigger 点击：siteId 取 currentTenantId（激活商户），null 则不带
   * - 来自 popover 商户行点击：siteId 取该行 merchantId
   * - 当前账号无 `Member:Users:UserList:GetOnlineUserPageList` 权限时，generator.ts 会把
   *   该路由从 router 中过滤掉；此时 router.push 会抛 `No match`。跳转前用 hasRoute 守卫，
   *   未注册时给提示而非抛错。
   */
  function goToOnlineUsers(siteId?: string | number | null) {
    if (!router.hasRoute(ONLINE_USERS_ROUTE_NAME)) {
      message.warning(t('common.header.online.noPermission'));
      return;
    }
    const resolved = siteId ?? props.currentTenantId;
    const query =
      resolved !== null && resolved !== undefined && resolved !== ''
        ? { siteId: String(resolved) }
        : {};
    void router.push({ name: ONLINE_USERS_ROUTE_NAME, query });
  }
</script>

<style lang="less" scoped>
  .online-badge__trigger {
    cursor: pointer;
  }

  .layout-header-trigger {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    height: 44px;
    margin: 0 2px;
    padding: 0 10px;
    border: 0;
    border-radius: 6px;
    background: transparent;
    color: rgb(255 255 255 / 0.86);
    transition:
      background-color 0.2s cubic-bezier(0.4, 0, 0.2, 1),
      color 0.2s cubic-bezier(0.4, 0, 0.2, 1);
  }

  .layout-header-trigger:hover {
    background: rgb(255 255 255 / 0.12);
    color: #fff;
  }

  .layout-header-trigger--badge {
    min-width: 54px;
  }

  .trigger-badge-content {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    gap: 2px;
  }

  .trigger-badge-text {
    font-size: 12px;
    line-height: 1.1;
    color: rgb(255 255 255 / 0.72);
    white-space: nowrap;
  }

  .online-panel {
    width: 320px;
    background: var(--ui-bg-popover);
    border: 1px solid var(--ui-border-default);
    border-radius: var(--ui-radius-card);
    box-shadow: var(--ui-shadow-popover);
    overflow: hidden;
  }

  .online-panel__header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 12px 16px 10px;
    border-bottom: 1px solid var(--ui-divider);
  }

  .online-panel__title {
    font-size: 14px;
    font-weight: 600;
    color: var(--ui-text-primary);
  }

  .online-panel__body {
    max-height: 420px;
    overflow-y: auto;
    padding: 8px 0 4px;
  }

  .online-panel__group-block {
    margin-bottom: 4px;
  }

  .online-panel__group-name {
    display: flex;
    align-items: center;
    gap: 6px;
    padding: 6px 16px 4px;
    font-size: 12px;
    font-weight: 700;
    color: var(--ui-text-secondary);
    letter-spacing: 0.02em;
  }

  .online-panel__group-dot {
    width: 6px;
    height: 6px;
    border-radius: 50%;
    background: var(--ui-info-solid);
    flex-shrink: 0;
  }

  .online-panel__merchant {
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 6px 16px 6px 28px;
    transition: background 0.15s;
  }

  .online-panel__merchant:hover {
    background: var(--ui-fill-hover);
  }

  .online-panel__merchant--clickable {
    cursor: pointer;
  }

  .online-panel__merchant-name {
    flex: 1;
    min-width: 0;
    font-size: 13px;
    color: var(--ui-text-secondary);
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }

  .online-panel__currency-tag {
    flex-shrink: 0;
    font-weight: 600;
    letter-spacing: 0.04em;
  }

  .online-panel__merchant-count {
    flex-shrink: 0;
    min-width: 56px;
    text-align: right;
    font-size: 13px;
    font-weight: 700;
    color: var(--ui-info-solid);
  }

  .online-panel__empty {
    padding: 24px 16px;
    text-align: center;
    font-size: 13px;
    color: var(--ui-text-disabled);
  }
</style>
