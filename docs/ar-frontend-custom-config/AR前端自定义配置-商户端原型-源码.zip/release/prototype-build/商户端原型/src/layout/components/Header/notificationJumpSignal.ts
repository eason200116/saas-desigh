/**
 * @description 站内信「查看详情」点击脉冲信号。
 *   与路由解耦的全局 reactive ref：每次 handleJump 必递增，目标页 watch 必触发。
 *
 *   解决问题：vue-router 4 在 same-URL push 时抛 NavigationFailure(duplicated)，
 *   currentRoute 不更新，目标页 watch(route.fullPath) / watch(route.query.xxx)
 *   都不触发，导致「同条消息再次点击查看详情」时子 tab 不切 / 卡片不闪烁。
 *
 *   方案：handleJump 端 pulseNotificationJump() 必递增；目标页（如 useDashboardPage）
 *   订阅 notificationJumpPulse，命中即重跑子 tab 切换 + 卡片高亮重置，与 router 响应式并行。
 * @date 2026-05-11
 * @author fifty-nine
 * @scope NotificationBadge.handleJump + 各跳转目标页（如 useDashboardPage）
 */
import { ref } from 'vue';

/** 「查看详情」点击脉冲计数，仅自增、不复位。 */
export const notificationJumpPulse = ref(0);

/** 在 handleJump 起始调用，无论 router.push 成败都先触发脉冲。 */
export function pulseNotificationJump(): void {
  notificationJumpPulse.value += 1;
}
