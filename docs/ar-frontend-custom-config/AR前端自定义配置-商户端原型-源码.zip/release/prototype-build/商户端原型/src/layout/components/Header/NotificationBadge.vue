<!--
/**
 * @description 头部消息通知弹窗组件：消息 badge 入口、未读/已读切换、滚动加载、详情弹窗、批量已读、跳转闭环。
 *   - 滚动加载：NDataTable :on-scroll，距底 80px 触发 fetchList(append=true)；规范 §3
 *   - 已读切换：行点击乐观 markRead + 异步 fetchDetail；全部已读二次确认；规范 §4
 *   - 视觉：未读行加粗 + 风控引擎警示色；新消息进入时角标弹性动画；规范 §7
 * @date 2026-05-02
 * @author fifty-nine
 * @scope src/layout/components/Header
 */
-->
<template>
  <NPopover
    v-model:show="popoverShow"
    trigger="click"
    placement="bottom-end"
    :show-arrow="false"
    :style="{ padding: 0 }"
    content-style="padding: 0;"
    raw
    @update:show="onPopoverShowChange"
  >
    <template #trigger>
      <div
        class="notification-badge__trigger layout-header-trigger layout-header-trigger-min layout-header-trigger--badge"
        :class="{ 'notification-badge__trigger--bump': bumpAnimating }"
      >
        <NBadge :value="unreadCount" :max="9999" :show-zero="true">
          <div class="trigger-badge-content">
            <NIcon size="18">
              <BellOutlined />
            </NIcon>
            <span class="trigger-badge-text">{{ t('common.header.notification.trigger') }}</span>
          </div>
        </NBadge>
      </div>
    </template>

    <div class="notification-panel">
      <div class="notification-panel__header">
        <div class="notification-panel__title">
          {{ t('common.header.notification.title') }}
        </div>
        <div class="notification-panel__actions">
          <NButton
            v-if="activeTab === 'unread' && unreadCount > 0"
            size="tiny"
            tertiary
            type="primary"
            :disabled="loading"
            @click="onMarkAllRead"
          >
            {{ t('common.header.notification.actions.markAllRead') }}
          </NButton>
        </div>
      </div>

      <div class="notification-panel__body">
        <!-- 左侧 sidebar：vertical tabs -->
        <aside class="notification-panel__sidebar">
          <ul class="notification-panel__tabs">
            <li
              class="notification-panel__tab"
              :class="{ 'is-active': activeTab === 'unread' }"
              @click="switchTab('unread')"
            >
              <span class="notification-panel__tab-text">
                {{ t('common.header.notification.tabs.unread') }}
              </span>
              <span
                v-if="unreadCount > 0"
                class="notification-panel__tab-count notification-panel__tab-count--unread"
              >
                {{ formatCount(unreadCount) }}
              </span>
            </li>
            <li
              class="notification-panel__tab"
              :class="{ 'is-active': activeTab === 'read' }"
              @click="switchTab('read')"
            >
              <span class="notification-panel__tab-text">
                {{ t('common.header.notification.tabs.read') }}
              </span>
              <span
                v-if="readCount > 0"
                class="notification-panel__tab-count notification-panel__tab-count--read"
              >
                {{ formatCount(readCount) }}
              </span>
            </li>
          </ul>
        </aside>

        <!-- 右侧 content：表格 -->
        <section class="notification-panel__content">
          <div v-if="wsDisconnected" class="notification-panel__alert">
            <NAlert type="warning" size="small" :show-icon="true" :bordered="false">
              {{ t('common.header.notification.actions.wsDisconnected') }}
            </NAlert>
          </div>

          <NDataTable
            class="notification-panel__table"
            :columns="columns"
            :data="currentList"
            :row-key="rowKey"
            :loading="loading"
            :max-height="360"
            :row-props="rowProps"
            :row-class-name="rowClassName"
            :bordered="false"
            :single-line="true"
            size="small"
            virtual-scroll
            :on-scroll="handleScroll"
          >
            <template #empty>
              <div class="notification-panel__empty">
                {{
                  activeTab === 'unread'
                    ? t('common.header.notification.empty.unread')
                    : t('common.header.notification.empty.read')
                }}
              </div>
            </template>
          </NDataTable>

          <!-- 底部 加载/到底 提示 -->
          <div v-if="currentList.length > 0" class="notification-panel__footer">
            <NSpin v-if="isFetchingNext" size="small" />
            <span v-else-if="!currentHasMore" class="notification-panel__footer-text">
              —— {{ t('common.noMore') }} ——
            </span>
          </div>
        </section>
      </div>
    </div>
  </NPopover>
</template>

<script setup lang="ts">
  import { computed, h, nextTick, ref, watch } from 'vue';
  import { useRouter, isNavigationFailure, NavigationFailureType } from 'vue-router';
  import { useI18n } from 'vue-i18n';
  import {
    NAlert,
    NBadge,
    NButton,
    NDataTable,
    NIcon,
    NPopover,
    NSpin,
    NTag,
    useDialog,
    type DataTableColumns,
  } from 'naive-ui';
  import { NotificationsOutline as BellOutlined } from '@vicons/ionicons5';
  import { storeToRefs } from 'pinia';
  import { useAdminWsStore } from '@/store/modules/adminWs';
  import {
    useNotificationStore,
    type NotificationItem,
    type NotificationTab,
  } from '@/store/modules/notification';
  import { useModalHelper } from '@/hooks/useModal';
  import { useTenantOptions } from '@/hooks/useTenantOptions';
  import { formatDateStr } from '@/utils/dateUtil';
  import { resolveNotificationRoute } from './notificationRouteMap';
  import { pulseNotificationJump } from './notificationJumpSignal';
  import NotificationDetailModal from './NotificationDetailModal.vue';
  import { useNotificationLabel } from './useNotificationLabel';

  const { t, locale } = useI18n();
  const router = useRouter();
  const dialog = useDialog();
  const notificationStore = useNotificationStore();
  const adminWsStore = useAdminWsStore();
  const { unreadList, readList, unreadCount, loading, isFetchingNext, hasMore } =
    storeToRefs(notificationStore);
  const { activeTenantId, getTenantLabel, getTenantTimeZoneLabel, formatTenantDateTime } =
    useTenantOptions();
  const { openCardModal } = useModalHelper();
  const { resolveLabel: resolveMessageTypeLabel } = useNotificationLabel();

  const popoverShow = ref(false);
  const activeTab = ref<NotificationTab>('unread');
  /**
   * 「全部已读」二次确认 dialog 的显示锁：dialog teleport 到 body 后，从 NPopover 视角属于「外部」，
   * 用户点 dialog 内任意位置都会触发 popover clickoutside 自动关闭。锁开期间在 onPopoverShowChange
   * 内强制保持 popover open，dialog onAfterLeave 解锁。
   */
  const markAllDialogOpen = ref(false);
  /**
   * 详情 modal 的显示锁：与 markAllDialogOpen 同源——modal teleport 到 body 后，
   * 点关闭按钮 / X / Esc / 遮罩都会被 NPopover 视为外部点击触发 clickoutside。
   * 锁开期间在 onPopoverShowChange 内强制保持 popover open，modal onAfterLeave 解锁。
   */
  const detailModalOpen = ref(false);
  /** 当前打开的详情 modal 实例（用于 jump 时统一关闭） */
  let detailDestroy: (() => void) | null = null;
  /** 角标新消息进入弹性动画 */
  const bumpAnimating = ref(false);
  let bumpTimer: ReturnType<typeof setTimeout> | null = null;

  const rowKey = (row: NotificationItem) => row.id;

  const currentList = computed<NotificationItem[]>(() =>
    activeTab.value === 'unread' ? unreadList.value : readList.value,
  );

  const readCount = computed(() => readList.value.length);

  const currentHasMore = computed(() => hasMore.value[activeTab.value]);

  const wsDisconnected = computed(
    () => adminWsStore.status === 'error' || adminWsStore.status === 'closed',
  );

  /** 完整展示数量（不做 99+ 截断），与 NBadge max=9999 表现一致。 */
  function formatCount(n: number): string {
    return String(n);
  }

  /** 未读消息整行 + 类型加粗；风控引擎类整行红色背景强化 */
  function rowClassName(row: NotificationItem) {
    const classes: string[] = [];
    classes.push(row.readState === 0 ? 'notification-row--unread' : 'notification-row--read');
    if (row.sender === 'RISK_ENGINE') classes.push('notification-row--risk');
    return classes.join(' ');
  }

  const columns = computed<DataTableColumns<NotificationItem>>(() => [
    {
      key: 'messageType',
      title: t('common.header.notification.columns.type'),
      width: 180,
      render: (row) =>
        h(
          'span',
          {
            class: [
              'notification-cell__type',
              row.readState === 1 ? 'notification-cell__type--read' : '',
              row.sender === 'RISK_ENGINE' ? 'notification-cell__type--risk' : '',
            ],
          },
          resolveMessageTypeLabel(row),
        ),
    },
    {
      key: 'content',
      title: t('common.header.notification.columns.content'),
      width: 350,
      className: 'notification-cell__content-cell',
      ellipsis: { tooltip: true },
      render: (row) => row.content,
    },
    {
      key: 'site',
      title: t('common.header.notification.columns.site'),
      // 列宽 +50px（110 → 160）容纳更长商户名；超出列宽时由 site-tag 样式 word-break 换行展示
      width: 160,
      align: 'center',
      titleAlign: 'center',
      render: (row) => {
        if (row.triggerTenantId === null || row.triggerTenantId === undefined) {
          return h('span', { class: 'notification-cell__empty' }, '--');
        }
        // 与系统表格「商户」列样板对齐（参考 finance/withdrawOrder/workbench/index.vue:282）：
        // NTag size=small + bordered=true + type=info；本列不做截断，允许换行多行展示
        return h(
          NTag,
          {
            type: 'info',
            size: 'small',
            bordered: true,
            class: 'notification-cell__site-tag',
          },
          { default: () => getTenantLabel(row.triggerTenantId, row.triggerTenantName, '--') },
        );
      },
    },
    {
      key: 'sender',
      title: t('common.header.notification.columns.sender'),
      width: 80,
      render: (row) =>
        h(
          'span',
          {
            class: [
              'notification-cell__sender',
              row.sender === 'RISK_ENGINE' ? 'notification-cell__sender--risk' : '',
            ],
          },
          row.senderName || t(`common.header.notification.senders.${row.sender}`),
        ),
    },
    {
      key: 'sendTime',
      title: () => {
        const baseTitle = t('common.header.notification.columns.time');
        const tzLabel = getTenantTimeZoneLabel(activeTenantId.value);
        if (!tzLabel) return baseTitle;
        return h('span', { class: 'notification-column-title' }, [
          h('span', null, baseTitle),
          h('span', { class: 'notification-column-title__suffix' }, `(${tzLabel})`),
        ]);
      },
      width: 180,
      render: (row) => {
        // 时间戳为 0 守卫（规范 15.8）
        if (!row.sendTime) return '--';
        // 统一以"当前激活商户"时区为基准，与表头括号 (UTC+x) 标签同源；
        // 行触发商户可能为 null（系统级消息）或与激活商户不同时区，沿用行级会与表头标签错位。
        // 拿不到激活商户时区时退回当前账号时区（参照 withdrawOrder/workbench 写法）。
        const tzLabel = getTenantTimeZoneLabel(activeTenantId.value);
        const text = tzLabel
          ? formatTenantDateTime(row.sendTime, activeTenantId.value, 'yyyy-MM-dd HH:mm:ss', '--')
          : formatDateStr(row.sendTime, 'yyyy-MM-dd HH:mm:ss');
        return h('span', { class: 'notification-cell__time' }, text || '--');
      },
    },
  ]);

  /** 行点击：点到非按钮 / 非链接区，打开详情 modal */
  const rowProps = (row: NotificationItem) => ({
    style: 'cursor: pointer;',
    onClick: (event: MouseEvent) => {
      const target = event.target as HTMLElement;
      if (target.closest('.n-button') || target.closest('a')) {
        return;
      }
      openDetailModal(row);
    },
  });

  // -- popover 打开行为：每次打开都强刷列表（reset 跳过 5 分钟缓存 + 清 cursor 重头拉），
  //    以及在 dialog 期间强制保持打开 --
  function onPopoverShowChange(show: boolean) {
    // 二次确认 dialog / 详情 modal 显示期间，clickoutside 试图关闭 popover 时强制恢复，
    // 避免 dialog / modal 内点击（含关闭按钮 / X / Esc / 遮罩）连带关闭通知列表。
    if (!show && (markAllDialogOpen.value || detailModalOpen.value)) {
      void nextTick(() => {
        popoverShow.value = true;
      });
      return;
    }
    if (!show) return;
    // 业务诉求：用户每次点开弹窗都必须发 /api/SysUserNotify/GetScrollList 请求。
    // reset:true 同时跳过 store 5 分钟 lastFetchedAt 缓存判定 + 重置 cursor/hasMore，重头拉首页。
    void notificationStore.fetchList(activeTab.value, { reset: true });
  }

  // -- tab 切换：reset 当前 tab 重新拉 --
  function switchTab(tab: NotificationTab) {
    if (activeTab.value === tab) return;
    activeTab.value = tab;
  }

  watch(activeTab, (tab) => {
    void notificationStore.fetchList(tab, { reset: true });
  });

  // -- 滚动加载：距底 80px 触发下一页（规范 §3.2） --
  function handleScroll(e: Event) {
    const el = e.target as HTMLElement | null;
    if (!el) return;
    const { scrollTop, clientHeight, scrollHeight } = el;
    if (scrollHeight - scrollTop - clientHeight < 80) {
      void notificationStore.fetchList(activeTab.value, { append: true });
    }
  }

  // -- 全部已读：二次确认（规范 §4.3） --
  // count 用「当前已加载到本地未读列表」的真实条数，与 store.markAllRead 的实际行为
  // （只标记 unreadList 已加载条目，受后端 MarkAllRead 端点缺位限制）保持一致，避免显示「全部 N 条」却只 mark 一部分误导用户。
  function onMarkAllRead() {
    const count = unreadList.value.length;
    if (count === 0) return;
    markAllDialogOpen.value = true;
    dialog.warning({
      title: t('common.tip'),
      content: `${t('common.header.notification.actions.markAllRead')}（${count}）？`,
      positiveText: t('common.confirm'),
      negativeText: t('common.cancel'),
      onPositiveClick: async () => {
        // 「确定」必须始终关闭当前提示弹窗：失败由 axios 拦截器 / store fetchUnreadCount 自校准，
        // 这里 try/catch 兜底，避免 promise reject 被 Naive UI dialog 视同返回 false 阻止关闭。
        try {
          await notificationStore.markAllRead();
          // 标记完成后重新拉取 GetScrollList，让 unreadList 与服务端真值同步（覆盖乐观更新可能漏掉的并发新增未读）。
          await notificationStore.fetchList(activeTab.value, { reset: true });
        } catch {
          /* 错误已由全局拦截器消化，吞掉以保证 dialog 关闭；不影响 popover */
        }
      },
      // dialog 完全离开（含动画）后才解锁，覆盖确定 / 取消 / X / 遮罩 / Esc 全部关闭路径。
      onAfterLeave: () => {
        markAllDialogOpen.value = false;
      },
    });
  }

  // -- 行点击：乐观 markRead + 打开详情 modal + 异步 fetchDetail（规范 §4.2） --
  function openDetailModal(row: NotificationItem) {
    if (row.readState === 0) {
      void notificationStore.markRead([row.id]);
    }

    /** 详情数据：先用列表行兜底，fetchDetail 返回后合并 */
    const detailItem = ref<NotificationItem>({ ...row, readState: 1 });

    // 先开锁再创建 modal：onAfterLeave 在所有关闭路径（关闭按钮 / X / Esc / 遮罩 / 主动 destroy）
    // 退场动画结束后解锁。锁定期间 onPopoverShowChange 拦截 clickoutside，保持 popover 开启。
    detailModalOpen.value = true;
    const { destroy } = openCardModal({
      title: t('common.header.notification.detailTitle'),
      width: '600px',
      maskClosable: true,
      closeOnEsc: true,
      content: ({ destroy: innerDestroy }) =>
        h(NotificationDetailModal, {
          item: detailItem.value,
          onClose: () => innerDestroy(),
          onJump: handleJump,
        }),
      onAfterLeave: () => {
        detailModalOpen.value = false;
      },
    });
    detailDestroy = destroy;

    // 异步拉真值：成功就合并 detailAction / relatedBizId 等扩展字段
    void notificationStore.fetchDetail(row.id).then((fresh) => {
      if (fresh) detailItem.value = fresh;
    });
  }

  // -- 跳转：关 modal + 关 popover + push 路由 + pulse 信号 --
  //
  // pulseNotificationJump 是与路由解耦的全局 reactive ref +1。无论 router.push 成败
  // （包含同 URL 触发 NavigationFailure.duplicated 不更新 currentRoute 的场景），
  // 目标页 watch(notificationJumpPulse) 必然触发——绕开 vue-router 4 在 KeepAlive
  // 缓存组件 + same-name push 下 watch(route.fullPath/query) 触发不稳定的边界。
  //
  // 必须放在 router.push 之后：目标页 watch callback 内会读 route.query.warningType
  // 决策（如「URL 带 warningType 才切 dashboard 主 tab」），如果 pulse 在 push 前触发，
  // watch 跑时 URL 还是旧值，条件判断走错分支。先 await push 确保 URL 已落地再 pulse。
  async function handleJump(row: NotificationItem) {
    const target = resolveNotificationRoute(row);
    if (!target) return;
    detailDestroy?.();
    detailDestroy = null;
    // 跳转路径需要同时关闭 popover；先手动清锁，避免 onPopoverShowChange 拦截 popoverShow=false。
    // modal 退场动画结束后 onAfterLeave 会再 set 一次 false（幂等，无副作用）。
    detailModalOpen.value = false;
    popoverShow.value = false;
    try {
      await router.push(target);
    } catch (err) {
      // duplicated 时 URL 没变但本来就是目标态，照常 pulse 让目标页响应
      if (!isNavigationFailure(err, NavigationFailureType.duplicated)) throw err;
    }
    pulseNotificationJump();
  }

  // -- 切语言重拉：后端按请求 Language 字段渲染 MessageContent，切语言后必须重新拉取（文档 §6） --
  watch(locale, () => {
    void notificationStore.fetchUnreadCount();
    void notificationStore.refetchAfterLocaleChange(activeTab.value);
  });

  // -- 角标弹性动画：unreadCount 增加时触发一次 320ms 动画（规范 §7.5 第 1 条） --
  watch(unreadCount, (next, prev) => {
    if (next > prev) {
      bumpAnimating.value = false;
      void nextTick(() => {
        bumpAnimating.value = true;
        if (bumpTimer) clearTimeout(bumpTimer);
        bumpTimer = setTimeout(() => {
          bumpAnimating.value = false;
        }, 320);
      });
    }
  });
</script>

<style lang="less" scoped>
  .notification-badge__trigger {
    cursor: pointer;
  }

  /** 弹性动画：scale(1.18) → scale(1) 320ms（规范 §7.5）*/
  .notification-badge__trigger--bump {
    animation: notification-badge-bump 320ms cubic-bezier(0.4, 0, 0.2, 1);
  }

  @keyframes notification-badge-bump {
    0% {
      transform: scale(1);
    }
    35% {
      transform: scale(1.18);
    }
    100% {
      transform: scale(1);
    }
  }

  .layout-header-trigger {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    height: 44px;
    margin: 0 2px;
    padding: 0 10px;
    border: 0;
    border-radius: 6px;
    background: transparent;
    color: rgb(255 255 255 / 0.86);
    transition:
      background-color 0.2s cubic-bezier(0.4, 0, 0.2, 1),
      color 0.2s cubic-bezier(0.4, 0, 0.2, 1);
  }

  .layout-header-trigger:hover {
    background: rgb(255 255 255 / 0.12);
    color: #fff;
  }

  .layout-header-trigger--badge {
    min-width: 54px;
  }

  .trigger-badge-content {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    gap: 2px;
  }

  .trigger-badge-text {
    font-size: 12px;
    line-height: 1.1;
    color: rgb(255 255 255 / 0.72);
    white-space: nowrap;
  }

  // 消息收件箱弹窗
  .notification-panel {
    width: 1100px;
    max-width: 96vw;
    background: #fff;
    border-radius: 8px;
    box-shadow: 0 6px 24px rgb(0 21 41 / 14%);
    overflow: hidden;
  }

  .notification-panel__header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 12px;
    padding: 13px 16px;
    border-bottom: 1px solid #f0f0f0;
  }

  .notification-panel__title {
    font-size: 14px;
    font-weight: 600;
    color: #1f2937;
  }

  .notification-panel__actions {
    display: flex;
    align-items: center;
    gap: 8px;
  }

  .notification-panel__body {
    display: flex;
    padding: 4px 0;
  }

  .notification-panel__sidebar {
    flex-shrink: 0;
    width: 140px;
    border-right: 1px solid #f0f0f0;
    background: #fafbfc;
  }

  .notification-panel__tabs {
    list-style: none;
    margin: 0;
    padding: 0;
  }

  .notification-panel__tab {
    position: relative;
    display: flex;
    align-items: center;
    justify-content: flex-start;
    gap: 6px;
    min-height: 36px;
    padding: 10px 14px;
    font-size: 13px;
    color: #1f2937;
    cursor: pointer;
    transition:
      background-color 0.15s,
      color 0.15s;

    &:hover {
      background: rgb(255 255 255 / 0.76);
    }

    &.is-active {
      color: #0faaa7;
      background: #fff;

      &::after {
        position: absolute;
        top: 0;
        right: -1px;
        bottom: 0;
        width: 2px;
        background: #0faaa7;
        content: '';
      }
    }

    &.is-active .notification-panel__tab-text {
      color: #0faaa7;
      font-weight: 500;
    }
  }

  .notification-panel__tab-text {
    flex: 1;
    line-height: 1.4;
  }

  .notification-panel__tab-count {
    flex-shrink: 0;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    min-width: 18px;
    height: 16px;
    padding: 0 5px;
    border-radius: 8px;
    font-size: 10px;
    font-weight: 700;
    line-height: 1;
  }

  .notification-panel__tab-count--unread {
    background: #ef4444;
    color: #fff;
  }

  .notification-panel__tab-count--read {
    background: #d1d5db;
    color: #fff;
  }

  // 右侧 content
  .notification-panel__content {
    flex: 1;
    min-width: 0;
    display: flex;
    flex-direction: column;
  }

  .notification-panel__alert {
    padding: 8px 12px 0;
  }

  .notification-panel__empty {
    padding: 48px 16px;
    text-align: center;
    font-size: 13px;
    color: var(--n-text-color-disabled, rgba(0, 0, 0, 0.3));
  }

  // 底部 加载/到底 提示
  .notification-panel__footer {
    display: flex;
    align-items: center;
    justify-content: center;
    min-height: 32px;
    padding: 6px 0;
    border-top: 1px solid #f5f5f5;
    background: #fafbfc;
  }

  .notification-panel__footer-text {
    font-size: 11px;
    color: #9ca3af;
    letter-spacing: 0.04em;
  }

  // 子组件内部样式：用 ::v-deep 命中 NDataTable cell 节点（CLAUDE.md 样式深度选择器约束）
  // —— 表头：浅灰背景 + 字号字色优化
  ::v-deep(.n-data-table .n-data-table-thead) {
    background: #fafbfc;
  }

  ::v-deep(.n-data-table .n-data-table-th) {
    padding: 9px 10px;
    background: #fafbfc;
    border-top: none;
    border-bottom: 1px solid #f0f0f0;
    font-size: 12px;
    font-weight: 500;
    color: #6b7280;
  }

  // 表体：行高、字号、字色对齐截图
  ::v-deep(.n-data-table .n-data-table-td) {
    padding: 10px;
    border-bottom: 1px solid #f5f5f5;
    font-size: 13px;
    color: #1f2937;
  }

  ::v-deep(.n-data-table .n-data-table-td.notification-cell__content-cell) {
    font-size: 12px;
  }

  ::v-deep(.n-data-table .n-data-table-tr:last-child .n-data-table-td) {
    border-bottom: none;
  }

  // 类型列加粗（未读行更显著）
  ::v-deep(.notification-cell__type) {
    color: #1f2937;
  }

  ::v-deep(.notification-cell__type--read) {
    color: #6b7280;
    font-weight: 400;
  }

  ::v-deep(.notification-cell__type--risk) {
    color: #d97706;
  }

  ::v-deep(.notification-row--unread .notification-cell__type) {
    font-weight: 600;
  }

  // 风控引擎行：整行底色微调，强化运维盯盘感（规范 §7.2）
  ::v-deep(.notification-row--unread.notification-row--risk .n-data-table-td) {
    background-color: rgba(217, 119, 6, 0.04) !important;
  }

  ::v-deep(.notification-cell__sender--risk) {
    color: #d97706;
    font-weight: 600;
  }

  ::v-deep(.notification-cell__empty) {
    color: #9ca3af;
    font-size: 12px;
  }

  ::v-deep(.notification-cell__sender),
  ::v-deep(.notification-cell__time) {
    color: #6b7280;
    font-size: 12px;
  }

  ::v-deep(.notification-cell__time) {
    color: #8a94a6;
    font-variant-numeric: tabular-nums;
  }

  ::v-deep(.notification-column-title) {
    display: inline-flex;
    align-items: baseline;
    gap: 6px;
    white-space: nowrap;
  }

  ::v-deep(.notification-column-title__suffix) {
    color: #9ca3af;
    font-size: 11px;
    font-weight: 400;
  }

  // 触发商户标签：与系统表格「商户」列保持一致（NTag size=small + type=info + bordered=true 默认主题样式）
  // 内容超出列宽时 word-break 换行展示；NTag 容器允许多行高度自适应
  ::v-deep(.notification-cell__site-tag) {
    max-width: 100%;
    height: auto;
    padding-top: 2px;
    padding-bottom: 2px;
    font-size: 12px;
    line-height: 1.4;
    white-space: normal;
    word-break: break-word;
  }

  ::v-deep(.notification-cell__site-tag .n-tag__content) {
    white-space: normal;
    word-break: break-word;
  }

  // 表格行光标 + hover
  ::v-deep(.n-data-table .n-data-table-tr) {
    cursor: pointer;
  }

  ::v-deep(.n-data-table .n-data-table-tr:hover .n-data-table-td) {
    background-color: #f7f9ff !important;
  }

  // 兜掉 NDataTable 包裹层默认 border（防止粉红顶线）
  ::v-deep(.n-data-table) {
    border: none;
  }

  ::v-deep(.n-data-table .n-data-table-wrapper) {
    border-top: none;
  }
</style>
