import {
  SearchOutlined,
  MenuFoldOutlined,
  MenuUnfoldOutlined,
  FullscreenOutlined,
  FullscreenExitOutlined,
  PoweroffOutlined,
  GithubOutlined,
  LockOutlined,
  ReloadOutlined,
  LogoutOutlined,
  UserOutlined,
  CheckOutlined,
} from '@vicons/antd';

export default {
  LockOutlined,
  GithubOutlined,
  SearchOutlined,
  MenuFoldOutlined,
  MenuUnfoldOutlined,
  FullscreenOutlined,
  FullscreenExitOutlined,
  PoweroffOutlined,
  ReloadOutlined,
  LogoutOutlined,
  UserOutlined,
  CheckOutlined,
};
