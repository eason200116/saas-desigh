<template>
  <router-view v-slot="{ Component }">
    <keep-alive v-if="keepAliveComponents.length" :include="keepAliveComponents" :max="20">
      <component :is="Component" />
    </keep-alive>
    <component v-else :is="Component" />
  </router-view>
</template>

<script setup lang="ts">
  // ParentLayout 是所有"嵌套子路由"的中间层（finance.ts 显式使用 + generator.ts 动态生成）。
  // 必须自己包一层 keep-alive：外层 layout/components/Main 缓存的是顶层 router-view 组件，
  // 切兄弟子路由时 ParentLayout 实例不变但内部 <router-view /> 会销毁旧子组件，
  // 所以叶子页面的 ProCrudTable 状态、表单输入、滚动位置都会丢失。
  // 加 defineOptions({ name: 'ParentLayout' }) 是为了让外层 Main 的 keep-alive 也能命中它，
  // 跨顶部多 tab 切走再切回时不丢失 ParentLayout 自身实例（进而保留内部 keep-alive 缓存）。
  // 'ParentLayout' 字符串在 store/modules/asyncRoute.ts 中作为 keepAliveComponents 默认值常驻。
  import { computed } from 'vue';
  import { useAsyncRouteStore } from '@/store/modules/asyncRoute';

  defineOptions({ name: 'ParentLayout' });

  const asyncRouteStore = useAsyncRouteStore();
  const keepAliveComponents = computed(() => asyncRouteStore.keepAliveComponents);
</script>
