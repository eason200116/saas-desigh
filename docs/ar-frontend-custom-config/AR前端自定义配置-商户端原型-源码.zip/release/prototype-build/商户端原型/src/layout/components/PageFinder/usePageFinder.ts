import { ref } from 'vue';

// 找页面抽屉开关的模块级共享状态（Header 触发按钮 ↔ 抽屉本体 共用同一份）。
// 默认打开：进入商户端首次即展开（用户 2026-07-18 拍板「默认打开」）。
const show = ref(true);

export function usePageFinder() {
  return {
    show,
    toggle: () => (show.value = !show.value),
    open: () => (show.value = true),
    close: () => (show.value = false),
  };
}
