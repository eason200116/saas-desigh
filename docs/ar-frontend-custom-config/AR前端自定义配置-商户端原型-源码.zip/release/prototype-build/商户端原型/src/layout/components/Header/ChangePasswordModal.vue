<template>
  <n-form
    ref="formRef"
    label-placement="top"
    size="large"
    :model="formInline"
    :rules="rules"
    @submit="handleSubmit"
  >
    <n-form-item path="oldPassword">
      <n-input
        type="password"
        v-model:value="formInline.oldPassword"
        :placeholder="t('common.oldPassword')"
      >
        <template #prefix>
          <n-icon size="18" color="#808695">
            <LockIcon />
          </n-icon>
        </template>
      </n-input>
    </n-form-item>
    <n-form-item path="newPassword">
      <n-input
        v-model:value="formInline.newPassword"
        type="password"
        show-password-on="click"
        :placeholder="t('common.newPassword')"
      >
        <template #prefix>
          <n-icon size="18" color="#808695">
            <LockIcon />
          </n-icon>
        </template>
      </n-input>
    </n-form-item>
    <n-form-item path="newPassword2">
      <n-input
        v-model:value="formInline.newPassword2"
        type="password"
        show-password-on="click"
        :placeholder="t('common.confirmPassword')"
      >
        <template #prefix>
          <n-icon size="18" color="#808695">
            <LockIcon />
          </n-icon>
        </template>
      </n-input>
    </n-form-item>
    <n-form-item>
      <n-button type="primary" attr-type="submit" size="large" :loading="loading" block>
        {{ t('common.modify') }}
      </n-button>
    </n-form-item>
  </n-form>
</template>

<script setup lang="ts">
  import { computed, reactive, ref } from 'vue';
  import { NButton, NForm, NFormItem, NIcon, NInput, useMessage } from 'naive-ui';
  import type { FormInst, FormItemRule } from 'naive-ui';
  import { useI18n } from 'vue-i18n';
  import { api } from '@/api';
  import { useUserStore } from '@/store/modules';
  import { TABS_ROUTES } from '@/store/mutation-types';
  import LockIcon from './icons/LockIcon.vue';

  interface PasswordForm {
    oldPassword: string;
    newPassword: string;
    newPassword2: string;
  }

  const emit = defineEmits<{ close: []; success: [] }>();

  const { t } = useI18n();
  const message = useMessage();
  const userStore = useUserStore();

  const formRef = ref<FormInst | null>(null);
  const loading = ref(false);
  const formInline = reactive<PasswordForm>({
    oldPassword: '',
    newPassword: '',
    newPassword2: '',
  });

  const rules = computed<Record<string, FormItemRule>>(() => ({
    oldPassword: {
      required: true,
      message: `${t('common.pleaseEnter')} ${t('common.oldPassword')}`,
      trigger: 'blur',
    },
    newPassword: {
      required: true,
      message: `${t('common.pleaseEnter')} ${t('common.newPassword')}`,
      trigger: 'blur',
    },
    newPassword2: {
      required: true,
      trigger: 'blur',
      validator: (_rule: FormItemRule, value: string) => {
        if (!value) {
          return new Error(t('common.header.validation.enterNewPasswordAgain'));
        }
        if (value !== formInline.newPassword) {
          return new Error(t('common.header.validation.passwordMismatch'));
        }
        return true;
      },
    },
  }));

  // 改密成功后接口流程：reset -> loginOff -> 清理本地状态 -> 刷新。
  // 放在组件内部独立闭合，父组件只负责弹窗生命周期。
  async function handleSubmit(e: Event) {
    e.preventDefault();
    try {
      await formRef.value?.validate();
    } catch {
      return;
    }

    loading.value = true;
    try {
      const { oldPassword, newPassword } = formInline;
      const { code, msg } = await api.system.resetPassword({ oldPassword, newPassword });
      if (code !== 0) {
        message.error(msg || t('common.edit_error'));
        return;
      }
      formRef.value?.restoreValidation();

      const { code: codeOut, msg: msgOut } = await api.admin.loginOff();
      if (codeOut !== 0) {
        message.error(msgOut);
        return;
      }
      emit('success');
      emit('close');
      await userStore.logout();
      localStorage.removeItem(TABS_ROUTES);
      message.success(t('common.edit_success'));
      location.reload();
    } finally {
      loading.value = false;
    }
  }
</script>
