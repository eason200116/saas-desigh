<!--
/**
 * @description Header 项目配置入口图标：对齐 Soybean Admin，采用 majesticons:color-swatch-line（调色板 + 拾色器）造型。fill 使用 currentColor，随 n-icon 主题色继承。
 * @author Shaba River
 * @date 2026-04-19
 * @scope src/layout/components/Header
 */
-->
<template>
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width="1em"
    height="1em"
    viewBox="0 0 24 24"
    aria-hidden="true"
    role="img"
  >
    <g fill="currentColor">
      <path
        d="M2 5a3 3 0 0 1 3-3h4a3 3 0 0 1 3 3v16a1 1 0 0 1-1 1H5a3 3 0 0 1-3-3V5zm3-1a1 1 0 0 0-1 1v14a1 1 0 0 0 1 1h5V5a1 1 0 0 0-1-1H5z"
      />
      <path
        d="M14.707 7.121a1 1 0 0 0-1.414 0l-1.586 1.586a1 1 0 1 1-1.414-1.414l1.586-1.586a3 3 0 0 1 4.242 0l2.172 2.172a3 3 0 0 1 .115 4.12H19a3 3 0 0 1 3 3v4a3 3 0 0 1-3 3h-8a1 1 0 1 1 0-2h8a1 1 0 0 0 1-1v-4a1 1 0 0 0-1-1h-2.586l-4.707 4.708a1 1 0 1 1-1.414-1.414l6.586-6.586a1 1 0 0 0 0-1.414L14.707 7.12zM7 15a1 1 0 0 1 1 1v.001a1 1 0 1 1-2 0V16a1 1 0 0 1 1-1z"
      />
    </g>
  </svg>
</template>

<script lang="ts" setup>
  defineOptions({
    name: 'ColorSwatchIcon',
  });
</script>
