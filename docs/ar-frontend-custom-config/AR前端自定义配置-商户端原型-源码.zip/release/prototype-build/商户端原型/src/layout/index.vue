<template>
  <n-layout class="layout" :position="fixedMenu" :has-sider="showSider">
    <n-layout-sider
      v-if="showSider"
      show-trigger="bar"
      :position="fixedMenu"
      :collapsed="effectiveCollapsed"
      collapse-mode="width"
      :collapsed-width="64"
      :width="leftMenuWidth"
      :native-scrollbar="false"
      :inverted="inverted"
      :class="['layout-sider', inverted ? 'is-inverted' : 'is-light']"
      @collapse="collapsed = true"
      @expand="collapsed = false"
    >
      <Logo v-if="showSiderLogo" :collapsed="effectiveCollapsed" />
      <AsideMenu
        :collapsed="effectiveCollapsed"
        location="left"
        @update:collapsed="collapsed = $event"
      />
    </n-layout-sider>

    <n-drawer
      v-model:show="showSideDrawer"
      :width="menuWidth"
      placement="left"
      class="layout-side-drawer"
    >
      <n-layout-sider
        :position="fixedMenu"
        :collapsed="false"
        :width="menuWidth"
        :native-scrollbar="false"
        :inverted="inverted"
        :class="['layout-sider', inverted ? 'is-inverted' : 'is-light']"
      >
        <Logo :collapsed="collapsed" />
        <AsideMenu location="left" />
      </n-layout-sider>
    </n-drawer>

    <!-- 直接使用 div 减少 DOM 层级 -->
    <div class="layout-main">
      <PageHeader
        :collapsed="effectiveCollapsed"
        :inverted="inverted"
        :header-style="headerStyle"
        :header-inverted="getHeaderInverted"
        @update:collapsed="collapsed = $event"
      />

      <TabsView v-if="isMultiTabs" :collapsed="effectiveCollapsed" />

      <main ref="layoutContentRef" class="layout-content" :class="contentClasses">
        <MainView />
      </main>
      <n-back-top :right="30" />
    </div>

    <RoleSwitcher />
    <ChangeLogFab />
    <PageManual />
    <PageFinder v-if="isTenant" />
  </n-layout>
</template>

<script lang="ts" setup>
  import { ref, unref, computed, onMounted, onBeforeUnmount, provide } from 'vue';
  import { useNotification, useThemeVars } from 'naive-ui';
  import { useIntervalFn } from '@vueuse/core';
  import { useI18n } from 'vue-i18n';
  import { Logo } from './components/Logo';
  import { TabsView } from './components/TagsView';
  import { MainView } from './components/Main';
  import { AsideMenu } from './components/Menu';
  import { PageHeader } from './components/Header';
  import { RoleSwitcher } from '@/components/RoleSwitcher';
  import { ChangeLogFab } from '@/components/ChangeLogFab';
  import { PageManual } from '@/components/PageManual';
  import { PageFinder } from './components/PageFinder';
  import { useRecentVisits } from './components/PageFinder/useRecentVisits';
  import { useRouter } from 'vue-router';
  import { useProjectSetting } from '@/hooks/setting';
  import { useProjectSettingStore, useRoleStore, useUserStore } from '@/store/modules';
  import { LayoutContentRectKey, type LayoutContentRect } from './contentRectContext';

  // 获取主题变量
  const themeVars = useThemeVars();

  // ============ 找页面抽屉（仅商户端）============
  const _pfRoleStore = useRoleStore();
  const isTenant = computed(() => _pfRoleStore.role === 'tenant');
  // 商户端：记录最近访问，供找页面抽屉「最近访问」组用（只记有标题的真实叶子页）
  const _pfUserStore = useUserStore();
  const { load: loadRecent, record: recordRecent } = useRecentVisits();
  loadRecent(String(_pfUserStore.info?.userId ?? 'anon'));
  const _pfRouter = useRouter();
  _pfRouter.afterEach((to) => {
    if (_pfRoleStore.role !== 'tenant') return;
    const title = to.meta?.title as string | undefined;
    if (to.name && title && to.meta?.hidden !== true) {
      recordRecent({ name: String(to.name), title });
    }
  });

  // ============ 常量定义 ============
  const COLLAPSE_WIDTH = 950;
  const XL_BREAKPOINT = 1280;
  const VERSION_CHECK_INTERVAL = 30000; // 30秒检查一次
  const VERSION_STORAGE_KEY = 'ar_version';

  const pauseVersionCheck = () => {};

  // ============ 依赖注入 ============
  const { t } = useI18n();
  const notification = useNotification();
  const settingStore = useProjectSettingStore();

  const { navTheme, menuSetting, multiTabsSetting } = useProjectSetting();

  // ============ 响应式状态 ============
  const collapsed = ref(false);
  const isCompactMenu = ref(false);
  const { mobileWidth, menuWidth } = unref(menuSetting);

  // ============ 计算属性 ============
  const isMobile = computed<boolean>({
    get: () => settingStore.getIsMobile,
    set: (val) => settingStore.setIsMobile(val),
  });

  // 直接从 store 获取 navMode，确保响应式
  const navMode = computed(() => settingStore.navMode);

  // Menu 始终固定
  const fixedMenu = computed((): 'absolute' | 'static' => 'absolute');

  // 是否开启混合菜单
  const mixMenu = computed(() => unref(menuSetting).mixMenu);

  // 是否显示侧边栏 (vertical 模式或 horizontal-mix 混合菜单模式)
  const showSider = computed(() => {
    if (isMobile.value) return false;
    // vertical 模式始终显示侧边栏
    if (navMode.value === 'vertical') return true;
    // horizontal-mix 模式且开启混合菜单时显示侧边栏（显示子菜单）
    if (navMode.value === 'horizontal-mix' && mixMenu.value) return true;
    return false;
  });

  // 是否显示侧边栏 Logo (仅 vertical 模式显示，混合模式 Logo 在 Header 中)
  const showSiderLogo = computed(() => navMode.value === 'vertical');

  const isMultiTabs = computed(() => unref(multiTabsSetting).show);

  const inverted = computed(() => {
    return ['dark', 'header-dark'].includes(unref(navTheme));
  });

  const getHeaderInverted = computed(() => {
    return ['light', 'header-dark'].includes(unref(navTheme)) ? inverted.value : !inverted.value;
  });

  const effectiveCollapsed = computed(
    () => !isMobile.value && (collapsed.value || isCompactMenu.value),
  );

  const leftMenuWidth = computed(() => {
    const { minMenuWidth, menuWidth } = unref(menuSetting);
    return effectiveCollapsed.value ? minMenuWidth : menuWidth;
  });

  // Header 动态样式 (根据侧边栏调整 left，使用主题色背景)
  const headerStyle = computed(() => {
    const baseStyle = {
      backgroundColor: themeVars.value.primaryColor,
    };
    // Only vertical mode has sidebar, others should have left: 0
    if (isMobile.value || !showSider.value) {
      return { ...baseStyle, left: '0px' };
    }
    return { ...baseStyle, left: `${leftMenuWidth.value}px` };
  });

  // 控制显示或隐藏移动端侧边栏
  const showSideDrawer = computed({
    get: () => isMobile.value && collapsed.value,
    set: (val) => (collapsed.value = val),
  });

  // 内容区域样式类
  const contentClasses = computed(() => ({
    'layout-content-main': !isMultiTabs.value, // 无 TabsView
    'layout-content-main-fix': isMultiTabs.value, // 有 TabsView
    'layout-content-themed': true, // 使用主题背景色
  }));

  // ============ 方法 ============
  const checkMobileMode = () => {
    const clientWidth = document.body.clientWidth;
    isMobile.value = clientWidth <= mobileWidth;
    isCompactMenu.value = clientWidth < XL_BREAKPOINT;
    if (isMobile.value) {
      collapsed.value = false;
    }
  };

  const watchWidth = () => {
    collapsed.value = document.body.clientWidth <= COLLAPSE_WIDTH;
    checkMobileMode();
  };

  // ============ 版本检查 ============
  let isChecking = false;

  // ============ Layout 主区域几何信息暴露 ============
  // 给非 ProTabs 的 ProCrudTable 等"撑满 page area"组件提供准确 ceiling，
  // 已扣除 layout-content 的 padding-top / padding-bottom，避免撑出 8px 触发滚动。
  const layoutContentRef = ref<HTMLElement | null>(null);
  const contentRect = ref<LayoutContentRect>({ top: 0, bottom: 0, height: 0 });

  function measureContentRect() {
    const el = layoutContentRef.value;
    if (!el) return;
    const rect = el.getBoundingClientRect();
    const style = getComputedStyle(el);
    const paddingTop = parseFloat(style.paddingTop) || 0;
    const paddingBottom = parseFloat(style.paddingBottom) || 0;
    const top = rect.top + paddingTop;
    const bottom = rect.bottom - paddingBottom;
    const cur = contentRect.value;
    // 只有数值真变化时写入，避免触发不必要的下游 watcher。height = bottom - top 是派生值，
    // top / bottom 不变 → height 必然不变，只比这两个即可。
    if (cur.top !== top || cur.bottom !== bottom) {
      contentRect.value = { top, bottom, height: bottom - top };
    }
  }

  provide(LayoutContentRectKey, { contentRect });

  // ResizeObserver 观察 content-box（默认 border-box 不感知 padding 变化），
  // 这样 TabsView 显隐导致 padding-top 从 76 ↔ 112 切换时能被捕获并更新 contentRect。
  let contentRectObserver: ResizeObserver | null = null;

  // ============ 生命周期 ============
  onMounted(() => {
    watchWidth();
    window.addEventListener('resize', watchWidth);

    measureContentRect();
    if (typeof ResizeObserver !== 'undefined' && layoutContentRef.value) {
      contentRectObserver = new ResizeObserver(() => measureContentRect());
      contentRectObserver.observe(layoutContentRef.value, { box: 'content-box' });
    }
    window.addEventListener('resize', measureContentRect);
  });

  onBeforeUnmount(() => {
    window.removeEventListener('resize', watchWidth);
    pauseVersionCheck();

    contentRectObserver?.disconnect();
    contentRectObserver = null;
    window.removeEventListener('resize', measureContentRect);
  });
</script>

<style lang="less">
  .layout-side-drawer {
    // Background color is handled by n-layout-sider's inverted prop

    .layout-sider {
      min-height: 100vh;
      box-shadow: 2px 0 8px 0 rgb(29 35 41 / 5%);
      position: relative;
      z-index: 13;
      transition: all 0.2s ease-in-out;
    }
  }

  // 深色（inverted）侧边栏加一层渐变质感。
  // Naive UI 的 siderColor token 只接单色，gradient 需走 CSS background 覆盖。
  // 通过模板上的 :class="inverted ? 'is-inverted' : 'is-light'" 控制生效范围。
  .layout-sider.is-inverted {
    background: linear-gradient(180deg, #0f172a 0%, #0b1220 100%) !important;
  }
</style>
<style lang="less" scoped>
  .layout {
    // Let n-layout handle flex direction based on has-sider prop
    flex: auto;
    height: 100%;
    background: var(--ui-bg-page);
    .layout-sider {
      min-height: 100vh;
      box-shadow: 2px 0 8px 0 rgb(29 35 41 / 5%);
      position: relative;
      z-index: 13;
      transition: all 0.2s ease-in-out;

      // 侧边栏内 NScrollbar 窄化 & hover 显形（notion/linear 风格）
      ::v-deep(.n-scrollbar-rail.n-scrollbar-rail--vertical) {
        width: 4px;
        right: 2px;
        opacity: 0;
        transition: opacity 0.3s ease;
      }

      &:hover ::v-deep(.n-scrollbar-rail.n-scrollbar-rail--vertical) {
        opacity: 1;
      }
    }
  }

  // 主内容区域
  .layout-main {
    flex: 1;
    display: flex;
    flex-direction: column;
    min-height: 0;
    min-width: 0; // Prevent flex item from overflowing
    overflow: hidden;
    background: var(--ui-bg-page);
    // 关键：horizontal 模式下 showSider=false，n-layout 不是 flex 容器（无 hasSiderStyle），
    // 此时 flex:1 退化无效。必须用 height:100% 兜底，让 layout-main 在任何 n-layout 形态
    // 下都撑到 100%（n-layout 自身是 position:absolute; inset:0 填满 #app = 100vh）。
    height: 100%;
  }

  // 内容区域
  .layout-content {
    flex: 1;
    min-height: 0;
    overflow: auto;
    padding: 0 8px 8px; // 顶部由下面的类控制
    background: var(--ui-bg-page);
    -ms-overflow-style: none;
    scrollbar-width: none;

    &::-webkit-scrollbar {
      width: 0;
      height: 0;
    }
  }

  // 无 TabsView 时，Header (68px) + 间距 (16px)
  .layout-content-main {
    padding-top: calc(68px + 8px);
  }

  // 有 TabsView 时，Header (68px) + TabsView (44px) + 间距 (16px)
  .layout-content-main-fix {
    padding-top: 112px;
  }
</style>
