/**
 * @description Layout 主区域（.layout-content）的 content-box 几何信息暴露契约。
 *   由 layout/index.vue 测量并 provide，消费者（如 ProCrudTable 的 useAutoHeight）inject 后用
 *   `contentRect.bottom` 当做"页面可用底"的 ceiling，避免 ProCrudTable 撑过 layout-content
 *   的 padding-bottom 触发 overflow:auto 滚动。与 ProTabsHeightContext 形态对称：ProTabs 内
 *   走 paneRect 优先；非 ProTabs 但在 layout 内走 contentRect；脱离 layout（独立弹窗/login）
 *   走 windowHeight 兜底。
 * @date 2026-05-23
 * @scope src/layout/contentRectContext.ts
 */
import type { InjectionKey, Ref } from 'vue';

/**
 * .layout-content 的 content-box（已扣除 padding-top / padding-bottom）几何信息。
 *
 * - top    : viewport 中 content-box 的顶（= border-box.top + padding-top，避开 fixed PageHeader / TabsView）
 * - bottom : viewport 中 content-box 的底（= border-box.bottom - padding-bottom，避开 layout-content 自身底部留白）
 * - height : bottom - top
 */
export interface LayoutContentRect {
  top: number;
  bottom: number;
  height: number;
}

export interface LayoutContentRectContext {
  /** 响应式只读：layout 内部 ResizeObserver + window resize 维护更新 */
  readonly contentRect: Ref<LayoutContentRect>;
}

export const LayoutContentRectKey: InjectionKey<LayoutContentRectContext> =
  Symbol('LayoutContentRect');
