<!--
/**
 * @description 头部消息通知详情弹窗内容组件：负责通知详情字段展示、消息内容卡片、详情跳转入口与关闭事件派发。
 * @date.  26-05-02
 * @scope src/layout/components/Header
 */
-->
<template>
  <div class="notification-detail" @click.stop>
    <div class="notification-detail__fields">
      <div class="notification-detail__field">
        <span class="notification-detail__meta-label">{{
          t('common.header.notification.columns.site')
        }}</span>
        <NTag
          v-if="hasTriggerTenant"
          type="info"
          size="small"
          :bordered="false"
          class="notification-detail__site-tag"
        >
          {{ tenantLabel }}
        </NTag>
        <span v-else class="notification-detail__meta-empty">--</span>
      </div>

      <div class="notification-detail__field">
        <span class="notification-detail__meta-label">{{
          t('common.header.notification.columns.type')
        }}</span>
        <NTag type="info" size="medium" class="notification-detail__type-tag">
          {{ messageTypeLabel }}
        </NTag>
      </div>

      <div class="notification-detail__field">
        <span class="notification-detail__meta-label">{{
          t('common.header.notification.columns.sender')
        }}</span>
        <span class="notification-detail__sender">{{ senderLabel }}</span>
      </div>

      <div class="notification-detail__field">
        <span class="notification-detail__meta-label">{{
          t('common.header.notification.columns.time')
        }}</span>
        <span class="notification-detail__time">
          {{ sendTimeText }}
          <span v-if="timeZoneLabel" class="notification-detail__time-zone">
            ({{ timeZoneLabel }})
          </span>
        </span>
      </div>

      <div class="notification-detail__field notification-detail__field--content">
        <span class="notification-detail__meta-label">{{
          t('common.header.notification.columns.content')
        }}</span>
        <div class="notification-detail__content-card">
          <span class="notification-detail__content-text">{{ item.content || '--' }}</span>
          <button
            v-if="canJump"
            type="button"
            class="notification-detail__link"
            @click.stop="emit('jump', item)"
          >
            {{ t('common.header.notification.actions.contentViewDetail') }}
            <span class="notification-detail__link-arrow">›</span>
          </button>
        </div>
      </div>
    </div>

    <div class="notification-detail__footer">
      <NButton size="medium" class="notification-detail__close" @click.stop="emit('close')">
        {{ t('common.close') }}
      </NButton>
    </div>
  </div>
</template>

<script setup lang="ts">
  import { computed } from 'vue';
  import { useI18n } from 'vue-i18n';
  import { NButton, NTag } from 'naive-ui';
  import { useTenantOptions } from '@/hooks/useTenantOptions';
  import type { NotificationItem } from '@/store/modules/notification';
  import { hasNotificationRoute } from './notificationRouteMap';
  import { useNotificationLabel } from './useNotificationLabel';

  const props = defineProps<{
    item: NotificationItem;
  }>();

  const emit = defineEmits<{
    close: [];
    jump: [item: NotificationItem];
  }>();

  const { t } = useI18n();
  const { activeTenantId, getTenantLabel, getTenantTimeZoneLabel, formatTenantDateTime } =
    useTenantOptions();
  const { resolveLabel: resolveMessageTypeLabel } = useNotificationLabel();

  const messageTypeLabel = computed(() => resolveMessageTypeLabel(props.item));

  // 优先后端返回的 senderName 原文（"系统" / 真实操作人名 e.g. "milozy01"，按当前请求语言渲染）；
  // 空字符串才回退到 i18n 枚举文案，作为字典 miss / 老接口的兜底。
  const senderLabel = computed(
    () => props.item.senderName || t(`common.header.notification.senders.${props.item.sender}`),
  );

  const hasTriggerTenant = computed(
    () => props.item.triggerTenantId !== null && props.item.triggerTenantId !== undefined,
  );

  const tenantLabel = computed(() =>
    getTenantLabel(props.item.triggerTenantId, props.item.triggerTenantName, '--'),
  );

  const timeTenantId = computed(() => props.item.triggerTenantId ?? activeTenantId.value);

  const timeZoneLabel = computed(() => getTenantTimeZoneLabel(timeTenantId.value));

  /** 详情时间格式化沿用单元格时区策略：按触发商户时区；无触发商户时回退到当前用户默认时区 */
  const sendTimeText = computed(() => {
    if (!props.item.sendTime) return '--';
    return formatTenantDateTime(
      props.item.sendTime,
      timeTenantId.value ?? undefined,
      'yyyy-MM-dd HH:mm:ss',
      '--',
    );
  });

  const canJump = computed(() => hasNotificationRoute(props.item));
</script>

<style lang="less" scoped>
  .notification-detail {
    display: flex;
    flex-direction: column;
    gap: 18px;
    width: 100%;
    min-width: 0;
  }

  .notification-detail__fields {
    display: flex;
    flex-direction: column;
    gap: 14px;
  }

  .notification-detail__field {
    display: grid;
    grid-template-columns: 72px minmax(0, 1fr);
    align-items: center;
    column-gap: 14px;
  }

  .notification-detail__field--content {
    display: flex;
    flex-direction: column;
    align-items: stretch;
    gap: 8px;
  }

  .notification-detail__meta-label {
    font-size: 13px;
    font-weight: 500;
    color: #6b7280;
  }

  .notification-detail__meta-empty {
    font-size: 13px;
    color: #9ca3af;
  }

  .notification-detail__sender,
  .notification-detail__time {
    font-size: 14px;
    color: #1f2937;
  }

  .notification-detail__sender {
    font-weight: 600;
  }

  .notification-detail__time {
    font-weight: 500;
    font-variant-numeric: tabular-nums;
  }

  .notification-detail__time-zone {
    margin-left: 6px;
    font-size: 11px;
    font-weight: 400;
    color: #8a94a6;
  }

  .notification-detail__content-card {
    box-sizing: border-box;
    width: 100%;
    max-width: 100%;
    min-height: 80px;
    padding: 13px 14px;
    border: 1px solid #e5e7eb;
    border-radius: 4px;
    background: #f9fafb;
    font-size: 14px;
    line-height: 2;
    color: #1f2937;
    white-space: normal;
    overflow-wrap: anywhere;
    word-break: break-word;
  }

  .notification-detail__content-text {
    display: block;
    white-space: pre-wrap;
    overflow-wrap: anywhere;
    word-break: break-word;
  }

  .notification-detail__link {
    display: inline-flex;
    align-items: center;
    gap: 2px;
    margin-top: 4px;
    margin-left: 0;
    padding: 0;
    border: 0;
    background: transparent;
    color: #2563eb;
    font: inherit;
    font-weight: 600;
    cursor: pointer;

    &:hover {
      color: #1d4ed8;
      text-decoration: underline;
    }
  }

  .notification-detail__link-arrow {
    font-size: 15px;
    line-height: 1;
  }

  .notification-detail__footer {
    display: flex;
    justify-content: flex-end;
    align-items: center;
    padding-top: 0;
  }

  .notification-detail__close {
    min-width: 52px;
    border-color: #0faaa7;
    color: #0faaa7;
  }

  .notification-detail__site-tag {
    width: fit-content;
    background: #e8f4ff;
    color: #1677ff;
    font-weight: 500;
  }

  .notification-detail__type-tag {
    width: fit-content;
    background: #e8f4ff;
    color: #1677ff;
    font-weight: 600;
  }
</style>
