<template>
  <n-layout class="v3-layout">
    <AppHeader />

    <n-layout-content :class="['v3-content', { 'v3-content--editor': isEditor }]">
      <router-view />
    </n-layout-content>
  </n-layout>
</template>

<script setup lang="ts">
import { computed } from 'vue';
import { NLayout, NLayoutContent } from 'naive-ui';
import { useRoute } from 'vue-router';
import AppHeader from './components/Header/index.vue';

const route = useRoute();
const isEditor = computed(() => ['config_layoutConfig_edit', 'config_layoutConfig_pc'].includes(String(route.name)));
</script>
