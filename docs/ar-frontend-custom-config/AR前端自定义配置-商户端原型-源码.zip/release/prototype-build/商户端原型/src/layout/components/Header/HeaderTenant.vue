<template>
  <n-popover
    trigger="click"
    :disabled="!canSwitchTenant"
    placement="bottom-start"
    :show-arrow="false"
    class="tenant-popover-overlay"
    content-style="padding: 0; background: transparent; box-shadow: none; border: 0;"
    raw
    v-model:show="popoverVisible"
    @update:show="handlePopoverVisibleChange"
  >
    <template #trigger>
      <button
        ref="tenantTriggerRef"
        type="button"
        class="header-tenant inline-flex h-full min-w-0 items-center justify-center rounded border-0 bg-transparent px-3 max-[1180px]:px-2"
        :class="{
          'header-tenant--clickable': canSwitchTenant,
          'header-tenant--open': popoverVisible,
        }"
        :style="tenantPanelWidthStyle"
        :title="tenantTitle"
      >
        <div
          class="header-tenant__identity flex w-full max-w-full min-w-0 flex-col items-center justify-center text-center"
        >
          <div
            class="header-tenant__time flex max-w-full items-center gap-1 whitespace-nowrap text-[12px] font-semibold leading-[1.35] max-[1180px]:hidden"
            :title="timezoneTitle"
          >
            <n-icon size="12" class="header-tenant__clock-icon opacity-85">
              <ClockCircleOutlined />
            </n-icon>
            <span ref="clockTextRef" class="header-tenant__clock-text tracking-[0.5px]">{{
              formattedTime
            }}</span>
            <span
              v-if="clockTimezoneLabel"
              class="header-tenant__clock-zone text-[11px] font-medium opacity-75"
            >
              {{ clockTimezoneLabel }}
            </span>
          </div>
          <div
            class="header-tenant__meta flex max-w-full items-center justify-center gap-1.5 whitespace-nowrap text-[12px] font-medium leading-[1.35]"
          >
            <span class="truncate max-w-[112px]" :title="tenantDisplay.groupName">
              {{ tenantDisplay.groupName }}
            </span>
            <span
              v-if="!isPlatformSide"
              class="header-tenant__pill inline-flex min-w-0 items-center gap-1 rounded-full px-2 text-[11px] font-semibold"
              :title="tenantDisplay.tenantTitle"
            >
              <span class="truncate">{{ tenantDisplay.tenantName }}</span>
            </span>
            <span
              v-if="canSwitchTenant"
              class="header-tenant__switch inline-flex items-center gap-0.5"
              :title="switchTitle"
            >
              <span class="text-[11px] font-medium">{{
                t('common.header.switchTenantShort')
              }}</span>
              <n-icon
                size="12"
                class="header-tenant__arrow opacity-72 transition-transform duration-200"
                :class="popoverVisible ? 'rotate-180' : ''"
              >
                <DownOutlined />
              </n-icon>
            </span>
          </div>
        </div>
      </button>
    </template>
    <n-el tag="div" class="tenant-popover" :style="tenantPopoverStyle">
      <div class="tenant-popover__search px-2 pb-2 pt-2">
        <n-input
          v-model:value="tenantKeyword"
          size="small"
          clearable
          :placeholder="t('common.header.searchTenantPlaceholder')"
        >
          <template #prefix>
            <n-icon size="14" class="tenant-popover__search-icon">
              <SearchOutlined />
            </n-icon>
          </template>
        </n-input>
      </div>
      <div class="tenant-popover__body">
        <template v-if="visibleTenantGroups.length">
          <section
            v-for="group in visibleTenantGroups"
            :key="group.orgId"
            class="tenant-popover__group"
          >
            <div class="flex items-center justify-between gap-2.5 px-2 pb-1">
              <span class="tenant-popover__group-name min-w-0 truncate text-[12px] font-semibold">
                {{ group.orgName }}
              </span>
              <span
                class="tenant-popover__group-count min-w-[22px] shrink-0 rounded-full px-1.5 text-center text-[11px] leading-[18px]"
              >
                {{ group.tenants.length }}
              </span>
            </div>
            <div class="tenant-popover__tenant-grid">
              <button
                v-for="tenant in group.tenants"
                :key="tenant.id"
                type="button"
                class="tenant-popover__item relative flex w-full items-center rounded-lg border-0 bg-transparent py-2 pl-2.5 pr-[30px] text-left text-inherit"
                :class="{ 'tenant-popover__item--active': tenant.id === currentTenantId }"
                @click="handleTenantChange(tenant.id)"
              >
                <span class="flex min-w-0 flex-1 flex-col gap-0.5">
                  <span class="tenant-popover__tenant-name truncate text-[13px] font-semibold">
                    {{ tenant.name }}
                  </span>
                  <span
                    class="tenant-popover__tenant-meta flex min-w-0 items-center gap-1.5 text-[11px] tracking-[0.04em]"
                  >
                    <span>#{{ tenant.id }}</span>
                    <n-tag
                      v-if="tenant.supportSysCurrency"
                      size="small"
                      type="success"
                      class="tenant-popover__currency-tag"
                    >
                      {{ tenant.supportSysCurrency }}
                    </n-tag>
                    <span v-if="tenant.timeZone" class="tenant-popover__timezone truncate">{{
                      resolveTenantTimezone(tenant.timeZone)
                    }}</span>
                  </span>
                </span>
                <n-icon
                  v-if="tenant.id === currentTenantId"
                  size="14"
                  class="tenant-popover__check"
                >
                  <CheckOutlined />
                </n-icon>
              </button>
            </div>
          </section>
        </template>
        <div
          v-else
          class="tenant-popover__empty flex min-h-[120px] items-center justify-center px-4 text-center"
        >
          {{ t('common.header.noTenantMatch') }}
        </div>
      </div>
    </n-el>
  </n-popover>
</template>

<script setup lang="ts">
  import { computed, nextTick, onMounted, onUnmounted, ref, shallowRef, watch } from 'vue';
  import { NEl, NIcon, NInput, NPopover, NTag } from 'naive-ui';
  import { useWindowSize } from '@vueuse/core';
  import { useI18n } from 'vue-i18n';
  import { useRouter } from 'vue-router';
  import { CheckOutlined, ClockCircleOutlined, DownOutlined, SearchOutlined } from '@vicons/antd';
  import { useUserStore } from '@/store/modules';
  import { formatToCurrentZone, formatToTimeZone, getTimeZoneOffsetLabel } from '@/utils/dateUtil';

  const TENANT_PANEL_COMPACT_BREAKPOINT = 1180;

  const { t } = useI18n();
  const router = useRouter();
  const userStore = useUserStore();

  const { width: viewportWidth } = useWindowSize();
  const popoverVisible = ref(false);
  const tenantKeyword = ref('');
  const tenantTriggerRef = ref<HTMLElement | null>(null);
  const lockedTenantWidth = ref<string>();
  const isPlatformSide = computed(() => userStore.isPlatformUser);
  const isCompactViewport = computed(() => viewportWidth.value <= TENANT_PANEL_COMPACT_BREAKPOINT);

  // 将 store 里的租户数据整理成统一结构，供展示和切换逻辑复用。
  const tenantGroups = computed(() =>
    userStore.getTenantGroups.filter((item) => item.tenants.length),
  );
  const tenantFlatList = computed(() => userStore.getTenantFlatList);
  // currentTenant 在没有显式 activeTenantId 时会 fall back 到 flatList[0]，
  // 时钟/时区 title 也要用同一个来源，否则会出现「显示 A 商户、时间按浏览器本地」的错位
  const currentTenant = computed(() =>
    isPlatformSide.value ? null : userStore.getActiveTenant || tenantFlatList.value[0] || null,
  );
  const currentTenantId = computed(() => currentTenant.value?.id ?? null);
  const currentTenantOrgId = computed(() => currentTenant.value?.orgId ?? null);
  const canSwitchTenant = computed(() => !isPlatformSide.value && tenantFlatList.value.length > 1);

  // 时钟：直接 DOM 更新，不走响应式，避免每秒触发 NPopover slot 警告
  const clockTextRef = ref<HTMLElement | null>(null);
  const timestamp = shallowRef(Date.now());
  let _clockTimer: ReturnType<typeof setInterval> | null = null;

  function formatTimeForTenant(value: number): string {
    const tz = currentTenant.value?.timeZone;
    // formatToCurrentZone 签名较宽返回 string | number（isTimer 分支会返回数字），
    // 这里统一走文本分支，用 String() 收敛类型
    return tz ? formatToTimeZone(value, tz) : String(formatToCurrentZone(value));
  }

  onMounted(() => {
    _clockTimer = setInterval(() => {
      if (!clockTextRef.value) return;
      clockTextRef.value.textContent = formatTimeForTenant(Date.now());
    }, 1000);
  });
  onUnmounted(() => {
    if (_clockTimer !== null) clearInterval(_clockTimer);
  });

  const formattedTime = computed(() => formatTimeForTenant(timestamp.value));
  const clockTimezoneLabel = computed(() => {
    const tz = currentTenant.value?.timeZone;
    return tz ? getTimeZoneOffsetLabel(tz, tz) : '';
  });
  const timezoneTitle = computed(() => {
    const label = clockTimezoneLabel.value;
    return label ? `${t('common.header.timezone')}: ${label}` : t('common.header.timezone');
  });

  // 原文可能是 "(UTC+5:30)Asia/Kolkata"，解析不出时 fall back 回原文避免空白
  function resolveTenantTimezone(raw?: string): string {
    return raw ? getTimeZoneOffsetLabel(raw, raw) : '';
  }

  // 统一总控端和租户端的展示文案，避免模板和标题计算里重复分支判断。
  const tenantDisplay = computed(() => {
    const platformSideLabel = t('common.profile.platformSide');
    const systemSideLabel = t('common.profile.systemSide');

    if (isPlatformSide.value) {
      return {
        groupName: userStore.info.orgName || platformSideLabel,
        metaLabel: systemSideLabel,
        tenantName: platformSideLabel,
        tenantTitle: `${systemSideLabel}: ${platformSideLabel}`,
      };
    }

    const tenant = currentTenant.value;
    const groupName =
      tenant?.orgName ||
      userStore.getActiveTenantGroup?.orgName ||
      tenantGroups.value.find((item) => item.orgId === tenant?.orgId)?.orgName ||
      userStore.info.orgName ||
      '--';

    return {
      groupName,
      metaLabel: t('common.header.tenant'),
      tenantName: tenant ? `(${tenant.id})${tenant.name}` : '--',
      tenantTitle: tenant ? `${tenant.name} (#${tenant.id})` : t('common.noData'),
    };
  });

  // 基于统一展示模型拼装触发器标题和辅助文案。
  const tenantTitle = computed(() =>
    [tenantDisplay.value.groupName, tenantDisplay.value.tenantTitle, timezoneTitle.value]
      .filter(Boolean)
      .join(' · '),
  );
  const switchTitle = computed(() =>
    t('common.header.switchTenant', { count: tenantFlatList.value.length }),
  );
  const normalizedTenantKeyword = computed(() => normalizeKeyword(tenantKeyword.value));

  // 锁定头部入口宽度，沿用初始渲染的自然宽度，避免切换不同商户后布局抖动。
  const tenantPanelWidthStyle = computed(() => {
    if (!lockedTenantWidth.value) return undefined;
    const width = lockedTenantWidth.value;

    return {
      width,
      minWidth: width,
      maxWidth: width,
    };
  });
  const tenantPopoverStyle = computed(() => {
    if (!lockedTenantWidth.value) return undefined;

    const baseWidth = Number.parseFloat(lockedTenantWidth.value);
    if (!Number.isFinite(baseWidth)) return tenantPanelWidthStyle.value;

    const width = `min(${Math.round(baseWidth * 2)}px, calc(100vw - 24px))`;
    return {
      width,
      minWidth: width,
      maxWidth: 'calc(100vw - 24px)',
    };
  });

  // 当商户数量较多时，通过关键字过滤并优先展示当前商户所在集团，降低定位成本。
  const visibleTenantGroups = computed(() => {
    const keyword = normalizedTenantKeyword.value;
    const groups = tenantGroups.value
      .map((group) => {
        const tenants = keyword
          ? group.tenants.filter((tenant) => matchesTenantKeyword(tenant, group.orgName, keyword))
          : group.tenants;

        return {
          ...group,
          tenants,
        };
      })
      .filter((group) => group.tenants.length);

    if (!keyword && currentTenantOrgId.value !== null) {
      groups.sort((first, second) => {
        const firstWeight = first.orgId === currentTenantOrgId.value ? 0 : 1;
        const secondWeight = second.orgId === currentTenantOrgId.value ? 0 : 1;
        return firstWeight - secondWeight;
      });
    }

    return groups;
  });

  // 仅在选择有效且发生变化时切换租户，并在切换前先关闭弹层。
  function handleTenantChange(key: string | number) {
    const tenantId = Number(key);
    if (Number.isNaN(tenantId) || tenantId === currentTenantId.value) return;
    popoverVisible.value = false;
    userStore.setActiveTenantId(tenantId);
    router.go(0);
  }

  function handlePopoverVisibleChange(show: boolean) {
    if (!show) {
      tenantKeyword.value = '';
    }
  }

  async function lockTenantPanelWidth() {
    lockedTenantWidth.value = undefined;
    await nextTick();
    const width = tenantTriggerRef.value?.offsetWidth;
    if (!width) return;
    lockedTenantWidth.value = `${width}px`;
  }

  function normalizeKeyword(value: string) {
    return value.trim().toLocaleLowerCase();
  }

  function matchesTenantKeyword(
    tenant: { id: number; name?: string; orgName?: string },
    groupName: string,
    keyword: string,
  ) {
    return [tenant.name, tenant.orgName, groupName, String(tenant.id)]
      .filter(Boolean)
      .some((item) => String(item).toLocaleLowerCase().includes(keyword));
  }

  onMounted(() => {
    void lockTenantPanelWidth();
  });

  watch(isCompactViewport, () => {
    void lockTenantPanelWidth();
  });
</script>

<style lang="less">
  .tenant-popover-overlay {
    &.n-popover {
      box-shadow: none !important;
      background: transparent !important;
      border: 0 !important;
    }
  }
</style>

<style scoped>
  .header-tenant {
    color: #fff;
    transition: background-color 0.2s;
  }

  .header-tenant--clickable {
    cursor: pointer;
  }

  .header-tenant--clickable:hover {
    background: rgb(255 255 255 / 0.08);
  }

  .header-tenant--open {
    background: rgb(255 255 255 / 0.1);
  }

  .header-tenant__time {
    color: #fff;
  }

  .header-tenant__meta {
    color: rgb(255 255 255 / 0.72);
  }

  .header-tenant__pill {
    min-height: 20px;
    border: 1px solid rgb(255 255 255 / 0.14);
    background: rgb(255 255 255 / 0.12);
    color: #fff;
  }

  .header-tenant__switch {
    color: rgb(255 255 255 / 0.86);
  }

  .header-tenant--clickable:hover .header-tenant__switch {
    color: #fff;
  }

  .header-tenant__clock-text {
    font-variant-numeric: tabular-nums;
  }

  .tenant-popover {
    box-sizing: border-box;
    padding: 8px;
    color: var(--text-color-1);
    border: 1px solid var(--border-color);
    border-radius: var(--border-radius);
    background: var(--popover-color);
    box-shadow: var(--popover-box-shadow);
  }

  .tenant-popover__search {
    border-bottom: 1px solid var(--divider-color);
  }

  .tenant-popover__search-icon {
    color: var(--text-color-3);
  }

  .tenant-popover__group-name {
    color: var(--text-color-2);
  }

  .tenant-popover__group-count {
    background: var(--hover-color);
    color: var(--text-color-2);
  }

  .tenant-popover__tenant-name {
    color: var(--text-color-1);
  }

  .tenant-popover__tenant-meta {
    color: var(--text-color-3);
  }

  .tenant-popover__currency-tag {
    flex-shrink: 0;
  }

  .tenant-popover__timezone {
    max-width: 58px;
  }

  .tenant-popover__body {
    max-height: min(600px, calc(100vh - 120px));
    padding: 2px;
    overflow: auto;
  }

  .tenant-popover__tenant-grid {
    display: grid;
    grid-template-columns: repeat(2, minmax(0, 1fr));
    gap: 5px;
  }

  .tenant-popover__body::-webkit-scrollbar {
    width: 6px;
  }

  .tenant-popover__body::-webkit-scrollbar-thumb {
    border-radius: 999px;
    background: var(--border-color);
  }

  .tenant-popover__group + .tenant-popover__group {
    margin-top: 6px;
    padding-top: 6px;
    border-top: 1px solid var(--divider-color);
  }

  .tenant-popover__item {
    cursor: pointer;
    box-shadow: inset 0 0 0 1px var(--border-color);
    transition:
      background-color 0.2s ease,
      box-shadow 0.2s ease;
  }

  .tenant-popover__item:hover {
    background: var(--hover-color);
    box-shadow: inset 0 0 0 1px var(--primary-color);
  }

  .tenant-popover__item--active {
    background: var(--hover-color);
    box-shadow: inset 0 0 0 1px var(--primary-color);
  }

  .tenant-popover__check {
    position: absolute;
    top: 50%;
    right: 10px;
    transform: translateY(-50%);
    color: var(--primary-color);
  }

  .tenant-popover__empty {
    color: var(--text-color-3);
    font-size: 12px;
  }

  @media (max-width: 640px) {
    .tenant-popover__tenant-grid {
      grid-template-columns: minmax(0, 1fr);
    }
  }
</style>
