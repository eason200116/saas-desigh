<template>
  <div class="h5-app">
    <div class="h5-shell">
      <!-- 状态栏（浅色·内容优先） -->
      <div class="h5-status">
        <span>9:41</span>
        <span class="r"><span>5G</span><span>▮▮▮</span><span>100%</span></span>
      </div>

      <!-- 路由视图 -->
      <div class="h5-view">
        <router-view v-slot="{ Component }">
          <keep-alive>
            <component :is="Component" />
          </keep-alive>
        </router-view>
      </div>

      <!-- 底部 Tab -->
      <div class="h5-tabbar">
        <div
          v-for="tab in tabs"
          :key="tab.path"
          class="h5-tab"
          :class="{ on: isActive(tab) }"
          @click="go(tab.path)"
        >
          <span class="ti">
            <Icon :name="tab.icon" :size="23" :sw="isActive(tab) ? 2 : 1.7" />
            <span v-if="tab.badge" class="h5-tab-dot">{{ tab.badge }}</span>
          </span>
          <span>{{ tab.label }}</span>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { useRoute, useRouter } from 'vue-router';
import Icon from '@/views/h5/_shared/Icon.vue';
import '@/views/h5/_shared/h5.css';

const route = useRoute();
const router = useRouter();

const tabs = [
  { path: '/h5/home', label: '工作台', icon: 'home' },
  { path: '/h5/apps', label: '应用', icon: 'apps' },
  { path: '/h5/approval', label: '审批', icon: 'approval', badge: '8' },
  { path: '/h5/profile', label: '我的', icon: 'user' },
];

const MODULE_PATHS = ['/h5/member', '/h5/operations', '/h5/finance', '/h5/game', '/h5/config', '/h5/report', '/h5/risk', '/h5/system'];

function isActive(tab: { path: string }) {
  if (tab.path === '/h5/apps') {
    // 「应用」Tab 在任意模块页内也保持高亮
    return route.path === '/h5/apps' || MODULE_PATHS.includes(route.path);
  }
  return route.path === tab.path;
}
function go(path: string) {
  if (route.path !== path) router.push(path);
}
</script>

<style scoped>
.h5-app {
  width: 100%;
  min-height: 100vh;
  background: #0b0f18;
  display: flex;
  justify-content: center;
}
.h5-shell {
  width: 100%;
  max-width: 430px;
  min-height: 100vh;
  background: #f5f6f8;
  display: flex;
  flex-direction: column;
  position: relative;
  box-shadow: 0 0 40px rgba(0, 0, 0, 0.3);
  overflow: hidden;
}
.h5-status {
  flex: none;
  height: 36px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 18px;
  font-size: 12.5px;
  font-weight: 600;
  color: #1c2330;
  background: #fff;
}
.h5-status .r {
  display: flex;
  gap: 6px;
  font-size: 11px;
  letter-spacing: 0.5px;
}
.h5-view {
  flex: 1;
  min-height: 0;
  display: flex;
  flex-direction: column;
  overflow: hidden;
}
.h5-view > * {
  flex: 1;
  min-height: 0;
}
.h5-tabbar {
  flex: none;
  height: 56px;
  background: #fff;
  border-top: 1px solid #eef0f4;
  display: flex;
  padding-bottom: env(safe-area-inset-bottom, 0);
}
.h5-tab {
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 2px;
  font-size: 10.5px;
  color: #9aa3b2;
  position: relative;
  cursor: pointer;
}
.h5-tab .ti {
  position: relative;
  display: flex;
}
.h5-tab.on {
  color: #2b54e6;
  font-weight: 600;
}
.h5-tab-dot {
  position: absolute;
  top: -5px;
  right: -9px;
  min-width: 15px;
  height: 15px;
  border-radius: 9px;
  background: #e23b3b;
  color: #fff;
  font-size: 9px;
  font-weight: 700;
  display: flex;
  align-items: center;
  justify-content: center;
  border: 1.5px solid #fff;
  padding: 0 3px;
}
</style>
