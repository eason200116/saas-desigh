<template>
  <!-- 顶部主类型横排 + 悬停弹出多列大菜单（Mega Menu）；页面带 新/原 标识 -->
  <!-- 交互：鼠标悬停主类型展开面板，移出主类型与面板区域后延时收起（跨越间隙不误关）-->
  <div class="mega-nav">
    <div
      v-for="(m, idx) in mainTypes"
      :key="m.key"
      class="mega-nav__item"
      :class="{ 'is-active': m.key === activeMainKey, 'is-open': m.key === hoverKey }"
      @mouseenter="openPanel(m.key, $event, idx)"
      @mouseleave="scheduleClose"
    >
      <span v-if="m.icon" class="mega-nav__icon"><component :is="m.icon" /></span>
      <span class="mega-nav__title">{{ m.label }}</span>
    </div>

    <!-- 大菜单面板：显示当前点击展开主类型的子类型多列（渐入动画）-->
    <transition name="mega-fade">
      <div
        v-if="hoverKey && hoveredColumns.length"
        ref="panelRef"
        class="mega-panel"
        :style="{ left: panelLeft + 'px' }"
        @mouseenter="cancelClose"
        @mouseleave="scheduleClose"
      >
        <div v-for="(col, ci) in hoveredColumns" :key="col.key" class="mega-col">
          <div class="mega-col__title" :class="`mega-col__title--c${ci % 5}`">{{ col.label }}</div>
          <a
            v-for="p in col.items"
            :key="p.key"
            class="mega-col__item"
            :class="{ 'is-active': p.key === activeKey }"
            @click="go(p.key)"
          >
            <span class="mega-col__item-main">
              <n-icon
                v-if="isTenant"
                class="mega-col__star"
                :class="{ 'is-on': isFav(p.key) }"
                :title="isFav(p.key) ? '取消收藏' : '收藏到左侧'"
                @click.stop="toggleFav(p.key, p.label)"
              >
                <Star v-if="isFav(p.key)" /><StarOutline v-else />
              </n-icon>
              <span class="mega-col__item-label">{{ p.label }}</span>
            </span>
            <span v-if="p.mark" class="mega-tag" :class="`mega-tag--${p.mark}`">{{
              t(`menu.tag_${p.mark}`)
            }}</span>
          </a>
        </div>
      </div>
    </transition>
  </div>
</template>

<script setup lang="ts">
  import { computed, nextTick, onBeforeUnmount, ref } from 'vue';
  import { useRoute, useRouter } from 'vue-router';
  import { useI18n } from 'vue-i18n';
  import { useAsyncRouteStore, useUserStore } from '@/store/modules';
  import { useRoleStore } from '@/store/modules/role';
  import { useFavorites } from '@/hooks/useFavorites';
  import { Star, StarOutline } from '@vicons/ionicons5';

  defineOptions({ name: 'MegaMenu' });

  // 迁移期标识：pending=待定(暂未定稿)、new=新增页、partial=原页本轮有新增、moved=从其它板块迁移过来、old=原有页
  // ''=本主类型整块不打标（父路由 meta.noMark=true，如「游戏管理」），此时不渲染角标
  type LeafMark = 'pending' | 'new' | 'partial' | 'moved' | 'old' | '';
  interface Leaf {
    label: string;
    key: string;
    mark: LeafMark;
  }
  interface Column {
    label: string;
    key: string;
    items: Leaf[];
  }
  interface MainType {
    label: string;
    key: string;
    icon: any;
    columns: Column[];
  }

  const route = useRoute();
  const router = useRouter();
  const { t } = useI18n();
  const asyncRouteStore = useAsyncRouteStore();
  const roleStore = useRoleStore();

  // 收藏星（仅商户端）：复用 useFavorites，与左侧「快速查找页面」抽屉的收藏是同一份数据（点星即入左侧收藏）。
  const userStore = useUserStore();
  const { favorites, addFavorite, removeFavorite, isFavorite, loadFavorites } = useFavorites();
  const isTenant = computed(() => roleStore.role === 'tenant');
  loadFavorites(String(userStore.info?.userId ?? 'anon'));
  // 收藏 path 统一用「真实路由 fullPath」（router.resolve），与标签栏 TagsView 存的 fullPath 一致，
  // 三方（顶部子类型星 / 标签栏星 / 左侧收藏）才认同一条、真正联动。name 兜底兼容历史存的 '/'+name。
  function resolveFavPath(name: string): string {
    try {
      return router.resolve({ name }).fullPath;
    } catch {
      return '/' + name;
    }
  }
  function isFav(name: string) {
    return isFavorite(resolveFavPath(name)) || favorites.value.some((f) => f.name === name);
  }
  function toggleFav(name: string, label: string) {
    const existing = favorites.value.find((f) => f.name === name);
    if (existing) removeFavorite(existing.path);
    else addFavorite({ fullPath: resolveFavPath(name), name, meta: { title: label } });
  }

  // hoverKey：当前展开的主类型 key（悬停驱动）
  const hoverKey = ref<string | null>(null);
  // 关闭延时句柄：移出后延时收起，避免穿过主类型与面板间隙时误关
  let closeTimer: ReturnType<typeof setTimeout> | null = null;

  // 面板锚点：前 4 个主类型左对齐、后 4 个右对齐
  const panelRef = ref<HTMLElement>();
  const panelLeft = ref(0);

  function cancelClose() {
    if (closeTimer) {
      clearTimeout(closeTimer);
      closeTimer = null;
    }
  }

  // 悬停主类型：展开面板并定位。前 4 个主类型面板左对齐（贴 tab 左缘向右展开），
  // 后 4 个右对齐（贴 tab 右缘向左展开），避免右侧主类型面板溢出屏幕。
  function openPanel(key: string, e?: MouseEvent, index = 0) {
    cancelClose();
    hoverKey.value = key;
    const item = e?.currentTarget as HTMLElement | undefined;
    if (!item) return;
    const alignRight = index >= 4;
    // 先给一个初值（首帧 opacity:0 不可见，nextTick 量到面板宽度后再校正，无闪烁）
    panelLeft.value = item.offsetLeft;
    nextTick(() => {
      const panel = panelRef.value;
      if (!panel) return;
      panelLeft.value = alignRight
        ? Math.max(0, item.offsetLeft + item.offsetWidth - panel.offsetWidth)
        : item.offsetLeft;
    });
  }

  // 移出主类型/面板：延时收起（120ms 内重新进入会取消）
  function scheduleClose() {
    cancelClose();
    closeTimer = setTimeout(() => {
      hoverKey.value = null;
      closeTimer = null;
    }, 120);
  }

  onBeforeUnmount(cancelClose);

  function visibleChildren(items: any[]): any[] {
    return (items || []).filter((it) => it?.meta?.hidden !== true);
  }

  // noMark=true：该主类型整块不打迁移期角标（父路由 meta.noMark），全部叶子 mark='' → 模板不渲染。
  // 用于已定稿、不再需要区分「新/原」的板块（如「游戏管理」，2026-07-14 用户要求去掉新原标）。
  function buildColumns(children: any[], noMark = false): Column[] {
    const result: Column[] = [];
    const groupMap = new Map<string, Column>();
    visibleChildren(children).forEach((c: any) => {
      const leaf: Leaf = {
        label: c.meta?.title ? t(c.meta.title) : (c.name as string),
        key: c.name as string,
        // isPending(待定) > isNew(新) > isPartial(部分·原页本轮有新增) > isMoved(移)；都没有则为原有页
        mark: noMark
          ? ''
          : c.meta?.isPending
            ? 'pending'
            : c.meta?.isNew
              ? 'new'
              : c.meta?.isPartial
                ? 'partial'
                : c.meta?.isMoved
                  ? 'moved'
                  : 'old',
      };
      // 角色级分组：双端共用页可用 meta.groupByRole[role] 覆盖默认 meta.group，
      // 让同一路由在总控端 / 商户端归入不同分组（如系统日志·IP白名单：admin 归「系统运维」、tenant 保持原组不变）。
      const g = (c.meta?.groupByRole?.[roleStore.role] ?? c.meta?.group) as string | undefined;
      if (!g) {
        result.push({ label: '', key: `solo-${c.name}`, items: [leaf] });
        return;
      }
      let col = groupMap.get(g);
      if (!col) {
        col = { label: t(g), key: `col-${g}`, items: [] };
        groupMap.set(g, col);
        result.push(col);
      }
      col.items.push(leaf);
    });
    return result;
  }

  const mainTypes = computed<MainType[]>(() =>
    (asyncRouteStore.getMenus as any[])
      // 顶层主类型也需按 meta.hidden 过滤（子项在 visibleChildren 里已过滤；此处补齐顶层）。
      // 用于「数据分析」等隐藏主类型：路由保留可直达，但不在顶部 tab 展示。
      .filter((m) => m.meta?.hidden !== true)
      .map((m) => ({
        label: m.meta?.title ? t(m.meta.title) : (m.name as string),
        key: m.name as string,
        icon: m.meta?.icon,
        columns: Array.isArray(m.children) ? buildColumns(m.children, m.meta?.noMark === true) : [],
      })),
  );

  const activeMainKey = computed(() => route.matched?.[0]?.name as string);
  const activeKey = computed(() => route.name as string);
  const hoveredColumns = computed<Column[]>(
    () => mainTypes.value.find((m) => m.key === hoverKey.value)?.columns ?? [],
  );

  function go(key: string) {
    hoverKey.value = null;
    if (key && key !== route.name) router.push({ name: key });
  }
</script>

<style lang="less" scoped>
  .mega-nav {
    position: relative;
    display: flex;
    align-items: stretch;
    height: 100%;
  }

  // ── 顶部主类型 tab ──
  .mega-nav__item {
    position: relative;
    display: inline-flex;
    align-items: center;
    gap: 6px;
    height: 100%;
    padding: 0 16px;
    color: rgba(255, 255, 255, 0.82);
    font-size: 15px;
    cursor: pointer;
    white-space: nowrap;
    transition: color 0.15s ease;

    // 悬停 / 展开下划线：贴 tab 底边的横线，hover 时由中间向两侧展开
    &::after {
      content: '';
      position: absolute;
      left: 16px;
      right: 16px;
      bottom: 0;
      height: 3px;
      border-radius: 2px 2px 0 0;
      background: #fff;
      transform: scaleX(0);
      transition: transform 0.2s ease;
    }

    &:hover {
      color: #fff;
      background: rgba(255, 255, 255, 0.08);

      &::after {
        transform: scaleX(1);
      }
    }

    // 展开态：高亮 + 浅色底 + 下划线常驻
    &.is-open {
      color: #fff;
      background: rgba(255, 255, 255, 0.12);

      &::after {
        transform: scaleX(1);
      }
    }

    // 当前所在主类型：不做高亮，与其它主类型保持一致（无下划线、不变色、不加粗）
  }

  .mega-nav__icon {
    display: inline-flex;
    font-size: 18px;
  }

  // ── 展开面板 ──
  .mega-panel {
    position: absolute;
    left: 0;
    top: calc(100% + 6px);
    display: flex;
    gap: 4px;
    width: max-content;
    max-width: 96vw;
    padding: 16px 14px;
    background: #fff;
    border: 1px solid #eef1f5;
    border-radius: 12px;
    box-shadow: 0 12px 32px rgba(15, 23, 42, 0.16);
    z-index: 1000;
  }

  // 面板渐入/渐出
  .mega-fade-enter-active,
  .mega-fade-leave-active {
    transition:
      opacity 0.16s ease,
      transform 0.16s ease;
  }
  .mega-fade-enter-from,
  .mega-fade-leave-to {
    opacity: 0;
    transform: translateY(-6px);
  }

  // ── 子 tab 列 ──
  .mega-col {
    min-width: 174px;
    padding: 0 12px;

    & + .mega-col {
      border-left: 1px solid #f1f5f9;
    }
  }

  .mega-col__title {
    margin: 2px 0 10px;
    padding-left: 9px;
    font-size: 13px;
    font-weight: 700;
    color: #1e293b;
    border-left: 3px solid #94a3b8;
    line-height: 1.3;

    &--c0 {
      border-left-color: #2563eb;
    }
    &--c1 {
      border-left-color: #7c3aed;
    }
    &--c2 {
      border-left-color: #0d9488;
    }
    &--c3 {
      border-left-color: #ea580c;
    }
    &--c4 {
      border-left-color: #db2777;
    }
  }

  // 星 + label 左侧成组（tag 保持靠右）
  .mega-col__item-main {
    display: flex;
    align-items: center;
    gap: 6px;
    min-width: 0;
  }
  // 收藏星（仅商户端）：默认浅灰、悬停/已收藏琥珀色
  .mega-col__star {
    flex: 0 0 auto;
    font-size: 14px;
    color: #cbd5e1;
    cursor: pointer;
    transition:
      color 0.15s ease,
      transform 0.15s ease;

    &:hover {
      color: #f59e0b;
      transform: scale(1.18);
    }
    &.is-on {
      color: #f59e0b;
    }
  }

  .mega-col__item {
    position: relative;
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 10px;
    padding: 8px 10px;
    border-radius: 8px;
    font-size: 14px;
    color: #475569;
    cursor: pointer;
    transition:
      background 0.12s ease,
      color 0.12s ease;

    & + & {
      margin-top: 1px;
    }

    &:hover {
      background: #f5f7fa;
      color: #1e293b;
    }

    // 当前所在页：底色 + 左侧蓝条（当前位置可见）
    &.is-active {
      background: #eff6ff;
      color: #2563eb;
      font-weight: 600;

      &::before {
        content: '';
        position: absolute;
        left: 2px;
        top: 7px;
        bottom: 7px;
        width: 3px;
        border-radius: 2px;
        background: #2563eb;
      }
    }
  }

  // 迁移期标识：刻意低调 —— 小字、低饱和、极浅底，不抢眼但靠颜色区分 新/移/原
  .mega-tag {
    flex-shrink: 0;
    padding: 0 5px;
    font-size: 10px;
    line-height: 15px;
    font-weight: 400;
    letter-spacing: 0.5px;
    border-radius: 3px;
  }

  // 待定：略醒目红，提示「该页暂未定稿」
  .mega-tag--pending {
    color: #d9534f;
    background: #fdeaea;
  }

  .mega-tag--new {
    color: #c08a4a;
    background: #faf4ec;
  }

  // 部分：原有页本轮有新增内容（如新增按钮/入口）→ 低饱和青绿，区别于「新」「移」「原」
  .mega-tag--partial {
    color: #4a9d92;
    background: #ecf6f4;
  }

  .mega-tag--moved {
    color: #7d93bf;
    background: #eff2f8;
  }

  .mega-tag--old {
    color: #aab2bd;
    background: #f5f6f8;
  }
</style>
