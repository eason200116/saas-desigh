<template>
  <RouterView>
    <template #default="{ Component, route }">
      <keep-alive v-if="keepAliveComponents.length" :include="keepAliveComponents" :max="20">
        <component :is="Component" :key="getRouteKey(route)" />
      </keep-alive>
      <component v-else :is="Component" :key="getRouteKey(route)" />
    </template>
  </RouterView>
</template>

<script>
  import { defineComponent, computed } from 'vue';
  import { useAsyncRouteStore } from '@/store/modules/asyncRoute';

  export default defineComponent({
    name: 'MainView',
    components: {},
    props: {
      notNeedKey: {
        type: Boolean,
        default: false,
      },
      animate: {
        type: Boolean,
        default: true,
      },
    },
    setup() {
      const asyncRouteStore = useAsyncRouteStore();
      // 需要缓存的路由组件
      const keepAliveComponents = computed(() => asyncRouteStore.keepAliveComponents);
      const getRouteKey = (route) => {
        const isSemanticLayoutEditor =
          String(route.name || '').endsWith('_templateLibrary_layoutConfig') ||
          route.path.includes('/templateLibrary/layoutConfig/');
        if (isSemanticLayoutEditor) {
          return `${String(route.name || route.path)}:${String(route.params?.templateId || '')}`;
        }
        if (route.meta?.keepAlive) {
          return String(route.name || route.path);
        }
        return route.fullPath;
      };

      return {
        getRouteKey,
        keepAliveComponents,
      };
    },
  });
</script>

<style lang="less" scoped></style>
