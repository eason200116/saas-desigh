<template>
  <n-drawer v-model:show="isDrawer" :width="320" placement="right">
    <n-drawer-content :title="t('common.projectSetting.title')" :native-scrollbar="false">
      <n-tabs
        v-model:value="activeTab"
        type="line"
        animated
        size="small"
        justify-content="space-evenly"
      >
        <!-- ===== 外观 ===== -->
        <n-tab-pane name="appearance" :tab="t('common.projectSetting.tabs.appearance')">
          <!-- 主题色 -->
          <section class="ps-section">
            <div class="ps-section__title">{{ t('common.projectSetting.systemTheme') }}</div>
            <div class="ps-color-grid">
              <span
                v-for="color in themeColorOptions"
                :key="color"
                class="ps-color-swatch"
                :class="{ 'ps-color-swatch--active': color === appearance.themeColor }"
                :style="{ backgroundColor: color }"
                @click="setThemeColor(color)"
              >
                <n-icon v-if="color === appearance.themeColor" size="12" color="#fff">
                  <CheckOutlined />
                </n-icon>
              </span>
            </div>
          </section>

          <!-- 外观开关（按需求暂时隐藏）
          <section class="ps-section">
            <div class="ps-row" v-for="item in appearanceSwitches" :key="item.key">
              <span class="ps-row__label">{{ item.label }}</span>
              <n-switch
                :value="(appearance as any)[item.key]"
                size="small"
                @update:value="(v: boolean) => setAppearanceSwitch(item.key, v)"
              />
            </div>
          </section>
          -->

          <!-- 圆角 -->
          <section class="ps-section">
            <div class="ps-row ps-row--align-top">
              <span class="ps-row__label">{{ t('common.projectSetting.borderRadius') }}</span>
              <div class="ps-slider-wrap">
                <n-slider
                  :value="appearance.borderRadius"
                  :min="0"
                  :max="24"
                  :step="2"
                  style="width: 120px"
                  @update:value="(v: number) => projectStore.setAppearance({ borderRadius: v })"
                />
                <span class="ps-slider-val">{{ appearance.borderRadius }}px</span>
              </div>
            </div>
          </section>
        </n-tab-pane>

        <!-- ===== 布局 ===== -->
        <n-tab-pane name="layout" :tab="t('common.projectSetting.tabs.layout')">
          <!-- 布局模式 -->
          <section class="ps-section">
            <div class="ps-section__title">{{ t('common.projectSetting.navigationMode') }}</div>
            <div class="ps-layout-grid">
              <div
                v-for="mode in layoutModes"
                :key="mode.id"
                class="ps-layout-card"
                :class="{
                  'ps-layout-card--active': isActiveLayoutMode(mode),
                  'ps-layout-card--disabled': mode.disabled,
                }"
                @click="!mode.disabled && applyLayoutMode(mode)"
              >
                <div class="ps-layout-card__thumb" v-html="mode.svg" />
                <span class="ps-layout-card__label">{{ mode.label }}</span>
              </div>
            </div>
          </section>

          <!-- 导航主题 -->
          <section class="ps-section">
            <div class="ps-section__title">{{ t('common.projectSetting.navigationStyle') }}</div>
            <div class="ps-nav-theme-group">
              <div
                v-for="navThemeItem in navThemeOptions"
                :key="navThemeItem.value"
                class="ps-nav-theme-card"
                :class="{
                  'ps-nav-theme-card--active': layout.navigationTheme === navThemeItem.value,
                }"
                @click="projectStore.setNavTheme(navThemeItem.value)"
              >
                <div class="ps-nav-theme-card__thumb" v-html="navThemeItem.svg" />
                <span class="ps-nav-theme-card__label">{{ navThemeItem.label }}</span>
              </div>
            </div>
          </section>

          <!-- 标签栏设置 -->
          <section class="ps-section">
            <div class="ps-section__title">{{ t('common.projectSetting.tabsSetting') }}</div>
            <div class="ps-row">
              <span class="ps-row__label">{{ t('common.projectSetting.display.showTabs') }}</span>
              <n-switch
                :value="general.showTabs"
                size="small"
                @update:value="(v: boolean) => projectStore.setGeneral({ showTabs: v })"
              />
            </div>
            <!-- 固定多页签（按需求暂时隐藏）
            <div class="ps-row">
              <span class="ps-row__label">{{
                t('common.projectSetting.functions.fixedTabs')
              }}</span>
              <n-switch
                :value="general.fixedTabs"
                size="small"
                :disabled="!general.showTabs"
                @update:value="(v: boolean) => projectStore.setGeneral({ fixedTabs: v })"
              />
            </div>
            -->
          </section>
        </n-tab-pane>

        <!-- ===== 通用 ===== -->
        <!-- 通用（按需求暂时隐藏）
        <n-tab-pane name="general" :tab="t('common.projectSetting.tabs.general')">
          <section class="ps-section">
            <div class="ps-row" v-for="item in generalSwitches" :key="item.key">
              <span class="ps-row__label">{{ item.label }}</span>
              <n-switch
                :value="(general as any)[item.key]"
                size="small"
                @update:value="(v: boolean) => projectStore.setGeneral({ [item.key]: v })"
              />
            </div>
          </section>
        </n-tab-pane>
        -->

        <!-- ===== 预设 ===== -->
        <n-tab-pane name="preset" :tab="t('common.projectSetting.tabs.preset')">
          <section class="ps-section">
            <div
              v-for="item in presetOptions"
              :key="item.key"
              class="ps-preset-card"
              :class="{ 'ps-preset-card--active': preset.activePreset === item.key }"
              @click="projectStore.applyPreset(item.key)"
            >
              <div class="ps-preset-card__header">
                <span class="ps-preset-card__name">{{ item.label }}</span>
                <n-tag v-if="preset.activePreset === item.key" size="tiny" type="primary">
                  {{ t('common.projectSetting.current') }}
                </n-tag>
              </div>
              <p class="ps-preset-card__desc">{{ item.desc }}</p>
            </div>
          </section>
        </n-tab-pane>
      </n-tabs>
    </n-drawer-content>
  </n-drawer>
</template>

<script lang="ts" setup>
  import { ref, computed } from 'vue';
  import { useI18n } from 'vue-i18n';
  import { CheckOutlined } from '@vicons/antd';
  import { themeConfig } from '@/hooks/setting';
  import { useProjectSettingStore } from '@/store/modules';
  import type { ProjectThemePresetKey } from '/#/config';

  const { t } = useI18n();
  const projectStore = useProjectSettingStore();

  const isDrawer = ref(false);
  const activeTab = ref<'appearance' | 'layout' | 'general' | 'preset'>('appearance');

  const appearance = computed(() => projectStore.appearance);
  const layout = computed(() => projectStore.layout);
  const general = computed(() => projectStore.general);
  const preset = computed(() => projectStore.preset);
  const themeColorOptions = computed(() => themeConfig.brandColors);

  // ── 导航主题 ──────────────────────────────────────────────────
  const navThemeOptions = computed(() => [
    {
      value: 'dark',
      label: t('common.projectSetting.navStyle.darkSidebar'),
      svg: `<svg viewBox="0 0 80 56" xmlns="http://www.w3.org/2000/svg">
        <rect width="80" height="56" rx="3" fill="#f0f2f5"/>
        <rect width="18" height="56" rx="3" fill="#1e293b"/>
        <rect x="22" y="8" width="50" height="8" rx="2" fill="#e2e8f0"/>
        <rect x="22" y="20" width="50" height="28" rx="2" fill="#fff"/>
      </svg>`,
    },
    {
      value: 'light',
      label: t('common.projectSetting.navStyle.lightSidebar'),
      svg: `<svg viewBox="0 0 80 56" xmlns="http://www.w3.org/2000/svg">
        <rect width="80" height="56" rx="3" fill="#f0f2f5"/>
        <rect width="18" height="56" rx="3" fill="#fff" stroke="#e2e8f0" stroke-width="0.5"/>
        <rect x="22" y="8" width="50" height="8" rx="2" fill="#e2e8f0"/>
        <rect x="22" y="20" width="50" height="28" rx="2" fill="#fff"/>
      </svg>`,
    },
  ]);

  // ── 布局模式 ──────────────────────────────────────────────────
  interface LayoutModeOption {
    id: string;
    navMode: string;
    mixMenu: boolean;
    label: string;
    disabled?: boolean;
    svg: string;
  }

  const layoutModes = computed<LayoutModeOption[]>(() => [
    // {
    //   id: 'vertical',
    //   navMode: 'vertical',
    //   mixMenu: false,
    //   label: '左侧菜单模式',
    //   svg: `<svg viewBox="0 0 80 56" xmlns="http://www.w3.org/2000/svg">
    //     <rect width="80" height="56" rx="3" fill="#f0f2f5"/>
    //     <rect width="18" height="56" rx="3" fill="#1e293b"/>
    //     <rect x="22" y="8" width="50" height="8" rx="2" fill="#e2e8f0"/>
    //     <rect x="22" y="20" width="50" height="28" rx="2" fill="#fff"/>
    //   </svg>`,
    // },
    // {
    //   id: 'vertical-mix',
    //   navMode: 'vertical',
    //   mixMenu: true,
    //   label: '左侧菜单混合模式',
    //   disabled: true,
    //   svg: `<svg viewBox="0 0 80 56" xmlns="http://www.w3.org/2000/svg">
    //     <rect width="80" height="56" rx="3" fill="#f0f2f5"/>
    //     <rect width="10" height="56" rx="3" fill="#1e293b"/>
    //     <rect x="11" y="0" width="16" height="56" fill="#fff" stroke="#e2e8f0" stroke-width="0.5"/>
    //     <rect x="30" y="8" width="44" height="8" rx="2" fill="#e2e8f0"/>
    //     <rect x="30" y="20" width="44" height="28" rx="2" fill="#fff"/>
    //   </svg>`,
    // },
    // {
    //   id: 'vertical-mix-top',
    //   navMode: 'vertical',
    //   mixMenu: false,
    //   label: '左侧混合-顶部优先',
    //   disabled: true,
    //   svg: `<svg viewBox="0 0 80 56" xmlns="http://www.w3.org/2000/svg">
    //     <rect width="80" height="56" rx="3" fill="#f0f2f5"/>
    //     <rect width="80" height="14" rx="3" fill="#1e293b"/>
    //     <rect width="14" height="42" y="14" rx="0" fill="#334155"/>
    //     <rect x="18" y="18" width="56" height="30" rx="2" fill="#fff"/>
    //   </svg>`,
    // },
    {
      id: 'horizontal',
      navMode: 'horizontal',
      mixMenu: false,
      label: t('common.projectSetting.navMode.horizontal'),
      svg: `<svg viewBox="0 0 80 56" xmlns="http://www.w3.org/2000/svg">
        <rect width="80" height="56" rx="3" fill="#f0f2f5"/>
        <rect width="80" height="14" rx="3" fill="#1e293b"/>
        <rect x="4" y="18" width="72" height="30" rx="2" fill="#fff"/>
      </svg>`,
    },
    {
      id: 'horizontal-mix',
      navMode: 'horizontal-mix',
      mixMenu: true,
      label: t('common.projectSetting.navMode.horizontalMix'),
      svg: `<svg viewBox="0 0 80 56" xmlns="http://www.w3.org/2000/svg">
        <rect width="80" height="56" rx="3" fill="#f0f2f5"/>
        <rect width="80" height="14" rx="3" fill="#1e293b"/>
        <rect width="18" height="42" y="14" rx="0" fill="#fff" stroke="#e2e8f0" stroke-width="0.5"/>
        <rect x="22" y="18" width="54" height="30" rx="2" fill="#fff"/>
      </svg>`,
    },
    // {
    //   id: 'horizontal-mix-top',
    //   navMode: 'horizontal-mix',
    //   mixMenu: false,
    //   label: '顶部混合-顶部优先',
    //   svg: `<svg viewBox="0 0 80 56" xmlns="http://www.w3.org/2000/svg">
    //     <rect width="80" height="56" rx="3" fill="#f0f2f5"/>
    //     <rect width="80" height="14" rx="3" fill="#1e293b"/>
    //     <rect width="10" height="42" y="14" rx="0" fill="#f8fafc" stroke="#e2e8f0" stroke-width="0.5"/>
    //     <rect x="14" y="18" width="62" height="30" rx="2" fill="#fff"/>
    //   </svg>`,
    // },
  ]);

  function isActiveLayoutMode(mode: LayoutModeOption) {
    return (
      projectStore.navMode === mode.navMode &&
      projectStore.layout.mixMenu === mode.mixMenu &&
      !mode.disabled
    );
  }

  function applyLayoutMode(mode: LayoutModeOption) {
    projectStore.setNavigationMode(mode.navMode, mode.mixMenu);
  }

  // ── 预设 ──────────────────────────────────────────────────────
  const presetOptions = computed<{ key: ProjectThemePresetKey; label: string; desc: string }[]>(
    () => [
      {
        key: 'ar-default',
        label: t('common.projectSetting.presetOptions.arDefault.label'),
        desc: t('common.projectSetting.presetOptions.arDefault.desc'),
      },
      // {
      //   key: 'soybean-classic',
      //   label: '经典',
      //   desc: '浅色导航，清晰层级，对齐  Admin 桌面后台体验。',
      // },
      // {
      //   key: 'soybean-compact',
      //   label: '紧凑',
      //   desc: '高信息密度，缩小间距，适合数据密集型页面。',
      // },
    ],
  );

  // ── 方法 ──────────────────────────────────────────────────────
  function setThemeColor(color: string) {
    projectStore.setAppearance({ themeColor: color });
  }

  // ── 暴露给父组件 ──────────────────────────────────────────────
  function openDrawer(tab?: 'appearance' | 'layout' | 'general' | 'preset') {
    if (tab === 'general') {
      activeTab.value = 'appearance';
      isDrawer.value = true;
      return;
    }

    activeTab.value = tab ?? 'appearance';
    isDrawer.value = true;
  }

  function closeDrawer() {
    isDrawer.value = false;
  }

  defineExpose({ openDrawer, closeDrawer });
</script>

<style lang="less" scoped>
  .ps-section {
    margin-bottom: 20px;

    &__title {
      font-size: 13px;
      font-weight: 600;
      color: var(--n-text-color-2, #374151);
      margin-bottom: 10px;
    }
  }

  // 颜色选择
  .ps-color-grid {
    display: flex;
    flex-wrap: wrap;
    gap: 8px;
  }

  .ps-color-swatch {
    width: 22px;
    height: 22px;
    border-radius: 4px;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    border: 2px solid transparent;
    transition: transform 0.15s;

    &:hover {
      transform: scale(1.15);
    }

    &--active {
      border-color: rgba(0, 0, 0, 0.25);
    }
  }

  // 深色模式选择
  .ps-scheme-group {
    display: flex;
    gap: 8px;
  }

  .ps-scheme-btn {
    flex: 1;
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 4px;
    padding: 8px 4px;
    border-radius: 8px;
    border: 1.5px solid var(--n-border-color, #e5e7eb);
    background: transparent;
    cursor: pointer;
    font-size: 11px;
    color: var(--n-text-color-2, #6b7280);
    transition: all 0.15s;

    &:hover {
      border-color: var(--n-primary-color, #009688);
      color: var(--n-primary-color, #009688);
    }

    &--active {
      border-color: var(--n-primary-color, #009688);
      background: rgba(0, 150, 136, 0.08);
      color: var(--n-primary-color, #009688);
    }
  }

  // 行
  .ps-row {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 7px 0;
    border-bottom: 1px solid var(--n-divider-color, #f0f0f0);

    &:last-child {
      border-bottom: none;
    }

    &--align-top {
      align-items: flex-start;
    }

    &__label {
      font-size: 13px;
      color: var(--n-text-color-2, #374151);
    }
  }

  .ps-slider-wrap {
    display: flex;
    align-items: center;
    gap: 8px;
  }

  .ps-slider-val {
    font-size: 12px;
    color: var(--n-text-color-3, #6b7280);
    min-width: 32px;
    text-align: right;
  }

  // 布局模式网格
  .ps-layout-grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 10px;
  }

  .ps-layout-card {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 6px;
    cursor: pointer;
    border-radius: 6px;
    padding: 6px 4px;
    transition: all 0.15s;

    &:hover:not(&--disabled) &__thumb {
      outline: 2px solid var(--n-primary-color, #009688);
    }

    &--active &__thumb {
      outline: 2px solid var(--n-primary-color, #009688);
    }

    &--disabled {
      cursor: not-allowed;
      opacity: 0.4;
    }

    &__thumb {
      width: 100%;
      border-radius: 4px;
      overflow: hidden;

      ::v-deep(svg) {
        width: 100%;
        height: auto;
        display: block;
      }
    }

    &__label {
      font-size: 11px;
      color: var(--n-text-color-2, #6b7280);
      text-align: center;
      line-height: 1.3;
    }
  }

  // 导航主题
  .ps-nav-theme-group {
    display: flex;
    gap: 12px;
  }

  .ps-nav-theme-card {
    flex: 1;
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 6px;
    cursor: pointer;

    &:hover &__thumb {
      outline: 2px solid var(--n-primary-color, #009688);
    }

    &--active &__thumb {
      outline: 2px solid var(--n-primary-color, #009688);
    }

    &__thumb {
      width: 100%;
      border-radius: 4px;
      overflow: hidden;

      ::v-deep(svg) {
        width: 100%;
        height: auto;
        display: block;
      }
    }

    &__label {
      font-size: 11px;
      color: var(--n-text-color-2, #6b7280);
    }
  }

  // 预设卡片
  .ps-preset-card {
    padding: 12px;
    border-radius: 8px;
    border: 1.5px solid var(--n-border-color, #e5e7eb);
    cursor: pointer;
    margin-bottom: 10px;
    transition: all 0.15s;

    &:hover {
      border-color: var(--n-primary-color, #009688);
    }

    &--active {
      border-color: var(--n-primary-color, #009688);
      background: rgba(0, 150, 136, 0.04);
    }

    &__header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      margin-bottom: 4px;
    }

    &__name {
      font-size: 13px;
      font-weight: 600;
    }

    &__desc {
      font-size: 12px;
      color: var(--n-text-color-3, #9ca3af);
      margin: 0;
      line-height: 1.5;
    }
  }
</style>
