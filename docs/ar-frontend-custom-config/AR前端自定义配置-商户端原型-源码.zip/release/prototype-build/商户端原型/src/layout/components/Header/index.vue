<template>
  <header
    class="layout-header"
    :class="{ 'layout-header-inverted': headerInverted }"
    :style="headerStyle"
  >
    <!-- 顶部菜单模式 -->
    <div class="layout-header-left" v-if="showHorizontalMenu">
      <HeaderLogo />
      <n-divider vertical class="header-divider" />
      <HeaderTenant />
    </div>
    <!-- 左侧菜单模式 -->
    <div class="layout-header-left" v-else>
      <!-- 菜单收起 -->
      <div
        class="ml-1 layout-header-trigger layout-header-trigger-min"
        @click="handleMenuCollapsed"
      >
        <n-icon size="18" v-if="collapsed">
          <MenuUnfoldOutlined />
        </n-icon>
        <n-icon size="18" v-else>
          <MenuFoldOutlined />
        </n-icon>
      </div>
      <!-- 刷新 -->
      <div
        class="mr-1 layout-header-trigger layout-header-trigger-min"
        v-if="headerSetting.isReload"
        @click="reloadPage"
      >
        <n-icon size="18">
          <ReloadOutlined />
        </n-icon>
      </div>
      <!-- 面包屑 -->
      <n-breadcrumb v-if="crumbsSetting.show">
        <template
          v-for="routeItem in breadcrumbList"
          :key="routeItem.name === 'Redirect' ? void 0 : routeItem.name"
        >
          <n-breadcrumb-item v-if="routeItem.meta.title">
            <n-dropdown
              v-if="routeItem.children?.length"
              :options="routeItem.children"
              @select="dropdownSelect"
            >
              <span class="link-text">
                <component
                  v-if="crumbsSetting.showIcon && routeItem.meta.icon"
                  :is="routeItem.meta.icon"
                />
                {{ routeItem.meta.title }}
              </span>
            </n-dropdown>
            <span class="link-text" v-else>
              <component
                v-if="crumbsSetting.showIcon && routeItem.meta.icon"
                :is="routeItem.meta.icon"
              />
              {{ routeItem.meta.title }}
            </span>
          </n-breadcrumb-item>
        </template>
      </n-breadcrumb>
    </div>
    <!-- 水平菜单：主类型 + 悬停弹出多列大菜单（Mega Menu） -->
    <div class="layout-header-center header-menu" v-if="showHorizontalMenu">
      <MegaMenu />
    </div>
    <div class="layout-header-right">
      <!-- 找页面（仅商户端）-->
      <div
        v-if="!isPlatformSide"
        class="layout-header-trigger layout-header-trigger-min"
        @click="togglePageFinder"
      >
        <n-tooltip placement="bottom">
          <template #trigger>
            <n-icon size="18"><SearchOutline /></n-icon>
          </template>
          <span>{{ t('common.pageFinder.title') }}</span>
        </n-tooltip>
      </div>
      <!--切换全屏-->
      <div class="layout-header-trigger layout-header-trigger-min" @click="toggleFullScreen">
        <n-tooltip placement="bottom">
          <template #trigger>
            <n-icon size="18">
              <component :is="fullscreenIcon" />
            </n-icon>
          </template>
          <span>{{ $t('common.fullScreen') }}</span>
        </n-tooltip>
      </div>
      <!-- 在线人数 / 出入款 / 消息通知 仅在商户端展示：总控侧（isPlatformSide）隐藏 -->
      <OnlineBadge
        v-if="!isPlatformSide"
        :groups="onlineGroups"
        :current-count="currentTenantOnlineCount"
        :current-tenant-id="userStore.getActiveTenantId"
      />
      <MessageBadge v-if="!isPlatformSide" :groups="messageGroups" />
      <NotificationBadge v-if="!isPlatformSide && canViewNotify" />
      <!-- 个人中心 -->
      <div class="layout-header-trigger layout-header-trigger-min">
        <n-dropdown
          trigger="click"
          class="dropdown-lang-main"
          @select="avatarSelect"
          placement="bottom-end"
          size="large"
          :options="avatarOptions"
        >
          <div class="avatar">
            <n-badge :value="messageNum" processing>
              <n-avatar round>
                <ArLogo :size="28" />
              </n-avatar>
            </n-badge>
            <n-divider vertical />
            <span>{{ username }}</span>
          </div>
        </n-dropdown>
      </div>
    </div>
  </header>
  <!--项目配置-->
  <ProjectSetting ref="drawerSetting" />
</template>

<script lang="ts" setup>
  import type { Component } from 'vue';
  import type { RouteLocationMatched } from 'vue-router';
  import { ref, shallowRef, computed, unref, h, onMounted, onUnmounted } from 'vue';
  import { useRouter, useRoute } from 'vue-router';
  import { useDialog, useMessage, NIcon, useModal, NBadge } from 'naive-ui';
  import {
    LogOutOutline,
    SearchOutline,
    // PersonCircleOutline as UserIcon, // 暂时移除：个人中心入口
    KeyOutline,
    // StarOutline, // 暂时移除：收藏列表入口
    Language,
    // ColorPaletteOutline, // 暂时移除：换肤入口
  } from '@vicons/ionicons5';
  import components from './components';
  import { TABS_ROUTES } from '@/store/mutation-types';
  import { useAdminWsStore, useNotificationStore, useUserStore } from '@/store/modules';
  import ProjectSetting from './ProjectSetting.vue';
  import HeaderLogo from './HeaderLogo.vue';
  import HeaderTenant from './HeaderTenant.vue';
  import MessageBadge from './MessageBadge.vue';
  import NotificationBadge from './NotificationBadge.vue';
  import OnlineBadge from './OnlineBadge.vue';
  import ChangePasswordModal from './ChangePasswordModal.vue';
  import ArLogo from '@/components/Brand/ArLogo.vue';
  import { AsideMenu } from '@/layout/components/Menu';
  import MegaMenu from '@/layout/components/MegaMenu.vue';
  import { usePageFinder } from '@/layout/components/PageFinder/usePageFinder';
  import { useProjectSetting } from '@/hooks/setting';
  import { api } from '@/api';
  import { useI18n } from 'vue-i18n';
  // import { useFavorites } from '@/hooks/useFavorites'; // 暂时移除：收藏列表入口
  import { useLang } from '@/hooks';
  // ============ 类型定义 ============
  interface BreadcrumbItem {
    name: string;
    path: string;
    label: string;
    key: string;
    disabled: boolean;
    meta: {
      title?: string;
      icon?: Component;
    };
    children?: BreadcrumbItem[];
  }

  interface HeaderMessageMerchant {
    merchantId: string;
    /** 形如 "(1050) daman" 的展示名 —— 原型规定括号在前 */
    merchantName: string;
    /** 三方待入款（无权限时服务端置 0） */
    thirdRechargeCount: number;
    /** 本地待入款（无权限时服务端置 0） */
    localRechargeCount: number;
    /** 待出款（无权限时服务端置 0） */
    withdrawCount: number;
  }

  interface HeaderMessageGroup {
    groupId: string;
    groupName: string;
    merchants: HeaderMessageMerchant[];
  }

  interface HeaderOnlineMerchant {
    merchantId: string;
    /** 形如 "(1050) daman" 的展示名 —— 原型规定括号在前 */
    merchantName: string;
    /** 商户支持币种（如 INR / VND）——来自 tenant.supportSysCurrency；无值时 OnlineBadge 不渲染 chip */
    currencyCode: string;
    onlineCount: number;
  }

  interface HeaderOnlineGroup {
    groupId: string;
    groupName: string;
    merchants: HeaderOnlineMerchant[];
  }

  // ============ 组件注册 ============
  const {
    MenuUnfoldOutlined,
    MenuFoldOutlined,
    ReloadOutlined,
    FullscreenOutlined,
    FullscreenExitOutlined,
  } = components;

  // ============ Props & Emits ============
  const props = defineProps<{
    collapsed?: boolean;
    inverted?: boolean;
    headerStyle?: Record<string, string>;
    headerInverted?: boolean;
  }>();

  const emit = defineEmits<{
    'update:collapsed': [value: boolean];
  }>();

  // ============ 依赖注入 ============
  const { t } = useI18n();
  const { toggle: togglePageFinder } = usePageFinder();
  const router = useRouter();
  const route = useRoute();
  const dialog = useDialog();
  const modal = useModal();
  const message = useMessage();
  const userStore = useUserStore();
  const adminWsStore = useAdminWsStore();
  const notificationStore = useNotificationStore();
  const { navMode, headerSetting, menuSetting, crumbsSetting } = useProjectSetting();
  // const { favorites } = useFavorites(); // 暂时移除：收藏列表入口
  // 头像下拉「切换语言」子菜单复用 Header 地球图标按钮使用的同一套 hook，
  // 两处入口指向同一套 langOptions / handleLang，避免状态分叉。
  const { langOptions, handleLang, currentLang } = useLang();

  // ============ 响应式状态 ============
  const fullscreenIcon = shallowRef<Component>(FullscreenOutlined);
  const messageNum = ref(0);

  // Refs
  const drawerSetting = ref<InstanceType<typeof ProjectSetting>>();

  // ============ 计算属性 ============
  const username = computed(() => userStore?.info?.userName ?? '');

  const mixMenu = computed(() => unref(menuSetting).mixMenu);

  // 是否显示水平菜单
  const showHorizontalMenu = computed(() => {
    return navMode.value === 'horizontal' || (navMode.value === 'horizontal-mix' && mixMenu.value);
  });

  // 面包屑列表
  const breadcrumbList = computed((): BreadcrumbItem[] => {
    const generator = (routerMap: RouteLocationMatched[]): BreadcrumbItem[] => {
      return routerMap.map((item) => {
        const rawTitle = item.meta?.title as string | undefined;
        const translatedTitle = rawTitle ? t(rawTitle) : '';
        const currentMenu: BreadcrumbItem = {
          ...item,
          label: translatedTitle,
          key: item.name as string,
          disabled: item.path === '/',
          meta: { ...item.meta, title: translatedTitle } as BreadcrumbItem['meta'],
          children: undefined,
        };
        if (item.children?.length) {
          currentMenu.children = generator(item.children as unknown as RouteLocationMatched[]);
        }
        return currentMenu;
      });
    };
    return generator(route.matched);
  });

  // 切换语言子菜单：沿用 useLang 提供的国旗 icon，保持与登录页一致的视觉识别；
  // key 加 `lang_` 前缀避免与 avatarOptions 数字 key 冲突；
  // 当前语言项置灰禁用，避免重复触发 switchLocale 无谓重载 namespace。
  const langChildren = computed(() =>
    langOptions.value.map(({ label, key, icon }) => ({
      label,
      key: `lang_${key}`,
      icon,
      disabled: key === currentLang.value,
    })),
  );

  // 收藏列表子菜单（暂时移除该功能）
  // const favoriteChildren = computed(() => {
  //   if (favorites.value.length === 0) {
  //     return [
  //       {
  //         label: t('common.noFavorites'),
  //         key: 'fav_empty',
  //         disabled: true,
  //       },
  //     ];
  //   }
  //   return favorites.value.map((item) => ({
  //     label: t(item.title) || item.name,
  //     key: `fav_${item.path}`,
  //   }));
  // });

  // 头像下拉菜单选项
  // 暂时移除：个人中心(key:1) / 收藏列表(key:10) / 换肤(key:7)
  const avatarOptions = computed(() => [
    // {
    //   label: t('common.header.personalCenter'),
    //   key: 1,
    //   icon: () => h(NIcon, { size: 20 }, () => h(UserIcon)),
    // },
    // {
    //   label: t('common.favorites'),
    //   key: 10,
    //   icon: () => h(NIcon, { size: 20 }, () => h(StarOutline)),
    //   children: favoriteChildren.value,
    // },
    // {
    //   label: t('common.themeConfig'),
    //   key: 7,
    //   icon: () => h(NIcon, { size: 20 }, () => h(ColorPaletteOutline)),
    // },
    {
      label: t('common.header.switchLanguage'),
      key: 8,
      icon: () => h(NIcon, { size: 20 }, () => h(Language)),
      children: langChildren.value,
    },
    {
      label: t('common.changePassword'),
      key: 3,
      icon: () => h(NIcon, { size: 20 }, () => h(KeyOutline)),
    },
    {
      label: t('common.logout'),
      key: 2,
      icon: () => h(NIcon, { size: 20 }, () => h(LogOutOutline)),
    },
  ]);

  // ============ 事件处理 ============
  function handleMenuCollapsed() {
    emit('update:collapsed', !props.collapsed);
  }

  function reloadPage() {
    router.push({ path: '/redirect' + route.fullPath });
  }

  function dropdownSelect(key: string) {
    router.push({ name: key });
  }

  function openSetting() {
    drawerSetting.value?.openDrawer();
  }

  // 全屏切换
  function toggleFullScreen() {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen();
    } else {
      document.exitFullscreen?.();
    }
  }

  function handleFullscreenChange() {
    fullscreenIcon.value = document.fullscreenElement ? FullscreenExitOutlined : FullscreenOutlined;
  }

  function switchHeaderLanguage(locale: string) {
    void handleLang(locale);
    router.go(0);
  }

  function initAdminWs() {
    adminWsStore.bootstrap({
      orgId: userStore.info?.orgId,
      userId: userStore.info?.userId,
    });

    void adminWsStore.connect();
  }

  // 商户 / 总控两种用户在顶栏有不同入口：在线和消息只在商户端展示
  const isPlatformSide = computed(() => userStore.isPlatformUser);

  // 站内信入口可见性总开关：以列表查询权限为判据；无权限则隐藏 NotificationBadge 并跳过 init，
  // 避免发任何 /api/SysUserNotify/* 请求。store 各 action 内部已有同源守卫，此处为入口层双保险。
  const canViewNotify = computed(() => true);

  // 顶栏在线人数 & 消息分组全部走 store：adminWs 在 handleBusinessEvent 里维护两份
  // 商户级快照，组件只负责做成 UI 需要的 shape。
  const messageGroups = computed<HeaderMessageGroup[]>(() => {
    const map = new Map<number, HeaderMessageGroup>();
    for (const item of adminWsStore.rechargeWithdrawWaitList) {
      const tenant = userStore.getTenantById(item.tenantId);
      if (!tenant) continue;
      let group = map.get(tenant.orgId);
      if (!group) {
        group = {
          groupId: String(tenant.orgId),
          groupName: tenant.orgName || String(tenant.orgId),
          merchants: [],
        };
        map.set(tenant.orgId, group);
      }
      group.merchants.push({
        merchantId: String(tenant.id),
        // 原型要求括号在前：(1050) daman
        merchantName: `(${tenant.id}) ${tenant.name}`,
        thirdRechargeCount: item.thirdRechargeCount ?? 0,
        localRechargeCount: item.localRechargeCount ?? 0,
        withdrawCount: item.withdrawCount ?? 0,
      });
    }
    return [...map.values()];
  });

  // 在线人数浮窗数据源：以 userStore.getTenantGroups（用户可见商户全集）为基础，叠加 WS 实时推送值。
  // WS 未推送 / 连接中断 / 部分商户无数据时兜底为 0，确保 hover 始终能展开完整商户清单，不再出现整体空态。
  // 可见商户范围与 adminWs.filterTenantScopedList 同源（都基于 user.info.tenantList），不会因兜底而误展示跨权限商户。
  const onlineGroups = computed<HeaderOnlineGroup[]>(() => {
    const onlineCountMap = new Map<number, number>();
    for (const item of adminWsStore.onlineUserCountList) {
      onlineCountMap.set(item.tenantId, item.onLineUserCount ?? 0);
    }
    return userStore.getTenantGroups
      .filter((group) => group.tenants.length > 0)
      .map((group) => ({
        groupId: String(group.orgId),
        groupName: group.orgName || String(group.orgId),
        merchants: group.tenants.map((tenant) => ({
          merchantId: String(tenant.id),
          // 原型要求括号在前：(1050) daman
          merchantName: `(${tenant.id}) ${tenant.name}`,
          currencyCode: tenant.supportSysCurrency || '',
          onlineCount: onlineCountMap.get(tenant.id) ?? 0,
        })),
      }));
  });

  // 顶栏角标只显示「当前激活商户」的在线人数，与 HeaderTenant / 列表时区基准同源（getActiveTenantId）。
  // 激活商户不在 list 里（字典加载延迟、被服务端裁、临时无数据）→ 兜底 0，配合 :show-zero 视觉稳定。
  const currentTenantOnlineCount = computed<number>(() => {
    const activeId = userStore.getActiveTenantId;
    if (typeof activeId !== 'number') return 0;
    const found = adminWsStore.onlineUserCountList.find((item) => item.tenantId === activeId);
    return found?.onLineUserCount ?? 0;
  });

  // 退出登录
  function doLogout() {
    const d = dialog.info({
      title: t('common.tip'),
      content: t('common.logoutTip'),
      positiveText: t('common.confirm'),
      negativeText: t('common.cancel'),
      onPositiveClick: async () => {
        d.loading = true;
        const { code, msg } = await api.admin.loginOff();
        if (code !== 0) {
          message.error(msg);
          await userStore.logout();
          router.replace({ name: 'Login' }).finally(() => {
            location.reload();
            localStorage.removeItem(TABS_ROUTES);
          });
          return;
        }
        message.success(t('common.logoutSuccess'));
        await userStore.logout();
        router.replace({ name: 'Login' }).finally(() => {
          location.reload();
          localStorage.removeItem(TABS_ROUTES);
        });
      },
    });
  }

  // 头像菜单选择
  function avatarSelect(key: string | number) {
    // 收藏项点击（功能已暂时移除，保留路由分支以便复原）
    // if (typeof key === 'string' && key.startsWith('fav_') && key !== 'fav_empty') {
    //   const path = key.slice(4);
    //   router.push(path);
    //   return;
    // }
    // 处理切换语言子菜单
    if (typeof key === 'string' && key.startsWith('lang_')) {
      void switchHeaderLanguage(key.slice(5));
      return;
    }

    switch (key) {
      // case 1:
      //   router.push({ name: 'home_profile' });
      //   break;
      case 2:
        doLogout();
        break;
      case 3:
        openChangePasswordModal();
        break;
      // case 7:
      //   openSetting();
      //   break;
    }
  }

  // 改密弹窗函数式调用：拆到独立组件，走 useModal.create，表单/校验/提交都自封装
  function openChangePasswordModal() {
    const inst = modal.create({
      title: t('common.changeLoginPassword'),
      preset: 'dialog',
      showIcon: false,
      style: { width: '440px' },
      content: () =>
        h(ChangePasswordModal, {
          onClose: () => inst.destroy(),
        }),
    });
  }

  // ============ 生命周期 ============
  onMounted(() => {
    handleFullscreenChange();
    document.addEventListener('fullscreenchange', handleFullscreenChange);
    initAdminWs();
    // 仅租户侧 + 拥有站内信功能权限时加载消息通知；总控、无权限用户均跳过 init
    // （store.init 内部也已守卫；此处提前判断避免无谓的入栈调用）
    if (!isPlatformSide.value && canViewNotify.value) {
      void notificationStore.init();
    }
  });

  onUnmounted(() => {
    document.removeEventListener('fullscreenchange', handleFullscreenChange);
    void adminWsStore.disconnect();
  });
</script>

<style lang="less" scoped>
  .layout-header {
    position: fixed;
    top: 0;
    right: 0;
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 0;
    height: 68px;
    box-shadow: 0 2px 8px rgb(0 21 41 / 15%);
    transition: all 0.2s ease-in-out;
    // 顶栏需高于内容区 sticky 元素（MerchantSwitchBar z:20 / 出款浮窗 z:40），
    // 否则 MegaMenu 下拉面板(被困在本层叠上下文)会被这些 sticky 条穿透遮挡。
    z-index: 100;
    color: #fff;

    // 所有图标和文字都使用白色
    .n-icon {
      color: #fff !important;
    }

    .anticon {
      color: #fff !important;
    }

    &-left {
      display: flex;
      align-items: center;
      height: 100%;

      .header-divider {
        height: 24px;
        margin: 0 4px;
        background-color: rgba(255, 255, 255, 0.3);
      }

      ::v-deep(.ant-breadcrumb span:last-child .link-text) {
        color: rgba(255, 255, 255, 0.85);
      }

      .n-breadcrumb {
        display: inline-block;

        ::v-deep(.n-breadcrumb-item__link) {
          color: rgba(255, 255, 255, 0.65) !important;
        }

        ::v-deep(.n-breadcrumb-item:last-child .n-breadcrumb-item__link) {
          color: #fff !important;
        }

        ::v-deep(.n-breadcrumb-item__separator) {
          color: rgba(255, 255, 255, 0.45) !important;
        }
      }

      &-menu {
        color: inherit;
      }
    }
    &-center {
    }

    &-right {
      display: flex;
      align-items: center;
      height: 100%;
      margin-right: 20px;

      .avatar {
        display: flex;
        align-items: center;
        height: 100%;

        ::v-deep(.n-divider) {
          background-color: rgba(255, 255, 255, 0.3) !important;
        }
      }

      > * {
        cursor: pointer;
      }
    }

    &-trigger {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      width: auto;
      height: 44px;
      margin: 0 2px;
      padding: 0 10px;
      border-radius: 6px;
      text-align: center;
      cursor: pointer;
      transition: background-color 0.2s cubic-bezier(0.4, 0, 0.2, 1);

      .n-icon {
        display: flex;
        align-items: center;
        height: auto;
        line-height: 1;
      }

      &:hover {
        background: hsla(0, 0%, 100%, 0.12);
      }
    }

    &-trigger-min {
      min-width: 36px;
      padding: 0 10px;
    }

    &-trigger--badge {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      height: 44px;
      padding: 0 10px;

      .n-icon {
        height: auto;
        line-height: 1;
      }

      .trigger-badge-content {
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        gap: 2px;
        cursor: pointer;
      }

      .trigger-badge-text {
        font-size: 12px;
        line-height: 1.1;
        white-space: nowrap;
      }
    }
  }

  .layout-header-fix {
    position: fixed;
    top: 0;
    right: 0;
    left: 200px;
    z-index: 100;
  }
</style>
<style lang="less">
  // 顶部菜单自定义样式 - 适配主题色背景
  .header-menu {
    .n-menu {
      background: transparent !important;
    }

    .n-menu--horizontal .n-menu-item-content,
    .n-menu--horizontal .n-submenu .n-menu-item-content {
      padding: 0 15px !important;
    }

    // 菜单项文字颜色
    .n-menu-item-content {
      color: rgba(255, 255, 255, 0.85) !important;

      &:hover {
        color: #fff !important;

        .n-icon,
        .n-menu-item-content__icon {
          color: #fff !important;
        }
      }

      // 选中状态
      &--selected {
        color: #fff !important;
        font-weight: 600;

        .n-icon,
        .n-menu-item-content__icon {
          color: #fff !important;
        }

        &::after {
          content: '';
          position: absolute;
          bottom: 0;
          left: 50%;
          transform: translateX(-50%);
          width: 80%;
          height: 2px;
          background: #fff;
          border-radius: 1px;
        }
      }

      // 菜单图标颜色
      .n-icon,
      .n-menu-item-content__icon {
        color: rgba(255, 255, 255, 0.85) !important;
      }
    }

    // 子菜单触发器
    .n-submenu-children {
      background: transparent !important;
    }

    // 箭头图标颜色
    .n-base-icon {
      color: rgba(255, 255, 255, 0.65) !important;
    }

    // 菜单项 hover 背景
    .n-menu-item-content-header {
      color: inherit !important;
    }

    // 所有菜单内的图标
    .n-menu-item .n-icon,
    .n-submenu .n-icon {
      color: rgba(255, 255, 255, 0.85) !important;
    }
  }

  .dropdown-lang {
    text-align: center;
    &-main {
      .n-dropdown-option-body__label {
        text-align: center;
      }
    }
    .n-dropdown-option-body__prefix {
      width: 40px !important;
    }
    &-item {
      align-items: center;
      color: var(--n-option-text-color);
      span {
        display: block;
        z-index: 1;
      }
      &:hover:before {
        background-color: var(--n-option-color-hover);
      }
    }
  }
</style>
