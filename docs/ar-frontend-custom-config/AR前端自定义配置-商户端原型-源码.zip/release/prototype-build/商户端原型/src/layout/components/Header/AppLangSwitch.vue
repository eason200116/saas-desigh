<!--
  @description Header 独立语言切换按钮：地球图标 + NDropdown + NTooltip，切换后刷新当前路由。
  消费 useLang 的 currentLang / langOptions / handleLang，内部剔除下拉选项上的国旗 icon，
  只保留 { label, key } 两字段，避免登录页使用的图片样式侵入 Header 深色工具栏。
  @author sum
  @date 2026-04-21
  @scope 仅用于 src/layout/components/Header/index.vue 右侧工具栏
-->
<template>
  <n-dropdown
    :options="options"
    :value="currentLang"
    trigger="click"
    placement="bottom-end"
    @select="onSelect"
  >
    <div
      class="layout-header-trigger layout-header-trigger-min"
      role="button"
      :aria-label="tooltipText"
    >
      <n-tooltip placement="bottom">
        <template #trigger>
          <n-icon size="18">
            <Language />
          </n-icon>
        </template>
        <span>{{ tooltipText }}</span>
      </n-tooltip>
    </div>
  </n-dropdown>
</template>

<script lang="ts" setup>
  import { computed, ref } from 'vue';
  import { NDropdown, NIcon, NTooltip } from 'naive-ui';
  import { Language } from '@vicons/ionicons5';
  import { useI18n } from 'vue-i18n';
  import { useRouter } from 'vue-router';
  import { useLang } from '@/hooks';

  const { t } = useI18n();
  const router = useRouter();
  const { currentLang, langOptions, handleLang } = useLang();

  const switching = ref(false);

  const tooltipText = computed(() => t('common.header.switchLanguage'));

  const options = computed(() => langOptions.value.map(({ label, key }) => ({ label, key })));

  async function onSelect(key: string) {
    if (switching.value || key === currentLang.value) return;
    switching.value = true;
    try {
      void handleLang(key);
      router.go(0);
    } finally {
      switching.value = false;
    }
  }
</script>

<style lang="less" scoped>
  .layout-header-trigger {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    height: 44px;
    margin: 1px 2px 0;
    padding: 0 10px;
    border-radius: 6px;
    color: rgb(255 255 255 / 0.86);
    cursor: pointer;
    transition:
      background-color 0.2s cubic-bezier(0.4, 0, 0.2, 1),
      color 0.2s cubic-bezier(0.4, 0, 0.2, 1);
  }

  .layout-header-trigger:hover {
    background: rgb(255 255 255 / 0.12);
    color: #fff;
  }

  .layout-header-trigger-min {
    min-width: 36px;
  }
</style>
