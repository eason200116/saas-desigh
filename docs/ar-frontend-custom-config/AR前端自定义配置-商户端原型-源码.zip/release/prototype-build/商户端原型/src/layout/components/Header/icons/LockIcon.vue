<template>
  <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
    <g>
      <rect width="16" height="16" fill="#D9D9D9" fill-opacity="0.01" />
      <path
        d="M11 7V4C11 2.34315 9.65685 1 8 1C6.34315 1 5 2.34315 5 4V7"
        stroke="#B0B5C3"
        stroke-width="2"
      />
      <path
        fill-rule="evenodd"
        clip-rule="evenodd"
        d="M4 7C2.89543 7 2 7.89543 2 9V13C2 14.1046 2.89543 15 4 15H12C13.1046 15 14 14.1046 14 13V9C14 7.89543 13.1046 7 12 7H4ZM8 9C7.44772 9 7 9.44772 7 10V12C7 12.5523 7.44772 13 8 13C8.55228 13 9 12.5523 9 12V10C9 9.44772 8.55228 9 8 9Z"
        fill="#B0B5C3"
      />
    </g>
  </svg>
</template>

<script lang="ts" setup>
  defineOptions({
    name: 'LockIcon',
  });
</script>
