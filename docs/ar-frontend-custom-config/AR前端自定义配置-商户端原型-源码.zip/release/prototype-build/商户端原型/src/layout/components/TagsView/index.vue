<template>
  <!-- n-el 暴露 naive-ui theme vars（--card-color / --divider-color 等），
       下面样式使用 var(--xxx)，主题切换自动跟随 -->
  <n-el
    tag="div"
    class="tabs-view"
    :class="{
      'tabs-view-fix': multiTabsSetting.fixed,
    }"
    :style="getChangeStyle"
  >
    <div class="tabs-view-main">
      <div ref="navWrap" class="tabs-card" :class="{ 'tabs-card-scrollable': scrollable }">
        <span
          class="tabs-card-prev"
          :class="{ 'tabs-card-prev-hide': !scrollable }"
          @click="scrollPrev"
        >
          <n-icon size="16" :color="getBaseColor">
            <LeftOutlined />
          </n-icon>
        </span>
        <span
          class="tabs-card-next"
          :class="{ 'tabs-card-next-hide': !scrollable }"
          @click="scrollNext"
        >
          <n-icon size="16" :color="getBaseColor">
            <RightOutlined />
          </n-icon>
        </span>
        <div
          ref="navScroll"
          class="tabs-card-scroll"
          @pointerdown="onTabsPointerDown"
          @pointermove="onTabsPointerMove"
          @pointerup="onTabsPointerUp"
          @pointerleave="onTabsPointerUp"
          @pointercancel="onTabsPointerUp"
          @wheel="onTabsWheel"
        >
          <Draggable
            v-model="tabsList"
            animation="300"
            item-key="fullPath"
            class="tabs-card-scroll-inner"
            @change="onDragChange"
          >
            <div
              v-for="element in tabsList"
              :key="element.fullPath"
              :id="`tag${element.fullPath.split('/').join('\/')}`"
              class="tabs-card-scroll-item"
              :class="{ 'active-item': activeKey === element.fullPath }"
              @click.stop="goPage(element)"
              @contextmenu="handleContextMenu($event, element)"
            >
              <n-icon
                v-if="isFavorite(element.fullPath)"
                size="14"
                class="tabs-card-scroll-item__star"
              >
                <StarOutline />
              </n-icon>
              <span>{{ getFormattedTitle(element.meta.title, element) }}</span>
              <n-icon v-if="isClosableTab(element)" size="14" @click.stop="closeTabItem(element)">
                <CloseOutlined />
              </n-icon>
            </div>
          </Draggable>
        </div>
      </div>
      <div class="tabs-close">
        <n-dropdown
          trigger="hover"
          @select="closeHandleSelect"
          placement="bottom-end"
          :options="TabsMenuOptions"
        >
          <div class="tabs-close-btn">
            <n-icon size="16" :color="getBaseColor">
              <ChevronDown />
            </n-icon>
          </div>
        </n-dropdown>
      </div>
      <n-dropdown
        :show="showDropdown"
        :x="dropdownX"
        :y="dropdownY"
        @clickoutside="onClickOutside"
        placement="bottom-start"
        @select="closeHandleSelect"
        :options="TabsMenuOptions"
      />
    </div>
  </n-el>
</template>

<script lang="ts">
  import {
    defineComponent,
    reactive,
    computed,
    ref,
    toRefs,
    provide,
    watch,
    onMounted,
    nextTick,
  } from 'vue';
  import { useRoute, useRouter } from 'vue-router';
  import { storage } from '@/utils/Storage';
  import { TABS_ROUTES } from '@/store/mutation-types';
  import { useTabsViewStore, useAsyncRouteStore } from '@/store/modules';
  import { RouteItem } from '@/store/modules/tabsView';
  import { useMessage, NEl } from 'naive-ui';
  import { VueDraggableNext as Draggable } from 'vue-draggable-next';
  import { PageEnum } from '@/enums';
  import {
    ReloadOutlined,
    CloseOutlined,
    ColumnWidthOutlined,
    MinusOutlined,
    LeftOutlined,
    RightOutlined,
  } from '@vicons/antd';
  import { ChevronDown, StarOutline } from '@vicons/ionicons5';
  import { renderIcon } from '@/utils';
  import elementResizeDetectorMaker from 'element-resize-detector';
  import { useProjectSetting } from '@/hooks/setting';
  import { useThemeVars } from 'naive-ui';
  import { useGo } from '@/hooks/web';
  import { useI18n } from 'vue-i18n';
  import { useFavorites } from '@/hooks/useFavorites';
  export default defineComponent({
    name: 'TabsView',
    components: {
      ChevronDown,
      CloseOutlined,
      LeftOutlined,
      RightOutlined,
      StarOutline,
      Draggable,
      NEl,
    },
    props: {
      collapsed: {
        type: Boolean,
      },
    },
    setup(props) {
      const { t } = useI18n();
      const { themeColor } = useProjectSetting();
      const { navMode, menuSetting, multiTabsSetting, isMobile } = useProjectSetting();

      const message = useMessage();
      const route = useRoute();
      const router = useRouter();
      const tabsViewStore = useTabsViewStore();
      const asyncRouteStore = useAsyncRouteStore();
      const navScroll: any = ref(null);
      const navWrap: any = ref(null);
      const go = useGo();

      const { favorites, addFavorite, removeFavorite, isFavorite } = useFavorites();
      const contextMenuRoute = ref<RouteItem | null>(null);

      const themeVars = useThemeVars();

      const getCardColor = computed(() => {
        return themeVars.value.cardColor;
      });

      const getBaseColor = computed(() => {
        return themeVars.value.textColor1;
      });

      // Background color for tabs view based on theme
      const getTabsBgColor = computed(() => {
        return themeVars.value.bodyColor;
      });

      const state = reactive({
        activeKey: route.fullPath,
        scrollable: false,
        dropdownX: 0,
        dropdownY: 0,
        showDropdown: false,
        multiTabsSetting: multiTabsSetting,
      });

      // 获取简易的路由对象
      const getSimpleRoute = (route): RouteItem => {
        const { fullPath, hash, meta, name, params, path, query } = route;
        return { fullPath, hash, meta, name, params, path, query };
      };

      const getCurrentRoute = () => getSimpleRoute(route);

      //动态组装样式 菜单缩进
      const getChangeStyle = computed(() => {
        const { collapsed } = props;
        const { minMenuWidth, menuWidth }: any = menuSetting.value || {};
        const { fixed }: any = multiTabsSetting.value || {};

        // 非 fixed 模式不需要定位样式
        if (!fixed) {
          return { width: '100%' };
        }

        // 移动端模式
        if (isMobile.value) {
          return {
            left: '0px',
            width: '100%',
          };
        }

        // 计算左侧偏移量（vertical 和 horizontal-mix + mixMenu 均有侧边栏）
        const { mixMenu } = menuSetting.value || {};
        const hasSidebar =
          navMode.value === 'vertical' || (navMode.value === 'horizontal-mix' && !!mixMenu);
        const lenNum = hasSidebar ? (collapsed ? minMenuWidth || 64 : menuWidth || 200) : 0;

        return {
          left: `${lenNum}px`,
          width: `calc(100% - ${lenNum}px)`,
        };
      });

      //tags 右侧下拉菜单
      const TabsMenuOptions = computed(() => {
        const targetRoute = state.showDropdown
          ? contextMenuRoute.value || getCurrentRoute()
          : getCurrentRoute();
        const isDisabled = tabsList.value.length <= 1;
        const targetPath = targetRoute.fullPath;
        const isFav = isFavorite(targetPath);
        const isProtectedTab = isClosableRoute(targetRoute) === false;
        return [
          {
            label: t('common.refreshCurrent'),
            key: '1',
            icon: renderIcon(ReloadOutlined),
          },
          {
            label: t('common.closeCurrent'),
            key: '2',
            disabled: isDisabled || isProtectedTab,
            icon: renderIcon(CloseOutlined),
          },
          {
            label: t('common.closeOther'),
            key: '3',
            disabled: isDisabled,
            icon: renderIcon(ColumnWidthOutlined),
          },
          {
            label: t('common.closeAll'),
            key: '4',
            disabled: isDisabled,
            icon: renderIcon(MinusOutlined),
          },
          {
            label: t('common.closeLeft'),
            key: '7',
            disabled: isDisabled,
            icon: renderIcon(LeftOutlined),
          },
          {
            label: t('common.closeRight'),
            key: '5',
            disabled: isDisabled,
            icon: renderIcon(RightOutlined),
          },
          {
            type: 'divider',
            key: 'd1',
          },
          {
            label: isFav ? t('common.removeFavorite') : t('common.addFavorite'),
            key: '6',
            icon: renderIcon(StarOutline),
          },
        ];
      });

      let cacheRoutes: RouteItem[] = [];
      const simpleRoute = getSimpleRoute(route);
      try {
        const routesStr = storage.get(TABS_ROUTES) as string | null | undefined;
        cacheRoutes = routesStr ? JSON.parse(routesStr) : [simpleRoute];
      } catch (e) {
        cacheRoutes = [simpleRoute];
      }

      // 将最新的路由信息同步到 localStorage 中
      const routes = router.getRoutes();
      cacheRoutes.forEach((cacheRoute) => {
        const route = routes.find((route) => route.path === cacheRoute.path);
        if (route) {
          cacheRoute.meta = cacheRoute.meta || route.meta;
          cacheRoute.name = (route.name || cacheRoute.name) as string;
          cacheRoute.meta.title = route.meta.title;
        }
      });

      // 初始化标签页（initTabs 内部已去重，杜绝刷新累积的重复 tab）
      tabsViewStore.initTabs(cacheRoutes);
      // 立即把去重后的列表回写 localStorage，使历史残留当场清理，不必等 beforeunload
      storage.set(TABS_ROUTES, JSON.stringify(tabsViewStore.tabsList));

      // 移除缓存组件名称
      const delKeepAliveCompName = () => {
        if (route.meta.keepAlive) {
          const name = router.currentRoute.value.matched.find((item) => item.name == route.name)
            ?.components?.default.name;
          if (name) {
            asyncRouteStore.keepAliveComponents = asyncRouteStore.keepAliveComponents.filter(
              (item) => item != name,
            );
          }
        }
      };

      // 标签页列表 - 使用 ref 以支持 Draggable 的 v-model
      const tabsList = ref<RouteItem[]>([]);

      const isAffixRoute = (target?: RouteItem | null) =>
        Boolean((target?.meta as { affix?: boolean } | undefined)?.affix);

      const sortTabsByFavorite = (list: RouteItem[]) => {
        return list
          .map((item, index) => ({ item, index }))
          .sort((source, target) => {
            const sourceAffix = isAffixRoute(source.item);
            const targetAffix = isAffixRoute(target.item);

            if (sourceAffix !== targetAffix) {
              return sourceAffix ? -1 : 1;
            }

            const sourceFavorite = isFavorite(source.item.fullPath);
            const targetFavorite = isFavorite(target.item.fullPath);

            if (sourceFavorite !== targetFavorite) {
              return sourceFavorite ? -1 : 1;
            }

            return source.index - target.index;
          })
          .map(({ item }) => item);
      };

      // 监听 store 变化，同步到本地 ref
      watch(
        () => tabsViewStore.tabsList,
        (newList) => {
          tabsList.value = sortTabsByFavorite(newList);
        },
        { deep: true, immediate: true },
      );

      watch(
        () => favorites.value.map((item) => item.path),
        () => {
          tabsList.value = sortTabsByFavorite(tabsViewStore.tabsList);
        },
        { deep: true },
      );

      // 拖拽排序后同步回 store
      const onDragChange = () => {
        tabsViewStore.initTabs(tabsList.value);
      };
      const whiteList: string[] = [
        PageEnum.BASE_LOGIN_NAME,
        PageEnum.REDIRECT_NAME,
        PageEnum.ERROR_PAGE_NAME,
      ];

      watch(
        () => route.fullPath,
        (to, from) => {
          if (whiteList.includes(route.name as string)) return;
          state.activeKey = to;
          tabsViewStore.insertRightTab(getSimpleRoute(route), from || '');
          updateNavScroll(true);
        },
        { immediate: true },
      );

      // 在页面关闭或刷新之前，保存数据
      window.addEventListener('beforeunload', () => {
        storage.set(TABS_ROUTES, JSON.stringify(tabsList.value));
      });

      const isClosableRoute = (target?: RouteItem | null) => {
        if (!target) return false;
        // 只有 affix 固定页不可关。收藏 ≠ 固定：收藏只是书签，不应锁住标签关闭（否则收藏后 X 消失）。
        // 2026-07-18 用户报 bug 修复：原来 `&& !isFavorite(...)` 把收藏标签判成不可关、X 不渲染。
        return !isAffixRoute(target);
      };

      const isClosableTab = (target?: RouteItem | null) => isClosableRoute(target);

      const getActionTarget = () =>
        state.showDropdown ? contextMenuRoute.value || getCurrentRoute() : getCurrentRoute();

      const filterClosableTabs = (predicate: (item: RouteItem, index: number) => boolean) => {
        tabsViewStore.initTabs(
          tabsList.value.filter((item, index) => !isClosableRoute(item) || predicate(item, index)),
        );
      };

      // 关闭当前页面
      const removeTab = (closedRoute) => {
        if (!closedRoute) return;
        if (tabsList.value.length === 1) {
          return message.warning(t('common.lastPageWarning'));
        }
        if (isFavorite(closedRoute.fullPath)) {
          return message.warning(t('common.favoriteCloseWarning'));
        }
        if (!isClosableRoute(closedRoute)) {
          return;
        }
        delKeepAliveCompName();
        tabsViewStore.closeCurrentTab(closedRoute);
        // 如果关闭的是当前页，导航到相邻标签
        if (state.activeKey === closedRoute.fullPath) {
          // 直接读 store（splice 已同步生效），不读 watch 延迟同步的本地 ref
          const storeList = tabsViewStore.tabsList;
          const nextRoute = storeList[Math.max(0, storeList.length - 1)];
          state.activeKey = nextRoute.fullPath;
          router.push(nextRoute);
        }
        updateNavScroll();
      };

      // 刷新页面
      const reloadPage = () => {
        delKeepAliveCompName();
        router.push({
          path: '/redirect' + route.fullPath,
        });
      };

      // 注入刷新页面方法
      provide('reloadPage', reloadPage);

      // 关闭左侧
      const closeLeft = (route) => {
        const index = tabsList.value.findIndex((item) => item.fullPath == route.fullPath);
        filterClosableTabs(
          (item, itemIndex) => itemIndex >= index || item.fullPath === route.fullPath,
        );
        state.activeKey = route.fullPath;
        router.replace(route.fullPath);
        updateNavScroll();
      };

      // 关闭右侧
      const closeRight = (route) => {
        const index = tabsList.value.findIndex((item) => item.fullPath == route.fullPath);
        filterClosableTabs(
          (item, itemIndex) => itemIndex <= index || item.fullPath === route.fullPath,
        );
        state.activeKey = route.fullPath;
        router.replace(route.fullPath);
        updateNavScroll();
      };

      // 关闭其他
      const closeOther = (route) => {
        filterClosableTabs((item) => item.fullPath === route.fullPath);
        state.activeKey = route.fullPath;
        router.replace(route.fullPath);
        updateNavScroll();
      };

      // 关闭全部
      const closeAll = () => {
        filterClosableTabs(() => false);
        router.replace(PageEnum.BASE_HOME);
        updateNavScroll();
      };

      //tab 操作
      const closeHandleSelect = (key) => {
        const target = getActionTarget();
        switch (key) {
          //刷新
          case '1':
            reloadPage();
            break;
          //关闭
          case '2':
            removeTab(target);
            break;
          //关闭其他
          case '3':
            closeOther(target);
            break;
          //关闭所有
          case '4':
            closeAll();
            break;
          //关闭右侧
          case '5':
            closeRight(target);
            break;
          //关闭左侧
          case '7':
            closeLeft(target);
            break;
          //收藏/取消收藏
          case '6': {
            if (isFavorite(target.fullPath)) {
              removeFavorite(target.fullPath);
            } else {
              addFavorite(target as any);
            }
            break;
          }
        }
        updateNavScroll();
        state.showDropdown = false;
      };

      /**
       * @param value 要滚动到的位置
       * @param amplitude 每次滚动的长度
       */
      function scrollTo(value: number, amplitude: number) {
        const currentScroll = navScroll.value.scrollLeft;
        const scrollWidth =
          (amplitude > 0 && currentScroll + amplitude >= value) ||
          (amplitude < 0 && currentScroll + amplitude <= value)
            ? value
            : currentScroll + amplitude;
        if (navScroll.value) {
          navScroll.value.scrollTo(scrollWidth, 0);
        }
        if (scrollWidth === value) return;
        return window.requestAnimationFrame(() => scrollTo(value, amplitude));
      }

      function scrollPrev() {
        const containerWidth = navScroll.value.offsetWidth;
        const currentScroll = navScroll.value.scrollLeft;

        if (!currentScroll) return;
        const scrollLeft = currentScroll > containerWidth ? currentScroll - containerWidth : 0;
        scrollTo(scrollLeft, (scrollLeft - currentScroll) / 20);
      }

      function scrollNext() {
        const containerWidth = navScroll.value.offsetWidth;
        const navWidth = navScroll.value.scrollWidth;
        const currentScroll = navScroll.value.scrollLeft;

        if (navWidth - currentScroll <= containerWidth) return;
        const scrollLeft =
          navWidth - currentScroll > containerWidth * 2
            ? currentScroll + containerWidth
            : navWidth - containerWidth;
        scrollTo(scrollLeft, (scrollLeft - currentScroll) / 20);
      }

      /**
       * @param autoScroll 是否开启自动滚动功能
       */
      async function updateNavScroll(autoScroll?: boolean) {
        await nextTick();
        if (!navScroll.value) return;
        const containerWidth = navScroll.value.offsetWidth;
        const navWidth = navScroll.value.scrollWidth;

        if (containerWidth < navWidth) {
          state.scrollable = true;
          if (autoScroll) {
            let tagList = navScroll.value.querySelectorAll('.tabs-card-scroll-item') || [];
            [...tagList].forEach((tag: HTMLElement) => {
              // fix SyntaxError
              if (tag.id === `tag${state.activeKey.split('/').join('/')}`) {
                if (tag.scrollIntoView) {
                  tag.scrollIntoView();
                }
              }
            });
          }
        } else {
          state.scrollable = false;
        }
      }

      function handleResize() {
        updateNavScroll(true);
      }

      function handleContextMenu(e, item) {
        e.preventDefault();
        contextMenuRoute.value = item;
        state.showDropdown = false;
        nextTick().then(() => {
          state.showDropdown = true;
          state.dropdownX = e.clientX;
          state.dropdownY = e.clientY;
        });
      }

      function onClickOutside() {
        state.showDropdown = false;
      }

      //tags 跳转页面
      function goPage(e) {
        // 拖动滚动结束瞬间不触发跳转
        if (suppressTabClick) return;
        const { fullPath } = e;
        if (fullPath === route.fullPath) return;
        state.activeKey = fullPath;
        go(e, true);
      }

      // ===== 二级导航条：按住左右拖动滚动 + 触控板横向滚动 =====
      let suppressTabClick = false;
      const dragScroll = { active: false, startX: 0, startScroll: 0, moved: false, pointerId: 0 };
      function onTabsPointerDown(e: PointerEvent) {
        if (!navScroll.value || e.button !== 0) return;
        dragScroll.active = true;
        dragScroll.moved = false;
        dragScroll.startX = e.clientX;
        dragScroll.startScroll = navScroll.value.scrollLeft;
        dragScroll.pointerId = e.pointerId;
      }
      function onTabsPointerMove(e: PointerEvent) {
        if (!dragScroll.active || !navScroll.value) return;
        const dx = e.clientX - dragScroll.startX;
        if (!dragScroll.moved && Math.abs(dx) > 5) {
          dragScroll.moved = true;
          try {
            navScroll.value.setPointerCapture(dragScroll.pointerId);
          } catch (err) {
            void err;
          }
        }
        if (dragScroll.moved) navScroll.value.scrollLeft = dragScroll.startScroll - dx;
      }
      function onTabsPointerUp() {
        if (dragScroll.moved) {
          suppressTabClick = true;
          window.setTimeout(() => (suppressTabClick = false), 60);
        }
        dragScroll.active = false;
      }
      function onTabsWheel(e: WheelEvent) {
        if (!navScroll.value) return;
        const delta = Math.abs(e.deltaX) >= Math.abs(e.deltaY) ? e.deltaX : e.deltaY;
        if (!delta) return;
        navScroll.value.scrollLeft += delta;
        e.preventDefault();
      }

      //删除tab
      function closeTabItem(e) {
        const { fullPath } = e;
        const routeInfo = tabsList.value.find((item) => item.fullPath == fullPath);
        removeTab(routeInfo);
      }

      onMounted(() => {
        onElementResize();
      });

      function onElementResize() {
        let observer;
        observer = elementResizeDetectorMaker();
        observer.listenTo(navWrap.value, handleResize);
      }

      // 格式化标题，智能处理包含参数的标题（支持数字、英文、中文等各种格式）
      const getFormattedTitle = (title: unknown, element) => {
        const normalizedTitle = typeof title === 'string' ? title : '';
        if (!normalizedTitle) return '';

        // 正则表达式匹配括号内的各种内容：数字、字母、中文、特殊字符等
        // 支持格式：(123), (abc), (用户名), (abc123), (user_name), (ID:123) 等
        const paramPattern = /\(([^)]+)\)$/;
        const match = normalizedTitle.match(paramPattern);
        let results;

        if (match) {
          // 如果包含参数格式，分离基础标题和参数部分
          const baseTitle = normalizedTitle.replace(paramPattern, '').trim();
          const paramPart = match[0]; // 包含括号的完整参数部分

          // 对基础标题进行国际化翻译，参数部分保持原样
          results = t(baseTitle) + paramPart;
        } else {
          // 如果不包含参数格式，直接进行国际化翻译
          results = t(normalizedTitle);
        }

        const getTagName = element.query?.name || '';
        if (getTagName) {
          results += `(${getTagName})`;
        }

        return results;
      };

      return {
        ...toRefs(state),
        navWrap,
        navScroll,
        route,
        tabsList,
        onDragChange,
        goPage,
        onTabsPointerDown,
        onTabsPointerMove,
        onTabsPointerUp,
        onTabsWheel,
        closeTabItem,
        closeLeft,
        closeRight,
        closeOther,
        closeAll,
        reloadPage,
        getChangeStyle,
        TabsMenuOptions,
        closeHandleSelect,
        scrollNext,
        scrollPrev,
        handleContextMenu,
        onClickOutside,
        themeColor,
        getCardColor,
        getBaseColor,
        getTabsBgColor,
        getFormattedTitle,
        isFavorite,
        isClosableTab,
      };
    },
  });
</script>

<style lang="less" scoped>
  .tabs-view {
    box-sizing: border-box;
    width: 100%;
    display: flex;
    // naive-ui theme vars（由外层 <n-el> 暴露）：卡片底色 + 底部分割线
    background: var(--card-color);
    border-bottom: 1px solid var(--divider-color);
    transition: all 0.2s ease-in-out;
    font-size: 14px;

    &-main {
      height: 32px;
      display: flex;
      max-width: 100%;
      min-width: 100%;

      .tabs-card {
        -webkit-box-flex: 1;
        flex-grow: 1;
        flex-shrink: 1;
        overflow: hidden;
        position: relative;

        .tabs-card-scroll {
          cursor: grab;
          &:active {
            cursor: grabbing;
          }
        }

        .tabs-card-prev,
        .tabs-card-next {
          width: 32px;
          text-align: center;
          position: absolute;
          line-height: 32px;
          cursor: pointer;

          .n-icon {
            display: flex;
            align-items: center;
            justify-content: center;
            height: 32px;
            width: 32px;
          }
        }

        .tabs-card-prev {
          left: 0;
        }

        .tabs-card-next {
          right: 0;
        }

        .tabs-card-next-hide,
        .tabs-card-prev-hide {
          display: none;
        }

        &-scroll {
          white-space: nowrap;
          overflow: hidden;

          &-inner {
            display: flex;
            flex-wrap: nowrap;
          }

          &-item {
            color: v-bind(getBaseColor);
            height: 32px;
            padding: 5px 16px 5px;
            margin-right: 6px;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            position: relative;
            flex: 0 0 auto;
            border-radius: 12px 12px 0 0;
            transition:
              color 0.3s,
              box-shadow 0.3s,
              background-color 0.3s;
            &:before,
            &:after {
              content: '';
              border-radius: 100%;
              width: 20px;
              height: 20px;
              transition: box-shadow 0.3s;
              position: absolute;
              bottom: 0;
              box-shadow: 0 0 0 40px #0000;
            }
            &:before {
              clip-path: inset(50% -10px 0 50%);
              left: -20px;
            }
            &:after {
              clip-path: inset(50% 50% 0 -10px);
              right: -20px;
            }
            &:hover:not(.active-item) {
              background-color: v-bind(themeColor);
              color: v-bind(getCardColor);
            }
            span {
              line-height: 22px;
            }

            .n-icon {
              height: 22px;
              width: 21px;
              margin-right: -6px;
              display: inline-flex;
              align-items: center;
              justify-content: center;
              color: inherit;
              svg {
                height: 21px;
                display: inline-block;
              }
            }

            .n-icon.tabs-card-scroll-item__star {
              width: 14px;
              height: 14px;
              margin-right: 6px;
              margin-left: -2px;
              color: inherit;
            }
          }

          .active-item {
            background: v-bind(themeColor);
            color: var(--n-color);
            &:after,
            &:before {
              box-shadow: 0 30px 0 30px v-bind(themeColor);
            }
            i {
              color: inherit;
              &:hover {
                color: inherit;
              }
            }
          }
        }
      }

      .tabs-card-scrollable {
        padding: 0 32px;
        overflow: hidden;
      }
    }

    .tabs-close {
      min-width: 32px;
      width: 32px;
      height: 32px;
      line-height: 32px;
      text-align: center;
      background: transparent;
      border-radius: 2px;
      cursor: pointer;

      &-btn {
        color: v-bind(getBaseColor);
        height: 100%;
        display: flex;
        align-items: center;
        justify-content: center;
      }
    }
  }

  /* TabsView 固定在 header 下方 */
  .tabs-view-fix {
    position: fixed;
    z-index: 5;
    padding: 6px 10px 0 10px;
    top: 68px;
    left: 0;
    right: 0;
  }
</style>
