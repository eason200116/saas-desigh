/**
 * @description 头部「消息通知」消息类型 → 路由跳转映射。
 *   优先消费后端 §4.4 下发的 DetailAction + RelatedBizId（v2 主路径），未携带时回退到 messageType 硬编码（v1 兜底）。
 *   集中维护避免散落在 NotificationBadge / NotificationDetailModal。
 *   - OpenThirdPayChannelWarningDetail → /report/channel-alert?warningId=<RelatedBizId>&warningType=<字典id>
 *     · warningId：未来支持单条详情唤起（todolist P3-8 follow-up）
 *     · warningType：当前由 channelAlert/index.vue applyQueryWarningType 消费，自动按预警类型筛选 + 搜索；
 *       优先取 messageTypeId（字典 warningTypeList[*].id 单一真值源），后端新增 511 等扩展项零侵入。
 *   - OpenWithdrawOrderDetail          → /finance/withdrawOrder?tab=records&orderId=<RelatedBizId>
 *   - OpenWithdrawUserWorkDetail       → /finance/withdrawOrder?tab=workbench&userId=<RelatedBizId>
 *   - 未匹配 → 按 messageType 兜底；仍未匹配返回 null，UI 隐藏跳转按钮。
 * @date 2026-05-02
 * @author fifty-nine
 * @scope NotificationBadge.vue / NotificationDetailModal.vue
 */
import type { RouteLocationRaw } from 'vue-router';
import {
  MESSAGE_TYPE_STRING_TO_NUMBER,
  type NotificationDetailAction,
  type NotificationItem,
  type NotificationType,
} from '@/store/modules/notification';

// ============================================================================
// v2 主路径：DetailAction + RelatedBizId（推荐）
// ============================================================================

function buildChannelAlertRoute(item: NotificationItem): RouteLocationRaw {
  // 优先用字典 id（item.messageTypeId）— 覆盖后端任意编号（含 511 通道自动关闭等扩展项），
  // 让目标页 applyQueryWarningType 直接按字典 id 筛选；
  // 字典 id 缺失（v1 仅推字符串 messageType 的历史路径）时，回落 MESSAGE_TYPE_STRING_TO_NUMBER 反查。
  const warningTypeNumber =
    item.messageTypeId ??
    (item.messageType ? MESSAGE_TYPE_STRING_TO_NUMBER[item.messageType] : undefined);
  const warningId = item.relatedBizId;
  const query: Record<string, string> = {};
  if (warningId) query.warningId = warningId;
  if (warningTypeNumber != null) query.warningType = String(warningTypeNumber);
  return {
    name: 'report_channel_alert',
    query: Object.keys(query).length ? query : undefined,
  };
}

/** DetailAction → route builder 表，由后端字段驱动 */
const ACTION_ROUTE_MAP: Record<
  NotificationDetailAction,
  (item: NotificationItem) => RouteLocationRaw
> = {
  OpenThirdPayChannelWarningDetail: (item) => buildChannelAlertRoute(item),
  OpenWithdrawOrderDetail: (item) => ({
    name: 'finance_withdraw_order_page',
    query: { tab: 'records', ...(item.relatedBizId ? { orderId: item.relatedBizId } : {}) },
  }),
  OpenWithdrawUserWorkDetail: (item) => ({
    name: 'finance_withdraw_order_page',
    query: { tab: 'workbench', ...(item.relatedBizId ? { userId: item.relatedBizId } : {}) },
  }),
};

// ============================================================================
// v1 兜底：messageType 硬编码（DetailAction 未上线时使用）
// ============================================================================

/**
 * 通道预警分类（V3 §1 WarningCategoryTypeMap[1]）：
 *   501 失败率 / 502 拉单失败 / 503 余额不足 / 504 大额出款
 * 这 4 类站内信点「查看详情」一律跳 channel-alert 列表页，
 * 由目标页 applyQueryWarningType 按 ?warningType=<num> 筛选 + 自动搜索。
 */
const CHANNEL_ALERT_TYPES: NotificationType[] = [
  'DEPOSIT_CHANNEL_FAILURE_RATE_WARNING',
  'DEPOSIT_CHANNEL_PULL_FAILURE_WARNING',
  'WITHDRAW_CHANNEL_BALANCE_WARNING',
  'LARGE_WITHDRAW_WARNING',
];

/** 出款 dashboard 业务异常类（V3 6xx 段及编号待补）：暂停 / 超审 / 池上限 */
const WITHDRAW_DASHBOARD_TYPES: NotificationType[] = [
  'USER_SUSPEND_TIMEOUT',
  'USER_AUDIT_TIMEOUT',
  'ORDER_AUDIT_TIMEOUT',
  'ORDER_POOL_LIMIT',
];

/** 工单转派（出款 workbench 处理） */
const WITHDRAW_WORKBENCH_TYPES: NotificationType[] = ['WITHDRAW_ORDER_TRANSFER'];

function resolveByMessageType(item: NotificationItem): RouteLocationRaw | null {
  // messageType 为 null 表示数字 id 不在前端已收录的 NotificationType 集里（如后端扩展的新编号）。
  // 此时既无字符串语义可走 v1 兜底跳转，也不应该误判到任何已知类型——直接返回 null，UI 隐藏跳转按钮。
  if (!item.messageType) return null;
  const orderId = typeof item.extData?.orderId === 'string' ? item.extData.orderId : undefined;

  if (CHANNEL_ALERT_TYPES.includes(item.messageType)) {
    const warningTypeNumber = MESSAGE_TYPE_STRING_TO_NUMBER[item.messageType];
    const query: Record<string, string> = {};
    if (orderId) query.warningId = orderId;
    if (warningTypeNumber != null) query.warningType = String(warningTypeNumber);
    return {
      name: 'report_channel_alert',
      query: Object.keys(query).length ? query : undefined,
    };
  }

  if (WITHDRAW_DASHBOARD_TYPES.includes(item.messageType)) {
    const warningTypeNumber = MESSAGE_TYPE_STRING_TO_NUMBER[item.messageType];
    // 不显式写 tab / sub：dashboard 同时是外层主 tab 与内层子 tab 的默认值。
    // vue-router 全量替换 query 后，外/内层 useTabQuery 各自 watch route.query[key]
    // 看到 undefined → next=defaultTab='dashboard' → activeTab 不是默认值时切回；
    // 已是默认值时不触发 updateQuery，地址栏自然只剩 ?warningType=xxx。
    // 反之若显式写 tab='dashboard'，当前 activeTab 已是默认值时 updateQuery 不触发清理，
    // URL 会残留 tab=dashboard，与用户期望的纯净 URL 不符。
    const query: Record<string, string> = {};
    if (warningTypeNumber != null) query.warningType = String(warningTypeNumber);
    if (orderId) query.orderId = orderId;
    return {
      name: 'finance_withdraw_order_page',
      query: Object.keys(query).length ? query : undefined,
    };
  }

  if (WITHDRAW_WORKBENCH_TYPES.includes(item.messageType)) {
    return {
      name: 'finance_withdraw_order_page',
      query: { tab: 'workbench', ...(orderId ? { orderId } : {}) },
    };
  }

  return null;
}

// ============================================================================
// 公共解析入口
// ============================================================================

/**
 * 解析单条通知到 RouteLocationRaw。
 * 优先级：DetailAction (v2) > messageType (v1 兜底) > null
 */
export function resolveNotificationRoute(item: NotificationItem): RouteLocationRaw | null {
  // v2 优先：后端下发了 DetailAction 就按 action 决策
  if (item.detailAction && ACTION_ROUTE_MAP[item.detailAction]) {
    return ACTION_ROUTE_MAP[item.detailAction](item);
  }
  // v1 兜底
  return resolveByMessageType(item);
}

/** 是否有可跳转目标（用于 UI 决定按钮显隐） */
export function hasNotificationRoute(item: NotificationItem): boolean {
  return resolveNotificationRoute(item) !== null;
}
