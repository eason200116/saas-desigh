/**
 * @description 应用启动入口：按顺序完成 i18n 预热 → 创建应用 → 注入状态/UI/指令/路由，最终 mount。i18n.setupI18n 的 await 必须在 createApp 之前，保证首屏渲染时消息已就位，避免闪现 key 原文。
 * @author
 * @date 2026-04-21
 * @scope 仅本文件为 Vite HTML 入口消费
 */
import { createApp } from 'vue';
import { setupNaiveDiscreteApi, setupNaive, setupDirectives } from '@/plugins';
import App from './App.vue';
import router, { setupRouter } from './router';
import { setupStore } from '@/store';
import { i18n, setupI18n } from '@/i18n';
import './styles/index.less';
import './styles/tailwind.css';

async function bootstrap() {
  // 先预热首屏语言，确保 App 首次渲染时 messages 不为空
  await setupI18n();

  const app = createApp(App);

  // 国际化
  app.use(i18n);

  // 挂载状态管理
  setupStore(app);

  // 注册全局常用的 naive-ui 组件
  setupNaive(app);

  // 挂载 naive-ui 脱离上下文的 Api
  setupNaiveDiscreteApi();

  // 注册全局自定义指令，如：v-permission权限指令
  setupDirectives(app);

  // 挂载路由
  setupRouter(app);
  await router.isReady();

  app.mount('#app', true);
}

void bootstrap();

// 仅开发环境：内置可视化「编辑模式」浮层（生产构建 import.meta.env.DEV=false，本分支被摇树删除，绝不进线上）
if (import.meta.env.DEV) {
  // 左下角「✎ 编辑」可视化编辑器已隐藏（2026-07-23 用户定：改用右键菜单内联编辑，见下方 contextMenu）。
  // 文件保留、未删除，如需恢复取消下一行注释即可。
  // void import('@/dev/pageEditor');
  void import('@/dev/contextMenu').then((m) => m.mountDevContextMenu());
}
