import type {
  ProjectAppearanceSetting,
  ProjectGeneralSetting,
  ProjectLayoutSetting,
  ProjectThemePresetKey as ProjectPresetKey,
} from '/#/config';
import { themeConfig } from '@/hooks/setting';

/**
 * 主题预设快照。
 */
export interface ThemePresetSnapshot {
  label: string;
  description: string;
  appearance: Partial<ProjectAppearanceSetting>;
  layout: Partial<ProjectLayoutSetting>;
  general: Partial<ProjectGeneralSetting>;
}

/**
 * 项目主题预设映射。
 *
 * @description
 * 预设实现参考   Admin 的“预设切换 + 局部锁定”模型，
 * 但保持当前后台的导航与品牌默认值不变。
 */
export const themePresetMap: Record<ProjectPresetKey, ThemePresetSnapshot> = {
  'ar-default': {
    label: 'AR 默认',
    description: '保留当前后台的深色顶栏与标准密度，适合作为基础主题。',
    appearance: {
      themeColor: themeConfig.defaultThemeColor,
      themeScheme: 'light',
      compactMode: false,
      borderRadius: 8,
    },
    layout: {
      navigationMode: 'horizontal',
      navigationTheme: 'dark',
      mixMenu: false,
      menuWidth: 240,
    },
    general: {
      showTabs: true,
      fixedTabs: true,
      showReload: true,
      showBreadcrumb: true,
      showBreadcrumbIcon: false,
    },
  },
  'soybean-classic': {
    label: '经典',
    description: '对齐   Admin 的常规桌面后台体验，强调浅色导航与清晰层级。',
    appearance: {
      themeColor: '#5a47ff',
      themeScheme: 'light',
      compactMode: false,
      borderRadius: 10,
    },
    layout: {
      navigationMode: 'vertical',
      navigationTheme: 'light',
      mixMenu: false,
      menuWidth: 220,
    },
    general: {
      showTabs: true,
      fixedTabs: true,
      showReload: true,
      showBreadcrumb: true,
      showBreadcrumbIcon: true,
    },
  },
  'soybean-compact': {
    label: '紧凑',
    description: '适合高信息密度场景，缩小间距并保持浅色导航结构。',
    appearance: {
      themeColor: '#6366f1',
      themeScheme: 'light',
      compactMode: true,
      borderRadius: 6,
    },
    layout: {
      navigationMode: 'vertical',
      navigationTheme: 'light',
      mixMenu: true,
      menuWidth: 208,
    },
    general: {
      showTabs: true,
      fixedTabs: false,
      showReload: true,
      showBreadcrumb: true,
      showBreadcrumbIcon: false,
    },
  },
};

/**
 * 获取主题预设。
 *
 * @param presetKey 预设 Key
 * @returns 主题预设快照
 */
export function getThemePreset(presetKey: ProjectPresetKey) {
  return themePresetMap[presetKey];
}
