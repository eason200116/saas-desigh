import type { ProjectNavigationTheme } from '/#/config';
import type { ResolveThemeInput, ResolvedTheme } from './types';

function normalizeNavigationTheme(value: string): ProjectNavigationTheme {
  return value === 'light' ? 'light' : 'dark';
}

function resolveColorMode(
  scheme: ResolveThemeInput['appearance']['themeScheme'],
  systemPrefersDark: boolean,
): ResolvedTheme['colorMode'] {
  if (scheme === 'auto') {
    return systemPrefersDark ? 'dark' : 'light';
  }

  return scheme === 'dark' ? 'dark' : 'light';
}

export function resolveTheme({
  appearance,
  layout,
  systemPrefersDark,
}: ResolveThemeInput): ResolvedTheme {
  return {
    colorMode: resolveColorMode(appearance.themeScheme, systemPrefersDark),
    requestedScheme: appearance.themeScheme,
    themeColor: appearance.themeColor,
    borderRadius: appearance.borderRadius,
    compactMode: appearance.compactMode,
    navigationTheme: normalizeNavigationTheme(layout.navigationTheme),
  };
}
