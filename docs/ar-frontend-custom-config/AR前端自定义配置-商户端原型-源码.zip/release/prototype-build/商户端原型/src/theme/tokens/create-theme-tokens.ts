import { normalizeHexColor } from '@/components/Brand/theme';
import type { ResolvedTheme } from '../runtime/types';

export type ThemeTokenMap = Record<`--${string}`, string>;

export interface ThemeTokens {
  atomic: ThemeTokenMap;
  semantic: ThemeTokenMap;
  all: ThemeTokenMap;
}

const neutralScale = {
  0: '#ffffff',
  50: '#f8fafc',
  100: '#f1f5f9',
  200: '#e5e7eb',
  300: '#d1d5db',
  400: '#9ca3af',
  500: '#6b7280',
  600: '#475569',
  700: '#374151',
  800: '#1f2937',
  900: '#111827',
  950: '#0f172a',
} as const;

const successScale = {
  100: '#dcfce7',
  500: '#18a058',
  600: '#15803d',
} as const;

const warningScale = {
  100: '#fef3c7',
  500: '#f0a020',
  600: '#d97706',
} as const;

const errorScale = {
  100: '#fee2e2',
  500: '#d03050',
  600: '#b91c1c',
} as const;

const spaceScale = {
  0: '0px',
  1: '4px',
  2: '8px',
  3: '12px',
  4: '16px',
  5: '20px',
  6: '24px',
  8: '32px',
  10: '40px',
  12: '48px',
} as const;

const fontSizeScale = {
  12: '12px',
  13: '13px',
  14: '14px',
  16: '16px',
  18: '18px',
  20: '20px',
  24: '24px',
} as const;

const lineHeightScale = {
  16: '16px',
  18: '18px',
  20: '20px',
  22: '22px',
  24: '24px',
  28: '28px',
  32: '32px',
} as const;

const shadowScale = {
  none: 'none',
  xs: '0 1px 2px rgb(0 0 0 / 0.03)',
  sm: '0 1px 2px rgb(0 0 0 / 0.08)',
  md: '0 8px 24px rgb(0 0 0 / 0.12)',
  lg: '0 16px 40px rgb(0 0 0 / 0.16)',
} as const;

const zScale = {
  base: '0',
  sticky: '100',
  dropdown: '300',
  overlay: '500',
  modal: '1000',
  toast: '1100',
} as const;

const motionScale = {
  fast: '120ms',
  normal: '180ms',
  slow: '240ms',
  'ease-standard': 'cubic-bezier(0.2, 0, 0, 1)',
  'ease-emphasized': 'cubic-bezier(0.2, 0, 0, 1.2)',
  'ease-linear': 'linear',
} as const;

function hexToRgb(hexColor: string) {
  const hex = normalizeHexColor(hexColor).slice(1);

  return {
    r: parseInt(hex.slice(0, 2), 16),
    g: parseInt(hex.slice(2, 4), 16),
    b: parseInt(hex.slice(4, 6), 16),
  };
}

function mixHex(primary: string, secondary: string, secondaryWeight: number) {
  const weight = Math.max(0, Math.min(1, secondaryWeight));
  const first = hexToRgb(primary);
  const second = hexToRgb(secondary);
  const channels = ['r', 'g', 'b'] as const;

  return `#${channels
    .map((channel) =>
      Math.round(first[channel] * (1 - weight) + second[channel] * weight)
        .toString(16)
        .padStart(2, '0'),
    )
    .join('')}`;
}

function toAlphaColor(hexColor: string, alpha: number) {
  const { r, g, b } = hexToRgb(hexColor);
  return `rgba(${r}, ${g}, ${b}, ${alpha})`;
}

function createBrandScale(themeColor: string) {
  const primary = normalizeHexColor(themeColor);

  return {
    50: mixHex(primary, '#ffffff', 0.9),
    100: mixHex(primary, '#ffffff', 0.82),
    200: mixHex(primary, '#ffffff', 0.68),
    300: mixHex(primary, '#ffffff', 0.5),
    400: mixHex(primary, '#ffffff', 0.18),
    500: primary,
    600: mixHex(primary, '#000000', 0.12),
    700: mixHex(primary, '#000000', 0.2),
    800: mixHex(primary, '#000000', 0.28),
    900: mixHex(primary, '#000000', 0.36),
  } as const;
}

function createAtomicTokens(resolvedTheme: ResolvedTheme): ThemeTokenMap {
  const brandScale = createBrandScale(resolvedTheme.themeColor);

  return {
    '--color-brand-50': brandScale[50],
    '--color-brand-100': brandScale[100],
    '--color-brand-200': brandScale[200],
    '--color-brand-300': brandScale[300],
    '--color-brand-400': brandScale[400],
    '--color-brand-500': brandScale[500],
    '--color-brand-600': brandScale[600],
    '--color-brand-700': brandScale[700],
    '--color-brand-800': brandScale[800],
    '--color-brand-900': brandScale[900],
    '--color-brand-alpha-08': toAlphaColor(brandScale[500], 0.08),
    '--color-brand-alpha-12': toAlphaColor(brandScale[500], 0.12),
    '--color-brand-alpha-16': toAlphaColor(brandScale[500], 0.16),
    '--color-brand-alpha-20': toAlphaColor(brandScale[500], 0.2),
    '--color-brand-alpha-24': toAlphaColor(brandScale[500], 0.24),
    '--color-neutral-0': neutralScale[0],
    '--color-neutral-50': neutralScale[50],
    '--color-neutral-100': neutralScale[100],
    '--color-neutral-200': neutralScale[200],
    '--color-neutral-300': neutralScale[300],
    '--color-neutral-400': neutralScale[400],
    '--color-neutral-500': neutralScale[500],
    '--color-neutral-600': neutralScale[600],
    '--color-neutral-700': neutralScale[700],
    '--color-neutral-800': neutralScale[800],
    '--color-neutral-900': neutralScale[900],
    '--color-neutral-950': neutralScale[950],
    '--color-success-100': successScale[100],
    '--color-success-500': successScale[500],
    '--color-success-600': successScale[600],
    '--color-warning-100': warningScale[100],
    '--color-warning-500': warningScale[500],
    '--color-warning-600': warningScale[600],
    '--color-error-100': errorScale[100],
    '--color-error-500': errorScale[500],
    '--color-error-600': errorScale[600],
    '--color-info-100': brandScale[100],
    '--color-info-500': brandScale[500],
    '--color-info-600': brandScale[600],
    '--space-0': spaceScale[0],
    '--space-1': spaceScale[1],
    '--space-2': spaceScale[2],
    '--space-3': spaceScale[3],
    '--space-4': spaceScale[4],
    '--space-5': spaceScale[5],
    '--space-6': spaceScale[6],
    '--space-8': spaceScale[8],
    '--space-10': spaceScale[10],
    '--space-12': spaceScale[12],
    '--font-size-12': fontSizeScale[12],
    '--font-size-13': fontSizeScale[13],
    '--font-size-14': fontSizeScale[14],
    '--font-size-16': fontSizeScale[16],
    '--font-size-18': fontSizeScale[18],
    '--font-size-20': fontSizeScale[20],
    '--font-size-24': fontSizeScale[24],
    '--line-height-16': lineHeightScale[16],
    '--line-height-18': lineHeightScale[18],
    '--line-height-20': lineHeightScale[20],
    '--line-height-22': lineHeightScale[22],
    '--line-height-24': lineHeightScale[24],
    '--line-height-28': lineHeightScale[28],
    '--line-height-32': lineHeightScale[32],
    '--radius-none': '0px',
    '--radius-xs': '2px',
    '--radius-sm': '4px',
    '--radius-md': `${resolvedTheme.borderRadius}px`,
    '--radius-lg': `${resolvedTheme.borderRadius + 2}px`,
    '--radius-xl': `${resolvedTheme.borderRadius + 4}px`,
    '--radius-full': '9999px',
    '--shadow-none': shadowScale.none,
    '--shadow-xs': shadowScale.xs,
    '--shadow-sm': shadowScale.sm,
    '--shadow-md': shadowScale.md,
    '--shadow-lg': shadowScale.lg,
    '--z-base': zScale.base,
    '--z-sticky': zScale.sticky,
    '--z-dropdown': zScale.dropdown,
    '--z-overlay': zScale.overlay,
    '--z-modal': zScale.modal,
    '--z-toast': zScale.toast,
    '--motion-fast': motionScale.fast,
    '--motion-normal': motionScale.normal,
    '--motion-slow': motionScale.slow,
    '--motion-ease-standard': motionScale['ease-standard'],
    '--motion-ease-emphasized': motionScale['ease-emphasized'],
    '--motion-ease-linear': motionScale['ease-linear'],
  };
}

function createSemanticTokens(
  resolvedTheme: ResolvedTheme,
  atomicTokens: ThemeTokenMap,
): ThemeTokenMap {
  const isDark = resolvedTheme.colorMode === 'dark';

  return {
    '--ui-accent-solid': atomicTokens['--color-brand-500'],
    '--ui-accent-hover': atomicTokens['--color-brand-400'],
    '--ui-accent-pressed': atomicTokens['--color-brand-600'],
    '--ui-accent-soft': isDark
      ? atomicTokens['--color-brand-alpha-12']
      : atomicTokens['--color-brand-alpha-08'],
    '--ui-accent-soft-hover': isDark
      ? atomicTokens['--color-brand-alpha-16']
      : atomicTokens['--color-brand-alpha-12'],
    '--ui-accent-text': isDark
      ? atomicTokens['--color-brand-400']
      : atomicTokens['--color-brand-500'],
    '--ui-focus-ring': isDark
      ? atomicTokens['--color-brand-alpha-24']
      : atomicTokens['--color-brand-alpha-20'],
    '--ui-success-solid': atomicTokens['--color-success-500'],
    '--ui-success-soft': atomicTokens['--color-success-100'],
    '--ui-warning-solid': atomicTokens['--color-warning-500'],
    '--ui-warning-soft': atomicTokens['--color-warning-100'],
    '--ui-danger-solid': atomicTokens['--color-error-500'],
    '--ui-danger-soft': atomicTokens['--color-error-100'],
    '--ui-info-solid': atomicTokens['--color-info-500'],
    '--ui-info-soft': atomicTokens['--color-info-100'],
    '--ui-bg-page': isDark
      ? atomicTokens['--color-neutral-950']
      : atomicTokens['--color-neutral-50'],
    '--ui-bg-page-elevated': isDark
      ? atomicTokens['--color-neutral-900']
      : atomicTokens['--color-neutral-100'],
    '--ui-bg-card': isDark
      ? atomicTokens['--color-neutral-900']
      : atomicTokens['--color-neutral-0'],
    '--ui-bg-card-elevated': isDark
      ? atomicTokens['--color-neutral-800']
      : atomicTokens['--color-neutral-0'],
    '--ui-bg-modal': isDark
      ? atomicTokens['--color-neutral-900']
      : atomicTokens['--color-neutral-0'],
    '--ui-bg-popover': isDark
      ? atomicTokens['--color-neutral-800']
      : atomicTokens['--color-neutral-0'],
    '--ui-bg-overlay': isDark ? 'rgb(15 23 42 / 0.6)' : 'rgb(15 23 42 / 0.45)',
    '--ui-text-primary': isDark ? 'rgb(255 255 255 / 0.88)' : atomicTokens['--color-neutral-900'],
    '--ui-text-secondary': isDark ? 'rgb(255 255 255 / 0.82)' : atomicTokens['--color-neutral-700'],
    '--ui-text-tertiary': isDark ? 'rgb(255 255 255 / 0.68)' : atomicTokens['--color-neutral-500'],
    '--ui-text-disabled': isDark ? 'rgb(255 255 255 / 0.38)' : atomicTokens['--color-neutral-400'],
    '--ui-text-inverse': atomicTokens['--color-neutral-0'],
    '--ui-text-link': isDark
      ? atomicTokens['--color-brand-400']
      : atomicTokens['--color-brand-500'],
    '--ui-text-on-accent': atomicTokens['--color-neutral-0'],
    '--ui-border-default': isDark ? 'rgb(255 255 255 / 0.12)' : atomicTokens['--color-neutral-200'],
    '--ui-border-strong': isDark ? 'rgb(255 255 255 / 0.18)' : atomicTokens['--color-neutral-300'],
    '--ui-border-focus': atomicTokens['--color-brand-500'],
    '--ui-divider': isDark ? 'rgb(255 255 255 / 0.08)' : atomicTokens['--color-neutral-200'],
    '--ui-fill-hover': isDark ? 'rgb(255 255 255 / 0.06)' : '#f3f6fb',
    '--ui-fill-active': isDark
      ? atomicTokens['--color-brand-alpha-16']
      : atomicTokens['--color-brand-alpha-12'],
    '--ui-fill-selected': isDark
      ? atomicTokens['--color-brand-alpha-12']
      : atomicTokens['--color-brand-alpha-08'],
    '--ui-fill-disabled': isDark ? 'rgb(255 255 255 / 0.04)' : atomicTokens['--color-neutral-100'],
    '--ui-control-bg': isDark
      ? atomicTokens['--color-neutral-900']
      : atomicTokens['--color-neutral-0'],
    '--ui-control-border': isDark ? 'rgb(255 255 255 / 0.12)' : atomicTokens['--color-neutral-300'],
    '--ui-control-border-focus': atomicTokens['--color-brand-500'],
    '--ui-control-placeholder': isDark
      ? 'rgb(255 255 255 / 0.38)'
      : atomicTokens['--color-neutral-400'],
    '--ui-control-text': isDark ? 'rgb(255 255 255 / 0.88)' : atomicTokens['--color-neutral-900'],
    '--ui-radius-control': atomicTokens['--radius-md'],
    '--ui-radius-card': atomicTokens['--radius-lg'],
    '--ui-radius-modal': atomicTokens['--radius-lg'],
    '--ui-shadow-card': atomicTokens['--shadow-xs'],
    '--ui-shadow-popover': atomicTokens['--shadow-md'],
    '--ui-shadow-modal': atomicTokens['--shadow-lg'],
  };
}

export function createThemeTokens(resolvedTheme: ResolvedTheme): ThemeTokens {
  const atomic = createAtomicTokens(resolvedTheme);
  const semantic = createSemanticTokens(resolvedTheme, atomic);

  return {
    atomic,
    semantic,
    all: {
      ...atomic,
      ...semantic,
    },
  };
}
