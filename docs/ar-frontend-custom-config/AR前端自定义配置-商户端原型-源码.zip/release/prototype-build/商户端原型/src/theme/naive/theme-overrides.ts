import type { GlobalThemeOverrides } from 'naive-ui';
import type { ProjectLayoutSetting } from '/#/config';
import type { ResolvedTheme } from '@/theme/runtime/types';
import type { ThemeTokenMap } from '@/theme/tokens';

interface CreateNaiveThemeOverridesInput {
  resolvedTheme: ResolvedTheme;
  semanticTokens: ThemeTokenMap;
  layoutSetting: ProjectLayoutSetting;
}

/**
 * 创建 Naive UI 全局主题覆盖。
 *
 * @param appearanceSetting 外观配置
 * @param layoutSetting 布局配置
 * @returns Naive UI 全局主题覆盖对象
 */
export function createNaiveThemeOverrides(
  input: CreateNaiveThemeOverridesInput,
): GlobalThemeOverrides {
  const { resolvedTheme, semanticTokens, layoutSetting } = input;
  const isDark = resolvedTheme.colorMode === 'dark';
  const navigationThemeIsDark = layoutSetting.navigationTheme === 'dark';
  const radius = semanticTokens['--ui-radius-control'];
  const radiusLg = semanticTokens['--ui-radius-card'];
  const primaryColor = semanticTokens['--ui-accent-solid'];
  const primaryColorHover = semanticTokens['--ui-accent-hover'];
  const primaryColorPressed = semanticTokens['--ui-accent-pressed'];

  return {
    common: {
      primaryColor,
      primaryColorHover,
      primaryColorPressed,
      primaryColorSuppl: primaryColor,
      infoColor: semanticTokens['--ui-info-solid'],
      infoColorHover: primaryColorHover,
      infoColorPressed: primaryColorPressed,
      infoColorSuppl: semanticTokens['--ui-info-solid'],
      successColor: semanticTokens['--ui-success-solid'],
      warningColor: semanticTokens['--ui-warning-solid'],
      errorColor: semanticTokens['--ui-danger-solid'],
      borderRadius: radius,
      // 高度缩紧
      heightSmall: '26px',
      heightMedium: '30px',
      heightLarge: '34px',
      fontSizeSmall: '13px',
      fontSizeMedium: '13px',
      bodyColor: semanticTokens['--ui-bg-page'],
      cardColor: semanticTokens['--ui-bg-card'],
      modalColor: semanticTokens['--ui-bg-modal'],
      popoverColor: semanticTokens['--ui-bg-popover'],
      tableColor: semanticTokens['--ui-bg-card'],
      actionColor: isDark ? '#2A2A2A' : '#f5f7fa',
      hoverColor: semanticTokens['--ui-fill-hover'],
      borderColor: semanticTokens['--ui-border-default'],
      textColorBase: semanticTokens['--ui-text-primary'],
      textColor1: semanticTokens['--ui-text-primary'],
      textColor2: semanticTokens['--ui-text-secondary'],
      textColor3: semanticTokens['--ui-text-tertiary'],
      dividerColor: semanticTokens['--ui-divider'],
      scrollbarColor: isDark ? 'rgba(255,255,255,0.2)' : 'rgba(31, 41, 55, 0.18)',
    },
    Layout: {
      // siderColor 保持单色（Naive UI token 不接受 gradient）；
      // 深色渐变质感在 layout/index.vue 的非 scoped 样式里走 CSS background 覆盖
      siderColor: navigationThemeIsDark ? '#0f172a' : '#ffffff',
      headerColor: navigationThemeIsDark ? '#0f172a' : '#ffffff',
      contentColor: semanticTokens['--ui-bg-page'],
      footerColor: semanticTokens['--ui-bg-card'],
      siderBorderColor: navigationThemeIsDark ? 'rgba(255,255,255,0.08)' : '#e5e7eb',
      headerBorderColor: semanticTokens['--ui-border-default'],
    },
    Menu: {
      fontSize: '13px',
      itemHeight: '38px',
      itemTextColor: navigationThemeIsDark ? 'rgba(255,255,255,0.78)' : '#334155',
      itemTextColorActive: primaryColor,
      itemTextColorHover: primaryColorHover,
      itemTextColorChildActive: primaryColor,
      itemColorHover: navigationThemeIsDark ? 'rgba(255,255,255,0.06)' : '#eef2ff',
      itemColorActive: navigationThemeIsDark ? `${primaryColor}2e` : '#eef2ff',
      itemIconColor: navigationThemeIsDark ? 'rgba(255,255,255,0.7)' : '#64748b',
      itemIconColorActive: primaryColor,
      itemIconColorHover: primaryColorHover,
      arrowColor: navigationThemeIsDark ? 'rgba(255,255,255,0.62)' : '#64748b',
      arrowColorHover: primaryColorHover,
      arrowColorActive: primaryColor,
      borderRadius: radius,
      // Inverted 模式（深色侧边栏）
      itemTextColorInverted: 'rgba(255,255,255,0.82)',
      itemTextColorHoverInverted: '#ffffff',
      itemTextColorActiveInverted: '#ffffff',
      itemIconColorInverted: 'rgba(255,255,255,0.82)',
      itemIconColorHoverInverted: '#ffffff',
      itemIconColorActiveInverted: '#ffffff',
      itemColorHoverInverted: 'rgba(255,255,255,0.08)',
      itemColorActiveInverted: primaryColor,
      arrowColorInverted: 'rgba(255,255,255,0.52)',
      arrowColorHoverInverted: '#ffffff',
      arrowColorActiveInverted: '#ffffff',
    },
    LoadingBar: {
      colorLoading: primaryColor,
    },
    Scrollbar: {
      height: '10px',
      width: '8px',
    },
    Tag: {
      borderRadius: radius,
    },
    Tabs: {
      tabColor: isDark ? '#1f2937' : '#ffffff',
      tabColorActive: primaryColor,
      tabTextColorActive: '#ffffff',
      paneTextColor: semanticTokens['--ui-text-secondary'],
      tabBorderRadius: radius,
    },
    Button: {
      borderRadius: radius,
      borderRadiusTiny: radius,
      borderRadiusSmall: radius,
      borderRadiusMedium: radius,
      borderRadiusLarge: radiusLg,
      textColorPrimary: '#ffffff',
      textColorHoverPrimary: '#ffffff',
      textColorPressedPrimary: '#ffffff',
    },
    Card: {
      borderRadius: radius,
      color: semanticTokens['--ui-bg-card'],
      borderColor: semanticTokens['--ui-border-default'],
    },
    Input: {
      borderRadius: radius,
      color: isDark ? '#111827' : '#ffffff',
      colorFocus: isDark ? '#0b1220' : '#ffffff',
      border: `1px solid ${semanticTokens['--ui-control-border']}`,
      borderHover: `1px solid ${primaryColorHover}`,
      borderFocus: `1px solid ${semanticTokens['--ui-control-border-focus']}`,
      caretColor: primaryColor,
      placeholderColor: isDark ? 'rgba(255,255,255,0.38)' : '#9ca3af',
    },
    Select: {
      peers: {
        InternalSelection: {
          borderRadius: radius,
          color: isDark ? '#111827' : '#ffffff',
          border: `1px solid ${semanticTokens['--ui-control-border']}`,
          borderHover: `1px solid ${primaryColorHover}`,
          borderActive: `1px solid ${semanticTokens['--ui-control-border-focus']}`,
        },
      },
    },
    Dialog: {
      borderRadius: radius,
      color: semanticTokens['--ui-bg-modal'],
      titleTextColor: semanticTokens['--ui-text-primary'],
      textColor: semanticTokens['--ui-text-secondary'],
      iconColorInfo: semanticTokens['--ui-info-solid'],
    },
    Drawer: {
      color: semanticTokens['--ui-bg-modal'],
      borderRadius: radius,
    },
    Notification: {
      color: semanticTokens['--ui-bg-card'],
      titleTextColor: semanticTokens['--ui-text-primary'],
      textColor: semanticTokens['--ui-text-secondary'],
      borderRadius: radius,
    },
    Message: {
      borderRadius: radius,
      colorInfo: isDark ? '#1f2937' : '#ffffff',
      textColorInfo: semanticTokens['--ui-text-primary'],
    },
    DataTable: {
      borderColor: semanticTokens['--ui-border-default'],
      tdColor: semanticTokens['--ui-bg-card'],
      tdColorHover: isDark ? '#202734' : '#f8fafc',
      thColor: isDark ? '#18212f' : '#f8fafc',
      thTextColor: semanticTokens['--ui-text-primary'],
      tdTextColor: semanticTokens['--ui-text-secondary'],
      borderRadius: radius,
    },
    Switch: {
      railColorActive: primaryColor,
      buttonColor: '#ffffff',
    },
    Slider: {
      fillColor: primaryColor,
      fillColorHover: primaryColorHover,
    },
  };
}
