import type { GlobalThemeComponentOptions } from 'naive-ui';

/**
 * Naive UI 全局组件默认配置。
 *
 * @description
 * 统一维护全局组件的尺寸、圆角和样式偏好，避免主题逻辑散落在页面入口中。
 */
export const componentOptions: GlobalThemeComponentOptions = {
  Input: {
    size: 'medium',
    round: true,
  },
  Select: {
    size: 'medium',
  },
  Button: {
    size: 'medium',
    round: true,
  },
  Card: {
    embedded: true,
  },
};
