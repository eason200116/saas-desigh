import type {
  ProjectAppearanceSetting,
  ProjectLayoutSetting,
  ProjectNavigationTheme,
  ProjectThemeScheme,
} from '/#/config';

export interface ResolveThemeInput {
  appearance: ProjectAppearanceSetting;
  layout: ProjectLayoutSetting;
  systemPrefersDark: boolean;
}

export interface ResolvedTheme {
  colorMode: 'light' | 'dark';
  requestedScheme: ProjectThemeScheme;
  themeColor: string;
  borderRadius: number;
  compactMode: boolean;
  navigationTheme: ProjectNavigationTheme;
}
