import type { ThemeTokenMap, ThemeTokens } from '@/theme/tokens';

/**
 * 主题桥接 CSS 变量集合。
 *
 * 说明：
 * - `themeTokens.all` 提供正式 `--ui-*` / `--color-*` / `--radius-*` 等 token
 * - 当前不再额外输出 `--app-*` / `--primary-*` 兼容桥
 */
export type ThemeCssVars = ThemeTokenMap;

export function createThemeCssVarsFromTokens(themeTokens: ThemeTokens): ThemeCssVars {
  return themeTokens.all;
}
