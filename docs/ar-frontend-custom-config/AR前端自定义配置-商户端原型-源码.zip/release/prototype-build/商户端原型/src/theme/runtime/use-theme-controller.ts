import { usePreferredDark } from '@vueuse/core';
import { computed, watchEffect, type ComputedRef, type Ref } from 'vue';
import type {
  ProjectAppearanceSetting,
  ProjectGeneralSetting,
  ProjectLayoutSetting,
} from '/#/config';
import { syncDynamicFavicon } from '@/components/Brand/favicon';
import { createThemeCssVarsFromTokens } from '@/theme/naive/css-vars';
import { createNaiveThemeOverrides } from '@/theme/naive/theme-overrides';
import { createThemeTokens } from '@/theme/tokens';
import { resolveTheme } from './resolve-theme';

interface UseThemeControllerInput {
  appearance: Ref<ProjectAppearanceSetting> | ComputedRef<ProjectAppearanceSetting>;
  layout: Ref<ProjectLayoutSetting> | ComputedRef<ProjectLayoutSetting>;
  general: Ref<ProjectGeneralSetting> | ComputedRef<ProjectGeneralSetting>;
}

export function useThemeController({ appearance, layout, general }: UseThemeControllerInput) {
  const preferredDark = usePreferredDark();

  const resolvedTheme = computed(() =>
    resolveTheme({
      appearance: appearance.value,
      layout: layout.value,
      systemPrefersDark: preferredDark.value,
    }),
  );

  const themeTokens = computed(() => createThemeTokens(resolvedTheme.value));
  const themeCssVars = computed(() => createThemeCssVarsFromTokens(themeTokens.value));
  const naiveThemeOverrides = computed(() =>
    createNaiveThemeOverrides({
      resolvedTheme: resolvedTheme.value,
      semanticTokens: themeTokens.value.semantic,
      layoutSetting: layout.value,
    }),
  );
  const isDark = computed(() => resolvedTheme.value.colorMode === 'dark');

  watchEffect(() => {
    if (typeof document === 'undefined') {
      return;
    }

    document.documentElement.classList.toggle('dark', isDark.value);
    document.documentElement.setAttribute('data-theme', resolvedTheme.value.colorMode);
  });

  watchEffect(() => {
    if (typeof document === 'undefined') {
      return;
    }

    [document.documentElement, document.body].forEach((element) => {
      Object.entries(themeCssVars.value).forEach(([key, value]) => {
        if (general.value.syncThemeCssVars) {
          element.style.setProperty(key, value);
        } else {
          element.style.removeProperty(key);
        }
      });
    });
  });

  watchEffect(() => {
    if (!general.value.syncDynamicFavicon) {
      return;
    }

    syncDynamicFavicon(resolvedTheme.value.themeColor, isDark.value);
  });

  return {
    isDark,
    resolvedTheme,
    themeTokens,
    themeCssVars,
    naiveThemeOverrides,
  };
}
