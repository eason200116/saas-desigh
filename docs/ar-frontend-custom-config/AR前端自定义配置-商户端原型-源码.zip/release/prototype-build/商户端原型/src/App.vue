<template>
  <NConfigProvider
    :locale="currentLocales"
    :theme="isDark ? darkTheme : null"
    :theme-overrides="getThemeOverrides"
    :date-locale="currentLocalesDate"
    :component-options="componentOptions"
    :hljs="hljs"
    :inline-theme-disabled="true"
  >
    <n-notification-provider>
      <n-message-provider>
        <n-dialog-provider>
          <n-modal-provider>
            <AppProvider>
              <RouterView />
              <DevLocator v-if="enableDevLocator" />
            </AppProvider>
          </n-modal-provider>
        </n-dialog-provider>
      </n-message-provider>
    </n-notification-provider>
  </NConfigProvider>
</template>

<script lang="ts" setup>
  import { computed, defineAsyncComponent, nextTick, onMounted, watch } from 'vue';
  import { darkTheme } from 'naive-ui';
  import hljs from 'highlight.js';
  import { AppProvider } from '@/components/Application';

  import { useProjectSettingStore, useUser } from '@/store/modules';
  import { useThemeController } from '@/theme/runtime/use-theme-controller';
  import { useI18n } from 'vue-i18n';
  import { useRoute } from 'vue-router';

  const i18n = useI18n();
  // 「定位探针」：dev 环境自动加载；发布构建显式设 VITE_DEV_LOCATOR=1 时也加载（线上原型站看悬停规范用）。
  // 普通 pnpm build（未设该变量）仍被 DCE 彻底剔除、不进打包。
  const enableDevLocator = import.meta.env.DEV || import.meta.env.VITE_DEV_LOCATOR === '1';
  const DevLocator = enableDevLocator
    ? defineAsyncComponent(() => import('@/components/DevLocator/index.vue'))
    : null;
  const route = useRoute();
  const userStore = useUser();
  const projectSettingStore = useProjectSettingStore();
  const message = computed<Record<string, any>>(
    () => i18n.getLocaleMessage(i18n.locale.value) as Record<string, any>,
  );
  const currentLocales = computed<any>(() => message.value.naive);
  const currentLocalesDate = computed<any>(() => message.value.date);
  const componentOptions = {
    AutoComplete: {
      size: 'small',
    },
    Cascader: {
      size: 'small',
    },
    Button: {
      size: 'small',
    },
    Card: {
      size: 'small',
    },
    Checkbox: {
      size: 'small',
    },
    Pagination: {
      size: 'small',
      inputSize: 'small',
      selectSize: 'small',
    },
    ColorPicker: {
      size: 'small',
    },
    DatePicker: {
      size: 'small',
      timePickerSize: 'small',
    },
    DataTable: {
      size: 'small',
    },
    Descriptions: {
      size: 'small',
    },
    Dropdown: {
      size: 'small',
    },
    DynamicInput: {
      buttonSize: 'small',
    },
    DynamicTags: {
      size: 'small',
    },
    Form: {
      size: 'small',
    },
    Input: {
      size: 'small',
    },
    InputNumber: {
      size: 'small',
    },
    InputOtp: {
      size: 'small',
    },
    Mention: {
      size: 'small',
    },
    Select: {
      size: 'small',
    },
    Popselect: {
      size: 'small',
    },
    Radio: {
      size: 'small',
    },
    Rate: {
      size: 'small',
    },
    Result: {
      size: 'small',
    },
    Skeleton: {
      size: 'small',
    },
    Space: {
      size: 'small',
    },
    Switch: {
      size: 'small',
    },
    Table: {
      size: 'small',
    },
    Tabs: {
      size: 'small',
    },
    Tag: {
      size: 'small',
    },
    TimePicker: {
      size: 'small',
    },
    Transfer: {
      size: 'small',
    },
    TreeSelect: {
      size: 'small',
    },
  } as const;

  const themeController = useThemeController({
    appearance: computed(() => projectSettingStore.appearance),
    layout: computed(() => projectSettingStore.layout),
    general: computed(() => projectSettingStore.general),
  });
  const isDark = themeController.isDark;
  const getThemeOverrides = themeController.naiveThemeOverrides;

  const resetAppRenderReady = () => {
    const runtimeWindow = window as Window & {
      __AR_APP_RENDER_READY__?: {
        reason: 'mounted' | 'route-change';
        path: string;
        fullPath: string;
        title: string;
        timestamp: number;
      };
    };

    delete runtimeWindow.__AR_APP_RENDER_READY__;
    document.documentElement.setAttribute('data-app-render-ready', 'false');
    document.documentElement.removeAttribute('data-app-render-path');
    document.documentElement.removeAttribute('data-app-render-at');
  };

  const notifyAppRenderReady = async (reason: 'mounted' | 'route-change') => {
    resetAppRenderReady();
    await nextTick();
    await new Promise<void>((resolve) => {
      requestAnimationFrame(() => {
        requestAnimationFrame(() => resolve());
      });
    });

    const detail = {
      reason,
      path: window.location.pathname,
      fullPath: route.fullPath,
      title: document.title,
      timestamp: Date.now(),
    };

    const runtimeWindow = window as Window & {
      __AR_APP_RENDER_READY__?: typeof detail;
    };
    runtimeWindow.__AR_APP_RENDER_READY__ = detail;

    document.documentElement.setAttribute('data-app-render-ready', 'true');
    document.documentElement.setAttribute('data-app-render-path', detail.path);
    document.documentElement.setAttribute('data-app-render-at', String(detail.timestamp));
    window.dispatchEvent(new CustomEvent('ar:app-render-ready', { detail }));
    document.dispatchEvent(new CustomEvent('ar:app-render-ready', { detail }));
  };

  watch(
    () => route.fullPath,
    () => {
      void notifyAppRenderReady('route-change');
    },
    { immediate: true, flush: 'post' },
  );

  onMounted(async () => {
    if (userStore.getToken) {
      await userStore.initDictionaries();
    }
    void notifyAppRenderReady('mounted');
  });
</script>
