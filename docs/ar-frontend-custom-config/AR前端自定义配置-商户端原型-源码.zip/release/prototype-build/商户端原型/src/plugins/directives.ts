import { App } from 'vue';

import { permission } from '@/directives/permission';

/**
 * 注册全局自定义指令
 * @param Vue
 */
export function setupDirectives(Vue: App) {
  // 权限控制指令
  Vue.directive('permission', permission);
  Vue.directive('per', permission);
}
