import * as NaiveUI from 'naive-ui';
import { usePreferredDark } from '@vueuse/core';
import { computed } from 'vue';
import { useProjectSettingStore } from '@/store/modules';
import { resolveTheme } from '@/theme/runtime/resolve-theme';
import { createThemeTokens } from '@/theme/tokens';

/**
 * 挂载 Naive-ui 脱离上下文的 API
 * 如果你想在 setup 外使用 useDialog、useMessage、useNotification、useLoadingBar，可以通过 createDiscreteApi 来构建对应的 API。
 * https://www.naiveui.com/zh-CN/dark/components/discrete
 */

export function setupNaiveDiscreteApi() {
  const projectStore = useProjectSettingStore();
  const preferredDark = usePreferredDark();

  const configProviderPropsRef = computed(() => {
    const resolvedTheme = resolveTheme({
      appearance: projectStore.appearance,
      layout: projectStore.layout,
      systemPrefersDark: preferredDark.value,
    });
    const semanticTokens = createThemeTokens(resolvedTheme).semantic;
    const theme = resolvedTheme.colorMode === 'dark' ? NaiveUI.darkTheme : null;

    return {
      theme,
      themeOverrides: {
        common: {
          primaryColor: semanticTokens['--ui-accent-solid'],
          primaryColorHover: semanticTokens['--ui-accent-hover'],
          primaryColorPressed: semanticTokens['--ui-accent-pressed'],
        },
        LoadingBar: {
          colorLoading: semanticTokens['--ui-accent-solid'],
        },
      },
    };
  });

  const { message, dialog, notification, loadingBar } = NaiveUI.createDiscreteApi(
    ['message', 'dialog', 'notification', 'loadingBar'],
    {
      configProviderProps: configProviderPropsRef,
    },
  );

  window['$message'] = message;
  window['$dialog'] = dialog;
  window['$notification'] = notification;
  window['$loading'] = loadingBar;
}
