<template>
  <router-view />
</template>

<script setup lang="ts">
// 独立 H5 应用根组件：仅承载 H5 路由（移动外壳 + 各页）
</script>
