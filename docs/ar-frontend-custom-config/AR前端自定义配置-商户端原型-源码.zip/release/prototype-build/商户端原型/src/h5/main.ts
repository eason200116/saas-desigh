/**
 * 独立 H5 应用入口（与 3100 主应用零耦合）
 * - 不引入 3100 的 store / naive-ui / i18n / 路由守卫
 * - 仅创建一个轻应用挂载 H5 路由；所有文案为中文硬编码
 */
import { createApp } from 'vue';
import App from './App.vue';
import router from './router';

const app = createApp(App);
app.use(router);
app.mount('#h5-root');
