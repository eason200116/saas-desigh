import { createRouter, createWebHashHistory, type RouteRecordRaw } from 'vue-router';
import { H5RootRoute } from '@/router/h5-routes';

/**
 * 独立 H5 应用路由（与 3100 主应用完全隔离）
 * - hash 路由：刷新/深链在任意静态服务下都稳（无需 SPA 兜底）
 * - '/' 重定向到 /h5/home；其余沿用 H5RootRoute 的子路由
 */
const routes: RouteRecordRaw[] = [
  { path: '/', redirect: '/h5/home' },
  H5RootRoute,
];

const router = createRouter({
  history: createWebHashHistory(),
  routes,
  scrollBehavior: () => ({ left: 0, top: 0 }),
});

export default router;
