export enum PageEnum {
  // 登录
  BASE_LOGIN = '/login',
  BASE_LOGIN_NAME = 'Login',
  //重定向
  REDIRECT = '/redirect',
  REDIRECT_NAME = 'Redirect',
  // 首页
  BASE_HOME = '/home',
  //首页跳转默认路由
  BASE_HOME_REDIRECT = '/home/welcome',
  // 错误
  BASE_FORBIDDEN = '/403',
  ERROR_PAGE_NAME = 'ErrorPage',
}
