export * from './pageEnum';

// ResultEnum: 与后端接口 code 字段约定
export enum ResultEnum {
  SUCCESS = 0,
  ERROR = 1,
  TIMEOUT = 401,
}
