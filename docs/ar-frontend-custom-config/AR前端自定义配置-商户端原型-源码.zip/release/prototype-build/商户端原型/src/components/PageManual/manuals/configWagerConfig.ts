// 打码量配置（商户端 tenant · configCenter_wagerConfig）功能说明书。
// 锚定 src/views/config/wagerConfig/index.vue + shared/ConfigOpLogPopover.vue + data.ts
// 真实控件（R53 实证、不臆造）。单商户配置，4大分类(充值/红利/任务/邀请)共22项打码量倍数，逐行独立编辑保存。

import type { PageManual } from '../types';

const manual: PageManual = {
  route: 'configCenter_wagerConfig',
  title: '打码量配置',
  overview:
    '商户端「配置中心 › 打码量配置」页，单商户配置(顶部商户下拉必选)。按"充值/红利/任务/邀请"4张分类卡片' +
    '展示共22项打码量倍数配置，每行=项名+说明+数值+操作，逐行独立编辑保存(不是整页统一保存)。数值≤20位；' +
    '"打码量倍数"类项单位固定"倍"，"打码量平0数"(rechargeZero)项无单位。切换商户会自动退出当前行编辑态，' +
    '避免脏数据残留。2026-07-22核实代码未发现真实缺陷(保存真实调用saveWagerItem并落库、失败态有Toast提示)。',
  items: [
    {
      anchor: 'curMerchant',
      name: '选商户（必选）',
      group: '搜索',
      interaction: '下拉可搜索，单选，红星标记必选；切换后重新加载该商户的22项配置。',
      limit: '必选。',
    },
    {
      anchor: 'editRow',
      name: '编辑',
      group: '操作',
      interaction: '每行独立"编辑"按钮，点击后该行数值输入框解除置灰可输入；同一时间只能编辑一行(其余行编辑按钮变禁用)。',
    },
    {
      anchor: 'rowValue',
      name: '数值（输入框）',
      group: '操作',
      interaction: '只读态置灰不可点；编辑态可输入数字，最多20位，超出被输入框钳制。',
      limit: '≤20位数字；留空保存时按倍数类回填1、平0数类回填0；负数会报错拦截。',
    },
    {
      anchor: 'saveRow',
      name: '保存（该行）',
      group: '操作',
      interaction: '仅编辑态出现，点击校验(非负)通过后立即调接口落库+写入商户配置记录+Toast提示，退出编辑态。',
    },
    {
      anchor: 'cancelRow',
      name: '取消（该行）',
      group: '操作',
      interaction: '仅编辑态出现，点击放弃本次修改，退出编辑态，数值还原。',
    },
    {
      anchor: 'itemOpLog',
      name: '操作记录',
      group: '操作',
      interaction: '项名旁小图标，点击弹出该配置项最近的操作记录(时间/操作人/内容)，仅查看。',
    },
  ],
  fields: [
    { name: '分类（卡片标题）', def: '充值/红利/任务/邀请 4大类，每类归拢若干打码量倍数配置项。' },
    { name: '项名', def: '该项打码量配置的名称，如"充值打码量倍数""红包打码量倍数"等。' },
    { name: '说明', def: '该项的用途说明文字，可换行居左(R41)。' },
    { name: '值', def: '打码量倍数(单位"倍")或打码量平0数(无单位)，逐行独立编辑保存。' },
  ],
};

export default manual;
