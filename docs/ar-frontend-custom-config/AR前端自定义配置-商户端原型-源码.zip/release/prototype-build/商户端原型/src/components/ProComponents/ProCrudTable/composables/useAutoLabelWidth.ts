/**
 * @description 自治式 label 宽度测量：canvas measureText 离屏测算。
 *   每个 ProSearchBar 自己测，完全绕过 NForm 的 maxChildLabelWidthRef 共享 ref，
 *   彻底规避 v-show 切换 / i18n 字典 swap / 字体 swap 等 race condition 下
 *   label 锁死成 width:0 的 bug
 * @date 2026-05-25
 */
import { ref, watch, onMounted, type Ref, type ComputedRef } from 'vue';
import { useResizeObserver } from '@vueuse/core';

export interface UseAutoLabelWidthOptions {
  /** 当前可见 label 文本数组，i18n 切换 / 列变化 / collapsed 切换会触发重测 */
  labels: ComputedRef<string[]>;
  /** 真实渲染容器，用于读取字体规格（font-size、family、weight） */
  containerRef: Ref<HTMLElement | null>;
  /** 是否启用自治测量（false 时直接返回 fallback） */
  enabled: ComputedRef<boolean>;
  /**
   * label 右侧 padding (Naive UI 默认 12px) + 必填星号 (&nbsp;* 约 10px)
   * + canvas 测量与 DOM 实测的 kerning 偏差余量 (~3px)，默认 20。
   * 多语言（英文 / 越南文 / 印尼文）下 label 偏长，余量过紧会触发浏览器自然 wrap。
   */
  buffer?: ComputedRef<number>;
  /** 最小宽度，默认 60 */
  minWidth?: ComputedRef<number>;
  /**
   * 最大宽度（防极端长 label 撑爆表单），默认 360。
   * 覆盖 ~25 个英文字符 / ~16 个中文字符的合理 SaaS label。
   * 测试要求「不许折行」：宁可让超长 label 在视觉上偏宽，也不能 wrap。
   * 若特定列确实需要更宽，可在 `column.labelWidth` 显式覆盖。
   */
  maxWidth?: ComputedRef<number>;
  /** 禁用时与异常时的兜底值，默认 80 */
  fallback?: ComputedRef<number>;
}

// 模块级共享 canvas context，所有 ProSearchBar 共用一个 1KB 离屏画布
let sharedCtx: CanvasRenderingContext2D | null = null;

function getCtx(): CanvasRenderingContext2D | null {
  if (sharedCtx) return sharedCtx;
  if (typeof document === 'undefined') return null;
  sharedCtx = document.createElement('canvas').getContext('2d');
  return sharedCtx;
}

function readFontSpec(el: HTMLElement | null): string {
  if (!el || typeof window === 'undefined') return '14px sans-serif';
  // 优先从真实 label 节点读取（小尺寸 NForm 用 14px，medium / large 按实际渲染读）
  const sample = el.querySelector<HTMLElement>('.n-form-item-label') ?? el;
  const cs = getComputedStyle(sample);
  return `${cs.fontStyle} ${cs.fontWeight} ${cs.fontSize} ${cs.fontFamily}`;
}

export function useAutoLabelWidth(opts: UseAutoLabelWidthOptions): Ref<number> {
  const fallbackOf = () => opts.fallback?.value ?? 80;
  const out = ref<number>(fallbackOf());

  function measure(): number {
    if (!opts.enabled.value) return fallbackOf();

    const ctx = getCtx();
    if (!ctx) return fallbackOf();

    ctx.font = readFontSpec(opts.containerRef.value);
    const buf = opts.buffer?.value ?? 20;
    const min = opts.minWidth?.value ?? 60;
    const max = opts.maxWidth?.value ?? 360;

    let maxW = 0;
    for (const text of opts.labels.value) {
      if (!text) continue;
      const w = ctx.measureText(text).width;
      if (w > maxW) maxW = w;
    }
    if (maxW <= 0) return fallbackOf();
    return Math.ceil(Math.min(Math.max(maxW + buf, min), max));
  }

  function update() {
    const next = measure();
    if (next !== out.value) out.value = next;
  }

  watch([() => JSON.stringify(opts.labels.value), () => opts.enabled.value], update, {
    immediate: true,
    flush: 'post',
  });

  // 2. 容器尺寸变化（ProTabs v-show 切回 / 窗口缩放 / 侧边栏伸缩）→ 重测
  //    canvas 测量与 DOM 可见性无关，clientWidth<=0 跳过避免无意义工作
  useResizeObserver(opts.containerRef, () => {
    const el = opts.containerRef.value;
    if (!el || el.clientWidth <= 0) return;
    update();
  });

  // 3. 字体加载完成 → 重测一次（避免 fallback font 与目标 font 字宽差异）
  onMounted(() => {
    if (typeof document !== 'undefined' && 'fonts' in document) {
      const fonts = (document as { fonts?: { ready?: Promise<unknown> } }).fonts;
      if (fonts?.ready) void fonts.ready.then(update);
    }
  });

  return out;
}
