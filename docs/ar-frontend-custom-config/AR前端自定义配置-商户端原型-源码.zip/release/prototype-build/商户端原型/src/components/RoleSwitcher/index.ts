import RoleSwitcher from './RoleSwitcher.vue';

export { RoleSwitcher };
export default RoleSwitcher;
