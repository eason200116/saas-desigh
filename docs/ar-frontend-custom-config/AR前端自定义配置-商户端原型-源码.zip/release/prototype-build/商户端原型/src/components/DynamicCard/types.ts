/**
 * 动态卡片类型定义
 * 直接复用后端 API 类型
 */
// 后端类型已替换为 any 占位

/**
 * 扩展的卡片配置（包含前端图表配置字段）
 */
export interface CardConfig extends any {
  /** 系列名称 */
  seriesName?: string;
  /** 第二系列名称 */
  seriesName2?: string;
  /** 系列颜色 */
  seriesColor?: string;
  /** 第二系列颜色 */
  seriesColor2?: string;
}

/**
 * 卡片类型枚举
 */
export type CardType =
  | 'bar'
  | 'line'
  | 'bar_line'
  | 'stacked'
  | 'funnel'
  | 'pie'
  | 'table'
  | 'number'
  | 'retention'
  | 'path';

/**
 * 漏斗数据点（从 statisticList[0].calcData 转换）
 */
export interface FunnelDataPoint {
  name: string;
  count: number;
  percentage: number;
}

/**
 * 时序数据点（从 statisticList[].calcData 转换）
 */
export interface TimeSeriesDataPoint {
  time: string;
  value: number;
  value2?: number;
}

/**
 * 表格数据点
 */
export interface TableDataPoint {
  time: string;
  value: number;
  value2?: number;
}

/**
 * 饼图/分布数据点
 */
export interface DistributionDataPoint {
  name: string;
  value: number;
}

/**
 * 留存数据点
 */
export interface RetentionDataPoint {
  day_diff: number;
  retained_users: number;
}

/**
 * 卡片渲染数据（联合类型）
 */
export type CardRenderData =
  | TimeSeriesDataPoint[]
  | DistributionDataPoint[]
  | FunnelDataPoint[]
  | RetentionDataPoint[]
  | TableDataPoint[];
