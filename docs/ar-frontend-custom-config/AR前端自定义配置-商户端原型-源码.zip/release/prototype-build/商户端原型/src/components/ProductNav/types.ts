/**
 * Product navigation types
 */
import type { Component } from 'vue';

/**
 * Tab configuration for a page
 */
export interface TabConfig {
  /** Tab key identifier */
  key: string;
  /** i18n title key */
  title: string;
  /** Required permissions for this tab */
  permissions?: string[];
}

/**
 * Service item (page-level navigation item)
 */
export interface ServiceItem {
  /** Route name */
  key: string;
  /** i18n title key */
  title: string;
  /** Route path */
  path: string;
  /** Icon component */
  icon?: Component;
  /** Required permissions */
  permissions?: string[];
  /** Whether this item is hidden in navigation */
  hidden?: boolean;
  /** Tab configurations for this page */
  tabs?: TabConfig[];
}

/**
 * Category (module-level grouping)
 */
export interface Category {
  /** Category key identifier */
  key: string;
  /** i18n title key */
  title: string;
  /** Icon component */
  icon?: Component;
  /** Service items in this category */
  items: ServiceItem[];
}

/**
 * Product navigation config
 */
export interface ProductNavConfig {
  /** All categories */
  categories: Category[];
}

/**
 * Search result item
 */
export interface SearchResultItem {
  /** Route name */
  key: string;
  /** Display title */
  title: string;
  /** Route path */
  path: string;
  /** Parent category title */
  categoryTitle: string;
  /** Tab key (if searching tab level) */
  tabKey?: string;
}
