<template>
  <div class="flex items-center gap-2 w-full">
    <n-color-picker
      v-model:value="pickerColor"
      :show-alpha="true"
      :modes="['hex']"
      :swatches="swatches"
      size="small"
      class="color-picker-no-text"
      @complete="handleColorComplete"
    />
    <n-input
      :value="modelValue"
      :placeholder="placeholder"
      @update:value="$emit('update:modelValue', $event)"
    />
  </div>
</template>

<script setup lang="ts">
  import { ref } from 'vue';

  const props = withDefaults(
    defineProps<{
      modelValue?: string;
      placeholder?: string;
    }>(),
    {
      modelValue: '',
      placeholder: '',
    },
  );

  const emit = defineEmits<{
    (e: 'update:modelValue', value: string): void;
  }>();

  // 预设颜色
  const swatches = [
    '#1a2744',
    '#0f1419',
    '#1890ff',
    '#52c41a',
    '#faad14',
    '#f5222d',
    '#722ed1',
    '#13c2c2',
    '#eb2f96',
    '#2f54eb',
  ];

  // 颜色选择器独立的值
  const pickerColor = ref('');

  // 处理颜色选择完成
  const handleColorComplete = (color: string) => {
    emit('update:modelValue', color);
  };
</script>

<style scoped>
  .color-picker-no-text {
    width: 34px;
    flex-shrink: 0;
  }

  .color-picker-no-text ::v-deep(.n-color-picker-trigger__value) {
    display: none;
  }
</style>
