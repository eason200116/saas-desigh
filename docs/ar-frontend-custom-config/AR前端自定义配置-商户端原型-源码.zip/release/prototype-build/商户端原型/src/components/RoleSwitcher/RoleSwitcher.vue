<template>
  <div v-if="visible" ref="fabEl" class="role-switcher-fab" :style="posStyle">
    <div
      v-if="expanded"
      class="role-switcher-card"
      :class="dropDown ? 'role-switcher-card--down' : 'role-switcher-card--up'"
    >
      <div class="role-switcher-card__title">当前角色</div>
      <div class="role-switcher-card__current">
        <n-icon :size="18" class="role-switcher-card__icon"
          ><component :is="currentIconComp"
        /></n-icon>
        <span>{{ currentLabel }}</span>
      </div>
      <div class="role-switcher-card__divider"></div>
      <div class="role-switcher-card__sub">切换到：</div>
      <button class="role-switcher-card__action" @click="onSwitch">
        <n-icon :size="18" class="role-switcher-card__icon"
          ><component :is="targetIconComp"
        /></n-icon>
        <span>{{ targetLabel }}</span>
      </button>
      <div class="role-switcher-card__divider"></div>
      <!-- 产品文档链接（二阶段 PRD，按站点语境取本地/线上 R40）-->
      <button class="role-switcher-card__action" @click="openDoc(PRD_URL)">
        <n-icon :size="18" class="role-switcher-card__icon"><DocumentTextOutline /></n-icon>
        <span>二阶段 PRD</span>
      </button>
      <div class="role-switcher-card__divider"></div>
      <div class="role-switcher-card__hint">ⓘ 切换会刷新页面 · 按住图标可拖动</div>
    </div>

    <button
      class="role-switcher-fab__button"
      :class="{ 'is-dragging': dragging }"
      :title="`当前: ${currentLabel}（可拖动）`"
      @pointerdown="onPointerDown"
      @click="onButtonClick"
    >
      <n-icon :size="22"><component :is="currentIconComp" /></n-icon>
    </button>
  </div>
</template>

<script lang="ts" setup>
  import { computed, ref, onMounted, onBeforeUnmount } from 'vue';
  import { useRoute } from 'vue-router';
  import { NIcon } from 'naive-ui';
  import { SettingsOutline, StorefrontOutline, DocumentTextOutline } from '@vicons/ionicons5';
  import { useRoleStore, isRoleLocked } from '@/store/modules/role';

  const route = useRoute();
  const roleStore = useRoleStore();
  const expanded = ref(false);

  const HINT_KEY = 'app:role-switcher-hint-seen';
  const POS_KEY = 'app:role-switcher-pos';
  const HIDE_ON_PATHS = ['/login', '/redirect'];

  // 产品文档地址：按站点语境取本地/线上（R40 链接环境一致）
  // 本地跑(localhost) → 本地文档站 8090；线上(github.io) → 公网 Pages 文档
  const DOC_BASE = window.location.hostname.endsWith('github.io')
    ? 'https://eason200116.github.io/saas-desigh/docs'
    : 'http://localhost:8090/docs';
  const PRD_URL = `${DOC_BASE}/saas-phase2-prd-full.html`;

  const visible = computed(() => {
    // 本地 3100/3200 已按端口绑定角色（各端口只留本端内容），隐藏切换浮窗、不可互切
    if (isRoleLocked()) return false;
    const p = route.path || '';
    return !HIDE_ON_PATHS.some((x) => p.startsWith(x));
  });

  const currentLabel = computed(() => (roleStore.role === 'admin' ? '总控（Admin）' : '商户端'));
  const targetLabel = computed(() => (roleStore.role === 'admin' ? '商户端' : '总控（Admin）'));
  const currentIconComp = computed(() =>
    roleStore.role === 'admin' ? SettingsOutline : StorefrontOutline,
  );
  const targetIconComp = computed(() =>
    roleStore.role === 'admin' ? StorefrontOutline : SettingsOutline,
  );

  // ===== 拖动 =====
  const fabEl = ref<HTMLElement | null>(null);
  const pos = ref<{ x: number; y: number } | null>(null);
  const dragging = ref(false);
  let moved = false;
  let startX = 0;
  let startY = 0;
  let origX = 0;
  let origY = 0;

  const posStyle = computed(() =>
    pos.value
      ? { left: `${pos.value.x}px`, top: `${pos.value.y}px`, right: 'auto', bottom: 'auto' }
      : {},
  );

  // 卡片默认向上弹（按钮在底部）；拖到视口上半部时改为向下弹，避免卡片溢出顶部
  const dropDown = computed(() => (pos.value ? pos.value.y < 320 : false));

  function clamp(v: number, min: number, max: number) {
    return Math.max(min, Math.min(max, v));
  }

  function onPointerDown(e: PointerEvent) {
    dragging.value = true;
    moved = false;
    startX = e.clientX;
    startY = e.clientY;
    const rect = fabEl.value?.getBoundingClientRect();
    origX = rect?.left ?? 0;
    origY = rect?.top ?? 0;
    window.addEventListener('pointermove', onPointerMove);
    window.addEventListener('pointerup', onPointerUp);
  }

  function onPointerMove(e: PointerEvent) {
    if (!dragging.value) return;
    const dx = e.clientX - startX;
    const dy = e.clientY - startY;
    if (Math.abs(dx) + Math.abs(dy) > 4) moved = true;
    const w = fabEl.value?.offsetWidth ?? 48;
    const h = fabEl.value?.offsetHeight ?? 48;
    pos.value = {
      x: clamp(origX + dx, 8, window.innerWidth - w - 8),
      y: clamp(origY + dy, 8, window.innerHeight - h - 8),
    };
  }

  function onPointerUp() {
    dragging.value = false;
    window.removeEventListener('pointermove', onPointerMove);
    window.removeEventListener('pointerup', onPointerUp);
    if (pos.value) localStorage.setItem(POS_KEY, JSON.stringify(pos.value));
  }

  function toggle() {
    expanded.value = !expanded.value;
  }

  function onButtonClick() {
    // 区分点击与拖动：发生过拖动则不触发展开
    if (moved) {
      moved = false;
      return;
    }
    toggle();
  }

  function onSwitch() {
    const target = roleStore.role === 'admin' ? 'tenant' : 'admin';
    roleStore.switchTo(target);
  }

  function openDoc(url: string) {
    window.open(url, '_blank', 'noopener');
  }

  onMounted(() => {
    // 恢复拖动位置
    try {
      const saved = localStorage.getItem(POS_KEY);
      if (saved) {
        const p = JSON.parse(saved);
        if (typeof p?.x === 'number' && typeof p?.y === 'number') {
          pos.value = {
            x: clamp(p.x, 8, window.innerWidth - 56),
            y: clamp(p.y, 8, window.innerHeight - 56),
          };
        }
      }
    } catch {
      /* ignore */
    }

    if (!localStorage.getItem(HINT_KEY) && visible.value) {
      const show = window['$message' as keyof Window] as
        | { info?: (msg: string, opts?: any) => void }
        | undefined;
      if (show && typeof show.info === 'function') {
        show.info('默认进入商户端，右下角可切换到总控端（图标可拖动）', { duration: 5000 });
      }
      localStorage.setItem(HINT_KEY, '1');
    }
  });

  onBeforeUnmount(() => {
    window.removeEventListener('pointermove', onPointerMove);
    window.removeEventListener('pointerup', onPointerUp);
  });
</script>

<style scoped>
  .role-switcher-fab {
    position: fixed;
    bottom: 24px;
    right: 24px;
    z-index: 9999;
    width: 48px;
    height: 48px;
  }

  .role-switcher-fab__button {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 48px;
    height: 48px;
    border-radius: 24px;
    border: none;
    background: #2563eb;
    color: #fff;
    cursor: grab;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.18);
    transition:
      transform 0.15s,
      box-shadow 0.15s;
    touch-action: none;
  }

  .role-switcher-fab__button:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 16px rgba(0, 0, 0, 0.22);
  }

  .role-switcher-fab__button.is-dragging {
    cursor: grabbing;
    transform: scale(1.05);
  }

  .role-switcher-card {
    position: absolute;
    right: 0;
    width: 250px;
    background: #fff;
    border-radius: 8px;
    box-shadow: 0 6px 24px rgba(0, 0, 0, 0.16);
    padding: 14px 16px;
    font-size: 13px;
    color: #1f2937;
  }

  /* 向上弹（按钮在下方时）*/
  .role-switcher-card--up {
    bottom: calc(100% + 12px);
  }

  /* 向下弹（按钮在视口上半部时）*/
  .role-switcher-card--down {
    top: calc(100% + 12px);
  }

  .role-switcher-card__title {
    font-size: 12px;
    color: #6b7280;
    margin-bottom: 4px;
  }

  .role-switcher-card__current {
    display: flex;
    align-items: center;
    gap: 8px;
    font-weight: 600;
    font-size: 15px;
    margin-bottom: 8px;
  }

  .role-switcher-card__icon {
    color: #2563eb;
  }

  .role-switcher-card__divider {
    height: 1px;
    background: #e5e7eb;
    margin: 8px 0;
  }

  .role-switcher-card__sub {
    font-size: 12px;
    color: #6b7280;
    margin-bottom: 6px;
  }

  .role-switcher-card__action {
    width: 100%;
    background: #f3f4f6;
    border: none;
    border-radius: 6px;
    padding: 8px 10px;
    display: flex;
    align-items: center;
    gap: 8px;
    cursor: pointer;
    font-size: 13px;
    color: #1f2937;
  }

  .role-switcher-card__action:hover {
    background: #e5e7eb;
  }

  .role-switcher-card__hint {
    font-size: 11px;
    color: #9ca3af;
    text-align: center;
  }
</style>
