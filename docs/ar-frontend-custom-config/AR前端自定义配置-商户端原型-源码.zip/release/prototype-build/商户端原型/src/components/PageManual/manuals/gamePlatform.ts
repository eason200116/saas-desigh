// 游戏厂商管理（总控端 admin · game_platform）功能说明书 —— 首个样板页。
// 内容锚定 src/views/game/platform/index.vue + data.ts 真实控件（R53 实证、不臆造）。
// 联动锚点 anchor 与页面控件的 data-manual 值一一对应：
//   搜索 6 项（componentProps 挂）+ 状态列（render 外包 span 挂）= 点了会联动高亮；
//   行操作 5 项（createActionColumn 不透传 attr）→ 页面在各 onClick 里派发 page-manual:focus 事件联动、点按钮也会高亮定位。

import type { PageManual } from '../types';

const manual: PageManual = {
  route: 'game_platform',
  title: '游戏厂商管理',
  overview:
    '总控端接入 / 管理第三方游戏厂商：定义厂商身份（编码 / 名称 / 大类 / 供应商），启停厂商，配置语言映射、货币映射，并可同步该厂商子游戏。2026-07-28 新增「编辑」入口（2026-07-29 按 Eason 截图标红精简）：可改厂商名称 / 排序 / 前台显示名称，不再展示英文名称输入及其余身份字段的只读区块。厂商身份取自共享厂商池 gameVendorPool；列表按搜索条件过滤、默认居中展示。',
  items: [
    // ============ 搜索区（点了联动）============
    {
      anchor: 'categoryType',
      name: '游戏大类',
      group: '搜索',
      interaction: '下拉单选、可清空。',
      dataSource:
        '来自「游戏管理 › 游戏主类型配置」页维护的主类型（与该页同一套主类型主数据，约 12 类；具体项与数量以该配置页为准，不写死）。',
      logic: '选定后列表只显示该大类的厂商（按大类精确匹配过滤）。',
      limit: '选填。',
      edge: '不选 = 不按大类过滤，显示全部。',
    },
    {
      anchor: 'vendorName',
      name: '厂商名称',
      group: '搜索',
      interaction: '下拉单选、可搜索、可清空。',
      dataSource: '来自共享厂商池 gameVendorPool（46 家厂商中文名，与总控厂商池身份一致）。',
      logic: '选定后按所选厂商中文名精确匹配筛选（原模糊文本输入改为下拉精确选择）。',
      limit: '选填。',
      edge: '不选 = 不按名称筛。',
    },
    {
      anchor: 'currency',
      name: '支持币种',
      group: '搜索',
      interaction: '下拉单选、可清空。',
      dataSource:
        '系统币种主数据；各商户在「商户端 · 配置中心 › 前台配置」按商户勾选启用其前台支持的币种。本页下拉为可筛币种（当前 INR / BRL / VND / PKR）。',
      logic: '筛出「支持币种」列包含所选币种的厂商。',
      limit: '选填。',
      edge: '不选 = 不按币种筛。',
    },
    {
      anchor: 'language',
      name: '支持语言',
      group: '搜索',
      interaction: '下拉单选、可清空。',
      dataSource:
        '系统语言主数据；各商户在「商户端 · 配置中心 › 前台配置」按商户勾选启用其前台支持的语言。本页下拉为可筛语言（当前 英语 / 中文 / 泰语 / 越南语 / 印尼语 / 葡萄牙语）。',
      logic: '筛出「支持语言」列包含所选语言的厂商。',
      limit: '选填。',
      edge: '不选 = 不按语言筛。',
    },
    {
      anchor: 'search_state',
      name: '游戏状态（搜索）',
      group: '搜索',
      interaction: '下拉单选：启用 / 禁用，可清空。',
      dataSource: '本地固定枚举（启用 = 1 / 禁用 = 0）。',
      logic: '按厂商启用状态筛选列表。',
      limit: '选填。',
      edge: '不选 = 全部状态都显示。',
    },
    {
      anchor: 'maintainState',
      name: '维护状态（搜索）',
      group: '搜索',
      interaction:
        '下拉单选：维护中 / 正常，可清空。2026-07-23 新增，紧跟在「游戏状态」搜索项之后（1:1 参照子游戏管理同款拆法）。',
      dataSource:
        '本页独立字段 maintainState（本地 mock 造数，非取自 game/maintain 维护记录池，二者数据不互通）。',
      logic: '按维护状态精确匹配过滤。',
      limit: '选填。',
      edge: '不选 = 全部维护状态。',
    },

    // ============ 关键列（状态列点了联动）============
    {
      anchor: 'col_state',
      name: '游戏状态列',
      group: '列',
      interaction: '只读 Tag：启用 = 绿、禁用 = 红，不可点。',
      dataSource: '行数据 state（1 = 启用 / 0 = 禁用）。',
      logic: '仅展示厂商当前启用状态；要改状态走右侧行操作「状态」弹窗里的开关。',
      note: '本页有意破例 R47：列用只读 Tag、启停开关移到弹窗（见总控游戏管理只读 Tag 破例约定）。原列名「状态」2026-07-23 改为「游戏状态」（与新增「维护状态」列并列区分），字段 state 本身不变。',
    },
    {
      anchor: 'col_maintainState',
      name: '维护状态列',
      group: '列',
      interaction: '只读语义色 Tag：维护中 warning 橙 / 正常 success 绿，不可点。',
      dataSource:
        '行数据 maintainState（1 = 维护中 / 0 = 正常），本页独立 mock 字段，非取自 game/maintain 维护记录池。',
      logic: '仅展示厂商当前维护状态，无编辑入口（不在任何弹窗字段内）。',
      limit: '2026-07-23 新增列，只读，无编辑入口（1:1 参照子游戏管理同款拆法）。',
    },

    // ============ 行操作（点按钮 → 派发 page-manual:focus 事件、也会联动高亮定位）============
    {
      anchor: 'act_edit',
      name: '行操作 · 编辑',
      group: '操作',
      interaction:
        '点击开「编辑厂商」弹窗（约 560px 宽，2026-07-28 新增，本页首个综合编辑入口；2026-07-29 按 Eason 截图标红精简）：可编辑 厂商名称（必填） / 前台显示名称 / 排序，不再展示英文名称输入及只读展示区块（原「使用供应商 / 厂商编码 / 厂商类型 / 游戏大类」4项已删除，这几个字段仍在列表列展示）。',
      logic:
        '保存调 api.game.platformUpdateVendor；厂商名称（中文）会同时回写共享厂商池 gameVendorPool 对应厂商，保持两端厂商身份一致（唯一真源；英文名称字段 2026-07-29 起弹窗不再可编辑，池内旧值原样保留）。语言 / 货币 / 状态仍走各自专项弹窗，本弹窗不重复编辑。',
      note: '设计详见 docs/superpowers/specs/2026-07-28-game-platform-vendor-edit-modal-design.md。',
    },
    {
      anchor: 'act_state',
      name: '行操作 · 状态',
      group: '操作',
      interaction:
        '点击开窄弹窗（约 460px，弹窗含 厂商 + 游戏状态开关，2026-07-23 已删除厂商类型行），用开关改该厂商启用 / 禁用。',
      logic: '保存后刷新列表；这是本页真正改厂商启停的入口（R47 开关在弹窗）。',
      note: '点行操作按钮由页面 onClick 派发 page-manual:focus 事件联动（会高亮定位到本条），未改共享件。',
    },
    {
      anchor: 'act_language',
      name: '行操作 · 语言',
      group: '操作',
      interaction:
        '点击开「语言映射」弹窗（约 680px 宽）：配置系统语言 ↔ 三方语言的对应，可增删行、每行可启停。',
      logic:
        '决定该厂商游戏在各语言下的展示；回显 / 保存走 platformGetLangMapping / platformSaveLangMapping。',
    },
    {
      anchor: 'act_currency',
      name: '行操作 · 货币',
      group: '操作',
      interaction:
        '点击开「货币映射」弹窗（约 680px 宽）：配置系统币种 ↔ 三方币种的对应，可增删行、每行可启停。',
      logic:
        '决定该厂商结算币种如何映射到平台币种；回显 / 保存走 platformGetCurrencyMapping / platformSaveCurrencyMapping。',
    },
    {
      anchor: 'act_syncSubGame',
      name: '行操作 · 同步子游戏',
      group: '操作',
      interaction: '点击弹确认框，确认后同步该厂商的子游戏清单（橙色，写操作）。',
      logic: '从三方拉取该厂商最新子游戏（原型为示意，确认后直接返回成功）。',
    },
    {
      anchor: 'act_viewSubGame',
      name: '行操作 · 查看子游戏',
      group: '操作',
      interaction: '点击跳转到「子游戏管理」页，并按本厂商（vendorCode）自动预筛。',
      logic:
        '导航类操作，不弹窗、不改本页数据；用于从游戏厂商管理快速定位到该厂商名下的子游戏清单。',
    },
  ],

  // ============ 字段介绍 tab（仅列表的列 + 定义；顺序同列表列序 R44、只介绍定义）============
  fields: [
    {
      name: '厂商名称',
      def: '第三方游戏厂商的名称（中 / 英），可在「编辑」弹窗修改（2026-07-28 新增）。',
    },
    {
      name: '排序',
      def: '本页独立排序字段（不在共享厂商池内），可在「编辑」弹窗修改，不填即 0（2026-07-28 新增）。',
    },
    {
      name: '前台显示名称',
      def: '可选的前台展示覆盖名称，未设置显示 --，可在「编辑」弹窗修改（2026-07-28 新增）。',
    },
    { name: '使用供应商', def: '提供该厂商游戏的实际供应方名称。' },
    { name: '厂商编码', def: '厂商的唯一标识编码（如 CQ9 / PP / EVO_Video）。' },
    {
      name: '厂商类型',
      def: '厂商归属分类——自营厂商（本平台自营接入，如 AR彩票 / ARBET体育 / EVO 系）/ 三方厂商（外部供应商接入，如 智风(ZhiFeng) / 登峰(DengFeng) 系）。按「使用供应商」派生，与「游戏大类」（游戏品类）是两个维度。',
    },
    {
      name: '游戏大类',
      def: '厂商所属的游戏主类型（电子 / 真人 / 彩票等），取自「游戏主类型配置」。',
    },
    { name: '支持币种', def: '该厂商可结算的币种清单。' },
    { name: '支持语言', def: '该厂商游戏可展示的语言清单。' },
    {
      name: '游戏状态',
      def: '厂商当前的启用 / 禁用状态。原字段名「状态」2026-07-23 改为「游戏状态」（与新增「维护状态」列并列区分）。',
    },
    {
      name: '维护状态',
      def: '厂商当前是否处于维护中；本页独立字段，与 game/maintain 维护记录池无关、不共享数据（2026-07-23 新增，1:1 参照子游戏管理同款拆法）。',
    },
    { name: '创建时间', def: '该厂商记录的创建时间（按商户时区展示）。' },
    { name: '创建人', def: '创建该厂商记录的操作账号。' },
    { name: '更新时间', def: '该厂商记录最近一次修改的时间（按商户时区展示）。' },
    { name: '更新人', def: '最近一次修改该厂商记录的操作账号。' },
  ],
};

export default manual;
