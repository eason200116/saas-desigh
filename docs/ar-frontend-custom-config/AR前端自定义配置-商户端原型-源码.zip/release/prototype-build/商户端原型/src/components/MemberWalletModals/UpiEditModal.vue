<template>
  <n-form ref="formRef" :model="formData" :rules="computedRules" label-placement="top">
    <n-grid :cols="2" :x-gap="14">
      <n-form-item-gi :label="t('member.bankCard.merchant')" path="tenantId">
        <n-select
          v-if="!lockTenantId"
          v-model:value="formData.tenantId"
          :options="tenantOptions"
          filterable
          clearable
          :placeholder="t('common.select_placeholder', { label: t('member.bankCard.merchant') })"
        />
        <n-input v-else :value="getTenantName(formData.tenantId)" disabled />
      </n-form-item-gi>
      <n-form-item-gi :label="t('member.bankCard.userId')" path="userId">
        <n-input
          v-model:value="formData.userId"
          :disabled="lockUserId"
          :allow-input="onlyDigits"
          :placeholder="t('common.input_placeholder', { label: t('member.bankCard.userId') })"
        />
      </n-form-item-gi>
      <n-form-item-gi :label="t('member.bankCard.upiType')">
        <n-select
          v-model:value="formData.withType"
          :options="upiTypeOptions"
          clearable
          :placeholder="t('common.select_placeholder', { label: t('member.bankCard.upiType') })"
        />
      </n-form-item-gi>
      <n-form-item-gi :label="t('member.bankCard.beneficiaryName')" path="beneficiaryName">
        <n-input
          v-model:value="formData.beneficiaryName"
          :placeholder="
            t('common.input_placeholder', { label: t('member.bankCard.beneficiaryName') })
          "
        />
      </n-form-item-gi>
      <n-form-item-gi :label="t('member.bankCard.upiAccount')" path="upiAccount">
        <n-input
          v-model:value="formData.upiAccount"
          :placeholder="t('common.input_placeholder', { label: t('member.bankCard.upiAccount') })"
        />
      </n-form-item-gi>
      <n-form-item-gi :label="t('member.bankCard.mobileNO')" path="mobileNO">
        <n-input
          v-model:value="formData.mobileNO"
          :placeholder="t('common.input_placeholder', { label: t('member.bankCard.mobileNO') })"
        />
      </n-form-item-gi>
      <n-form-item-gi :label="t('member.bankCard.kycBankCode')" path="kycBankCode">
        <n-input
          v-model:value="formData.kycBankCode"
          :placeholder="t('common.input_placeholder', { label: t('member.bankCard.kycBankCode') })"
        />
      </n-form-item-gi>
    </n-grid>
  </n-form>
  <n-space justify="end" :style="{ marginTop: '16px' }">
    <n-button @click="emit('cancel')">{{ t('common.cancel') }}</n-button>
    <n-button type="primary" :loading="loading" @click="handleSubmit">
      {{ t('common.confirm') }}
    </n-button>
  </n-space>
</template>

<script setup lang="ts">
  import { reactive, ref, computed } from 'vue';
  import type { FormInst, FormRules } from 'naive-ui';
  import { useI18n } from 'vue-i18n';
  import { useMessage } from 'naive-ui';
  import { useTenantOptions, useUser } from '@/hooks';
  import { onlyDigits } from '@/utils';
  import { api } from './data';
  const props = defineProps<{
    mode: 'add' | 'edit';
    record?: Partial<any> | null;
    // 新增模式下可由调用方预填商户/会员，例如会员详情 - 钱包信息 tab
    initial?: { tenantId?: number | null; userId?: string | number | null } | null;
  }>();

  const emit = defineEmits<{
    (e: 'cancel'): void;
    (e: 'confirm'): void;
  }>();

  const { t } = useI18n();
  const message = useMessage();
  const { tenantOptions, getTenantName, defaultTenantId } = useTenantOptions();
  const { getOptions } = useUser();

  const isEdit = computed(() => props.mode === 'edit');
  // 新增模式下如果调用方通过 initial 预填了商户/会员，则锁死不可编辑
  const lockTenantId = computed(() => isEdit.value || props.initial?.tenantId != null);
  const lockUserId = computed(() => isEdit.value || props.initial?.userId != null);
  const formRef = ref<FormInst | null>(null);
  const loading = ref(false);

  // UPI 类型从 v1 字典 upiList 获取
  const upiTypeOptions = computed(() => getOptions('upiList'));

  const formData = reactive({
    tenantId:
      props.record?.tenantId ?? props.initial?.tenantId ?? defaultTenantId.value ?? undefined,
    userId:
      props.record?.userId != null
        ? String(props.record.userId)
        : props.initial?.userId != null
          ? String(props.initial.userId)
          : '',
    withType:
      props.record?.withType != null ? String(props.record.withType) : (null as string | null),
    beneficiaryName: props.record?.beneficiaryName ?? '',
    upiAccount: props.record?.accountNo ?? '',
    mobileNO: props.record?.mobileNO ?? '',
    kycBankCode: props.record?.bankCode ?? '',
  });

  // Fast UPI 时手机和 KYC 银行编码必填
  const computedRules = computed<FormRules>(() => {
    const selectedLabel = String(
      upiTypeOptions.value.find((o) => String(o.value) === formData.withType)?.label ?? '',
    );
    const isFastUpi = selectedLabel.toUpperCase().includes('FAST');
    return {
      tenantId: {
        required: true,
        type: 'number',
        message: t('common.select_placeholder', { label: t('member.bankCard.merchant') }),
        trigger: 'change',
      },
      userId: [
        {
          required: true,
          message: t('common.input_placeholder', { label: t('member.bankCard.userId') }),
          trigger: 'blur',
        },
        {
          pattern: /^\d+$/,
          message: t('member.bankCard.userIdIntegerOnly'),
          trigger: ['blur', 'input'],
        },
      ],
      beneficiaryName: {
        required: true,
        message: t('common.input_placeholder', { label: t('member.bankCard.beneficiaryName') }),
        trigger: 'blur',
      },
      upiAccount: [
        {
          required: true,
          message: t('common.input_placeholder', { label: t('member.bankCard.upiAccount') }),
          trigger: 'blur',
        },
        {
          validator: (_rule: unknown, value: string) => {
            if (!value) return true;
            if (value.length > 50) return new Error('UPI ID 长度不能超过50个字符');
            if (!value.includes('@')) return new Error('UPI ID 必须包含 @ 符号');
            return true;
          },
          trigger: 'blur',
        },
      ],
      ...(isFastUpi
        ? {
            mobileNO: {
              required: true,
              message: t('common.input_placeholder', { label: t('member.bankCard.mobileNO') }),
              trigger: 'blur',
            },
            kycBankCode: {
              required: true,
              message: t('common.input_placeholder', { label: t('member.bankCard.kycBankCode') }),
              trigger: 'blur',
            },
          }
        : {}),
    };
  });

  async function handleSubmit() {
    try {
      await formRef.value?.validate();
    } catch {
      return;
    }
    loading.value = true;
    try {
      const payload = {
        tenantId: formData.tenantId,
        userId: Number(formData.userId) || undefined,
        withType: formData.withType != null ? Number(formData.withType) : undefined,
        beneficiaryName: formData.beneficiaryName || undefined,
        accountNo: formData.upiAccount || undefined,
        mobileNO: formData.mobileNO || undefined,
        bankCode: formData.kycBankCode || undefined,
      };
      if (isEdit.value) {
        const { result, msg } = await api.v1platform.updateUPI({
          ...payload,
          bId: props.record?.bId,
        });
        if (!result) {
          message.error(msg ?? t('common.operateFailed'));
          return;
        }
      } else {
        const { result, msg } = await api.v1platform.addUPI(payload);
        if (!result) {
          message.error(msg ?? t('common.operateFailed'));
          return;
        }
      }
      message.success(t('member.bankCard.saveSuccess'));
      emit('confirm');
    } finally {
      loading.value = false;
    }
  }
</script>
