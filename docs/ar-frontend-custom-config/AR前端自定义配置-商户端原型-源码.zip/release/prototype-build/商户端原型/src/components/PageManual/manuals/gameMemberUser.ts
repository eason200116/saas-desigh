// 游戏会员管理（总控端 admin · game_member_user）功能说明书。
// 锚定 src/views/game/member/user/index.vue + data.ts + components/*Modal.vue 真实控件（R53 实证、不臆造）。
// 标准 ProCrudTable 列表页：6 搜索项（商户+代理合并格必填）+ 13 列 + 3 类行操作（详情 / 冻结·解冻 / 彩票限红，无顶部新增）。

import type { PageManual } from '../types';

const manual: PageManual = {
  route: 'game_member_user',
  title: '游戏会员管理',
  overview:
    '总控端查看与管理各商户的游戏会员：按商户（必选）+ 所属代理 + 会员ID 等条件查询，查看会员余额 / 策略钱包 / 累计输赢 / 状态等，可看会员详情、冻结 / 解冻会员、设置彩票限红。金额与输赢列左对齐（R61），状态用只读 Tag（R47 反转、开关在行操作）。',
  items: [
    // ============ 搜索区 ============
    {
      anchor: 'merchant',
      name: '商户名称（+ 所属代理）',
      group: '搜索',
      interaction: '一格两下拉（照源站）：左「商户名称」下拉、右「所属代理」下拉，占 2 列宽。',
      dataSource:
        '商户选项来自 gameMemberPool MEMBER_MERCHANT_OPTIONS；代理选项 agentOptionsForMerchant(商户)，随所选商户联动。',
      logic:
        '商户必选（会员ID 须落到唯一商户下才有意义，R63）；换商户会清空代理、只列该商户名下代理。',
      limit:
        '商户必填（红星 showRequireMark + requiredRule，空商户点搜索被拦 + 红字）；所属代理选填。',
      edge: '进页默认选中第一个商户（不落空表 R32）。',
    },
    {
      anchor: 'memberId',
      name: '会员ID',
      group: '搜索',
      interaction: '文本输入、模糊匹配。',
      dataSource: '用户输入。',
      logic: '按平台会员ID筛选。',
      limit: '选填；最多 50 字（inputProps searchKw）。',
      edge: '空 = 不按会员ID筛。',
    },
    {
      anchor: 'merchantMemberId',
      name: '商户会员ID',
      group: '搜索',
      interaction: '文本输入、模糊匹配。',
      dataSource: '用户输入。',
      logic: '按商户侧会员ID筛选。',
      limit: '选填；最多 50 字（inputProps searchKw）。',
      edge: '空 = 不按商户会员ID筛。',
    },
    {
      anchor: 'registerTimeRange',
      name: '会员注册时间',
      group: '搜索',
      interaction: '日期时间范围选择（proDateRange，精确到秒，占 2 列，label 后带问号提示）。',
      dataSource: '用户选择。',
      logic: '按会员注册时间范围筛选。',
      limit:
        '条件式：未输入会员ID/商户会员ID 时限 31 天内；输入了会员ID 或 商户会员ID 则不限时间。不可选未来（allowFuture false）。',
      edge: '空 = 返回全部；且 mock（userGetPageList）根本不按注册时间过滤——即使填了时间也不会真按注册时间筛（本页时间区间 UI 放出但 mock 未接、本模块唯一如此的页），故未强制必填。',
    },
    {
      anchor: 'currency',
      name: '币种',
      group: '搜索',
      interaction: '下拉单选、可清空。',
      dataSource: '选项来自 gameMemberPool MEMBER_CURRENCY_OPTIONS。',
      logic: '按会员币种筛选。',
      limit: '选填。',
      edge: '不选 = 全部币种。',
    },
    {
      anchor: 'userType',
      name: '用户类型',
      group: '搜索',
      interaction: '下拉单选、可清空。',
      dataSource: '选项来自 gameMemberPool USER_TYPE_OPTIONS。',
      logic: '按用户类型筛选。',
      limit: '选填。',
      edge: '不选 = 全部类型。',
    },

    // ============ 关键列（状态列）============
    {
      anchor: 'col_state',
      name: '状态列',
      group: '列',
      interaction: '只读 Tag：正常绿 / 冻结红，不可点。',
      dataSource: '行数据 state（1 正常 / 0 冻结）。',
      logic: '仅展示会员状态；改状态走行操作「冻结 / 解冻」。',
      note: '本页 R47 反转（列内只读 Tag、开关移入行操作），与 game/game 同口径。',
    },

    // ============ 行操作（无顶部新增）============
    {
      anchor: 'act_detail',
      name: '行操作 · 详情',
      group: '操作',
      interaction:
        '点击打开会员详情弹窗（约 900px，MemberDetailModal）：会员信息 / 游戏信息 / 注册信息三块。',
      logic: '只读展示，不修改数据。',
    },
    {
      anchor: 'act_toggleState',
      name: '行操作 · 冻结 / 解冻',
      group: '操作',
      interaction: '正常态显「冻结」、冻结态显「解冻」（同一入口按状态切文案）；点击弹二次确认框。',
      logic: '确认后调用 api.gameMember.userUpdateState 切换会员状态（正常⇄冻结）并刷新列表。',
    },
    {
      anchor: 'act_lotteryLimit',
      name: '行操作 · 彩票限红',
      group: '操作',
      interaction:
        '点击打开「设置用户彩票限红」弹窗（约 440px，LotteryLimitModal，标题带橙色警告图标）。',
      logic:
        '为该会员设置彩票限红分组（LOTTERY_LIMIT_OPTIONS 共 9 档：不限 + 限红组 1~8；LotteryLimitModal 照源站 /account/user「彩票限红」弹窗 1:1 实采）。',
    },
  ],

  // ============ 字段介绍 tab（列序照源站；仅列表列 + 定义）============
  fields: [
    { name: '商户名称', def: '会员所属的商户。' },
    { name: '会员ID', def: '会员在平台侧的唯一ID。' },
    { name: '商户会员ID', def: '会员在商户侧的ID。' },
    { name: '币种', def: '会员账户的币种。' },
    { name: '用户类型', def: '会员的用户类型（如正式 / 测试等）。' },
    { name: '会员余额', def: '会员主钱包余额。' },
    { name: '策略钱包余额', def: '会员策略钱包的余额。' },
    { name: '累计输赢', def: '会员累计净输赢（赢绿、输红，正负号标识）。' },
    { name: '注册ip', def: '会员注册时的 IP 地址。' },
    { name: '状态', def: '会员当前状态：正常 / 冻结。' },
    { name: '最后登录时间', def: '会员最近一次登录时间（按商户时区展示）。' },
    { name: '注册时间', def: '会员注册时间（按商户时区展示）。' },
  ],
};

export default manual;
