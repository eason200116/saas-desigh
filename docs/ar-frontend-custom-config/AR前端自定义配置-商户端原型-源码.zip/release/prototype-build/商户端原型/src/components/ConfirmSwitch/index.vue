<template>
  <n-switch
    ref="switchRef"
    :value="modelValue"
    :checked-value="checkedValue"
    :unchecked-value="uncheckedValue"
    :disabled="isDisabled"
    v-bind="$attrs"
    @update:value="handleChange"
  />
</template>

<script setup lang="ts">
  import { computed, ref } from 'vue';
  import { useDialog } from 'naive-ui';
  import { useI18n } from 'vue-i18n';

  interface Props {
    /** 绑定值 */
    modelValue: boolean | string | number;
    /** 是否禁用 */
    disabled?: boolean;
    /** 额外提示文本 */
    extraTip?: string;
    /** 确认按钮文案 */
    positiveText?: string;
    /** 取消按钮文案 */
    negativeText?: string;
    /** 选中时的值 */
    checkedValue?: boolean | string | number;
    /** 未选中时的值 */
    uncheckedValue?: boolean | string | number;
  }

  const props = withDefaults(defineProps<Props>(), {
    checkedValue: true,
    uncheckedValue: false,
    extraTip: '',
  });

  const emit = defineEmits<{
    'update:modelValue': [value: boolean | string | number];
    confirm: [value: boolean | string | number];
  }>();

  const { t } = useI18n();
  const dialog = useDialog();
  const switchRef = ref();
  const pendingValue = ref<boolean | string | number | null>(null);

  const isDisabled = computed(() => props.disabled === true);

  /**
   * 处理切换
   */
  const handleChange = (value: boolean | string | number) => {
    const isEnabling = value === props.checkedValue;
    const confirmText = isEnabling ? t('common.confirmEnable') : t('common.confirmDisable');
    const tipText = props.extraTip ? confirmText + props.extraTip : confirmText;

    pendingValue.value = value;

    dialog.warning({
      title: t('common.prompt'),
      content: tipText,
      positiveText: props.positiveText ?? t('common.confirm'),
      negativeText: props.negativeText ?? t('common.cancel'),
      onPositiveClick: () => {
        emit('update:modelValue', value);
        emit('confirm', value);
      },
      onNegativeClick: () => {
        pendingValue.value = null;
      },
    });
  };

  defineExpose({
    switchRef,
  });
</script>
