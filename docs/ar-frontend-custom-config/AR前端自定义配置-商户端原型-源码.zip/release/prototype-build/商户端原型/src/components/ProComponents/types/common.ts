import type { Component, VNode, Ref, ComputedRef } from 'vue';
import type { FormItemRule, SelectOption } from 'naive-ui';

// ============== 工具类型 ==============

/** 深度可选 */
export type DeepPartial<T> = {
  [P in keyof T]?: T[P] extends object ? DeepPartial<T[P]> : T[P];
};

/** 可能是 Ref */
export type MaybeRef<T> = T | Ref<T>;

/** 可能是 ComputedRef */
export type MaybeComputedRef<T> = T | ComputedRef<T>;

/** 记录类型 */
export type Recordable<T = any> = Record<string, T>;

/** 可空类型 */
export type Nullable<T> = T | null;

/** 函数类型 */
export type Fn<T = any, R = void> = (...args: T[]) => R;

/** 异步函数类型 */
export type AsyncFn<T = any, R = void> = (...args: T[]) => Promise<R>;

// ============== 字段值类型 ==============

export type ProFieldValueType =
  | 'text'
  | 'password'
  | 'textarea'
  | 'number'
  | 'select'
  | 'multiSelect'
  | 'tenantSelect'
  | 'dictSelect'
  | 'date'
  | 'dateRange'
  | 'datetime'
  | 'datetimeRange'
  | 'time'
  | 'timeRange'
  | 'week'
  | 'month'
  | 'year'
  | 'quarter'
  | 'checkbox'
  | 'checkboxGroup'
  | 'radio'
  | 'radioGroup'
  | 'switch'
  | 'cascader'
  | 'cascadeSelect'
  | 'treeSelect'
  | 'upload'
  | 'slider'
  | 'rate'
  | 'color'
  | 'custom'
  | 'proDateRange'
  | 'proSelectDateRange'
  | 'numberRange';

// ============== 组件类型 ==============

export type ProComponentType =
  | 'NInput'
  | 'NInputNumber'
  | 'NSelect'
  | 'TenantSelect'
  | 'DictSelect'
  | 'NDatePicker'
  | 'NTimePicker'
  | 'NCheckbox'
  | 'NCheckboxGroup'
  | 'NRadio'
  | 'NRadioGroup'
  | 'NSwitch'
  | 'NCascader'
  | 'ProCascadeSelect'
  | 'NTreeSelect'
  | 'NUpload'
  | 'NSlider'
  | 'NRate'
  | 'NColorPicker'
  | 'NAutoComplete'
  | 'NMention'
  | 'NDynamicTags'
  | 'NTransfer'
  | 'ProDateRangeInput'
  | 'ProSelectDateRange'
  | 'ProNumberRange'
  | Component;

// ============== 选项类型 ==============

export interface ProOptionItem<V = any> {
  label: string;
  value: V;
  disabled?: boolean;
  children?: ProOptionItem<V>[];
  [key: string]: any;
}

/** 异步选项加载器 */
export type ProAsyncOptions<V = any> =
  | ProOptionItem<V>[]
  | SelectOption[]
  | ((params?: Recordable) => Promise<ProOptionItem<V>[] | SelectOption[]>);

/** 字段映射配置 */
export interface ProFieldMapping {
  label?: string;
  value?: string;
  children?: string;
  disabled?: string;
}

// ============== 验证类型 ==============

export interface ProValidationRule extends FormItemRule {
  /** 异步验证器 */
  asyncValidator?: (
    value: any,
    rule: ProValidationRule,
    callback: (error?: Error) => void,
  ) => Promise<void>;
  /** 条件验证 */
  when?: (formModel: Recordable) => boolean;
  /** 值转换 */
  transform?: (value: any) => any;
  /** 消息模板 */
  messageTemplate?: string;
  /** 优先级 */
  priority?: number;
}

/** 验证结果 */
export interface ProValidationResult {
  valid: boolean;
  errors: string[];
  warnings?: string[];
}

/** 验证状态 */
export interface ProValidationState {
  isValid: boolean;
  isValidating: boolean;
  errors: string[];
  warnings: string[];
}

// ============== 值枚举类型 ==============

export interface ProValueEnumItem {
  text: string;
  status?: 'default' | 'success' | 'error' | 'warning' | 'info' | 'processing';
  color?: string;
  disabled?: boolean;
}

export type ProValueEnum = Record<string | number, ProValueEnumItem | string>;

// ============== 事件类型 ==============

export interface ProFormEvents<T = Recordable> {
  submit: (values: T) => void;
  reset: (values: T) => void;
  valuesChange: (changedValues: Partial<T>, allValues: T) => void;
  validateFail: (errors: Recordable<string[]>) => void;
}

export interface ProTableEvents<T = Recordable> {
  fetchSuccess: (result: { items: T[]; total: number }) => void;
  fetchError: (error: Error) => void;
  rowClick: (row: T, index: number) => void;
  rowDblclick: (row: T, index: number) => void;
  selectionChange: (keys: (string | number)[], rows: T[]) => void;
}

// ============== 布局类型 ==============

export type ProFormLayout = 'horizontal' | 'vertical' | 'inline';
export type ProLabelPlacement = 'left' | 'top';
export type ProLabelAlign = 'left' | 'right';
export type ProSize = 'small' | 'medium' | 'large';

// ============== 触发器类型 ==============

export type ProValidateTrigger = 'blur' | 'change' | 'input' | 'focus';

// ============== 通用回调类型 ==============

export type ProTransformFn<T = any, R = any> = (value: T) => R;
export type ProRenderFn<T = any> = (context: T) => VNode | VNode[] | string | null;
