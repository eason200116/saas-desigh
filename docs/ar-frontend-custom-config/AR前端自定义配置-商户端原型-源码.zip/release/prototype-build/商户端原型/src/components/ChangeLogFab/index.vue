<template>
  <div v-if="visible" ref="fabEl" class="changelog-fab" :style="posStyle">
    <div
      v-if="expanded"
      class="changelog-panel"
      :class="[
        dropUp ? 'changelog-panel--up' : 'changelog-panel--down',
        openLeft ? 'changelog-panel--left' : 'changelog-panel--right',
      ]"
    >
      <div class="changelog-panel__head">
        <span class="changelog-panel__title">📝 {{ t('common.changelog.title') }}</span>
        <span class="changelog-panel__meta">
          {{ t('common.changelog.count', { n: list.length }) }}
          <template v-if="latest">
            · {{ t('common.changelog.latest') }} {{ latest.version }}
          </template>
        </span>
        <button class="changelog-panel__close" title="close" @click="expanded = false">×</button>
      </div>
      <div class="changelog-panel__body">
        <div v-if="!list.length" class="changelog-panel__empty">{{
          t('common.changelog.empty')
        }}</div>
        <div
          v-for="(e, i) in list"
          :key="e.version + i"
          class="changelog-item"
          :class="{ 'is-open': !!openMap[i] }"
        >
          <button class="changelog-item__head" @click="toggleItem(i)">
            <span class="changelog-item__ver">{{ e.version }}</span>
            <span class="changelog-item__date">{{ e.date }}</span>
            <span class="changelog-item__summary">{{
              t('common.changelog.items', { n: e.changes.length })
            }}</span>
            <span class="changelog-item__arrow">{{ openMap[i] ? '▾' : '▸' }}</span>
          </button>
          <div v-if="openMap[i]" class="changelog-item__detail">
            <div v-for="(c, ci) in e.changes" :key="ci" class="changelog-change">
              <div class="changelog-change__path">{{ c.path }}</div>
              <div class="changelog-change__content">{{ c.content }}</div>
              <a v-if="c.link" class="changelog-change__link" @click="goto(c.link)"
                >🔗 {{ t('common.changelog.goto') }}</a
              >
            </div>
          </div>
        </div>
      </div>
    </div>

    <button
      class="changelog-fab__button"
      :class="{ 'is-dragging': dragging }"
      :title="t('common.changelog.tooltip')"
      @pointerdown="onPointerDown"
      @click="onButtonClick"
    >
      <span class="changelog-fab__icon">📝</span>
    </button>
  </div>
</template>

<script lang="ts" setup>
  import { computed, reactive, ref, onMounted, onBeforeUnmount } from 'vue';
  import { useRoute, useRouter } from 'vue-router';
  import { useI18n } from 'vue-i18n';
  import { CHANGELOG, CHANGELOG_LATEST } from './data';

  const { t } = useI18n();
  const route = useRoute();
  const router = useRouter();

  const list = CHANGELOG;
  const latest = CHANGELOG_LATEST;

  const POS_KEY = 'app:changelog-fab-pos';
  const HIDE_ON_PATHS = ['/login', '/redirect'];
  const visible = computed(() => {
    const p = route.path || '';
    return !HIDE_ON_PATHS.some((x) => p.startsWith(x));
  });

  const expanded = ref(false);
  const openMap = reactive<Record<number, boolean>>({ 0: true }); // 最新版默认展开
  function toggleItem(i: number) {
    openMap[i] = !openMap[i];
  }
  // 产品链接：应用内跳转到该原型页面（本地/线上都对，免 R40 环境问题），并收起面板
  function goto(link?: string) {
    if (!link) return;
    expanded.value = false;
    router.push(link);
  }

  // ===== 拖动（对齐 RoleSwitcher）=====
  const fabEl = ref<HTMLElement | null>(null);
  const pos = ref<{ x: number; y: number } | null>(null);
  const dragging = ref(false);
  let moved = false;
  let startX = 0;
  let startY = 0;
  let origX = 0;
  let origY = 0;

  const posStyle = computed(() =>
    pos.value ? { left: `${pos.value.x}px`, top: `${pos.value.y}px`, right: 'auto' } : {},
  );
  // 默认在顶部 → 面板向下弹；拖到视口下半部 → 向上弹，避免溢出底部
  const dropUp = computed(() => (pos.value ? pos.value.y > window.innerHeight / 2 : false));
  // 浮窗在右半屏 → 面板向左展开(靠右对齐)；在左半屏 → 向右展开(靠左对齐)，避免溢出屏外
  const openLeft = computed(() => {
    const w = fabEl.value?.offsetWidth ?? 48;
    const cx = pos.value ? pos.value.x + w / 2 : window.innerWidth - 24 - w / 2;
    return cx > window.innerWidth / 2;
  });

  function clamp(v: number, min: number, max: number) {
    return Math.max(min, Math.min(max, v));
  }
  function onPointerDown(e: PointerEvent) {
    dragging.value = true;
    moved = false;
    startX = e.clientX;
    startY = e.clientY;
    const rect = fabEl.value?.getBoundingClientRect();
    origX = rect?.left ?? 0;
    origY = rect?.top ?? 0;
    window.addEventListener('pointermove', onPointerMove);
    window.addEventListener('pointerup', onPointerUp);
  }
  function onPointerMove(e: PointerEvent) {
    if (!dragging.value) return;
    const dx = e.clientX - startX;
    const dy = e.clientY - startY;
    if (Math.abs(dx) + Math.abs(dy) > 4) moved = true;
    const w = fabEl.value?.offsetWidth ?? 48;
    const h = fabEl.value?.offsetHeight ?? 48;
    pos.value = {
      x: clamp(origX + dx, 8, window.innerWidth - w - 8),
      y: clamp(origY + dy, 8, window.innerHeight - h - 8),
    };
  }
  function onPointerUp() {
    dragging.value = false;
    window.removeEventListener('pointermove', onPointerMove);
    window.removeEventListener('pointerup', onPointerUp);
    if (pos.value) localStorage.setItem(POS_KEY, JSON.stringify(pos.value));
  }
  function onButtonClick() {
    if (moved) {
      moved = false;
      return;
    }
    expanded.value = !expanded.value;
  }

  onMounted(() => {
    try {
      const saved = localStorage.getItem(POS_KEY);
      if (saved) {
        const p = JSON.parse(saved);
        if (typeof p?.x === 'number' && typeof p?.y === 'number') {
          pos.value = {
            x: clamp(p.x, 8, window.innerWidth - 56),
            y: clamp(p.y, 8, window.innerHeight - 56),
          };
        }
      }
    } catch {
      /* ignore */
    }
  });
  onBeforeUnmount(() => {
    window.removeEventListener('pointermove', onPointerMove);
    window.removeEventListener('pointerup', onPointerUp);
  });
</script>

<style scoped>
  .changelog-fab {
    position: fixed;
    top: 76px;
    right: 24px;
    z-index: 9999;
    width: 48px;
    height: 48px;
  }
  .changelog-fab__button {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 48px;
    height: 48px;
    border-radius: 24px;
    border: none;
    background: #7c3aed;
    color: #fff;
    cursor: grab;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.18);
    transition:
      transform 0.15s,
      box-shadow 0.15s;
    touch-action: none;
  }
  .changelog-fab__button:hover {
    transform: scale(1.06);
    box-shadow: 0 6px 16px rgba(0, 0, 0, 0.24);
  }
  .changelog-fab__button.is-dragging {
    cursor: grabbing;
  }
  .changelog-fab__icon {
    font-size: 22px;
    line-height: 1;
  }

  .changelog-panel {
    position: absolute;
    width: 380px;
    max-width: min(380px, 90vw);
    max-height: 70vh;
    display: flex;
    flex-direction: column;
    background: #fff;
    border: 1px solid #e5e7eb;
    border-radius: 12px;
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.18);
    overflow: hidden;
  }
  .changelog-panel--down {
    top: calc(100% + 12px);
  }
  .changelog-panel--up {
    bottom: calc(100% + 12px);
  }
  /* 横向自适应：右半屏靠右对齐向左展开；左半屏靠左对齐向右展开 */
  .changelog-panel--left {
    right: 0;
  }
  .changelog-panel--right {
    left: 0;
  }
  .changelog-panel__head {
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 10px 12px;
    border-bottom: 1px solid #eef2f7;
    background: #f5f3ff;
  }
  .changelog-panel__title {
    font-weight: 600;
    color: #6d28d9;
    white-space: nowrap;
  }
  .changelog-panel__meta {
    flex: 1;
    font-size: 12px;
    color: #6b7280;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }
  .changelog-panel__close {
    border: none;
    background: transparent;
    font-size: 18px;
    line-height: 1;
    color: #9ca3af;
    cursor: pointer;
  }
  .changelog-panel__close:hover {
    color: #374151;
  }
  .changelog-panel__body {
    overflow-y: auto;
    padding: 6px;
  }
  .changelog-panel__empty {
    padding: 24px;
    text-align: center;
    color: #9ca3af;
  }

  .changelog-item {
    border-bottom: 1px solid #f1f5f9;
  }
  .changelog-item__head {
    display: flex;
    align-items: center;
    gap: 8px;
    width: 100%;
    padding: 9px 8px;
    border: none;
    background: transparent;
    text-align: left;
    cursor: pointer;
  }
  .changelog-item__head:hover {
    background: #faf5ff;
  }
  .changelog-item__ver {
    font-weight: 600;
    color: #7c3aed;
    white-space: nowrap;
  }
  .changelog-item__date {
    font-size: 12px;
    color: #9ca3af;
    white-space: nowrap;
  }
  .changelog-item__summary {
    flex: 1;
    font-size: 13px;
    color: #374151;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
  .changelog-item__arrow {
    color: #c4b5fd;
    font-size: 12px;
  }
  .changelog-item__detail {
    padding: 2px 0 8px;
  }
  .changelog-change {
    padding: 7px 10px;
    border-top: 1px dashed #f1f5f9;
  }
  .changelog-change:first-child {
    border-top: none;
  }
  .changelog-change__path {
    font-weight: 600;
    color: #6d28d9;
    font-size: 12.5px;
    margin-bottom: 3px;
    word-break: break-word;
  }
  .changelog-change__content {
    font-size: 12.5px;
    line-height: 1.7;
    color: #4b5563;
    word-break: break-word;
  }
  .changelog-change__link {
    display: inline-block;
    margin-top: 5px;
    font-size: 12px;
    color: #2563eb;
    cursor: pointer;
    user-select: none;
  }
  .changelog-change__link:hover {
    text-decoration: underline;
  }
</style>
