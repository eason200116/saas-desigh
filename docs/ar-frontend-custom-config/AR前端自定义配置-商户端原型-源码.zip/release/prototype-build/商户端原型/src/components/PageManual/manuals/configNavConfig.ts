// 导航配置（商户端 tenant · configCenter_navConfig）功能说明书。
// 锚定 src/views/config/navConfig/index.vue + data.ts 真实控件（R53 实证、不臆造）。
// 1:1迁自ar-saas原型「运营管理→导航配置」。纯列表/入口页，点卡片跳转到独立详情路由
// configCenter_navConfigDetail(游戏导航工作台，另见 configNavConfigDetail.ts manual)。

import type { PageManual } from '../types';

const manual: PageManual = {
  route: 'configCenter_navConfig',
  title: '导航配置',
  overview:
    '商户端「配置中心 › 导航配置」页，1:1迁自ar-saas原型「运营管理→导航配置」。卡片网格展示全部商户' +
    '的导航配置完成情况，每张卡含Logo+商户名/ID+配置状态(已配置/部分配置/未配置)+已完成板块标签' +
    '(Header/Sidebar/Footer/首页数据)+4项数量统计(Header/Sidebar/Footer/楼层)+最近更新时间与操作人+' +
    '待补项提示。点击任意卡片跳转到该商户独立的「游戏导航工作台」详情页(真实路由' +
    'configCenter_navConfigDetail，非弹窗)。本页自身无搜索/新增/删除等操作，纯只读入口。2026-07-22' +
    '核实代码未发现真实缺陷(路由跳转真实可达，与更早版本brandConfig曾出现的死链路由不同)。',
  items: [
    {
      anchor: 'selectMerchant',
      name: '商户卡片（点击进入配置）',
      group: '操作',
      interaction: '点击整张卡片跳转到该商户的「游戏导航工作台」详情页(/config-center/navConfig/:tenantId)。',
    },
  ],
  fields: [
    { name: '状态', def: '已配置(全部板块完成)/部分配置(部分板块完成)/未配置(尚无任何配置)，标签颜色区分。' },
    { name: '板块完成标签', def: 'Header/Sidebar/Footer/首页数据 4个板块各自是否已配置，完成标绿。' },
    { name: '数量统计', def: 'Header/Sidebar/Footer 三处导航项数量 + 楼层数量，共4项。' },
    { name: '待补提示', def: '未完全配置的卡片底部显示"待补：xxx"列出尚缺的板块名；全部完成显示"配置完整"。' },
    { name: '最近更新', def: '该商户导航配置最后一次修改的时间+操作人。' },
  ],
};

export default manual;
