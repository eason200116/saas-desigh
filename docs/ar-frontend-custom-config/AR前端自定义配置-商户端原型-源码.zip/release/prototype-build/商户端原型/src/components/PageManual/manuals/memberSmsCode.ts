// 验证码查询（商户端 tenant · member_sms_code）功能说明书。
// 锚定 src/views/member/smsCode/index.vue + data.ts 真实控件（R53 实证、不臆造）。
// 纯查询列表页：单表 ProCrudTable，无新增/编辑/删除/批量操作/导出按钮，表格 11 列里也没有「操作」列；
// 全页唯一交互出口是「会员ID」列命中已注册会员时可点击跳转全站共用的会员详情弹窗（openMemberDetailModal，来自 useUser hook，非本页专属组件）；
// 目录内确认仅 index.vue + data.ts 两件套，无独立弹窗/抽屉/子组件文件。
// 页面本身未挂 data-manual 锚点（对齐同模块既有先例 riskControlSameIp.ts / memberGroupManage.ts 现状），本说明书条目暂不联动面板点击高亮，仅供阅读。
// 路由 roles:['tenant']，仅商户端可见，总控端不可访问本页。

import type { PageManual } from '../types';

const manual: PageManual = {
  route: 'member_sms_code',
  title: '验证码查询',
  overview:
    '商户端「会员管理 › 登录·验证 › 验证码查询」页，单表（ProCrudTable）查询短信 / 邮箱验证码的发送记录：mobile 字段统一承载手机号或邮箱两种联系方式（列表用前置 Tag 区分"手机"/"邮箱"），vendor 对应该条记录发出时用的短信厂商或邮箱厂商。全页仅一次查询交互：无新增/编辑/删除、无批量操作、无导出按钮，表格也没有操作列；会员ID命中已注册会员时可点击跳转全站共用的「会员详情」弹窗，命中"已发码但未注册"（如注册流程验证码发送时账户尚未生成）时展示不可点的灰色「未注册」标签。如实记录两处设计特征：①表格没有独立的「验证码」列，验证码原文只出现在「内容」列文案里；②mock 的 mobile 字段本身即以脱敏态存储，并非真实号码/邮箱原文。',
  items: [
    // ============ 搜索区 ============
    {
      anchor: 'merchant',
      name: '商户',
      group: '搜索',
      interaction:
        '下拉单选、可搜索（商户选择器 merchantSearchColumn，multiple:false → 架构级不可清空，见《交互规范》§3 商户选择器；单选自动去掉「全部」选项）。',
      dataSource:
        '全站商户列表；默认预填当前左上角选中的商户（defaultTenantId）——本页路由 roles 仅 tenant，总控端不可访问，故代码里"总控端 defaultTenantId=null 不锁商户"分支实际不会被触发。',
      logic: '按选中商户过滤验证码发送记录。',
      limit:
        '必填（红星 showRequireMark + requiredRule）；单选、不可清空——命中 R63（本页商户与会员ID同屏出现，商户必单选+必填）。',
      edge: '不选商户点查询 → 红框 + 红字提示「请选择商户」（common.select_placeholder 拼商户）。',
    },
    {
      anchor: 'memberId',
      name: '会员ID',
      group: '搜索',
      interaction: '文本输入。',
      dataSource: '用户输入。',
      logic: '按会员ID做包含匹配（仅比对 memberId 非空的记录，"未注册"记录天然被排除）。',
      limit: '选填；仅数字，最多 9 位（inputProps intNum）。',
      edge: '空 = 不按会员ID筛。',
    },
    {
      anchor: 'mobile',
      name: '手机号/邮箱',
      group: '搜索',
      interaction:
        '文本输入，同一框可查手机号也可查邮箱、无格式强校验（代码注释明确：不用 phone 预设即 onlyDigits，会拦掉邮箱地址的字母/@/点号，致"邮箱查询"名不副实）。',
      dataSource: '用户输入。',
      logic: '按 mobile 字段做包含匹配。',
      limit: '选填；最多 50 字，仅拦控制字符（inputProps searchKw）。',
      edge:
        '⚠️ 核实代码后发现：mock 的 mobile 字段本身就是脱敏后的展示态字符串（如 138****0203 / mem****@gmail.com，data.ts 生成逻辑写死、注释已注明"模糊查询时两者通用此字段"），并非真实手机号/邮箱原文——本框实际能查到的只是这串打码文本里的可见片段（如前几位数字、或 @ 后的域名），不是按完整真实号码/邮箱全文检索；列表渲染时还会对这个已打码的值再调一次 maskEmail/maskPhone，因格式恰好吻合而不改变显示结果。这是 mock 数据设计如此，非本次引入。',
    },
    {
      anchor: 'code',
      name: '验证码',
      group: '搜索',
      interaction: '文本输入。',
      dataSource: '用户输入。',
      logic: '按验证码做包含匹配。',
      limit: '选填；最多 32 字，仅字母数字（inputProps code）。',
      edge:
        '空 = 不按验证码筛；如实记录：表格 11 列里没有独立的「验证码」列，验证码原文只出现在「内容」列的文案里（如"验证码 1234，请勿泄露。"）——本搜索项按 code 字段本身匹配，能正确查到结果，只是查到后要在"内容"列文案里找验证码，而非有专属列直接展示。',
    },
    {
      anchor: 'bizType',
      name: '业务类型',
      group: '搜索',
      interaction:
        '下拉单选，可清空（未显式设 filterable，落到 NSelect 默认值、不可搜索——4 个固定选项符合《交互规范》§2"选项少不需要开"的惯例）。',
      dataSource:
        '本地枚举（非字典）：登录验证 / 注册验证 / 绑定手机 / 重置密码，与列表「业务类型」列共用同一份 bizTypeLabel 映射。',
      logic: '按业务类型精确过滤（bizType === Number(选中值)）。',
      limit: '选填。',
      edge: '空 = 不按业务类型筛。',
    },
    {
      anchor: 'sendIp',
      name: '发送IP',
      group: '搜索',
      interaction: '文本输入。',
      dataSource: '用户输入。',
      logic: '按发送IP做包含匹配。',
      limit: '选填；最多 45 字，仅数字/点/冒号/十六进制字符（inputProps ip）。',
      edge: '空 = 不按发送IP筛。',
    },

    // ============ 列 ============
    {
      anchor: 'col_memberId',
      name: '会员ID列（两态：已注册可点 / 未注册灰标签）',
      group: '列',
      interaction:
        '已注册记录：会员ID以可点击蓝字链接形式展示（跳转类控件）；命中"已发码但未注册"记录时改为不可点的灰色「未注册」标签（NTag type=default）。',
      dataSource:
        '行数据 memberId（null=未注册）；mock 生成规则：仅 bizType=2(注册验证) 且 i%8===1 的记录落入未注册态，其余（含大多数 bizType=2 记录）恒有 memberId。',
      logic:
        '点击已注册会员ID → 调 openMemberDetailModal(memberId, tenantId) 打开全站共用「会员详情」弹窗（来自 useUser hook，非本页专属组件）。',
      note:
        '"未注册"态对应真实业务场景：验证码在会员账户尚未生成前就已发送（如注册流程本身），此时还没有可跳转的会员账户。',
    },
  ],

  // ============ 字段介绍 tab（列序照页面；仅列表列 + 定义）============
  fields: [
    { name: '商户', def: '该验证码发送记录所属的商户（renderTenantTag，格式"商户号(商户名)"）。' },
    {
      name: '会员ID',
      def: '关联的会员ID；若验证码发送时账户尚未生成（如注册流程本身），则为空、列表显示"未注册"灰标签。',
    },
    {
      name: '短信/邮箱厂商',
      def: '发出该条验证码所用的短信厂商或邮箱厂商（按联系方式类型对应短信/邮箱两套厂商池，纯展示）。',
    },
    {
      name: '手机号/邮箱',
      def: '接收验证码的手机号或邮箱，脱敏展示（手机 138****0203 / 邮箱 前3位****@域名），前置类型 Tag 区分"手机"/"邮箱"；mock 该字段本身即以脱敏态存储，并非真实号码/邮箱原文。',
    },
    { name: '业务类型', def: '发送该验证码所服务的业务场景：登录验证 / 注册验证 / 绑定手机 / 重置密码。' },
    {
      name: '内容',
      def: '发送的短信/邮件正文内容（含验证码原文）；表格没有独立的「验证码」列，验证码只能在这里看到。',
    },
    { name: '发送时间', def: '该条验证码的发送时间。' },
    {
      name: '失效时间',
      def: '该条验证码的过期时间；mock 按业务类型给不同有效期（5/10/15/30分钟，对应登录/注册/绑定手机/重置密码）叠加到发送时间算出。',
    },
    {
      name: '状态',
      def: '该次发送是否成功（发送成功 / 发送失败），只读语义 Tag（绿/红）——是这条历史发送记录的结果状态，不是可切换的启用/禁用开关，不受 R47 约束。',
    },
    { name: '发送IP', def: '发起该次验证码发送请求时的来源 IP。' },
    { name: '三方信息', def: '该次发送在短信/邮件三方通道侧的回执信息（通道名 + 三方流水号）。' },
  ],
};

export default manual;
