/**
 * @description 弹窗标题渲染层：渲染「标题文字 + 紧贴 8px 的圆形 quaternary 全屏切换按钮」，支持 prefix / suffix 槽位注入额外节点（如审单耗时计时器、Reviewing tag）。是 ProFullscreenModal 基座的渲染层。
 * @date 2026-05-08
 * @scope src/components/ProComponents/ProFullscreenModal
 */

import { h, type Ref, type VNodeChild } from 'vue';
import { NButton, NIcon } from 'naive-ui';
import { FullscreenExitOutlined, FullscreenOutlined } from '@vicons/antd';

export interface RenderFullscreenTitleOptions {
  /** 主标题文字（已 i18n 渲染） */
  title: string;
  /** 是否全屏的响应式 ref */
  isFullscreen: Ref<boolean>;
  /** 全屏按钮点击回调 */
  onToggle: () => void;
  /** 标题之前注入（例如图标） */
  prefix?: () => VNodeChild;
  /** 标题与全屏按钮之间注入（例如审单耗时 + Reviewing tag） */
  suffix?: () => VNodeChild;
  /** 全屏按钮之后注入 */
  extra?: () => VNodeChild;
}

/**
 * 渲染弹窗顶部的"标题 + 全屏按钮"。
 *
 * 默认布局（左 → 右）：
 *   [prefix?] [title] [suffix?] [全屏按钮] [extra?]
 *
 * 全屏按钮**紧贴**主标题（gap: 8px），不会被推到弹窗右上角的关闭 X 旁边。
 */
export function renderFullscreenTitle(options: RenderFullscreenTitleOptions): VNodeChild {
  const { title, isFullscreen, onToggle, prefix, suffix, extra } = options;

  return h('div', { class: 'inline-flex items-center gap-2' }, [
    prefix?.(),
    h('span', { class: 'text-base font-semibold text-slate-800' }, title),
    suffix?.(),
    h(
      NButton,
      { quaternary: true, circle: true, size: 'small', onClick: onToggle },
      {
        icon: () =>
          h(NIcon, { size: 16 }, () =>
            h(isFullscreen.value ? FullscreenExitOutlined : FullscreenOutlined),
          ),
      },
    ),
    extra?.(),
  ]);
}
