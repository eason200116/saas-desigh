import type { TiptapAiActionDefinition, TiptapAiActionRequest } from './types';

export function getTiptapAiActions(t: (key: string) => string): TiptapAiActionDefinition[] {
  return [
    {
      key: 'continue',
      label: t('common.tiptap.aiContinue'),
      description: t('common.tiptap.aiContinueDescription'),
      defaultInstruction: t('common.tiptap.aiContinueDefaultInstruction'),
    },
    {
      key: 'generate',
      label: t('common.tiptap.aiGenerate'),
      description: t('common.tiptap.aiGenerateDescription'),
      defaultInstruction: t('common.tiptap.aiGenerateDefaultInstruction'),
    },
    {
      key: 'rewrite',
      label: t('common.tiptap.aiRewrite'),
      description: t('common.tiptap.aiRewriteDescription'),
      requiresSelection: true,
      defaultInstruction: t('common.tiptap.aiRewriteDefaultInstruction'),
    },
    {
      key: 'expand',
      label: t('common.tiptap.aiExpand'),
      description: t('common.tiptap.aiExpandDescription'),
      requiresSelection: true,
      defaultInstruction: t('common.tiptap.aiExpandDefaultInstruction'),
    },
    {
      key: 'shorten',
      label: t('common.tiptap.aiShorten'),
      description: t('common.tiptap.aiShortenDescription'),
      requiresSelection: true,
      defaultInstruction: t('common.tiptap.aiShortenDefaultInstruction'),
    },
    {
      key: 'translate',
      label: t('common.tiptap.aiTranslate'),
      description: t('common.tiptap.aiTranslateDescription'),
      requiresSelection: true,
      defaultInstruction: t('common.tiptap.aiTranslateDefaultInstruction'),
    },
    {
      key: 'polish',
      label: t('common.tiptap.aiPolish'),
      description: t('common.tiptap.aiPolishDescription'),
      defaultInstruction: t('common.tiptap.aiPolishDefaultInstruction'),
    },
  ];
}

function getActionInstruction(request: TiptapAiActionRequest) {
  switch (request.action) {
    case 'continue':
      return '请延续当前文档风格，继续补全后续内容，直接输出可粘贴正文。';
    case 'generate':
      return '请根据标题、场景和补充要求，生成结构完整、适合运营发布的正文 HTML 片段。';
    case 'rewrite':
      return '请改写选中文本，保留原意但提升表达质量，直接输出改写结果。';
    case 'expand':
      return '请扩写选中文本，补充细节和说明，直接输出扩写结果。';
    case 'shorten':
      return '请压缩选中文本，保留关键信息并更利于快速阅读，直接输出精简结果。';
    case 'translate':
      return '请翻译选中文本并保留原有结构，直接输出翻译结果。';
    case 'polish':
      return '请优化当前文档语气、结构和可读性，直接输出可替换正文。';
    default:
      return '请根据上下文优化文案，直接输出结果。';
  }
}

export function buildTiptapAiPrompt(request: TiptapAiActionRequest) {
  const sections = [
    '你现在是运营富文本编辑器内的写作助手。',
    '输出要求：只返回最终可直接粘贴到编辑器的正文内容，不要加解释，不要加代码围栏。',
    `编辑场景：${request.profile}`,
    `动作：${request.action}`,
    `动作要求：${getActionInstruction(request)}`,
  ];

  if (request.title?.trim()) {
    sections.push(`文档标题：${request.title.trim()}`);
  }

  if (request.instruction?.trim()) {
    sections.push(`补充要求：${request.instruction.trim()}`);
  }

  if (request.selection?.trim()) {
    sections.push(`选中文本：\n${request.selection.trim()}`);
  }

  sections.push(`当前文档：\n${request.document.trim() || '<empty>'}`);

  return sections.join('\n\n');
}

export function shouldReplaceWholeDocument(
  action: TiptapAiActionRequest['action'],
  hasSelection: boolean,
) {
  if (action === 'polish' && !hasSelection) return true;
  if (action === 'generate' && !hasSelection) return true;
  return false;
}
