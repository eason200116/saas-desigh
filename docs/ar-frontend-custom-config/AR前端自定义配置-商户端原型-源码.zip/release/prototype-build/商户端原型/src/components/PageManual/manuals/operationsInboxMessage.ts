// 站内信管理（商户端 tenant · operations_inboxMessage）功能说明书。
// 锚定 src/views/operations/inboxMessage/index.vue(Tab壳) + 3个子Tab
// PopupMessageTab.vue(弹窗消息)/ScrollMessageTab.vue(滚动消息)/PushMessageTab.vue(推送消息)
// + 4个弹窗(InboxMessageFormModal/ScrollMessageFormModal/PushMessageFormModal/PushMessageDetailModal)
// + 共享渲染 langCells.ts + data.ts 真实控件（R53 实证、不臆造）。是operations模块文件数最多的页面(共11个文件)。

import type { PageManual } from '../types';

const manual: PageManual = {
  route: 'operations_inboxMessage',
  title: '站内信管理',
  overview:
    '商户端「运营管理 › 站内信管理」页，容器是一个3标签页壳（弹窗消息 popup 默认 / 滚动消息 scroll / 推送消息 push），' +
    '3个标签页结构上分两类：「弹窗消息」「滚动消息」结构完全相同（各自独立组件+独立数据，仅弹窗标题/存储对象不同），' +
    '均支持多语言（每条消息按所属商户的启用语言集逐语言配置标题+内容，语言集来自 languageConfig「前台配置」按商户' +
    '配置，本页5个mock商户覆盖单/双/三语言场景）；「推送消息」结构不同——单语言（标题+文字+图片，无语言tab，因推送' +
    '走第三方Firebase/极光平台侧配置）、行操作按发送状态区分（未发送=可编辑删除，其余四态=只读详情），列表也多出' +
    '通知名称/渠道/推送设备/接收对象/发送状态/发送时间等推送特有字段。' +
    '2026-07-22核实代码发现：3个Tab的新增/编辑保存(saveInboxMessage/saveScrollMessage/savePushMessage)与删除' +
    '(deleteInboxMessage/deleteScrollMessage/deletePushMessage)全部只返回成功、不真正写回各自底层数组，操作提示' +
    '成功但列表刷新后看不到变化——6个操作mock方法形态一致（同一处历史模板复制），如实记录，未修复。',
  items: [
    {
      anchor: 'tab_switch',
      name: '3个子页Tab切换（弹窗消息/滚动消息/推送消息）',
      group: '操作',
      interaction: '横排Tab，点击切换，默认停在"弹窗消息"。',
    },

    // ============ 弹窗消息 Tab ============
    {
      anchor: 'popup_merchant',
      name: '商户（弹窗消息·搜索）',
      group: '搜索',
      interaction: '下拉筛选。',
    },
    {
      anchor: 'popup_title',
      name: '标题（弹窗消息·搜索）',
      group: '搜索',
      interaction: '文本框，可清空，按默认语言标题模糊匹配。',
    },
    {
      anchor: 'popup_state',
      name: '状态（弹窗消息·搜索）',
      group: '搜索',
      interaction: '下拉单选（启用/禁用），可清空。',
    },
    {
      anchor: 'popup_reset',
      name: '重置（弹窗消息）',
      group: '搜索',
      interaction: 'ProCrudTable内置重置按钮。',
    },
    {
      anchor: 'popup_add',
      name: '新增（弹窗消息）',
      group: '操作',
      interaction: '主色按钮，点击打开新增弹窗（880px宽）。',
      logic:
        '弹窗字段：商户(单选，编辑态置灰) → 排序(数字) → 语言Tab切换(默认语言排首，默认语言标题+内容必填、' +
        '其余选填，标题为普通输入框，内容为富文本编辑器BasicTiptapEditor固定高度320px) → 状态(开关，置于弹窗' +
        '底部)。点"保存并发布"先校验默认语言必填项，通过后弹二次确认预览弹窗（竖版前台样式模拟，可切语言逐个预览' +
        '标题+富文本内容），确认后才真正提交。',
    },
    {
      anchor: 'col_popup_content',
      name: '消息内容·更多（弹窗消息·列）',
      group: '列',
      interaction:
        '默认语言内容截断展示（富文本转纯文本摘要，40字）；已配置语言数>1时额外显示"更多"按钮。',
      logic: '点击"更多"弹出气泡卡片，逐语言列出标题+内容（未配置的语言不展示）。',
    },
    {
      anchor: 'act_popup_edit',
      name: '编辑（弹窗消息·行操作）',
      group: '操作',
      interaction: '每行常驻，点击打开编辑弹窗（字段同新增，回显当前值）。',
    },
    {
      anchor: 'act_popup_delete',
      name: '删除（弹窗消息·行操作）',
      group: '操作',
      interaction: '每行常驻，点击弹二次确认。',
    },

    // ============ 滚动消息 Tab（结构与弹窗消息完全一致，仅数据/弹窗组件独立） ============
    {
      anchor: 'scroll_merchant',
      name: '商户（滚动消息·搜索）',
      group: '搜索',
      interaction: '下拉筛选。',
    },
    {
      anchor: 'scroll_title',
      name: '标题（滚动消息·搜索）',
      group: '搜索',
      interaction: '文本框，可清空，按默认语言标题模糊匹配。',
    },
    {
      anchor: 'scroll_state',
      name: '状态（滚动消息·搜索）',
      group: '搜索',
      interaction: '下拉单选（启用/禁用），可清空。',
    },
    {
      anchor: 'scroll_reset',
      name: '重置（滚动消息）',
      group: '搜索',
      interaction: 'ProCrudTable内置重置按钮。',
    },
    {
      anchor: 'scroll_add',
      name: '新增（滚动消息）',
      group: '操作',
      interaction:
        '主色按钮，点击打开新增弹窗（880px宽，字段/交互与"弹窗消息"新增完全一致，见 popup_add）。',
    },
    {
      anchor: 'col_scroll_content',
      name: '消息内容·更多（滚动消息·列）',
      group: '列',
      interaction:
        '与 col_popup_content 一致，滚动消息内容本身是纯文本（非富文本），摘要不需去标签。',
    },
    {
      anchor: 'act_scroll_edit',
      name: '编辑（滚动消息·行操作）',
      group: '操作',
      interaction: '每行常驻，点击打开编辑弹窗。',
    },
    {
      anchor: 'act_scroll_delete',
      name: '删除（滚动消息·行操作）',
      group: '操作',
      interaction: '每行常驻，点击弹二次确认。',
    },

    // ============ 推送消息 Tab（单语言，结构与前两者不同） ============
    {
      anchor: 'push_merchant',
      name: '商户（推送消息·搜索）',
      group: '搜索',
      interaction: '下拉筛选。',
    },
    {
      anchor: 'push_title',
      name: '标题（推送消息·搜索）',
      group: '搜索',
      interaction: '文本框，可清空。',
    },
    {
      anchor: 'push_sendState',
      name: '发送状态（推送消息·搜索）',
      group: '搜索',
      interaction: '下拉单选，可清空；选项：未发送/发送中/成功/部分成功/失败。',
    },
    {
      anchor: 'push_reset',
      name: '重置（推送消息）',
      group: '搜索',
      interaction: 'ProCrudTable内置重置按钮。',
    },
    {
      anchor: 'push_add',
      name: '新增（推送消息）',
      group: '操作',
      interaction: '主色按钮，点击打开新增弹窗（720px宽）。',
      logic:
        '弹窗字段：商户(单选，编辑态置灰) → 标题/文字(均单语言，无语言Tab) → 图片上传(ImageUploadField) → ' +
        '推送渠道(下拉：Firebase/极光) → 发送时间(日期时间选择) → 推送终端(仅渠道=极光时显示，复选框：WEB/APP) → ' +
        '通知名称/链接(渠道决定标签文案：Firebase=名称、极光=链接) → 接收对象(单选：全体/指定用户) → ' +
        '指定用户ID(仅接收对象=指定用户时显示，多行文本框逗号分隔)。',
    },
    {
      anchor: 'col_push_content',
      name: '通知内容（推送消息·列，标题+文字+图片合一）',
      group: '列',
      interaction: '标题+文字(截断50字)+图片缩略图；图片hover弹出放大预览(气泡)。',
    },
    {
      anchor: 'act_push_edit',
      name: '编辑（推送消息·行操作，条件显示）',
      group: '操作',
      interaction: '仅"发送状态=未发送"的行显示，点击打开编辑弹窗（字段同新增）。',
    },
    {
      anchor: 'act_push_delete',
      name: '删除（推送消息·行操作，条件显示）',
      group: '操作',
      interaction: '仅"发送状态=未发送"的行显示，点击弹二次确认。',
    },
    {
      anchor: 'act_push_detail',
      name: '详情（推送消息·行操作，条件显示）',
      group: '操作',
      interaction:
        '"发送状态≠未发送"（发送中/成功/部分成功/失败）的行显示，点击打开只读详情弹窗（PushMessageDetailModal，字段同新增弹窗但全部禁用不可编辑）。',
    },
  ],
  fields: [
    { name: '商户（弹窗/滚动/推送 通用列）', def: '该消息所属商户，标签展示。' },
    { name: 'ID（弹窗/滚动/推送 通用列）', def: '该条消息记录的唯一编号。' },
    {
      name: '标题（弹窗/滚动列，按默认语言展示）',
      def: '该消息标题的默认语言值；其余语言见"更多"弹层。',
    },
    {
      name: '消息内容（弹窗/滚动列）',
      def: '该消息内容的默认语言摘要，见交互条目 col_popup_content/col_scroll_content。',
    },
    {
      name: '已配语言（弹窗/滚动列）',
      def: '该消息所属商户支持的每种语言一个Tag：默认语言标"默认"(蓝)、已填写(绿)、未填写(灰"未配置")。',
    },
    { name: '排序（弹窗/滚动列）', def: '数值，决定该消息在前台的展示顺序。' },
    { name: '最后修改时间（弹窗/滚动列）', def: '该消息最近一次编辑保存的时间。' },
    { name: '最后修改人（弹窗/滚动列）', def: '最近一次编辑该消息的操作人账号。' },
    { name: '状态（弹窗/滚动列）', def: '启用/禁用，只读Tag，恒排最后一个数据列。' },
    { name: '通知内容（推送列）', def: '标题+文字+图片合并展示，见交互条目 col_push_content。' },
    {
      name: '通知名称/链接（推送列）',
      def: '极光渠道=推送平台侧配置的链接地址；Firebase渠道=推送平台侧配置的通知名称。',
    },
    { name: '渠道（推送列）', def: 'Firebase / 极光 两种推送通道，Tag展示。' },
    { name: '推送设备（推送列）', def: '仅极光渠道有值(WEB设备/APP设备)，Firebase恒显示"-"。' },
    { name: '接收对象（推送列）', def: '全体会员 / 指定用户，Tag展示。' },
    {
      name: '发送状态（推送列）',
      def: '未发送/发送中/成功/部分成功/失败 五态，Tag展示（成功=绿，失败=红，其余默认色）。',
    },
    { name: '发送时间（推送列）', def: '该推送任务计划/实际发送的时间。' },
    { name: '最后修改时间（推送列）', def: '该推送任务记录最近一次修改的时间。' },
    { name: '最后修改人（推送列）', def: '创建/最近操作该推送任务的账号。' },
  ],
};

export default manual;
