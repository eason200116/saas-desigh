// 邮件商配置（商户端 tenant · operations_emailConfig）功能说明书。
// 锚定 src/views/operations/emailConfig/index.vue（新增/编辑弹窗内联在同一文件，无独立组件）+ data.ts 真实控件（R53 实证、不臆造）。
// 排版/结构对齐「短信商配置」页（同批次姊妹页）。

import type { PageManual } from '../types';

const manual: PageManual = {
  route: 'operations_emailConfig',
  title: '邮件商配置',
  overview:
    '商户端「运营管理 › 邮件商配置」页，维护平台对外发信用的邮件服务商账号配置（SMTP账号/API密钥等），' +
    '每条配置归属单一商户。列表仅展示商户/自定义名称/供应商/Logo/邮件内容/备注，其余字段(账号/密码/服务器/' +
    '端口/状态等)收在编辑弹窗内。密码与API密钥编辑回显时脱敏(前4后4中间***)，重新输入即覆盖明文。' +
    '2026-07-22核实代码发现：保存(saveEmailConfig)只返回成功、不真正写回底层数组，操作提示成功但列表刷新' +
    '看不到变化；另外 data.ts 里定义的 updateEmailConfigState(单独状态切换)、deleteEmailConfig(删除) 两个' +
    'mock方法在index.vue里完全没有被调用——本页没有独立的启用/禁用开关或删除按钮，状态只能通过编辑弹窗内的' +
    '开关连同其它字段一起保存。如实记录，未修复。',
  items: [
    {
      anchor: 'merchant',
      name: '商户',
      group: '搜索',
      interaction: '下拉筛选。',
    },
    {
      anchor: 'provider',
      name: '邮件供应商',
      group: '搜索',
      interaction: '下拉单选，可清空。',
    },
    {
      anchor: 'name',
      name: '自定义名称',
      group: '搜索',
      interaction: '文本框，可清空，模糊匹配。',
    },
    {
      anchor: 'reset',
      name: '重置',
      group: '搜索',
      interaction: 'ProCrudTable内置重置按钮。',
    },
    {
      anchor: 'act_add',
      name: '新增',
      group: '操作',
      interaction: '主色按钮，点击打开新增弹窗（920px宽）。',
      logic:
        '字段顺序固定：商户(必选，新增可选/编辑置灰) → 邮件供应商(必选下拉，新增可选/编辑禁用，选择后' +
        '联动自定义名称默认取供应商名) → 自定义名称(必填，可改) → 邮件标题(必填) → 邮箱账号(必填) → ' +
        '邮箱密码(必填，编辑回显脱敏) → API商户号(选填) → API密钥(选填，编辑回显脱敏) → 邮箱服务器(必填) → ' +
        '邮箱端口(必填，1-65535) → 邮箱Logo(必填，图片上传) → 状态(开关) → 备注(选填)。',
    },
    {
      anchor: 'col_logo',
      name: 'Logo（列，悬停放大）',
      group: '列',
      interaction: '缩略图展示，有值时hover弹出放大预览；无值显示"-"。',
    },
    {
      anchor: 'act_edit',
      name: '编辑',
      group: '操作',
      interaction: '每行常驻，点击打开编辑弹窗（字段同新增，回显当前值，密码/密钥脱敏显示）。',
    },
  ],
  fields: [
    { name: '商户（列）', def: '该邮件配置所属商户，标签展示。' },
    { name: '自定义名称', def: '该邮件配置的展示名称，为空展示"-"。' },
    { name: '邮件供应商', def: '所选邮件服务商品牌名，为空展示"-"。' },
    { name: 'Logo', def: '邮件模板使用的品牌Logo图，见交互条目 col_logo。' },
    { name: '邮件内容', def: '邮件正文模板内容(只读)，来源V1脚本，多行完整展示不截断。' },
    { name: '备注', def: '补充说明信息，多行完整展示不截断，为空展示"-"。' },
  ],
};

export default manual;
