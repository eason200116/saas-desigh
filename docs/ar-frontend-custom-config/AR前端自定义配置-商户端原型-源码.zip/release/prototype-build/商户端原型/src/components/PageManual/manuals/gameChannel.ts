// 游戏通道管理（总控端 admin · game_channel）功能说明书。
// 锚定 src/views/game/channel/index.vue + data.ts 真实控件（R53 实证、不臆造）。
// 标准 ProCrudTable 列表页：8 搜索项 + 17 列 + 顶部「新增」+ 3 行操作。

import type { PageManual } from '../types';

const manual: PageManual = {
  route: 'game_channel',
  title: '游戏通道管理',
  overview:
    '总控端配置第三方游戏「通道」（厂商 × 商户号 × 币种的一条接入通道）：定义通道身份（厂商 / 供应商 / 商户号 / API 域名 / 币种与转换比例），启停通道（三态），可新增 / 编辑 / 复制通道。列表按搜索条件过滤、默认居中展示。',
  items: [
    // ============ 搜索区（点了联动）============
    {
      anchor: 'channelId',
      name: '通道ID',
      group: '搜索',
      interaction: '文本输入。',
      dataSource: '用户输入。',
      logic: '按通道 ID 精确/模糊筛选。',
      limit: '选填；仅整数、最多 9 位（inputProps intNum）。',
      edge: '空 = 不按 ID 筛。',
    },
    {
      anchor: 'factoryCode',
      name: '厂商名称',
      group: '搜索',
      interaction: '下拉单选、可清空。',
      dataSource: '厂商选项，来自 api.game.channelGetFactoryOptions（页面加载时拉取）。',
      logic: '筛选该厂商下的通道。',
      limit: '选填。',
      edge: '不选 = 不按厂商筛。',
    },
    {
      anchor: 'vendor',
      name: '供应商',
      group: '搜索',
      interaction: '下拉单选、可清空。',
      dataSource: '供应商选项，来自 api.game.channelGetVendorOptions。',
      logic: '筛选该供应商的通道。',
      limit: '选填。',
      edge: '不选 = 不按供应商筛。',
    },
    {
      anchor: 'merchantNo',
      name: '商户号',
      group: '搜索',
      interaction: '文本输入、模糊匹配。',
      dataSource: '用户输入。',
      logic: '按通道商户号模糊筛选。',
      limit: '选填；最多 50 字（inputProps searchKw）。',
      edge: '空 = 不按商户号筛。',
    },
    {
      anchor: 'channelType',
      name: '通道类型',
      group: '搜索',
      interaction: '下拉单选：正式 / 演示，可清空。',
      dataSource: '本地枚举（正式 = 1 / 演示 = 2）。',
      logic: '按通道类型筛选。',
      limit: '选填。',
      edge: '不选 = 全部类型。',
    },
    {
      anchor: 'systemCurrency',
      name: '系统币种',
      group: '搜索',
      interaction: '下拉单选、可清空。',
      dataSource: '币种选项，来自 api.game.channelGetCurrencyOptions。',
      logic: '筛选支持该系统币种的通道。',
      limit: '选填。',
      edge: '不选 = 不按币种筛。',
    },
    {
      anchor: 'isDeprecated',
      name: '是否弃用',
      group: '搜索',
      interaction: '下拉单选：是 / 否，可清空。',
      dataSource: '本地枚举（是 = 1 / 否 = 0）。',
      logic: '按是否已弃用筛选通道。',
      limit: '选填。',
      edge: '不选 = 不按弃用状态筛。',
    },
    {
      anchor: 'search_state',
      name: '状态（搜索）',
      group: '搜索',
      interaction: '下拉单选：禁用 / 启用 / 维护中（三态），可清空。',
      dataSource: '复用全局枚举 game.status（0 禁用 / 1 启用 / 2 维护中）。',
      logic: '按通道启停状态筛选列表。',
      limit: '选填。',
      edge: '不选 = 全部状态。',
    },

    // ============ 关键列（状态列点了联动）============
    {
      anchor: 'col_state',
      name: '状态列',
      group: '列',
      interaction: '只读 Tag：启用绿 / 禁用红 / 维护中橙（三态），不可点。',
      dataSource: '行数据 state（0 禁用 / 1 启用 / 2 维护中）。',
      logic: '仅展示通道当前状态；要改状态走右侧行操作「状态」弹窗（三态 radio）。',
      note: '本页有意破例 R47：列用只读 Tag、状态切换移到弹窗。',
    },

    // ============ 操作（顶部新增 + 3 行操作）============
    {
      anchor: 'act_add',
      name: '新增（顶部）',
      group: '操作',
      interaction: '点击顶部「新增」开新增弹窗（约 760px，ChannelFormModal）填写并保存新通道。',
      logic: '保存后刷新列表；新增时状态由 data.ts 固定落「启用」（弹窗内不收状态字段）。',
      limit:
        '表单前端必填 9 项（代码可见 FormRules）：厂商名称 / 供应商 / 商户号 / 商户密钥 / 系统币种 / 通道币种 / 转换比例(数字) / API域名 / 通道类型；其余各类 Key / 登录·下注地址 / 扩展字段选填。真后端唯一性 / 格式校验待 5190 核实。',
    },
    {
      anchor: 'act_edit',
      name: '行操作 · 编辑',
      group: '操作',
      interaction: '点击开编辑弹窗（约 760px），改该通道配置。',
      logic: '保存后刷新列表。',
    },
    {
      anchor: 'act_setState',
      name: '行操作 · 状态',
      group: '操作',
      interaction: '点击开三态 radio 弹窗（约 420px）：禁用 / 启用 / 维护中。',
      logic: '这是本页改通道状态的入口（R47 状态在弹窗、三态）。',
    },
    {
      anchor: 'act_copy',
      name: '行操作 · 通道复制',
      group: '操作',
      interaction: '点击开复制弹窗（约 760px），带出源通道内容供预览编辑后另存为新通道。',
      logic: '以源通道为模板快速新建，减少重复录入。',
    },
  ],

  // ============ 字段介绍 tab（仅列表的列 + 定义；顺序同列序 R44）============
  fields: [
    { name: '通道ID', def: '一条接入通道的唯一编号。' },
    { name: '厂商名称', def: '该通道所属的游戏厂商。' },
    { name: '供应商', def: '提供该通道的供应商。' },
    { name: '商户号', def: '通道在三方侧对应的商户号。' },
    { name: '通道类型', def: '正式 / 演示。' },
    { name: 'API域名', def: '该通道对接三方的接口域名。' },
    { name: '系统币种', def: '平台侧结算币种。' },
    { name: '通道币种', def: '通道（三方）侧的币种。' },
    { name: '转换比例', def: '系统币种与通道币种的换算比例。' },
    { name: '注册数', def: '经该通道注册 / 接入的数量。' },
    { name: '创建人', def: '创建该通道记录的操作账号。' },
    { name: '创建时间', def: '通道记录创建时间（按商户时区展示）。' },
    { name: '最后修改人', def: '最近一次修改该通道的操作账号。' },
    { name: '更新时间', def: '通道记录最近修改时间（按商户时区展示）。' },
    { name: '是否弃用', def: '该通道是否已弃用。' },
    { name: '状态', def: '通道当前启停状态：禁用 / 启用 / 维护中。' },
    { name: '备注', def: '通道的补充说明。' },
  ],
};

export default manual;
