import ChangeLogFab from './index.vue';

export { ChangeLogFab };
export default ChangeLogFab;
