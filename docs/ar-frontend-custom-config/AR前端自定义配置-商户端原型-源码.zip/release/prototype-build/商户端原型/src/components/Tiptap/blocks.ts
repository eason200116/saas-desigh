import { Node, mergeAttributes } from '@tiptap/core';

declare module '@tiptap/core' {
  interface Commands<ReturnType> {
    opsBlocks: {
      insertCalloutBlock: (attrs?: { tone?: 'info' | 'success' | 'warning' }) => ReturnType;
      insertStatusBlock: (attrs?: { tone?: 'info' | 'success' | 'warning' }) => ReturnType;
      insertDateBlock: (attrs?: { label?: string; date?: string }) => ReturnType;
      insertOpsColumns: () => ReturnType;
    };
  }
}

export const CalloutBlock = Node.create({
  name: 'calloutBlock',
  group: 'block',
  content: 'block+',
  defining: true,

  addAttributes() {
    return {
      tone: {
        default: 'info',
      },
    };
  },

  parseHTML() {
    return [{ tag: 'div[data-type="callout-block"]' }];
  },

  renderHTML({ HTMLAttributes }) {
    return [
      'div',
      mergeAttributes(HTMLAttributes, {
        'data-type': 'callout-block',
        class: `tiptap-callout tiptap-callout--${HTMLAttributes.tone || 'info'}`,
      }),
      0,
    ];
  },

  addCommands() {
    return {
      insertCalloutBlock:
        (attrs) =>
        ({ commands }) =>
          commands.insertContent({
            type: this.name,
            attrs: { tone: attrs?.tone || 'info' },
            content: [
              {
                type: 'paragraph',
                content: [{ type: 'text', text: '请补充重点提示内容' }],
              },
            ],
          }),
    };
  },
});

export const StatusBlock = Node.create({
  name: 'statusBlock',
  group: 'block',
  content: 'inline*',
  defining: true,

  addAttributes() {
    return {
      tone: {
        default: 'info',
      },
    };
  },

  parseHTML() {
    return [{ tag: 'p[data-type="status-block"]' }];
  },

  renderHTML({ HTMLAttributes }) {
    return [
      'p',
      mergeAttributes(HTMLAttributes, {
        'data-type': 'status-block',
        class: `tiptap-status tiptap-status--${HTMLAttributes.tone || 'info'}`,
      }),
      0,
    ];
  },

  addCommands() {
    return {
      insertStatusBlock:
        (attrs) =>
        ({ commands }) =>
          commands.insertContent({
            type: this.name,
            attrs: { tone: attrs?.tone || 'info' },
            content: [{ type: 'text', text: '状态说明' }],
          }),
    };
  },
});

export const DateBlock = Node.create({
  name: 'dateBlock',
  group: 'block',
  content: 'inline*',
  defining: true,

  addAttributes() {
    return {
      label: {
        default: '执行时间',
      },
      date: {
        default: '',
      },
    };
  },

  parseHTML() {
    return [{ tag: 'div[data-type="date-block"]' }];
  },

  renderHTML({ HTMLAttributes }) {
    return [
      'div',
      mergeAttributes(HTMLAttributes, {
        'data-type': 'date-block',
        class: 'tiptap-date-block',
      }),
      ['div', { class: 'tiptap-date-block__meta' }, HTMLAttributes.label || '执行时间'],
      ['div', { class: 'tiptap-date-block__value' }, HTMLAttributes.date || '请选择日期'],
      ['div', { class: 'tiptap-date-block__note' }, 0],
    ];
  },

  addCommands() {
    return {
      insertDateBlock:
        (attrs) =>
        ({ commands }) =>
          commands.insertContent({
            type: this.name,
            attrs: {
              label: attrs?.label || '执行时间',
              date: attrs?.date || new Date().toISOString().slice(0, 10),
            },
            content: [{ type: 'text', text: '补充日期说明' }],
          }),
    };
  },
});

export const OpsColumn = Node.create({
  name: 'opsColumn',
  content: 'block+',
  isolating: true,

  parseHTML() {
    return [{ tag: 'div[data-type="ops-column"]' }];
  },

  renderHTML({ HTMLAttributes }) {
    return [
      'div',
      mergeAttributes(HTMLAttributes, {
        'data-type': 'ops-column',
        class: 'tiptap-columns__item',
      }),
      0,
    ];
  },
});

export const OpsColumns = Node.create({
  name: 'opsColumns',
  group: 'block',
  content: 'opsColumn opsColumn',
  isolating: true,
  defining: true,

  parseHTML() {
    return [{ tag: 'div[data-type="ops-columns"]' }];
  },

  renderHTML({ HTMLAttributes }) {
    return [
      'div',
      mergeAttributes(HTMLAttributes, {
        'data-type': 'ops-columns',
        class: 'tiptap-columns',
      }),
      0,
    ];
  },

  addCommands() {
    return {
      insertOpsColumns:
        () =>
        ({ commands }) =>
          commands.insertContent({
            type: this.name,
            content: [
              {
                type: 'opsColumn',
                content: [
                  {
                    type: 'paragraph',
                    content: [{ type: 'text', text: '左侧内容' }],
                  },
                ],
              },
              {
                type: 'opsColumn',
                content: [
                  {
                    type: 'paragraph',
                    content: [{ type: 'text', text: '右侧内容' }],
                  },
                ],
              },
            ],
          }),
    };
  },
});
