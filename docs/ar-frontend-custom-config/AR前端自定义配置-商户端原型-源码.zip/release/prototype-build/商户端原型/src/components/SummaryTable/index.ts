export { default as SummaryTable } from './index.vue';
