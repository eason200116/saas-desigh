import { ref, watch } from 'vue';
import { useI18n } from 'vue-i18n';
import { useUser } from '@/hooks';
import { useMemberContext } from '../useMemberContext';
import { buildWalletData } from './buildWalletData';

/**
 * 钱包信息 Tab 的业务逻辑（懒加载）
 */
export function useWallet() {
  const { t } = useI18n();
  const {
    memberId,
    tenantId: ctxTenantId,
    activeTab,
    detailData,
    queryVersion,
  } = useMemberContext();
  const { fetchWalletInfo } = useUser();

  const walletLoading = ref(false);
  const walletLoaded = ref(false);

  async function loadWalletData(userId: string | number) {
    walletLoading.value = true;
    try {
      // 嵌入弹窗时按订单商户拉取钱包
      const data = await fetchWalletInfo(userId, ctxTenantId.value);
      detailData.value.walletSections = buildWalletData(data, t);
    } catch (e) {
      console.error('加载钱包信息失败', e);
    } finally {
      walletLoading.value = false;
    }
  }

  // 懒加载：切到钱包 tab 时才加载
  watch(
    activeTab,
    (tab) => {
      if (tab === 'wallet' && !walletLoaded.value) {
        walletLoaded.value = true;
        loadWalletData(memberId.value);
      }
    },
    { immediate: true },
  );

  // 上层点击"查询"时，当前在钱包 tab 则重新加载
  watch(queryVersion, () => {
    if (activeTab.value === 'wallet') {
      loadWalletData(memberId.value);
    }
  });

  /** 手动重新加载钱包数据（编辑/新增/删除后调用） */
  function reloadWallet() {
    loadWalletData(memberId.value);
  }

  return { walletLoading, detailData, reloadWallet };
}
