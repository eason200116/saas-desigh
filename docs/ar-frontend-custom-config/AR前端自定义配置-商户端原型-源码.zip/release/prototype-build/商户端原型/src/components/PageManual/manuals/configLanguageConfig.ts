// 前台配置（商户端 tenant · configCenter_languageConfig，路由/文件名为languageConfig，
// 页面真实中文名"前台配置"——锚定ConfigOpLogPopover的page prop实证，非按路由英文名直译）功能说明书。
// 锚定 src/views/operations/languageConfig/index.vue + shared/ConfigOpLogPopover.vue + data.ts
// 真实控件（R53 实证、不臆造；页面真名参见page-names-from-prototype记忆）。单商户配置，整页统一保存。

import type { PageManual } from '../types';

const manual: PageManual = {
  route: 'configCenter_languageConfig',
  title: '前台配置',
  overview:
    '商户端「配置中心 › 前台配置」页(菜单文案"语言配置"，页面/操作记录内部实际标注为"前台配置"，' +
    '对齐源站H5Setting前台参数配置全集，由会员管理迁入)，单商户配置，整页统一"保存"。内容分3个板块：' +
    '①品牌素材(项目名称+项目Logo/头部Logo/网站Icon 3张图，本地预览无真实上传)②语言设置(15种语言勾选' +
    '支持哪些+默认语言下拉)③展示设置(货币符号)。保存前校验：项目名称必填/至少勾1种支持语言/默认语言' +
    '必选，缺项红框+Toast指名。"区号+手机号长度"配置已归入「注册管理」页，本页不重复。2026-07-22核实' +
    '代码未发现真实缺陷。',
  items: [
    {
      anchor: 'tenantId',
      name: '商户',
      group: '搜索',
      interaction: '单一商户条；切换后重新加载该商户的前台配置。',
    },
    {
      anchor: 'onSave',
      name: '保存',
      group: '操作',
      interaction: '顶部工具行按钮，点击先校验(项目名称/支持语言/默认语言)，通过后弹二次确认→确认后整页统一落库生效。',
      limit: '项目名称未填/支持语言一个都没勾/默认语言未选，任一缺失阻止保存并红框+Toast指名缺哪项。',
    },
    {
      anchor: 'projectName',
      name: '项目名称',
      group: '操作',
      interaction: '文本框，必填；前台/App显示的项目(品牌)名称。',
      limit: '必填。',
    },
    {
      anchor: 'projectLogo',
      name: '项目Logo',
      group: '操作',
      interaction: '图片上传卡片，点击选图后本地生成预览URL(原型无真实后端上传)，可再次点击替换/删除。',
    },
    {
      anchor: 'headLogo',
      name: '头部Logo',
      group: '操作',
      interaction: '图片上传卡片，同项目Logo交互。',
    },
    {
      anchor: 'webIco',
      name: '网站Icon',
      group: '操作',
      interaction: '图片上传卡片，同项目Logo交互，建议尺寸更小(ico图标规格)。',
    },
    {
      anchor: 'supportLanguages',
      name: '支持语言',
      group: '操作',
      interaction: '多选复选组，15种语言全部展示可勾选；勾选即代表前台该语言可切换使用。',
      limit: '至少勾选1种。',
    },
    {
      anchor: 'defaultLanguage',
      name: '默认语言',
      group: '操作',
      interaction: '下拉单选，可选全部15种语言(不限于已勾选的支持语言)。',
      limit: '必选；会员首次进入前台时展示的默认语言。',
    },
    {
      anchor: 'currencySymbol',
      name: '货币符号',
      group: '操作',
      interaction: '下拉单选，10种货币符号枚举。',
      logic: '前台金额展示统一使用该符号(与会员实际货币/结算无关，仅展示符号)。',
    },
    {
      anchor: 'opLogIcon',
      name: '操作记录',
      group: '操作',
      interaction: '每个配置项名称旁小图标，点击弹出该配置项最近的操作记录(时间/操作人/内容)，仅查看。',
    },
  ],
  fields: [
    { name: '项目名称', def: '前台/App显示的项目(品牌)名称，对应源站H5ProjectName。' },
    { name: '项目Logo/头部Logo/网站Icon', def: '3处不同展示位置的品牌图片素材，对应源站H5ProjectLogo/H5HeadLogo/H5WebIco。' },
    { name: '支持语言', def: '前台支持并可供会员切换的语言集合，源站FrontSiteLanguageEnum共15种。' },
    { name: '默认语言', def: '会员首次进入前台时的默认显示语言。' },
    { name: '货币符号', def: '前台金额展示使用的货币符号。' },
  ],
};

export default manual;
