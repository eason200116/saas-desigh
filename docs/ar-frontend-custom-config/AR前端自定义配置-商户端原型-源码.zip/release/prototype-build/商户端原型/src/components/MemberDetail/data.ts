// MemberDetail 组件层本地 mock（无后端）。
// 「系统日志」Tab（原「操作记录」，已去子 Tab 合并为单列表）取数：
//   api.v1platform.getMemberSysLogPageList({ userId, tenantId, operationPath, keyWords,
//                                            startTime, endTime, pageNo, pageSize, orderBy }) → 列表
// 会员维度：这些是「针对当前会员」的后台操作记录（会员管理模块）；列/搜索对齐系统管理-系统日志
//   （src/views/system/platformLog），但无商户维度（会员详情商户已锁定）。
// 字段严格对齐 useOperationLog.tableColumns（复用 system/platformLog 的 operationPathParts 渲染）
//   + 复用系统日志「详情」弹窗 Info.vue 消费：
//   logID, tenantId, logType(恒为 2=操作), logTitle(→关键词列),
//   logPage(操作页面·含弹窗层级), logControl(配置项), controlType(控件类型),
//   userName, userIP, userIPArea, userOS, userIE, logDateStr, logState(0/1), logInfo, changedTablesLogJson?
// 各行 logPage/logControl 取自 operationCatalog「会员列表」真实条目，故操作路径级联可命中。

import { moduleOfLogPage } from '@/views/system/platformLog/data';

interface MemberSysLogRecord {
  logID: string;
  tenantId: number;
  logType: number; // 恒为 2=操作（会员维度无后台登录记录）
  logTitle: string;
  logPage?: string; // 操作页面(location，含弹窗层级)
  logControl?: string; // 配置项
  controlType?: string; // 控件类型
  userName: string;
  userIP: string;
  userIPArea: string;
  userOS: string;
  userIE: string;
  logDateStr: string;
  logState: 0 | 1;
  logInfo: string;
  changedTablesLogJson?: string;
}

// 12 条：均为「会员列表」模块对当前会员的后台操作；路径(logPage+logControl)对齐 operationCatalog「会员列表」真实条目故级联可命中；
// 操作员/IP/系统浏览器/状态多样化（R32），含 2 条失败态、开关/文本/数字三类「变更详情」样例。
const MEMBER_SYS_LOGS: MemberSysLogRecord[] = [
  {
    logID: 'ML2026032418451',
    tenantId: 1050,
    logType: 2,
    logTitle: '修改密码',
    logPage: '会员列表 › 修改密码弹窗',
    logControl: '新密码',
    controlType: '文本',
    userName: 'admin001',
    userIP: '10.0.0.12',
    userIPArea: '北京市 / 北京市',
    userOS: 'Mac',
    userIE: 'Chrome 134',
    logDateStr: '2026-03-24 18:45:12',
    logState: 1,
    logInfo: 'admin超管 重置会员「30040000135833」登录密码',
  },
  {
    logID: 'ML2026032418102',
    tenantId: 1050,
    logType: 2,
    logTitle: '领取返佣',
    logPage: '会员列表',
    logControl: '领取返佣',
    controlType: '开关',
    userName: 'ops_wang',
    userIP: '58.62.122.7',
    userIPArea: '广东省 / 广州市',
    userOS: 'Windows',
    userIE: 'Edge 124',
    logDateStr: '2026-03-24 18:10:33',
    logState: 1,
    logInfo: '[禁用] ops王强 将会员「30040000135833」领取返佣 由 启用 改为 禁用',
    changedTablesLogJson:
      '{"tab_user":[[{"name":"canReceiveRebate","desc":"领取返佣","newValue":"0","oldValue":"1"}]]}',
  },
  {
    logID: 'ML2026032417583',
    tenantId: 1050,
    logType: 2,
    logTitle: '对上级返佣',
    logPage: '会员列表',
    logControl: '对上级返佣',
    controlType: '开关',
    userName: 'ops_wang',
    userIP: '58.62.122.7',
    userIPArea: '广东省 / 广州市',
    userOS: 'Windows',
    userIE: 'Edge 124',
    logDateStr: '2026-03-24 17:58:02',
    logState: 1,
    logInfo: '[开启] ops王强 将会员「30040000135833」对上级返佣 由 禁用 改为 启用',
  },
  {
    logID: 'ML2026032417204',
    tenantId: 1050,
    logType: 2,
    logTitle: '红包充值',
    logPage: '会员列表 › 红包充值弹窗',
    logControl: '充值金额',
    controlType: '数字',
    userName: 'admin002',
    userIP: '172.16.0.88',
    userIPArea: '上海市 / 上海市',
    userOS: 'Windows',
    userIE: 'Chrome 124',
    logDateStr: '2026-03-24 17:20:41',
    logState: 1,
    logInfo: 'admin运营 为会员「30040000135833」红包充值，金额 由 0 调整为 88',
    changedTablesLogJson:
      '{"tab_user_wallet":[[{"name":"redPacketAmount","desc":"充值金额","newValue":"88","oldValue":"0"}]]}',
  },
  {
    logID: 'ML2026032416555',
    tenantId: 1050,
    logType: 2,
    logTitle: '三方信息',
    logPage: '会员列表 › 三方信息弹窗',
    logControl: 'FireBase Token',
    controlType: '文本',
    userName: 'admin001',
    userIP: '10.0.0.12',
    userIPArea: '北京市 / 北京市',
    userOS: 'Mac',
    userIE: 'Chrome 134',
    logDateStr: '2026-03-24 16:55:20',
    logState: 1,
    logInfo: 'admin超管 更新会员「30040000135833」FireBase Token',
  },
  {
    logID: 'ML2026032416306',
    tenantId: 1050,
    logType: 2,
    logTitle: '谷歌验证绑定',
    logPage: '会员列表 › 谷歌验证绑定弹窗',
    logControl: '6位验证码',
    controlType: '文本',
    userName: 'ops_zhang',
    userIP: '203.0.113.55',
    userIPArea: '广东省 / 深圳市',
    userOS: 'Windows',
    userIE: 'Chrome 124',
    logDateStr: '2026-03-24 16:30:09',
    logState: 0,
    logInfo: '[绑定失败] ops张伟 为会员「30040000135833」绑定谷歌验证，验证码错误',
  },
  {
    logID: 'ML2026032415477',
    tenantId: 1050,
    logType: 2,
    logTitle: '极光 Token',
    logPage: '会员列表 › 三方信息弹窗',
    logControl: '极光 Token',
    controlType: '文本',
    userName: 'admin001',
    userIP: '10.0.0.12',
    userIPArea: '北京市 / 北京市',
    userOS: 'Mac',
    userIE: 'Chrome 134',
    logDateStr: '2026-03-24 15:47:33',
    logState: 1,
    logInfo: 'admin超管 更新会员「30040000135833」极光 Token',
  },
  {
    logID: 'ML2026032415108',
    tenantId: 1050,
    logType: 2,
    logTitle: '批量添加用户',
    logPage: '会员列表 › 批量添加用户弹窗',
    logControl: '会员分组',
    controlType: '下拉单选',
    userName: 'admin002',
    userIP: '172.16.0.88',
    userIPArea: '上海市 / 上海市',
    userOS: 'Windows',
    userIE: 'Chrome 124',
    logDateStr: '2026-03-24 15:10:50',
    logState: 1,
    logInfo: 'admin运营 新增会员「30040000135833」，会员分组 归入「VIP专属组」',
  },
  {
    logID: 'ML2026032414329',
    tenantId: 1050,
    logType: 2,
    logTitle: '批量操作参数',
    logPage: '会员列表 › 批量操作参数弹窗(分组/渠道/代理模式)',
    logControl: '目标值(会员分组/渠道/代理模式 三选一)',
    controlType: '下拉单选',
    userName: 'ops_wang',
    userIP: '58.62.122.7',
    userIPArea: '广东省 / 广州市',
    userOS: 'Windows',
    userIE: 'Edge 124',
    logDateStr: '2026-03-24 14:32:18',
    logState: 1,
    logInfo: 'ops王强 批量调整会员「30040000135833」代理模式 为「自营」',
  },
  {
    logID: 'ML2026032413500',
    tenantId: 1050,
    logType: 2,
    logTitle: '批量导入',
    logPage: '会员列表 › 批量导入弹窗',
    logControl: '上传Excel',
    controlType: '上传',
    userName: 'admin003',
    userIP: '45.32.10.8',
    userIPArea: '海外 / 新加坡',
    userOS: 'Linux',
    userIE: 'Chrome 124',
    logDateStr: '2026-03-24 13:50:00',
    logState: 0,
    logInfo: '[导入失败] admin客服 批量导入会员时第 5 行「30040000135833」账号已存在',
  },
  {
    logID: 'ML2026032413111',
    tenantId: 1050,
    logType: 2,
    logTitle: '批量添加用户',
    logPage: '会员列表 › 批量添加用户弹窗',
    logControl: '邀请码',
    controlType: '文本',
    userName: 'ops_wang',
    userIP: '58.62.122.7',
    userIPArea: '广东省 / 广州市',
    userOS: 'Windows',
    userIE: 'Edge 124',
    logDateStr: '2026-03-24 13:11:26',
    logState: 1,
    logInfo: 'ops王强 为会员「30040000135833」录入邀请码「AR8899」',
  },
  {
    logID: 'ML2026032412402',
    tenantId: 1050,
    logType: 2,
    logTitle: '批量添加用户',
    logPage: '会员列表 › 批量添加用户弹窗',
    logControl: '用户类型',
    controlType: '下拉单选',
    userName: 'admin002',
    userIP: '172.16.0.88',
    userIPArea: '上海市 / 上海市',
    userOS: 'Windows',
    userIE: 'Chrome 124',
    logDateStr: '2026-03-24 12:40:12',
    logState: 1,
    logInfo: 'admin运营 将会员「30040000135833」用户类型 设为「正式会员」',
  },
];

/**
 * 会员系统日志分页（会员维度）。
 * 过滤：operationPath 级联（m:模块 / p:页面 / c:页面::控件）+ keyWords（内容/操作员/IP）+ 时间区间。
 * userId/tenantId 会员维度传入（原型固定演示数据，恒为当前会员）。
 */
async function getMemberSysLogPageList(req: any = {}) {
  const rawPath = Array.isArray(req?.operationPath)
    ? req.operationPath[req.operationPath.length - 1]
    : req?.operationPath;
  const operationPath = String(rawPath ?? '').trim();
  const keyWords = String(req?.keyWords ?? '')
    .trim()
    .toLowerCase();
  const startTime = String(req?.startTime ?? '').trim();
  const endTime = String(req?.endTime ?? '').trim();

  let filtered = MEMBER_SYS_LOGS.slice();
  // 操作路径级联筛选：按叶子值前缀按 模块 / 页面 / 页面+控件 过滤（与系统日志同口径）
  if (operationPath.startsWith('m:')) {
    const mod = operationPath.slice(2);
    filtered = filtered.filter((l) => moduleOfLogPage(l.logPage) === mod);
  } else if (operationPath.startsWith('p:')) {
    const loc = operationPath.slice(2);
    filtered = filtered.filter((l) => l.logPage === loc);
  } else if (operationPath.startsWith('c:')) {
    const [loc, item] = operationPath.slice(2).split('::');
    filtered = filtered.filter((l) => l.logPage === loc && l.logControl === item);
  }
  if (keyWords) {
    filtered = filtered.filter(
      (l) =>
        l.logInfo.toLowerCase().includes(keyWords) ||
        l.userName.toLowerCase().includes(keyWords) ||
        l.userIP.includes(keyWords),
    );
  }
  if (startTime) filtered = filtered.filter((l) => l.logDateStr >= startTime);
  if (endTime) filtered = filtered.filter((l) => l.logDateStr <= endTime);

  const pageSize = Number(req?.pageSize) || 10;
  const pageNo = Number(req?.pageNo) || 1;
  const start = (pageNo - 1) * pageSize;
  const list = filtered.slice(start, start + pageSize);
  return {
    code: 0,
    result: true,
    data: {
      list,
      total: filtered.length,
      totalCount: filtered.length,
      pageNo,
      pageSize,
    },
    msg: 'success',
  };
}

const v1platformOverride: Record<string, (...args: any[]) => Promise<any>> = {
  getMemberSysLogPageList,
};

// 占位 api —— 优先命中 v1platform 的真实 mock 方法，其余走空信封占位
// 视图调用形态保持源项目一致：const { data, result } = await api.<module>.<method>(req);
export const api: any = new Proxy(
  {},
  {
    get(_t, mod: string) {
      return new Proxy(
        {},
        {
          get(_, method: string) {
            if (mod === 'v1platform' && v1platformOverride[method]) {
              return v1platformOverride[method];
            }
            return async (..._args: any[]) => {
              console.warn(
                '[component data placeholder] api.' + mod + '.' + method + ' not implemented',
              );
              return { code: 0, result: true, data: null, msg: 'placeholder' };
            };
          },
        },
      );
    },
  },
);

// 兼容：组件如直接 import http
export const http: any = new Proxy(
  {},
  {
    get(_t, method: string) {
      return async (..._args: any[]) => {
        console.warn('[component http placeholder] http.' + method + ' not implemented');
        return { code: 0, result: true, data: null, msg: 'placeholder' };
      };
    },
  },
);
