// 意见反馈（商户端 tenant · operations_feedback）功能说明书。
// 锚定 src/views/operations/feedback/index.vue + data.ts 真实控件（R53 实证、不臆造）。
// 纯只读查询页，无新增/编辑/删除，甚至无操作列。

import type { PageManual } from '../types';

const manual: PageManual = {
  route: 'operations_feedback',
  title: '意见反馈',
  overview:
    '商户端「运营管理 › 意见反馈」页，只读查询会员提交的意见反馈内容，无任何操作列（无新增/编辑/删除/详情按钮）。' +
    '2026-07-22核实代码发现：组件目录下已建好一个只读详情弹窗 FeedbackDetailModal.vue（描述列表展示会员ID/' +
    '提交时间/反馈全文），但index.vue完全没有导入或触发它（全仓grep确认零引用）——列表"反馈内容"列本身用' +
    'NEllipsis省略长文本，没有可点击查看全文的入口。如实记录，未修复（内容严重程度较低，因该弹窗字段与列表' +
    '本身重合度高，未接入影响相对有限）。',
  items: [
    {
      anchor: 'merchant',
      name: '商户（必选）',
      group: '搜索',
      interaction: '下拉单选，红星必填；未选点查询红框+红字提示。',
      limit: '单选必填（R63）。',
    },
    {
      anchor: 'userId',
      name: '会员ID',
      group: '搜索',
      interaction: '文本框，仅允许数字与空格，可清空。',
    },
    {
      anchor: 'timeRange',
      name: '提交时间',
      group: '搜索',
      interaction: '日期时间区间选择，精确到秒，最长跨度90天，不允许选未来日期。',
      limit: '最长跨度90天。',
    },
    {
      anchor: 'reset',
      name: '重置',
      group: '搜索',
      interaction: 'ProCrudTable内置重置按钮。',
    },
    {
      anchor: 'col_userId',
      name: '会员ID（列，可点击）',
      group: '列',
      interaction: '蓝字可点。',
      logic: '点击打开全站共用「会员详情」弹窗。',
    },
  ],
  fields: [
    { name: '商户（列）', def: '该反馈所属商户，标签展示。' },
    { name: '会员ID', def: '提交反馈的会员编号，可点击进详情，见交互条目 col_userId。' },
    { name: '反馈内容', def: '会员提交的反馈原文，超长省略（NEllipsis），悬停可看部分展开。' },
    { name: '提交时间', def: '该条反馈的提交时间。' },
  ],
};

export default manual;
