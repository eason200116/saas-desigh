import { maskEmail, maskPhone } from '@/utils';

/** 钱包卡片字段 */
export interface WalletField {
  label: string;
  value: string;
}

/** 钱包卡片 */
export interface WalletCard {
  id: string;
  fields: WalletField[];
  /** 编辑弹窗回填的原始数据 */
  payload: Record<string, unknown>;
}

/** 钱包分组 */
export interface WalletSection {
  key: 'bank' | 'ewallet' | 'upi' | 'usdt';
  title: string;
  idLabel: string;
  cards: WalletCard[];
}

/**
 * 将 getUserWalletInfo API 响应转换为钱包展示数据
 * 纯函数，无响应式依赖
 */
export function buildWalletData(
  data: any | null | undefined,
  t: (key: string) => string,
): WalletSection[] {
  // 子列表在 any 中都是非空数组，但 data 可能整体为空
  const source = data ?? ({} as Partial<any>);

  return [
    {
      key: 'bank',
      title: t('member.detail.wallet.bankCardInfo'),
      idLabel: t('member.detail.wallet.cardId'),
      cards: (source.bankCards || []).map(
        (card: any): WalletCard => ({
          id: String(card.bId),
          fields: [
            { label: t('member.detail.wallet.userName'), value: maskPhone(card.mobileNO) || '--' },
            {
              label: t('member.detail.wallet.beneficiaryName'),
              value: card.beneficiaryName || '--',
            },
            { label: t('member.detail.wallet.cardNo'), value: card.accountNo || '--' },
            { label: t('member.detail.wallet.ifscCode'), value: card.ifscCode || '--' },
            { label: t('member.detail.wallet.bankInfo'), value: card.bankName || '--' },
            { label: t('member.detail.wallet.phone'), value: maskPhone(card.mobileNO) || '--' },
            { label: t('member.detail.wallet.email'), value: maskEmail(card.email) || '--' },
            {
              label: t('member.detail.wallet.location'),
              value:
                [card.bankProvinceCode, card.bankCityCode, card.bankBranchAddress]
                  .filter(Boolean)
                  .join(' / ') || '--',
            },
          ],
          payload: {
            bId: card.bId,
            tenantId: card.tenantId,
            userId: card.userId,
            bankId: card.bankId,
            beneficiaryName: card.beneficiaryName,
            accountNo: card.accountNo,
            mobileNO: card.mobileNO,
            ifscCode: card.ifscCode,
            email: card.email,
            bankProvinceCode: card.bankProvinceCode,
            bankCityCode: card.bankCityCode,
            bankBranchAddress: card.bankBranchAddress,
            bankNameStr: card.bankName,
          },
        }),
      ),
    },
    {
      key: 'ewallet',
      title: t('member.detail.wallet.ewalletInfo'),
      idLabel: t('member.detail.wallet.walletId'),
      cards: (source.wallets || []).map(
        (wallet: any): WalletCard => ({
          id: String(wallet.bId),
          fields: [
            {
              label: t('member.detail.wallet.ewalletName'),
              value: wallet.beneficiaryName || '--',
            },
            {
              label: t('member.detail.wallet.phoneOrAccount'),
              value: wallet.phoneOrAccount || wallet.accountNo || '--',
            },
            { label: t('member.detail.wallet.ewallet'), value: wallet.bankName || '--' },
          ],
          payload: {
            bId: wallet.bId,
            tenantId: wallet.tenantId,
            userId: wallet.userId,
            bankId: wallet.bankId,
            beneficiaryName: wallet.beneficiaryName,
            phoneOrAccount: wallet.phoneOrAccount || wallet.accountNo,
            bankNameStr: wallet.bankName,
          },
        }),
      ),
    },
    {
      key: 'upi',
      title: t('member.detail.wallet.upiInfo'),
      idLabel: 'UPI ID',
      cards: (source.upiList || []).map(
        (upi: any): WalletCard => ({
          id: String(upi.bId),
          fields: [
            { label: t('member.detail.wallet.upiType'), value: upi.withTypeName || '--' },
            { label: t('member.detail.wallet.upiName'), value: upi.beneficiaryName || '--' },
            { label: 'UPI ID', value: upi.accountNo || '--' },
            { label: t('member.detail.wallet.mobileNO'), value: maskPhone(upi.mobileNO) || '--' },
          ],
          payload: {
            bId: upi.bId,
            tenantId: upi.tenantId,
            userId: upi.userId,
            withType: upi.withType,
            beneficiaryName: upi.beneficiaryName,
            accountNo: upi.accountNo,
            mobileNO: upi.mobileNO,
            bankCode: upi.bankCode,
          },
        }),
      ),
    },
    {
      key: 'usdt',
      title: t('member.detail.wallet.usdtInfo'),
      idLabel: 'USDT ID',
      cards: (source.usdtList || []).map(
        (usdt: any): WalletCard => ({
          id: String(usdt.bId),
          fields: [
            { label: t('member.detail.wallet.mainNetwork'), value: usdt.bankName || '--' },
            { label: t('member.detail.wallet.usdtAddress'), value: usdt.accountNo || '--' },
            { label: t('member.detail.wallet.addressAlias'), value: usdt.beneficiaryName || '--' },
          ],
          payload: {
            bId: usdt.bId,
            tenantId: usdt.tenantId,
            userId: usdt.userId,
            bankId: usdt.bankId,
            accountNo: usdt.accountNo,
            bankNameStr: usdt.bankName,
            beneficiaryName: usdt.beneficiaryName,
          },
        }),
      ),
    },
  ];
}
