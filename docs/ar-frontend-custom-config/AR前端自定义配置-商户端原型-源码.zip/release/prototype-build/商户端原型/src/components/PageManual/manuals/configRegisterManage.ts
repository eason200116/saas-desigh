// 注册管理（商户端 tenant · configCenter_registerManage）功能说明书。
// 锚定 src/views/operations/registerManage/index.vue + shared/ConfigOpLogPopover.vue + data.ts
// 真实控件（R53 实证、不臆造）。单商户配置，整页统一保存(非逐项/逐组保存，与同模块其它页不同)。

import type { PageManual } from '../types';

const manual: PageManual = {
  route: 'configCenter_registerManage',
  title: '注册管理',
  overview:
    '商户端「配置中心 › 注册管理」页(由会员管理迁入)，单商户配置，整页统一"保存"(区别于本模块多数' +
    '页面的逐项/逐组独立保存)。内容分4个板块：①注册开关(7项，含手机/邮箱注册开关等)②注册限制(单IP/' +
    '同浏览器/同设备注册次数上限)③注册赠送(赠送金额+打码倍数)④可注册手机号(区号+手机号长度，卡片式' +
    '平铺可增删，保存前校验区号/长度是否填写完整，缺失红框+定位到第几张卡)。' +
    'data.ts中另有getCaptchaConfig/saveCaptchaConfig(图形验证码配置)mock方法及注释"作为注册管理第二个' +
    'Tab"，但当前index.vue无任何Tab结构、也未调用这两个方法——是规划中但未接入UI的孤立mock(2026-07-22' +
    '核实，非本次改动引入)。除此之外未发现其它缺陷。',
  items: [
    {
      anchor: 'tenantId',
      name: '商户',
      group: '搜索',
      interaction: '单一商户条；切换后重新加载该商户的全部注册配置。',
    },
    {
      anchor: 'onSave',
      name: '保存',
      group: '操作',
      interaction: '顶部工具行按钮，点击先校验可注册手机号(区号/长度是否都已填)，通过后弹二次确认(展示手机号条数)→确认后整页统一落库生效。',
      limit: '可注册手机号任一行缺区号或长度，阻止保存并红框定位到第一处缺失行。',
    },
    {
      anchor: 'switchToggle',
      name: '注册开关（本体）',
      group: '操作',
      interaction: '开关，切换即改本地表单值，需点顶部"保存"才真正提交生效。',
    },
    {
      anchor: 'numberField',
      name: '数值配置项（注册限制/注册赠送）',
      group: '操作',
      interaction: '数字输入框，最小值0；改动需点顶部"保存"才真正提交生效。',
    },
    {
      anchor: 'currentAreaCode',
      name: '当前国家区号',
      group: '操作',
      interaction: '下拉可搜索，单选。',
    },
    {
      anchor: 'addPhone',
      name: '新增（可注册手机号）',
      group: '操作',
      interaction: '按钮，在卡片列表末尾新增一张空白手机号卡片(区号未选+默认长度10)。',
    },
    {
      anchor: 'removePhone',
      name: '删除（可注册手机号卡片）',
      group: '操作',
      interaction: '每张卡片右上角×按钮，点击直接移除该卡片(无二次确认)，同时清空当前校验错误标记。',
    },
    {
      anchor: 'phoneAreaCode',
      name: '区号（卡片内）',
      group: '操作',
      interaction: '下拉可搜索，单选，只能选合法区号；未选在保存校验时标红框。',
    },
    {
      anchor: 'phoneLength',
      name: '手机号长度（卡片内）',
      group: '操作',
      interaction: '数字输入框，范围6~15位。',
    },
    {
      anchor: 'opLogIcon',
      name: '操作记录',
      group: '操作',
      interaction: '每个配置项名称旁小图标，点击弹出该配置项最近的操作记录(时间/操作人/内容)，仅查看。',
    },
  ],
  fields: [
    { name: '注册开关·手机/邮箱注册', def: '是否允许会员用手机号/邮箱方式注册。' },
    { name: '注册开关·图形验证码/邀请码/隐私协议', def: '注册流程中是否要求填写图形验证码/邀请码/勾选隐私协议。' },
    { name: '注册开关·手机号首位限0/长度校验', def: '迁自开关参数配置-开关配置：注册手机号是否限制首位不为0、后台注册时是否校验手机号长度。' },
    { name: '注册限制·单IP/同浏览器/同设备注册次数', def: '同一IP/浏览器指纹/设备指纹允许注册的账号数量上限。' },
    { name: '注册赠送·赠送金额/打码倍数', def: '新会员注册即送的金额，及该赠送金额对应的打码(有效流水)倍数要求。' },
    { name: '当前国家区号', def: '页面默认展示/新建手机号卡片时参考的区号，来源同国家字典。' },
    { name: '可注册手机号·区号+长度', def: '允许注册使用的手机号区号列表，每个区号对应一个合法手机号位数，卡片式管理。' },
  ],
};

export default manual;
