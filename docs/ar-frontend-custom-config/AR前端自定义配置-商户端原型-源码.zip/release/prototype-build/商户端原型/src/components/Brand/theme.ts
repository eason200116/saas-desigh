export const DEFAULT_BRAND_THEME = '#0960bd';

// SOURCE_PALETTE 是 SVG 渐变的色相基准；transform 会以 DEFAULT_BRAND_THEME 为参照、
// 把这组色板朝当前 themeColor 偏移。所以 SOURCE 的 hue 必须与 DEFAULT_BRAND_THEME（蓝 h≈209）
// 对齐——否则即使 themeColor=DEFAULT，hueShift 也非零，渲染出的颜色与品牌主色色相不一致。
const SOURCE_PALETTE = {
  backgroundStart: '#063a78', // 深蓝
  backgroundMid: '#0960bd', // = DEFAULT_BRAND_THEME，品牌主色
  backgroundEnd: '#7eb1e6', // 浅蓝
  glyphEnd: '#dde9f6', // 玻璃末端浅蓝白
  dotStart: '#f5f8fc', // 点高光近白蓝
  dotEnd: '#5fa9ee', // 点末端亮蓝
  shadow: '#062c5f', // 极深蓝阴影
  outline: '#a3c4ec', // 浅蓝描边
} as const;

interface ColorTransform {
  hueShift: number;
  lightnessShift: number;
  saturationScale: number;
}

export interface BrandPalette {
  backgroundEnd: string;
  backgroundGlowEnd: string;
  backgroundGlowStart: string;
  backgroundMid: string;
  backgroundStart: string;
  dotEnd: string;
  dotStart: string;
  glyphEnd: string;
  glyphStart: string;
  outlineColor: string;
  shadowColor: string;
  surfaceEnd: string;
  surfaceStart: string;
}

export function normalizeHexColor(input?: string) {
  if (!input) return DEFAULT_BRAND_THEME;

  const value = input.trim();
  if (/^#[0-9a-fA-F]{6}$/.test(value)) return value;
  if (/^#[0-9a-fA-F]{3}$/.test(value)) {
    return `#${value[1]}${value[1]}${value[2]}${value[2]}${value[3]}${value[3]}`;
  }
  return DEFAULT_BRAND_THEME;
}

export function getBrandPalette(themeColor?: string, isDark = false): BrandPalette {
  const accent = normalizeHexColor(themeColor);
  const transform = createColorTransform(accent);
  const backgroundStart = mixHex(
    tintSourceColor(SOURCE_PALETTE.backgroundStart, transform, {
      lightnessShift: isDark ? -0.04 : -0.01,
      saturationScale: 0.95,
      hueShift: 4,
    }),
    tintThemeColor(accent, {
      lightnessShift: isDark ? -0.16 : -0.1,
      saturationScale: 1.08,
      hueShift: 4,
    }),
    0.42,
  );
  const backgroundMid = mixHex(
    tintSourceColor(SOURCE_PALETTE.backgroundMid, transform, {
      lightnessShift: isDark ? -0.03 : 0,
    }),
    tintThemeColor(accent, {
      lightnessShift: isDark ? -0.06 : 0,
      saturationScale: 1.04,
    }),
    0.52,
  );
  const backgroundEnd = mixHex(
    tintSourceColor(SOURCE_PALETTE.backgroundEnd, transform, {
      lightnessShift: isDark ? -0.08 : 0.03,
      saturationScale: 0.88,
      hueShift: -6,
    }),
    tintThemeColor(accent, {
      lightnessShift: isDark ? 0.05 : 0.2,
      saturationScale: 0.9,
      hueShift: -8,
    }),
    0.62,
  );
  const glyphEnd = mixHex(
    tintSourceColor(SOURCE_PALETTE.glyphEnd, transform, {
      lightnessShift: isDark ? -0.05 : 0.02,
      saturationScale: 0.4,
      hueShift: -4,
    }),
    tintThemeColor(accent, {
      lightnessShift: isDark ? 0.22 : 0.38,
      saturationScale: 0.32,
      hueShift: -6,
    }),
    0.4,
  );
  const dotStart = mixHex(
    tintSourceColor(SOURCE_PALETTE.dotStart, transform, {
      lightnessShift: isDark ? -0.06 : 0.01,
      saturationScale: 0.24,
      hueShift: -6,
    }),
    tintThemeColor(accent, {
      lightnessShift: isDark ? 0.3 : 0.46,
      saturationScale: 0.18,
      hueShift: -6,
    }),
    0.34,
  );
  const dotEnd = mixHex(
    tintSourceColor(SOURCE_PALETTE.dotEnd, transform, {
      lightnessShift: isDark ? -0.03 : 0.04,
      saturationScale: 1.05,
      hueShift: -4,
    }),
    tintThemeColor(accent, {
      lightnessShift: isDark ? 0.16 : 0.28,
      saturationScale: 1.08,
      hueShift: -4,
    }),
    0.62,
  );
  const shadowColor = mixHex(
    tintSourceColor(SOURCE_PALETTE.shadow, transform, {
      lightnessShift: isDark ? -0.09 : -0.04,
      saturationScale: 0.9,
      hueShift: 8,
    }),
    tintThemeColor(accent, {
      lightnessShift: isDark ? -0.24 : -0.18,
      saturationScale: 0.88,
      hueShift: 8,
    }),
    0.5,
  );
  const outlineColor = mixHex(
    tintSourceColor(SOURCE_PALETTE.outline, transform, {
      lightnessShift: isDark ? -0.1 : -0.02,
      saturationScale: 0.72,
      hueShift: -4,
    }),
    tintThemeColor(accent, {
      lightnessShift: isDark ? 0.02 : 0.14,
      saturationScale: 0.74,
      hueShift: -4,
    }),
    0.56,
  );

  return {
    backgroundStart,
    backgroundMid,
    backgroundEnd,
    backgroundGlowStart: toAlpha(
      mixHex(
        backgroundEnd,
        tintThemeColor(accent, {
          lightnessShift: isDark ? 0.12 : 0.26,
          saturationScale: 0.42,
          hueShift: -10,
        }),
        0.28,
      ),
      isDark ? 0.22 : 0.3,
    ),
    backgroundGlowEnd: toAlpha(mixHex(backgroundEnd, '#ffffff', 0.24), 0),
    surfaceStart: 'rgba(255, 255, 255, 0.22)',
    surfaceEnd: 'rgba(255, 255, 255, 0)',
    glyphStart: '#ffffff',
    glyphEnd,
    dotStart,
    dotEnd,
    shadowColor,
    outlineColor,
  };
}

function createColorTransform(themeColor: string): ColorTransform {
  const source = hexToHsl(DEFAULT_BRAND_THEME);
  const target = hexToHsl(themeColor);

  return {
    hueShift: wrapHue(target.h - source.h),
    lightnessShift: clamp((target.l - source.l) * 0.55, -0.12, 0.12),
    saturationScale: clamp(target.s / Math.max(source.s, 0.01), 0.72, 1.45),
  };
}

function tintSourceColor(
  sourceHex: string,
  transform: ColorTransform,
  options: {
    hueShift?: number;
    lightnessShift?: number;
    saturationScale?: number;
  } = {},
) {
  const { h, l, s } = hexToHsl(sourceHex);

  return hslToHex(
    h + transform.hueShift + (options.hueShift ?? 0),
    clamp(s * transform.saturationScale * (options.saturationScale ?? 1), 0, 1),
    clamp(l + transform.lightnessShift + (options.lightnessShift ?? 0), 0, 1),
  );
}

function tintThemeColor(
  themeHex: string,
  options: {
    hueShift?: number;
    lightnessShift?: number;
    saturationScale?: number;
  } = {},
) {
  const { h, l, s } = hexToHsl(themeHex);

  return hslToHex(
    h + (options.hueShift ?? 0),
    clamp(s * (options.saturationScale ?? 1), 0, 1),
    clamp(l + (options.lightnessShift ?? 0), 0, 1),
  );
}

function mixHex(primary: string, secondary: string, secondaryWeight: number) {
  const weight = clamp(secondaryWeight, 0, 1);
  const first = hexToRgb(primary);
  const second = hexToRgb(secondary);
  const channels = ['r', 'g', 'b'] as const;

  return `#${channels
    .map((channel) =>
      Math.round(first[channel] * (1 - weight) + second[channel] * weight)
        .toString(16)
        .padStart(2, '0'),
    )
    .join('')}`;
}

function toAlpha(hexColor: string, opacity: number) {
  const { b, g, r } = hexToRgb(hexColor);
  return `rgba(${r}, ${g}, ${b}, ${clamp(opacity, 0, 1)})`;
}

function hexToRgb(hexColor: string) {
  const hex = normalizeHexColor(hexColor).slice(1);

  return {
    r: parseInt(hex.slice(0, 2), 16),
    g: parseInt(hex.slice(2, 4), 16),
    b: parseInt(hex.slice(4, 6), 16),
  };
}

function hexToHsl(hexColor: string) {
  const { b, g, r } = hexToRgb(hexColor);
  const red = r / 255;
  const green = g / 255;
  const blue = b / 255;
  const max = Math.max(red, green, blue);
  const min = Math.min(red, green, blue);
  const l = (max + min) / 2;

  if (max === min) {
    return { h: 0, s: 0, l };
  }

  const delta = max - min;
  const s = l > 0.5 ? delta / (2 - max - min) : delta / (max + min);
  let h = 0;

  switch (max) {
    case red:
      h = ((green - blue) / delta + (green < blue ? 6 : 0)) * 60;
      break;
    case green:
      h = ((blue - red) / delta + 2) * 60;
      break;
    default:
      h = ((red - green) / delta + 4) * 60;
      break;
  }

  return { h, s, l };
}

function hslToHex(h: number, s: number, l: number) {
  const hue = wrapHue(h);

  if (s === 0) {
    const channel = Math.round(l * 255)
      .toString(16)
      .padStart(2, '0');
    return `#${channel}${channel}${channel}`;
  }

  const q = l < 0.5 ? l * (1 + s) : l + s - l * s;
  const p = 2 * l - q;
  const red = hueToRgb(p, q, hue / 360 + 1 / 3);
  const green = hueToRgb(p, q, hue / 360);
  const blue = hueToRgb(p, q, hue / 360 - 1 / 3);

  return `#${[red, green, blue]
    .map((channel) =>
      Math.round(channel * 255)
        .toString(16)
        .padStart(2, '0'),
    )
    .join('')}`;
}

function hueToRgb(p: number, q: number, t: number) {
  let channel = t;
  if (channel < 0) channel += 1;
  if (channel > 1) channel -= 1;
  if (channel < 1 / 6) return p + (q - p) * 6 * channel;
  if (channel < 1 / 2) return q;
  if (channel < 2 / 3) return p + (q - p) * (2 / 3 - channel) * 6;
  return p;
}

function wrapHue(value: number) {
  let hue = value % 360;
  if (hue < 0) hue += 360;
  return hue;
}

function clamp(value: number, min: number, max: number) {
  return Math.min(max, Math.max(min, value));
}
