<template>
  <n-el
    tag="div"
    class="tiptap-toolbar flex flex-wrap items-start gap-x-2 gap-y-1.5 rounded-2xl px-2.5 py-2"
  >
    <div class="tiptap-toolbar__cluster flex max-w-full items-center gap-1.5">
      <span
        class="tiptap-toolbar__label text-[11px] font-semibold uppercase leading-none tracking-[0.04em]"
      >
        {{ t('common.tiptap.style') }}
      </span>
      <n-dropdown trigger="click" :options="styleOptions" @select="handleStyleSelect">
        <n-button size="small" secondary class="rounded-lg" :disabled="toolbarDisabled">
          <template #icon>
            <n-icon><FontSizeOutlined /></n-icon>
          </template>
          <span class="max-w-[80px] truncate">{{ currentStyleLabel }}</span>
          <n-icon class="tiptap-toolbar__caret text-[12px]"><CaretDownOutlined /></n-icon>
        </n-button>
      </n-dropdown>
    </div>

    <div class="tiptap-toolbar__cluster flex max-w-full items-center gap-1.5">
      <span
        class="tiptap-toolbar__label text-[11px] font-semibold uppercase leading-none tracking-[0.04em]"
      >
        {{ t('common.tiptap.text') }}
      </span>
      <div class="tiptap-toolbar__group flex items-center gap-1">
        <n-popover trigger="click" placement="bottom-start" :show-arrow="false">
          <template #trigger>
            <n-button
              size="small"
              secondary
              class="rounded-lg px-2"
              :disabled="!canRun(canSetTextColor)"
            >
              <span class="relative inline-flex h-4 items-center justify-center px-0.5">
                <n-icon class="text-[14px]"><FontColorsOutlined /></n-icon>
                <span
                  class="absolute inset-x-0 -bottom-0.5 h-0.5 rounded-full"
                  :style="{ backgroundColor: textColorValue || 'var(--text-color-3)' }"
                />
              </span>
            </n-button>
          </template>

          <div
            class="tiptap-toolbar__color-panel flex w-[248px] flex-col gap-3 p-3"
            :style="popoverThemeStyle"
          >
            <div class="flex items-center justify-between gap-3">
              <span class="tiptap-toolbar__panel-title text-sm font-medium">
                {{ t('common.tiptap.textColor') }}
              </span>
              <button
                type="button"
                class="tiptap-toolbar__panel-action text-xs font-medium transition-colors"
                :disabled="!textColorValue"
                @click="setTextColor(null)"
              >
                {{ t('common.reset') }}
              </button>
            </div>

            <div
              class="tiptap-toolbar__panel-value flex items-center gap-2 rounded-lg border px-2.5 py-2 text-xs"
            >
              <span
                class="tiptap-toolbar__panel-dot inline-flex size-3 shrink-0 rounded-full border"
                :style="{ backgroundColor: textColorValue || 'transparent' }"
              />
              <span class="tiptap-toolbar__panel-text truncate">{{ textColorValue || '--' }}</span>
            </div>

            <n-color-picker
              :value="textColorValue || undefined"
              :modes="['hex']"
              :show-alpha="false"
              :swatches="colorSwatches"
              size="small"
              @complete="handleTextColorChange"
            />
          </div>
        </n-popover>

        <n-popover trigger="click" placement="bottom-start" :show-arrow="false">
          <template #trigger>
            <n-button
              size="small"
              secondary
              class="rounded-lg px-2"
              :disabled="!canRun(canSetBackgroundColor)"
            >
              <span class="relative inline-flex h-4 items-center justify-center px-0.5">
                <n-icon class="text-[14px]"><BgColorsOutlined /></n-icon>
                <span
                  class="absolute inset-x-0 -bottom-0.5 h-0.5 rounded-full"
                  :style="{ backgroundColor: backgroundColorValue || 'var(--border-color)' }"
                />
              </span>
            </n-button>
          </template>

          <div
            class="tiptap-toolbar__color-panel flex w-[248px] flex-col gap-3 p-3"
            :style="popoverThemeStyle"
          >
            <div class="flex items-center justify-between gap-3">
              <span class="tiptap-toolbar__panel-title text-sm font-medium">
                {{ t('common.tiptap.backgroundColor') }}
              </span>
              <button
                type="button"
                class="tiptap-toolbar__panel-action text-xs font-medium transition-colors"
                :disabled="!backgroundColorValue"
                @click="setBackgroundColor(null)"
              >
                {{ t('common.reset') }}
              </button>
            </div>

            <div
              class="tiptap-toolbar__panel-value flex items-center gap-2 rounded-lg border px-2.5 py-2 text-xs"
            >
              <span
                class="tiptap-toolbar__panel-dot inline-flex size-3 shrink-0 rounded-full border"
                :style="{ backgroundColor: backgroundColorValue || 'transparent' }"
              />
              <span class="tiptap-toolbar__panel-text truncate">
                {{ backgroundColorValue || '--' }}
              </span>
            </div>

            <n-color-picker
              :value="backgroundColorValue || undefined"
              :modes="['hex']"
              :show-alpha="false"
              :swatches="colorSwatches"
              size="small"
              @complete="handleBackgroundColorChange"
            />
          </div>
        </n-popover>

        <n-tooltip v-for="item in textItems" :key="item.key" trigger="hover">
          <template #trigger>
            <n-button
              size="small"
              secondary
              class="rounded-lg"
              :type="item.isActive() ? 'primary' : 'default'"
              :disabled="!canRun(item.canRun)"
              @click="item.run"
            >
              <template #icon>
                <n-icon><component :is="item.icon" /></n-icon>
              </template>
            </n-button>
          </template>
          {{ item.title }}
        </n-tooltip>
      </div>
    </div>

    <div class="tiptap-toolbar__cluster flex max-w-full items-center gap-1.5">
      <span
        class="tiptap-toolbar__label text-[11px] font-semibold uppercase leading-none tracking-[0.04em]"
      >
        {{ t('common.tiptap.align') }}
      </span>
      <div class="tiptap-toolbar__group flex items-center gap-1">
        <n-tooltip v-for="item in alignItems" :key="item.key" trigger="hover">
          <template #trigger>
            <n-button
              size="small"
              secondary
              class="rounded-lg"
              :type="item.isActive() ? 'primary' : 'default'"
              :disabled="!canRun(item.canRun)"
              @click="item.run"
            >
              <template #icon>
                <n-icon><component :is="item.icon" /></n-icon>
              </template>
            </n-button>
          </template>
          {{ item.title }}
        </n-tooltip>
      </div>
    </div>

    <div class="tiptap-toolbar__cluster flex max-w-full items-center gap-1.5">
      <span
        class="tiptap-toolbar__label text-[11px] font-semibold uppercase leading-none tracking-[0.04em]"
      >
        {{ t('common.tiptap.structure') }}
      </span>
      <div class="tiptap-toolbar__group flex items-center gap-1">
        <n-tooltip v-for="item in structureItems" :key="item.key" trigger="hover">
          <template #trigger>
            <n-button
              size="small"
              secondary
              class="rounded-lg"
              :type="item.isActive() ? 'primary' : 'default'"
              :disabled="!canRun(item.canRun)"
              @click="item.run"
            >
              <template #icon>
                <n-icon><component :is="item.icon" /></n-icon>
              </template>
            </n-button>
          </template>
          {{ item.title }}
        </n-tooltip>
      </div>
    </div>

    <div class="tiptap-toolbar__cluster flex max-w-full items-center gap-1.5">
      <span
        class="tiptap-toolbar__label text-[11px] font-semibold uppercase leading-none tracking-[0.04em]"
      >
        {{ t('common.tiptap.insert') }}
      </span>

      <n-popover
        :show="showQuickActionPanel"
        trigger="click"
        :placement="insertPopoverPlacement"
        :show-arrow="false"
        :flip="false"
        @update:show="handleQuickActionPanelShow"
      >
        <template #trigger>
          <span ref="insertTriggerRef" class="inline-flex">
            <n-button size="small" secondary class="rounded-lg" :disabled="toolbarDisabled">
              <span>{{ t('common.tiptap.insert') }}</span>
              <n-icon class="tiptap-toolbar__caret text-[12px]"><CaretDownOutlined /></n-icon>
            </n-button>
          </span>
        </template>

        <TiptapInsertPanel
          :items="quickActions"
          :disabled="toolbarDisabled"
          :open="showQuickActionPanel"
          :can-run="canQuickAction"
          @select="handleQuickAction"
        />
      </n-popover>

      <n-dropdown
        v-if="showTable"
        trigger="click"
        :options="tableMenuOptions"
        @select="handleTableSelect"
      >
        <n-button
          size="small"
          secondary
          class="rounded-lg"
          :type="isTableActive ? 'primary' : 'default'"
          :disabled="toolbarDisabled"
        >
          <template #icon>
            <n-icon><TableOutlined /></n-icon>
          </template>
          <span>{{ t('common.tiptap.table') }}</span>
          <n-icon class="tiptap-toolbar__caret text-[12px]"><CaretDownOutlined /></n-icon>
        </n-button>
      </n-dropdown>
    </div>

    <div class="tiptap-toolbar__cluster flex max-w-full items-center gap-1.5">
      <span
        class="tiptap-toolbar__label text-[11px] font-semibold uppercase leading-none tracking-[0.04em]"
      >
        {{ t('common.tiptap.history') }}
      </span>
      <div class="tiptap-toolbar__group flex items-center gap-1">
        <n-tooltip trigger="hover">
          <template #trigger>
            <n-button
              size="small"
              secondary
              class="rounded-lg"
              :disabled="!canRun(canUndo)"
              @click="undo"
            >
              <template #icon>
                <n-icon><UndoOutlined /></n-icon>
              </template>
            </n-button>
          </template>
          {{ t('common.tiptap.undo') }}
        </n-tooltip>

        <n-tooltip trigger="hover">
          <template #trigger>
            <n-button
              size="small"
              secondary
              class="rounded-lg"
              :disabled="!canRun(canRedo)"
              @click="redo"
            >
              <template #icon>
                <n-icon><RedoOutlined /></n-icon>
              </template>
            </n-button>
          </template>
          {{ t('common.tiptap.redo') }}
        </n-tooltip>

        <n-tooltip trigger="hover">
          <template #trigger>
            <n-button
              size="small"
              secondary
              class="rounded-lg"
              :disabled="!canRun(canClearFormatting)"
              @click="clearFormatting"
            >
              <template #icon>
                <n-icon><ClearOutlined /></n-icon>
              </template>
            </n-button>
          </template>
          {{ t('common.tiptap.clearFormatting') }}
        </n-tooltip>
      </div>
    </div>

    <div
      class="tiptap-toolbar__cluster tiptap-toolbar__cluster--utility-start ml-0 flex max-w-full items-center gap-1.5"
    >
      <n-button
        size="small"
        secondary
        class="rounded-lg"
        :disabled="toolbarDisabled"
        @click="emit('source')"
      >
        <template #icon>
          <n-icon><CodeOutlined /></n-icon>
        </template>
        {{ t('common.tiptap.sourceCode') }}
      </n-button>
    </div>

    <div v-if="showPreview" class="tiptap-toolbar__cluster flex max-w-full items-center gap-1.5">
      <n-button size="small" secondary class="rounded-lg" @click="emit('preview')">
        <template #icon>
          <n-icon><EyeOutlined /></n-icon>
        </template>
        {{ t('common.tiptap.preview') }}
      </n-button>
    </div>

    <div class="tiptap-toolbar__cluster flex max-w-full items-center gap-1.5">
      <n-button size="small" type="primary" ghost class="rounded-lg" @click="emit('fullscreen')">
        <template #icon>
          <n-icon><component :is="fullscreenIcon" /></n-icon>
        </template>
        {{ isFullscreen ? t('common.tiptap.exitFullscreen') : t('common.tiptap.fullscreen') }}
      </n-button>
    </div>
  </n-el>
</template>

<script setup lang="ts">
  import { computed, nextTick, ref, toRef, type CSSProperties } from 'vue';
  import { useEventListener } from '@vueuse/core';
  import { useThemeVars } from 'naive-ui';
  import {
    BgColorsOutlined,
    CaretDownOutlined,
    ClearOutlined,
    CodeOutlined,
    EyeOutlined,
    FontColorsOutlined,
    RedoOutlined,
    TableOutlined,
    UndoOutlined,
  } from '@vicons/antd';
  import { TIPTAP_COLOR_SWATCHES } from './constants';
  import TiptapInsertPanel from './TiptapInsertPanel.vue';
  import { useTiptapToolbar, type TiptapToolbarProps } from './toolbar';
  import type { TiptapQuickActionItem } from './types';

  interface Props extends TiptapToolbarProps {
    quickActions?: TiptapQuickActionItem[];
  }

  const props = withDefaults(defineProps<Props>(), {
    refreshKey: 0,
    disabled: false,
    readonly: false,
    showImage: true,
    showTable: true,
    showPreview: true,
    isFullscreen: false,
    quickActions: () => [],
  });

  const emit = defineEmits<{
    link: [];
    image: [];
    preview: [];
    source: [];
    fullscreen: [];
    'quick-action': [key: string];
  }>();

  const INSERT_PANEL_WIDTH = 400;
  const INSERT_PANEL_HEIGHT = 300;
  const INSERT_PANEL_GAP = 24;

  const themeVars = useThemeVars();
  const insertTriggerRef = ref<HTMLElement | null>(null);
  const showQuickActionPanel = ref(false);
  const insertPopoverPlacement = ref<'bottom-start' | 'bottom-end' | 'top-start' | 'top-end'>(
    'bottom-start',
  );
  const popoverThemeStyle = computed<CSSProperties>(() => ({
    '--tiptap-toolbar-popover-bg': themeVars.value.popoverColor,
    '--tiptap-toolbar-card-bg': themeVars.value.cardColor,
    '--tiptap-toolbar-muted-bg': themeVars.value.actionColor,
    '--tiptap-toolbar-border': themeVars.value.borderColor,
    '--tiptap-toolbar-text': themeVars.value.textColor1,
    '--tiptap-toolbar-text-2': themeVars.value.textColor2,
    '--tiptap-toolbar-text-3': themeVars.value.textColor3,
    '--tiptap-toolbar-primary': themeVars.value.primaryColor,
    '--tiptap-toolbar-primary-soft': themeVars.value.primaryColorSuppl,
  }));
  const colorSwatches = TIPTAP_COLOR_SWATCHES;

  const {
    t,
    toolbarDisabled,
    isTableActive,
    currentStyleLabel,
    fullscreenIcon,
    textColorValue,
    backgroundColorValue,
    textItems,
    alignItems,
    structureItems,
    styleOptions,
    tableMenuOptions,
    canRun,
    canUndo,
    canRedo,
    canClearFormatting,
    canSetTextColor,
    canSetBackgroundColor,
    handleStyleSelect,
    handleTableSelect,
    undo,
    redo,
    clearFormatting,
    setTextColor,
    setBackgroundColor,
    FontSizeOutlined,
  } = useTiptapToolbar({
    editor: toRef(props, 'editor'),
    refreshKey: toRef(props, 'refreshKey'),
    disabled: toRef(props, 'disabled'),
    readonly: toRef(props, 'readonly'),
    showImage: toRef(props, 'showImage'),
    showTable: toRef(props, 'showTable'),
    isFullscreen: toRef(props, 'isFullscreen'),
    onLink: () => emit('link'),
    onImage: () => emit('image'),
  });

  function canQuickAction(item: TiptapQuickActionItem) {
    if (toolbarDisabled.value) return false;
    return item.canRun ? canRun(item.canRun) : true;
  }

  function handleQuickAction(key: string) {
    emit('quick-action', key);
    showQuickActionPanel.value = false;
  }

  async function handleQuickActionPanelShow(show: boolean) {
    showQuickActionPanel.value = show;
    if (!show) return;

    await nextTick();
    updateInsertPopoverPlacement();
  }

  function updateInsertPopoverPlacement() {
    if (typeof window === 'undefined') return;

    const trigger = insertTriggerRef.value;
    if (!trigger) return;

    const rect = trigger.getBoundingClientRect();
    const spaceAbove = rect.top;
    const spaceBelow = window.innerHeight - rect.bottom;
    const spaceLeft = rect.right;
    const spaceRight = window.innerWidth - rect.left;

    const vertical =
      spaceBelow < INSERT_PANEL_HEIGHT + INSERT_PANEL_GAP && spaceAbove > spaceBelow
        ? 'top'
        : 'bottom';
    const horizontal =
      spaceRight < INSERT_PANEL_WIDTH + INSERT_PANEL_GAP && spaceLeft > spaceRight
        ? 'end'
        : 'start';

    insertPopoverPlacement.value = `${vertical}-${horizontal}`;
  }

  function handleTextColorChange(color: string) {
    setTextColor(color);
  }

  function handleBackgroundColorChange(color: string) {
    setBackgroundColor(color);
  }

  useEventListener(window, 'resize', () => {
    if (!showQuickActionPanel.value) return;
    updateInsertPopoverPlacement();
  });
</script>

<style scoped>
  .tiptap-toolbar {
    container-type: inline-size;
    container-name: tiptap-toolbar;
    border: 1px solid var(--border-color);
    background: var(--popover-color);
    box-shadow:
      0 1px 2px rgba(15, 23, 42, 0.04),
      0 12px 32px rgba(15, 23, 42, 0.06);
  }

  .tiptap-toolbar__cluster {
    min-width: 0;
    position: relative;
    flex: 0 1 auto;
    flex-wrap: wrap;
  }

  .tiptap-toolbar__group {
    min-width: 0;
    flex-wrap: wrap;
  }

  .tiptap-toolbar__label {
    display: none;
    color: var(--text-color-3);
  }

  .tiptap-toolbar__caret {
    color: var(--text-color-3);
  }

  .tiptap-toolbar__color-panel {
    background: var(--tiptap-toolbar-popover-bg);
  }

  .tiptap-toolbar__panel-title {
    color: var(--tiptap-toolbar-text);
  }

  .tiptap-toolbar__panel-action {
    color: var(--tiptap-toolbar-text-3);
  }

  .tiptap-toolbar__panel-action:hover {
    color: var(--tiptap-toolbar-text);
  }

  .tiptap-toolbar__panel-value {
    border-color: var(--tiptap-toolbar-border);
    background: var(--tiptap-toolbar-muted-bg);
  }

  .tiptap-toolbar__panel-dot {
    border-color: var(--tiptap-toolbar-border);
  }

  .tiptap-toolbar__panel-text {
    color: var(--tiptap-toolbar-text-2);
  }

  @container tiptap-toolbar (max-width: 639px) {
    .tiptap-toolbar__cluster {
      flex-wrap: wrap;
    }

    .tiptap-toolbar__group {
      flex-wrap: wrap;
    }
  }

  @container tiptap-toolbar (min-width: 640px) and (max-width: 767px) {
    .tiptap-toolbar__cluster {
      flex-wrap: wrap;
    }

    .tiptap-toolbar__group {
      flex-wrap: wrap;
    }
  }

  @container tiptap-toolbar (min-width: 768px) and (max-width: 1279px) {
    .tiptap-toolbar__group {
      flex-wrap: nowrap;
    }

    .tiptap-toolbar__cluster--utility-start {
      margin-left: 0;
    }
  }

  @container tiptap-toolbar (min-width: 1280px) {
    .tiptap-toolbar__cluster + .tiptap-toolbar__cluster {
      padding-left: 8px;
    }

    .tiptap-toolbar__cluster + .tiptap-toolbar__cluster::before {
      content: '';
      position: absolute;
      left: 0;
      top: 50%;
      width: 1px;
      height: 20px;
      background: var(--divider-color);
      transform: translateY(-50%);
    }

    .tiptap-toolbar__cluster--utility-start {
      margin-left: auto;
    }
  }

  @container tiptap-toolbar (min-width: 1536px) {
    .tiptap-toolbar__label {
      display: inline-flex;
    }

    .tiptap-toolbar__cluster--utility-start {
      margin-left: auto;
    }
  }
</style>
