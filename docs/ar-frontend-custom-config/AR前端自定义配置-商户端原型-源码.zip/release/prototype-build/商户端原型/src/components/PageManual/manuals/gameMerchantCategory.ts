// 游戏展示分类管理（商户端 tenant · game_merchant_category）功能说明书。
// 锚定 src/views/game/merchant/category/index.vue + data.ts 真实控件（R53 实证、不臆造）。
// R64：本页 roles:['tenant']。标准 ProCrudTable 列表页：2 搜索项 + 5 列（含显示开关）+ 1 行操作（编辑）。

import type { PageManual } from '../types';

const manual: PageManual = {
  route: 'game_merchant_category',
  title: '游戏展示分类管理',
  overview:
    '商户端配置 C 端玩家首页的游戏展示分类：按分类名称、展示状态筛选，可切换分类的 C端展示 / 隐藏（开关）、查看图标与排序、编辑。控制玩家端游戏分类的呈现。⚠️ 本页无「商户」筛选项，data.ts 固定回落到首个商户（GAME_MERCHANT_LIST[0]），页面上不能切换商户（与 subgame / display 的「商户必选」模式不同）。',
  items: [
    // ============ 搜索区 ============
    {
      anchor: 'categoryName',
      name: '分类名称',
      group: '搜索',
      interaction: '文本输入、模糊匹配。',
      dataSource: '用户输入。',
      logic: '按分类名称筛选。',
      limit: '选填（代码未设长度上限）。',
      edge: '空 = 全部分类。',
    },
    {
      anchor: 'visible',
      name: '展示状态（搜索）',
      group: '搜索',
      interaction: '下拉单选：显示 / 隐藏，可清空。',
      dataSource: '本地枚举（显示 = 1 / 隐藏 = 0）。',
      logic: '按分类显示状态筛选。',
      limit: '选填。',
    },

    // ============ 关键列（显示开关）============
    {
      anchor: 'col_visible',
      name: 'C端展示列',
      group: '列',
      interaction: '开关（ConfirmSwitch，带二次确认），可直接点切换。',
      dataSource: '行数据 visible（1 显示 / 0 隐藏）。',
      logic: '这是改分类显示状态的入口（本列符合 R47 用开关）；切换即调 api.merchantCategory.updateVisible 并刷新。',
    },

    // ============ 行操作 ============
    {
      anchor: 'act_edit',
      name: '行操作 · 编辑',
      group: '操作',
      interaction: '点击进入编辑。',
      logic: '当前为骨架占位（handleEdit 仅弹提示回显分类名），完整编辑功能待补。',
    },
  ],

  // ============ 字段介绍 tab（列序照页面；仅列表列 + 定义）============
  fields: [
    { name: '分类名称', def: '游戏展示分类的名称。' },
    { name: '图标', def: '分类的图标（emoji / 图形）。' },
    { name: 'C端展示', def: '该分类是否在 C 端展示：展示 / 隐藏（真实列头 i18n = C端展示）。' },
    { name: '排序', def: '分类在 C 端的展示位次。' },
    { name: '更新时间', def: '分类配置最近一次更新时间。' },
  ],
};

export default manual;
