// 会员层级（商户端 tenant · member_level）功能说明书。
// 锚定 src/views/member/level/{index.vue,data.ts,form.ts,useLevelPage.ts,DateModeBar.vue} 真实控件（R53 实证、不臆造）。
// 单表列表页：19 数据列 + 双行汇总（本页汇总/总计），无新增/编辑/删除，无独立弹窗。
// 双上下文：既是独立路由页，也作为提现工作台订单详情弹窗（WorkbenchOrderDetailModal.vue）的动态添加 Tab 被嵌入
// （与「下级会员」「银行卡」同级）。核心特色是自定义日期模式切换器 DateModeBar（日/日区间/月/所有 四态），
// 非全站通用的单一 proDateRange。

import type { PageManual } from '../types';

const manual: PageManual = {
  route: 'member_level',
  title: '会员层级',
  overview:
    '商户端「会员管理 › 会员层级」页，按代理层级维度展示会员的层级关系（上级ID/层级/直属下级/全部下级）与投注、中奖、充值、提现、红包、签到等 20 余项统计数据，纯查看用途，无新增/编辑/删除。支持两种访问方式：①独立路由 /member/level；②嵌入「提现工作台」订单详情弹窗，作为可动态添加的「会员层级」Tab（此时商户上下文锁定为订单所属商户）。页面顶部有一条自定义日期模式切换条（DateModeBar）：日 / 日区间 / 月 / 所有 四态，「日」「月」态下另有上一日/下一日（或上/下月）翻页按钮，切换模式会联动搜索表单里的「日期」字段类型（单日选择器/区间选择器/月份选择器/不显示）并自动重新查询。表格底部固定两行汇总（本页汇总 / 总计，共 40 个字段循环赋值）。进入页面默认不自动加载数据（auto-load=false，与同模块「下级会员」页一致），需先确认商户等条件后点「查询」。',
  items: [
    // ============ 搜索区 ============
    {
      anchor: 'merchant',
      name: '商户',
      group: '搜索',
      interaction: '下拉单选（商户选择器，架构级不可清空，见《交互规范》§3 商户选择器）。',
      dataSource:
        '商户端可见商户列表；默认预填当前左上角选中商户（defaultTenantId），嵌入提现工作台场景下预填订单所属商户（memberCtx.tenantId）。',
      logic: '按选中商户过滤会员层级列表结果。',
      limit: '必填（红星 showRequireMark + requiredRule）；单选、不可清空——命中 R63。',
      edge: '⚠️ 核实代码后发现：useLevelPage.ts 的 loadData 函数里有注释"嵌入弹窗时强制使用订单/会员所属商户，避免下拉被禁用后参数缺失"，但 form.ts 的 createLevelSearchColumns 实际并未给这个商户下拉传 disabled——嵌入场景（提现工作台"会员层级"动态 Tab）下商户下拉仍可正常点开改选；但无论选什么，loadData 都优先取 memberCtx.tenantId.value，下拉的选择结果不影响实际查询商户，即"看起来能改、实际改了不生效"，如实记录，非本次引入。',
    },
    {
      anchor: 'userId',
      name: '会员ID',
      group: '搜索',
      interaction: '文本输入。',
      dataSource: '用户输入。',
      logic: '按会员ID子串匹配过滤（String(userId).includes()）。',
      limit:
        '选填；仅数字字符（allowInput: onlyDigits 过滤非数字按键，不限位数——不是 inputConstraints 的 intNum 预设）。',
      edge: '空 = 不按会员ID筛，仅按商户等其它条件过滤。',
    },
    {
      anchor: 'agentType',
      name: '代理模式',
      group: '搜索',
      interaction: '下拉单选（本页固定枚举 select，非字典 dictSelect，可清空）。',
      dataSource:
        '本页固定两项：流水返佣(value=1) / 盈亏返利(value=2)，value 沿用字典 v1/agentTypeList 原数值，' +
        '但不再复用该字典本身（该字典含"非代理"(0)，2026-07-25 起本搜索项不再展示该选项；' +
        '字典整体保留，列表列「代理模式」仍用其渲染三态标签，见下方字段介绍）。',
      logic: '按代理模式精确过滤。',
      limit: '选填。',
    },
    {
      anchor: 'lv',
      name: '当前层级',
      group: '搜索',
      interaction: '下拉单选（dictSelect，可清空）。',
      dataSource: '字典 v1/userRelativeLevelList：Lv1 ~ Lv6。',
      logic: '按层级精确过滤（对应行数据 lv 字段）。',
      limit: '选填。',
    },
    {
      anchor: 'date',
      name: '日期（随日期模式变化：单日选择器 / 日期区间 / 月份选择器 / 不显示）',
      group: '搜索',
      interaction:
        '「日」模式=单日期选择器（默认今天）；「日区间」模式=proDateRange 区间选择（展平写入 startTime/endTime）；「月」模式=月份选择器（默认当月）；「所有」模式=不渲染该字段。字段类型由上方「日期模式切换条」联动决定，非用户直接切换。',
      dataSource: '用户选择，或由日期模式切换条 / 翻页按钮联动写入。',
      logic: '按所选日期/区间/月份过滤统计数据；请求另附 type 字段（D/C/M/A）标记当前模式。',
      limit:
        '「日区间」最多跨 90 天（标准档，对齐《交互规范》§0 时间查询"标准档"分级）；「日」「日区间」「月」三种有日期的模式均不可选未来（isDateDisabled / allowFuture:false）。',
      edge: '「所有」模式下该字段消失、不传日期参数，查询范围覆盖全部历史数据。',
    },

    // ============ 操作 ============
    {
      anchor: 'dateModeBar',
      name: '日期模式切换条（日 / 日区间 / 月 / 所有）+ 上一日/下一日翻页',
      group: '操作',
      interaction:
        '渲染在表格上方工具条（#table-header slot，非搜索表单内）。4 个模式按钮；「日」「月」模式下左侧多出"上一日/下一日"或"上个月/下个月"翻页按钮，「日区间」「所有」模式下无翻页按钮。',
      logic:
        '点模式按钮 → 切换 dateMode，清空旧日期参数（date / startTime+endTime）并写入新模式默认值（今天/当月），自动重新查询；点翻页按钮 → 按当前模式移动一天/一月并自动重新查询。',
      limit: '翻页不可超过今天：超过会被拦截，弹 Toast「不能超过今日日期」，日期不变。',
      note: '与上方"日期"搜索字段联动——本控件决定搜索表单里渲染哪种日期控件。',
    },
    {
      anchor: 'reset',
      name: '重置（搜索表单）',
      group: '操作',
      interaction: '点击搜索表单「重置」按钮。',
      logic:
        '除清空搜索表单各字段外，额外把日期模式（dateMode）重置回「日」模式（handleReset），联动重新渲染搜索表单里的日期字段类型。',
      note: '这是本页对框架默认「重置」行为的定制扩展；其它多数列表页的「重置」只清空表单值，不涉及"模式"这类页面自有状态。',
    },

    // ============ 列 ============
    {
      anchor: 'col_userId',
      name: '会员ID列',
      group: '列',
      interaction: '数字以可点击蓝字链接形式展示（跳转类控件，非纯展示）。',
      dataSource: '行数据 userId + tenantId。',
      logic:
        '点击调用 openMemberDetailModal(userId, tenantId) 打开会员详情弹窗（renderMemberIdLink，全站统一的会员ID可点规范）。',
    },
    {
      anchor: 'col_betWinDepositWithdraw',
      name: '投注 / 中奖 / 充值 / 提现 四个组合列',
      group: '列',
      interaction: '每格纯文本展示"金额/次数"两段拼接（如"256,000.00/1280"），非可点击。',
      dataSource:
        '行数据对应的 xxxAmount + xxxTimes 字段（如 lotteryAmount/lotteryTimes、winAmount/winTimes、rechargeAmount/rechargeTimes、withdrawAmount/withdrawTimes）。',
      logic: '单纯展示该会员在当前查询条件下的统计值，无点击交互。',
      edge: '⚠️ 核实代码后发现：这 4 列的 i18n 标题都写"(金额/次/人)"三段（如「投注(金额/次/人)」），承诺展示金额/次数/人数三项；但 form.ts 里这 4 列的 render 函数都只拼接了 amount/times 两项，人数字段（lotteryUsers/winUsers/rechargeUsers/withdrawUsers）在逐行展示里完全没有输出。这些人数字段在 mock 数据（data.ts LevelRow）里每条记录都有真实值，且在表格底部"本页汇总/总计"两行汇总里通过 summaryCell() 正确显示了金额+次数+人数三项——唯独逐行列展示漏了"人"这一项，标题与实际展示不一致，如实记录，非本次引入。',
    },

    // ============ 其它 ============
    {
      anchor: 'summaryRow',
      name: '汇总行（本页汇总 / 总计 两行）',
      group: '其它',
      interaction: '表格底部固定两行汇总，非可交互控件，纯展示。',
      dataSource:
        '接口 getUserRelativePageList 返回的 summary 对象（40 个字段：page 前缀=当前页汇总、all 前缀=按当前筛选条件的全部汇总），前端 fillSummaryFromResponse 按字段名后缀自动识别格式化（xxxAmount 走 currency 千分位+2位小数，xxxTimes/xxxUsers 直接整数展示）。',
      logic:
        '「本页汇总」=当前分页条数内的合计；「总计」=当前筛选条件下全部符合条件记录的合计（不受分页影响）；投注/中奖/充值/提现四组在汇总行按"金额（加粗）+ 次数/人数（两行小字）"三项完整展示——对比逐行列只展示两项（见 col_betWinDepositWithdraw 条），汇总行的字段完整度反而更高。',
    },
  ],

  // ============ 字段介绍 tab（列序照页面；仅列表列 + 定义）============
  fields: [
    { name: '商户', def: '该会员所属商户，标签形式展示（renderTenantTag）。' },
    { name: '会员ID', def: '会员唯一标识，可点击蓝字跳转会员详情弹窗。' },
    { name: '会员账号', def: '会员的登录账号。' },
    { name: '上级ID', def: '该会员的直接上级会员ID；无上级（顶层会员）时为空。' },
    {
      name: '层级',
      def: '该会员在代理层级体系中的层级序号（与搜索区「当前层级」下拉 Lv1~Lv6 对应同一份 lv 原始数值，列上直接显示数字，不带"Lv"前缀）。',
    },
    { name: '直属下级', def: '该会员名下一级（直接邀请/直属）的下级会员数量。' },
    { name: '全部下级', def: '该会员名下所有层级（含间接）的下级会员总数量。' },
    {
      name: '代理模式',
      def: '该会员的代理类型：非代理（灰色默认标签）/ 流水返佣（橙色警示标签）/ 盈亏返利（绿色成功标签），三态彩色标签区分。',
    },
    { name: '注册时间', def: '该会员的注册时间，按其所属商户时区显示。' },
    {
      name: '投注(金额/次/人)',
      def: '当前查询条件下该会员的投注金额与投注次数（如"256,000.00/1280"）；列标题含"人"但逐行展示未含人数，详见「交互介绍」投注/中奖/充值/提现组合列条目。',
    },
    { name: '中奖(金额/次/人)', def: '同上结构，展示中奖金额与中奖次数。' },
    { name: '佣金', def: '该会员产生的佣金金额，绿色加粗展示。' },
    { name: '充值(金额/次/人)', def: '展示充值金额与充值次数。' },
    { name: '提现(金额/次/人)', def: '展示提现金额与提现次数。' },
    { name: '红包', def: '该会员领取的红包金额。' },
    { name: '签到', def: '该会员签到获得的金额。' },
    { name: '代理红包', def: '该会员作为代理领取/发放的红包金额。' },
    { name: '充值赠送', def: '充值赠送到账金额。' },
    { name: '注册送金', def: '注册赠送到账金额。' },
    { name: '彩金充值', def: '彩金充值到账金额。' },
    { name: '首充赠送', def: '首次充值赠送到账金额。' },
  ],
};

export default manual;
