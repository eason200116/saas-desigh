<template>
  <n-popover
    trigger="click"
    placement="bottom-start"
    :show="showPopover"
    :width="showTime ? undefined : popoverWidth"
    :style="showTime ? 'max-width: none;' : ''"
    @update:show="handlePopoverShow"
  >
    <template #trigger>
      <!-- n-el 把 naive-ui theme vars（--border-color / --border-radius / --ui-accent-hover
           / --text-color / --placeholder-color / --icon-color 等）挂到根元素，
           子元素走 CSS 继承即可消费，切换主题时自动跟随 -->
      <n-el
        tag="div"
        class="pro-date-range-trigger"
        :class="{ 'is-disabled': disabled }"
        :data-manual="$attrs['data-manual']"
        @click="handleTriggerClick"
      >
        <span class="pro-date-range-trigger__value" :class="{ 'is-placeholder': !startDisplay }">{{
          startDisplay || effectivePlaceholder
        }}</span>
        <span class="pro-date-range-trigger__separator">→</span>
        <span class="pro-date-range-trigger__value" :class="{ 'is-placeholder': !endDisplay }">{{
          endDisplay || effectivePlaceholder
        }}</span>
        <span class="pro-date-range-trigger__icons">
          <n-icon v-if="clearable && modelValue" class="clear-icon" @click.stop="handleClear">
            <CloseCircleFilled />
          </n-icon>
          <n-icon v-else><CalendarOutlined /></n-icon>
        </span>
        <!--
          paste 事件只在 input/textarea/contenteditable 上触发；这里铺一个 opacity:0 的
          覆盖 input，光标看不到也不可输入（@beforeinput.prevent），仅用于接管 ⌘V 粘贴：
          - 父 trigger 点击时主动 focus 它，确保浏览器把粘贴目标定到这里
          - @paste 命中后 prevent 默认行为，避免任何文本进入 input
        -->
        <input
          ref="pasteCatcherRef"
          class="pro-date-range-trigger__paste-catcher"
          :tabindex="disabled ? -1 : 0"
          :disabled="disabled"
          :aria-hidden="true"
          autocomplete="off"
          @paste.prevent="handlePaste"
          @beforeinput.prevent
          @keydown.enter.prevent="showPopover = true"
        />
      </n-el>
    </template>

    <ZonedDateRangePanel
      :value="modelValue"
      :value-format="valueFormat"
      :value-string-pattern="valueStringPattern"
      :timezone="pickerTimezone"
      :max-days="maxDays"
      :allow-future="allowFuture"
      :shortcuts="shortcuts"
      :shortcut-preset="shortcutPreset"
      :show-time="showTime"
      :bind-calendar-months="bindCalendarMonths"
      :default-time="defaultTime"
      @confirm="handleConfirm"
      @reset="handleReset"
    />
  </n-popover>
</template>

<script lang="ts" setup>
  import { ref, computed, watch, toRef } from 'vue';
  import { format } from 'date-fns';
  import { useI18n } from 'vue-i18n';
  import { NPopover, NIcon, NEl } from 'naive-ui';
  import { CalendarOutlined, CloseCircleFilled } from '@vicons/antd';
  import ZonedDateRangePanel from './components/ZonedDateRangePanel.vue';
  import { createZonedDefaultShortcutValue } from './composables/useZonedShortcuts';
  import { useDateRangeTrigger, type RangeValue } from './useDateRange';
  import { encodeExternalValue, parsePastedRange } from './utils/rangeValueCodec';
  import { compareParts, resolveTimezoneId } from './utils/zonedDateMath';
  import type {
    DateRangeDefaultShortcut,
    DateRangeShortcutPreset,
    DateRangeShortcuts,
    DateRangeTimezone,
  } from '../types';
  import { useProFormContextSafe } from '../context';

  defineOptions({
    name: 'ProDateRangeInput',
  });

  const props = withDefaults(
    defineProps<{
      /** 当前值 [start, end]。number 元组用于 timestamp 模式；string 元组仅 valueFormat='string' 时生效 */
      value?: [number, number] | [string, string] | null;
      /** 出站格式：'timestamp'（默认）emit 毫秒时间戳；'string' emit 格式化字符串（不做任何 tz 处理） */
      valueFormat?: 'timestamp' | 'string';
      /** valueFormat='string' 时的字符串格式，默认 'yyyy-MM-dd HH:mm:ss' */
      valueStringPattern?: string;
      /** 商户时区。string=自定义；false=强制 UTC；未传=CrudTable 上下文或默认商户 */
      timezone?: DateRangeTimezone;
      /** 占位符 */
      placeholder?: string;
      /** 是否禁用 */
      disabled?: boolean;
      /** 是否可清除 */
      clearable?: boolean;
      /** 弹出框宽度 */
      popoverWidth?: number;
      /** 显示格式 */
      displayFormat?: string;
      /** 最大可选天数 */
      maxDays?: number;
      /** 是否允许选择未来日期 */
      allowFuture?: boolean;
      /** 快捷选项：false 隐藏，true/不传显示默认，数组使用外部自定义 */
      shortcuts?: DateRangeShortcuts;
      /** 快捷选项预设 */
      shortcutPreset?: DateRangeShortcutPreset;
      /** 初始为空时按快捷项 key 写入默认区间 */
      defaultShortcut?: DateRangeDefaultShortcut;
      /** 是否显示时分秒选择 */
      showTime?: boolean;
      /**
       * 把起止两端的值直接展平写回 form model 对应字段。数组顺序 = [start, end]。
       * 例：`['beginTime', 'endTime']` → 起始 → form.beginTime，结束 → form.endTime。
       * 设置后：组件初始化时从这两个字段读初值、交互时把起止值写回它们；
       * 自身 `update:value` 不再发射（聚合数组不再落 form 里，避免冗余）。
       * 仅在 ProField 包裹下生效（需要 form context）。
       */
      modelKeys?: string[];
      /**
       * 左右日历视图是否绑定连续。与 NDatePicker bind-calendar-months 同名同义。
       *  - true（默认，兼容现状）：右视图 = 左视图 + 1 月，箭头联动
       *  - false：左右独立视图，互不影响（与原生 NDatePicker 默认一致）
       * ⚠️ 默认值与 NDatePicker 原生默认（false）反向，为兼容现状的有意选择。
       */
      bindCalendarMonths?: boolean;
      /**
       * 选完日期未编辑时分秒时自动填充的默认时间。与 NDatePicker default-time 同名同义。
       * 格式 'HH:mm:ss'；不传走旧硬编码（起点 00:00:00、终点 23:59:59）。
       */
      defaultTime?: string | [string, string];
    }>(),
    {
      value: null,
      valueFormat: 'timestamp',
      valueStringPattern: 'yyyy-MM-dd HH:mm:ss',
      timezone: null,
      placeholder: '',
      disabled: false,
      clearable: true,
      popoverWidth: 650,
      displayFormat: 'yyyy-MM-dd',
      maxDays: 31,
      allowFuture: false,
      shortcuts: undefined,
      shortcutPreset: 'default',
      defaultShortcut: undefined,
      showTime: true,
      modelKeys: undefined,
      bindCalendarMonths: false,
      defaultTime: undefined,
    },
  );

  const emit = defineEmits<{
    'update:value': [value: RangeValue];
    change: [value: RangeValue];
    clear: [];
  }>();

  const { t } = useI18n();

  const showPopover = ref(false);
  const modelValue = ref<RangeValue>(props.value);
  const pasteCatcherRef = ref<HTMLInputElement | null>(null);

  // 走 ProField 包装时能拿到 form context；直接 v-model 使用时为 null
  const formContext = useProFormContextSafe();

  /** 是否启用 modelKeys 展平模式：modelKeys 长度 >=2 + 有 form context */
  const useModelKeys = computed(
    () => Array.isArray(props.modelKeys) && props.modelKeys.length >= 2 && !!formContext,
  );

  function readFromModelKeys(): RangeValue {
    if (!useModelKeys.value) return null;
    const [startKey, endKey] = props.modelKeys!;
    const startVal = formContext!.getFieldValue(startKey);
    const endVal = formContext!.getFieldValue(endKey);
    if (
      (startVal === undefined || startVal === null || startVal === '') &&
      (endVal === undefined || endVal === null || endVal === '')
    ) {
      return null;
    }
    return [startVal, endVal] as RangeValue;
  }

  function writeToModelKeys(val: RangeValue) {
    if (!useModelKeys.value) return;
    const [startKey, endKey] = props.modelKeys!;
    if (Array.isArray(val) && val.length === 2) {
      formContext!.setFieldValue(startKey, val[0]);
      formContext!.setFieldValue(endKey, val[1]);
    } else {
      formContext!.setFieldValue(startKey, null);
      formContext!.setFieldValue(endKey, null);
    }
  }

  /**
   * 统一的"值变化"出口：
   * - modelKeys 模式：只写回展平字段，不再 emit update:value，避免 form 里出现冗余的 aggregate
   * - 普通模式：按原路走 update:value（外层 ProField 会把它写入 form[path]）
   */
  function commitValue(val: RangeValue) {
    modelValue.value = val;
    if (useModelKeys.value) {
      writeToModelKeys(val);
    } else {
      emit('update:value', val);
    }
  }

  const effectivePlaceholder = computed(
    () => props.placeholder || t('common.dateRange.placeholder'),
  );

  // 共用触发器状态机：面板时区 / 显示 / string 规范化 / tz 切换全部在 composable 里
  const { pickerTimezone, startDisplay, endDisplay } = useDateRangeTrigger({
    value: modelValue,
    externalValue: toRef(props, 'value'),
    valueFormat: toRef(props, 'valueFormat'),
    valueStringPattern: toRef(props, 'valueStringPattern'),
    displayFormat: toRef(props, 'displayFormat'),
    propTimezone: toRef(props, 'timezone'),
    onStringNormalize: (normalized) => {
      commitValue(normalized);
      emit('change', normalized);
    },
  });

  const defaultShortcutValue = computed(() => {
    const timezone = pickerTimezone.value;
    if (timezone === null && props.timezone !== false) return null;
    return createZonedDefaultShortcutValue({
      defaultShortcut: props.defaultShortcut,
      timezoneId: resolveTimezoneId(timezone === false ? null : timezone),
      valueFormat: props.valueFormat,
      valueStringPattern: props.valueStringPattern,
      preset: props.shortcutPreset,
      t,
    });
  });
  const suppressDefaultShortcut = ref(false);

  function isEmptyRange(value: RangeValue): boolean {
    if (!Array.isArray(value) || value.length !== 2) return true;
    const startEmpty = value[0] === undefined || value[0] === null || value[0] === '';
    const endEmpty = value[1] === undefined || value[1] === null || value[1] === '';
    return startEmpty && endEmpty;
  }

  function getCurrentRange(): RangeValue {
    return useModelKeys.value ? readFromModelKeys() : modelValue.value;
  }

  function getTimezoneIdentity(value: DateRangeTimezone | undefined): string {
    if (value === false || value === null || value === undefined) return 'UTC';
    return resolveTimezoneId(value);
  }

  function resetDefaultShortcut() {
    const next = defaultShortcutValue.value;
    if (!next) return false;
    suppressDefaultShortcut.value = false;
    commitValue(next);
    return true;
  }

  function applyDefaultShortcutIfEmpty(): boolean {
    const next = defaultShortcutValue.value;
    if (!next) return false;
    // 先判空再消费 suppress：modelKeys 模式下 commitValue(null) 是两次 setFieldValue 串行触发，
    // 中间态 [null, oldEnd] 不是空范围，若此时把 suppress 提前消耗，第二次进入真正空状态时
    // 就会被 defaultShortcut 重新填回，导致清空失败。
    if (!isEmptyRange(getCurrentRange())) return false;
    if (suppressDefaultShortcut.value) {
      suppressDefaultShortcut.value = false;
      return false;
    }
    commitValue(next);
    return true;
  }

  // 外部 props.value 变化 → modelValue 同步
  //   - string 模式 number 元组已由 composable 规范化后写回，这里跳过
  //   - modelKeys 模式下 props.value（= form[path]）不是权威源，空值时从分字段回填
  //   - 其他情况直接镜像
  watch(
    () => props.value,
    (val) => {
      if (
        props.valueFormat === 'string' &&
        Array.isArray(val) &&
        val.length === 2 &&
        typeof val[0] === 'number' &&
        typeof val[1] === 'number'
      ) {
        return;
      }
      if (useModelKeys.value && (val === null || val === undefined)) {
        modelValue.value = readFromModelKeys();
        applyDefaultShortcutIfEmpty();
        return;
      }
      modelValue.value = val;
      applyDefaultShortcutIfEmpty();
    },
    { immediate: true, flush: 'sync' },
  );

  // modelKeys 模式下单独追踪 form 里两个分字段：父组件 reset / setFieldValue 清掉它们时
  // props.value 不会变（ProField 在 modelKeys 模式下不写回 path），上面那条 watch 触发不了，
  // 必须靠这条 computed + watch 把清空回灌到自己的 modelValue 里，UI 才能同步回到 placeholder
  const modelKeysSnapshot = computed<RangeValue>(() =>
    useModelKeys.value ? readFromModelKeys() : null,
  );
  watch(
    modelKeysSnapshot,
    (next) => {
      if (!useModelKeys.value) return;
      if (
        props.valueFormat === 'string' &&
        Array.isArray(next) &&
        next.length === 2 &&
        typeof next[0] === 'number' &&
        typeof next[1] === 'number'
      ) {
        const pattern = props.valueStringPattern;
        commitValue([format(next[0], pattern), format(next[1], pattern)]);
        return;
      }
      // 和当前 modelValue 比较，避免自己写回后又被回灌触发无限循环
      const curr = modelValue.value;
      const nextStart = next?.[0] ?? null;
      const nextEnd = next?.[1] ?? null;
      const currStart = curr?.[0] ?? null;
      const currEnd = curr?.[1] ?? null;
      if (nextStart === currStart && nextEnd === currEnd) return;
      modelValue.value = next;
      // 不在此处 applyDefaultShortcutIfEmpty：外部（如 ProCrudTable quick-date "所有" 按钮）
      // 把 modelKeys 字段写为 null 时，会触发本 watch，此前会 fillback 回 today 导致清空失效。
      // 首屏 mount 的 fillback 由上方监听 dateValue/value 的 watch (immediate) 保证。
    },
    { flush: 'sync' },
  );

  // 切换搜索商户时，配置了 defaultShortcut 的日期范围按新商户时区重新初始化。
  // 例如 today 始终重新落到新商户的 00:00:00 ~ 23:59:59，而不是沿用旧商户的 UTC 毫秒值。
  watch(
    pickerTimezone,
    (nextTimezone, previousTimezone) => {
      if (!props.defaultShortcut) return;
      if (getTimezoneIdentity(nextTimezone) === getTimezoneIdentity(previousTimezone)) return;
      resetDefaultShortcut();
    },
    { flush: 'sync' },
  );

  watch(
    defaultShortcutValue,
    () => {
      applyDefaultShortcutIfEmpty();
    },
    { immediate: true, flush: 'sync' },
  );

  function handlePopoverShow(show: boolean) {
    showPopover.value = show;
  }

  function handleConfirm(value: [number, number] | [string, string]) {
    showPopover.value = false;
    commitValue(value);
    emit('change', value);
  }

  function handleReset() {
    suppressDefaultShortcut.value = true;
    commitValue(null);
    emit('change', null);
  }

  function handleClear() {
    suppressDefaultShortcut.value = true;
    commitValue(null);
    emit('change', null);
    emit('clear');
  }

  /**
   * 触发器点击：打开 popover 同时把焦点放到隐藏 paste-catcher，
   * 之后用户 ⌘V 才能命中 input 的 paste 事件。
   */
  function handleTriggerClick() {
    if (props.disabled) return;
    showPopover.value = true;
    pasteCatcherRef.value?.focus({ preventScroll: true });
  }

  /**
   * 粘贴流程：用户粘贴**纯日期**（如 `2026-05-10 ~ 2026-05-15`）且页面配了 `defaultTime` 时，
   * 把 parsePastedRange 解析后的 0/0/0 时分秒覆盖为 defaultTime；用户显式粘贴时分秒时保留原值。
   *
   * 解析靠 PastedRangeResult.startHasTime / endHasTime 标志位区分（同一个 0/0/0
   * 既可能是"用户明示 00:00:00"也可能是"未提供被填零"，必须用标志位而非值本身判断）。
   */
  function applyDefaultTimeIfMissing(
    parts: {
      year: number;
      month: number;
      day: number;
      hour: number;
      minute: number;
      second: number;
      millisecond: number;
    },
    hasTime: boolean,
    position: 'start' | 'end',
  ) {
    if (hasTime) return parts; // 粘贴文本含时分秒，原样保留
    const dt = props.defaultTime;
    if (!dt) return parts; // 未配 defaultTime，保持解析的 0/0/0（与改造前行为一致）
    const str = Array.isArray(dt) ? dt[position === 'start' ? 0 : 1] : dt;
    const m = /^(\d{1,2}):(\d{1,2}):(\d{1,2})$/.exec(str ?? '');
    if (!m) return parts;
    return {
      ...parts,
      hour: Number(m[1]),
      minute: Number(m[2]),
      second: Number(m[3]),
      millisecond: 0,
    };
  }

  /**
   * 粘贴处理：解析剪贴板文本为 [start, end] wall-clock parts，按当前 picker 时区
   * 编码到 valueFormat（timestamp / string）后走与日历选择相同的 commit 链路。
   * 解析失败 / 起止反转 / 超 maxDays / 越界未来 → 静默忽略，让用户继续手选。
   *
   * 粘贴纯日期 + 配 defaultTime 时，自动应用配置的默认时分秒（避免 defaultTime 在粘贴路径静默失效）。
   */
  function handlePaste(event: ClipboardEvent) {
    const text = event.clipboardData?.getData('text');
    if (!text) return;
    const parsed = parsePastedRange(text);
    if (!parsed) return;
    if (compareParts(parsed.start, parsed.end) > 0) return;

    const finalStart = applyDefaultTimeIfMissing(parsed.start, parsed.startHasTime, 'start');
    const finalEnd = applyDefaultTimeIfMissing(parsed.end, parsed.endHasTime, 'end');

    const timezone = pickerTimezone.value;
    const outbound = encodeExternalValue(
      { start: finalStart, end: finalEnd },
      {
        valueFormat: props.valueFormat,
        valueStringPattern: props.valueStringPattern,
        timezone: timezone === false ? null : timezone,
      },
    );
    if (!outbound) return;

    suppressDefaultShortcut.value = true;
    commitValue(outbound);
    emit('change', outbound);
    showPopover.value = false;
  }
</script>

<style lang="less" scoped>
  // 由外层 <n-el> 暴露 naive-ui theme vars：--border-color / --border-radius /
  // --ui-accent-hover / --text-color / --placeholder-color / --icon-color
  // / --cubic-bezier-ease-in-out，切换明暗主题和主色时自动跟随

  .pro-date-range-trigger {
    display: flex;
    align-items: center;
    width: 100%;
    height: 26px;
    padding: 0 8px;
    border: 1px solid var(--border-color);
    border-radius: var(--border-radius);
    background: var(--card-color);
    cursor: pointer;
    transition: border-color 0.3s var(--cubic-bezier-ease-in-out);
    font-size: 13px;
    box-sizing: border-box;
    position: relative; // 给 paste-catcher 做绝对定位锚

    &:hover {
      border-color: var(--ui-accent-hover);
    }

    &:focus-within {
      border-color: var(--ui-accent-hover);
    }

    &.is-disabled {
      opacity: 0.5;
      cursor: not-allowed;
    }
  }

  // 隐形 input：仅用于捕获 ⌘V 粘贴事件
  // pointer-events:none 让鼠标穿透到下面的清除/日历图标；focus 由父 trigger 的 @click 主动调用
  .pro-date-range-trigger__paste-catcher {
    position: absolute;
    inset: 0;
    width: 100%;
    height: 100%;
    border: 0;
    background: transparent;
    color: transparent;
    caret-color: transparent;
    pointer-events: none;
    outline: none;
    padding: 0;
    font: inherit;

    &::selection {
      background: transparent;
    }
  }

  .pro-date-range-trigger__value {
    flex: 1;
    min-width: 0;
    text-align: center;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    color: var(--text-color);

    &.is-placeholder {
      color: var(--placeholder-color);
    }
  }

  .pro-date-range-trigger__separator {
    flex-shrink: 0;
    color: var(--text-color-3);
    font-size: 12px;
    margin: 0 4px;
  }

  .pro-date-range-trigger__icons {
    flex-shrink: 0;
    display: flex;
    align-items: center;
    margin-left: 4px;
    color: var(--icon-color);
  }

  .clear-icon {
    cursor: pointer;
    transition: color 0.3s var(--cubic-bezier-ease-in-out);

    &:hover {
      color: var(--icon-color-hover);
    }
  }
</style>
