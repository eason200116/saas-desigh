// 彩票域名管理（总控端 admin · lottery_domain）功能说明书。
// 锚定 src/views/lottery/domain/index.vue + data.ts + components/*Modal.vue 真实控件（R53 实证、不臆造）。
// 标准 ProCrudTable 列表页：4 搜索项 + 10 列 + 顶部「添加域名」+ 2 行操作（编辑 / 设置状态）。

import type { PageManual } from '../types';

const manual: PageManual = {
  route: 'lottery_domain',
  title: '彩票域名管理',
  overview:
    '总控端维护彩票业务对外访问的域名：为每个域名配置支持的国家 / 商户，启停域名。列序、搜索序照 SIT 源站镜像 1:1（备注列在第 5 位、搜索为商户/国家/域名/状态，均为本页对 R66/R60 的破例）。可添加 / 编辑域名、设置启停状态。',
  items: [
    // ============ 搜索区（顺序照镜像：商户/国家/域名/状态）============
    {
      anchor: 'merchant',
      name: '商户',
      group: '搜索',
      interaction: '下拉多选、可搜索、可清空。',
      dataSource: '商户选项来自 data.ts MERCHANT_POOL（源站 sitINR 那套小池，不接 V3 商户池）。',
      logic: '选多家 = 含任一即命中该域名。',
      limit: '选填；多选形态不受 R63「商户单选加红星」约束。',
      edge: '不选 = 不按商户筛。',
    },
    {
      anchor: 'country',
      name: '国家',
      group: '搜索',
      interaction: '下拉单选、可清空。',
      dataSource: '国家选项来自 data.ts COUNTRY_POOL。',
      logic: '按域名支持的国家筛选。',
      limit: '选填。',
      edge: '不选 = 不按国家筛。',
    },
    {
      anchor: 'domain',
      name: '域名',
      group: '搜索',
      interaction: '文本输入、模糊匹配。',
      dataSource: '用户输入。',
      logic: '按域名模糊筛选。',
      limit: '选填；最多 50 字（inputProps searchKw）。',
      edge: '空 = 不按域名筛。',
    },
    {
      anchor: 'state',
      name: '状态（搜索）',
      group: '搜索',
      interaction: '下拉单选：启用 / 禁用（二态），可清空。',
      dataSource: '本地枚举（启用 = 1 / 禁用 = 0）。',
      logic: '按域名启停状态筛选。',
      limit: '选填。',
      edge: '不选 = 全部状态。',
    },

    // ============ 关键列（状态列）============
    {
      anchor: 'col_state',
      name: '状态列',
      group: '列',
      interaction: '只读 Tag：启用绿 / 禁用红（二态），不可点。',
      dataSource: '行数据 state（0 禁用 / 1 启用）。',
      logic: '仅展示域名启停状态；改状态可走行操作「设置状态」弹窗，也可在「编辑」弹窗内的状态开关一并改（两处保存都写回 state）。',
      note: '本页 R47 反转（列内只读 Tag、开关移入弹窗），用户拍板照源站，与 platform/game/mainType 同口径。',
    },

    // ============ 操作（顶部添加 + 2 行操作）============
    {
      anchor: 'act_add',
      name: '添加域名（顶部）',
      group: '操作',
      interaction: '点击顶部「添加域名」打开表单弹窗（约 560px，DomainFormModal）：填域名 / 支持国家 / 支持商户 / 备注 + 状态开关（新增默认启用）后保存。',
      logic: '保存后刷新列表。',
      limit: '表单校验（代码可见）：域名必填且须以 http:// 或 https:// 开头、国家必选、域名不可重复；备注 maxlength 100。',
    },
    {
      anchor: 'act_edit',
      name: '行操作 · 编辑',
      group: '操作',
      interaction: '点击打开同一表单弹窗（约 560px，添加/编辑共用），回显该行域名配置（含状态开关，可一并改状态）。',
      logic: '保存后刷新列表。',
    },
    {
      anchor: 'act_setState',
      name: '行操作 · 设置状态',
      group: '操作',
      interaction: '点击打开状态弹窗（约 460px，DomainStateModal）：信息行 + 开关切启用/禁用。',
      logic: '改域名启停状态的入口之一（R47 状态在弹窗）；「编辑」弹窗内也有状态开关可一并改。保存后刷新列表。',
    },
  ],

  // ============ 字段介绍 tab（列序照镜像；仅列表列 + 定义）============
  fields: [
    { name: 'ID', def: '域名记录的唯一编号。' },
    { name: '域名', def: '对外访问的完整域名（含 http:// 或 https:// 前缀）。' },
    { name: '支持的国家', def: '该域名面向的国家/地区（多值 Tag 展示）。' },
    { name: '支持的商户', def: '该域名归属/服务的商户（多值 Tag 展示）。' },
    { name: '备注', def: '域名的补充说明（镜像原位在第 5 列，R66 破例）。' },
    { name: '状态', def: '域名当前启停状态：启用 / 禁用。' },
    { name: '创建人', def: '创建该域名记录的操作账号。' },
    { name: '创建时间', def: '域名记录创建时间（按商户时区展示）。' },
    { name: '最后修改人', def: '最近一次修改该域名的操作账号（展示名由「修改人」改来）。' },
    { name: '最后修改时间', def: '域名记录最近一次修改时间（按商户时区展示）。' },
  ],
};

export default manual;
