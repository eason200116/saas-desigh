<template>
  <!-- 全局导出交互：点击展开格式下拉（Excel/CSV），选定格式后再触发原导出逻辑 -->
  <n-dropdown trigger="click" :options="formatOptions" @select="handleSelect">
    <n-button size="small" :loading="loading" v-bind="$attrs">
      <template #icon>
        <n-icon><DownloadOutlined /></n-icon>
      </template>
      {{ t('common.download.export') }}
    </n-button>
  </n-dropdown>
</template>

<script setup lang="ts">
  import { computed } from 'vue';
  import { NButton, NDropdown, NIcon } from 'naive-ui';
  import { DownloadOutlined } from '@vicons/antd';
  import { useI18n } from 'vue-i18n';

  defineOptions({ name: 'ExportButton', inheritAttrs: false });

  defineProps<{ loading?: boolean }>();

  // click：兼容各页既有 `@click="handleExport"`（选定格式后触发，format 作参数透传，旧 handler 可忽略）
  // export：新事件，需要拿到所选格式的页面可监听
  const emit = defineEmits<{
    (e: 'click', format: string): void;
    (e: 'export', format: string): void;
  }>();

  const { t } = useI18n();

  const formatOptions = computed(() => [
    { label: t('common.download.formatExcel'), key: 'xlsx' },
    { label: t('common.download.formatCsv'), key: 'csv' },
  ]);

  function handleSelect(key: string) {
    emit('export', key);
    emit('click', key);
  }
</script>
