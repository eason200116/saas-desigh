<template>
  <div class="image-cropper">
    <div class="image-cropper__workspace" :style="workspaceStyle">
      <div v-if="imageUrl" class="image-cropper__viewport">
        <cropper-canvas :key="renderKey" ref="canvasRef" class="image-cropper__canvas" background>
          <cropper-image
            ref="imageElementRef"
            class="image-cropper__image"
            rotatable
            scalable
            translatable
            :src="imageUrl"
            :alt="t('operations.imageCrop.workspaceEmpty')"
            @transform="handleImageTransform"
          />
          <cropper-shade hidden />
          <cropper-handle action="select" plain />
          <cropper-selection
            ref="selectionElementRef"
            class="image-cropper__selection"
            movable
            resizable
            initial-coverage="0.6"
            @change="handleSelectionChange"
          >
            <cropper-grid role="grid" bordered covered />
            <cropper-crosshair centered />
            <cropper-handle action="move" theme-color="rgba(255, 255, 255, 0.35)" />
            <cropper-handle action="n-resize" />
            <cropper-handle action="e-resize" />
            <cropper-handle action="s-resize" />
            <cropper-handle action="w-resize" />
            <cropper-handle action="ne-resize" />
            <cropper-handle action="nw-resize" />
            <cropper-handle action="se-resize" />
            <cropper-handle action="sw-resize" />
          </cropper-selection>
        </cropper-canvas>
      </div>
      <n-empty v-else :description="t('common.noData')" class="image-cropper__empty" />
    </div>

    <div v-if="showActions" class="image-cropper__toolbar">
      <div v-if="showZoomSlider" class="image-cropper__toolbar-row">
        <span class="image-cropper__toolbar-label">{{ t('operations.imageCrop.zoom') }}</span>
        <n-slider
          v-model:value="zoomPercent"
          :min="Math.round(MIN_ZOOM * 100)"
          :max="Math.round(MAX_ZOOM * 100)"
          :step="1"
          class="image-cropper__slider"
        />
      </div>

      <div class="image-cropper__toolbar-row">
        <n-space :size="8" wrap>
          <n-button size="small" @click="zoomOut()">
            {{ t('operations.imageCrop.zoomOut') }}
          </n-button>
          <n-button size="small" @click="zoomIn()">
            {{ t('operations.imageCrop.zoomIn') }}
          </n-button>
          <n-button size="small" @click="rotateLeft()">
            {{ t('operations.imageCrop.rotateLeft') }}
          </n-button>
          <n-button size="small" @click="rotateRight()">
            {{ t('operations.imageCrop.rotateRight') }}
          </n-button>
          <n-button size="small" @click="toggleFlipX()">
            {{ t('operations.imageCrop.flipHorizontal') }}
          </n-button>
          <n-button size="small" @click="toggleFlipY()">
            {{ t('operations.imageCrop.flipVertical') }}
          </n-button>
          <n-button size="small" @click="toggleDragMode()">
            {{
              dragMode === 'move'
                ? t('operations.imageCrop.dragModeFree')
                : t('operations.imageCrop.dragModeLocked')
            }}
          </n-button>
          <n-button size="small" @click="reset()">
            {{ t('operations.imageCrop.resetCropper') }}
          </n-button>
        </n-space>
      </div>

      <div class="image-cropper__toolbar-row image-cropper__toolbar-row--footer">
        <n-space justify="end" class="w-full">
          <n-button v-if="showCancel" @click="emit('cancel')">
            {{ t('common.cancel') }}
          </n-button>
          <n-button type="primary" @click="handleConfirm">
            {{ t('common.confirm') }}
          </n-button>
        </n-space>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
  import 'cropperjs';

  import { computed, nextTick, onBeforeUnmount, ref, watch } from 'vue';
  import type { CropperCanvas, CropperImage, CropperSelection } from 'cropperjs';
  import { useI18n } from 'vue-i18n';
  import {
    clamp,
    isQualityAdjustableMimeType,
    normalizeMimeType,
    type CropRequestOptions as CropOptions,
    type DragMode,
    type SupportedExportMimeType,
  } from './useImageCropper';

  interface ImageCropData {
    x: number;
    y: number;
    width: number;
    height: number;
    selectionX: number;
    selectionY: number;
    selectionWidth: number;
    selectionHeight: number;
    transform: ImageTransformMatrix;
    rotate: number;
    scaleX: number;
    scaleY: number;
    zoom: number;
    dragMode: DragMode;
  }

  type ImageTransformMatrix = [number, number, number, number, number, number];

  type CropperSelectionWithCanvas = CropperSelection & {
    $toCanvas: (options?: {
      width?: number;
      height?: number;
      beforeDraw?: (context: CanvasRenderingContext2D, canvas: HTMLCanvasElement) => void;
    }) => Promise<HTMLCanvasElement>;
  };

  const MIN_ZOOM = 0.1;
  const MAX_ZOOM = 4;
  const ZOOM_STEP = 0.1;
  const DEFAULT_MATRIX: ImageTransformMatrix = [1, 0, 0, 1, 0, 0];

  const props = withDefaults(
    defineProps<{
      file: File | Blob;
      aspectRatio?: number;
      outputWidth?: number;
      outputHeight?: number;
      viewportMaxWidth?: number;
      viewportMaxHeight?: number;
      showActions?: boolean;
      showCancel?: boolean;
      showZoomSlider?: boolean;
    }>(),
    {
      aspectRatio: 0,
      outputWidth: 0,
      outputHeight: 0,
      viewportMaxWidth: 520,
      viewportMaxHeight: 320,
      showActions: true,
      showCancel: true,
      showZoomSlider: true,
    },
  );

  const emit = defineEmits<{
    (e: 'cancel'): void;
    (e: 'confirm', value: Blob): void;
    (e: 'change', value: ImageCropData): void;
  }>();

  const { t } = useI18n();

  const canvasRef = ref<CropperCanvas | null>(null);
  const imageElementRef = ref<CropperImage | null>(null);
  const selectionElementRef = ref<CropperSelectionWithCanvas | null>(null);

  const imageUrl = ref('');
  const renderKey = ref(0);
  const setupToken = ref(0);
  const isReady = ref(false);

  const dragMode = ref<DragMode>('move');
  const zoomLevel = ref(1);
  const rotation = ref(0);
  const flipX = ref<1 | -1>(1);
  const flipY = ref<1 | -1>(1);
  const baseMatrix = ref<ImageTransformMatrix>([...DEFAULT_MATRIX]);

  const effectiveAspectRatio = computed(() => {
    if (props.aspectRatio && props.aspectRatio > 0) return props.aspectRatio;
    if (props.outputWidth > 0 && props.outputHeight > 0) {
      return props.outputWidth / props.outputHeight;
    }
    return Number.NaN;
  });

  const workspaceStyle = computed(() => ({
    '--image-cropper-viewport-max-width': `${Math.max(props.viewportMaxWidth, 120)}px`,
    '--image-cropper-viewport-max-height': `${Math.max(props.viewportMaxHeight, 120)}px`,
  }));

  const zoomPercent = computed({
    get: () => Math.round(zoomLevel.value * 100),
    set: (value: number) => {
      zoomTo(clamp(value / 100, MIN_ZOOM, MAX_ZOOM));
    },
  });

  function revokeImageUrl() {
    if (!imageUrl.value) return;
    URL.revokeObjectURL(imageUrl.value);
    imageUrl.value = '';
  }

  function getPreferredMimeType() {
    // 与业务页面共享的 mime 标准化逻辑
    return normalizeMimeType(props.file.type) || 'image/png';
  }

  function getOutputSize(options?: CropOptions) {
    const fallbackWidth = Math.max(Math.round(selectionElementRef.value?.width || 0), 1);
    const fallbackHeight = Math.max(Math.round(selectionElementRef.value?.height || 0), 1);

    const width = options?.width ?? props.outputWidth ?? fallbackWidth;
    const height = options?.height ?? props.outputHeight ?? fallbackHeight;

    return {
      width: Math.max(1, Math.round(width || fallbackWidth)),
      height: Math.max(1, Math.round(height || fallbackHeight)),
    };
  }

  function getSelectionBox() {
    const selection = selectionElementRef.value;
    if (!selection) {
      return {
        x: 0,
        y: 0,
        width: 0,
        height: 0,
      };
    }

    return {
      x: Math.round(selection.x),
      y: Math.round(selection.y),
      width: Math.round(selection.width),
      height: Math.round(selection.height),
    };
  }

  function getImageTransformMatrix(): ImageTransformMatrix {
    const image = imageElementRef.value;
    const matrix = image?.$getTransform();

    return [
      Number(matrix?.[0] ?? DEFAULT_MATRIX[0]),
      Number(matrix?.[1] ?? DEFAULT_MATRIX[1]),
      Number(matrix?.[2] ?? DEFAULT_MATRIX[2]),
      Number(matrix?.[3] ?? DEFAULT_MATRIX[3]),
      Number(matrix?.[4] ?? DEFAULT_MATRIX[4]),
      Number(matrix?.[5] ?? DEFAULT_MATRIX[5]),
    ];
  }

  function getImageNaturalSize() {
    const image = imageElementRef.value;
    if (!image) return null;

    const styleWidth = Number.parseFloat(image.style.width || '');
    const styleHeight = Number.parseFloat(image.style.height || '');
    const naturalWidth = Number.isFinite(styleWidth) ? styleWidth : image.offsetWidth;
    const naturalHeight = Number.isFinite(styleHeight) ? styleHeight : image.offsetHeight;

    if (!naturalWidth || !naturalHeight) {
      return null;
    }

    return {
      width: naturalWidth,
      height: naturalHeight,
    };
  }

  function mapCanvasPointToImagePoint(
    pointX: number,
    pointY: number,
    matrix: ImageTransformMatrix,
    naturalWidth: number,
    naturalHeight: number,
  ) {
    const [a, b, c, d, e, f] = matrix;
    const determinant = a * d - b * c;

    if (!Number.isFinite(determinant) || Math.abs(determinant) < 1e-8) {
      return {
        x: pointX,
        y: pointY,
      };
    }

    const centerX = naturalWidth / 2;
    const centerY = naturalHeight / 2;
    const translateX = e + centerX - a * centerX - c * centerY;
    const translateY = f + centerY - b * centerX - d * centerY;
    const offsetX = pointX - translateX;
    const offsetY = pointY - translateY;

    return {
      x: (offsetX * d - c * offsetY) / determinant,
      y: (offsetY * a - b * offsetX) / determinant,
    };
  }

  function getCropBoundsInImageSpace(selectionBox: ReturnType<typeof getSelectionBox>) {
    const naturalSize = getImageNaturalSize();
    const transform = getImageTransformMatrix();

    if (!naturalSize) {
      return {
        x: selectionBox.x,
        y: selectionBox.y,
        width: selectionBox.width,
        height: selectionBox.height,
        transform,
      };
    }

    const corners = [
      mapCanvasPointToImagePoint(
        selectionBox.x,
        selectionBox.y,
        transform,
        naturalSize.width,
        naturalSize.height,
      ),
      mapCanvasPointToImagePoint(
        selectionBox.x + selectionBox.width,
        selectionBox.y,
        transform,
        naturalSize.width,
        naturalSize.height,
      ),
      mapCanvasPointToImagePoint(
        selectionBox.x,
        selectionBox.y + selectionBox.height,
        transform,
        naturalSize.width,
        naturalSize.height,
      ),
      mapCanvasPointToImagePoint(
        selectionBox.x + selectionBox.width,
        selectionBox.y + selectionBox.height,
        transform,
        naturalSize.width,
        naturalSize.height,
      ),
    ];

    const xs = corners.map((corner) => corner.x);
    const ys = corners.map((corner) => corner.y);
    const minX = Math.min(...xs);
    const maxX = Math.max(...xs);
    const minY = Math.min(...ys);
    const maxY = Math.max(...ys);

    return {
      x: Math.round(minX),
      y: Math.round(minY),
      width: Math.max(0, Math.round(maxX - minX)),
      height: Math.max(0, Math.round(maxY - minY)),
      transform,
    };
  }

  function getCurrentScale() {
    const image = imageElementRef.value;
    if (!image) return zoomLevel.value;

    const matrix = image.$getTransform();
    const base = baseMatrix.value;
    const baseScale = Math.hypot(base[0] || 1, base[1] || 0) || 1;
    const currentScale = Math.hypot(matrix[0] || 1, matrix[1] || 0) || 1;

    return currentScale / baseScale;
  }

  function getCropData(): ImageCropData {
    const selectionBox = getSelectionBox();
    const cropBounds = getCropBoundsInImageSpace(selectionBox);

    return {
      x: cropBounds.x,
      y: cropBounds.y,
      width: cropBounds.width,
      height: cropBounds.height,
      selectionX: selectionBox.x,
      selectionY: selectionBox.y,
      selectionWidth: selectionBox.width,
      selectionHeight: selectionBox.height,
      transform: cropBounds.transform,
      rotate: ((rotation.value % 360) + 360) % 360,
      scaleX: flipX.value,
      scaleY: flipY.value,
      zoom: Number(getCurrentScale().toFixed(4)),
      dragMode: dragMode.value,
    };
  }

  function emitCropChange() {
    emit('change', getCropData());
  }

  function syncDragMode() {
    const image = imageElementRef.value;
    const canvas = canvasRef.value;
    if (!image || !canvas) return;

    image.translatable = dragMode.value === 'move';
    canvas.$setAction(dragMode.value === 'move' ? 'move' : 'none');
  }

  function syncSelectionOptions() {
    const selection = selectionElementRef.value;
    if (!selection) return;

    const nextAspectRatio = effectiveAspectRatio.value;
    const normalizedRatio =
      Number.isFinite(nextAspectRatio) && nextAspectRatio > 0 ? nextAspectRatio : Number.NaN;

    selection.movable = dragMode.value === 'move';
    selection.resizable = true;
    selection.initialAspectRatio = normalizedRatio;
    selection.aspectRatio = normalizedRatio;
  }

  async function initializeCropper() {
    const token = ++setupToken.value;

    await nextTick();

    const image = imageElementRef.value;
    if (!image) return;

    try {
      await image.$ready();
      if (token !== setupToken.value) return;

      baseMatrix.value = getImageTransformMatrix();
      isReady.value = true;
      zoomLevel.value = 1;
      rotation.value = 0;
      flipX.value = 1;
      flipY.value = 1;
      syncDragMode();
      syncSelectionOptions();
      await nextTick();
      if (token !== setupToken.value) return;
      emitCropChange();
    } catch {
      if (token !== setupToken.value) return;
      isReady.value = false;
    }
  }

  function zoomTo(targetZoom: number) {
    const image = imageElementRef.value;
    if (!image || !isReady.value) return;

    const nextZoom = clamp(targetZoom, MIN_ZOOM, MAX_ZOOM);
    const currentZoom = getCurrentScale();
    if (!currentZoom) return;

    const ratio = nextZoom / currentZoom;
    if (Math.abs(ratio - 1) < 0.001) return;

    const delta = ratio >= 1 ? ratio - 1 : 1 - 1 / ratio;
    image.$zoom(delta);
    zoomLevel.value = nextZoom;
    emitCropChange();
  }

  function zoomIn() {
    zoomTo(getCurrentScale() + ZOOM_STEP);
  }

  function zoomOut() {
    zoomTo(getCurrentScale() - ZOOM_STEP);
  }

  function rotateBy(degrees: number) {
    const image = imageElementRef.value;
    if (!image || !isReady.value) return;
    if (!Number.isFinite(degrees) || Math.abs(degrees) < 0.001) return;

    image.$rotate(`${degrees}deg`);
    rotation.value = (((rotation.value + degrees) % 360) + 360) % 360;
    emitCropChange();
  }

  function rotateLeft() {
    rotateBy(-90);
  }

  function rotateRight() {
    rotateBy(90);
  }

  function toggleFlipX() {
    const image = imageElementRef.value;
    if (!image || !isReady.value) return;

    image.$scale(-1, 1);
    flipX.value = flipX.value === 1 ? -1 : 1;
    emitCropChange();
  }

  function toggleFlipY() {
    const image = imageElementRef.value;
    if (!image || !isReady.value) return;

    image.$scale(1, -1);
    flipY.value = flipY.value === 1 ? -1 : 1;
    emitCropChange();
  }

  function setDragMode(mode: DragMode) {
    dragMode.value = mode;
    syncDragMode();
    syncSelectionOptions();
    emitCropChange();
  }

  function toggleDragMode() {
    setDragMode(dragMode.value === 'move' ? 'none' : 'move');
  }

  function reset() {
    const image = imageElementRef.value;
    const selection = selectionElementRef.value;
    if (!image || !selection || !isReady.value) return;

    image.$setTransform(baseMatrix.value);
    dragMode.value = 'move';
    syncDragMode();
    syncSelectionOptions();
    selection.$reset();
    zoomLevel.value = 1;
    rotation.value = 0;
    flipX.value = 1;
    flipY.value = 1;
    emitCropChange();
  }

  function getOutputQuality(type: SupportedExportMimeType, quality?: number) {
    if (!isQualityAdjustableMimeType(type)) return undefined;
    if (typeof quality === 'number' && Number.isFinite(quality)) {
      return clamp(quality, 0, 1);
    }
    return 0.92;
  }

  async function toBlob(
    canvas: HTMLCanvasElement,
    type: SupportedExportMimeType,
    quality?: number,
  ) {
    return await new Promise<Blob>((resolve, reject) => {
      const handleBlob = (blob: Blob | null) => {
        if (blob) {
          resolve(blob);
          return;
        }

        reject(new Error('Failed to generate cropped image blob.'));
      };

      canvas.toBlob(handleBlob, type, quality);
    });
  }

  async function crop(options?: CropOptions) {
    const selection = selectionElementRef.value;
    if (!selection || !isReady.value) {
      throw new Error('Cropper is not ready.');
    }

    const outputSize = getOutputSize(options);
    const preferredType = options?.type
      ? normalizeMimeType(options.type) || 'image/png'
      : getPreferredMimeType();
    const outputQuality = getOutputQuality(preferredType, options?.quality);
    const canvas = await selection.$toCanvas({
      width: outputSize.width,
      height: outputSize.height,
      beforeDraw:
        preferredType === 'image/jpeg'
          ? (context, nextCanvas) => {
              context.fillStyle = '#ffffff';
              context.fillRect(0, 0, nextCanvas.width, nextCanvas.height);
            }
          : undefined,
    });

    return await toBlob(canvas, preferredType, outputQuality);
  }

  async function handleConfirm() {
    const blob = await crop();
    emit('confirm', blob);
  }

  function handleSelectionChange() {
    if (!isReady.value) return;
    emitCropChange();
  }

  function handleImageTransform() {
    if (!isReady.value) return;
    zoomLevel.value = clamp(getCurrentScale(), MIN_ZOOM, MAX_ZOOM);
    emitCropChange();
  }

  watch(
    () => props.file,
    () => {
      revokeImageUrl();
      imageUrl.value = URL.createObjectURL(props.file);
      renderKey.value += 1;
      isReady.value = false;
      dragMode.value = 'move';
      zoomLevel.value = 1;
      rotation.value = 0;
      flipX.value = 1;
      flipY.value = 1;
      baseMatrix.value = [...DEFAULT_MATRIX];
      void initializeCropper();
    },
    { immediate: true },
  );

  watch(
    effectiveAspectRatio,
    () => {
      if (!isReady.value) return;
      syncSelectionOptions();
      void nextTick().then(() => {
        emitCropChange();
      });
    },
    { flush: 'post' },
  );

  onBeforeUnmount(() => {
    revokeImageUrl();
    setupToken.value += 1;
  });

  defineExpose({
    crop,
    reset,
    zoomIn,
    zoomOut,
    rotateBy,
    rotateLeft,
    rotateRight,
    toggleFlipX,
    toggleFlipY,
    setDragMode,
    getCropData,
  });
</script>

<style scoped>
  .image-cropper {
    display: flex;
    flex: 1;
    flex-direction: column;
    gap: 12px;
    min-height: 0;
  }

  .image-cropper__workspace {
    display: flex;
    flex: 1;
    min-height: 0;
    align-items: center;
    justify-content: center;
    border: 1px solid var(--n-border-color);
    border-radius: 8px;
    background:
      linear-gradient(
        45deg,
        rgb(0 0 0 / 0.02) 25%,
        transparent 25%,
        transparent 75%,
        rgb(0 0 0 / 0.02) 75%
      ),
      linear-gradient(
        45deg,
        rgb(0 0 0 / 0.02) 25%,
        transparent 25%,
        transparent 75%,
        rgb(0 0 0 / 0.02) 75%
      );
    background-color: var(--n-color);
    background-position:
      0 0,
      8px 8px;
    background-size: 16px 16px;
    overflow: hidden;
  }

  .image-cropper__viewport {
    display: flex;
    flex: 0 1 auto;
    inline-size: min(100%, var(--image-cropper-viewport-max-width));
    block-size: min(100%, var(--image-cropper-viewport-max-height));
    min-width: 0;
    min-height: 0;
    margin: auto;
  }

  .image-cropper__canvas {
    display: block;
    inline-size: 100%;
    block-size: 100%;
    min-width: 0;
    min-height: 0;
  }

  .image-cropper__image,
  .image-cropper__selection {
    min-width: 0;
    min-height: 0;
  }

  .image-cropper__empty {
    display: grid;
    flex: 1;
    min-height: 180px;
    place-items: center;
    width: 100%;
    height: 100%;
  }

  .image-cropper__toolbar {
    display: flex;
    flex-direction: column;
    gap: 12px;
  }

  .image-cropper__toolbar-row {
    display: flex;
    align-items: center;
    gap: 12px;
  }

  .image-cropper__toolbar-row--footer {
    justify-content: flex-end;
  }

  .image-cropper__toolbar-label {
    flex: 0 0 auto;
    min-width: 48px;
    color: var(--n-text-color-2);
    font-size: 12px;
    line-height: 1.5;
  }

  .image-cropper__slider {
    flex: 1;
  }
</style>
