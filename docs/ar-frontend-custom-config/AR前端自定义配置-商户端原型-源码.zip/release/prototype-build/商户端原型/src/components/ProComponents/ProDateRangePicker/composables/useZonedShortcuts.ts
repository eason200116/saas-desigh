import { computed, unref, type ComputedRef } from 'vue';
import type {
  DateRangeDefaultShortcut,
  DateRangeShortcutPreset,
  DateRangeShortcuts,
  DateRangeTimezone,
  MaybeRef,
  QuickDateItem,
} from '../../types';
import { useEffectiveDateRangeTimezone } from '../useDateRange';
import {
  addDays,
  addMonths,
  endOfDay,
  endOfMonth,
  endOfWeek,
  formatUtcMsInZone,
  nowInZone,
  partsToUtcMs,
  resolveTimezoneId,
  startOfDay,
  startOfMonth,
  startOfWeek,
  toDateKey,
  utcMsToParts,
  type ZonedDateTimeParts,
} from '../utils/zonedDateMath';

type TranslateFn = (key: string, params?: Record<string, unknown>) => string;

/** "所有/不限"快捷项的固定 key，匹配高亮与点击清空都通过 `clear: true` 标记识别 */
export const CLEAR_SHORTCUT_KEY = '__clear__';

/**
 * 构造"所有/不限"清空项。
 * - `value: [0, 0]` 仅占位，handleQuickDateSelect 看到 `clear: true` 会走清空分支
 * - matchShortcutIndexByRange 在 range 为空时让首个 `clear: true` 项高亮
 */
export function createClearShortcutItem(t: TranslateFn): QuickDateItem {
  return {
    key: CLEAR_SHORTCUT_KEY,
    label: t('common.dateShortcuts.all'),
    value: [0, 0],
    clear: true,
  };
}

export function useZonedShortcuts(options: {
  timezone?: MaybeRef<DateRangeTimezone | undefined>;
  preset?: MaybeRef<DateRangeShortcutPreset>;
  customShortcuts?: MaybeRef<DateRangeShortcuts | undefined>;
  t: TranslateFn;
}): ComputedRef<QuickDateItem[]> {
  const propTimezone = computed<DateRangeTimezone | undefined>(() => unref(options.timezone));
  const effectiveTimezone = useEffectiveDateRangeTimezone(propTimezone);

  return computed(() => {
    return resolveZonedShortcutItems({
      shortcuts: unref(options.customShortcuts),
      timezoneId: resolveTimezoneId(effectiveTimezone.value),
      preset: unref(options.preset) ?? 'default',
      t: options.t,
    });
  });
}

/**
 * 按 UTC 日级（`Math.floor(ms / 86400000)`）反向匹配 `[ms, ms]` 元组对应的快捷项索引。
 * 用于 ProQuickDateButtons / useRechargeQuickDate 这种已经持有 UTC ms 范围的场景；
 * 面板内部用 PlainDateTime 的版本走 `matchZonedShortcutIndex`。
 */
export function matchShortcutIndexByRange(
  range: [number, number] | number[] | null | undefined,
  shortcuts: QuickDateItem[],
): number | undefined {
  if (!Array.isArray(range) || range.length !== 2) {
    // range 为空：让"所有/不限"项高亮（取首个 clear=true 项）
    const clearIdx = shortcuts.findIndex((item) => item.clear === true);
    return clearIdx >= 0 ? clearIdx : undefined;
  }
  const dayMs = 86400000;
  const startDay = Math.floor(range[0] / dayMs);
  const endDay = Math.floor(range[1] / dayMs);
  for (let i = 0; i < shortcuts.length; i++) {
    if (shortcuts[i].clear) continue; // clear 项的 value 是占位，不参与时间匹配
    const [s, e] = shortcuts[i].value;
    if (Math.floor(s / dayMs) === startDay && Math.floor(e / dayMs) === endDay) return i;
  }
  return undefined;
}

export function matchZonedShortcutIndex(
  draft: { start: ZonedDateTimeParts | null; end: ZonedDateTimeParts | null },
  shortcuts: QuickDateItem[],
  timezone: string | null | undefined,
): number | undefined {
  if (!draft.start || !draft.end) return undefined;
  const timezoneId = resolveTimezoneId(timezone);
  const startKey = toDateKey(draft.start);
  const endKey = toDateKey(draft.end);

  for (let i = 0; i < shortcuts.length; i++) {
    const [start, end] = shortcuts[i].value;
    const shortcutStart = utcMsToParts(start, timezoneId);
    const shortcutEnd = utcMsToParts(end, timezoneId);
    if (!shortcutStart || !shortcutEnd) continue;
    if (toDateKey(shortcutStart) === startKey && toDateKey(shortcutEnd) === endKey) {
      return i;
    }
  }

  return undefined;
}

export function createZonedShortcutItems(
  timezoneId: string,
  preset: DateRangeShortcutPreset,
  t: TranslateFn,
): QuickDateItem[] {
  const builtIns = createZonedBaseShortcutItems(timezoneId, t);
  const now = nowInZone(timezoneId);
  const todayEnd = endOfDay(now);
  const lastN = (n: number, key: string) =>
    createItem(
      key,
      t(`common.dateShortcuts.${key}`),
      startOfDay(addDays(now, -(n - 1))),
      todayEnd,
      timezoneId,
    );
  // default = ProCrudTable 搜索区通用 9 项：今天/昨天/本周/上周/本月/上月/近7天/近30天/近60天
  // last3Days/last15Days 与近 7 天/近 30 天高度重叠，已下沉到 report 预设；
  // 仍需短/中跨度的页面请显式声明 shortcutPreset:'report' 或自定 shortcuts。
  const defaults = [
    ...builtIns,
    lastN(7, 'last7Days'),
    lastN(30, 'last30Days'),
    // lastN(60, 'last60Days'),
  ];

  // simple: today / yesterday / last7Days / last30Days（索引基于 default：0=today / 1=yesterday / 6=last7Days / 7=last30Days）
  if (preset === 'simple') return [defaults[0], defaults[1], defaults[6], defaults[7]];
  // report: 含 last3/15/60/90 的最完整跨度
  if (preset === 'report')
    return [
      ...builtIns,
      lastN(3, 'last3Days'),
      lastN(7, 'last7Days'),
      lastN(15, 'last15Days'),
      lastN(30, 'last30Days'),
      lastN(60, 'last60Days'),
      lastN(90, 'last90Days'),
    ];
  // reportCompact: 数据概况等报表常用 6 项；与 last7Days/last30Days 共享 ms range（startOfDay~endOfDay），
  // 仅 label 用 nearOneWeek / nearOneMonth，配合 i18n zh 显示为"近一周/近一月"。
  if (preset === 'reportCompact') {
    return [
      builtIns[0], // today
      builtIns[1], // yesterday
      lastN(3, 'last3Days'),
      lastN(7, 'nearOneWeek'),
      lastN(15, 'last15Days'),
      lastN(30, 'nearOneMonth'),
    ];
  }

  // default（含未指定）= 全局标准搜索快捷项：今天/昨天/本周/上周/本月/上月/所有。
  // 用户 2026-06-23 指定：时间控件精确到时分秒 + 可跨天跨月 + 仅这 7 个快捷项（"所有"=清空查全部）。
  // 与工具栏 quick-date 的「6 基础项 + 所有」对齐；仍需近7/近30天等长跨度的页面请显式用 shortcutPreset:'report'。
  // 注：上方 `defaults`（含近7/近30天）保留给 'simple' 预设按下标取项，勿删。
  return [...builtIns, createClearShortcutItem(t)];
}

export function createZonedBaseShortcutItems(timezoneId: string, t: TranslateFn): QuickDateItem[] {
  const now = nowInZone(timezoneId);
  const todayStart = startOfDay(now);
  const todayEnd = endOfDay(now);
  const yesterday = addDays(todayStart, -1);
  const thisWeekStart = startOfWeek(now);
  const lastWeekStart = addDays(thisWeekStart, -7);
  const thisMonthStart = startOfMonth(now);
  const lastMonthStart = startOfMonth(addMonths(now, -1));

  return [
    createItem('today', t('common.dateShortcuts.today'), todayStart, todayEnd, timezoneId),
    createItem(
      'yesterday',
      t('common.dateShortcuts.yesterday'),
      startOfDay(yesterday),
      endOfDay(yesterday),
      timezoneId,
    ),
    createItem('thisWeek', t('common.dateShortcuts.thisWeek'), thisWeekStart, todayEnd, timezoneId),
    createItem(
      'lastWeek',
      t('common.dateShortcuts.lastWeek'),
      lastWeekStart,
      endOfWeek(lastWeekStart),
      timezoneId,
    ),
    createItem(
      'thisMonth',
      t('common.dateShortcuts.thisMonth'),
      thisMonthStart,
      todayEnd,
      timezoneId,
    ),
    createItem(
      'lastMonth',
      t('common.dateShortcuts.lastMonth'),
      lastMonthStart,
      endOfMonth(lastMonthStart),
      timezoneId,
    ),
  ];
}

export function createZonedDefaultShortcutValue(options: {
  defaultShortcut: DateRangeDefaultShortcut | undefined;
  timezoneId: string;
  valueFormat: 'timestamp' | 'string';
  valueStringPattern: string;
  preset: DateRangeShortcutPreset;
  t: TranslateFn;
}): [number, number] | [string, string] | null {
  const key = options.defaultShortcut;
  if (!key) return null;

  const shortcuts = createZonedShortcutItems(options.timezoneId, options.preset, options.t);
  const shortcut = shortcuts.find((item) => item.key === key);
  if (!shortcut) return null;

  if (options.valueFormat === 'string') {
    return [
      formatUtcMsInZone(shortcut.value[0], options.timezoneId, options.valueStringPattern),
      formatUtcMsInZone(shortcut.value[1], options.timezoneId, options.valueStringPattern),
    ];
  }

  return shortcut.value;
}

function resolveZonedShortcutItems(options: {
  shortcuts: DateRangeShortcuts | undefined;
  timezoneId: string;
  preset: DateRangeShortcutPreset;
  t: TranslateFn;
}): QuickDateItem[] {
  if (Array.isArray(options.shortcuts)) return options.shortcuts;
  if (options.shortcuts === false) return [];
  return createZonedShortcutItems(options.timezoneId, options.preset, options.t);
}

function createItem(
  key: string,
  label: string,
  start: ZonedDateTimeParts,
  end: ZonedDateTimeParts,
  timezoneId: string,
): QuickDateItem {
  return {
    key,
    label,
    value: [partsToUtcMs(start, timezoneId), partsToUtcMs(end, timezoneId)],
  };
}
