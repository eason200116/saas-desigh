// 会员上下分记录（总控端 admin · game_member_transfer）功能说明书。
// 锚定 src/views/game/member/transfer/index.vue + data.ts 真实控件（R53 实证、不臆造）。
// 标准 ProCrudTable 列表页：9 搜索项（商户+代理合并格）+ 12 列 + 账变类型/交易状态双 Tag；纯查询、无行操作。

import type { PageManual } from '../types';

const manual: PageManual = {
  route: 'game_member_transfer',
  title: '会员上下分记录',
  overview:
    '总控端查询会员在游戏钱包与主钱包之间的上下分（转账）记录：按商户 + 代理、平台订单号、会员ID / 商户会员ID、触发上分游戏厂商、转账类型、交易状态、币种、时间筛选。转账金额上分为正绿、下分为负红（R61 左对齐）。本页只查询、无行操作。',
  items: [
    {
      anchor: 'merchant',
      name: '商户名称（+ 所属代理）',
      group: '搜索',
      interaction: '一格两下拉：左「商户名称」、右「所属代理」，占 2 列宽。',
      dataSource: '商户 MEMBER_MERCHANT_OPTIONS；代理 agentOptionsForMerchant(商户) 随商户联动。',
      logic: '商户选填（无红星）；须先选具体商户才能选代理，换商户清空代理。',
      limit: '选填。',
      edge: '未选商户时代理置灰不可选。',
    },
    {
      anchor: 'platformOrderNo',
      name: '平台订单号',
      group: '搜索',
      interaction: '文本输入、模糊匹配。',
      dataSource: '用户输入。',
      logic: '按平台订单号筛选。',
      limit: '选填；最多 50 字（searchKw）。',
      edge: '空 = 不按平台订单号筛。',
    },
    {
      anchor: 'memberId',
      name: '会员ID',
      group: '搜索',
      interaction: '文本输入、模糊匹配。',
      dataSource: '用户输入。',
      logic: '按平台会员ID筛选。',
      limit: '选填；最多 50 字。',
      edge: '空 = 不按会员ID筛。',
    },
    {
      anchor: 'merchantMemberId',
      name: '商户会员ID',
      group: '搜索',
      interaction: '文本输入、模糊匹配。',
      dataSource: '用户输入。',
      logic: '按商户侧会员ID筛选。',
      limit: '选填；最多 50 字。',
      edge: '空 = 不按商户会员ID筛。',
    },
    {
      anchor: 'triggerVendor',
      name: '触发上分游戏厂商',
      group: '搜索',
      interaction: '下拉单选、可搜索、可清空。',
      dataSource: '选项来自 MEMBER_VENDOR_OPTIONS。',
      logic: '按触发本次上下分的游戏厂商筛选。',
      limit: '选填。',
      edge: '不选 = 全部厂商。',
    },
    {
      anchor: 'transferType',
      name: '转账类型（搜索）',
      group: '搜索',
      interaction: '下拉单选：上分 / 下分，可清空。',
      dataSource: '选项来自 TRANSFER_TYPE_OPTIONS。',
      logic: '按上分 / 下分筛选。',
      limit: '选填。',
    },
    {
      anchor: 'transferState',
      name: '交易状态（搜索）',
      group: '搜索',
      interaction: '下拉单选：成功 / 处理中 / 失败，可清空。',
      dataSource: '选项来自 TRANSFER_STATE_OPTIONS（三值，1:1 照源站）。',
      logic: '按交易状态筛选。',
      limit: '选填。',
    },
    {
      anchor: 'currency',
      name: '币种',
      group: '搜索',
      interaction: '下拉单选、可清空。',
      dataSource: '选项来自 MEMBER_CURRENCY_OPTIONS。',
      logic: '按币种筛选。',
      limit: '选填。',
    },
    {
      anchor: 'transferTimeRange',
      name: '时间',
      group: '搜索',
      interaction: '日期时间范围选择（proDateRange，精确到秒，占 2 列）。',
      dataSource: '用户选择。',
      logic: '按交易时间范围筛选。',
      limit: '不可选未来（allowFuture false）。',
      edge: '空 = 不按时间筛。',
    },

    // ============ 关键列（账变类型 + 交易状态，均只读 Tag）============
    {
      anchor: 'col_transferType',
      name: '账变类型列',
      group: '列',
      interaction: '只读 Tag：转入（上分）绿 / 转出（下分）橙。',
      dataSource: '行数据 transferType（in 上分 / out 下分）。',
      logic: '仅展示上下分方向。',
    },
    {
      anchor: 'col_transferState',
      name: '交易状态列',
      group: '列',
      interaction: '只读 Tag（三值）：成功绿 / 处理中橙 / 失败红。',
      dataSource: '行数据 transferState（success / processing / fail）。',
      logic: '仅展示上下分交易状态。',
    },
  ],

  // ============ 字段介绍 tab（列序照源站；仅列表列 + 定义）============
  fields: [
    { name: '商户名称', def: '会员所属商户。' },
    { name: '代理编码', def: '会员所属代理的编码。' },
    { name: '会员ID', def: '会员的平台ID。' },
    { name: '商户会员ID', def: '会员的商户侧ID。' },
    { name: '平台订单号', def: '本次上下分在平台侧的订单号。' },
    { name: '商户订单号', def: '本次上下分在商户侧的订单号。' },
    { name: '转账金额', def: '本次上下分的金额（上分正绿、下分负红）。' },
    { name: '币种', def: '转账金额的币种。' },
    { name: '触发上分游戏厂商', def: '触发本次上下分的游戏厂商。' },
    { name: '账变类型', def: '转入（上分）/ 转出（下分）。' },
    { name: '交易状态', def: '成功 / 处理中 / 失败。' },
    { name: '交易时间', def: '本次上下分发生时间（按商户时区展示）。' },
  ],
};

export default manual;
