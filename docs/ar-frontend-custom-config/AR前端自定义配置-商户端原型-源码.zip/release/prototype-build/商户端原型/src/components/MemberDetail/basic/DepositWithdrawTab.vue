<template>
  <div class="deposit-split">
    <div class="detail-section deposit-split__card">
      <h4 class="detail-section__title deposit-split__card-title">{{
        t('member.detail.depositWithdraw.depositInfo')
      }}</h4>
      <div class="detail-grid deposit-split__overview">
        <template v-for="(item, idx) in detailData.depositInfo" :key="idx">
          <div v-if="item.spacer" class="detail-cell detail-cell--spacer" />
          <div v-else class="detail-cell">
            <span class="detail-cell__label">{{ item.label }}</span>
            <span
              class="detail-cell__value"
              :class="item.highlight ? `highlight--${item.highlight}` : ''"
            >
              {{ item.value }}
              <span
                v-if="item.timeZoneLabel"
                style="
                  font-size: 12px;
                  font-weight: 400;
                  color: #999;
                  margin-left: 4px;
                  flex-shrink: 0;
                "
                >({{ item.timeZoneLabel }})</span
              >
            </span>
          </div>
        </template>
      </div>
      <div class="deposit-split__recent">
        <div class="deposit-split__divider" />
        <h5 class="deposit-split__sub-title">{{
          t('member.detail.depositWithdraw.last3Deposits')
        }}</h5>
        <n-data-table
          :columns="recentDepositColumns"
          :data="detailData.recentDeposits"
          :bordered="false"
          size="small"
        />
      </div>
    </div>
    <div class="detail-section deposit-split__card">
      <h4 class="detail-section__title deposit-split__card-title">{{
        t('member.detail.depositWithdraw.withdrawInfo')
      }}</h4>
      <div class="detail-grid deposit-split__overview">
        <div v-for="item in detailData.withdrawInfo" :key="item.label" class="detail-cell">
          <span class="detail-cell__label">{{ item.label }}</span>
          <span
            class="detail-cell__value"
            :class="item.highlight ? `highlight--${item.highlight}` : ''"
            >{{ item.value }}</span
          >
        </div>
      </div>
      <div class="deposit-split__recent">
        <div class="deposit-split__divider" />
        <h5 class="deposit-split__sub-title">{{
          t('member.detail.depositWithdraw.last3Withdraws')
        }}</h5>
        <n-data-table
          :columns="recentWithdrawColumns"
          :data="detailData.recentWithdraws"
          :bordered="false"
          size="small"
        />
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
  import { h, computed } from 'vue';
  import { NTag } from 'naive-ui';
  import { useI18n } from 'vue-i18n';
  import { useTenantOptions } from '@/hooks';
  import { useMemberContext } from '../useMemberContext';

  const { t } = useI18n();
  const { detailData, tenantId } = useMemberContext();
  const { renderTenantDateTimeColumnTitle } = useTenantOptions();

  // 通道列渲染：typeId >= 10000 时在通道名称前显示 tag
  function renderChannelCell(typeId: number | null, typeName: string) {
    if (typeId != null && typeId >= 10000) {
      return h('span', { style: 'display: inline-flex; align-items: center; gap: 4px;' }, [
        h(NTag, { size: 'small', bordered: true, type: 'info' }, () => String(typeId)),
        typeName,
      ]);
    }
    return typeName;
  }

  const recentDepositColumns = computed(() => [
    {
      title: renderTenantDateTimeColumnTitle(
        t('member.detail.depositWithdraw.depositTime'),
        tenantId.value,
      ),
      key: 'time',
      titleAlign: 'center' as const,
    },
    {
      title: t('member.detail.depositWithdraw.amount'),
      key: 'amount',
      titleAlign: 'center' as const,
    },
    {
      title: t('member.detail.depositWithdraw.type'),
      key: 'type',
      titleAlign: 'center' as const,
      render: (row: any) => renderChannelCell(row.payTypeId, row.type),
    },
  ]);
  const recentWithdrawColumns = computed(() => [
    {
      title: t('member.detail.depositWithdraw.withdrawMultiplier'),
      key: 'multiple',
      titleAlign: 'center' as const,
      render: (row: any) => {
        const val = row.multiple;
        if (!val || val === '-') return val;
        return h('span', { style: 'color: #dc2626; font-weight: 600' }, val);
      },
    },
    {
      title: renderTenantDateTimeColumnTitle(
        t('member.detail.depositWithdraw.withdrawTime'),
        tenantId.value,
      ),
      key: 'time',
      titleAlign: 'center' as const,
    },
    {
      title: t('member.detail.depositWithdraw.amount'),
      key: 'amount',
      titleAlign: 'center' as const,
    },
    {
      title: t('member.detail.depositWithdraw.type'),
      key: 'type',
      titleAlign: 'center' as const,
      render: (row: any) => renderChannelCell(row.withdrawTypeId, row.type),
    },
  ]);
</script>
