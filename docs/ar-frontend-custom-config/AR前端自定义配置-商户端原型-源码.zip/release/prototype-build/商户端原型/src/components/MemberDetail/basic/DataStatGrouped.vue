<template>
  <!--
    数据统计·卡片化重排 demo（样板会员 1100001/1100002 门控 · 2026-07-16 用户附图定稿）：
    三版块骨架照用户设计图 1:1——
      ① 顶部「今日/累计数据」：6 指标整行卡片（今日值绿 / 累计值蓝，用户图示着色=对 R65 的有意豁免）
      ② 左「今日 / 提现数据」（版块名照图）：人工充值/充值赠送/彩金充值 三张浅绿卡 →
         首充(金额+日期)｜累计提现手续费 → 等待提现(橙) → 次充/三充 折叠行(点击收起日期) →
         最后3次充值/提现 两小表并排
      ③ 右「奖励与投注数据」（版块名照图）：活动奖励信息(4列) / 佣金奖励(3列) / VIP奖励·洗码返水(4列)，
         子标题沿用共享 .detail-grid__subheader 浅蓝条
    字段 38 项全复用现有数据、不加不减不改名（图中「充值差」按现字段「充提差」落地——用户拍板字段不变）。
    数据流仍为视图层分桶：只消费 useMemberContext 的 dataStatSections / recentDeposits / recentWithdraws，
    buildDetailData 与现有三组件零改动；非样板会员走原布局零变化。
  -->
  <div class="dsg-wrap">
    <!-- ① 今日/累计数据：6 指标卡片整行 -->
    <div class="detail-section">
      <div class="detail-section__header">
        <h4 class="detail-section__title">{{ cumTitle }}</h4>
      </div>
      <div class="dsg-cum-row">
        <div v-for="row in rows" :key="row.item" class="dsg-cum-card">
          <div class="dsg-cum-card__name">{{ row.item }}</div>
          <div class="dsg-cum-card__line">
            <span class="dsg-tag">{{ cumNames.today }}</span>
            <span class="dsg-val dsg-val--today">{{ row.today }}</span>
          </div>
          <div class="dsg-cum-card__line">
            <span class="dsg-tag">{{ cumNames.total }}</span>
            <span class="dsg-val dsg-val--total">{{ row.total }}</span>
          </div>
        </div>
      </div>
    </div>

    <div class="dsg-two">
      <!-- ② 今日 / 提现数据（左列） -->
      <div class="detail-section dsg-left">
        <div class="detail-section__header">
          <!-- 版块名「充提数据」：复用现成键 depositWithdrawData（六轮调整①，原临时键 dwPanel 已删） -->
        <h4 class="detail-section__title">{{ t('member.detail.dataStat.depositWithdrawData') }}</h4>
        </div>
        <!-- 首行并列：人工充值 ｜ 累计提现手续费（2026-07-16 用户确认：删「等待提现」卡，
             累计提现手续费移来与人工充值并列一行；原三张绿卡剩下两张下移次行） -->
        <div class="dsg-row2">
          <div class="dsg-mini-card">
            <div class="dsg-mini-card__name">{{ manualRecharge?.label }}</div>
            <div class="dsg-mini-card__val">{{ manualRecharge?.value }}</div>
          </div>
          <div class="dsg-mini-card">
            <div class="dsg-mini-card__name">{{ withdrawFee?.label }}</div>
            <div class="dsg-mini-card__val">{{ withdrawFee?.value }}</div>
          </div>
        </div>
        <!-- 第二行：充值赠送 ｜ 彩金充值（原三张绿卡去掉人工充值后剩下两张） -->
        <div class="dsg-row2">
          <div v-for="it in rechargeRest2" :key="it.label" class="dsg-mini-card">
            <div class="dsg-mini-card__name">{{ it.label }}</div>
            <div class="dsg-mini-card__val">{{ it.value }}</div>
          </div>
        </div>
        <!-- 首充 / 次充 / 三充：同款静态行（首充并入=2026-07-16 用户二轮调整③；
             收缩箭头及折叠交互已按四轮调整②移除，日期恒显） -->
        <div v-for="it in foldDeposits" :key="it.label" class="dsg-fold">
          <span class="dsg-fold__name">{{ it.label }}</span>
          <span class="dsg-fold__val">{{ it.value }}</span>
          <span class="dsg-fold__date">{{ it.dateNote }}</span>
        </div>
        <!-- 最后3次充值 / 提现 两小表并排 -->
        <div class="dsg-tables">
          <div class="dsg-tablecol">
            <span class="dsg-sub">{{ t('member.detail.depositWithdraw.last3Deposits') }}</span>
            <n-data-table
              class="dsg-table"
              :columns="depositCols"
              :data="recentDeposits"
              :bordered="false"
              size="small"
            />
          </div>
          <div class="dsg-tablecol">
            <span class="dsg-sub">{{ t('member.detail.depositWithdraw.last3Withdraws') }}</span>
            <n-data-table
              class="dsg-table"
              :columns="withdrawCols"
              :data="recentWithdraws"
              :bordered="false"
              size="small"
            />
          </div>
        </div>
      </div>

      <!-- ③ 奖励与投注数据（右列） -->
      <div class="detail-section dsg-right">
        <div class="detail-section__header">
          <h4 class="detail-section__title">{{ t('member.detail.dataStat.rewardPanel') }}</h4>
        </div>
        <template v-for="group in activityGroups" :key="group.title">
          <div class="detail-grid__subheader dsg-subheader">{{ group.title }}</div>
          <div
            class="detail-grid dsg-reward-grid"
            :style="{ gridTemplateColumns: `repeat(${group.columns}, minmax(0, 1fr))` }"
          >
            <div v-for="(it, idx) in group.items" :key="it.label || `g-${idx}`" class="detail-cell">
              <span class="detail-cell__label"
                >{{ it.label }}<span v-if="it.changed" class="ar-changemark">改</span></span
              >
              <span
                class="detail-cell__value"
                :class="it.highlight ? `highlight--${it.highlight}` : ''"
                >{{ it.value }}</span
              >
            </div>
          </div>
        </template>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
  import { h, computed } from 'vue';
  import { NTag } from 'naive-ui';
  import { useI18n } from 'vue-i18n';
  import { useTenantOptions } from '@/hooks';
  import { useMemberContext } from '../useMemberContext';

  const { t } = useI18n();
  const { detailData, tenantId } = useMemberContext();
  const { renderTenantDateTimeColumnTitle } = useTenantOptions();

  const sections = computed<any[]>(() => detailData.value.dataStatSections || []);

  /** ① 今日/累计：rows 全 6 指标整行（顺序=充值/提现/充提差/有效投注/输赢/活动优惠，同 buildDetailData） */
  const cumSection = computed<any>(
    () => sections.value.find((s: any) => s.type === 'cumulativeList') || null,
  );
  const cumTitle = computed(() => cumSection.value?.title || '');
  const cumNames = computed(() => ({
    today: cumSection.value?.cumulative?.todayName || '',
    total: cumSection.value?.cumulative?.totalName || '',
  }));
  const rows = computed<any[]>(() => cumSection.value?.cumulative?.rows || []);

  /** ② 充提字段（索引序=人工充值/充值赠送/彩金充值/首充/次充/三充；提现侧=等待提现/累计提现手续费） */
  const dw = computed<any>(
    () => sections.value.find((s: any) => s.type === 'depositWithdraw')?.dw || null,
  );
  const rechargeItems = computed<any[]>(() => dw.value?.rechargeItems || []);
  const withdrawItems = computed<any[]>(() => dw.value?.withdrawItems || []);
  // 首行「人工充值 ｜ 累计提现手续费」并列（2026-07-16 用户确认）：删「等待提现」withdrawItems[0] 不再渲染；
  // 累计提现手续费 withdrawItems[1] 移来与人工充值 rechargeItems[0] 并列一行；充值赠送/彩金充值下移次行。
  const manualRecharge = computed(() => rechargeItems.value[0]);
  const rechargeRest2 = computed(() => rechargeItems.value.slice(1, 3));
  const foldDeposits = computed(() => rechargeItems.value.slice(3, 6));
  const withdrawFee = computed(() => withdrawItems.value[1]);

  /** ③ 奖励与投注数据三组（标题/字段沿用各 section 现成内容；列数照图：4/3/4） */
  const secByKey = (k: string) => sections.value.find((s: any) => s.key === k);
  const activityGroups = computed(() => {
    const act = secByKey('dcActivity');
    const comm = secByKey('dcCommission');
    const vip = secByKey('dcVip');
    const wash = secByKey('dcWash');
    return [
      act && { title: act.title, items: act.items || [], columns: 4 },
      comm && { title: comm.title, items: comm.items || [], columns: 3 },
      (vip || wash) && {
        title: [vip?.title, wash?.title].filter(Boolean).join(' / '),
        items: [...(vip?.items || []), ...(wash?.items || [])],
        columns: 4,
      },
    ].filter((g: any) => g && g.items.length) as {
      title: string;
      items: any[];
      columns: number;
    }[];
  });

  /** 最后3次充值/提现（列定义与 DataStatDepositWithdraw 同款：通道 tag / 打码倍数红字） */
  const recentDeposits = computed<any[]>(() => detailData.value.recentDeposits || []);
  const recentWithdraws = computed<any[]>(() => detailData.value.recentWithdraws || []);

  function renderChannelCell(typeId: number | null, typeName: string) {
    if (typeId != null && typeId >= 10000) {
      return h('span', { style: 'display: inline-flex; align-items: center; gap: 4px;' }, [
        h(NTag, { size: 'small', bordered: true, type: 'info' }, () => String(typeId)),
        typeName,
      ]);
    }
    return typeName;
  }

  const depositCols = computed(() => [
    {
      title: renderTenantDateTimeColumnTitle(
        t('member.detail.depositWithdraw.depositTime'),
        tenantId.value,
      ),
      key: 'time',
      titleAlign: 'center' as const,
      align: 'center' as const,
    },
    {
      title: t('member.detail.depositWithdraw.amount'),
      key: 'amount',
      titleAlign: 'center' as const,
      align: 'center' as const,
    },
    {
      title: t('member.detail.depositWithdraw.type'),
      key: 'type',
      titleAlign: 'center' as const,
      align: 'center' as const,
      render: (row: any) => renderChannelCell(row.payTypeId, row.type),
    },
  ]);

  const withdrawCols = computed(() => [
    {
      title: renderTenantDateTimeColumnTitle(
        t('member.detail.depositWithdraw.withdrawTime'),
        tenantId.value,
      ),
      key: 'time',
      titleAlign: 'center' as const,
      align: 'center' as const,
    },
    {
      title: t('member.detail.dataStat.codingMultiplier'),
      key: 'multiple',
      titleAlign: 'center' as const,
      align: 'center' as const,
      render: (row: any) => {
        const val = row.multiple;
        if (!val || val === '-') return val;
        return h('span', { style: 'color: #dc2626; font-weight: 600' }, val);
      },
    },
    {
      title: t('member.detail.depositWithdraw.amount'),
      key: 'amount',
      titleAlign: 'center' as const,
      align: 'center' as const,
    },
    {
      title: t('member.detail.depositWithdraw.type'),
      key: 'type',
      titleAlign: 'center' as const,
      align: 'center' as const,
      render: (row: any) => renderChannelCell(row.withdrawTypeId, row.type),
    },
  ]);
</script>

<style lang="less" scoped>
  .dsg-wrap {
    display: flex;
    flex-direction: column;
    gap: 10px;
  }
  /* ① 今日/累计 6 卡片整行（浅灰底、今日绿/累计蓝——用户图示着色） */
  .dsg-cum-row {
    display: grid;
    grid-template-columns: repeat(6, minmax(0, 1fr));
    gap: 10px;
  }
  .dsg-cum-card {
    /* 三轮调整：除标题栏外底色全白（原 #f8fafc） */
    background: #fff;
    border: 1px solid #eef0f2;
    border-radius: 8px;
    padding: 8px 12px;
  }
  .dsg-cum-card__name {
    font-size: 13px;
    font-weight: 600;
    color: #111827;
    margin-bottom: 4px;
  }
  .dsg-cum-card__line {
    display: flex;
    align-items: baseline;
    gap: 6px;
    line-height: 1.6;
  }
  .dsg-tag {
    flex-shrink: 0;
    font-size: 12px;
    color: #8c8c8c;
  }
  .dsg-val {
    font-size: 13px;
    font-weight: 600;
  }
  .dsg-val--today {
    color: #16a34a;
  }
  .dsg-val--total {
    color: #2563eb;
  }
  .dsg-val--success {
    color: #16a34a;
  }
  .dsg-val--warning {
    color: #d97706;
  }

  /* 下方两列：等高拉伸（五轮调整③——左「充值/提现数据」与右「奖励与投注数据」整体高度一致，
     flex 默认 stretch、两版块底边对齐） */
  .dsg-two {
    display: flex;
    gap: 10px;
  }
  .dsg-left {
    flex: 0.92;
    min-width: 0;
  }
  .dsg-right {
    flex: 1.08;
    min-width: 0;
  }

  /* ② 迷你卡（人工充值/充值赠送/彩金充值 + 等待提现/累计提现手续费同款）：
     白底描边（二轮调整①底色改白，原 #f8fafc←#effaf3） */
  .dsg-cards3 {
    display: grid;
    grid-template-columns: repeat(3, minmax(0, 1fr));
    gap: 8px;
  }
  .dsg-mini-card {
    background: #fff;
    border: 1px solid #eef0f2;
    border-radius: 8px;
    padding: 8px 10px;
    text-align: center;
  }
  .dsg-mini-card__name {
    font-size: 12px;
    color: #374151;
  }
  .dsg-mini-card__val {
    margin-top: 2px;
    font-size: 14px;
    font-weight: 600;
    color: #111827;
  }
  /* 等待提现橙值：双类压过 __val 基础黑 */
  .dsg-mini-card__val.dsg-val--warning {
    color: #d97706;
  }
  /* 等待提现｜累计提现手续费 两卡一行（同 .dsg-mini-card 样式；
     原 dsg-cell-card 系列/首充整行卡/dsg-datenote 已随二轮调整②③移除） */
  .dsg-row2 {
    display: grid;
    grid-template-columns: repeat(2, minmax(0, 1fr));
    gap: 8px;
    margin-top: 8px;
  }
  /* 首充/次充/三充静态行（收缩箭头及折叠交互已按四轮调整②移除） */
  .dsg-fold {
    margin-top: 8px;
    border: 1px solid #eef0f2;
    border-radius: 6px;
    padding: 6px 10px;
    display: flex;
    align-items: baseline;
    gap: 10px;
  }
  .dsg-fold__name {
    font-size: 12px;
    color: #6b7280;
    flex-shrink: 0;
  }
  .dsg-fold__val {
    font-size: 13px;
    font-weight: 600;
    color: #111827;
  }
  .dsg-fold__date {
    font-size: 12px;
    color: #9ca3af;
  }
  /* 两小表并排 */
  .dsg-tables {
    display: flex;
    gap: 10px;
    align-items: flex-start;
    margin-top: 8px;
  }
  .dsg-tablecol {
    flex: 1;
    min-width: 0;
  }
  .dsg-sub {
    display: block;
    margin: 0 0 3px;
    font-size: 12px;
    font-weight: 600;
    color: #595959;
  }
  /* 小表字号 12px 与本 Tab 其它文字统一（四轮调整①）；行高拉高（五轮调整①，28→36） */
  .dsg-table :deep(.n-data-table-th),
  .dsg-table :deep(.n-data-table-td) {
    height: 36px;
    padding: 4px 6px;
    font-size: 12px;
    box-sizing: border-box;
    white-space: nowrap;
  }

  /* ③ 奖励与投注数据：子标题灰条（原共享浅蓝 #f0f5ff，2026-07-16 用户调整③；双类压过 ::v-deep 注入，
     只影响本 demo、共享 .detail-grid__subheader 别处仍为蓝） + 各组网格（4/3/4 列照图） */
  .detail-grid__subheader.dsg-subheader {
    margin-top: 6px;
    border-radius: 4px;
    background: #f8fafc;
    border-bottom-color: #eef0f2;
  }
  .dsg-reward-grid {
    margin-top: 4px;
  }
  /* 奖励格上下结构：名称灰小在上、数值黑粗在下（2026-07-16 用户调整④；
     压过 ::v-deep 的横排 row + label 冒号）；padding 加大=二轮调整④「每个版块高度提高点」 */
  .dsg-reward-grid .detail-cell {
    padding: 10px 10px;
    flex-direction: column;
    align-items: flex-start;
    gap: 2px;
    /* 三轮调整：除标题栏外底色全白（压过 ::v-deep 注入的 #fafbfc；网格缝细线保留作分隔） */
    background: #fff;
  }
  .dsg-reward-grid .detail-cell .detail-cell__label {
    font-size: 12px;
    line-height: 1.4;
    color: #6b7280;
  }
  .dsg-reward-grid .detail-cell .detail-cell__label::after {
    content: none;
  }
  .dsg-reward-grid .detail-cell .detail-cell__value {
    font-size: 12px;
    line-height: 1.4;
    font-weight: 600;
    color: #111827;
    flex: 0 0 auto;
  }
</style>
