<template>
  <div class="img-upload-field" :class="{ 'img-upload-field--vertical': linkBelow }">
    <!-- 隐藏的本地文件选择 input：点击上传框时调起系统文件夹 -->
    <input
      ref="fileInput"
      type="file"
      :accept="accept"
      class="img-upload-field__file"
      @change="onFileChange"
    />
    <!-- 有图：缩略框 + 鼠标悬停放大预览；点击重新选择 -->
    <n-popover v-if="modelValue" trigger="hover" placement="right" :show-arrow="false">
      <template #trigger>
        <div
          :class="['img-upload-field__box', boxClass, 'is-filled', { 'is-disabled': disabled }]"
          @click="openPicker"
        >
          <img :src="modelValue" class="img-upload-field__thumb" alt="preview" />
        </div>
      </template>
      <div :class="['img-upload-field__preview', previewClass]">
        <img :src="modelValue" class="img-upload-field__preview-img" alt="preview" />
      </div>
    </n-popover>
    <!-- 无图：占位上传框；点击调起文件选择 -->
    <div
      v-else
      :class="['img-upload-field__box', boxClass, 'is-empty', { 'is-disabled': disabled }]"
      @click="openPicker"
    >
      <n-icon size="24" :component="ImageOutline" />
      <span class="img-upload-field__placeholder">{{ t('common.upload_image') }}</span>
    </div>
  </div>
</template>

<script lang="ts" setup>
  import { computed, ref } from 'vue';
  import { NPopover, NIcon } from 'naive-ui';
  import { ImageOutline } from '@vicons/ionicons5';
  import { useI18n } from 'vue-i18n';

  defineOptions({ name: 'ImageUploadField' });

  const props = withDefaults(
    defineProps<{
      /** 图片地址（v-model:value） */
      value?: string;
      /** 尺寸预设：按图片用途宽高比 */
      preset?: 'banner' | 'announcement' | 'push';
      placeholder?: string;
      disabled?: boolean;
      /** 文件选择过滤，默认仅图片 */
      accept?: string;
      /** 图片链接(URL 输入)置于图片下方（竖向排版）；默认横向（图右） */
      linkBelow?: boolean;
    }>(),
    {
      value: '',
      preset: 'banner',
      placeholder: '',
      disabled: false,
      accept: 'image/*',
      linkBelow: false,
    },
  );

  const emit = defineEmits<{ (e: 'update:value', v: string): void }>();

  const { t } = useI18n();
  const modelValue = computed(() => props.value);
  const fileInput = ref<HTMLInputElement | null>(null);
  const boxClass = computed(() => `img-upload-field__box--${props.preset}`);
  const previewClass = computed(() => `img-upload-field__preview--${props.preset}`);

  // 点击上传框 → 调起系统本地文件夹
  function openPicker() {
    if (props.disabled) return;
    fileInput.value?.click();
  }

  // 选中本地文件 → 原型用 ObjectURL 本地预览（不上传），写回 value
  function onFileChange(e: Event) {
    const input = e.target as HTMLInputElement;
    const file = input.files?.[0];
    if (file) emit('update:value', URL.createObjectURL(file));
    input.value = '';
  }
</script>

<style lang="less" scoped>
  .img-upload-field {
    display: flex;
    align-items: flex-start;
    gap: 12px;
    width: 100%;

    // 竖向：图片在上、链接输入在下（推送逐语言卡牌用）
    &--vertical {
      flex-direction: column;
      align-items: stretch;
      gap: 8px;
    }

    &__file {
      display: none;
    }

    &__box {
      flex: 0 0 auto;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      gap: 4px;
      border: 1px dashed var(--n-border-color, #d9d9d9);
      border-radius: 6px;
      overflow: hidden;
      background: rgba(0, 0, 0, 0.02);
      cursor: pointer;
      transition: border-color 0.2s;

      &:hover {
        border-color: var(--n-color-target, #2080f0);
      }

      &.is-empty {
        color: rgba(0, 0, 0, 0.35);
      }

      &.is-disabled {
        cursor: not-allowed;
        opacity: 0.6;
      }

      &--banner {
        width: 192px;
        height: 75px;
      }

      &--announcement {
        width: 175px;
        height: 123px;
      }

      &--push {
        width: 180px;
        height: 90px;
      }
    }

    &__thumb {
      width: 100%;
      height: 100%;
      object-fit: cover;
      display: block;
    }

    &__placeholder {
      font-size: 12px;
      line-height: 1.2;
    }

    &__input {
      flex: 1 1 auto;
      min-width: 0;
    }

    &__preview {
      display: flex;
      align-items: center;
      justify-content: center;
      overflow: hidden;
      border-radius: 4px;

      &--banner {
        width: 440px;
        height: 172px;
      }

      &--announcement {
        width: 360px;
        height: 252px;
      }

      &--push {
        width: 440px;
        height: 220px;
      }
    }

    &__preview-img {
      width: 100%;
      height: 100%;
      object-fit: contain;
      display: block;
    }
  }
</style>
