// 会员列表（商户端 tenant · member_user）功能说明书。
// 锚定 src/views/member/user/index.vue + useUserPage.ts(1926行，核心逻辑全在这) + data.ts + 7个弹窗组件
// （MemberPasswordResetModal/MemberThirdInfoModal/MemberRedPacketRechargeModal/MemberGoogleAuthModal/
// BatchImportModal/BatchMemberActionModal/BatchAddUserModal）的真实控件（R53 实证、不臆造）。
//
// 结构：单页非Tab壳，但有「横版/竖版」两种列表展示模式（工具栏按钮切换，默认竖版）——横版=38个扁平列
// (allColumns)，竖版=9个复合分组列(verticalColumns，每列内含多个"标签:值"行，靠 vKv() 助手统一渲染)。
// 两种模式渲染同一份行数据、字段完全一致，仅展示形态不同；本说明书的"列"分组条目按【横版列 key】命名
// anchor(col_xxx)，竖版模式下对应字段通过 vKv() 助手统一挂载同一批 anchor（见 useUserPage.ts vKv 函数），
// 因此无论当前处于哪种版式，点击对应字段都能触发同一条说明书高亮——但只有"当前显示的那种版式"里的
// DOM 存在，切到另一版式才能点亮另一批（跟其它页面 Tab 切换后才能点亮该 Tab 内控件是同一道理）。
//
// 范围边界（重要）：会员ID列点击调用共享 composable useUser().openMemberDetailModal，打开的是全站共用的
// "会员详情"超大弹窗（有自己独立的 DevLocator 悬停规范体系，跟本次说明书铺开任务里刻意暂缓的
// finance_member_detail_page 是同一套东西）。本说明书不展开会员详情弹窗内部，只把"会员ID可点击"记成
// 1条跳转类 item。

import type { PageManual } from '../types';

const manual: PageManual = {
  route: 'member_user',
  title: '会员列表',
  overview:
    '商户端「会员管理 › 会员列表」页，全站信息量最大的单页之一（核心逻辑文件 useUserPage.ts 单文件1926行）。' +
    '顶部工具栏含「批量导入」「导出」「横竖版切换」三个按钮 + ProCrudTable 内置「批量操作」下拉（11个子动作）；' +
    '搜索区19个查询项（商户/会员ID/会员账号/会员状态/注册时间/在线时间为常驻，其余13项收进"更多筛选"高级分组）；' +
    '列表默认竖版（9个复合分组列，每列内"标签:值"多行堆叠展示，压缩横向宽度），可切横版（38个扁平列，一字段一列）；' +
    '行操作固定"修改密码"+"三方信息"，按条件追加"红包充值"（代理模式=盈亏返利才显示）、"前台谷歌重置"（前台谷歌已绑定才显示）、"代理后台谷歌重置"（代理模式=盈亏返利才显示，与 backGoogle 列「点击查看」条件一致，2026-07-24 晚修复前误用过 backGoogle 绑定状态判断）；后两者 2026-07-24 由原单一"谷歌重置"按钮拆分而来。' +
    '会员ID列点击跳全站共用「会员详情」弹窗（另一套独立体系，本说明书不展开其内部）。' +
    '2026-07-22 核实代码未发现真实功能缺陷——横竖版内容/排序完全对齐、字段映射(mapRow)清晰、导出三条特殊规则(角标列取纯列名/打码进度导出两数/枚举转中文)逻辑自洽。',
  items: [
    // ============ 搜索区（19项，常驻6 + 高级筛选13，按"定位类/资料类/风控类"三组收纳） ============
    {
      anchor: 'merchant',
      name: '商户（常驻·必选）',
      group: '搜索',
      interaction:
        '下拉单选，恒排搜索区第一位，红星必填；未选就点查询会红框+红字提示"请选择商户"。',
      limit: '单选（R63：与会员ID筛选项共存场景下商户必单选必填）。',
      note: '2026-07-04 用户裁决：商户筛选两端都显示（不再是"仅总控端"），但商户"列"仍仅总控端显示。',
    },
    {
      anchor: 'memberId',
      name: '会员ID（常驻）',
      group: '搜索',
      interaction: '文本框，仅允许数字+空格输入（支持空格分隔多ID查询）。',
      dataSource: '对应后端字段 userId。',
    },
    {
      anchor: 'memberAccount',
      name: '会员账号（常驻）',
      group: '搜索',
      interaction: '文本框，可清空。',
      dataSource: '对应后端字段 userName。',
    },
    {
      anchor: 'userStatus',
      name: '会员状态（常驻）',
      group: '搜索',
      interaction: '字典下拉单选，可清空。',
      dataSource: '字典 userStateList（source=v1）。',
    },
    {
      anchor: 'registerTimeRange',
      name: '注册时间（常驻）',
      group: '搜索',
      interaction:
        '日期时间区间选择，精确到秒；不设跨度上限、允许选未来日期；默认快捷"今天"；工具栏另有横排快捷按钮(quick-date)。',
      limit: '无跨度上限（maxDays: Infinity）。',
    },
    {
      anchor: 'onlineTimeRange',
      name: '在线时间（常驻）',
      group: '搜索',
      interaction: '日期时间区间选择，精确到秒；不设跨度上限、允许选未来日期。',
      dataSource: '对应后端字段 activityStartTime/activityEndTime。',
    },
    {
      anchor: 'agentId',
      name: '代理ID（高级筛选·定位类）',
      group: '搜索',
      interaction: '文本框，可清空；收在"更多筛选"分组内，默认不常驻显示。',
    },
    {
      anchor: 'registerIp',
      name: '注册IP（高级筛选·定位类）',
      group: '搜索',
      interaction: '文本框，可清空。',
    },
    {
      anchor: 'loginIp',
      name: '登录IP（高级筛选·定位类）',
      group: '搜索',
      interaction: '文本框，可清空。',
      note: '风控管理「同IP/设备检测」页人数下钻跳转本页时，会按此项预填筛选值（见 useUserPage.ts searchInitialValues）。',
    },
    {
      anchor: 'inviteCode',
      name: '邀请码（高级筛选·定位类）',
      group: '搜索',
      interaction: '文本框，可清空。',
    },
    {
      anchor: 'remark',
      name: '备注（高级筛选·定位类）',
      group: '搜索',
      interaction: '文本框，可清空。',
    },
    {
      anchor: 'channel',
      name: '渠道（高级筛选·资料类）',
      group: '搜索',
      interaction: '下拉单选，可清空。',
      dataSource: '接口枚举 channelList（useUser().getOptions）。',
    },
    {
      anchor: 'registerDevice',
      name: '注册设备（高级筛选·资料类）',
      group: '搜索',
      interaction: '字典下拉单选，可清空。',
      dataSource: '字典 phoneTypeList（source=v1）。',
    },
    {
      anchor: 'loginDevice',
      name: '登录设备（高级筛选·资料类）',
      group: '搜索',
      interaction: '字典下拉单选，可清空。',
      dataSource: '字典 phoneTypeList（source=v1）。',
      note: '风控管理「同IP/设备检测」页人数下钻跳转本页时，会按此项预填筛选值。',
    },
    {
      anchor: 'agentStatus',
      name: '代理状态（高级筛选·资料类）',
      group: '搜索',
      interaction: '下拉单选，可清空。',
      dataSource:
        '本页固定枚举（不复用全局字典 agentTypeList，避免影响"会员等级"页仍需展示的"非代理"标签）：流水返佣(1) / 盈亏返利(2)，不含"非代理"。',
    },
    {
      anchor: 'vipLevel',
      name: 'VIP等级（高级筛选·资料类）',
      group: '搜索',
      interaction: '下拉单选，可清空。',
      dataSource: '接口枚举 vipLevelList。',
    },
    {
      anchor: 'memberGroup',
      name: '会员分组（高级筛选·资料类）',
      group: '搜索',
      interaction: '下拉单选，可清空。',
      dataSource:
        '接口枚举 userGroupList；若从「会员分组管理」页"分组人数"下钻带入的分组名不在字典里，会临时注入为可选项，保证筛选 chip 正常显示。',
    },
    {
      anchor: 'activityBlacklistStatus',
      name: '活动黑名单（高级筛选·风控类）',
      group: '搜索',
      interaction: '下拉单选，可清空。',
      dataSource: '本地硬编码选项：正常/已拉黑。',
    },
    {
      anchor: 'fingerprint',
      name: '注册指纹（高级筛选·风控类）',
      group: '搜索',
      interaction: '文本框，可清空。',
    },

    // ============ 工具栏（4项） ============
    {
      anchor: 'act_batchImport',
      name: '批量导入',
      group: '操作',
      interaction:
        '点击打开「批量导入」弹窗（需权限 Member:Users:UserList:BatchImport）；若当前搜索区未选商户会先提示"请选择商户"再打开。',
      logic:
        '弹窗内两阶段：①下载模板/上传Excel(仅.xlsx/.xls，格式不符直接拦截提示，不静默兜底) → mock解析校验，' +
        '返回逐行结果(用户ID/会员状态/黑名单/佣金状态三个三态字段：-1不更新/0关闭/1开启，及校验错误信息) → ' +
        '②确认后"一键执行"提交，二次确认弹窗展示总数/通过数/失败数，执行中主弹窗盖 NSpin loading，' +
        '结果按失败数分别用 success/warning/error 三种 dialog 反馈，并回填表格逐行"处理结果"列。',
    },
    {
      anchor: 'act_export',
      name: '导出',
      group: '操作',
      interaction:
        '点击按当前筛选条件导出CSV（客户端生成，前端直接把当前筛选结果转CSV下载，非仅当前页）。',
      logic:
        '三条特殊导出规则：①角标列("新"标/带帮助图标的列)导出表头取纯列名，不含图标/角标；' +
        '②打码进度列导出"已完成/需要打码量"两个数字；③枚举/布尔列(会员状态/在线状态/佣金开关/返佣开关/前后台谷歌绑定)转成中文文案。' +
        '导出列固定按横版38列（操作列/竖版复合列不导出）。',
    },
    {
      anchor: 'act_toggleLayout',
      name: '横竖版切换',
      group: '操作',
      interaction:
        '纯图标+文字按钮（无图标，按钮文案随当前版式变化：竖版时显示"竖版"、横版时显示"横版"，hover tooltip提示切换后动作）。',
      logic:
        '点击切换 layoutMode：竖版(复合分组列，默认) ⇄ 横版(38个扁平列)；两版各自独立记忆列显隐(column-setting-version按版式区分)。',
    },
    {
      anchor: 'act_batchActions',
      name: '批量操作（下拉，11个子动作）',
      group: '操作',
      interaction: '需先勾选至少1行才可点击（未勾选置灰）；点击展开下拉菜单，箭头随展开/收起旋转。',
      logic:
        '11个子动作：批量拉黑/批量加白/批量禁用/批量启用/批量改代理模式/批量设置分组/批量设置彩票限红/批量新增会员/' +
        '批量迁移渠道/批量删除备注/批量重置谷歌验证。其中"批量新增会员"打开 BatchAddUserModal(表格逐行填账号/注册类型/' +
        '密码/邀请码/分组/备注，账号+密码必填，校验失败对应输入框红框+toast指名第几行缺哪项)；"批量拉黑/批量设置分组/' +
        '批量迁移渠道/批量改代理模式/批量设置彩票限红"5个打开 BatchMemberActionModal(单一下拉选目标值)——' +
        '其中批量拉黑额外展示"归入该黑名单分组后会被禁止的功能清单"(锚定会员分组配置，旧分组禁7项/新分组禁8项)，' +
        '批量限红因维度过多(彩种×玩法×限红类型)弹窗内只放引导文案不做实际选择(2026-07-20用户拍板简化)；' +
        '其余5个(批量加白/禁用/启用/删除备注/重置谷歌)直接二次确认弹窗、确认后mock执行+清空勾选+刷新列表。',
    },
    {
      anchor: 'reset',
      name: '重置',
      group: '搜索',
      interaction: 'ProCrudTable内置重置按钮，点击清空全部搜索条件（含高级筛选分组）并重新查询。',
    },

    // ============ 列（横版38列/竖版9个复合列共用同批anchor；仅列出有交互的列，纯展示列见 fields） ============
    {
      anchor: 'col_memberId',
      name: '会员ID（可点击）',
      group: '列',
      interaction: '蓝字可点+复制图标（CopyText组件）。',
      logic: '点击打开全站共用「会员详情」弹窗（独立子系统，本说明书不展开其内部字段/Tab/操作）。',
    },
    {
      anchor: 'col_betAmount',
      name: '打码进度（已完成打码量列，横版列名"打码进度"）',
      group: '列',
      interaction: '进度条+百分比+达标/未达标徽标，下方小灰字"已完成/需要"+问号图标。',
      logic:
        '悬停问号弹出打码量计算公式说明；进度=已完成打码量÷需要打码量，达标(done≥need)显绿色徽标，未达标显橙色。',
      note: '与会员详情弹窗打码量展示同一套计算逻辑(seedCode/getCodeDone/getCodeNeed共享store，保证两处数值一致)。',
    },
    {
      anchor: 'col_commissionEnabled',
      name: '返佣开关（"是否计算佣金"列，带帮助图标）',
      group: '列',
      interaction:
        '开关控件（R47），点击切换弹二次确认弹窗，确认后才真正切换+成功提示；取消则开关回弹原状态。',
      logic: '列标题带问号图标，悬停显示该字段释义。',
    },
    {
      anchor: 'col_rebateToParent',
      name: '上级返佣开关（带帮助图标）',
      group: '列',
      interaction:
        '开关控件（R47），点击切换弹二次确认弹窗，确认后才真正切换+成功提示；取消则开关回弹原状态。',
      logic: '列标题带问号图标，悬停显示该字段释义。',
    },
    {
      anchor: 'col_frontGoogle',
      name: '前台谷歌验证',
      group: '列',
      interaction: '已绑定 → 蓝字按钮"点击查看谷歌码"；未绑定 → 灰色只读标签"未绑定"。',
      logic: '点击打开 MemberGoogleAuthModal（三步绑定说明+二维码占位+密钥可复制+账号展示）。',
    },
    {
      anchor: 'col_backGoogle',
      name: '后台谷歌验证',
      group: '列',
      interaction:
        '仅"代理模式=盈亏返利"的会员：已绑定 → 蓝字按钮"点击查看谷歌码"、未绑定 → 灰色标签；非盈亏返利模式一律显示"未开放"（灰字，不可点）。',
      logic: '点击打开 MemberGoogleAuthModal（与前台谷歌同一弹窗组件）。',
      edge: '"未开放"态是纯灰字文本、非按钮，视觉上容易被当成禁用态按钮，实为普通文本；不算缺陷，如实记录展示形态。',
    },

    // ============ 行操作（5个，按条件追加） ============
    {
      anchor: 'act_resetPassword',
      name: '修改密码（常驻）',
      group: '操作',
      interaction: '每行常驻显示，主题色按钮，点击打开 MemberPasswordResetModal。',
      logic: '弹窗仅1个新密码输入框(最少6位)，确认后提交；密码留空或不足6位表单校验拦截。',
    },
    {
      anchor: 'act_thirdInfo',
      name: '三方信息（常驻）',
      group: '操作',
      interaction: '每行常驻显示，蓝色按钮，点击打开 MemberThirdInfoModal。',
      logic: '弹窗展示 Firebase Token + 极光推送 Token 两个文本域（演示mock值），可编辑保存。',
    },
    {
      anchor: 'act_redPacketRecharge',
      name: '红包充值（条件显示）',
      group: '操作',
      interaction: '橙色按钮，仅"代理模式=盈亏返利"的会员行显示。',
      logic: '弹窗仅1个充值金额输入(必填且>0)，确认后提交。',
    },
    {
      anchor: 'act_resetFrontGoogle',
      name: '前台谷歌重置（条件显示）',
      group: '操作',
      interaction:
        '红色按钮，仅"前台谷歌已绑定"（frontGoogle=bound）的会员行显示。2026-07-24 新增，由原单一"谷歌重置"按钮拆分而来，与「代理后台谷歌重置」为并列的两个独立按钮（互不影响，同一行可同时出现两者）。',
      logic:
        '点击弹二次确认，确认后mock重置+成功提示；与「代理后台谷歌重置」复用同一套确认框/成功提示文案（i18n member.user.resetGoogle），演示，不真正改变绑定状态显示。',
    },
    {
      anchor: 'act_resetBackGoogle',
      name: '代理后台谷歌重置（条件显示）',
      group: '操作',
      interaction:
        '红色按钮，仅"代理模式=盈亏返利"（commissionMode=盈亏返利）的会员行显示——与 backGoogle 列「点击查看」条件保持一致（该列仅盈亏返利模式才可点开查看，流水返佣/未开通显示"未开放"）。2026-07-24 文案由「谷歌重置」改为「代理后台谷歌重置」，与新拆出的「前台谷歌重置」区分开；同日晚修复一处显示条件bug——拆分之初误用了 backGoogle=bound（谷歌绑定状态）判断，与列表中"有点击查看才有对应重置项"的预期不符（backGoogle 绑定状态与该列是否显示"点击查看"是两个独立维度），已改回按 commissionMode 判断。',
      logic: '点击弹二次确认，确认后mock重置+成功提示（演示，不真正改变绑定状态显示）。',
      edge: '确认后仅弹成功提示，未观察到该行 backGoogle 状态被回写为未绑定——mock 是纯演示反馈，不影响判断为缺陷（后台谷歌重置在源站本身也是"通知会员重新绑定"性质，不当场改变列表态属预期行为）。',
    },
  ],
  fields: [
    { name: '商户（列，仅总控端显示）', def: '该会员所属商户，标签展示，恒第一列。' },
    { name: '会员ID', def: '会员唯一编号，可点击进详情，见交互条目 col_memberId。' },
    { name: '昵称', def: '会员昵称；竖版同格另显示在线状态圆点+文字。' },
    { name: '手机', def: '登录手机号，脱敏展示（保留区号+前3后4位）。' },
    { name: '邮箱', def: '登录邮箱，脱敏展示。' },
    { name: '余额', def: '会员账户余额，可排序，居左（R61金额列）。' },
    {
      name: '策略钱包余额',
      def: '策略钱包余额，可排序，居左；镜像总控端 game/member/user 同名列，排在"余额"后。',
    },
    { name: '安全箱余额', def: '安全箱（保险箱）内金额，可排序，居左。' },
    { name: '红包余额', def: '会员红包账户余额，居左。' },
    {
      name: '限红分组',
      def: '会员所属彩票限红分组（0=不限，1-8=限红组-N），与批量设置彩票限红弹窗同一份选项映射。',
    },
    { name: '邀请码', def: '该会员自己的邀请码。' },
    { name: '渠道号', def: '该会员的注册渠道编号。' },
    { name: '注册IP', def: '会员注册时的来源IP。' },
    { name: '注册设备', def: '会员注册时使用的设备类型（Android/iOS/PC/未知），按字典枚举展示。' },
    { name: '注册设备号（新）', def: '会员注册时的设备唯一标识号。' },
    { name: '注册浏览器指纹（新）', def: '会员注册时采集的浏览器指纹。' },
    { name: '登录渠道（新）', def: '会员最近一次登录使用的渠道，按枚举展示。' },
    { name: '登录设备（新）', def: '会员最近一次登录使用的设备类型，按枚举展示。' },
    { name: '最后登录设备号（新）', def: '会员最近一次登录的设备唯一标识号。' },
    { name: '最后登录浏览器指纹（新）', def: '会员最近一次登录的浏览器指纹。' },
    { name: '打码进度', def: '已完成打码量与需要打码量的进度展示，见交互条目 col_betAmount。' },
    { name: '会员分组', def: '会员所属分组，按枚举展示。' },
    { name: '会员类型', def: '真实会员/代理会员/测试会员三态，按会员类型码派生文案。' },
    { name: '在线状态', def: '在线/离线标签（依据后端返回的中文状态字段判断，非数值枚举）。' },
    { name: '最后在线时间', def: '会员最近一次活跃时间，按商户所在时区展示。' },
    { name: '首位代理（新）', def: '该会员的首位上级代理ID。' },
    { name: '佣金模式（新）', def: '该会员的返佣计算模式：盈亏返利/流水返佣/未开通。' },
    { name: '返佣开关', def: '是否计算该会员佣金，见交互条目 col_commissionEnabled。' },
    { name: '上级返佣开关', def: '是否将佣金返给上级，见交互条目 col_rebateToParent。' },
    { name: '前台谷歌验证', def: '会员前台登录谷歌验证器绑定状态，见交互条目 col_frontGoogle。' },
    {
      name: '后台谷歌验证',
      def: '代理后台谷歌验证器绑定状态（仅盈亏返利代理模式适用），见交互条目 col_backGoogle。',
    },
    { name: '首次登录时间', def: '会员账号首次登录的时间，按商户时区展示。' },
    { name: '注册时间', def: '会员账号注册时间，按商户时区展示。' },
    { name: 'VIP等级', def: '会员当前VIP等级，形如"L 数字"标签展示。' },
    { name: '充值次数', def: '该会员累计充值成功笔数。' },
    { name: '充值金额', def: '该会员累计充值金额。' },
    { name: '首次充值时间', def: '该会员第一笔充值成功的时间。' },
    { name: '最后充值时间', def: '该会员最近一笔充值成功的时间。' },
    {
      name: '备注',
      def: '会员备注信息，富文本渲染(HTML解码+消毒)，3行省略+悬停看全，红色加粗展示。',
    },
    { name: '会员状态', def: '启用/禁用，只读标签展示（恒排最后一个数据列，操作列前）。' },
  ],
};

export default manual;
