<script setup lang="ts">
  import { ref, computed, type CSSProperties } from 'vue';
  import { NIcon, NPopover } from 'naive-ui';
  import { CopyOutline } from '@vicons/ionicons5';
  import { useClipboard } from '@vueuse/core';
  import { useI18n } from 'vue-i18n';

  defineOptions({
    name: 'CopyText',
  });

  const props = withDefaults(
    defineProps<{
      /** 要复制的文本 (默认使用 slot 内容) */
      text?: string;
      /** 文本类型样式 */
      type?: 'info' | 'default';
      /** 是否显示复制图标 */
      showCopy?: boolean;
      /** 最大显示行数 (超出截断) */
      lineClamp?: number;
      /** 最大宽度 */
      maxWidth?: string | number;
      /** 是否显示悬停提示 (当文本截断时) */
      showTooltip?: boolean;
      /** Popover 位置 */
      placement?: 'top' | 'bottom' | 'left' | 'right';
    }>(),
    {
      type: 'default',
      showCopy: true,
      lineClamp: 1,
      showTooltip: false,
      placement: 'top',
    },
  );

  const { t } = useI18n();
  const message = window['$message'];
  const { copy } = useClipboard({ legacy: true });
  const textRef = ref<HTMLElement>();
  const isOverflow = ref(false);

  // 文本容器样式
  const textStyle = computed<CSSProperties>(() => {
    const style: CSSProperties = {};

    if (props.maxWidth) {
      style.maxWidth = typeof props.maxWidth === 'number' ? `${props.maxWidth}px` : props.maxWidth;
    }

    if (props.lineClamp > 0) {
      style.display = '-webkit-box';
      style.WebkitBoxOrient = 'vertical';
      style.WebkitLineClamp = props.lineClamp;
      style.overflow = 'hidden';
      style.textOverflow = 'ellipsis';
      style.wordBreak = 'break-all';
    }

    return style;
  });

  // 检测是否溢出
  function checkOverflow() {
    if (!textRef.value || props.lineClamp <= 0) {
      isOverflow.value = false;
      return;
    }
    isOverflow.value = textRef.value.scrollHeight > textRef.value.clientHeight;
  }

  // 复制文本
  async function onCopy() {
    const word = props.text || textRef.value?.innerText;
    if (!word) return;

    const loading = message.loading(t('common.copy.copying'));
    try {
      await copy(word);
      message.success(t('common.copy.success'));
    } catch (e) {
      message.error(t('common.copy.failed'));
    } finally {
      loading.destroy();
    }
  }

  // 监听内容变化
  function onContentChange() {
    requestAnimationFrame(checkOverflow);
  }

  defineExpose({
    copy: onCopy,
  });
</script>

<template>
  <n-el tag="span" class="copy-text" :class="[`copy-${type}`]">
    <!-- 带 Tooltip 的文本 -->
    <n-popover
      v-if="showTooltip && (lineClamp > 0 || maxWidth)"
      :placement="placement"
      trigger="hover"
      :disabled="!isOverflow"
    >
      <template #trigger>
        <span
          ref="textRef"
          :style="textStyle"
          @vue:mounted="onContentChange"
          @vue:updated="onContentChange"
        >
          <slot>{{ text }}</slot>
        </span>
      </template>
      <span class="block text-sm max-w-[300px] break-words whitespace-normal leading-relaxed">
        <slot>{{ text }}</slot>
      </span>
    </n-popover>

    <!-- 不带 Tooltip 的文本 -->
    <span v-else ref="textRef" :style="textStyle">
      <slot>{{ text }}</slot>
    </span>

    <!-- 复制图标 -->
    <span v-if="showCopy" class="copy-icon" @click.stop="onCopy">
      <n-icon :size="16" color="var(--ui-accent-solid)">
        <CopyOutline />
      </n-icon>
    </span>
  </n-el>
</template>

<style scoped lang="less">
  .copy-text {
    display: inline-flex;
    align-items: center;
    transition: 0.3s cubic-bezier(0.4, 0, 0.2, 1);

    .copy-icon {
      cursor: pointer;
      margin-left: 4px;
      display: inline-flex;
      flex-shrink: 0;
    }
  }

  .copy-info {
    color: var(--ui-accent-solid);
  }
</style>
