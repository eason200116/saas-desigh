// ============================================
// ProComponents - 高级组件库
// 基于 Naive UI 构建，与 pro-naive-ui 保持一致
// ============================================

// ================== 组件 ==================

// ProField - 表单字段组件
export { ProField, ProFormItem, ProNumberRange, ProTenantSelect } from './ProField';

// ProForm - 表单组件
export { ProForm } from './ProForm';

// ProDataTable - 数据表格组件
export { ProDataTable } from './ProDataTable';

// ProCrudTable - 查询表格一体化组件
export { ProCrudTable } from './ProCrudTable';

// ProEditDataTable - 可编辑表格组件
export {
  ProEditDataTable,
  ProEditableCell,
  ProRowActions,
  ProCreatorButton,
  ProDragHandle,
} from './ProEditDataTable';

// ProDateRangePicker - 日期范围选择器组件（含内部快捷日期按钮）
export { ProDateRangePicker, ProDateRangeInput, ProQuickDateButtons } from './ProDateRangePicker';

// ProTabs - 业务定制 Tabs 容器（slot-based + n-el 主题 + layout-main 高度链补丁）
export { ProTabs, ProTabPane, ProTabsContextKey, ProTabsHeightContextKey } from './ProTabs';
export type {
  ProTabPaneDisplayDirective,
  ProTabPaneMeta,
  ProTabsContext,
  ProTabsHeightContext,
  ProTabsPaneRect,
} from './ProTabs';

// ProFullscreenModal - 弹窗全屏基座（业务入口 + 状态层 + 渲染层 + 共享常量）
export {
  useProDetailModal,
  useFullscreenModalState,
  renderFullscreenTitle,
  MODAL_FULLSCREEN_STYLE,
  DEFAULT_NORMAL_MODAL_STYLE,
  type ProDetailModalContext,
  type ProDetailModalInstance,
  type ProDetailModalOpenOptions,
  type UseProDetailModalReturn,
  type UseFullscreenModalStateReturn,
  type RenderFullscreenTitleOptions,
} from './ProFullscreenModal';

// ================== Composables ==================
export {
  // 表单工厂
  createProForm,
  // 搜索表单工厂
  createProSearchForm,
  // 字段 composable
  useProField,
  // 验证 composable
  useProValidation,
  validationPresets,
  // 操作守卫
  useActionGuard,
  // 拖拽排序
  useDragSort,
  // 列渲染器
  useColumnRenderer,
  registerColumnRenderer,
  getColumnRenderer,
} from './composables';

// 快捷日期（基于 useZonedShortcuts，按时区计算 today/yesterday/last3-30 Days 等内置项）
export {
  useZonedShortcuts,
  matchShortcutIndexByRange,
  createZonedDefaultShortcutValue,
} from './ProDateRangePicker';

// 日期时区解析（业务层 API 字符串化时与 picker 同源，避免跨日 bug）
export { useEffectiveDateRangeTimezone } from './ProDateRangePicker';

// ================== Context ==================
export {
  // 表单上下文
  ProFormContextKey,
  createProFormContext,
  useProFormContext,
  useProFormContextSafe,
  // 字段上下文
  ProFieldContextKey,
  ProFormItemContextKey,
  createProFieldContext,
  useProFieldContext,
  createProFormItemContext,
  useProFormItemContext,
  // 表格上下文
  ProTableContextKey,
  ProEditTableContextKey,
  ProRowContextKey,
  createProTableContext,
  useProTableContext,
  createProEditTableContext,
  useProEditTableContext,
  createProRowContext,
  useProRowContext,
} from './context';

// ================== Utils ==================
export {
  // 配置
  getGlobalConfig,
  setGlobalConfig,
  // 值转换
  getValueByPath,
  setValueByPath,
  deepClone,
  isEqual,
  getChangedFields,
} from './utils';

// ================== Types ==================
export type {
  // Common types
  Recordable,
  Nullable,
  DeepPartial,
  MaybeRef,
  ProFieldValueType,
  ProComponentType,
  ProSize,
  ProValidationRule,
  ProValueEnum,
  ProValueEnumItem,
  ProAsyncOptions,
  ProFieldMapping,
  ProValidationState,

  // Field types
  ProFieldSchema,

  // Form types
  ProFormProps,
  ProFormExtendProps,
  CreateProFormOptions,
  CreateProFormReturn,
  ProFormInstance,
  ValidationTrigger,
  ValidateError,

  // SearchForm types
  ProSearchFormColumn,
  ProSearchFormProps,
  CreateProSearchFormOptions,
  CreateProSearchFormReturn,

  // DataTable types
  ProColumn,
  ProColumnEditContext,
  ProDataTableProps,
  ProDataTableExtendProps,
  ProTableDragSortOptions,
  ProDataTableInstance,
  ProColumnTypeRenderer,
  ProColumnType,

  // CrudTable types
  CrudRequestParams,
  CrudRequestResult,
  CrudActionColumn,
  ProCrudTableProps,
  ProCrudTableInstance,

  // EditDataTable types
  ProEditMode,
  ProEditTrigger,
  ProEditConfig,
  ProEditGuardContext,
  ProEditGuards,
  ProRecordCreatorProps,
  ProEditDataTableProps,
  ProEditState,
  ProRowChangeRecord,
  ProEditDataTableInstance,
  ProEditableCellProps,
  ProRowActionConfig,

  // DateRangePicker types
  DateRangeValue,
  DateRangeTimezone,
  ShortcutItem,
  ProDateRangePickerProps,

  // QuickDate types
  QuickDateItem,
} from './types';
