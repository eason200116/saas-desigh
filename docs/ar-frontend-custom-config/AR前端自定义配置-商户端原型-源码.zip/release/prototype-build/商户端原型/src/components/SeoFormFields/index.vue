<template>
  <n-grid :cols="2" x-gap="12">
    <slot name="prepend" />
    <n-form-item-gi :label="t('tenant.styleManage.seoTitle')" path="title">
      <n-input
        v-model:value="model.title"
        :placeholder="t('tenant.styleManage.seoTitlePlaceholder')"
      />
    </n-form-item-gi>
  </n-grid>
  <n-grid :cols="2" x-gap="12">
    <n-form-item-gi :label="t('tenant.styleManage.seoKeywords')" path="keywords">
      <n-input
        v-model:value="model.keywords"
        type="textarea"
        :rows="3"
        :placeholder="t('tenant.styleManage.seoKeywordsPlaceholder')"
      />
    </n-form-item-gi>
    <n-form-item-gi :label="t('tenant.styleManage.seoDescription')" path="description">
      <n-input
        v-model:value="model.description"
        type="textarea"
        :rows="3"
        :placeholder="t('tenant.styleManage.seoDescriptionPlaceholder')"
      />
    </n-form-item-gi>
  </n-grid>
  <n-grid :cols="2" x-gap="12">
    <n-form-item-gi :label="t('tenant.styleManage.favicon')" path="favicon">
      <BasicUpload
        :value="model.favicon ? [model.favicon] : []"
        :max-number="1"
        :width="50"
        :height="50"
        :custom-path="4"
        :accept="ACCEPT_PRESETS.ICON"
        full-path
        compact
        @update:value="(val: string[]) => (model.favicon = val[0] || '')"
      />
    </n-form-item-gi>
    <n-form-item-gi :label="t('tenant.styleManage.promoImage')" path="promoImage">
      <BasicUpload
        :value="model.promoImage ? [model.promoImage] : []"
        :max-number="1"
        :width="156"
        :height="88"
        :custom-path="4"
        :accept="ACCEPT_PRESETS.STATIC"
        full-path
        compact
        @update:value="(val: string[]) => (model.promoImage = val[0] || '')"
      />
    </n-form-item-gi>
  </n-grid>
  <n-form-item :label="t('tenant.styleManage.scripts')" path="scripts">
    <n-input
      v-model:value="model.scripts"
      type="textarea"
      :rows="4"
      :placeholder="t('tenant.styleManage.scriptsPlaceholder')"
    />
  </n-form-item>
</template>

<script lang="ts" setup>
  import { useI18n } from 'vue-i18n';
  import { BasicUpload, ACCEPT_PRESETS } from '@/components';

  export interface SeoFormData {
    title: string;
    keywords: string;
    description: string;
    favicon: string;
    promoImage?: string;
    scripts?: string;
  }

  const model = defineModel<SeoFormData>({ required: true });
  const { t } = useI18n();
</script>
