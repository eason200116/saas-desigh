export { default as SeoFormFields } from './index.vue';
export type { SeoFormData } from './index.vue';
