<template>
  <span :style="{ color }">
    {{ displayValue }}
  </span>
</template>

<script lang="ts" setup>
  import { ref, computed, watch, onMounted } from 'vue';

  const props = withDefaults(
    defineProps<{
      startVal?: number;
      endVal?: number;
      duration?: number;
      autoplay?: boolean;
      decimals?: number;
      prefix?: string;
      suffix?: string;
      separator?: string;
      decimal?: string;
      color?: string;
    }>(),
    {
      startVal: 0,
      endVal: 0,
      duration: 1500,
      autoplay: true,
      decimals: 0,
      prefix: '',
      suffix: '',
      separator: ',',
      decimal: '.',
    },
  );

  const emit = defineEmits(['onStarted', 'onFinished']);

  const currentValue = ref(props.startVal);
  let animationFrame: number | null = null;
  let startTime: number | null = null;

  const displayValue = computed(() => {
    const { decimals, decimal, separator, suffix, prefix } = props;
    let num = currentValue.value.toFixed(decimals);
    const x = num.split('.');
    let x1 = x[0];
    const x2 = x.length > 1 ? decimal + x[1] : '';

    const rgx = /(\d+)(\d{3})/;
    if (separator) {
      while (rgx.test(x1)) {
        x1 = x1.replace(rgx, '$1' + separator + '$2');
      }
    }
    return prefix + x1 + x2 + suffix;
  });

  const animate = (timestamp: number) => {
    if (!startTime) startTime = timestamp;
    const progress = timestamp - startTime;
    const percentage = Math.min(progress / props.duration, 1);

    currentValue.value = props.startVal + (props.endVal - props.startVal) * percentage;

    if (percentage < 1) {
      animationFrame = requestAnimationFrame(animate);
    } else {
      currentValue.value = props.endVal;
      emit('onFinished');
    }
  };

  const start = () => {
    startTime = null;
    currentValue.value = props.startVal;
    emit('onStarted');
    animationFrame = requestAnimationFrame(animate);
  };

  const reset = () => {
    if (animationFrame) {
      cancelAnimationFrame(animationFrame);
    }
    currentValue.value = props.startVal;
  };

  watch(
    () => props.endVal,
    () => {
      if (props.autoplay) {
        start();
      }
    },
  );

  onMounted(() => {
    if (props.autoplay) {
      start();
    }
  });

  defineExpose({ start, reset });
</script>
