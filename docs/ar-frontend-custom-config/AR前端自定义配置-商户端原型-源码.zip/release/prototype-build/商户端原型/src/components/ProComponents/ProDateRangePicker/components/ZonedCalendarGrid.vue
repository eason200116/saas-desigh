<template>
  <div class="zoned-calendar-grid box-border select-none">
    <div class="zoned-calendar-grid__header grid items-center justify-items-center">
      <n-button text size="tiny" class="zoned-calendar-grid__nav" @click="$emit('prev-year')">
        <n-icon size="14">
          <DoubleLeftOutlined />
        </n-icon>
      </n-button>
      <n-button text size="tiny" class="zoned-calendar-grid__nav" @click="$emit('prev')">
        <n-icon size="14">
          <LeftOutlined />
        </n-icon>
      </n-button>
      <span
        ref="titleRef"
        class="zoned-calendar-grid__title"
        :class="{ 'is-active': panelMode === 'year-month' }"
        role="button"
        tabindex="0"
        @click="togglePanelMode"
        @keydown.enter.prevent="togglePanelMode"
        @keydown.space.prevent="togglePanelMode"
        >{{ title }}</span
      >
      <n-button text size="tiny" class="zoned-calendar-grid__nav" @click="$emit('next')">
        <n-icon size="14">
          <RightOutlined />
        </n-icon>
      </n-button>
      <n-button text size="tiny" class="zoned-calendar-grid__nav" @click="$emit('next-year')">
        <n-icon size="14">
          <DoubleRightOutlined />
        </n-icon>
      </n-button>
    </div>

    <!-- date 模式：原有 weekdays + days 网格 -->
    <template v-if="panelMode === 'date'">
      <div class="zoned-calendar-grid__weekdays grid items-center justify-items-center text-center">
        <span
          v-for="weekday in weekdayLabels"
          :key="weekday"
          class="zoned-calendar-grid__weekday"
          >{{ weekday }}</span
        >
      </div>

      <div
        class="zoned-calendar-grid__days grid grid-cols-7 grid-rows-6 items-center justify-items-center"
      >
        <button
          v-for="cell in cells"
          :key="cell.key"
          type="button"
          class="zoned-calendar-grid__day relative z-0 cursor-pointer border-0 bg-transparent text-center"
          :class="getCellClass(cell)"
          :disabled="isDisabled(cell.parts)"
          @mouseenter="$emit('hover-date', cell.parts)"
          @mouseleave="$emit('hover-date', null)"
          @click="handleSelect(cell.parts)"
        >
          <span>{{ cell.label }}</span>
        </button>
      </div>
    </template>

    <!-- year-month 模式：年列 + 月列，与原生 NDatePicker 二级面板对齐（div 标签语义一致） -->
    <div v-else ref="yearMonthRef" class="zoned-calendar-grid__year-month">
      <div ref="yearColRef" class="zoned-calendar-grid__year-col">
        <div
          v-for="y in yearList"
          :key="y"
          class="zoned-calendar-grid__year-item"
          :class="{ 'is-current': y === year }"
          @click="handleSelectYear(y)"
        >
          {{ y }}
        </div>
      </div>
      <div ref="monthColRef" class="zoned-calendar-grid__month-col">
        <div
          v-for="m in monthList"
          :key="m"
          class="zoned-calendar-grid__month-item"
          :class="{ 'is-current': m === month, 'is-disabled': isMonthDisabled(m) }"
          :aria-disabled="isMonthDisabled(m) || undefined"
          @click="handleSelectMonth(m)"
        >
          {{ m }}
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
  import { computed, nextTick, onMounted, onUnmounted, ref } from 'vue';
  import { useI18n } from 'vue-i18n';
  import {
    DoubleLeftOutlined,
    DoubleRightOutlined,
    LeftOutlined,
    RightOutlined,
  } from '@vicons/antd';
  import { NButton, NIcon } from 'naive-ui';
  import {
    compareDateParts,
    formatParts,
    getMonthGrid,
    isSameDate,
    nowInZone,
    type CalendarCell,
    type ZonedDateTimeParts,
  } from '../utils/zonedDateMath';

  defineOptions({ name: 'ZonedCalendarGrid' });

  const props = withDefaults(
    defineProps<{
      year: number;
      month: number;
      timezoneId: string;
      selectedStart?: ZonedDateTimeParts | null;
      selectedEnd?: ZonedDateTimeParts | null;
      hoveredDate?: ZonedDateTimeParts | null;
      disabledDate?: (parts: ZonedDateTimeParts) => boolean;
      /**
       * 是否允许选未来日期。控制 header 年月二级面板的可选范围：
       *  - false（默认，与父级 allowFuture 一致）：年列 = [今年-10, 今年]；当前年 → 月列只到当前月
       *  - true：年列 = [今年-10, 今年+10]；月列全 12 月可选
       */
      allowFuture?: boolean;
    }>(),
    {
      selectedStart: null,
      selectedEnd: null,
      hoveredDate: null,
      disabledDate: undefined,
      allowFuture: false,
    },
  );

  const emit = defineEmits<{
    select: [parts: ZonedDateTimeParts];
    'prev-year': [];
    prev: [];
    next: [];
    'next-year': [];
    'hover-date': [parts: ZonedDateTimeParts | null];
    /**
     * 用户从 header 二级面板点击年/月时触发；父级应据此设置 visibleMonth。
     * 起止 day 由父级决定（一般 reset 为 1）。
     */
    'jump-to': [year: number, month: number];
  }>();

  const { t } = useI18n();

  const weekdayLabels = computed(() => [
    t('common.dateRange.weekdays.mon'),
    t('common.dateRange.weekdays.tue'),
    t('common.dateRange.weekdays.wed'),
    t('common.dateRange.weekdays.thu'),
    t('common.dateRange.weekdays.fri'),
    t('common.dateRange.weekdays.sat'),
    t('common.dateRange.weekdays.sun'),
  ]);

  const title = computed(() =>
    formatParts(
      {
        year: props.year,
        month: props.month,
        day: 1,
        hour: 0,
        minute: 0,
        second: 0,
        millisecond: 0,
      },
      'yyyy-MM',
    ),
  );

  const cells = computed(() => getMonthGrid(props.year, props.month, props.timezoneId));

  // ===== Header 年月二级面板（panel mode 切换） =====

  /** 'date' 显示日历网格；'year-month' 显示年/月二级面板（与原生 NDatePicker 对齐） */
  const panelMode = ref<'date' | 'year-month'>('date');
  /** 年列 ref，用于打开二级面板时自动滚动当前年居中 */
  const yearColRef = ref<HTMLElement | null>(null);
  /** 月列 ref，与年列对称：12 项一列滚动，当前月需要自动滚动居中 */
  const monthColRef = ref<HTMLElement | null>(null);
  /** year-month 容器 ref，用于"点击外部关闭"判断 click 是否落在二级面板内 */
  const yearMonthRef = ref<HTMLElement | null>(null);
  /** title ref，"点击外部关闭"逻辑要排除 title 自身（让 toggle 行为正常） */
  const titleRef = ref<HTMLSpanElement | null>(null);

  /** 当前面板时区下的"今天" wall-clock parts，用于 allowFuture=false 时拦截未来年月 */
  const today = computed(() => nowInZone(props.timezoneId));

  /** 年列数据：默认 [今年-10, 今年] 11 项；allowFuture=true 时扩到 [今年-10, 今年+10] 21 项 */
  const yearList = computed<number[]>(() => {
    const currentYear = today.value.year;
    const start = currentYear - 10;
    const end = props.allowFuture ? currentYear + 10 : currentYear;
    return Array.from({ length: end - start + 1 }, (_, i) => start + i);
  });

  /** 月项是否禁用：allowFuture=false 时，当前年 → 只允许到当前月 */
  function isMonthDisabled(m: number): boolean {
    if (props.allowFuture) return false;
    const n = today.value;
    if (props.year < n.year) return false;
    if (props.year > n.year) return true;
    return m > n.month;
  }

  /** 月列 2 列 × 6 行布局：[[1,2],[3,4],...,[11,12]] */
  const monthList = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12];

  function togglePanelMode() {
    panelMode.value = panelMode.value === 'date' ? 'year-month' : 'date';
    if (panelMode.value === 'year-month') {
      // 等渲染完再滚动两列当前项居中；用 'auto' 避免 smooth 动画带来的视觉延迟
      nextTick(() => {
        yearColRef.value
          ?.querySelector<HTMLElement>('.zoned-calendar-grid__year-item.is-current')
          ?.scrollIntoView({ block: 'center', behavior: 'auto' });
        monthColRef.value
          ?.querySelector<HTMLElement>('.zoned-calendar-grid__month-item.is-current')
          ?.scrollIntoView({ block: 'center', behavior: 'auto' });
      });
    }
  }

  /**
   * 点击外部关闭 year-month 二级面板（对齐 NDatePicker 视觉一致性）：
   *  - 仅在 panelMode === 'year-month' 时生效
   *  - 排除二级面板内部点击（保留"选年/月不关闭面板"现有行为）
   *  - 排除 title 自身点击（让 togglePanelMode toggle 行为正常）
   *  - 使用 capture 阶段：保证在子元素 @click 之前判断，且首次点 title 打开面板时
   *    document handler 看到的 panelMode 还是 'date'（不会误触发关闭）
   */
  function handleDocumentClick(e: MouseEvent) {
    if (panelMode.value !== 'year-month') return;
    const target = e.target as Node | null;
    if (!target) return;
    if (yearMonthRef.value?.contains(target)) return;
    if (titleRef.value?.contains(target)) return;
    panelMode.value = 'date';
  }

  onMounted(() => {
    document.addEventListener('click', handleDocumentClick, true);
  });
  onUnmounted(() => {
    document.removeEventListener('click', handleDocumentClick, true);
  });

  function handleSelectYear(y: number) {
    // 选完年后若新年是今年 + 当前 props.month 超过今月，自动收紧到今月（避免跳到未来月份）
    let m = props.month;
    if (!props.allowFuture && y === today.value.year && m > today.value.month) {
      m = today.value.month;
    }
    emit('jump-to', y, m);
    // 保留在 year-month 模式（与 NDatePicker fast-year-select: false 默认对齐）：
    // 让用户可连续选年→选月，主动点 header title 才回到 date 模式
  }

  function handleSelectMonth(m: number) {
    if (isMonthDisabled(m)) return;
    emit('jump-to', props.year, m);
    // 保留在 year-month 模式（与 NDatePicker fast-month-select: false 默认对齐）
  }

  function getCellClass(cell: CalendarCell) {
    const start = props.selectedStart;
    const end = props.selectedEnd;
    const hoverEnd = !end && start && props.hoveredDate ? props.hoveredDate : null;
    const rangeEnd = end ?? hoverEnd;
    const canPaintRangeState = cell.inCurrentMonth;
    const isStart = canPaintRangeState && isSameDate(cell.parts, start);
    const isEnd = canPaintRangeState && isSameDate(cell.parts, rangeEnd);
    const inRange =
      canPaintRangeState &&
      start &&
      rangeEnd &&
      compareDateParts(cell.parts, start) >= 0 &&
      compareDateParts(cell.parts, rangeEnd) <= 0;

    return {
      'is-outside': !cell.inCurrentMonth,
      'is-today': canPaintRangeState && cell.isToday,
      'is-selected-start': isStart,
      'is-selected-end': isEnd,
      'is-in-range': inRange,
      'is-disabled': isDisabled(cell.parts),
    };
  }

  function isDisabled(parts: ZonedDateTimeParts) {
    return props.disabledDate?.(parts) ?? false;
  }

  function handleSelect(parts: ZonedDateTimeParts) {
    if (isDisabled(parts)) return;
    emit('select', parts);
  }
</script>

<style lang="less" scoped>
  .zoned-calendar-grid {
    --zoned-date-font-size: var(--font-size, 14px);
    --zoned-date-title-font-size: var(--font-size, 14px);
    --zoned-date-days-font-size: var(--font-size, 14px);
    --zoned-date-item-font-size: var(--font-size, 14px);
    --zoned-date-item-size: 24px;
    --zoned-date-cell-width: 38px;
    --zoned-date-cell-height: 32px;
    --zoned-date-radius: var(--border-radius-small, 3px);
    --zoned-date-primary: var(--primary-color, #18a058);
    --zoned-date-primary-soft: color-mix(in srgb, var(--primary-color, #18a058) 12%, transparent);
    --zoned-date-hover: var(--hover-color, rgba(46, 51, 56, 0.09));

    width: calc(var(--zoned-date-cell-width) * 7 + 24px);
    padding: 4px 12px;
    color: var(--text-color-2);
    font-family: inherit;
    font-size: var(--zoned-date-font-size);

    &__header {
      grid-template-columns: 28px 28px 1fr 28px 28px;
      height: 28px;
      padding: 0;
      font-size: var(--zoned-date-title-font-size);
    }

    &__nav {
      width: 14px;
      height: 14px;
      line-height: 0;
      color: var(--text-color-2);
    }

    &__title {
      border-radius: var(--border-radius, 3px);
      padding: 6px 8px;
      color: var(--text-color-1);
      font-size: var(--zoned-date-title-font-size);
      font-weight: var(--font-weight-strong, 600);
      line-height: var(--zoned-date-title-font-size);
      text-align: center;
      cursor: pointer;
      user-select: none;
      transition:
        background-color 0.3s var(--bezier),
        color 0.3s var(--bezier);

      &:hover {
        background-color: var(--zoned-date-hover);
      }
      &.is-active {
        color: var(--zoned-date-primary);
      }
      &:focus-visible {
        outline: 1px solid var(--zoned-date-primary);
        outline-offset: 1px;
      }
    }

    // year-month 二级面板：年列 + 月列两列对称（与原生 NDatePicker 截图一致）
    // 整体卡片感：圆角 + 1px 边框 + 阴影，与日历主体分明
    &__year-month {
      display: grid;
      grid-template-columns: 1fr 1fr;
      // 与 weekdays(1 行) + days(6 行 grid) 总高对齐，避免 mode 切换时父级高度抖动
      min-height: calc(var(--zoned-date-cell-height) * 7);
      margin: 4px 0;
      border: 1px solid var(--divider-color, #efeff5);
      border-radius: var(--border-radius, 3px);
      box-shadow: 0 2px 8px 0 rgba(0, 0, 0, 0.06);
      overflow: hidden;
      background: var(--card-color, #fff);
    }

    // 年列：一列纵向滚动（21+ 项需要滚动）
    &__year-col {
      overflow-y: auto;
      max-height: calc(var(--zoned-date-cell-height) * 7);
      display: flex;
      flex-direction: column;
      border-right: 1px solid var(--divider-color, #efeff5);
    }

    // 月列：与年列对称——一列纵向滚动（12 项，默认显示 6 项 + 滚动其余）
    &__month-col {
      overflow-y: auto;
      max-height: calc(var(--zoned-date-cell-height) * 7);
      display: flex;
      flex-direction: column;
    }

    &__year-item,
    &__month-item {
      flex-shrink: 0;
      padding: 8px 12px;
      border: 0;
      background: transparent;
      cursor: pointer;
      color: var(--text-color-1);
      font-size: var(--zoned-date-item-font-size);
      font-family: inherit;
      text-align: center;
      transition:
        background-color 0.2s var(--bezier),
        color 0.2s var(--bezier);

      // hover：浅 primary 横向条带（对齐 NDatePicker 截图 hover 视觉）
      &:hover:not(.is-disabled):not(.is-current) {
        background-color: var(--zoned-date-primary-soft);
      }

      // current：无背景，仅 primary 文字 + 加粗（对齐 NDatePicker 截图当前项视觉）
      // 与 hover 视觉层次：disabled < normal < hover (primary-soft 背景) < current (primary 文字)
      &.is-current {
        background-color: transparent;
        color: var(--zoned-date-primary);
        font-weight: var(--font-weight-strong, 600);
      }

      &.is-disabled {
        color: var(--text-color-disabled);
        cursor: not-allowed;
      }
    }

    &__weekdays {
      grid-template-columns: repeat(7, var(--zoned-date-cell-width));
      grid-template-rows: var(--zoned-date-cell-height);
      margin: 0 auto 4px;
      border-bottom: 1px solid var(--divider-color);
    }

    &__weekday {
      display: flex;
      width: var(--zoned-date-item-size);
      align-items: center;
      justify-content: center;
      color: var(--text-color-2);
      font-size: var(--zoned-date-days-font-size);
      line-height: 15px;
      white-space: nowrap;
    }

    &__days {
      grid-template-columns: repeat(7, var(--zoned-date-cell-width));
      grid-auto-rows: var(--zoned-date-cell-height);
      margin: auto;
    }

    &__day {
      width: var(--zoned-date-item-size);
      height: var(--zoned-date-item-size);
      margin-bottom: 2px;
      border-radius: var(--zoned-date-radius);
      color: var(--text-color-2);
      font-size: var(--zoned-date-item-font-size);
      line-height: var(--zoned-date-item-size);
      transition:
        background-color 0.2s var(--bezier),
        color 0.2s var(--bezier);

      &::before {
        position: absolute;
        z-index: -2;
        top: 0;
        bottom: 0;
        left: calc((var(--zoned-date-item-size) - var(--zoned-date-cell-width)) / 2);
        right: calc((var(--zoned-date-item-size) - var(--zoned-date-cell-width)) / 2);
        background: transparent;
        content: '';
      }

      &::after {
        position: absolute;
        z-index: -1;
        inset: 0;
        border-radius: inherit;
        background: transparent;
        content: '';
        transition: background-color 0.2s var(--bezier);
      }

      span {
        position: relative;
        z-index: 0;
      }

      &.is-outside {
        color: var(--text-color-disabled);
      }

      &.is-today span::after {
        position: absolute;
        top: 0;
        right: -4px;
        width: 4px;
        height: 4px;
        border-radius: 50%;
        background: var(--zoned-date-primary);
        content: '';
      }

      &.is-in-range {
        color: var(--zoned-date-primary);

        &::before {
          background: var(--zoned-date-primary-soft);
        }
      }

      &.is-selected-start,
      &.is-selected-end {
        color: #fff;

        &::after {
          background: var(--zoned-date-primary);
        }
      }

      &.is-selected-start::before {
        left: 50%;
      }

      &.is-selected-end::before {
        right: 50%;
      }

      &.is-selected-start.is-selected-end::before {
        background: transparent;
      }

      &.is-selected-start span::after,
      &.is-selected-end span::after {
        background: #fff;
      }

      &.is-disabled {
        color: var(--text-color-disabled);
        cursor: not-allowed;
      }

      &:not(.is-disabled):not(.is-selected-start):not(.is-selected-end):hover::after {
        background: var(--zoned-date-hover);
      }
    }
  }
</style>
