export type DragMode = 'move' | 'none';
export type ExportFormat = 'original' | 'png' | 'jpeg' | 'webp';
export type CropOutputMode = 'preview' | 'download';
export type SupportedExportMimeType = 'image/png' | 'image/jpeg' | 'image/webp';
export type CropRequestOptions = {
  width?: number;
  height?: number;
  type?: SupportedExportMimeType;
  quality?: number;
};

type CropOutputSizeParams = {
  mode: CropOutputMode;
  outputWidth: number | null | undefined;
  outputHeight: number | null | undefined;
  previewMaxEdge?: number;
  fallbackWidth?: number;
  fallbackHeight?: number;
};

type CreateCropRequestOptionsParams = {
  mode: CropOutputMode;
  outputWidth: number | null | undefined;
  outputHeight: number | null | undefined;
  exportFormat: ExportFormat;
  sourceType?: string | null;
  exportQuality?: number | null;
  previewMaxEdge?: number;
  fallbackWidth?: number;
  fallbackHeight?: number;
};

/** ImageCropper 与业务页面共用的基础配置常量 */
export const SUPPORTED_IMAGE_MIME_TYPES: SupportedExportMimeType[] = [
  'image/png',
  'image/jpeg',
  'image/webp',
];
export const SUPPORTED_IMAGE_EXTENSIONS = ['png', 'jpg', 'jpeg', 'webp'];
export const MIN_OUTPUT_DIMENSION = 1;
export const MAX_OUTPUT_DIMENSION = 4096;
export const DEFAULT_EXPORT_QUALITY = 92;
export const DEFAULT_ROTATE_FINE_STEP = 5;
export const DEFAULT_PREVIEW_MAX_EDGE = 960;

/** 数值钳制工具：确保结果落在指定区间内 */
export function clamp(value: number, min: number, max: number) {
  return Math.min(Math.max(value, min), max);
}

/** 标准化 mime 类型；不支持时返回 null */
export function normalizeMimeType(type?: string | null): SupportedExportMimeType | null {
  const normalizedType = (type || '').toLowerCase();
  if (normalizedType === 'image/jpg') return 'image/jpeg';
  if (SUPPORTED_IMAGE_MIME_TYPES.includes(normalizedType as SupportedExportMimeType)) {
    return normalizedType as SupportedExportMimeType;
  }
  return null;
}

export function resolveExportMimeType(
  exportFormat: ExportFormat,
  sourceType?: string | null,
): SupportedExportMimeType {
  // 显式格式优先，original 时回落到原图 mime，仍不可用则默认 png
  if (exportFormat === 'png') return 'image/png';
  if (exportFormat === 'jpeg') return 'image/jpeg';
  if (exportFormat === 'webp') return 'image/webp';
  return normalizeMimeType(sourceType) || 'image/png';
}

/** JPEG/WEBP 才支持质量参数 */
export function isQualityAdjustableMimeType(type: SupportedExportMimeType) {
  return type === 'image/jpeg' || type === 'image/webp';
}

/** 仅基于后缀判断文件是否属于可裁剪图片格式 */
export function hasSupportedImageExtension(fileName: string) {
  const nextName = fileName.toLowerCase();
  return SUPPORTED_IMAGE_EXTENSIONS.some((extension) => nextName.endsWith(`.${extension}`));
}

/** 输出尺寸标准化：补默认值 + 四舍五入 + 范围约束 */
export function normalizeDimension(
  value: number | null | undefined,
  fallback: number,
  min = MIN_OUTPUT_DIMENSION,
  max = MAX_OUTPUT_DIMENSION,
) {
  const raw = typeof value === 'number' && Number.isFinite(value) ? value : fallback;
  return clamp(Math.round(raw), min, max);
}

/** 导出质量标准化到 1-100 */
export function normalizeExportQuality(
  value: number | null | undefined,
  fallback = DEFAULT_EXPORT_QUALITY,
) {
  const raw = typeof value === 'number' && Number.isFinite(value) ? value : fallback;
  return clamp(Math.round(raw), 1, 100);
}

/** 微调角度标准化到 1-45 */
export function normalizeRotateFineStep(
  value: number | null | undefined,
  fallback = DEFAULT_ROTATE_FINE_STEP,
) {
  const raw = typeof value === 'number' && Number.isFinite(value) ? value : fallback;
  return clamp(Math.round(raw), 1, 45);
}

/** 拖拽模式容错，保证只输出 move/none */
export function normalizeDragMode(value: DragMode | string | null | undefined): DragMode {
  return value === 'none' ? 'none' : 'move';
}

/** 统一计算裁剪输出尺寸；预览模式会按最大边限制自动缩放 */
export function getCropOutputSize({
  mode,
  outputWidth,
  outputHeight,
  previewMaxEdge = DEFAULT_PREVIEW_MAX_EDGE,
  fallbackWidth = 800,
  fallbackHeight = 450,
}: CropOutputSizeParams) {
  const width = normalizeDimension(outputWidth, fallbackWidth);
  const height = normalizeDimension(outputHeight, fallbackHeight);

  if (mode === 'download') {
    return { width, height };
  }

  const normalizedPreviewMaxEdge = Math.max(1, Math.round(previewMaxEdge));
  const maxEdge = Math.max(width, height);
  if (maxEdge <= normalizedPreviewMaxEdge) {
    return { width, height };
  }

  const scale = normalizedPreviewMaxEdge / maxEdge;
  return {
    width: Math.max(1, Math.round(width * scale)),
    height: Math.max(1, Math.round(height * scale)),
  };
}

/** 根据页面配置生成可直接传给 cropper 的请求参数 */
export function createCropRequestOptions({
  mode,
  outputWidth,
  outputHeight,
  exportFormat,
  sourceType,
  exportQuality,
  previewMaxEdge,
  fallbackWidth,
  fallbackHeight,
}: CreateCropRequestOptionsParams): CropRequestOptions {
  const outputSize = getCropOutputSize({
    mode,
    outputWidth,
    outputHeight,
    previewMaxEdge,
    fallbackWidth,
    fallbackHeight,
  });
  const mimeType = resolveExportMimeType(exportFormat, sourceType);
  const options: CropRequestOptions = {
    width: outputSize.width,
    height: outputSize.height,
    type: mimeType,
  };

  if (isQualityAdjustableMimeType(mimeType)) {
    options.quality = normalizeExportQuality(exportQuality) / 100;
  }

  return options;
}
