import { h } from 'vue';
import { NRadio, NRadioGroup } from 'naive-ui';
import { endOfDay, format } from 'date-fns';
import type { ProColumn } from '@/components';
import { currency } from '@/utils';

/** 把时间戳格式化成后端要求的 'yyyy-MM-dd HH:mm:ss' 字符串 */
function fmtDateTime(ts: number): string {
  return format(ts, 'yyyy-MM-dd HH:mm:ss');
}

/**
 * 投注统计表格列配置
 */
export function createBettingStatColumns(t: (key: string) => string): ProColumn[] {
  return [
    { key: 'gameType', title: t('member.detail.betting.gameType'), width: 80 },
    { key: 'provider', title: t('member.detail.betting.provider'), width: 110 },
    {
      key: 'subGameName',
      title: t('member.detail.betting.subGameName'),
      width: 140,
      ellipsis: { tooltip: true },
    },
    { key: 'subGameId', title: t('member.detail.betting.subGameId'), width: 100 },
    { key: 'betCount', title: t('member.detail.betting.betCount'), width: 90 },
    {
      key: 'betAmount',
      title: t('member.detail.betting.betAmount'),
      width: 140,
      render: (row) => h('span', { style: 'font-weight: 500;' }, currency(row.betAmount)),
    },
    {
      key: 'validBetAmount',
      title: t('member.detail.betting.validBetAmount'),
      width: 120,
      render: (row) => currency(row.validBetAmount),
    },
    {
      key: 'payoutAmount',
      title: t('member.detail.betting.payoutAmount'),
      width: 110,
      render: (row) => currency(row.payoutAmount),
    },
    {
      key: 'profit',
      title: t('member.detail.betting.platformProfit'),
      width: 110,
      sortable: 'custom',
      render: (row) => {
        const val = row.winLoseAmount ?? 0;
        return h(
          'span',
          { style: `color: ${val >= 0 ? '#16a34a' : '#dc2626'}; font-weight: 600;` },
          (val >= 0 ? '+' : '') + currency(val),
        );
      },
    },
  ];
}

/**
 * 游戏类型映射（函数形式，支持 i18n）
 */
export function getCategoryTypeMap(t: (key: string) => string) {
  return {
    0: t('member.detail.betting.categoryElectronic'),
    1: t('member.detail.betting.categoryLive'),
    2: t('member.detail.betting.categorySport'),
    3: t('member.detail.betting.categoryLottery'),
    4: t('member.detail.betting.categoryChess'),
  };
}

/**
 * 创建投注统计搜索列配置
 * 需要响应式数据，所以用工厂函数
 */
export function createBettingSearchColumns(
  t: (key: string) => string,
  options: {
    lastWithdrawTime: string;
    parseLastWithdrawTime: () => number | null;
    defaultBetTimeRange: [number, number];
    default30DaysRange: [number, number];
    onUserModifyTime?: () => void;
  },
) {
  const {
    lastWithdrawTime,
    parseLastWithdrawTime,
    defaultBetTimeRange,
    default30DaysRange,
    onUserModifyTime,
  } = options;

  return [
    {
      path: 'timeRange',
      label: t('member.detail.betting.timeRange'),
      valueType: 'proDateRange' as const,
      placeholder: t('member.detail.betting.selectTimeRange'),
      defaultValue: lastWithdrawTime
        ? [fmtDateTime(parseLastWithdrawTime()!), fmtDateTime(endOfDay(new Date()).getTime())]
        : [fmtDateTime(defaultBetTimeRange[0]), fmtDateTime(defaultBetTimeRange[1])],
      span: 2,
      componentProps: {
        valueFormat: 'string',
        displayFormat: 'yyyy-MM-dd HH:mm:ss',
        maxDays: 90,
        allowFuture: false,
        shortcuts: false,
        // 时间区间为必选业务语义，去掉清除按钮，避免清空后无起止时间
        clearable: false,
        onConfirm: onUserModifyTime,
        // 展平写回：起 → form.startTime，止 → form.endTime
        modelKeys: ['startTime', 'endTime'],
      },
      order: 99,
    },
    {
      path: 'timePreset',
      formItemProps: { showLabel: false },
      order: 99,
      defaultValue: lastWithdrawTime ? 'since_last_withdraw' : 'all',
      render: ({ formModel, setValue }) => {
        // 在 render 函数内提前求值，避免 slot 函数在 render 外部调用时触发 Vue 警告
        const sinceLastLabel = t('member.detail.betting.sinceLastWithdraw');
        const allLabel = t('member.detail.betting.all');
        return h(
          NRadioGroup,
          {
            value: formModel.timePreset ?? (lastWithdrawTime ? 'since_last_withdraw' : 'all'),
            onUpdateValue: (val) => {
              setValue(val);
              onUserModifyTime?.();
              // 同步更新时间区间控件：写入 modelKeys 对应的分字段 startTime / endTime
              if (val === 'since_last_withdraw' && lastWithdrawTime) {
                const ts = parseLastWithdrawTime();
                if (ts) {
                  formModel.startTime = fmtDateTime(ts);
                  formModel.endTime = fmtDateTime(endOfDay(new Date()).getTime());
                }
              } else if (val === 'all') {
                // "所有" 与 "从上次提现至今" 语义对立：强制重置为 default30DaysRange，
                // 不读 globalTimeRange——上层 MemberDetailShell 会把顶部 toolbar 时间
                // 自动写成 [lastWithdrawTime, now]，若此处复用 globalTimeRange，
                // 切到"所有"后开始时间纹丝不动（视觉上等同于"从上次提现至今"）
                formModel.startTime = fmtDateTime(default30DaysRange[0]);
                formModel.endTime = fmtDateTime(endOfDay(default30DaysRange[1]).getTime());
              }
            },
          },
          () => [
            h(NRadio, { value: 'since_last_withdraw' }, { default: () => sinceLastLabel }),
            h(NRadio, { value: 'all' }, { default: () => allLabel }),
          ],
        );
      },
    },
  ];
}
