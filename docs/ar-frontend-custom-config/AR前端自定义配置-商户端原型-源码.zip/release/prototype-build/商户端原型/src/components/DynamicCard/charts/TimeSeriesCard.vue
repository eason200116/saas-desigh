<script setup lang="ts">
  /**
   * 时序数据图表卡片
   * 支持：bar（柱状图）、line（折线图）、bar_line（柱线混合）、stacked（堆叠图）
   */
  import { computed } from 'vue';
  import { useI18n } from 'vue-i18n';
  import Chart1 from '@/components/Chart/chart1.vue';
  import BaseChartCard from './BaseChartCard.vue';
  import {
    generateBarLineConfig,
    generateBarLineComboConfig,
    generateStackedConfig,
  } from '../chartConfigs';
  import type { CardConfig, TimeSeriesDataPoint } from '../types';

  type ChartType = 'bar' | 'line' | 'bar_line' | 'stacked';

  interface Props {
    title: string;
    chartType: ChartType;
    data: TimeSeriesDataPoint[];
    config: CardConfig;
    height?: string | number;
    loading?: boolean;
    showToggle?: boolean;
  }

  const props = withDefaults(defineProps<Props>(), {
    height: 220,
    loading: false,
    showToggle: true,
  });

  const { t } = useI18n();

  // 是否有数据
  const hasData = computed(() => props.data && props.data.length > 0);

  // 生成图表配置
  const chartConfig = computed(() => {
    if (!hasData.value) return null;

    switch (props.chartType) {
      case 'bar':
        return generateBarLineConfig(props.data, props.config, 'bar', t);
      case 'line':
        return generateBarLineConfig(props.data, props.config, 'line', t);
      case 'bar_line':
        return generateBarLineComboConfig(props.data, props.config, t);
      case 'stacked':
        return generateStackedConfig(props.data, props.config, t);
      default:
        return null;
    }
  });

  // 表格列配置
  const tableColumns = computed(() => {
    const cols: any[] = [
      { title: t('analytics.common.time'), key: 'time' },
      {
        title: props.config.seriesName || t('analytics.common.value'),
        key: 'value',
      },
    ];

    // 如果有第二系列
    if (props.config.seriesName2) {
      cols.push({
        title: props.config.seriesName2,
        key: 'value2',
      });
    }

    return cols;
  });
</script>

<template>
  <BaseChartCard
    :title="title"
    :height="height"
    :loading="loading"
    :show-toggle="showToggle"
    :has-data="hasData"
  >
    <template #chart="{ height: h }">
      <Chart1 v-if="chartConfig" :config="chartConfig" :height="h" />
    </template>
    <template #table="{ maxHeight }">
      <n-data-table
        :columns="tableColumns"
        :data="data"
        :bordered="false"
        size="small"
        :max-height="maxHeight"
      />
    </template>
  </BaseChartCard>
</template>

<script lang="ts">
  export default {
    name: 'TimeSeriesCard',
  };
</script>
