// 提现配置（总控端 admin · finance_withdraw_config_page）功能说明书。
// 锚定 src/views/finance/withdrawConfig/index.vue 容器 + 2 个子 Tab（channelDictionary 提现通道字典 /
// bankMapping 代付三方银行）各自的 index.vue/data.ts/useXxxPage.ts/编辑弹窗真实控件（R53 实证、不臆造）。
// 容器只是 n-tabs 壳（读 route.meta.tabs），2 个子 Tab 各自独立的搜索表单 + 列表 + 操作，互不共用编辑弹窗——
// 与 withdrawType.ts（提现类型管理）同属"1 路由 2 子 Tab"结构范式，但本页路由 meta.roles 仅 ['admin']，
// 是总控端专属页面（非商户端可见）。

import type { PageManual } from '../types';

const manual: PageManual = {
  route: 'finance_withdraw_config_page',
  title: '提现配置',
  overview:
    '总控端「财务管理 › 提现配置」页（路由 meta.roles 仅 [\'admin\']，非商户端可见页面），容器是一个 2 标签页壳（提现通道字典 / 代付三方银行），两个标签页完全独立、互不共用组件：「提现通道字典」维护平台内置的提现通道基础定义（三方映射码/内置提现大类/网关地址/是否校验银行等），仅支持编辑、不支持新增删除；「代付三方银行」维护每个通道背后实际可代付的银行清单（通道→银行名称→三方Code的映射关系），支持新增/编辑/删除单条，以及 CSV 批量导入。2026-07-21 核实代码时曾发现 4 处 mock 层真实缺陷（状态开关/编辑保存不持久化、"是否校验银行"可编辑性判断枚举语义错位、代付银行增删改不持久化、批量导入返回结构与消费方期望不匹配导致必现失败提示），已于 2026-07-22 逐个修复（状态/编辑/新增/删除均真实写回底层数组，枚举语义对齐本页 CATEGORY_ENUM，批量导入改为解析文件返回数组），详见 ChangeLogFab v1.9.146。',
  items: [
    // ============ 容器：Tab 切换 ============
    {
      anchor: 'tab_switch',
      name: '2 个子页 Tab 切换（提现通道字典 / 代付三方银行）',
      group: '操作',
      interaction: '点顶部 Tab 切换，2 个 Tab 各自独立的搜索表单 + 列表 + 操作，不共用编辑弹窗。',
      dataSource:
        '从当前路由 meta.tabs 读取配置（useRouteTabs），默认展示「提现通道字典」Tab（key: channelDictionary）。',
      logic: '默认 keepAlive（各 Tab 切走后状态不丢，含分页/筛选）。',
      note: '容器组件 src/views/finance/withdrawConfig/index.vue 本身只是壳，不含独立业务控件；实际控件都在两个子 Tab 自己的 index.vue / useXxxPage.ts 里。',
    },

    // ============ Tab①提现通道字典：搜索 ============
    {
      anchor: 'dict_categoryId',
      name: '内置提现大类（提现通道字典 Tab，搜索区）',
      group: '搜索',
      interaction: '下拉单选，可搜索可清空。',
      dataSource:
        "common 字典 withdrawCategoryEnumList（dict.getOptions('withdrawCategoryEnumList',{source:'common'})，用户登录 boot 阶段一次性加载）。",
      logic: '按选中大类 ID 精确过滤列表。',
      limit: '选填。',
      edge: '该下拉选项与列表「内置提现大类」列使用同一份字典数据源，值域一致。',
    },
    {
      anchor: 'dict_payCode',
      name: '三方映射码（提现通道字典 Tab，搜索区）',
      group: '搜索',
      interaction: '下拉单选，可搜索可清空。',
      dataSource:
        "useChannelGroupList 共享的 withdrawPayCodeOptions（GetChannelSelectData({channelType:'Withdraw'}) 返回的 payCodes）。",
      logic:
        '选中后清空"通道名称"已选值并重新加载该映射码下的通道名称选项（loadChannelNames）；清空时重载全量通道名称。',
      edge: '与「代付三方银行」Tab 的同名字段共用同一个 useChannelGroupList 数据源（同一份 payCode 列表）。',
    },
    {
      anchor: 'dict_channelId',
      name: '通道名称（提现通道字典 Tab，搜索区）',
      group: '搜索',
      interaction: '下拉单选可搜索可清空，依赖三方映射码。',
      dataSource:
        "GetChannelSelectData({channelType:'Withdraw', payCode})，展示为「[通道ID] 通道名称」，值为通道字典 id（number）。",
      logic: '按 channelId 精确匹配过滤。',
      limit: '选填。',
    },
    {
      anchor: 'dict_sysCurrency',
      name: '提现币种（提现通道字典 Tab，搜索区）',
      group: '搜索',
      interaction: '下拉单选可搜索可清空。',
      dataSource:
        "useChannelGroupList 共享的 currencyOptions（GetCurrencySelectData({channelType:'Withdraw'})，固定 INR/USDT/BRL 三种）。",
      logic: '按选中币种精确过滤。',
    },
    {
      anchor: 'dict_state',
      name: '状态（提现通道字典 Tab，搜索区）',
      group: '搜索',
      interaction: '下拉单选可清空，固定 2 个选项。',
      dataSource: '固定选项：启用(1) / 禁用(0)，非字典来源。',
      logic: '按选中值精确过滤（不选=不筛）。',
    },

    // ============ Tab①提现通道字典：列 ============
    {
      anchor: 'col_dict_payCode',
      name: '三方映射码列（提现通道字典 Tab）',
      group: '列',
      interaction: '标签（NTag）展示，不可点。',
      dataSource: '行数据 payCode。',
      logic:
        "payCode==='SystemBuiltIn' 时（如 id=999「Manual Handle」内置行）额外并排展示一个「内置」标签；其余行仅展示映射码本身标签。",
      note: '与搜索区「三方映射码」下拉是同一批字典派生数据的两种呈现。',
    },
    {
      anchor: 'col_dict_categoryName',
      name: '内置提现大类列（提现通道字典 Tab）',
      group: '列',
      interaction: '标签（NTag）展示，不可点。',
      dataSource:
        "行数据 categoryId，经 dict.findLabel('withdrawCategoryEnumList', categoryId) 反查名称。",
      logic:
        '若反查结果为空或等于裸 ID 字符串（未命中兜底）则显示"--"；此判断专门用于避免内置行（如 Manual Handle 的 categoryId=0，字典最小 id=1）渲染出裸"0"（源码注释明确写此意图）。',
    },
    {
      anchor: 'col_dict_state',
      name: '状态列（提现通道字典 Tab，启用/禁用开关）',
      group: '列',
      interaction:
        "开关（ConfirmSwitch），点击弹二次确认框确认后才真正切换，命中 R47；payCode==='SystemBuiltIn' 的内置行禁用（不可点）。",
      dataSource: '行数据 state（0/1）。',
      logic:
        '确认后调用 withdrawChannelDictionaryUpdateState 提交，成功后整表 reload 并提示"更新成功"。',
      edge: '2026-07-22 已修复：withdrawChannelDictionaryUpdateState 现按 id 定位后真实写回 CHANNEL_DICTIONARY 数组的 state 字段，切换开关 reload 后能看到状态变化（2026-07-21 曾如实记录为未修复缺陷，详见 ChangeLogFab v1.9.146）。',
    },

    // ============ Tab①提现通道字典：操作 ============
    {
      anchor: 'dict_edit',
      name: '编辑（提现通道字典 Tab，行操作按钮）',
      group: '操作',
      interaction:
        "点行内「编辑」打开弹窗（ChannelDictionaryEditModal，宽 560px，标题含通道ID+通道名称+币种标签）；payCode==='SystemBuiltIn' 的内置行（id=999 Manual Handle）整个操作列显示「--」，无编辑入口。",
      dataSource:
        '弹窗内"内置提现大类"下拉选项：若 payCode 为 ArbPayINR/ArbPay2INR（锁定映射码）则用 row 自身 categoryId 经字典反查构造单一回显项（下拉禁用，不可改）；否则调用 getChannelWithdrawCategoryEnumList({sysCurrency}) 按币种取候选（INR→银行卡+UPI 两类，USDT→数字货币一类，BRL→PIX 一类）。',
      logic:
        '弹窗字段=内置提现大类下拉/通道名称/三方通道编码/网关地址/是否校验银行开关；提交调用 withdrawChannelDictionaryUpdate，成功后提示"更新成功"并 reload。"是否校验银行"开关仅当选中大类为"银行卡"或"E-Wallet"语义时可编辑，其余大类强制不可编辑并重置为不校验（切大类时 onCategoryChange 自动重置）。',
      limit:
        '通道名称必填 ≤30 字（不超过 INPUT_PRESETS.name 默认的 50 字上限）；三方通道编码选填 ≤200 字，仅字母数字；网关地址必填 ≤50 字，且须以 http:// 或 https:// 开头（正则校验）；内置提现大类必选。',
      edge: '2026-07-22 已修复两处（2026-07-21 曾如实记录为未修复缺陷，详见 ChangeLogFab v1.9.146）：①withdrawChannelDictionaryUpdate 现按 id 定位后真实写回 CHANNEL_DICTIONARY 对应字段，保存后 reload 能看到修改生效。②"是否校验银行"开关可编辑性判断：弹窗组件本地 CATEGORY 常量已改为对齐本页 mock data.ts 的 CATEGORY_ENUM 真实语义（1=INR银行卡/2=USDT数字货币/3=UPI钱包/4=PIX即时支付），可编辑条件收窄为仅"银行卡"(id=1)；列表里 id=601「BancoDoBrasil-PIX」通道（categoryId:4，语义是 PIX）编辑时正确锁定为不可编辑，不再因 id 巧合误判。',
    },

    // ============ Tab②代付三方银行：搜索 ============
    {
      anchor: 'bank_payCode',
      name: '三方映射码（代付三方银行 Tab，搜索区）',
      group: '搜索',
      interaction: '下拉单选可搜索可清空。',
      dataSource: 'useChannelGroupList 共享的 withdrawPayCodeOptions（与提现通道字典 Tab 同源）。',
      logic:
        '选中后清空"通道名称"已选值并联动加载该映射码下的通道选项（loadSearchChannelOptions）；已加载过的 payCode 会跳过重复请求（loadedPayCode 缓存判重）。',
      limit: '选填。',
    },
    {
      anchor: 'bank_channelId',
      name: '通道名称（代付三方银行 Tab，搜索区）',
      group: '搜索',
      interaction: '下拉单选可搜索可清空，依赖三方映射码。',
      dataSource:
        "GetChannelSelectData({channelType:'Withdraw', payCode})，展示为「[通道ID] 通道名称」。",
      logic: '按 channelId 精确过滤。',
    },
    {
      anchor: 'bank_bankName',
      name: '银行名称（代付三方银行 Tab，搜索区）',
      group: '搜索',
      interaction: '文本输入。',
      dataSource: '用户输入。',
      logic: '按银行名称子串匹配（不区分大小写 includes）过滤。',
      limit: "选填；最多 50 字（inputProps('name') 预设）。",
    },

    // ============ Tab②代付三方银行：操作 ============
    {
      anchor: 'bank_add',
      name: '新增（代付三方银行 Tab，表格左上角按钮）',
      group: '操作',
      interaction:
        '点表格左上角"新增"按钮打开弹窗（BankMappingEditModal，宽 600px），2 列栅格布局：三方映射码 / 通道名称（联动 payCode）/ 银行名称 / 三方Code。',
      dataSource:
        '"三方映射码"下拉选项来自父级传入的 withdrawPayCodeOptions；选中映射码后"通道名称"下拉调用（弹窗组件自身 data.ts 的）getChannelSelectData({channelType:\'Withdraw\',payCode}) 加载。',
      logic: '四项均必填；提交调用 addBankMapping，成功后提示"新增成功"并关闭弹窗、刷新列表。',
      limit:
        '银行名称 ≤50 字（INPUT_PRESETS.name，普通文本无控制字符即可）；三方Code ≤32 字，仅字母数字（INPUT_PRESETS.code）。',
      edge: '2026-07-22 已修复：addBankMapping 现真实 unshift 新记录到 BANK_MAPPINGS 数组表头（按 channelId 从 ALL_CHANNELS 反查表补全 payCode/channelName），新增后 reload 能在列表看到新记录（2026-07-21 曾如实记录为未修复缺陷，详见 ChangeLogFab v1.9.146）。',
    },
    {
      anchor: 'bank_batchImport',
      name: '批量导入（代付三方银行 Tab，表格左上角按钮）',
      group: '操作',
      interaction:
        '点表格左上角"批量导入"打开弹窗（BankMappingImportModal，宽 860px）；内含"模板下载"+"上传Excel"两个工具栏按钮、上传提示文案（单次限 5000 条/文件 ≤3M）、始终显示的预览表格（通道字典ID/银行名称/三方Code）。2026-07-25 改版：底部新增常驻按钮区"取消"（始终可点，关闭弹窗）+"一键导入"（始终渲染，无预览数据或已导入完成时禁用，不再整段隐藏）；点击"一键导入"先切到本弹窗内的二次确认视图（标题"导入预览"+数据摘要"共 N 条数据，其中通过 X 条、校验失败 Y 条"+提示文案+内嵌同一份预览表格），确认视图"取消"回退上传视图（不提交）、"发布"才真正调用 batchImportBankMapping(file)。',
      dataSource:
        '"模板下载"用 Blob 在前端本地生成 CSV（表头"通道字典ID,银行名称,三方Code"+一行样例数据），非请求接口；"上传Excel"实际触发隐藏的 `<input type="file" accept=".csv">`，选中文件后前端本地按逗号分隔纯文本解析（不请求接口），生成预览行。',
      logic:
        '解析时校验通道ID须为有限正整数，否则该行置 0 并标红错误信息"通道ID无效，必须为正整数"；文件大小超 3MB 或解析后行数超 5000 条会分别弹警告并中止（不进入预览）；空文件（无有效数据行）弹"文件中没有可导入的数据"。2026-07-25 起：点击"一键导入"仅切到二次确认视图，须在确认视图再点"发布"才真正调用 batchImportBankMapping(file) 提交；确认视图"取消"或提交失败都会自动收起回上传视图，预览数据保留可重试。',
      limit: '文件大小 ≤3MB；单次导入 ≤5000 条（不含表头行）。',
      edge: '核实代码后发现两处问题，①如实记录暂未修复（不在 2026-07-22 修复范围）：按钮文案是"上传Excel"（i18n uploadFile），但 input 限定 accept=".csv" 且解析逻辑只按纯文本 CSV 格式处理，与"Excel"字面表述不完全相符。②已于 2026-07-22 修复：batchImportBankMapping 的 mock（components/data.ts）此前返回 data:{successCount,failCount,failList}（一个对象），但弹窗消费时按 response.data.data ?? response.data ?? [] 取值取到的是该对象本身（非数组），对其调用 .filter() 抛 TypeError 被外层 catch 吞掉转成"导入失败"——现 mock 已改为直接解析上传文件、返回逐行结果数组（含 channelId/bankName/thirdCode/success/errorMsg），结构对齐消费方数组期望，一键导入不再必现失败提示（2026-07-21 曾如实记录为未修复缺陷，详见 ChangeLogFab v1.9.146）。③2026-07-25：任务原文要求二次确认参照 bankDictionary/BatchImportModal.vue 用 useDialog()+dialog.warning() 实现，但核实该参照文件当日最新代码后发现它与 BankAddModal.vue 均已因 Eason 实测"点了没反应"做紧急修复、弃用了 useDialog() 嵌套弹窗（本组件同样经 modal.create()/useModal() 渲染，嵌套 useDialog() 属"覆盖层套覆盖层"架构，全项目未见验证工作的先例）；本组件经核实同架构，故改用已验证安全的组件内 showConfirm 视图切换实现同等的二次确认效果，未按原文字面用 useDialog()（详见 ChangeLogFab v2.0.119）。同一 modal-stack 场景下 BankMappingEditModal.vue（v2.0.118）目前仍是未修复的 useDialog() 写法，本次任务范围明确排除该文件、未动，已提请一并核查。',
    },
    {
      anchor: 'bank_edit',
      name: '编辑（代付三方银行 Tab，行操作按钮）',
      group: '操作',
      interaction:
        '点行内"编辑"打开同一弹窗（BankMappingEditModal），预填当前行数据；组件挂载时若已有 payCode 会自动预加载对应通道选项。',
      dataSource:
        '直接使用行数据（id/payCode/channelId/channelName/bankName/thirdCode）构造表单初值，无独立详情接口。',
      logic: '字段集合与"新增"完全一致；提交调用 editBankMapping，成功后提示"更新成功"并刷新列表。',
      edge: '2026-07-22 已修复：editBankMapping 现按 id 定位后真实写回 BANK_MAPPINGS 对应行（含按 channelId 反查更新 payCode/channelName），编辑保存后 reload 能看到修改生效（2026-07-21 曾如实记录为未修复缺陷，详见 ChangeLogFab v1.9.146）。',
    },
    {
      anchor: 'bank_delete',
      name: '删除（代付三方银行 Tab，行操作按钮）',
      group: '操作',
      interaction:
        '点行内"删除"，弹二次确认对话框（useDialog.warning，非 ActionConfig 内置 delete 语义）。',
      logic: '确认后调用 deleteBankMapping({id})，成功后提示"删除成功"并刷新列表。',
      edge: '2026-07-22 已修复：deleteBankMapping 现按 id 定位后真实从 BANK_MAPPINGS 数组 splice 移除该行，删除后 reload 该行不再出现，新增/编辑/删除三个操作现均已真实持久化（2026-07-21 曾如实记录为未修复缺陷，详见 ChangeLogFab v1.9.146）。',
    },
  ],

  // ============ 字段介绍 tab（按各自 Tab 列表列真实列序；仅列表列 + 定义）============
  fields: [
    // ---- 提现通道字典 Tab（11 列，同 channelDictionary/useChannelDictionaryPage.ts tableColumns 顺序）----
    { name: '「提现通道字典」通道字典ID', def: '该条通道字典记录的唯一编号。' },
    { name: '「提现通道字典」通道名称', def: '该通道的展示名称（如"ArbPay-IMPS"）。' },
    {
      name: '「提现通道字典」三方映射码',
      def: '该通道所属的三方支付映射码（payCode），系统内置行（Manual Handle）额外标注"内置"标签。',
    },
    { name: '「提现通道字典」三方通道编码', def: '对接三方支付网关时使用的通道编码。' },
    {
      name: '「提现通道字典」内置提现大类',
      def: '该通道归属的系统内置提现大类（如 INR银行卡/USDT数字货币/UPI钱包/PIX即时支付）。',
    },
    { name: '「提现通道字典」提现币种', def: '该通道处理的结算币种（如 INR/USDT/BRL）。' },
    {
      name: '「提现通道字典」是否校验银行',
      def: '发起提现时是否需要校验收款银行信息，彩色文字展示（校验=绿色 / 不校验=灰色）。',
    },
    { name: '「提现通道字典」网关地址', def: '对接三方支付的 API 网关地址。' },
    { name: '「提现通道字典」最后修改人', def: '最近一次编辑该通道配置的操作人账号。' },
    { name: '「提现通道字典」最后修改时间', def: '最近一次编辑该通道配置的时间。' },
    {
      name: '「提现通道字典」启用状态',
      def: '该通道是否启用（可主动开关切换，系统内置行不可操作）。',
    },

    // ---- 代付三方银行 Tab（6 列，同 bankMapping/useBankMappingPage.ts tableColumns 顺序）----
    {
      name: '「代付三方银行」三方映射码',
      def: '该条银行映射所属的三方支付映射码（payCode），标签形式展示。',
    },
    {
      name: '「代付三方银行」通道名称',
      def: '该映射所属的具体通道，展示为「[通道ID] 通道名称」拼接格式。',
    },
    { name: '「代付三方银行」银行名称', def: '该通道对接的实际收款/代付银行名称。' },
    { name: '「代付三方银行」三方Code', def: '该银行在三方支付系统里的编码标识。' },
    { name: '「代付三方银行」最后修改人', def: '最近一次编辑该映射记录的操作人账号。' },
    { name: '「代付三方银行」最后修改时间', def: '最近一次编辑该映射记录的时间。' },
  ],
};

export default manual;
