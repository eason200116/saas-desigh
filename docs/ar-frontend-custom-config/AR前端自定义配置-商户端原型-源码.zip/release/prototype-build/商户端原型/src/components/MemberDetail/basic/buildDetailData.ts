import { currency, formatDateStr, maskEmail, maskPhone, NEW_MARK_ENABLED } from '@/utils';
import { seedCode, getCodeDone, getCodeNeed, getCodePct } from '@/utils/memberCodeProgress';
import { bracketLabel, stateLabel, remarkLabel } from './attributionLabel';

// 代理模式枚举：mock 数据为中文字面量（流水返佣/盈亏返利/未开通），仅在显示处翻译（不改数据源）。
// 复用会员列表已有键 member.user.agentType*，中文态显示原文。
const COMMISSION_MODE_I18N: Record<string, string> = {
  流水返佣: 'member.user.agentTypeExternal',
  盈亏返利: 'member.user.agentTypeInternal',
  未开通: 'member.user.agentTypeNone',
};
export function commissionModeLabel(t: (k: string) => string, raw: any): any {
  if (raw == null || raw === '') return raw;
  const key = COMMISSION_MODE_I18N[String(raw).trim()];
  return key ? t(key) : raw;
}

/**
 * 将 getUserDetail API 响应转换为页面展示数据结构
 * 纯函数，无响应式依赖
 */
export function buildDetailData(
  res: any,
  utils: {
    t: (key: string, params?: Record<string, any>) => string;
    /** 按商户时区格式化时间值 */
    formatTenantDateTime?: (
      value: any,
      tenantId?: any,
      formatStr?: string,
      fallback?: string,
    ) => string;
    /** 根据商户 id / 名称生成统一展示文案 */
    getTenantLabel?: (
      tenantId?: string | number | null,
      tenantName?: string | null,
      fallback?: string,
    ) => string;
    /** 商户时区展示文案，例如 UTC+08:00 */
    tenantTimeZoneLabel?: string;
    /** 查公共字典 label（会员状态用 enableStateList） */
    findLabel?: (key: string, value: string | number | null | undefined) => string;
  },
) {
  const { t, formatTenantDateTime, getTenantLabel, tenantTimeZoneLabel, findLabel } = utils;
  const tzLabel = tenantTimeZoneLabel || '';
  const u = res.userInfo || {};
  // 打码进度（list↔detail 一致）：以会员列表 amountOfCode 为标准（共享 store，按 userId），需要 = 已完成 × 列表系数
  const codeUid = Number(u.userId ?? 0);
  seedCode(codeUid, Number(u.amountofCode ?? 0));
  const codeDone = getCodeDone(codeUid, Number(u.amountofCode ?? 0));
  const codeNeed = getCodeNeed(codeUid, Number(u.amountofCode ?? 0));
  // 【已铺开·2026-07-14 用户确认】原为「仅样板会员 1100002 试点」，验收通过后铺开到全部会员，故恒为 true。
  // 变量名与各处判断保留不动，便于需要时一行收回门控（改回 Number(u.userId) === 1100002 即恢复试点态）。
  // 它统管：一页紧凑布局(basicOnePage) / 会员风控版块 / 数据统计页构建 / 字段搬移(VIP并入·代理+打码相邻·删注册时间·首次登录移位)
  //        / 会员ID黑色 / 用户备注末位铺满省略 / 操作记录入口 等。
  const isSample = true;
  const tenantId = u.tenantId ?? res.tenantId;
  const tenantName = u.tenantName ?? res.tenantName ?? u.merchantName ?? res.merchantName;
  const tenantLabel = getTenantLabel
    ? getTenantLabel(tenantId, tenantName, '--')
    : tenantName || (tenantId ? String(tenantId) : '--');

  // 使用商户时区格式化时间，若 formatTenantDateTime 不可用则降级到 formatDateStr
  const fmtTime = (value: any) =>
    formatTenantDateTime ? formatTenantDateTime(value, tenantId) : formatDateStr(value);
  const loginLogs = res.loginLogList || [];
  const rechargeList = res.rechargeList || [];
  const withdrawList = res.withdrawList || [];
  const financeList = res.financeList || [];

  // 资金账变汇总：按 type 取 financeAmountSum
  const financeSumByType = (type: number): number => {
    const item = financeList.find((f: any) => f?.type === type);
    return item?.financeAmountSum ?? 0;
  };

  // 同设备 / 同指纹计数：仅 1 人时标注「仅本账号」（括号随 locale，中文全角 / 英文半角）
  const onlySelfSuffix = (n: any) => {
    const c = Number(n ?? 0);
    return c <= 1 ? t('member.detail.basic.onlySelfSuffix', { c }) : String(c);
  };

  // 代理关系链（流程图）：1级·总代 → … → 直属上级 → 本会员
  const agentIds: string[] = Array.isArray(u.agentChainIds) ? u.agentChainIds : [];
  const agentChain = agentIds.map((id, i) => {
    const n = i + 1;
    let level: string;
    if (i === 0) level = t('member.detail.basic.chainTopAgent', { n });
    else if (i === agentIds.length - 1)
      level = t('member.detail.basic.chainDirectParentLevel', { n });
    else level = t('member.detail.basic.chainLevelN', { n });
    // levelShort：紧凑模式(样板)顶部只显「N级」(chainLevelN)，完整层级(含总代/直属上级)留悬停
    return { level, levelShort: t('member.detail.basic.chainLevelN', { n }), value: id };
  });
  agentChain.push({
    level: t('member.detail.basic.chainSelfLevel', { n: agentIds.length + 1 }),
    levelShort: t('member.detail.basic.chainLevelN', { n: agentIds.length + 1 }),
    value: String(u.userId ?? '--'),
    kind: 'member' as any,
  });

  const basicSections = [
    {
      key: 'base',
      title: t('member.detail.basic.baseInfo'),
      columns: 4,
      items: [
        {
          label: t('member.detail.basic.memberId'),
          value: String(u.userId ?? '--'),
          // 会员ID 默认蓝色(highlight:'primary')；仅样板 1100002 在下方 isSample 块去蓝改黑(pilot)，其它会员保持原蓝色
          highlight: 'primary',
        },
        {
          label: t('member.detail.basic.merchant'),
          value: tenantLabel,
        },
        {
          label: t('member.detail.basic.account'),
          value: u.userName || '--',
        },
        { label: t('member.detail.basic.nickName'), value: u.nickName || '--' },
        {
          label: t('member.detail.basic.bindEmailPhone'),
          value: u.user_Name2
            ? String(u.user_Name2).includes('@')
              ? maskEmail(u.user_Name2)
              : maskPhone(u.user_Name2)
            : '--',
        },
        { label: t('member.detail.basic.language'), value: u.useLanguage || '--' },
        {
          label: t('member.detail.basic.userBalance'),
          value: currency(u.userAmount),
        },
        {
          // 策略钱包余额（展示字段·商-4）：随本详情既有余额项样式（纯文本），不引入总控端 n-tag 变色
          label: t('member.detail.basic.strategyWallet'),
          value: currency(u.strategyWallet),
        },
        {
          label: t('member.detail.basic.rechargeLevel'),
          value: u.rechargesLeveStr || '--',
        },
        {
          label: t('member.detail.basic.firstLogin'),
          value: fmtTime(u.userLoginDate),
          timeZoneLabel: tzLabel,
        },
        {
          label: t('member.detail.basic.registerTime'),
          value: u.userRegisterTime || fmtTime(u.createTime),
          timeZoneLabel: tzLabel,
        },
        {
          label: t('member.detail.basic.userStatus'),
          // 会员状态走 member.user.enabled/disabled 映射（enableStateList 字典只有中文，英文态会漏中文）
          value: stateLabel(t, findLabel?.('enableStateList', u.userState), u.userState),
          highlight: u.userState === 1 ? 'success' : 'error',
          // 状态改直接开关（R47）：点击 → 二次确认 → 切换启用/禁用 + Toast
          stateSwitch: true,
          _userState: u.userState,
          // 操作记录入口（仅样板 1100002·pilot）：动词取「会员列表」字典（含 启用/禁用）
          ...(isSample
            ? { opLog: { page: '会员列表', item: t('member.detail.basic.userStatus') } }
            : {}),
        },
        {
          // 用户备注（原位置·会员状态后，全局默认形态：不铺满、不省略）
          // 仅样板 1100002 在下方 isSample 块移到版块最下方 + 整行铺满(span4) + 单行省略（pilot）；其它会员保持此原位/原样
          // 后端 remark 为 HTML 编码内容；html 标记让视图层 getSafeHtml 解码消毒；value 留原始编码串供编辑回填、displayValue 为翻译展示值。
          label: t('member.detail.basic.userRemark'),
          value: u.remark || '--',
          displayValue: remarkLabel(t, u.remark) || '--',
          html: true,
          // 2026-07-16 用户要求：用户备注由「红 #dc2626 + 加粗」改回完全默认（去 highlight/highlightBold）；
          // 备注为普通补充文本、红色非语义仅强调 → 同向 R65（非跳转/非状态用默认色）
          actionKey: 'remark',
          actionLabel: t('member.detail.basic.edit'),
          // 操作记录入口（仅样板 1100002·pilot）：动词取「会员列表」字典（含 删除备注）
          ...(isSample
            ? { opLog: { page: '会员列表', item: t('member.detail.basic.userRemark') } }
            : {}),
        },
        {
          // 用户类型：取 userType 字段，与会员列表的会员类型列保持同一映射
          label: t('member.detail.basic.userType'),
          value: (() => {
            const v = Number(u.userType);
            if (v === 1) return t('member.user.userTypeAgent');
            if (v === 2) return t('member.user.userTypeTest');
            return t('member.user.userTypeReal');
          })(),
        },
        {
          // 会员分组：只读展示分组名，值对齐会员列表 userGroupName（普通会员/VIP1/黑名单/代理 等）
          label: t('member.detail.basic.memberGroup'),
          value: u.userGroupName || '--',
        },
        // 用户积分、是否有效字段已按需求删除
      ],
    },
    // 注册信息（归因）：注册字段网格 + 可展开「归因脉络」漏斗（5 步穷举判定，注册时一次性固化）
    {
      key: 'attribution',
      title: t('member.detail.basic.attributionInfo'),
      isNew: NEW_MARK_ENABLED,
      columns: 3,
      items: [
        {
          label: t('member.detail.basic.registerTime'),
          value: u.userRegisterTime || fmtTime(u.createTime),
          timeZoneLabel: tzLabel,
        },
        { label: t('member.detail.basic.registerIp'), value: u.userRegisterIP || '--' },
        {
          label: t('member.detail.basic.registerDevice'),
          value: bracketLabel(t, u.registerClient) || '--',
          isNew: NEW_MARK_ENABLED,
        },
        {
          label: t('member.detail.basic.registerDeviceNo'),
          value: u.registerDeviceId || '--',
          isNew: NEW_MARK_ENABLED,
        },
        {
          // 注册浏览器指纹：复用既有 key，值取 registerBrowserFp
          label: t('member.detail.basic.registerFingerprint'),
          value: u.registerBrowserFp || '--',
          isNew: NEW_MARK_ENABLED,
        },
        {
          label: t('member.detail.basic.registerPackage'),
          value: u.registerPackage || '--',
          isNew: NEW_MARK_ENABLED,
        },
        {
          label: t('member.detail.basic.registerDomain'),
          value: bracketLabel(t, u.registerDomain) || '--',
          isNew: NEW_MARK_ENABLED,
        },
        {
          label: t('member.detail.basic.registerChannel'),
          value: bracketLabel(t, u.registerChannel) || '--',
          isNew: NEW_MARK_ENABLED,
        },
        {
          label: t('member.detail.basic.inviter'),
          value: u.inviter || '--',
          isNew: NEW_MARK_ENABLED,
        },
        {
          // 推广平台名称 → 推广三方类型（Facebook / Adjust / TikTok 等）
          label: t('member.detail.basic.promoThirdType'),
          value: u.promoThirdType || '--',
          isNew: NEW_MARK_ENABLED,
        },
        // 同IP/设备/指纹「注册」计数：样板 1100002 迁入「会员风控」版块；其他会员仍留在此（试点门控，2026-07-11）
        ...(isSample
          ? []
          : [
              {
                label: t('member.detail.basic.sameIpRegisterCount'),
                value: String(u.userRegisterSameIPCount ?? 0),
              },
              {
                label: t('member.detail.basic.sameDeviceRegisterCount'),
                value: onlySelfSuffix(u.sameDeviceRegisterCount),
                isNew: NEW_MARK_ENABLED,
              },
              {
                label: t('member.detail.basic.sameFingerprintRegisterCount'),
                value: String(u.sameFingerprintRegisterCount ?? 0),
              },
            ]),
      ],
      // 归因脉络漏斗（可展开），数据来自 mock attributionFunnel
      funnel: u.attributionFunnel
        ? { title: t('member.detail.basic.funnel.title'), data: u.attributionFunnel }
        : null,
    },
    {
      key: 'stats',
      title: t('member.detail.basic.stats'),
      columns: 3,
      items: [
        {
          label: t('member.detail.basic.todayTotalRecharge'),
          value: `${currency(u.userRechargePriceSum_Today)} / ${currency(u.userRechargePriceSum_All)}`,
        },
        {
          label: t('member.detail.basic.todayTotalWithdraw'),
          value: `${currency(u.userWithdrawPriceSum_Today)} / ${currency(u.userWithdrawPriceSum_All)}`,
        },
        {
          label: t('member.detail.basic.todayTotalDiff'),
          value: `${currency(u.cwDifference_Today)} / ${currency(u.cwDifference_All)}`,
        },
        {
          label: t('member.detail.basic.todayTotalValidBet'),
          value: `${currency(u.validAmount_Today)} / ${currency(u.validAmount_All)}`,
        },
        {
          label: t('member.detail.basic.todayTotalWinLoss'),
          value: `${currency(u.profitAmount_Today)} / ${currency(u.profitAmount_All)}`,
          changed: true,
        },
        {
          label: t('member.detail.basic.todayTotalPromo'),
          value: `${currency(u.activityDiscount_Today)} / ${currency(u.activityDiscount_All)}`,
          changed: true,
        },
      ],
    },
    {
      key: 'activity',
      title: t('member.detail.basic.activityReward'),
      columns: 5,
      items: [
        {
          label: t('member.detail.basic.redPacketReceived'),
          value: currency(u.financeRedEnvelope),
        },
        {
          label: t('member.detail.basic.newbieGift'),
          value: currency(u.financeNewbieGift),
          changed: true,
        },
        {
          label: t('member.detail.basic.luckyWheel'),
          value: currency(u.financeBigWheel),
          changed: true,
        },
        { label: t('member.detail.basic.registerGift'), value: currency(u.financeRegisterBonus) },
        {
          label: t('member.detail.basic.weeklyDailyReward'),
          value: `${currency(u.financeWeeklyAward)} / ${currency(u.financeDailyAward)}`,
        },
        {
          label: t('member.detail.basic.inviteWheelReward'),
          value: currency(u.turntableInviteReward),
        },
        { label: t('member.detail.basic.tgActivity'), value: currency(u.tgActivityAward) },
        {
          // 首充奖励：取 financeList 中 type=14 的 financeAmountSum
          label: t('member.detail.basic.firstRechargeReward'),
          value: currency(financeSumByType(14)),
        },
        {
          label: t('member.detail.basic.superPrize'),
          value: currency(u.financeSuperJackpot),
        },
        {
          label: t('member.detail.basic.agentRedPacketRecharge'),
          value: currency(u.redEnvelope_Recharge),
        },
        {
          label: t('member.detail.basic.returnNewRechargeReward'),
          value: currency(u.returnNewRechargeReward),
        },
        {
          label: t('member.detail.basic.dailySignIn'),
          value: currency(u.financeDailySignIn),
        },
        {
          label: t('member.detail.basic.tournamentReward'),
          value: currency(u.financeTournament),
        },
        {
          label: t('member.detail.basic.newMemberGift'),
          value: currency(u.financeNewMemberGift),
          changed: true,
        },
        { label: t('member.detail.basic.returnReward'), value: currency(u.oldUserReturnAward) },
        // 充值赠送、彩金充值字段已按需求删除
      ],
    },
    // 代理数据：按钮（是否领取返佣 / 是否对上级返佣开关）+ 流程图（代理关系链）+ 可展开「代理明细」
    {
      key: 'agent',
      title: t('member.detail.basic.agentData'),
      isNew: NEW_MARK_ENABLED,
      columns: 3,
      chain: agentChain,
      // 点击代理关系链 → 代理线全链路逐级详情（modal 表格）
      chainHint: t('member.detail.basic.agentLine.viewHint'),
      agentLine: res.userInfo?.agentLineDetail || [],
      items: [],
      collapsible: {
        label: t('member.detail.basic.agentDetail'),
        columns: 3,
        items: [
          {
            label: t('member.detail.basic.firstAgent'),
            value: bracketLabel(t, u.firstAgent) || '--',
          },
          {
            label: t('member.detail.basic.directParentAgent'),
            value: bracketLabel(t, u.directParentAgent) || '--',
          },
          {
            label: t('member.detail.basic.directSubCount'),
            value: String(u.children_1_Total ?? 0),
          },
          {
            label: t('member.detail.basic.teamSubCount'),
            value: String(u.teamSubCount ?? 0),
          },
          { label: t('member.detail.basic.totalCommission'), value: currency(u.financeCommission) },
          { label: t('member.detail.basic.inviteReward'), value: currency(u.agentInviteReward) },
          { label: t('member.detail.basic.partnerReward'), value: currency(u.agentPartnerReward) },
          {
            label: t('member.detail.basic.commissionMode'),
            value: commissionModeLabel(t, u.commissionMode) || '--',
          },
          {
            // 昨日返佣模式：固定返佣 / 动态返佣（保底为动态的子情形，归入动态返佣），置于昨日返佣等级前
            label: t('member.detail.basic.yesterdayRebateMode'),
            value:
              (u.rebateLevelType || '动态') === '固定'
                ? t('member.detail.basic.rebateModeFixed')
                : t('member.detail.basic.rebateModeDynamic'),
          },
          {
            // 昨日返佣等级三态：保底 / 固定 / 动态（原型默认演示动态）。html 渲染带配色升降标识
            label: t('member.detail.basic.yesterdayRebateLevel'),
            html: true,
            value: (() => {
              const type = u.rebateLevelType || '动态';
              const y = String(u.rebateLevelYesterday ?? 'L3');
              const today = String(u.rebateLevelToday ?? 'L4');
              const lvl = (txt: string, color: string) =>
                `<span style="display:inline-block;min-width:30px;text-align:center;padding:0 7px;border-radius:6px;background:${color}1a;color:${color};font-weight:700">${txt}</span>`;
              const dim = (txt: string) =>
                `<span style="color:#94a3b8;font-size:12px">${txt}</span>`;
              const arrow = `<span style="color:#cbd5e1;margin:0 6px">→</span>`;
              // 显示文案走 i18n（中文态原样昨日/今日/保底）；type 仍按 mock 中文值比较，不改数据
              const yesterdayText = t('member.detail.basic.yesterday');
              const todayText = t('member.detail.basic.today');
              if (type === '固定') return lvl(today, '#2563eb');
              if (type === '保底') {
                return `${dim(yesterdayText)} ${lvl(y, '#64748b')} ${arrow} ${dim(todayText)} ${lvl(today, '#2563eb')} <span style="margin-left:6px;padding:0 7px;border-radius:8px;background:#f1f5f9;color:#64748b;font-size:11px;font-weight:600">${t('member.detail.basic.rebateGuaranteed')}</span>`;
              }
              const yn = Number(y.replace(/\D/g, '')) || 0;
              const tn = Number(today.replace(/\D/g, '')) || 0;
              const up = tn >= yn;
              const color = up ? '#16a34a' : '#e0524d';
              const ind = `<span style="margin-left:7px;color:${color};font-weight:700;font-size:13px">${up ? '↑' : '↓'}</span>`;
              return `${dim(yesterdayText)} ${lvl(y, '#64748b')} ${arrow} ${dim(todayText)} ${lvl(today, color)} ${ind}`;
            })(),
          },
          // 是否领取返佣 / 是否对上级返佣：放代理明细最后 2 行（各占整行 span 3），仍是开关（R47）
          {
            label: t('member.detail.basic.rebateStatus'),
            itemSwitch: true,
            switchValue: !!u.isRebate_Bet,
            span: 3,
            // 操作记录入口（仅样板 1100002·pilot）：动词取「会员列表」字典（含 佣金返利开关）
            ...(isSample
              ? { opLog: { page: '会员列表', item: t('member.detail.basic.rebateStatus') } }
              : {}),
          },
          {
            label: t('member.detail.basic.rebateToParent'),
            itemSwitch: true,
            switchValue: !!u.isRebateToParent,
            span: 3,
            // 操作记录入口（仅样板 1100002·pilot）：动词取「会员列表」字典（含 返佣到上级开关）
            ...(isSample
              ? { opLog: { page: '会员列表', item: t('member.detail.basic.rebateToParent') } }
              : {}),
          },
        ],
      },
    },
    {
      key: 'vip',
      title: t('member.detail.basic.vip'),
      columns: 4,
      items: [
        { label: t('member.detail.basic.vipExp'), value: String(u.userVipExperienceId ?? 0) },
        {
          label: t('member.detail.basic.vipLevel'),
          value: String(u.userVipLevelId ?? 0),
        },
        { label: t('member.detail.basic.vipMonthlyReward'), value: currency(u.vipReward_2) },
        { label: t('member.detail.basic.vipUpgradeGift'), value: currency(u.vipReward_1) },
      ],
    },
    {
      key: 'safe-box',
      title: t('member.detail.basic.safeBox'),
      columns: 4,
      items: [
        {
          label: t('member.detail.basic.safeBoxBalance'),
          value: currency(u.safeAmount),
        },
        { label: t('member.detail.basic.claimedEarnings'), value: currency(u.safeTotalEarnings) },
        {
          label: t('member.detail.basic.pendingEarnings'),
          value: currency(u.safeEarnings),
        },
        {
          label: t('member.detail.basic.safeBoxRate'),
          value: u.dayShareRate != null ? `${(u.dayShareRate * 100).toFixed(2)}%` : '--',
        },
      ],
    },
    {
      key: 'betting',
      title: t('member.detail.basic.bettingWashing'),
      columns: 2,
      // 打码进度行（独占一行）：进度 = 已完成打码量 ÷ 需要打码量（已完成≥需要即达标可提现；累计打码量为总流水、不参与）。
      // 「修改」按钮编辑「需要打码量」（editActionKey=requiredBetAmount），改后进度条（详情 + 列表）联动；已完成打码量按列表标准只读。
      progress: (() => {
        const pct = getCodePct(codeDone, codeNeed);
        return {
          pct,
          reached: codeDone >= codeNeed,
          done: currency(codeDone), // X = 已完成打码量（只读，按列表标准）
          need: currency(codeNeed), // Y = 需要打码量（可编辑）
          doneLabel: t('member.detail.basic.betAmount'),
          needLabel: t('member.detail.basic.requiredBetAmount'),
          doneTip: t('member.detail.basic.betAmountTip'),
          needTip: t('member.detail.basic.requiredBetAmountTip'),
          reachedText: t('member.detail.basic.codeReached'),
          unreachedText: t('member.detail.basic.codeUnreached'),
          editActionKey: 'requiredBetAmount',
          editLabel: t('member.detail.basic.edit'),
          // 操作记录入口（仅样板 1100002·pilot）：挂在「修改」按钮右侧，动词取「会员列表」字典
          editOpLog: isSample
            ? { page: '会员列表', item: t('member.detail.basic.requiredBetAmount') }
            : null,
        };
      })(),
      items: [
        {
          label: t('member.detail.basic.totalBetAmount'),
          value: currency(u.allAmountofCode),
          tip: t('member.detail.basic.totalBetAmountTip'),
        },
        {
          label: t('member.detail.basic.currentBetMultiplier'),
          value: String(u.thisCodingAmount ?? 0),
          tip: t('member.detail.basic.currentBetMultiplierTip'),
        },
        {
          label: t('member.detail.basic.rebateAmount'),
          value: currency(u.backWater_Amount),
        },
        { label: t('member.detail.basic.memberWashAmount'), value: currency(u.codeWash_Amount) },
      ],
    },
    // 登录信息（迁移自参考站会员详情，整段新增：当前登录端/设备/域名）
    {
      key: 'loginInfo',
      title: t('member.detail.basic.loginInfo'),
      isNew: NEW_MARK_ENABLED,
      columns: 3,
      items: [
        {
          label: t('member.detail.basic.lastLoginChannel'),
          value: bracketLabel(t, u.loginChannel) || '--',
          isNew: NEW_MARK_ENABLED,
        },
        {
          label: t('member.detail.basic.lastLoginClient'),
          value: bracketLabel(t, u.loginClient) || '--',
        },
        { label: t('member.detail.basic.lastLoginIp'), value: u.loginIp || '--' },
        { label: t('member.detail.basic.lastLoginDeviceNo'), value: u.loginDeviceId || '--' },
        { label: t('member.detail.basic.lastLoginBrowserFp'), value: u.loginFingerprint || '--' },
        {
          label: t('member.detail.basic.lastLoginDomain'),
          value: bracketLabel(t, u.loginDomain) || '--',
        },
        { label: t('member.detail.basic.lastLoginPackage'), value: u.lastLoginPackage || '--' },
        // 同IP/设备/指纹「登录」计数：样板 1100002 迁入「会员风控」版块；其他会员仍留在此（试点门控，2026-07-11）
        ...(isSample
          ? []
          : [
              {
                // 同IP登录数 → 点击跳会员列表（loginIp 下钻）
                label: t('member.detail.basic.sameIpLoginCount'),
                value: String(u.sameIpLoginCount ?? 0),
                jumpQuery: u.loginIp ? { loginIp: u.loginIp } : undefined,
                isNew: NEW_MARK_ENABLED,
              },
              {
                // 同设备登录数 → 点击跳会员列表（loginDevice 下钻）
                label: t('member.detail.basic.sameDeviceLoginCount'),
                value: onlySelfSuffix(u.sameDeviceLoginCount),
                jumpQuery: u.loginDeviceId ? { loginDevice: u.loginDeviceId } : undefined,
              },
              {
                label: t('member.detail.basic.sameFingerprintLoginCount'),
                value: String(u.sameFingerprintLoginCount ?? 0),
              },
            ]),
      ],
    },
    // 最后 3 次登录：独立分区，表头右侧展示「同IP登录数 N 人」
    {
      key: 'last3Login',
      title: t('member.detail.basic.last3LoginInfo'),
      // 同IP登录数合计 → 点击跳会员列表（loginIp 下钻）
      headerNote: t('member.detail.basic.sameIpLoginTotal', { n: u.loginSameIpUserTotal ?? 0 }),
      headerNoteJump: u.loginIp ? { loginIp: u.loginIp } : undefined,
      columns: 12,
      items: [
        // 仅展示最近 3 次登录
        ...loginLogs.slice(0, 3).flatMap((log, i) => [
          {
            label: t('member.detail.basic.lastNthLoginTime', { n: i + 1, d: i === 0 ? '' : '第' }),
            value: log.time || '--',
            timeZoneLabel: log.time ? tzLabel : '',
            stack: true,
            span: 3,
          },
          {
            // IP + 该次登录同登录IP数（同一格右侧挂计数·非独立列·可点下钻风控页 loginIp 维度）
            label: t('member.detail.basic.nthLoginIp', { n: i + 1, d: i === 0 ? '' : '第' }),
            value: log.loginIp || '--',
            span: 3,
            sameCount: {
              label: t('member.detail.basic.sameLoginIpCount'),
              value: String(log.ip_UserID_Count ?? 0),
              jumpPath: '/risk-control/sameIp',
              jumpQuery: { tab: 'loginIp', keyword: log.loginIp || '' },
            },
          },
          {
            label: t('member.detail.basic.nthLoginDevice', { n: i + 1, d: i === 0 ? '' : '第' }),
            value: log.loginDeviceId || '--',
            span: 3,
            sameCount: {
              label: t('member.detail.basic.sameLoginDeviceCount'),
              value: String(log.sameDeviceCount ?? 0),
              jumpPath: '/risk-control/sameIp',
              jumpQuery: { tab: 'loginDevice', keyword: log.loginDeviceId || '' },
            },
          },
          {
            label: t('member.detail.basic.nthLoginFp', { n: i + 1, d: i === 0 ? '' : '第' }),
            value: log.loginFingerprint || '--',
            span: 3,
            sameCount: {
              label: t('member.detail.basic.sameLoginFpCount'),
              value: String(log.sameFpCount ?? 0),
              jumpPath: '/risk-control/sameIp',
              jumpQuery: { tab: 'loginFingerprint', keyword: log.loginFingerprint || '' },
            },
          },
        ]),
        ...(loginLogs.length < 3
          ? Array.from({ length: 3 - loginLogs.length }).flatMap((_, i) => {
              const idx = loginLogs.length + i;
              return [
                {
                  label: t('member.detail.basic.lastNthLoginTime', {
                    n: idx + 1,
                    d: idx === 0 ? '' : '第',
                  }),
                  value: '--',
                  stack: true,
                  span: 3,
                },
                {
                  label: t('member.detail.basic.nthLoginIp', {
                    n: idx + 1,
                    d: idx === 0 ? '' : '第',
                  }),
                  value: '--',
                  span: 3,
                  sameCount: { label: t('member.detail.basic.sameLoginIpCount'), value: '0' },
                },
                {
                  label: t('member.detail.basic.nthLoginDevice', {
                    n: idx + 1,
                    d: idx === 0 ? '' : '第',
                  }),
                  value: '--',
                  span: 3,
                  sameCount: { label: t('member.detail.basic.sameLoginDeviceCount'), value: '0' },
                },
                {
                  label: t('member.detail.basic.nthLoginFp', {
                    n: idx + 1,
                    d: idx === 0 ? '' : '第',
                  }),
                  value: '--',
                  span: 3,
                  sameCount: { label: t('member.detail.basic.sameLoginFpCount'), value: '0' },
                },
              ];
            })
          : []),
      ],
    },
    // 会员风控（仅样板会员 1100002 弹窗输出·试点门控见下方 return 过滤，验收后再铺开到所有会员）：集中「同IP/设备/浏览器指纹」的注册 + 登录聚合计数（原分散在 注册信息 / 登录信息，置于基本信息最末）。
    // 每项可点击 → 先关会员详情弹窗，再跳「风控管理-同IP/设备检查」对应维度 Tab（jumpPath=/risk-control/sameIp，jumpQuery 带 tab 预选 + keyword 预填并查出对应行；样板会员 6 值已对齐风控页 mock）。
    {
      key: 'riskControl',
      title: t('member.detail.basic.riskControl'),
      isNew: NEW_MARK_ENABLED,
      columns: 12,
      items: [
        {
          label: t('member.detail.basic.sameIpRegisterCount'),
          value: String(u.userRegisterSameIPCount ?? 0),
          span: 4,
          jumpPath: '/risk-control/sameIp',
          jumpQuery: { tab: 'registerIp', keyword: u.userRegisterIP || '' },
        },
        {
          label: t('member.detail.basic.sameDeviceRegisterCount'),
          value: onlySelfSuffix(u.sameDeviceRegisterCount),
          span: 4,
          jumpPath: '/risk-control/sameIp',
          jumpQuery: { tab: 'registerDevice', keyword: u.registerDeviceId || '' },
        },
        {
          label: t('member.detail.basic.sameFingerprintRegisterCount'),
          value: String(u.sameFingerprintRegisterCount ?? 0),
          span: 4,
          jumpPath: '/risk-control/sameIp',
          jumpQuery: { tab: 'registerFingerprint', keyword: u.registerBrowserFp || '' },
        },
      ],
    },
  ];

  const depositInfo = [
    {
      label: t('member.detail.depositWithdraw.manualRecharge'),
      value: currency(u.financeManualRecharge),
    },
    {
      label: t('member.detail.depositWithdraw.rechargeGift'),
      value: currency(u.financeRechargeGift),
    },
    {
      label: t('member.detail.depositWithdraw.bonusRecharge'),
      value: currency(u.financeBonusRecharge),
    },
    { spacer: true },
    {
      label: t('member.detail.depositWithdraw.firstDepositDate'),
      value: u.recharge_1_Time || '--',
      timeZoneLabel: u.recharge_1_Time ? tzLabel : '',
    },
    {
      label: t('member.detail.depositWithdraw.firstDepositAmount'),
      value: currency(u.recharge_1_Amount),
      highlight: 'success',
    },
    {
      label: t('member.detail.depositWithdraw.secondDepositDate'),
      value: u.recharge_2_Time || '--',
      timeZoneLabel: u.recharge_2_Time ? tzLabel : '',
    },
    {
      label: t('member.detail.depositWithdraw.secondDepositAmount'),
      value: currency(u.recharge_2_Amount),
      highlight: 'success',
    },
    {
      label: t('member.detail.depositWithdraw.thirdDepositDate'),
      value: u.recharge_3_Time || '--',
      timeZoneLabel: u.recharge_3_Time ? tzLabel : '',
    },
    {
      label: t('member.detail.depositWithdraw.thirdDepositAmount'),
      value: currency(u.recharge_3_Amount),
      highlight: 'success',
    },
  ];

  const withdrawInfo = [
    {
      label: t('member.detail.depositWithdraw.pendingWithdraw'),
      value: currency(u.userWithdrawPriceSum_0),
      highlight: 'warning',
    },
    {
      label: t('member.detail.depositWithdraw.totalWithdrawFee'),
      value: currency(u.userWithdrawCommissionSum_All),
    },
  ];

  // 近3笔充值：只取前 3 条与「近3笔」标签一致（mock rechargeList 长度为 4，原来会多列 1 条）
  const recentDeposits = rechargeList.slice(0, 3).map((r) => ({
    time: r.upTime || '--',
    amount: currency(r.price),
    payTypeId: r.payTypeId ?? null,
    type: r.type || '--',
  }));
  const recentWithdraws = withdrawList.map((w) => ({
    multiple: String(w.thisCodingAmount ?? '--'),
    time: w.upTime || '--',
    amount: currency(w.price),
    withdrawTypeId: w.withdrawTypeId ?? null,
    type: w.type || '--',
  }));

  // —— 步骤B「数据统计」页（仅样板会员 1100002·试点门控，验收后再铺开）——
  // 把「累计统计 / 充提明细(充值+提现) / 活动奖励 / 佣金奖励 / VIP奖励 / 洗码返水」从 基本信息 / 充提信息 抽出，独立成一个 Tab；
  // 原位置同步移走（迁移＝删原位）：stats/activity 整段移走；vip 保留经验/等级、移走 2 项奖励；betting 保留打码进度+累计+倍数、移走反水/洗码；
  // agent 明细移走 3 项佣金；充值+提现整合成「充提明细」版块（DataStatTab 内嵌 DepositWithdrawTab 渲染两卡片）、充提信息 Tab 撤掉。非样板会员 dataStatSections 为空、各字段留原处。
  const vipRewardLabels = [
    t('member.detail.basic.vipMonthlyReward'),
    t('member.detail.basic.vipUpgradeGift'),
  ];
  const washLabels = [
    t('member.detail.basic.rebateAmount'),
    t('member.detail.basic.memberWashAmount'),
  ];
  const commissionLabels = [
    t('member.detail.basic.totalCommission'),
    t('member.detail.basic.partnerReward'),
    t('member.detail.basic.inviteReward'),
  ];
  const dataStatSections: any[] = [];
  if (isSample) {
    const findSec = (k: string) => basicSections.find((s: any) => s.key === k);
    const has = (items: any[], labels: string[]) =>
      (items || []).filter((it: any) => labels.includes(it.label));
    const not = (items: any[], labels: string[]) =>
      (items || []).filter((it: any) => !labels.includes(it.label));
    const activitySec: any = findSec('activity');
    const vipSec: any = findSec('vip');
    const agentSec: any = findSec('agent');
    const bettingSec: any = findSec('betting');
    dataStatSections.push(
      {
        // 今日/累计数据：6 指标做成「项目 / 今日 / 累计」三列列表（原分组柱状图，2026-07-13 改列表——与基本信息一致、一页展示完；DataStatTab 用 DataStatCumulativeList 渲染 n-data-table）。
        // 今日/累计为金额·流水汇总值 → R61 列内居左；充提差/输赢可负，currency 原样带负号。
        key: 'dcCumulative',
        title: t('member.detail.dataStat.cumulative'),
        type: 'cumulativeList',
        cumulative: {
          todayName: t('member.detail.dataStat.chartToday'),
          totalName: t('member.detail.dataStat.chartTotal'),
          rows: [
            {
              item: t('member.detail.dataStat.chartCat.recharge'),
              today: currency(u.userRechargePriceSum_Today),
              total: currency(u.userRechargePriceSum_All),
            },
            {
              item: t('member.detail.dataStat.chartCat.withdraw'),
              today: currency(u.userWithdrawPriceSum_Today),
              total: currency(u.userWithdrawPriceSum_All),
            },
            {
              item: t('member.detail.dataStat.chartCat.diff'),
              today: currency(u.cwDifference_Today),
              total: currency(u.cwDifference_All),
            },
            {
              item: t('member.detail.dataStat.chartCat.validBet'),
              today: currency(u.validAmount_Today),
              total: currency(u.validAmount_All),
            },
            {
              item: t('member.detail.dataStat.chartCat.winLoss'),
              today: currency(u.profitAmount_Today),
              total: currency(u.profitAmount_All),
            },
            {
              item: t('member.detail.dataStat.chartCat.promo'),
              today: currency(u.activityDiscount_Today),
              total: currency(u.activityDiscount_All),
            },
          ],
        },
      },
      // 充提明细：充值 + 提现整合成一个版块（type 标记 → DataStatTab 用样板专用 DataStatDepositWithdraw 干净排版，不复用共用的 DepositWithdrawTab）。
      // 充值构成(人工/充值赠送/彩金) + 首/二/三充(金额·日期合并成一格、不再拆 date/amount 两列) 排 3 列 + 近3笔充值表；提现(待提现/手续费) 2 列 + 近3笔提现表。
      {
        key: 'dcDepositWithdraw',
        title: t('member.detail.dataStat.depositWithdrawDetail'),
        type: 'depositWithdraw',
        dw: {
          rechargeItems: [
            {
              label: t('member.detail.depositWithdraw.manualRecharge'),
              value: currency(u.financeManualRecharge),
            },
            {
              label: t('member.detail.depositWithdraw.rechargeGift'),
              value: currency(u.financeRechargeGift),
            },
            {
              label: t('member.detail.depositWithdraw.bonusRecharge'),
              value: currency(u.financeBonusRecharge),
            },
            {
              // 首充：金额与日期拆两行（日期小字），不再挤一格（2026-07-13 用户要求·上下结构）
              label: t('member.detail.depositWithdraw.firstDepositAmount'),
              value: currency(u.recharge_1_Amount),
              dateNote: u.recharge_1_Time || '--',
              highlight: 'success',
            },
            {
              label: t('member.detail.depositWithdraw.secondDepositAmount'),
              value: currency(u.recharge_2_Amount),
              dateNote: u.recharge_2_Time || '--',
              highlight: 'success',
            },
            {
              label: t('member.detail.depositWithdraw.thirdDepositAmount'),
              value: currency(u.recharge_3_Amount),
              dateNote: u.recharge_3_Time || '--',
              highlight: 'success',
            },
          ],
          withdrawItems: [
            {
              label: t('member.detail.depositWithdraw.pendingWithdraw'),
              value: currency(u.userWithdrawPriceSum_0),
              highlight: 'warning',
            },
            {
              label: t('member.detail.depositWithdraw.totalWithdrawFee'),
              value: currency(u.userWithdrawCommissionSum_All),
            },
          ],
        },
      },
      {
        key: 'dcActivity',
        title: t('member.detail.basic.activityReward'),
        columns: 5,
        items: activitySec ? activitySec.items : [],
      },
      {
        key: 'dcCommission',
        title: t('member.detail.dataStat.commissionReward'),
        columns: 3,
        items: agentSec?.collapsible ? has(agentSec.collapsible.items, commissionLabels) : [],
      },
      {
        key: 'dcVip',
        title: t('member.detail.dataStat.vipReward'),
        columns: 2,
        items: vipSec ? has(vipSec.items, vipRewardLabels) : [],
      },
      {
        key: 'dcWash',
        title: t('member.detail.dataStat.washRebate'),
        columns: 2,
        items: bettingSec ? has(bettingSec.items, washLabels) : [],
      },
    );
    // 原位置剥离（部分字段：vip 留经验/等级、betting 留进度+累计+倍数、agent 明细去 3 佣金）
    if (vipSec) {
      vipSec.items = not(vipSec.items, vipRewardLabels);
      vipSec.columns = 2; // 样板：VIP 只剩经验/等级 2 项，改 2 列平铺（原 4 列 2 项会挤在左半）
    }
    if (bettingSec) bettingSec.items = not(bettingSec.items, washLabels);
    if (bettingSec) bettingSec.title = t('member.detail.basic.codeOnly'); // #1 样板去洗码后标题「打码/洗码」→「打码」
    if (agentSec?.collapsible)
      agentSec.collapsible.items = not(agentSec.collapsible.items, commissionLabels);
    // 「最后3次登录」融入「会员风控」（仅样板·方案3 竖版分组卡片）：3 次登录明细组成卡片——
    // 每次登录一张卡：时间做卡头（红色序号「最后N次登录」+ 时间），IP/设备/指纹为卡内行、各带「同登录X数」可下钻。
    // 不再把 last3Login 扁平项并入 riskSec.items（items 只保留 3 个注册计数）。
    const last3Sec = findSec('last3Login');
    const riskSec = findSec('riskControl');
    if (last3Sec && riskSec) {
      // 会员风控「同X数」计数统一构造（2026-07-16 用户确认）：值 ≤1（含 0，只剩本账号/无记录、无可下钻内容）
      // → 纯数字文本、不挂下钻链接、不带「（仅本账号）」括号；>1 才挂风控页下钻。12 个计数行为一致（R68②）。
      const riskCount = (n: any, label: string, tab: string, keyword: string) => {
        const c = Number(n ?? 0);
        return {
          label,
          value: String(c),
          ...(c > 1 ? { jumpPath: '/risk-control/sameIp', jumpQuery: { tab, keyword } } : {}),
        };
      };
      // 注册风控卡（与最后N次登录卡同构，2026-07-13 用户要求）：卡头 标题+注册时间；
      // 每行 注册IP/设备/指纹的值 + 同X注册数（可下钻风控页对应维度 Tab）
      riskSec.registerCard = {
        title: t('member.detail.basic.registerRisk'),
        time: u.userRegisterTime || fmtTime(u.createTime),
        timeZoneLabel: tzLabel,
        rows: [
          {
            label: t('member.detail.basic.registerIp'),
            value: u.userRegisterIP || '--',
            count: riskCount(
              u.userRegisterSameIPCount,
              t('member.detail.basic.sameIpRegisterCount'),
              'registerIp',
              u.userRegisterIP || '',
            ),
          },
          {
            label: t('member.detail.basic.registerDevice'),
            value: u.registerDeviceId || '--',
            // 2026-07-16 用户确认：原 onlySelfSuffix「（仅本账号）」括号去掉，=1 时纯数字且不可点
            count: riskCount(
              u.sameDeviceRegisterCount,
              t('member.detail.basic.sameDeviceRegisterCount'),
              'registerDevice',
              u.registerDeviceId || '',
            ),
          },
          {
            label: t('member.detail.basic.registerFpShort'),
            value: u.registerBrowserFp || '--',
            count: riskCount(
              u.sameFingerprintRegisterCount,
              t('member.detail.basic.sameFingerprintRegisterCount'),
              'registerFingerprint',
              u.registerBrowserFp || '',
            ),
          },
        ],
      };
      riskSec.items = []; // 注册计数已并入 registerCard.rows，原网格不再单独渲染
      // 「最后3次登录信息」小标题已删（2026-07-13 用户要求）；3 次登录明细仍组成卡片（方案3 竖版分组卡片）
      riskSec.loginGroups = [0, 1, 2].map((i) => {
        const log: any = loginLogs[i] || {};
        return {
          seq: t('member.detail.basic.lastNthLogin', { n: i + 1, d: i === 0 ? '' : '第' }),
          time: log.time || '--',
          timeZoneLabel: log.time ? tzLabel : '',
          rows: [
            {
              label: t('member.detail.basic.loginIpShort'),
              value: log.loginIp || '--',
              count: riskCount(
                log.ip_UserID_Count,
                t('member.detail.basic.sameLoginIpCount'),
                'loginIp',
                log.loginIp || '',
              ),
            },
            {
              label: t('member.detail.basic.loginDeviceShort'),
              value: log.loginDeviceId || '--',
              count: riskCount(
                log.sameDeviceCount,
                t('member.detail.basic.sameLoginDeviceCount'),
                'loginDevice',
                log.loginDeviceId || '',
              ),
            },
            {
              label: t('member.detail.basic.loginFpShort'),
              value: log.loginFingerprint || '--',
              count: riskCount(
                log.sameFpCount,
                t('member.detail.basic.sameLoginFpCount'),
                'loginFingerprint',
                log.loginFingerprint || '',
              ),
            },
          ],
        };
      });
    }
    // 登录信息版块移到「注册信息（attribution）」下方（仅样板）
    const loginIdx = basicSections.findIndex((s: any) => s.key === 'loginInfo');
    if (loginIdx >= 0) {
      const [movedLogin] = basicSections.splice(loginIdx, 1);
      const attrIdx = basicSections.findIndex((s: any) => s.key === 'attribution');
      basicSections.splice(attrIdx >= 0 ? attrIdx + 1 : 0, 0, movedLogin);
    }
    // ===== 样板 1100002 · 基本信息字段搬移（本轮：#4删注册时间 / #5移首次登录 / #2并VIP撤版块 / #3代理+打码相邻）=====
    const baseSec = findSec('base');
    // #4 基本信息删除「注册时间」（注册信息·归因里仍保留）
    if (baseSec)
      baseSec.items = baseSec.items.filter(
        (it: any) => it.label !== t('member.detail.basic.registerTime'),
      );
    // #5 「首次登录」从基本信息移到「登录信息」顶部——置于「上次登录渠道」上方（2026-07-13 用户要求，由末尾追加改头部前插）
    if (baseSec) {
      const fiIdx = baseSec.items.findIndex(
        (it: any) => it.label === t('member.detail.basic.firstLogin'),
      );
      if (fiIdx >= 0) {
        const [fl] = baseSec.items.splice(fiIdx, 1);
        const loginSec = findSec('loginInfo');
        if (loginSec) loginSec.items = [fl, ...loginSec.items];
      }
    }
    // #2 VIP 基础内容(经验值/等级)并入「基本信息」、撤掉独立 VIP 版块
    if (baseSec && vipSec) {
      baseSec.items = [...baseSec.items, ...vipSec.items];
      const vi = basicSections.findIndex((s: any) => s.key === 'vip');
      if (vi >= 0) basicSections.splice(vi, 1);
    }
    // #6 (pilot·仅样板) 会员ID 去蓝改黑：不可点击、避免误认为链接；其它会员保持默认蓝(highlight:'primary')
    if (baseSec) {
      const midItem = baseSec.items.find(
        (it: any) => it.label === t('member.detail.basic.memberId'),
      );
      if (midItem) delete midItem.highlight;
    }
    // #7 (pilot·仅样板) 用户备注移到基本信息最下方 + 整行铺满(span4) + 单行省略；其它会员保持原位(会员状态后)/原样
    if (baseSec) {
      const rIdx = baseSec.items.findIndex(
        (it: any) => it.label === t('member.detail.basic.userRemark'),
      );
      if (rIdx >= 0) {
        const [rm] = baseSec.items.splice(rIdx, 1);
        rm.span = 4;
        rm.ellipsis = true;
        baseSec.items.push(rm);
      }
    }
    // #3 「代理数据」+「打码/洗码」相邻 → masonry 叠成同一列
    {
      const bIdx = basicSections.findIndex((s: any) => s.key === 'betting');
      const aIdx = basicSections.findIndex((s: any) => s.key === 'agent');
      if (bIdx >= 0 && aIdx >= 0 && bIdx !== aIdx + 1) {
        const [bSec] = basicSections.splice(bIdx, 1);
        const na = basicSections.findIndex((s: any) => s.key === 'agent');
        basicSections.splice(na + 1, 0, bSec);
      }
      if (agentSec) agentSec.groupNext = true; // 代理 break-after:avoid → 打码/洗码 与其同列(#3)
    }
    // ===== 4 列显式分组（仅样板）：①基本+保险箱 ②注册+登录 ③代理+打码 ④风控竖版 =====
    const attrSec: any = findSec('attribution');
    {
      // 保险箱移到基本信息正下方（同列）
      const sbIdx = basicSections.findIndex((s: any) => s.key === 'safe-box');
      const b0 = basicSections.findIndex((s: any) => s.key === 'base');
      if (sbIdx >= 0 && b0 >= 0 && sbIdx !== b0 + 1) {
        const [sb] = basicSections.splice(sbIdx, 1);
        const nb = basicSections.findIndex((s: any) => s.key === 'base');
        basicSections.splice(nb + 1, 0, sb);
      }
    }
    if (baseSec) baseSec.groupNext = true; // 基本→保险箱 同列
    if (attrSec) attrSec.groupNext = true; // 注册→登录 同列
    // 「合并信息」已撤销(照目标图·数值字段保持原样分开)：base 注册/首登、VIP 等级/经验、VIP/保险箱 均恢复为独立字段/版块。
    // 「一页看完·竖版自适应」(仅样板 1100002)：所有版块(含会员风控)统一上下结构(标题在上/数值在下) + 按宽度自适应列数；
    // 风控原本的注册计数/登录 span 由 CSS grid-column:auto 归一成 1 列、也走竖版。不再排除任何版块。
    const ONEPAGE_WIDE = new Set<string>([]); // #4 风控改竖版列、不再通栏
    basicSections.forEach((s: any) => {
      if (ONEPAGE_WIDE.has(s.key)) s.wide = true;
    });
  }

  return {
    // 「一页看完」布局门控：仅样板 1100002 的基础信息走多列紧凑重排，其他会员原样竖排（试点·验收后再铺开）
    basicOnePage: isSample,
    // 样板 1100002：会员风控保留、stats/activity 整段移走（已入数据统计）；非样板：过滤掉 riskControl、其余原样
    basicSections: basicSections.filter((s: any) => {
      if (s.key === 'riskControl') return isSample;
      if ((s.key === 'stats' || s.key === 'activity') && isSample) return false;
      // 最后3次登录已并入会员风控（样板），撤掉独立分区
      if (s.key === 'last3Login' && isSample) return false;
      return true;
    }),
    dataStatSections,
    // 样板：充值/提现整合成「充提明细」版块放进数据统计（DataStatTab 复用 DepositWithdrawTab 渲染），充提信息 Tab 撤掉；
    // depositInfo/withdrawInfo/近3笔 保持原样供该版块渲染。非样板：仍在充提信息 Tab、原样。
    depositInfo,
    withdrawInfo,
    recentDeposits,
    recentWithdraws,
    walletSections: [],
  };
}
