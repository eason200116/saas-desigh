<script setup lang="ts">
  import { computed } from 'vue';
  import { useI18n } from 'vue-i18n';

  const props = withDefaults(
    defineProps<{
      show: boolean;
    }>(),
    {
      show: false,
    },
  );

  const emit = defineEmits<{
    (e: 'update:show', value: boolean): void;
    (e: 'download'): void;
  }>();

  const { t } = useI18n();

  const visible = computed({
    get: () => props.show,
    set: (val) => emit('update:show', val),
  });

  const handleDownload = () => {
    emit('download');
    visible.value = false;
  };
</script>

<template>
  <n-modal v-model:show="visible" preset="dialog" :title="t('components.batchTemplateModal.title')">
    <div class="py-4">
      <n-button type="primary" @click="handleDownload">
        {{ t('components.batchTemplateModal.download') }}
      </n-button>
    </div>
  </n-modal>
</template>
