<template>
  <div class="setting-config" :style="gridStyle">
    <template v-for="item in items" :key="item.key">
      <!-- 标签 -->
      <button
        :ref="(el) => setLabelRef(item.key, el)"
        class="setting-label"
        type="button"
        @click="handleLogToggle(true, item.key)"
      >
        {{ item.label }}
      </button>

      <!-- 控件 -->
      <div class="setting-control">
        <SettingSwitch
          v-if="item.type === 'switch'"
          :value="getDisplayValue(item.key)"
          @confirm="(v: number) => handleConfirm(item.key, v)"
        />
        <template v-else-if="item.type === 'number'">
          <SettingNumber
            :value="getDisplayValue(item.key)"
            :suffix="item.suffix"
            :rules="item.rules"
            :props="item.props"
            @confirm="(v: number) => handleConfirm(item.key, v)"
          />
          <span v-if="item.unit" class="setting-unit">{{ item.unit }}</span>
        </template>
        <template v-else-if="item.type === 'range'">
          <SettingRange
            :value1="getRangeValue(item.key, 0)"
            :value2="getRangeValue(item.key, 1)"
            :suffix="item.suffix"
            :rules="item.rules"
            @confirm="(v1: number, v2: number) => handleRangeConfirm(item.key, v1, v2)"
          />
          <span v-if="item.unit" class="setting-unit">{{ item.unit }}</span>
        </template>
      </div>

      <!-- 描述 -->
      <n-tooltip v-if="item.desc" trigger="hover">
        <template #trigger>
          <n-icon class="setting-tip" :size="16">
            <QuestionCircleOutlined />
          </n-icon>
        </template>
        {{ item.desc }}
      </n-tooltip>
      <span v-else />
    </template>

    <!-- 单例日志弹窗 -->
    <n-popover
      :show="!!activeLog"
      trigger="manual"
      placement="bottom-start"
      :x="popoverPos.x"
      :y="popoverPos.y"
      @clickoutside="activeLog = null"
    >
      <n-data-table
        :columns="logColumns"
        :data="logData"
        :loading="logLoading"
        :pagination="false"
        :max-height="300"
        size="small"
        class="setting-log-table"
      />
    </n-popover>
  </div>
</template>

<script setup lang="ts">
  import { shallowRef, markRaw, onMounted, computed } from 'vue';
  import { useI18n } from 'vue-i18n';
  import { useMessage } from 'naive-ui';
  import { QuestionCircleOutlined } from '@vicons/antd';
  import { formatToCurrentZone } from '@/utils';
  import { api } from './data';
  import SettingSwitch from './controls/SettingSwitch.vue';
  import SettingNumber from './controls/SettingNumber.vue';
  import SettingRange from './controls/SettingRange.vue';
  import type {
    SettingItemConfig,
    SettingValue,
    SettingLogRecord,
    SettingApiConfig,
  } from './types';

  // ========== Props ==========
  const props = withDefaults(
    defineProps<{
      items: SettingItemConfig[];
      api: SettingApiConfig;
      modelValue?: Record<string, SettingValue>;
      autoLoad?: boolean;
      columns?: 1 | 2 | 3;
    }>(),
    {
      autoLoad: true,
      columns: 1,
    },
  );

  // ========== Emits ==========
  const emit = defineEmits<{
    (e: 'update:modelValue', value: Record<string, SettingValue>): void;
    (e: 'change', key: string, value: unknown): void;
    (e: 'loaded', data: Record<string, SettingValue>): void;
  }>();

  // ========== Composables ==========
  const { t } = useI18n();
  const message = useMessage();
  // ========== State ==========
  const formData = shallowRef<Record<string, SettingValue>>({});
  const activeLog = shallowRef<string | null>(null);
  const logData = shallowRef<SettingLogRecord[]>([]);
  const logLoading = shallowRef(false);
  const labelRefs: Record<string, HTMLElement | null> = {};
  const popoverPos = shallowRef({ x: 0, y: 0 });

  // ========== Computed ==========
  const gridStyle = computed(() => {
    const cols = props.columns;
    // 每个配置项占 3 列：标签、控件、描述
    return {
      gridTemplateColumns: `repeat(${cols}, auto auto 1fr)`,
    };
  });

  // ========== 日志列 ==========
  const logColumns = markRaw([
    {
      title: t('common.operationTime'),
      key: 'updateTime',
      width: 160,
      align: 'center' as const,
      render: (row: SettingLogRecord) => formatToCurrentZone(row.updateTime),
    },
    {
      title: t('common.operator'),
      key: 'operatorName',
      width: 100,
      align: 'center' as const,
    },
    {
      title: t('common.configValue'),
      key: 'updateContent',
      width: 120,
      align: 'center' as const,
    },
  ]);

  // ========== Methods ==========
  const getData = () => props.modelValue ?? formData.value;

  const getDisplayValue = (key: string): number | string => {
    return getData()[key]?.value1 ?? 0;
  };

  const getRangeValue = (key: string, index: number): number => {
    const item = getData()[key];
    return Number(index === 0 ? item?.value1 : item?.value2) || 0;
  };

  const setLabelRef = (key: string, el: unknown) => {
    labelRefs[key] = el as HTMLElement;
  };

  // 默认日志 API
  const defaultLogApi = (params: { settingKey: string }) => {
    return api.operations.getListUpdateLog(params as any);
  };

  const handleLogToggle = async (show: boolean, key: string) => {
    if (!show) {
      activeLog.value = null;
      return;
    }

    const el = labelRefs[key];
    if (el) {
      const rect = el.getBoundingClientRect();
      popoverPos.value = { x: rect.left, y: rect.bottom + 4 };
    }

    activeLog.value = key;
    logLoading.value = true;
    try {
      const logApi = props.api.log || defaultLogApi;
      const { data } = await logApi({ settingKey: key });
      logData.value = (data ?? []) as SettingLogRecord[];
    } catch {
      logData.value = [];
    } finally {
      logLoading.value = false;
    }
  };

  const handleConfirm = async (key: string, value: number | string) => {
    const data = getData();
    const item = data[key];
    if (!item) return;

    try {
      const { code } = await props.api.update({
        settingKey: item.settingKey || key,
        value1: String(value),
        value2: '',
      });

      if (code === 0) {
        message.success(t('common.operationSuccess'));
        const newData = { ...getData(), [key]: { ...item, value1: value } };

        if (props.modelValue) {
          emit('update:modelValue', newData);
        } else {
          formData.value = newData;
        }
        emit('change', key, value);
      }
    } catch (e) {
      console.error('Update failed:', e);
    }
  };

  const handleRangeConfirm = async (key: string, v1: number, v2: number) => {
    const data = getData();
    const item = data[key];
    if (!item) return;

    try {
      const { code } = await props.api.update({
        settingKey: item.settingKey || key,
        value1: String(v1),
        value2: String(v2),
      });

      if (code === 0) {
        message.success(t('common.operationSuccess'));
        const newData = { ...getData(), [key]: { ...item, value1: v1, value2: v2 } };

        if (props.modelValue) {
          emit('update:modelValue', newData);
        } else {
          formData.value = newData;
        }
        emit('change', key, [v1, v2]);
      }
    } catch (e) {
      console.error('Update failed:', e);
    }
  };

  const loadData = async () => {
    try {
      const { data } = await props.api.get();
      const transformed: Record<string, SettingValue> = {};

      if (data) {
        Object.keys(data).forEach((k) => {
          const item = data[k];
          if (item?.settingKey) {
            transformed[item.settingKey] = item;
          } else {
            transformed[k] = item;
          }
        });
      }

      if (props.modelValue) {
        emit('update:modelValue', transformed);
      } else {
        formData.value = transformed;
      }
      emit('loaded', transformed);
    } catch (e) {
      console.error('Load failed:', e);
    }
  };

  const reload = () => loadData();
  const getFormData = () => getData();

  // ========== Lifecycle ==========
  onMounted(() => {
    if (props.autoLoad && !props.modelValue) {
      loadData();
    }
  });

  // ========== Expose ==========
  defineExpose({ reload, getFormData });
</script>

<style scoped>
  .setting-config {
    display: grid;
    gap: 12px 16px;
    align-items: center;
  }

  .setting-label {
    color: #2080f0;
    background: none;
    border: none;
    cursor: pointer;
    padding: 4px 0;
    font-size: 14px;
    white-space: nowrap;
    text-align: left;
  }

  .setting-label:hover {
    text-decoration: underline;
  }

  .setting-control {
    display: flex;
    align-items: center;
    gap: 4px;
    min-width: 80px;
  }

  .setting-unit {
    color: #666;
    font-size: 13px;
  }

  .setting-tip {
    color: #2080f0;
    cursor: pointer;
  }

  .setting-log-table {
    width: 420px;
  }
</style>
