<template>
  <div class="tableAction">
    <n-space size="small" justify="center">
      <span v-if="showNoPermissionText" class="tableAction__empty">
        {{ $t('components.tableAction.noPermissionOperate') }}
      </span>
      <template v-for="(action, index) in getActions" :key="`${index}-${action.label}`">
        <n-button
          v-if="action.action !== 'delete'"
          class="mx-1"
          size="small"
          :text="actionText"
          :type="action.type"
          :color="action.color"
          :disabled="action.disabled"
          @click="action.onClick?.()"
        >
          {{ action.label }}
          <template #icon v-if="action.icon">
            <n-icon :component="action.icon" />
          </template>
        </n-button>
        <Popconfirm v-else v-bind="action" />
      </template>
      <n-dropdown
        v-if="dropDownActions && getDropdownList.length"
        trigger="hover"
        :options="getDropdownList"
        @select="onSelect"
      >
        <slot name="more"></slot>
        <n-button v-bind="getMoreProps" class="mx-1" v-if="!$slots.more" icon-placement="right">
          <div class="flex items-center">
            <span>{{ $t('common.more') }}</span>
            <n-icon size="14" class="ml-1">
              <DownOutlined />
            </n-icon>
          </div>
        </n-button>
      </n-dropdown>
    </n-space>
  </div>
</template>

<script lang="ts">
  import { defineComponent, PropType, computed, toRaw } from 'vue';
  import type { ButtonProps, DropdownOption } from 'naive-ui';
  import { ActionItem } from '../types/tableAction';
  import Popconfirm from './Popconfirm.vue';
  import { usePermission } from '@/hooks/web/usePermission';
  import { isBoolean, isFunction } from '@/utils/is';
  import { DownOutlined } from '@vicons/antd';

  export default defineComponent({
    name: 'TableAction',
    components: { DownOutlined, Popconfirm },
    props: {
      actions: {
        type: Array as PropType<ActionItem[]>,
        default: null,
        required: true,
      },
      dropDownActions: {
        type: Array as PropType<ActionItem[]>,
        default: null,
      },
      style: {
        type: String as PropType<string>,
        default: 'text',
      },
      select: {
        type: Function as PropType<Function>,
        default: () => {},
      },
    },
    setup(props) {
      const { hasPermission } = usePermission();
      const actionType: ButtonProps['type'] =
        props.style === 'button' ? 'default' : props.style === 'text' ? 'primary' : 'default';
      const actionText: ButtonProps['text'] =
        props.style === 'button' ? undefined : props.style === 'text' ? true : undefined;

      const getMoreProps = computed<Pick<ButtonProps, 'size' | 'text' | 'type'>>(() => {
        return {
          text: actionText,
          type: actionType,
          size: 'small',
        };
      });

      const getDropdownList = computed<DropdownOption[]>(() => {
        return (toRaw(props.dropDownActions) || [])
          .filter((action) => {
            return hasPermission(action.auth as string[]) && isIfShow(action);
          })
          .map((action) => {
            return {
              key: action.key ?? action.label ?? '',
              label: action.label,
              disabled: action.disabled,
            };
          });
      });

      function isIfShow(action: ActionItem): boolean {
        const ifShow = action.ifShow;

        let isIfShow = true;

        if (isBoolean(ifShow)) {
          isIfShow = ifShow;
        }
        if (isFunction(ifShow)) {
          isIfShow = ifShow(action);
        }
        return isIfShow;
      }

      const getActions = computed(() => {
        return (toRaw(props.actions) || [])
          .filter((action) => {
            return hasPermission(action.auth as string[]) && isIfShow(action);
          })
          .map((action) => {
            const { popConfirm } = action;
            return {
              size: 'small',
              text: actionText,
              type: actionType,
              ...action,
              ...popConfirm,
              onConfirm: popConfirm?.confirm || action.onClick,
              onCancel: popConfirm?.cancel,
              enable: !!popConfirm,
            };
          });
      });

      const showNoPermissionText = computed(() => {
        return getActions.value.length === 0 && getDropdownList.value.length === 0;
      });

      const onSelect = (key: string) => {
        const item = props.dropDownActions?.find((item) => item.key === key);
        if (item && item.onClick) {
          item.onClick();
        } else {
          props.select(key);
        }
      };

      return {
        getActions,
        getDropdownList,
        getMoreProps,
        actionText,
        showNoPermissionText,
        onSelect,
      };
    },
  });
</script>

<style lang="less" scoped>
  .tableAction__empty {
    color: #909399;
    display: inline-block;
    font-size: 12px;
    line-height: 18px;
    max-width: 100%;
    white-space: normal;
  }
</style>
