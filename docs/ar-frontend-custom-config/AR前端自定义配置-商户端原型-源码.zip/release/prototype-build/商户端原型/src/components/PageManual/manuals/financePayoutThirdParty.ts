// 三方代付（商户端 tenant · finance_merchant_payout_third_party_page）功能说明书。
// 锚定 src/views/finance/payoutThirdParty/index.vue + components/ThirdPartyMerchantTab.vue +
// components/{ThirdPartyMerchantEditModal,MerchantUsageDetailModal}.vue + components/data.ts +
// components/thirdPartyMerchantTabCache.ts + merchantUsageTypes.ts 真实控件（R53 实证、不臆造）。
// index.vue 当前只挂了一个 Tab（ThirdPartyMerchantTab，支代付三方商户管理）；同目录下的
// ChannelAlertTab.vue + channelAlertPrototype.ts（支代付通道预警，i18n 文案已备好 tabs.payoutThirdParty.channelAlert）
// 是已写好但当前未挂入 index.vue 的孤儿 Tab（channelAlertPrototype.ts 文件头注释自己写明"当前未挂入路由，
// 仅供 ChannelAlertTab 本地演示"），如实记录，本说明书不为其编写条目（页面上看不到这个 Tab）。
//
// ⚠️⚠️ 核实代码后发现两个独立的真实 bug（均只如实记录、未在本次任务中修复）：
// 【Bug A】thirdPartyMerchantTabCache.ts 调用的 api.recharge.getPayCodeSelectData /
// api.recharge.getThirdPayMerchantSelectData 两个方法，在本页 mock（components/data.ts 导出的
// api.recharge，一个普通对象字面量，不是 src/api/index.ts 那种兜底 Proxy）里从未实现，调用会直接
// TypeError: xxx is not a function。影响：①页面一进入即因 initializeSearchSelectData() 报错，
// Promise.all 整体 reject，弹「筛选下拉数据加载失败，请稍后重试」，搜索区「币种/三方映射码/
// 三方商户昵称」三个下拉从进页面起选项恒空、且没有任何交互能救回来；②「新增三方商户」弹窗内选完
// 币种后「三方映射码」下拉永远查不到选项，而映射码是必填项，新增流程实际无法真正提交成功。
// 【Bug B】mock（components/data.ts 的 MERCHANT_LIST）用的是扁平字段名
// （currency/mappingCode/name/merchantNo/thirdBalance/associatedMerchants(纯字符串数组)/
// creator/updatedBy/state 等），但 ThirdPartyMerchantTab.vue 的 mapMerchantRow / createEditorData /
// buildRequestParams 读写的是另一套命名（sysCurrency/payCode/customName/merchantCode/balance/
// thirdPayMerchantRelationList/lastUpdateMan/lastUpdateTime），像是照真实 V1 后端契约写的，
// 但本页本地 mock 从未切换成这套命名——两边对不上。影响见下方对应列/字段条目的 edge。

import type { PageManual } from '../types';

const manual: PageManual = {
  route: 'finance_merchant_payout_third_party_page',
  title: '三方代付',
  overview:
    '商户端「财务管理 › 三方代付」页（仅商户端 roles:[\'tenant\']），单表 ProCrudTable：维护"三方代付商户"档案（映射码/密钥、关联哪些站点收付款通道在用它、余额、启停）。页面目前只有一个功能区（无 Tab 切换器），点表格「关联商户」文字可查看该三方商户被哪些站点的哪些收/付款通道关联使用的只读明细。⚠️ 核实代码后发现两个独立的真实 bug（详见下方各条 edge，均未修复）：①`thirdPartyMerchantTabCache.ts` 里两个下拉联动方法在本页 mock 里从未实现，导致进页面就弹报错提示、3 个搜索下拉恒空、新增流程因映射码永远选不出而无法真正提交；②`mapMerchantRow` 等函数读取的字段名和本页 mock 实际字段名对不上，导致列表 6 列恒显示"--"/"-"、关联商户列恒空（其详情弹窗因此在正常操作下摸不到入口）、多个搜索过滤条件形同虚设或一用就把结果清零、编辑弹窗回填商户昵称/商户号为空且大概率无法保存成功。',
  items: [
    // ============ 搜索区 ============
    {
      anchor: 'currency',
      name: '币种',
      group: '搜索',
      interaction: '下拉单选（NSelect，可清空、可搜索）。',
      dataSource:
        '页面挂载时由 initializeSearchSelectData() 请求查询用接口 GetThirdPayMerchantSelectData（经 requestSearchMappingCodeSelectData → requestThirdPayMerchantSelectDataWithCache 共享缓存）得到；与「新增/编辑弹窗」里币种选项来源不同接口（弹窗走 getSysCurrencySelectData，两边各自维护一份 ref，非共享同一份数据）。',
      logic:
        '选中后清空「三方映射码」「三方商户昵称/商户号」两项当前值，并按新币种重新请求映射码下拉（handleSearchCurrencyChange）；查询时按 sysCurrency 精确过滤列表。',
      limit: '选填，可清空。',
      edge:
        '⚠️【Bug A】核实代码后发现：requestThirdPayMerchantSelectDataWithCache 调用的 api.recharge.getThirdPayMerchantSelectData 在本页 mock（components/data.ts）里从未实现（该 mock 是普通对象字面量，不是 src/api/index.ts 那种兜底 Proxy，调用不存在的方法直接抛 TypeError: xxx is not a function）。因此 initializeSearchSelectData() 在 onMounted 阶段必抛错，Promise.all 整体 reject，页面一进入就会弹「筛选下拉数据加载失败，请稍后重试」提示；本下拉从进入页面起选项永远为空，之后无论 reset 还是联动切换都会重新触发同一条报错链路，救不回来。⚠️【Bug B】即使数据链路通了，服务端过滤也对不上：buildRequestParams 往接口发的键是 sysCurrency，但 mock 端 filterAndPaginate 实际读取的是 req.currency——两边键名不一致，选中币种查询等于没选。如实记录，均非本次引入，不修复。',
    },
    {
      anchor: 'mappingCode',
      name: '三方映射码',
      group: '搜索',
      interaction:
        '下拉单选（NSelect，可清空、可搜索），带 loading 态；下拉展开时若当前选项为空会按需重新请求（onUpdateShow 懒加载设计）。',
      dataSource:
        '同「币种」，走查询用接口 GetThirdPayMerchantSelectData（经 requestSearchMappingCodeSelectData 复用页面级缓存），按当前是否已选币种决定是否带 sysCurrency 过滤。',
      logic:
        '选中后清空「三方商户昵称/商户号」当前值，并按当前 币种+映射码 重新请求商户昵称下拉（handleSearchMappingCodeChange）；查询时按 payCode 精确过滤列表。',
      limit: '选填，可清空；未选币种时展示全量映射码，不会因未选币种而禁用。',
      edge:
        '⚠️【Bug A】与「币种」同一根因（api.recharge.getThirdPayMerchantSelectData 未实现），本下拉在页面生命周期内恒为空选项、不可用。⚠️【Bug B】buildRequestParams 发的键是 payCode，mock filterAndPaginate 读取的是 req.mappingCode，即便下拉能选出值，服务端过滤也不会生效。如实记录，不修复。',
    },
    {
      anchor: 'customName',
      name: '三方商户昵称/商户号',
      group: '搜索',
      interaction:
        '下拉单选（NSelect，可清空、可搜索），dependencies:[\'mappingCode\']（映射码变化会重新求值本列渲染）；下拉展开时若选项为空会按需重新请求。看起来像自由关键词搜索框，实际是"只能选已有候选值"的闭合下拉，不能输入不在候选里的字符串。',
      dataSource: '同上查询接口按 当前币种+映射码 过滤后的 customNames 去重列表。',
      logic: '查询时按 customName 精确过滤列表。',
      limit: '选填，可清空。',
      edge:
        '⚠️【Bug A】与「币种」同一根因，本下拉恒为空、不可用。另：i18n 里还留有一个未被本字段引用的占位 key placeholders.enterMerchantKeyword（"请输入三方商户昵称/商户号"）——本字段实际渲染用的是 common.select_placeholder 拼出的"请选择..."文案，命名/实现不完全对应，如实记录，非本次引入。',
    },
    {
      anchor: 'associatedMerchants',
      name: '关联商户',
      group: '搜索',
      interaction: '下拉多选（NSelect multiple:true，可清空、可搜索）。',
      dataSource:
        'loadMerchantOptions()（onMounted 触发）调用 api.tenant.tenantGetSelectList({})，按"名称（id）"格式拼装成 options（如"daman（1050）"）；该接口本页 mock 已正确实现，下拉选项本身能正常加载。',
      logic:
        '查询时把选中的多个商户名映射回 tenantId 集合（normalizeAssociatedMerchantIds），按行数据 associatedMerchantIds 是否有交集过滤（client-side 补充过滤，见 filterMerchantRows）。',
      limit: '选填，可清空，可多选。',
      edge:
        '⚠️【Bug B】下拉选项本身能加载，但一旦真的选中任意商户去查询，结果必为 0 条：filterMerchantRows 拿行数据 row.associatedMerchantIds 做交集判断，而 mapMerchantRow 里这个字段来自 item.thirdPayMerchantRelationList（mock 没有这个字段，恒为空数组），空数组和任何选择都不会有交集，所以只要用了这个筛选就会把结果清零。如实记录，不修复。',
    },
    {
      anchor: 'status',
      name: '状态',
      group: '搜索',
      interaction: '下拉单选（valueType:\'select\' 声明式写法，非自定义 render），可清空。',
      dataSource: '固定 2 项：启用/禁用（本地常量 statusOptions）。',
      logic: '查询时按 state 精确过滤（normalizeStateFilter 归一化 1/0）。',
      limit: '选填，可清空。',
      note: '本页 6 个搜索项里，「状态」是唯一一个服务端过滤键名双边（buildRequestParams 发 state、mock filterAndPaginate 读 req.state）完全对齐、能真正按条件筛出结果的字段。',
    },
    {
      anchor: 'balanceRangeMin',
      name: '三方余额区间',
      group: '搜索',
      interaction:
        '数字区间输入（两个 NInputNumber 用"~"拼成一组，precision:0、隐藏步进箭头），起止值合法性即时校验。',
      dataSource: '用户输入。',
      logic:
        '查询时按 balanceRangeMin/balanceRangeMax 转数字后过滤（client-side：parseBalanceAmount 解析行内 thirdBalance 字符串做比较，见 filterMerchantRows）。',
      limit:
        '最小值不能大于最大值，否则两个输入框都标红（status:\'error\'）并在下方出现红字提示"最小不能大于最大"（isThirdBalanceRangeInvalid）；范围 -9999999999~9999999999，仅整数（precision:0）。',
      edge:
        '非法区间时点查询会被前端直接拦截（loadDataTable 顶部 message.warning + throw，不发请求）。⚠️【Bug B】即便区间合法，只要真填了 min 或 max 去查询，结果也必为 0 条：parseBalanceAmount 解析的是 row.thirdBalance，而该字段来自 resolveBalanceDisplay(item)，item.balance 在本页 mock 里恒为 undefined（mock 实际字段名是 thirdBalance 不是 balance），resolveBalanceDisplay 因此恒返回"--"，parseBalanceAmount(\'--\') 解析不出数字、恒为 null，filterMerchantRows 里 balance===null 直接判定不匹配。如实记录，不修复。',
    },

    // ============ 操作·工具栏 ============
    {
      anchor: 'act_addMerchant',
      name: '新增三方商户',
      group: '操作',
      interaction: '点击打开新增弹窗（ThirdPartyMerchantEditModal，isAdd:true）。',
      logic: '弹窗内币种/映射码/名称等留空待填，保存时走 api.recharge.thirdPayMerchantAdd。',
      edge:
        '弹窗能正常打开。⚠️【Bug A】但用户在弹窗内一旦选中币种，会触发 syncEditorMappingCodeOptions → api.recharge.getPayCodeSelectData（同样未在本页 mock 实现），「三方映射码」下拉永远查不到选项；映射码是必填项（表单 rules.mappingCode.required），导致新增三方商户在当前代码状态下实际无法真正提交成功。详见「弹窗 · 三方映射码」条目。',
    },

    // ============ 列 ============
    {
      anchor: 'col_currency',
      name: '币种列',
      group: '列',
      interaction: '空值/\'--\'显示纯文本"--"；有值时以 Tag（success 类型）展示。',
      dataSource: '行数据 currency（mapMerchantRow 里来自 normalizeCurrencyDisplay(item.sysCurrency)）。',
      edge:
        '⚠️【Bug B，本页最核心的发现，完整版】本页 mock（components/data.ts 的 MERCHANT_LIST）用的是扁平字段名：currency/mappingCode/name/merchantNo/thirdBalance/associatedMerchants(纯字符串数组)/creator/updatedBy/createdAt&createTime(重复两份同值)/updatedAt&updateTime(重复两份同值)/state；而 ThirdPartyMerchantTab.vue 的 mapMerchantRow 读的却是另一套命名：item.sysCurrency/item.payCode/item.customName/item.merchantCode/item.balance/item.thirdPayMerchantRelationList/item.lastUpdateMan/item.lastUpdateTime——像是照真实 V1 后端契约写的，但本页本地 mock 从未跟着切换成这套命名，两边完全对不上。本列 item.sysCurrency 恒为 undefined → normalizeCurrencyDisplay 恒返回"--"，即列表「币种」列不论 mock 里实际配置了 INR/BRL/USDT 哪个值，界面上永远只显示"--"。同一根因还波及：「三方映射码列」「三方商户昵称列」「三方商户号列」「三方余额列」「最后修改人列」同样恒为"--"；「最后修改时间列」恒显示"-"；「创建时间列」能显示原始字符串但跳过时区换算；「关联商户列」因 item.thirdPayMerchantRelationList 不存在而恒空（渲染成不可点的灰色"--"Tag，其"查看关联商户详情"入口因此在正常操作下摸不到）；只有「创建人列」「状态列」用的字段名（item.creator / item.state）与 mock 一致，能正确显示。如实记录，非本次引入，不修复（详见各自条目）。',
    },
    {
      anchor: 'col_mappingCode',
      name: '三方映射码列',
      group: '列',
      interaction: '空值/\'--\'显示纯文本"--"；有值时以 Tag（info 类型）展示。',
      dataSource: '行数据 mappingCode（mapMerchantRow 里来自 item.payCode）。',
      edge: '⚠️【Bug B】同「币种列」根因，item.payCode 恒为 undefined，本列恒显示"--"。如实记录，不修复。',
    },
    {
      anchor: 'col_name',
      name: '三方商户昵称列',
      group: '列',
      interaction: '纯文本展示，不可点击。',
      dataSource: '行数据 name（mapMerchantRow 里来自 item.customName）。',
      edge: '⚠️【Bug B】同「币种列」根因，item.customName 恒为 undefined，本列恒显示"--"。如实记录，不修复。',
    },
    {
      anchor: 'col_merchantNo',
      name: '三方商户号列',
      group: '列',
      interaction: '纯文本展示。',
      dataSource: '行数据 merchantNo（mapMerchantRow 里来自 item.merchantCode）。',
      edge: '⚠️【Bug B】同「币种列」根因，item.merchantCode 恒为 undefined，本列恒显示"--"。如实记录，不修复。',
    },
    {
      anchor: 'col_thirdBalance',
      name: '三方余额列',
      group: '列',
      interaction: '纯文本展示，设计意图是千分位+两位小数格式化（如"125,680.50"）。',
      dataSource: '行数据 thirdBalance（mapMerchantRow 里来自 resolveBalanceDisplay(item)，读 item.balance）。',
      edge:
        '⚠️【Bug B】同「币种列」根因，且更明确：本页 mock 每条 MERCHANT_LIST 记录实际把格式化好的余额存在字段 thirdBalance 上（如\'125,680.50\'），但 resolveBalanceDisplay 读的是 item.balance（不存在的字段名），恒为 undefined → 函数恒返回"--"。也就是说 mock 里明明准备了逼真的余额样例数据，却因为这一处字段名不对齐，列表上一条都显示不出来。如实记录，不修复。',
    },
    {
      anchor: 'col_associatedMerchants',
      name: '关联商户列',
      group: '列',
      interaction:
        '有值时以蓝字（#1677ff）可点击文本展示多个商户名（用", "拼接），点击打开「关联商户详情」只读弹窗（跳转类控件）；无值时展示灰色不可点的 Tag"--"。',
      dataSource: '行数据 associatedMerchants（mapMerchantRow 里来自 item.thirdPayMerchantRelationList，逐条取 relation.tenantNameWithId）。',
      logic: '点击调用 openMerchantUsageDetail(row)，把 row.usageDetails 传给 MerchantUsageDetailModal 展示。',
      edge:
        '⚠️【Bug B】item.thirdPayMerchantRelationList 在本页 mock 里不存在，associatedMerchants 与配套的 associatedMerchantIds、usageDetails（供详情弹窗用）三者恒为空数组/空数组——本列因此永远走"无值"分支，只显示不可点的灰色"--"，可点击查看详情的交互设计在当前 mock 数据状态下摸不到入口；mock 里另有一个平行、从未被读取的原始字段 item.associatedMerchants（纯字符串数组，如[\'1050\',\'1048\']），本该是这份数据的来源但从未被消费。如实记录，不修复。',
    },
    {
      anchor: 'col_creator',
      name: '创建人列',
      group: '列',
      interaction: '纯文本展示。',
      dataSource: '行数据 creator（mapMerchantRow 里来自 item.creator || \'--\'）。',
      note: '本页与 mock 字段名对齐、能正确显示真实值的少数几列之一（字段名双边都叫 creator）。',
    },
    {
      anchor: 'col_updatedBy',
      name: '最后修改人列',
      group: '列',
      interaction: '纯文本展示。',
      dataSource: '行数据 updatedBy（mapMerchantRow 里来自 item.lastUpdateMan || \'--\'）。',
      edge:
        '⚠️【Bug B】mock 实际字段名是 updatedBy，代码读的是 item.lastUpdateMan（不存在），本列恒显示"--"。如实记录，不修复。当前本列未挂 data-manual 联动点击高亮（纯文本列、无自定义 render，出于成本考虑未额外包裹）。',
    },
    {
      anchor: 'col_createdAt',
      name: '创建时间列',
      group: '列',
      interaction: '纯文本展示，列标题按 showTenantTimeZone 设计会带商户时区后缀。',
      dataSource:
        '行数据 createdAt（mapMerchantRow 里来自 item.createTime）；商户时区解析链路：搜索区 singleAssociatedMerchantTenantId（初始值=当前左上角选中商户 activeTenantId）→ 兜底 defaultTenantId。',
      edge:
        '⚠️ 核实代码后发现：mock 记录里 createTime 字段存的是字符串（如\'2025-11-10 10:00:00\'），而 ProDataTable 的 showTenantTimeZone 时区换算只对 number/Date 类型的值生效，字符串会原样透传显示——即本列展示的是 mock 里的原始字符串，并未真正按商户时区转换过，与列标题暗示的"已按时区换算"不完全一致。如实记录，不修复。因涉及 ProComponents 框架内部 showTenantTimeZone 渲染逻辑（第 4 参时区注入依赖框架自动解析），本次评估改造风险后未给本列挂 data-manual 联动点击高亮，仅保留纯阅读条目。',
    },
    {
      anchor: 'col_updatedAt',
      name: '最后修改时间列',
      group: '列',
      interaction: '纯文本展示，列标题按 showTenantTimeZone 设计会带商户时区后缀。',
      dataSource: '行数据 updatedAt（mapMerchantRow 里来自 item.lastUpdateTime）。',
      edge:
        '⚠️【Bug B】mock 实际字段名是 updatedAt/updateTime，代码读的是 item.lastUpdateTime（都不存在），值为 undefined，走 showTenantTimeZone 渲染的"空值"分支恒显示"-"。如实记录，不修复；与「创建时间列」同理，出于同样的框架渲染风险考虑未挂 data-manual。',
    },
    {
      anchor: 'col_status',
      name: '状态列',
      group: '列',
      interaction: '开关（ConfirmSwitch），点击弹二次确认框（"确定启用/禁用该XX吗？"），确认后才真正切换（R47）。',
      dataSource: '行数据 status（mapMerchantRow 里来自 normalizeStatus(item.state)，与 mock 字段名对齐）。',
      logic:
        'onConfirm → handleUpdateStatus：调用 api.recharge.thirdPayMerchantUpdate({id, state}) 修改启停；成功后 invalidateDictionary(\'thirdPayMerchantList\') 让报表/通道页消费的字典缓存失效，并 tableRef.reload() 整表刷新。',
      note: '本页与 mock 字段名对齐、能正确显示+正确修改的列（Bug B 不影响本列）。',
    },

    // ============ 行操作 ============
    {
      anchor: 'act_edit',
      name: '行操作 · 编辑',
      group: '操作',
      interaction: '点击打开编辑弹窗（ThirdPartyMerchantEditModal，isEdit），编辑前先查详情接口回填。',
      dataSource: '点击时 loadMerchantDetail(row.id) → api.recharge.getByPrimaryKey({id})（本页 mock 已实现，能正常返回）。',
      logic: '按 detail 构造 createEditorData，回填弹窗表单，保存走 api.recharge.thirdPayMerchantUpdate。',
      edge:
        '⚠️【Bug B 的连锁影响，且和直觉相反】弹窗本身能正常打开——因为 row.currency（同 Bug B，恒为"--"）传给 normalizeEditorCurrencyValue 后被判定为无效值、返回 null，这反而绕开了「Bug A」会触发报错的分支（currency 为 null 时 syncEditorMappingCodeOptions 提前 return，不会走到未实现的 getPayCodeSelectData）。但打开后：币种/映射码两个字段（编辑态本就禁用 disabled）回填成空白而非该记录真实值；「三方商户昵称」「三方商户号」两个本该可编辑回填的输入框也因 detail.customName/detail.merchantCode 读不到而回填成空白（应显示原名称/编号却是空的）；密钥类三个掩码字段（merchantKeyMask/publicKeyMask/privateKeyMask）和「状态」不受影响、能正确回填。由于「币种」「三方映射码」两个字段仍受表单 rules 的 required 校验约束、值为空，而这两个输入框又是禁用态、用户在弹窗里无法手动修正，点"确定"大概率会被判定校验不通过——这一步是否真的拦截取决于 naive-ui 对禁用态字段是否豁免 required 校验，本次未逐行核实 naive-ui 组件源码，属基于表单校验机制的合理推断而非直接实测，如实标注推断依据。如实记录，不修复。',
    },
    {
      anchor: 'usage_table',
      name: '弹窗 · 关联商户详情（只读表格）',
      group: '操作',
      interaction:
        '由点击「关联商户列」触发，只读 n-data-table：同一站点名（siteName）用 rowSpan 合并单元格；列含 商户/通道类型(Tag 充值蓝·提现橙)/关联通道详情(通道ID → 通道名称)/通道状态(Tag 启用绿·禁用灰)/通道最后修改人/通道最后修改时间；同站点分组之间有加粗分隔线（rowClassName）。无任何可编辑控件，仅"关闭"退出。',
      dataSource: '父层传入的 merchants（即该行 row.usageDetails，来自 mapMerchantRow 里 buildUsageDetails(item)）。',
      edge:
        '⚠️【Bug B】row.usageDetails 恒为空数组（同「关联商户列」根因：item.thirdPayMerchantRelationList 不存在），且触发它的「关联商户列」在无值时不可点——本弹窗设计完整、组件本身没问题，但在当前 mock 数据状态下，正常操作路径永远打不开它、也永远看不到非空表格。如实记录，不修复。',
    },

    // ============ 弹窗：ThirdPartyMerchantEditModal（新增/编辑三方商户） ============
    {
      anchor: 'form_currency',
      name: '弹窗 · 币种',
      group: '操作',
      interaction: '下拉单选（n-select，可搜索、可清空），编辑态禁用（:disabled="isEditMode || submitting"）。',
      dataSource: 'editorCurrencyOptions，来自 initializeCurrencySelectData() 调 api.recharge.getSysCurrencySelectData()（本页 mock 已实现，正常加载）。',
      logic: '切换后清空「三方映射码」当前值，并 emit(\'currencyChange\') 通知父层按新币种重新请求映射码下拉。',
      limit: '必填（rules.currency.required，trigger:\'change\'）。',
      edge:
        '⚠️【Bug B】编辑态下本字段回填值来自 row.currency（恒为"--"，见「行操作·编辑」条目），被判定无效后显示为空——即编辑已有记录时，这个本该回填真实币种的禁用框实际显示空白。新增态不受此影响，用户可正常手动选择。',
    },
    {
      anchor: 'form_mappingCode',
      name: '弹窗 · 三方映射码',
      group: '操作',
      interaction: '下拉单选（n-select，可搜索、可清空），带 loading 态；编辑态或未选币种时禁用（:disabled="isEditMode || submitting || !currency"）。',
      dataSource: 'editorMappingCodeOptions，来自 syncEditorMappingCodeOptions(currency) → requestPayCodeSelectData → api.recharge.getPayCodeSelectData。',
      logic: '新增态下随「币种」变化重新请求；提交时映射码随表单一起提交给 thirdPayMerchantAdd/Update。',
      limit: '必填（rules.mappingCode.required，trigger:\'change\'）。',
      edge:
        '⚠️【Bug A，本页第二个核心发现】api.recharge.getPayCodeSelectData 在本页 mock 里从未实现（同「币种（搜索）」条目根因）。新增态：用户选定币种后本下拉的请求会抛 TypeError，选项永远停留在空数组，而本字段是必填项——新增三方商户在当前代码状态下实际无法真正提交成功。编辑态：因「行操作·编辑」条目所述的另一个 bug（currency 提前变成 null），本字段不会触发这次报错，但会显示为空白禁用框。如实记录，不修复。',
    },
    {
      anchor: 'form_name',
      name: '弹窗 · 三方商户昵称',
      group: '操作',
      interaction: '单行文本输入。',
      dataSource: '用户输入；编辑态尝试从 detail.customName 回填。',
      limit: `必填（rules.name.required，trigger:'blur'）；最多 50 字，普通文本字符（INPUT_PRESETS.name）。`,
      edge: '⚠️【Bug B】编辑态下 detail.customName 读不到（同「币种列」根因），回填为空字符串，用户打开编辑会看到这一栏意外空白，需要重新手动填写才能保存。',
    },
    {
      anchor: 'form_merchantNo',
      name: '弹窗 · 三方商户号',
      group: '操作',
      interaction: '单行文本输入。',
      dataSource: '用户输入；编辑态尝试从 detail.merchantCode 回填。',
      limit:
        '实际未强制必填——i18n 已备好 validation.enterMerchantNo（"请输入三方商户号"）提示文案，但表单 rules 对象里并未真的给 merchantNo 配 required 规则，留空也能通过校验，如实记录这处文案与规则不完全对应；50 字预设（INPUT_PRESETS.searchKw，与「搜索关键词」共用同一预设，非命名为 merchantNo 专属预设）。',
      edge: '⚠️【Bug B】编辑态下 detail.merchantCode 读不到，回填为空字符串，同「弹窗·三方商户昵称」。',
    },
    {
      anchor: 'form_secretKey',
      name: '弹窗 · 商户密钥',
      group: '操作',
      interaction: '多行文本域（3~6 行自适应）。',
      dataSource: '用户输入；编辑态优先显示后端掩码（merchantKeyMask，如\'••••••••••••\'），未改动则提交时保持原值下发（buildSubmitPayload 的 shouldKeepOriginalSecretKey 逻辑）。',
      limit: '无长度限制声明（普通 n-input，未套 INPUT_PRESETS）。',
      note: '密钥类字段是本页少数不受 Bug B 影响的编辑态回填字段——merchantKeyMask 由 getByPrimaryKey 显式赋值，字段名双边一致。',
    },
    {
      anchor: 'form_publicKey',
      name: '弹窗 · 公钥',
      group: '操作',
      interaction: '多行文本域（3~6 行自适应）。',
      dataSource: '用户输入；编辑态优先显示掩码 publicKeyMask。',
      limit: '无长度限制声明。',
    },
    {
      anchor: 'form_privateKey',
      name: '弹窗 · 私钥',
      group: '操作',
      interaction: '多行文本域（3~6 行自适应）。',
      dataSource: '用户输入；编辑态优先显示掩码 privateKeyMask。',
      limit: '无长度限制声明。',
    },
    {
      anchor: 'form_remark',
      name: '弹窗 · 备注',
      group: '操作',
      interaction: '多行文本域（2~4 行自适应），带字数统计。',
      dataSource: '用户输入；编辑态尝试从 detail.remark 回填。',
      limit: '选填；200 字（INPUT_PRESETS.remark）。',
      edge: '本页 mock 的 ThirdPayMerchantRow 接口本身未定义 remark 字段，编辑态该框恒为空（不算 Bug B 的对齐问题，是这份 mock 数据本来就没准备备注样例）。',
    },
    {
      anchor: 'form_status',
      name: '弹窗 · 状态',
      group: '操作',
      interaction: '开关（n-switch），开=启用、关=禁用。',
      dataSource: '用户切换；新增默认"启用"；编辑态从 detail.state 回填（字段名对齐，能正确回填）。',
      logic: '提交时 status==="enabled" 映射为 state:1，否则 state:0。',
    },
    {
      anchor: 'form_save',
      name: '弹窗 · 取消/确定',
      group: '操作',
      interaction: '"取消"关闭弹窗不保存；"确定"先触发表单校验（formRef.validate()），通过后 emit(\'save\')。',
      logic:
        '父层 onSave：新增走 thirdPayMerchantAdd、编辑走 thirdPayMerchantUpdate；成功后 Toast 提示 + invalidateDictionary(\'thirdPayMerchantList\') + 整表刷新 + 关闭弹窗；失败仅 Toast 报错，弹窗保持打开、不清空已填内容。',
      edge:
        '见「弹窗·币种」「弹窗·三方映射码」「行操作·编辑」三条：新增态选完币种后映射码必填项永远填不上；编辑态币种/映射码/商户昵称/商户号回填异常，大概率无法顺利通过校验保存。',
    },
  ],

  // ============ 字段介绍 tab（列序照页面；仅列表列 + 定义）============
  fields: [
    {
      name: '币种',
      def: '该三方代付商户账号使用的结算币种（如 INR/BRL/USDT）。⚠️ 当前页面代码读取字段名（sysCurrency）与本页 mock 实际字段名（currency）不一致，本列展示恒为"--"，如实记录非本次引入。',
    },
    {
      name: '三方映射码',
      def: '该三方商户在系统内的映射标识码，用于把系统内部通道与三方账号对应起来。⚠️ 同「币种」字段名不对齐问题，本列展示恒为"--"。',
    },
    {
      name: '三方商户昵称',
      def: '新增/编辑时自定义填写的三方商户显示名称，便于人工识别。⚠️ 同「币种」字段名不对齐问题，本列展示恒为"--"。',
    },
    {
      name: '三方商户号',
      def: '该三方商户在对方平台的商户编号。⚠️ 同「币种」字段名不对齐问题，本列展示恒为"--"。',
    },
    {
      name: '三方余额',
      def: '该三方商户账号在对方平台的余额快照（页面设计为千分位+两位小数展示）。⚠️ mock 里已准备好逼真的格式化余额样例值（存在 thirdBalance 字段上），但页面代码读的是另一个不存在的字段名（balance），本列展示恒为"--"。',
    },
    {
      name: '关联商户',
      def: '哪些站点（商户）的收/付款通道正在使用这个三方账号；点击可查看每个站点具体关联了哪些通道的只读明细。⚠️ 页面代码读取的关联关系字段（thirdPayMerchantRelationList）在本页 mock 里不存在，本列展示恒为空、不可点，详情弹窗在当前 mock 数据下摸不到入口。',
    },
    { name: '创建人', def: '新增该三方商户记录的操作人账号。' },
    {
      name: '创建时间',
      def: '该三方商户记录的创建时间，按当前操作商户所在时区展示（showTenantTimeZone）。⚠️ mock 里存的是字符串而非数值时间戳，实际未经过时区换算、原样显示。',
    },
    {
      name: '最后修改人',
      def: '最近一次编辑/启停该记录的操作人账号。⚠️ 页面代码读取字段名（lastUpdateMan）与 mock 实际字段名（updatedBy）不一致，本列展示恒为"--"。',
    },
    {
      name: '最后修改时间',
      def: '最近一次编辑/启停该记录的时间，按当前操作商户所在时区展示。⚠️ 页面代码读取字段名（lastUpdateTime）与 mock 实际字段名（updatedAt）不一致，本列展示恒为"-"。',
    },
    {
      name: '状态',
      def: '该三方商户账号的启用/禁用状态；可点击开关直接切换（二次确认），字段名双边对齐、能正确显示与修改。',
    },
  ],
};

export default manual;
