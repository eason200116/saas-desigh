/**
 * @description ProTabs 父子组件之间的 provide/inject 上下文协议。父容器 ProTabs 暴露 activeKey 与
 *   注册/反注册接口；子 ProTabPane 在 mount 时把自己 meta 注册进来，由父统一渲染 tab nav。
 * @date 2026-05-22
 * @scope src/components/ProComponents/ProTabs
 */
import type { ComputedRef, InjectionKey, Ref } from 'vue';

/** ProTabPane 注册到父容器时携带的元信息（label / disabled / 渲染策略均以 ref 暴露，保持响应式） */
export interface ProTabPaneMeta {
  /** Tab 唯一标识，等同 ProTabPane :name */
  name: string;
  /** 已 i18n 后的显示标题 */
  tab: ComputedRef<string>;
  /** 是否禁用点击 */
  disabled: ComputedRef<boolean>;
  /** 渲染策略 */
  displayDirective: ComputedRef<ProTabPaneDisplayDirective>;
}

/**
 * 渲染策略：
 * - lazy：首次激活才挂载，之后 v-show 切换（≈ KeepAlive 缓存，默认值）
 * - show：始终挂载所有 pane，v-show 切换
 * - if：仅激活时挂载，离开即销毁（每次重建，无缓存）
 */
export type ProTabPaneDisplayDirective = 'lazy' | 'show' | 'if';

export interface ProTabsContext {
  /** 当前激活的 Tab key（响应式只读） */
  readonly activeKey: Ref<string>;
  /** 子 pane mount 时调用 */
  registerPane(meta: ProTabPaneMeta): void;
  /** 子 pane unmount 时调用 */
  unregisterPane(name: string): void;
}

export const ProTabsContextKey: InjectionKey<ProTabsContext> = Symbol('ProTabsContext');

/**
 * 当前激活 pane content 区域（"三段模型"的 Block 3）在 viewport 中的几何信息。
 * 由 ResizeObserver + window resize + tab 切换三处触发器维护更新。
 *
 * - top：Block 3 顶 = layout 头部高度 + ProTabs tab nav 高度（已含间距）
 * - bottom：Block 3 底（通常贴 viewport 底，特殊场景如弹窗嵌入会上移）
 * - height：bottom - top，便于消费者直接拿"可用高度"撑满（如图表/canvas）
 */
export interface ProTabsPaneRect {
  top: number;
  bottom: number;
  height: number;
}

export interface ProTabsHeightContext {
  /** 当前激活 pane content 区域几何信息（响应式只读） */
  readonly paneRect: Ref<ProTabsPaneRect>;
}

export const ProTabsHeightContextKey: InjectionKey<ProTabsHeightContext> =
  Symbol('ProTabsHeightContext');
