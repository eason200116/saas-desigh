// 异常会员（商户端 tenant · riskControl_abnormalMember）功能说明书。
// 锚定 src/views/riskControl/abnormalMember/index.vue(752行，含名单导入弹窗) + data.ts(339行) 真实控件（R53 实证、不臆造）。
// 结构：非Tab壳单页，定位是"资金处置工作台"——3种资金处置动作(保险箱转出/驳回提现/余额扣除)贯穿
// 顶部工具栏「名单导入」按钮×3、底部「批量操作」下拉×3、行操作按钮×3，三处触发的是同一套确认+接口逻辑
// （confirmFundAction 统一处理单条/批量/导入三种入口）。

import type { PageManual } from '../types';

const manual: PageManual = {
  route: 'riskControl_abnormalMember',
  title: '异常会员',
  overview:
    '商户端「风控管理 › 异常会员」页，定位资金处置工作台，围绕3种处置动作（保险箱转出/驳回提现/余额扣除）' +
    '设计了3套并行入口：①行操作按钮（对单条会员立即处置）②底部"批量操作"下拉（对勾选的多条会员批量处置）' +
    '③顶部3个"名单导入"按钮（上传CSV/TXT名单 → mock校验有效性 → 确认后批量处置，同一弹窗按类型复用）。' +
    '三处入口最终都调用同一个 confirmFundAction() 统一确认+接口调用，行为完全一致。' +
    '搜索区仅暴露"商户"+"会员ID"两项，但 data.ts 的 abnormalMemberGetPageList 实际支持按账号/设备/会员状态/' +
    '黑名单状态/注册时间区间过滤（mock 过滤逻辑已写好），这些字段未在 UI 上暴露为搜索项——如实记录，不属于本次任务修复范围。' +
    '另有 abnormalMemberHandle({id}) 这个"标记处理"mock 方法在 data.ts 里定义并导出，但全页未见任何地方调用，是死代码。',
  items: [
    // ============ 搜索区 ============
    {
      anchor: 'merchant',
      name: '商户（必选）',
      group: '搜索',
      interaction: '下拉单选，恒排第一位，红星必填；未选点查询红框+红字「请选择商户」。',
      limit: '单选（R63）。',
    },
    {
      anchor: 'memberId',
      name: '会员ID',
      group: '搜索',
      interaction: '文本框，支持一次输入多个（空格/逗号/分号分隔），仅允许数字与空格。',
      edge:
        'data.ts 的 abnormalMemberGetPageList 实际还支持按 account(账号)/device(设备)/memberState(会员状态)/' +
        'blacklistState(黑名单状态)/startTime~endTime(注册时间区间) 过滤，mock 过滤逻辑均已写好，但这些字段' +
        '未在本页搜索区暴露为可操作的搜索项——如实记录，未修复。',
    },
    {
      anchor: 'reset',
      name: '重置',
      group: '搜索',
      interaction: 'ProCrudTable内置重置按钮，点击清空商户+会员ID并重新查询。',
    },

    // ============ 工具栏：3个名单导入入口 ============
    {
      anchor: 'act_importSafeBox',
      name: '保险箱转出名单导入',
      group: '操作',
      interaction: '蓝色(info)按钮，点击打开名单导入弹窗（3类型复用同一弹窗组件，本次固定为"保险箱转出"类型）。',
      logic: '见 act_importModal 条目描述完整导入流程；本类型校验金额取该会员"保险箱余额"字段。',
    },
    {
      anchor: 'act_importReject',
      name: '驳回提现名单导入',
      group: '操作',
      interaction: '橙色(warning)按钮，点击打开名单导入弹窗（固定为"驳回提现"类型）。',
      logic: '校验金额取该会员"处理中提款金额"字段。',
    },
    {
      anchor: 'act_importDeduct',
      name: '余额扣除名单导入',
      group: '操作',
      interaction: '红色(error)按钮，点击打开名单导入弹窗（固定为"余额扣除"类型）。',
      logic: '校验金额取该会员"钱包余额"字段；本类型唯一需要上传文件里带"扣除金额"这一列（其余两类型只需会员ID一列）。',
    },
    {
      anchor: 'act_batchActions',
      name: '批量操作（下拉，3个子动作）',
      group: '操作',
      interaction: '需先勾选至少1行才可点击（未勾选置灰）；下拉展开显示保险箱转出/驳回提现/余额扣除3项。',
      logic: '选中某项 → 对全部勾选行执行 confirmFundAction()（与行操作同一套二次确认+接口逻辑，rows变为多条）。',
    },

    // ============ 名单导入弹窗内部控件 ============
    {
      anchor: 'act_importUpload',
      name: '上传文件',
      group: '操作',
      interaction: '弹窗内蓝色描边按钮，点击触发隐藏的 file input（仅接受 .csv/.txt）。',
      logic:
        '上传后按当前导入类型解析：非余额扣除类=逐行提取数字会员ID(去重，去除表头文案)；余额扣除类=' +
        '按行解析"会员ID,扣除金额"两列。解析结果调用 abnormalMemberImportValidate 校验（按当前商户+对应金额' +
        '字段逐行核对是否存在该会员），返回校验表填充下方表格。单次最多解析1000条。',
      limit: '仅接受 .csv/.txt 格式文件；单次上限1000条记录。',
    },
    {
      anchor: 'act_downloadTemplate',
      name: '下载模板',
      group: '操作',
      interaction: '弹窗内灰色按钮，点击下载CSV模板文件。',
      logic:
        '模板内容=当前商户下真实会员ID样例(有效) + 一个固定不存在ID"9999999"(无效样例)，下载后可直接' +
        '上传验证有效/无效两种校验结果（R32数据多样）；余额扣除类模板额外含"扣除金额"列（负数样例）。',
    },
    {
      anchor: 'col_importValid',
      name: '导入校验表·校验结果列',
      group: '列',
      interaction: '有效/无效 圆角Tag（绿/红），无效行整行标红（背景+文字变红）、不参与后续导入。',
      logic: '校验依据：该会员ID是否存在于当前选定商户下；余额扣除类另需扣除金额为合法负数，否则同样判无效。',
    },
    {
      anchor: 'act_importRemark',
      name: '备注（导入弹窗内）',
      group: '搜索',
      interaction: '多行文本框，选填，最多100字，带计数；填了则校验不可含中文。',
      limit: '选填；填写时不可含中文字符。',
    },
    {
      anchor: 'act_importConfirm',
      name: '确认导入（弹窗内）',
      group: '操作',
      interaction: '主色按钮，按钮文案带当前有效行数「确认导入（N）」；有效行数为0时禁用。',
      logic:
        '点击先校验（有效行≥1、备注不含中文），通过后弹二次确认对话框，再次确认才真正调用对应处置接口' +
        '（仅对有效行处置，余额扣除类按每行各自的扣除金额、其余两类型按校验表所示金额整额处置）。',
    },

    // ============ 列（表格8列，均展示为主，仅会员ID可点） ============
    {
      anchor: 'col_memberId',
      name: '会员ID（可点击）',
      group: '列',
      interaction: '蓝字可点。',
      logic: '点击打开全站共用「会员详情」弹窗。',
    },

    // ============ 行操作（3个，恒常驻） ============
    {
      anchor: 'act_rowSafeBox',
      name: '保险箱转出（行操作）',
      group: '操作',
      interaction: '蓝色文字链，每行常驻。',
      logic: '点击弹二次确认（含选填备注，不可含中文），确认后调用保险箱转出接口，仅处置该行会员。',
    },
    {
      anchor: 'act_rowReject',
      name: '驳回提现（行操作）',
      group: '操作',
      interaction: '橙色文字链，每行常驻。',
      logic: '点击弹二次确认（含选填备注，不可含中文），确认后调用驳回提现接口。',
    },
    {
      anchor: 'act_rowDeduct',
      name: '余额扣除（行操作）',
      group: '操作',
      interaction: '红色文字链，每行常驻。',
      logic: '点击弹二次确认（含必填扣除金额，须为负数，及选填备注不可含中文），确认后调用余额扣除接口。',
      limit: '扣除金额必须为负数（max: -0.01）。',
    },
  ],
  fields: [
    { name: '商户（列）', def: '该异常会员所属商户，标签展示。' },
    { name: '会员ID', def: '会员唯一编号，可点击进详情，见交互条目 col_memberId。' },
    { name: '账号', def: '会员登录账号（脱敏展示）。' },
    { name: '会员状态', def: '正常/禁用，只读Tag展示。' },
    { name: '钱包余额', def: '该会员当前钱包余额，"余额扣除"类处置的处置对象。' },
    { name: '保险箱余额', def: '该会员保险箱内金额，"保险箱转出"类处置的处置对象。' },
    { name: '处理中提款金额', def: '该会员当前处于处理中状态的提现总金额，"驳回提现"类处置的处置对象。' },
    { name: '注册时间', def: '该会员账号注册时间，按商户时区展示。' },
    { name: '备注', def: '风控/处置备注，超长省略+悬停看全文，可为空。' },
  ],
};

export default manual;
