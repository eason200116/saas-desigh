/**
 * 字典数据 Hook：项目唯一字典访问入口。
 *
 * 整合 5 种 source：
 *  - common   ← user store.dictionary（GetDictionary 返回）
 *  - group    ← user store.gropuData（集团字典）
 *  - platform ← user store.platformDic（总控字典）
 *  - v1       ← user store.v1Dictionary（v1 字典）
 *  - dynamic  ← 模块级 shallowReactive 缓存（GetDynamicDictionary 懒加载）
 *
 * dynamic 与静态字典的区别仅在于：调用 findLabel/getOptions 时如果未加载或缓存过期，
 * 内部副作用触发 fetch；shallowReactive 让模板自动响应数据到位。
 *
 * 业务侧只需 useDictionary({ source: 'dynamic' }).findLabel('thirdPayMerchantList', id)。
 *
 * @see preloadDictionary / invalidateDictionary（模块级 utils，跨页缓存控制）
 */
import { ref, shallowReactive } from 'vue';
import { useUserStore } from '@/store/modules';
import { api } from './data';
// ============================================================================
// 1. 动态字典：key → 元素类型 强类型映射（直接复用 swagger 生成的 DTO 类型）
// ============================================================================

export interface DynamicDictionaryItemMap {
  organizationList: any;
  tenantList: any;
  sysCurrencyList: any;
  payCodeList: any;
  thirdPayMerchantList: any;
  tenantPayChannelList: any;
  sysPayChannelList: any;
  rechargeCategoryList: any;
  withdrawCategoryList: any;
  roleList: any;
  menuList: any;
  withdrawConfigGroupList: any;
  approvalAuthorizeList: any;
  /** 后端 Dictionary<int,string> 归一化为 [{ id, name }] */
  userName: { id: number; name: string };
  /** 商户字典（国家/币种/语言管理弹窗用）：统一 { value, label } 形态，见 DictSelect/data.ts */
  timeZoneDictionaryList: { value: string; label: string };
  countryDictionaryList: { value: string; label: string };
  currencyDictionaryList: { value: string; label: string };
  languageDictionaryList: { value: string; label: string };
}

export type DynamicDictionaryKey = keyof DynamicDictionaryItemMap;

// ============================================================================
// 2. 模块级动态字典缓存（替代 Pinia store；shallowReactive 触发模板响应）
// ============================================================================

/**
 * SWR 双闸门：
 * - STALE_AFTER_MS：硬过期兜底，超过此值视为缓存空（首次 read 会阻塞拉取）；放宽到 30min，
 *   避免短期反复阻塞。日常刷新由 REVALIDATE 节流的后台 fetch 接管。
 * - REVALIDATE_INTERVAL_MS：节流窗口。命中 cache 时仅每 30s 触发一次后台 refetch；
 *   shallowReactive 让 fetch 完成后 UI 自动 re-render（业务零改造拿到 SWR）。
 */
const STALE_AFTER_MS = 30 * 60 * 1000;
const REVALIDATE_INTERVAL_MS = 15 * 1000;

interface DynamicCacheEntry<T = unknown> {
  data: T[];
  loadedAt: number;
}

const dynamicCache = shallowReactive<{
  [K in DynamicDictionaryKey]?: DynamicCacheEntry<DynamicDictionaryItemMap[K]>;
}>({});

const dynamicPending = new Map<DynamicDictionaryKey, Promise<unknown>>();
/** 最近一次"后台节流刷新"时间戳；用于 maybeRevalidate 跳过过频请求 */
const lastRevalidateAt: Partial<Record<DynamicDictionaryKey, number>> = {};

function readDynamicValue(data: Record<string, unknown> | undefined | null, key: string): unknown {
  if (!data) return undefined;
  // 新版结构：直接 camelCase 字段在顶层（Dynamicany 已显式声明）。
  // 老版结构：兼容 items[key] / items[Pascal] 兜底（个别后端版本未刷新时不至于失效）。
  if (data[key] !== undefined) return data[key];
  const items = data.items as Record<string, unknown> | undefined;
  if (items) {
    const pascal = key.charAt(0).toUpperCase() + key.slice(1);
    return items[key] ?? items[pascal];
  }
  return undefined;
}

function normalizeDynamicList<K extends DynamicDictionaryKey>(
  key: K,
  rawValue: unknown,
): DynamicDictionaryItemMap[K][] {
  // userName 后端返回 Dictionary<int,string>；归一化为 [{ id, name }]
  if (key === 'userName') {
    if (!rawValue || typeof rawValue !== 'object' || Array.isArray(rawValue)) {
      return [];
    }
    return Object.entries(rawValue as Record<string, unknown>).flatMap(([id, name]) => {
      const parsedId = Number(id);
      if (!Number.isFinite(parsedId)) return [];
      return [
        {
          id: parsedId,
          name: typeof name === 'string' ? name || String(parsedId) : String(name ?? parsedId),
        },
      ];
    }) as DynamicDictionaryItemMap[K][];
  }
  return Array.isArray(rawValue) ? (rawValue as DynamicDictionaryItemMap[K][]) : [];
}

function isStale(key: DynamicDictionaryKey): boolean {
  const entry = dynamicCache[key];
  return !entry || Date.now() - entry.loadedAt > STALE_AFTER_MS;
}

/**
 * 节流后台刷新：cache 命中读时由 resolveItems 触发，避免每次 read 都打请求。
 * 30s 内重复触发只发 1 次；fire-and-forget，不阻塞调用方；shallowReactive 写回时
 * 自动唤醒所有依赖该 key 的 computed/render（业务无感的 SWR）。
 */
function maybeRevalidate(key: DynamicDictionaryKey): void {
  const now = Date.now();
  const last = lastRevalidateAt[key] ?? 0;
  if (now - last < REVALIDATE_INTERVAL_MS) return;
  lastRevalidateAt[key] = now;
  // 走 force=true 绕开 scheduleAutoLoad 的 isStale 短路；in-flight 仍复用，避免并发
  void scheduleAutoLoad(key, { force: true });
}

// ─── 自动批量队列：同 microtask 内多 key 合并为 1 次 API 请求 ───────────────

/** 当前批次累积的 key 集合（同 tick 内） */
let batchQueue = new Set<DynamicDictionaryKey>();
/** 当前已调度的 flush microtask；本批所有 key 共享此 Promise */
let batchFlushPromise: Promise<void> | null = null;

/**
 * 把 key 加入下一个 microtask 的批次队列。同 tick 内多次调用（即使来自不同组件）
 * 只产生 1 次后端请求；已 in-flight 复用其 Promise。
 *
 * - 默认（force=false）：cache 未过期直接 resolve（用于业务侧 preload / 自动 fetch on miss）
 * - force=true：跳过 isStale 短路，强制进队列（用于 maybeRevalidate 的 SWR 后台刷）
 *
 * 这是底层调度，业务方只需调 findLabel/getOptions 即可（内部副作用触发本函数）。
 */
function scheduleAutoLoad(
  key: DynamicDictionaryKey,
  options: { force?: boolean } = {},
): Promise<void> {
  if (!options.force && !isStale(key)) return Promise.resolve();
  const existing = dynamicPending.get(key);
  if (existing) return existing as Promise<void>;

  batchQueue.add(key);

  if (!batchFlushPromise) {
    batchFlushPromise = Promise.resolve().then(() => flushBatch());
  }

  // 把同一个 flush Promise 挂到本批次每个 key 的 pending 上
  dynamicPending.set(key, batchFlushPromise);
  return batchFlushPromise;
}

/** 取当前批次所有 key，1 次请求合并加载，写回 cache。 */
async function flushBatch(): Promise<void> {
  const keys = Array.from(batchQueue);
  batchQueue = new Set();
  batchFlushPromise = null;
  if (!keys.length) return;

  try {
    const { data } = await api.common.getDynamicDictionary({
      keys: keys as unknown as any[],
    });
    const finishedAt = Date.now();
    for (const key of keys) {
      const rawValue = readDynamicValue(data as unknown as Record<string, unknown>, key);
      dynamicCache[key] = {
        data: normalizeDynamicList(key, rawValue),
        loadedAt: finishedAt,
      } as never;
      // 同步初始化节流戳：本次 fetch 自身就是一次 revalidate，
      // 后续 cache 命中读触发 maybeRevalidate 时按 finishedAt 起算 15s 节流，
      // 避免「首次响应到达 → cache 命中读 → maybeRevalidate 立刻又发一次」
      lastRevalidateAt[key] = finishedAt;
    }
  } catch (e) {
    console.error(`[useDictionary] 批量加载动态字典 [${keys.join(',')}] 失败`, e);
    // 失败兜底：未缓存的 key 写空数组，避免 findLabel 永远等待
    const finishedAt = Date.now();
    for (const key of keys) {
      if (!dynamicCache[key]) {
        dynamicCache[key] = { data: [], loadedAt: finishedAt } as never;
        lastRevalidateAt[key] = finishedAt;
      }
    }
  } finally {
    for (const key of keys) dynamicPending.delete(key);
  }
}

/**
 * 显式预加载动态字典。等价于把多个 key 推入批次然后 await flush。
 *
 * findLabel/getOptions 内部已自动批量；只在以下场景才需要显式调用：
 *  - setup 内 await 字典就绪后再渲染（如鉴权后路由跳转）
 *  - 想触发预热但本 tick 没有任何 findLabel 调用
 *
 * @example
 * onMounted(async () => {
 *   await preloadDictionary(['tenantPayChannelList', 'thirdPayMerchantList']);
 *   ready.value = true;
 * });
 */
export async function preloadDictionary(keys: readonly DynamicDictionaryKey[]): Promise<void> {
  await Promise.all(keys.map((k) => scheduleAutoLoad(k)));
}

/**
 * 让指定 key 缓存失效（业务编辑数据后调用，下次 findLabel/getOptions 重拉）。
 */
export function invalidateDictionary(
  key: DynamicDictionaryKey | readonly DynamicDictionaryKey[],
): void {
  const keys = Array.isArray(key) ? key : [key as DynamicDictionaryKey];
  for (const k of keys) {
    delete dynamicCache[k];
    dynamicPending.delete(k);
    delete lastRevalidateAt[k];
  }
}

/** 测试专用：清空模块级缓存（生产代码勿用） */
export function __resetDictionaryCacheForTest(): void {
  for (const k of Object.keys(dynamicCache) as DynamicDictionaryKey[]) {
    delete dynamicCache[k];
  }
  for (const k of Object.keys(lastRevalidateAt) as DynamicDictionaryKey[]) {
    delete lastRevalidateAt[k];
  }
  dynamicPending.clear();
}

// ============================================================================
// 3. 静态字典源 + 候选字段映射
// ============================================================================

export type DictionarySource = 'common' | 'group' | 'platform' | 'v1' | 'dynamic';

export type DictionaryType = keyof any | keyof any | keyof any | DynamicDictionaryKey | string;

export interface SelectOption {
  label: string;
  value: string | number;
  [key: string]: unknown;
}

export interface GetOptionsConfig {
  source?: DictionarySource;
  labelField?: string;
  valueField?: string;
}

interface ResolvedFieldConfig {
  labelField?: string;
  valueField?: string;
}

const SOURCE_DEFAULT_FIELDS: Record<DictionarySource, ResolvedFieldConfig> = {
  common: { labelField: 'name', valueField: 'id' },
  group: { labelField: 'dictName', valueField: 'dictCode' },
  platform: {},
  v1: { labelField: 'name', valueField: 'id' },
  dynamic: {},
};

const SOURCE_LABEL_CANDIDATES: Record<DictionarySource, string[]> = {
  common: ['name', 'label', 'dictName', 'value'],
  group: ['dictName', 'name', 'label'],
  platform: ['countryName', 'languageName', 'currencyName', 'name', 'label', 'dictName'],
  v1: ['name', 'label', 'value'],
  dynamic: [
    'name',
    'customName',
    'orgName',
    'tenantName',
    'sysChannelName',
    'roleName',
    'menuName',
    'groupName',
    'payCode',
    'sysCurrency',
  ],
};

const SOURCE_VALUE_CANDIDATES: Record<DictionarySource, string[]> = {
  common: ['id', 'code', 'key', 'value', 'dictCode'],
  group: ['dictCode', 'id', 'code', 'key', 'value'],
  platform: ['countryCode', 'languageCode', 'currencyCode', 'code', 'key', 'id', 'value'],
  v1: ['id', 'code', 'key', 'value'],
  // dynamic 源不能放 orgId/tenantId 这种"次级 ID"——多个 dict 的 item 形态都包含它，
  // 候选探测会把同一 orgId 下所有 role/tenant item 折叠成同 value，
  // 触发 n-select "点 1 个选中多个" 的 bug。dynamic 走 DYNAMIC_FIELD_MAP 显式映射。
  dynamic: ['id', 'code', 'key', 'value'],
};

/**
 * 动态字典 per-key 显式 label/value 映射。
 * 不再依赖通用候选数组顺序猜测：每个 dict 的"主键 ID"和展示名都直接指定，
 * 避免 any/any 等含 orgId 的项被错误命中 orgId。
 */
const DYNAMIC_FIELD_MAP: Partial<Record<DynamicDictionaryKey, { label: string; value: string }>> = {
  organizationList: { label: 'orgName', value: 'orgId' },
  tenantList: { label: 'tenantName', value: 'tenantId' },
  sysCurrencyList: { label: 'sysCurrency', value: 'sysCurrency' },
  payCodeList: { label: 'payCode', value: 'payCode' },
  thirdPayMerchantList: { label: 'customName', value: 'merchantId' },
  tenantPayChannelList: { label: 'customName', value: 'tenantChannelId' },
  sysPayChannelList: { label: 'sysChannelName', value: 'sysChannelId' },
  rechargeCategoryList: { label: 'name', value: 'id' },
  withdrawCategoryList: { label: 'name', value: 'id' },
  roleList: { label: 'roleName', value: 'roleId' },
  menuList: { label: 'menuName', value: 'menuId' },
  withdrawConfigGroupList: { label: 'groupName', value: 'configGroupId' },
  userName: { label: 'name', value: 'id' },
  // 商户字典（国家/币种/语言/时区）：DictSelect/data.ts 里已直接是 { value, label } 形态，原样透传
  timeZoneDictionaryList: { label: 'label', value: 'value' },
  countryDictionaryList: { label: 'label', value: 'value' },
  currencyDictionaryList: { label: 'label', value: 'value' },
  languageDictionaryList: { label: 'label', value: 'value' },
};

// ============================================================================
// 4. Hook
// ============================================================================

export interface UseDictionaryConfig {
  /** 实例默认 source；调用时 opts.source 可单次覆盖 */
  source?: DictionarySource;
}

/**
 * 字典 Hook，统一访问入口。
 *
 * @example
 * // 静态字典
 * const dict = useDictionary({ source: 'common' });
 * dict.findLabel('withdrawStateList', 1);
 *
 * @example
 * // 动态字典（自动按需加载，模板响应式）
 * const dict = useDictionary({ source: 'dynamic' });
 * dict.findLabel('thirdPayMerchantList', merchantId);
 *
 * @example
 * // 混用：实例默认 common，单次切 dynamic
 * const dict = useDictionary();
 * dict.findLabel('withdrawStateList', 1);
 * dict.findLabel('thirdPayMerchantList', mid, { source: 'dynamic' });
 */
export function useDictionary(config: UseDictionaryConfig = {}) {
  const defaultSource = config.source ?? 'common';
  const userStore = useUserStore();
  const loading = ref(false);

  const resolveStaticData = (source: Exclude<DictionarySource, 'dynamic'>) => {
    switch (source) {
      case 'group':
        return userStore.getGropuData;
      case 'platform':
        return userStore.getPlatformDic;
      case 'v1':
        return userStore.getV1Dictionary;
      case 'common':
      default:
        return userStore.getDictionaryList;
    }
  };

  const resolveLabelField = (source: DictionarySource, labelField?: string) =>
    labelField || SOURCE_DEFAULT_FIELDS[source].labelField;

  const resolveValueField = (source: DictionarySource, valueField?: string) =>
    valueField || SOURCE_DEFAULT_FIELDS[source].valueField;

  const readByCandidates = (item: Record<string, unknown>, candidates: string[]): unknown => {
    for (const f of candidates) {
      const v = item[f];
      if (v !== undefined && v !== null && v !== '') return v;
    }
    return undefined;
  };

  /**
   * 取 source + key 对应的 items 数组。
   * dynamic 源会触发懒加载；shallowReactive 让模板加载完成自动重渲染。
   */
  const resolveItems = (source: DictionarySource, key: DictionaryType): unknown[] => {
    if (!key) return [];
    if (source === 'dynamic') {
      const k = key as DynamicDictionaryKey;
      // 缓存空 / 硬过期 → 等首次请求；命中 → 同步返回，节流触发后台刷新
      if (isStale(k)) {
        void scheduleAutoLoad(k);
      } else {
        maybeRevalidate(k);
      }
      return dynamicCache[k]?.data ?? [];
    }
    const data = resolveStaticData(source);
    if (!data) return [];
    const items = (data as Record<string, unknown[]>)[key];
    return Array.isArray(items) ? items : [];
  };

  /** 获取字典选项列表 */
  const getOptions = (key: DictionaryType, opts: GetOptionsConfig = {}): SelectOption[] => {
    const { source = defaultSource, labelField, valueField } = opts;
    const items = resolveItems(source, key);
    if (!items.length) return [];

    const lf = resolveLabelField(source, labelField);
    const vf = resolveValueField(source, valueField);

    // dynamic 源每个 key 的字段映射不一致（RoleDict 有 orgId，会污染候选探测），
    // 优先级：调用方传的 labelField/valueField > DYNAMIC_FIELD_MAP per-key 显式 > 通用候选
    const dynamicMap =
      source === 'dynamic' ? DYNAMIC_FIELD_MAP[key as DynamicDictionaryKey] : undefined;

    return items.map((raw) => {
      const item = raw as Record<string, unknown>;
      const labelKey = lf ?? dynamicMap?.label;
      const valueKey = vf ?? dynamicMap?.value;
      return {
        label: String(
          (labelKey ? item[labelKey] : undefined) ??
            readByCandidates(item, SOURCE_LABEL_CANDIDATES[source]) ??
            '',
        ),
        value: ((valueKey ? item[valueKey] : undefined) ??
          readByCandidates(item, SOURCE_VALUE_CANDIDATES[source])) as string | number,
        ...item,
      };
    });
  };

  /** 获取字典 Map (value -> option) */
  const getOptionMap = (
    key: DictionaryType,
    opts: GetOptionsConfig = {},
  ): Map<string | number, SelectOption> => {
    return new Map(getOptions(key, opts).map((opt) => [opt.value, opt]));
  };

  /** 根据 value 获取 label */
  const findLabel = (
    key: DictionaryType,
    value: string | number | undefined | null,
    opts: GetOptionsConfig = {},
  ): string => {
    if (value === undefined || value === null) return '';
    return getOptionMap(key, opts).get(value)?.label ?? String(value);
  };

  /** 获取原始字典数组（已 normalize；dynamic 源会触发懒加载） */
  const getRawData = (
    key: DictionaryType,
    source: DictionarySource = defaultSource,
  ): unknown[] | null => {
    const items = resolveItems(source, key);
    return items.length ? items : null;
  };

  return {
    loading,
    getOptions,
    getOptionMap,
    findLabel,
    getRawData,
  };
}
