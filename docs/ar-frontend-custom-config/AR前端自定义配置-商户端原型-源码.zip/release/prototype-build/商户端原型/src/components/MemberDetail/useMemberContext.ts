import { inject, provide, watch, type InjectionKey, type Ref } from 'vue';
import type { WalletSection } from './wallet/buildWalletData';

/**
 * 会员详情内部子弹窗的 zIndex。
 * 会员详情主弹窗 zIndex=6000（见 useMemberDetailModal），其内部再开的弹窗
 * （编辑备注/积分/状态、代理线、邀请人、钱包、账变、日志等）必须高于它，
 * 否则会被主弹窗盖住、层级错乱。取 6100：> 会员详情 6000，< 投注详情 7000。
 */
export const MEMBER_DETAIL_CHILD_Z_INDEX = 6100;

/**
 * 会员详情上下文 — 提供给所有 Tab 子组件使用
 *
 * MemberDetailContent.vue 调用 provideMemberContext() 注入
 * 各 Tab hooks 调用 useMemberContext() 消费
 */

/** 详情区域的通用条目结构（buildDetailData 返回的对象数组均是此形状的集合）
 *  条目字段由 buildDetailData 动态构造（key/title/label/value/highlight 等），消费方按需访问。
 *  这里允许 any 值以减少模板消费处的 unknown 收窄成本。 */
export type DetailSection = Record<string, any>;

export interface DetailData {
  /** 基础信息分组（由 buildDetailData 构建） */
  basicSections: DetailSection[];
  /** 数据统计分组（仅样板会员 1100002 试点·由 buildDetailData 抽取；非样板为空） */
  dataStatSections: DetailSection[];
  /** 充值概览条目 */
  depositInfo: DetailSection[];
  /** 提现概览条目 */
  withdrawInfo: DetailSection[];
  /** 近期充值记录 */
  recentDeposits: DetailSection[];
  /** 近期提现记录 */
  recentWithdraws: DetailSection[];
  /** 钱包分组（由 buildWalletData 构建） */
  walletSections: WalletSection[];
}

export interface MemberContext {
  /** 会员 ID */
  memberId: Ref<string | number>;
  /** 列表行的商户 ID，用于时区展示等场景 */
  tenantId: Ref<number | null>;
  /** 全局时间范围（与 MemberDetailContent props.globalTimeRange 一致） */
  globalTimeRange: Ref<number[] | null>;
  /** 当前激活的 Tab */
  activeTab: Ref<string>;
  /** 会员详情数据 */
  detailData: Ref<DetailData>;
  /** 最后提现时间 */
  lastWithdrawTime: Ref<string>;
  /** 查询版本号，上层点击"查询"时递增，各 tab 监听此值刷新数据 */
  queryVersion: Ref<number>;
}

const MEMBER_CONTEXT_KEY: InjectionKey<MemberContext> = Symbol('memberDetail:context');

/** 是否存在顶部多会员切换标签栏；BettingStatTab 等子组件靠它决定 max-height。 */
export const MEMBER_DETAIL_HAS_HISTORY_BAR: InjectionKey<Ref<boolean>> = Symbol(
  'memberDetail:hasHistoryBar',
);

/**
 * 「时间查询」下放契约（2026-07-14 用户要求·仅样板 1100002）：
 * 顶部工具栏的「日期」筛选挪进「数据统计」Tab 内渲染。
 * 注意：时间**状态仍留在 MemberDetailShell**（searchForm.timeRange），
 * 因此它照旧作为 globalTimeRange 流向 投注 / 系统日志 / 资金账变 等 Tab 的兜底时间、行为不变；
 * 这里只把「读写时间 + 触发查询」的能力下放给 Tab 内的控件。
 */
export interface MemberDetailTimeQuery {
  /** 可读写的时间范围（绑定 Shell 的 searchForm.timeRange） */
  timeRange: Ref<[number, number] | null>;
  /** 日期 picker 展示时区（按会员所属商户） */
  timezone: Ref<string | null>;
  /** 应用查询：递增 queryVersion → 当前 Tab 按新时间重新加载（与原顶部「查询」同一机制） */
  apply: () => void;
}

export const MEMBER_DETAIL_TIME_QUERY: InjectionKey<MemberDetailTimeQuery> = Symbol(
  'memberDetail:timeQuery',
);

/**
 * 在 MemberDetailContent.vue 中调用 — 向下注入会员上下文
 */
export function provideMemberContext(ctx: MemberContext) {
  provide(MEMBER_CONTEXT_KEY, ctx);
  return ctx;
}

/**
 * 在任何 Tab 子组件或 hooks 中调用 — 获取会员上下文
 */
export function useMemberContext(): MemberContext {
  const ctx = inject(MEMBER_CONTEXT_KEY);
  if (!ctx) {
    throw new Error('[useMemberContext] 必须在 provideMemberContext 的子组件中使用');
  }
  return ctx;
}

/**
 * 可选版：独立路由场景返回 undefined，嵌入到会员/订单详情弹窗时返回上下文。
 * 用于同时支持独立访问与嵌入两种身份的页面（会员层级 / 下级会员 / 银行卡 等）。
 */
export function useMemberContextOptional(): MemberContext | undefined {
  return inject(MEMBER_CONTEXT_KEY, undefined);
}

/**
 * 上层"查询"时自动刷新当前 tab 的表格
 *
 * @param tabName - 当前 tab 名称（如 'bet'、'fund'、'log'）
 * @param tableRef - ProCrudTable 的 ref
 */
export function useQueryReload(tabName: string, tableRef: Ref<{ reload?: () => void } | null>) {
  const { activeTab, queryVersion } = useMemberContext();
  watch(queryVersion, () => {
    if (activeTab.value === tabName) {
      tableRef.value?.reload?.();
    }
  });
}
