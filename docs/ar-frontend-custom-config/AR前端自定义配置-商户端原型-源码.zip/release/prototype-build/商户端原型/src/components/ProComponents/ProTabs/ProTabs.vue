<!--
/**
 * @description 业务定制 Tabs 容器。借鉴 naive-ui 视觉，但 slot-based 渲染模式让每个 ProTabPane
 *   各自常驻 DOM、用 v-show 切换，不再需要外层 <KeepAlive>。根节点通过 <n-el> 暴露主题变量
 *   （--border-color / --card-color / --text-color / --primary-color 等），明暗主题与商户主色自动跟随。
 *   组件内部封装 layout-main 高度链补丁，调用方不再需要 pageRef + add class 的 hack。
 * @date 2026-05-22
 * @scope src/components/ProComponents/ProTabs
 */
-->
<template>
  <n-el
    ref="rootRef"
    tag="div"
    :class="[
      'pro-tabs',
      `pro-tabs--${size}`,
      `pro-tabs--${type}`,
      {
        'pro-tabs--embed': embed,
        'pro-tabs--fill': fillLayoutEffective,
        'pro-tabs--borderless': !borderedEffective,
      },
    ]"
  >
    <div ref="navRef" class="pro-tabs__nav" :style="{ marginBottom: `${navGap}px` }">
      <div class="pro-tabs__nav-list">
        <div
          v-for="pane in panes"
          :key="pane.name"
          :class="[
            'pro-tabs__tab',
            {
              'pro-tabs__tab--active': pane.name === activeKey,
              'pro-tabs__tab--disabled': pane.disabled.value,
            },
          ]"
          role="tab"
          :aria-selected="pane.name === activeKey"
          :aria-disabled="pane.disabled.value"
          :tabindex="pane.disabled.value ? -1 : 0"
          @click="handleTabClick(pane)"
          @keydown.enter.prevent="handleTabClick(pane)"
          @keydown.space.prevent="handleTabClick(pane)"
        >
          {{ pane.tab.value }}
        </div>
        <div class="pro-tabs__bar" :style="barStyle" />
      </div>
    </div>

    <div ref="contentRef" class="pro-tabs__content">
      <slot />
    </div>
  </n-el>
</template>

<script setup lang="ts">
  import {
    computed,
    inject,
    nextTick,
    onActivated,
    onDeactivated,
    onMounted,
    onUnmounted,
    provide,
    ref,
    shallowReactive,
    watch,
  } from 'vue';
  import { NEl } from 'naive-ui';
  import { LayoutContentRectKey } from '@/layout/contentRectContext';
  import {
    ProTabsContextKey,
    ProTabsHeightContextKey,
    type ProTabPaneMeta,
    type ProTabsPaneRect,
  } from './context';

  defineOptions({ name: 'ProTabs' });

  const props = withDefaults(
    defineProps<{
      /** 当前激活 Tab，v-model:value */
      value: string;
      /** 视觉尺寸 */
      size?: 'small' | 'medium' | 'large';
      /**
       * 视觉风格：
       * - 'line'（默认）：底部 2px 主色下划线，简洁
       * - 'card'：物理卡片样式，激活 tab 与 content 区无缝相接（参考 naive-ui card）
       */
      type?: 'line' | 'card';
      /** 嵌入模式（如弹窗内）：去外壳 padding/bg/border-radius，且不做 layout-main 高度修补 */
      embed?: boolean;
      /** 是否占满父布局并补 layout-main 高度链；默认 !embed */
      fillLayout?: boolean;
      /**
       * 是否显示外壳边框。默认 `!embed`：独立页面有边框（视觉外壳），弹窗内嵌无边框
       * （弹窗 NCard 本身已是外壳，再叠 ProTabs 边框会显得重）。
       * 显式传 true / false 可覆盖默认。
       */
      bordered?: boolean;
      /** tab nav 与 content 之间的间距 px */
      navGap?: number;
    }>(),
    {
      size: 'small',
      type: 'line',
      embed: false,
      fillLayout: undefined,
      bordered: undefined,
      navGap: 8,
    },
  );

  const emit = defineEmits<{
    'update:value': [value: string];
    change: [value: string];
  }>();

  /** 默认行为：embed 模式不撑高，否则撑满父布局 */
  const fillLayoutEffective = computed(() => props.fillLayout ?? !props.embed);
  /** 默认行为：embed 模式不显边框，否则显边框；显式 bordered 覆盖 */
  const borderedEffective = computed(() => props.bordered ?? !props.embed);

  // 包装为内部 ref，方便 inject 给子组件（避免子组件直接接触 props）
  const activeKey = computed(() => props.value);

  // 子 pane 注册到这里。用 shallowReactive 避免 reactive 深度展开 meta 内的 ComputedRef.value
  const panes = shallowReactive<ProTabPaneMeta[]>([]);

  provide(ProTabsContextKey, {
    activeKey,
    registerPane(meta) {
      panes.push(meta);
    },
    unregisterPane(name) {
      const i = panes.findIndex((p) => p.name === name);
      if (i >= 0) panes.splice(i, 1);
    },
  });

  // ==================== 高度 context（三段模型 Block 3） ====================
  // 当前激活 pane content 区域在 viewport 中的几何信息，给未来 ProCrudTable / 图表
  // 等需要"撑满父容器"的组件 inject 用。本次只 provide，不强制任何消费者接入；
  // 没有 consumer 时 ResizeObserver 仍跑（开销可忽略），有 consumer 时直接拿值。
  const contentRef = ref<HTMLElement | null>(null);
  const paneRect = ref<ProTabsPaneRect>({ top: 0, bottom: 0, height: 0 });

  // 弹窗内 ProModalContentRect 会 provide LayoutContentRectKey（viewport-based 稳定 bottom）。
  // embed 模式下 ProTabs 自己的 contentRef 高度受循环依赖影响（父级 NCard__content 无明确
  // height + 自身依内容撑开），rect.bottom 首帧坍缩 ≈ rect.top，导致 useAutoHeight 拿到
  // ceiling 极小、actualMaxHeight 坍到 200px。此时 bottom 改用外层 layoutContent.bottom
  // 跳出循环依赖；非弹窗场景（layoutContent 来自 layout/index.vue）行为也兼容。
  const layoutContentCtx = inject(LayoutContentRectKey, null);

  function measurePaneRect() {
    const el = contentRef.value;
    if (!el) return;
    const rect = el.getBoundingClientRect();
    const layoutBottom = layoutContentCtx?.contentRect.value.bottom ?? 0;
    // embed 且 layout 提供了有效 bottom 时，bottom 优先取 layoutBottom 与 rect.bottom 的较大值，
    // 避免 contentRef 自身坍缩污染 ceiling。top 仍用 rect.top（contentRef 真实位置）。
    const useLayoutBottom = props.embed && layoutBottom > 0 && layoutBottom > rect.bottom;
    const nextBottom = useLayoutBottom ? layoutBottom : rect.bottom;
    if (
      paneRect.value.top !== rect.top ||
      paneRect.value.bottom !== nextBottom ||
      paneRect.value.height !== nextBottom - rect.top
    ) {
      paneRect.value = {
        top: rect.top,
        bottom: nextBottom,
        height: nextBottom - rect.top,
      };
    }
  }

  provide(ProTabsHeightContextKey, {
    paneRect,
  });

  // embed 模式下还要在外层 layoutContent.bottom 变化时重测 paneRect，
  // 否则 ResizeObserver 只听自己的 contentRef，外层 viewport-based ceiling 变化无感知。
  watch(
    () => layoutContentCtx?.contentRect.value.bottom ?? 0,
    () => nextTick(measurePaneRect),
  );

  function handleTabClick(pane: ProTabPaneMeta) {
    if (pane.disabled.value) return;
    if (pane.name === activeKey.value) return;
    emit('update:value', pane.name);
    emit('change', pane.name);
  }

  // ==================== 激活下划线动画 ====================
  // 借鉴 naive-ui line 类型：底部 2px 主色下划线，定位到激活 tab 元素，transform 过渡。
  const navRef = ref<HTMLElement | null>(null);
  const barStyle = ref<Record<string, string>>({
    transform: 'translateX(0px)',
    width: '0px',
    opacity: '0',
  });

  async function updateBar() {
    await nextTick();
    const nav = navRef.value;
    if (!nav) return;
    const activeEl = nav.querySelector<HTMLElement>('.pro-tabs__tab--active');
    if (!activeEl) {
      barStyle.value = { ...barStyle.value, opacity: '0' };
      return;
    }
    barStyle.value = {
      transform: `translateX(${activeEl.offsetLeft}px)`,
      width: `${activeEl.offsetWidth}px`,
      opacity: '1',
    };
  }

  watch([activeKey, () => panes.length], updateBar, { flush: 'post' });
  onMounted(updateBar);

  // 容器尺寸变化（如商户切换、收起侧边栏导致字号伸缩）→ 重新定位下划线
  let resizeObserver: ResizeObserver | null = null;
  onMounted(() => {
    if (typeof ResizeObserver === 'undefined' || !navRef.value) return;
    resizeObserver = new ResizeObserver(() => {
      updateBar();
    });
    resizeObserver.observe(navRef.value);
  });
  onUnmounted(() => {
    resizeObserver?.disconnect();
    resizeObserver = null;
  });

  // ==================== paneRect 测量触发器 ====================
  // 三处触发，缺一漏 case：
  // 1. ResizeObserver(contentEl)：pane 自身尺寸变化（layout 高度变 / tab nav 换行）
  // 2. window resize：viewport 整体变化（窗口缩放、devtools 弹出）
  // 3. 切 tab 后 nextTick：active pane 切换瞬间 content 容器视情况可能位移
  let paneResizeObserver: ResizeObserver | null = null;

  function setupPaneObserver() {
    if (typeof ResizeObserver === 'undefined' || !contentRef.value) return;
    paneResizeObserver?.disconnect();
    paneResizeObserver = new ResizeObserver(() => {
      measurePaneRect();
    });
    paneResizeObserver.observe(contentRef.value);
  }

  function handleWindowResize() {
    measurePaneRect();
  }

  onMounted(() => {
    measurePaneRect();
    setupPaneObserver();
    window.addEventListener('resize', handleWindowResize);
  });

  // 切 tab 时也重测（active pane 切换 / 数量变化都可能影响）
  watch([activeKey, () => panes.length], () => nextTick(measurePaneRect), { flush: 'post' });

  onUnmounted(() => {
    paneResizeObserver?.disconnect();
    paneResizeObserver = null;
    window.removeEventListener('resize', handleWindowResize);
  });

  // ==================== layout-main 高度链补丁 ====================
  // 默认 .layout-main 是 flex:1 + overflow:hidden，但不强制 height:100%，
  // 导致 ProCrudTable 等内部虚拟滚动无法生效。这里在 fillLayout 模式下给最近的
  // .layout-main 加一个 height:100% 的工具类，激活期间生效、离开自动撤销。
  const LAYOUT_MAIN_FIX_CLASS = 'pro-tabs-layout-main-fill';
  const rootRef = ref<{ $el?: HTMLElement } | HTMLElement | null>(null);
  let layoutMainEl: HTMLElement | null = null;

  function resolveRootEl(): HTMLElement | null {
    const raw = rootRef.value;
    if (!raw) return null;
    // n-el 在 ref 取到的是组件实例，需要从 $el 取真实 DOM
    if ('$el' in raw && raw.$el instanceof HTMLElement) return raw.$el;
    if (raw instanceof HTMLElement) return raw;
    return null;
  }

  function applyLayoutMainFix() {
    if (!fillLayoutEffective.value) return;
    const el = resolveRootEl();
    const layoutMain = el?.closest<HTMLElement>('.layout-main');
    if (!layoutMain) return;
    layoutMain.classList.add(LAYOUT_MAIN_FIX_CLASS);
    layoutMainEl = layoutMain;
  }

  function clearLayoutMainFix() {
    layoutMainEl?.classList.remove(LAYOUT_MAIN_FIX_CLASS);
    layoutMainEl = null;
  }

  onMounted(applyLayoutMainFix);
  onActivated(applyLayoutMainFix);
  onActivated(() => nextTick(measurePaneRect));
  onDeactivated(clearLayoutMainFix);
  onUnmounted(clearLayoutMainFix);
</script>

<style lang="less" scoped>
  // 由根 <n-el> 暴露 naive-ui theme vars：--border-color / --card-color / --text-color
  // / --text-color-2 / --text-color-3 / --primary-color / --primary-color-hover
  // / --cubic-bezier-ease-in-out 等，明暗主题与商户主色自动跟随
  .pro-tabs {
    display: flex;
    flex-direction: column;
    box-sizing: border-box;
    background: var(--card-color);
    border-radius: 12px;
    padding: 12px;
    color: var(--text-color);
    border: 1px solid var(--border-color);
  }

  .pro-tabs--fill {
    height: 100%;
    min-height: 0;
  }

  .pro-tabs--embed {
    background: transparent;
    border-radius: 0;
    padding: 0;
  }

  // 边框开关：默认 embed 模式无边框（弹窗内嵌时弹窗外壳已是边框，再叠一层冗余）；
  // 非 embed 模式可通过显式 :bordered="false" 关闭外框。
  .pro-tabs--borderless {
    border: none;
  }

  // ==================== 尺寸 ====================
  .pro-tabs--small .pro-tabs__tab {
    height: 28px;
    padding: 0 12px;
    font-size: 13px;
  }
  .pro-tabs--medium .pro-tabs__tab {
    height: 34px;
    padding: 0 14px;
    font-size: 14px;
  }
  .pro-tabs--large .pro-tabs__tab {
    height: 40px;
    padding: 0 16px;
    font-size: 15px;
  }

  // ==================== Nav ====================
  .pro-tabs__nav {
    flex-shrink: 0;
  }

  .pro-tabs__nav-list {
    position: relative;
    display: flex;
    align-items: center;
    gap: 4px;
  }

  .pro-tabs__tab {
    position: relative;
    display: inline-flex;
    align-items: center;
    box-sizing: border-box;
    cursor: pointer;
    user-select: none;
    color: var(--text-color-2);
    transition:
      color 0.3s var(--cubic-bezier-ease-in-out),
      background-color 0.3s var(--cubic-bezier-ease-in-out);
    outline: none;
    white-space: nowrap;

    &:hover {
      color: var(--primary-color-hover);
    }

    &:focus-visible {
      box-shadow: 0 0 0 2px var(--primary-color-suppl, var(--primary-color));
      border-radius: 4px;
    }
  }

  .pro-tabs__tab--active {
    color: var(--primary-color);
    font-weight: 500;

    &:hover {
      color: var(--primary-color);
    }
  }

  .pro-tabs__tab--disabled {
    color: var(--text-color-disabled, var(--text-color-3));
    cursor: not-allowed;

    &:hover {
      color: var(--text-color-disabled, var(--text-color-3));
    }
  }

  .pro-tabs__bar {
    position: absolute;
    bottom: -1px;
    left: 0;
    height: 2px;
    background: var(--primary-color);
    border-radius: 1px;
    pointer-events: none;
    transition:
      transform 0.3s var(--cubic-bezier-ease-in-out),
      width 0.3s var(--cubic-bezier-ease-in-out),
      opacity 0.2s var(--cubic-bezier-ease-in-out);
  }

  // ==================== Card 风格 ====================
  // 参考 naive-ui type="card"：每个 tab 是物理卡片样式，三边 border，底部 border 消失，
  // 激活 tab 用 card-color 背景与 content 区无缝相接；inactive tab 用 hover-color 弱化。
  // .pro-tabs__bar 在 card 模式下隐藏（不需要下划线）。
  .pro-tabs--card {
    .pro-tabs__nav-list {
      gap: 4px;
      border-bottom: 1px solid var(--border-color);
    }

    .pro-tabs__tab {
      border: 1px solid var(--border-color);
      border-bottom: none;
      border-radius: 6px 6px 0 0;
      background: var(--action-color, var(--body-color));
      margin-bottom: -1px;
      padding: 0 16px;
    }

    .pro-tabs__tab--active {
      background: var(--card-color);
      // 用阴影 inset 抹掉与下方 border-bottom 重合处的视觉色差（无缝相接）
      box-shadow: inset 0 -1px 0 var(--card-color);

      &:hover {
        color: var(--primary-color);
      }
    }

    // card 模式不显示下划线 bar
    .pro-tabs__bar {
      display: none;
    }
  }

  // ==================== Content ====================
  .pro-tabs__content {
    flex: 1;
    min-height: 0;
    display: flex;
    flex-direction: column;
    overflow: hidden;
  }
</style>

<style lang="less">
  // 全局工具类：消化历史上各页面散落的 xxx-layout-main-height-fix 命名分歧。
  // 仅在 ProTabs fillLayout 模式下追加到最近的 .layout-main，激活期间生效。
  .layout-main.pro-tabs-layout-main-fill {
    height: 100%;
  }
</style>
