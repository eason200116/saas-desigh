// 会员投注记录 / 三方游戏记录（商户端 tenant · game_order）功能说明书。
// 锚定 src/views/game/betRecord/index.vue + shared/useGameColumns.ts + shared/useGameTypeFilter.ts 真实控件（R53 实证、不臆造）。
// R64：本页 roles:['tenant']。特殊页：5 套游戏类型 Tab（彩票/视讯/体育/电子/棋牌），独立页把「游戏类型」下沉为搜索区首位下拉切表。
// 覆盖范围：视讯/体育/电子/棋牌 4 类共用的三方注单通用搜索/列（shared/useGameColumns）；彩票 Tab 有独立结构（useLotteryPage），本说明书未逐项展开。
// 说明：本页 shared 工厂同时被「会员详情→投注详情」弹窗 embed 复用；embed 不注入游戏类型上下文、且 PageManual 按当前路由激活，故本页锚点不影响 embed。
// 2026-07-25 电子 Tab 新增「奖励倍数」字段（列表列+筛选区间+导出Excel），仅电子 Tab 生效，视讯/体育/棋牌 3 个 Tab 不受影响（R83 arv3-executor 执行）。

import type { PageManual } from '../types';

const manual: PageManual = {
  route: 'game_order',
  title: '会员投注记录',
  overview:
    '商户端查询会员的三方游戏投注注单，分 5 套游戏类型（彩票/视讯/体育/电子/棋牌）。2026-07-18（R3）起 5 类全并入同一套统一级联管线（useThirdGamePage）：搜索区一套、不随大类变（10 维通用搜索 + 选择游戏级联多选，彩票在内）——大类切换靠「选择游戏」级联的大类层，不再有独立「游戏类型」下拉，彩票也撤掉了彩种切换/玩法类型/投注类型/XOSO 地区等专属搜索项。列按类差异：普通游戏列（本说明书字段介绍覆盖这套）；彩票沿用彩票列（含期号等）。金额 / 盈亏列。2026-07-23 本任务：列表+搜索均删除「完成状态」；新增「投注IP」（5 类均有）/「游戏通道ID」（5 类均有）；新增「注单版本号」（仅视讯/体育两类，电子/棋牌不显示）；详情弹窗新增「会员类型」（通用）与「跟单策略单号」（仅彩票）；列表列改为平铺单行（不分组表头）。2026-07-24 本任务三项：①彩票 Tab「玩法类型」列/筛选/详情弹窗三处改造为「子游戏」——数据源由假的「彩种+分钟」枚举改为真实字典（WinGo/5D/K3/TRX WinGo 按期号类型接口、新彩种按 getLotteryGameCategoryList），命名统一英文格式（如 WinGo 1M/5D 10M/Video WinGo），XOSO 沿用现有南北中三区地区概念（只改标签不改数据）；原「玩法类型」实际承载的投注内容（数字/大小/颜色/单双等）搬进详情弹窗，改名「投注内容类型」，不再占列表列。②5 个 Tab 搜索区「会员类型/用户类型」筛选新增默认值，进页默认选中「正式会员」。③5 个 Tab 搜索区下方新增一行提示文字「开始时间必选且距今不超过60天；结束时间可选，若选，与开始时间跨度不能超过30天」（纯展示，未改任何日期选择器的实际校验逻辑，maxDays 参数不变）。2026-07-25 电子 Tab 新增「奖励倍数」列+筛选区间（保留2位小数，紧跟盈亏后；仅电子 Tab 有，其余3个Tab不受影响）。',
  items: [
    // ============ 搜索区 ============
    {
      anchor: 'gameTypeFilter',
      name: '游戏类型（内部大类状态·非渲染控件）',
      group: '搜索',
      interaction:
        '2026-07-18（R3）起不再作为独立搜索下拉渲染在任何 Tab——大类切换改由「选择游戏」级联的大类层驱动（选到某大类/厂商/子游戏即定位到对应 Tab 数据）。',
      dataSource:
        '游戏大类池（本页仅 9 类，去掉 热门/精选/推荐）；仅供内部 activeMainType 状态与 Tab 映射用。',
      logic:
        '此前只在旧彩票 Tab 渲染的「游戏类型」下拉已随彩票并入统一管线（R3）一并撤除；本条保留为内部机制说明，页面上无对应可点控件（故无 data-manual 高亮目标）。',
      note: 'embed 弹窗（财务出款详情 / 会员详情投注）不注入游戏类型上下文。',
    },
    {
      anchor: 'merchant',
      name: '商户',
      group: '搜索',
      interaction: '全站统一商户控件（merchantSearchColumn）：单选、必填红星、可搜索。',
      dataSource: '全站商户主数据源。',
      logic: '进页默认预选第一家商户。',
      limit: '必填（R63）。',
    },
    {
      anchor: 'memberKeyword',
      name: '平台 / 商户会员ID',
      group: '搜索',
      interaction: '文本输入、模糊匹配。',
      dataSource: '用户输入。',
      logic:
        '合并「会员ID + 商户会员ID」为一个框，查 userId ∨ memberAccount 任一命中（2026-07-17 合并）。',
      limit: '选填；最多 50 字（inputProps searchKw）。',
    },
    {
      anchor: 'gamePath',
      name: '选择游戏（级联）',
      group: '搜索',
      interaction: '级联多选：大类 → 厂商 → 子游戏。',
      dataSource: '由 useThirdGamePage 在搜索第 3 位插入，选项按当前商户重建。',
      logic: '替代原「游戏大类 / 厂商 / 游戏名称」三个独立项，多选取并集。',
      note: 'data-manual="gamePath" 挂在 useThirdGamePage 插入的 NCascader 上（NCascader 默认 inheritAttrs，attr 落到选择框根节点）→ 点「选择游戏」即高亮本条（2026-07-18 补挂）。',
    },
    {
      anchor: 'orderNo',
      name: '游戏注单号',
      group: '搜索',
      interaction: '文本输入、模糊匹配。',
      dataSource: '用户输入。',
      logic: '按游戏注单号筛选。',
      limit: '选填；最多 50 字（searchKw）。',
    },
    {
      anchor: 'orderStatus',
      name: '订单状态（搜索）',
      group: '搜索',
      interaction: '字典下拉、可清空。',
      dataSource: '字典 orderStatusList（体育类走 sportGamesOrderStatusList）。',
      logic:
        '按订单状态筛选（搜索项 i18n = 订单状态；对应列头 i18n = 注单状态，两处文案不同、勿混）。',
      limit: '选填。',
    },
    {
      anchor: 'betAmountRange',
      name: '投注金额（区间）',
      group: '搜索',
      interaction: '数值区间输入（最小 ~ 最大）。',
      dataSource: '用户输入。',
      logic: '按投注金额区间筛选。',
      limit: '最小值 ≥ 0；最小不得大于最大（rangeError）。',
    },
    {
      name: '奖励倍数（区间，仅电子 Tab）',
      group: '搜索',
      interaction: '数值区间输入（最小 ~ 最大），控件同投注金额区间。',
      dataSource: '用户输入。',
      logic: '按奖励倍数区间筛选（2026-07-25 新增，仅电子 Tab 有此项，其余 3 个 Tab 无）。',
      limit: '选填。',
    },
    {
      anchor: 'orderSource',
      name: '注单来源（搜索）',
      group: '搜索',
      interaction: '下拉单选：普通投注 / 策略投注 / 机器人投注，可清空。',
      dataSource:
        '本地枚举（normal / strategy / robot）。2026-07-22 由技术分类（API直连/转账钱包）改为业务分类三选一，覆盖彩票 Tab 在内的 5 类共用搜索。',
      logic: '按注单来源筛选。',
      limit: '选填。',
    },
    {
      anchor: 'round',
      name: '局号',
      group: '搜索',
      interaction: '文本输入、模糊匹配。',
      dataSource: '用户输入。',
      logic: '按局号筛选。',
      limit: '选填；最多 50 字（searchKw）。',
    },
    {
      anchor: 'userType',
      name: '用户类型（搜索）',
      group: '搜索',
      interaction: '下拉单选：正式 / 试玩，可清空。',
      dataSource: '本地枚举（正式 = 1 / 试玩 = 0）。',
      logic: '按用户类型筛选。',
      limit: '选填。',
      note: '2026-07-24 本任务新增默认值：进页默认选中「正式会员」（defaultValue: 1），可手动清空/切换。',
    },
    {
      anchor: 'timeRange',
      name: '时间',
      group: '搜索',
      interaction:
        '带时间类型选择的日期范围（proSelectDateRange，跨 2 列）：可选「投注时间 / 结算时间」再选区间。',
      dataSource: '用户选择；时间类型选项来自字典 queryTimeTypeList。',
      logic: '按所选时间类型的范围筛选，默认「投注时间 + 今天」。',
      limit: '不可清空（clearable false）。',
    },
    {
      name: '时间查询提示文字',
      group: '搜索',
      interaction:
        '搜索区下方一行提示条（ProCrudTable 现成插槽 #table-alert，位置在搜索区之后、工具栏之前），纯展示。',
      dataSource: 'i18n game.betRecord.timeRangeHint 固定文案。',
      logic:
        '2026-07-24 本任务新增：文案「开始时间必选且距今不超过60天；结束时间可选，若选，与开始时间跨度不能超过30天」。2026-07-25 Eason 要求暂时隐藏，代码（useGameColumns.ts refTimeCol 的 formItemProps）已注释保留待恢复（当前已注释隐藏）。',
      note: '仅新增提示文字，未改 maxDays 参数、未加任何实际日期校验/拦截逻辑，「时间」筛选项本身行为不变。',
    },

    // ============ 行操作 ============
    {
      anchor: 'act_detail',
      name: '行操作 · 详情',
      group: '操作',
      interaction:
        '点击列表末尾「详情」按钮打开注单详情弹窗（OrderDetailModal），按 Tab 分组展示会员 / 游戏 / 该类专属字段。',
      logic:
        'useGameColumns.createThirdGameColumns 在 onDetail 存在时追加操作列（useThirdGamePage 恒传 onDetail:openDetail），故四普通 Tab 都有此按钮。',
      note: '该「详情」按钮代码里未挂 data-manual/focusManual，本条为文档记录、点击暂不触发说明书高亮。',
    },
    {
      anchor: 'export',
      name: '导出',
      group: '操作',
      interaction: '点表格右上「导出」按钮 → 展开格式下拉（Excel / CSV）→ 选定格式后触发导出。',
      dataSource:
        '导出当前搜索条件命中的注单列表；表头按列 export 元数据生成、时间按商户时区格式化。',
      logic:
        '走 useTableExport 统一处理（读列 / 参数 / 时区、下载、loading）。四普通 Tab 与彩票 Tab（含 XOSO 两处）各自的「导出」按钮都挂 data-manual="export" 指向本条。',
      note: 'ExportButton 内部 <n-button v-bind="$attrs">，故 data-manual 在各 Tab 使用处挂即可落到按钮 DOM；原型无真实文件、仅演示交互。',
    },
  ],

  // ============ 字段介绍 tab（视讯/体育/电子/棋牌通用列；列序照 shared/useGameColumns）============
  fields: [
    { name: '商户名称', def: '投注会员所属商户。' },
    { name: '会员ID', def: '投注会员的平台ID（可点进会员详情）。' },
    { name: '商户会员ID', def: '投注会员的商户侧账号。' },
    { name: '游戏厂商', def: '该注单的游戏厂商。' },
    { name: '游戏名称', def: '投注的具体游戏名称。' },
    { name: '游戏编码', def: '游戏的编码。' },
    { name: '币种', def: '投注 / 结算币种。' },
    { name: '供应商', def: '提供该游戏的供应商。' },
    {
      name: '游戏通道ID',
      def: '该注单走的接入通道ID（2026-07-22 由「通道ID」更名，与详情弹窗字段名对齐）。',
    },
    { name: '游戏订单号', def: '一笔注单的唯一订单号。' },
    { name: '游戏通道ID', def: '该注单走的接入通道ID（2026-07-23 扩至 5 个 Tab 均有）。' },
    { name: '注单状态', def: '注单结算状态（字典标签，语义色 Tag）。' },
    { name: '投注金额', def: '该注单的投注额（可排序）。' },
    { name: '有效投注', def: '计入流水的有效投注额。' },
    { name: '派彩金额', def: '该注单的派彩额。' },
    { name: '盈亏', def: '会员在该注单上的净输赢（赢绿输红，可排序）。' },
    {
      name: '奖励倍数',
      def: '该注单命中的奖励倍数，保留2位小数，无值显示"--"（2026-07-25 新增，仅电子 Tab 有此列，紧跟盈亏后；其余视讯/体育/棋牌 3 个 Tab 无）。',
    },
    { name: '税收', def: '该注单收取的手续费 / 税额（仅棋牌 Tab）。' },
    { name: '局号', def: '该注单所属的游戏局号（视讯/棋牌）。' },
    { name: '投注IP', def: '该笔投注请求的来源 IP（5 个 Tab 均有）。' },
    { name: '投注时间', def: '下注时间（按商户时区展示）。' },
    { name: '结算时间', def: '注单结算时间（未结算显示 --）。' },
    { name: '创建时间', def: '注单记录创建时间。' },
    { name: '更新时间', def: '注单记录最近更新时间。' },
    {
      name: '注单版本号',
      def: '三方厂商返回的注单版本号，用于对账（2026-07-23 收窄为仅视讯/体育两个 Tab 显示，电子/棋牌不显示此列）。',
    },
  ],
};

export default manual;
