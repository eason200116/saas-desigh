// 防封救援（商户端 tenant · operations_domainRescue）功能说明书。
// 锚定 src/views/operations/domainRescue/index.vue + DomainRescueFormModal.vue + data.ts 真实控件（R53 实证、不臆造）。
// V3 新增功能，V1旧后台无对应模块。

import type { PageManual } from '../types';

const manual: PageManual = {
  route: 'operations_domainRescue',
  title: '防封救援',
  overview:
    '商户端「运营管理 › 防封救援」页，配置主域名的备用救援方案（备用域名池+检测间隔+自动救援开关），' +
    '当主域名被封锁时自动/引导切换到备用域名，列表展示每条救援配置当前的生效域名/救援状态/累计切换次数。' +
    '2026-07-22核实代码发现：新增/编辑保存(saveDomainRescue)、删除(deleteDomainRescue)、关闭(disableDomainRescue)' +
    '三个操作均只返回成功、不真正写回底层数组ALL_LIST，操作提示成功但列表刷新后看不到变化。如实记录，未修复。',
  items: [
    {
      anchor: 'merchant',
      name: '商户',
      group: '搜索',
      interaction: '下拉筛选。',
    },
    {
      anchor: 'mainDomain',
      name: '主域名',
      group: '搜索',
      interaction: '文本框，可清空，模糊匹配。',
    },
    {
      anchor: 'rescueState',
      name: '救援状态',
      group: '搜索',
      interaction: '下拉单选，可清空；选项：正常/已切换。',
    },
    {
      anchor: 'createTime',
      name: '创建时间',
      group: '搜索',
      interaction: '日期时间区间选择，精确到秒，最长跨度90天，不允许选未来日期。',
      limit: '最长跨度90天。',
    },
    {
      anchor: 'reset',
      name: '重置',
      group: '搜索',
      interaction: 'ProCrudTable内置重置按钮。',
    },
    {
      anchor: 'act_add',
      name: '新增',
      group: '操作',
      interaction: '主色按钮，点击打开新增弹窗（440px宽）。',
      logic:
        '弹窗字段：商户(可多选) → 主域名 → 备用域名(多行文本域，一行一个域名，换行分隔，≤500字) → ' +
        '检测间隔(数字，单位分钟，最小1) → 自动救援(开关) → 状态(开关)。',
    },
    {
      anchor: 'act_rescueRecord',
      name: '救援记录',
      group: '操作',
      interaction: '每行常驻，蓝色按钮，点击打开只读详情弹窗。',
      logic: '弹窗以描述列表展示该条配置的主域名/当前生效域名/救援方案/弹窗方式/救援奖金/累计救援人数/累计切换次数/最近切换时间。',
    },
    {
      anchor: 'act_edit',
      name: '编辑',
      group: '操作',
      interaction: '每行常驻，点击打开编辑弹窗（字段同新增，回显当前值）。',
    },
    {
      anchor: 'act_disable',
      name: '关闭',
      group: '操作',
      interaction: '每行常驻，橙色按钮，点击弹二次确认。',
    },
    {
      anchor: 'act_delete',
      name: '删除',
      group: '操作',
      interaction: '每行常驻，红色按钮，点击弹二次确认。',
    },
  ],
  fields: [
    { name: '商户（列）', def: '该救援配置所属商户，标签展示。' },
    { name: 'ID', def: '该救援配置记录的唯一编号。' },
    { name: '主域名', def: '被保护的主域名。' },
    { name: '备用域名', def: '配置的备用域名池，多行截断展示，悬停看全。' },
    { name: '当前生效域名', def: '当前实际对外提供服务的域名（正常态=主域名，已切换态=某个备用域名）。' },
    { name: '落地页类型', def: '救援跳转的落地页样式：谷歌页/苹果页/H5页。' },
    { name: '救援方案', def: '触发救援时采取的处理方案（自动切换/弹窗引导/客服介入）。' },
    { name: '弹窗方式', def: '救援提示的展现方式：自动弹出/点击触发。' },
    { name: '救援奖金', def: '因域名切换给受影响会员发放的补偿金额。' },
    { name: '累计救援人数', def: '该配置历史累计触发救援保护的会员数量。' },
    { name: '救援状态', def: '正常(绿)/已切换(橙)。' },
    { name: '累计切换次数', def: '该配置历史累计触发域名切换的次数。' },
    { name: '最近切换时间', def: '最近一次触发域名切换的时间，未切换过显示"-"。' },
    { name: '创建人', def: '创建该救援配置的操作人账号。' },
    { name: '创建时间', def: '该救援配置的创建时间。' },
    { name: '状态', def: '启用(绿)/停用(灰)，只读展示，恒排最后一个数据列。' },
  ],
};

export default manual;
