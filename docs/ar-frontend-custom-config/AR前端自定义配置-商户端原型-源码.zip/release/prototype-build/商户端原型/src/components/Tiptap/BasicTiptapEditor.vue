<template>
  <n-el
    tag="div"
    class="basic-tiptap-editor flex flex-col gap-2.5"
    :class="{ 'basic-tiptap-editor--fullscreen': isFullscreen }"
  >
    <div
      v-if="isTranslateMode && showLabel"
      class="basic-tiptap-editor__translate-head flex flex-wrap items-center justify-between gap-3"
    >
      <div class="flex min-w-0 flex-1 items-center gap-3">
        <span v-if="fieldLabel" class="basic-tiptap-editor__translate-label text-sm font-medium">
          {{ fieldLabel }}
        </span>
        <n-button
          v-if="showTranslateAction"
          size="small"
          secondary
          class="rounded-lg"
          :loading="translating"
          @click="handleTranslateAll"
        >
          {{ t('common.translate.aiTranslate') }}
        </n-button>
      </div>
      <n-radio-group v-model:value="currentLang" size="small">
        <n-radio-button v-for="lang in sortedLanguages" :key="lang.code" :value="lang.code">
          {{ lang.name }}
        </n-radio-button>
      </n-radio-group>
    </div>

    <TiptapToolbar
      v-if="showToolbar"
      :editor="editor"
      :refresh-key="editorTick"
      :disabled="disabled"
      :readonly="readonly"
      :show-image="profileConfig.allowImages"
      :show-table="profileConfig.allowTables"
      :show-preview="showPreview"
      :is-fullscreen="isFullscreen"
      :quick-actions="quickActions"
      @link="handleLinkRequest"
      @image="handleImageRequest"
      @source="openSourceModal"
      @preview="openPreviewModal"
      @fullscreen="toggleFullscreen"
      @quick-action="handleQuickAction"
    />

    <n-modal
      v-model:show="showSourceModal"
      preset="card"
      :title="t('common.tiptap.sourceTitle')"
      style="width: min(1180px, 94vw)"
      :mask-closable="true"
    >
      <HtmlCodeEditorPanel
        :initial-code="sourceCodeDraft"
        :preview-height="sourcePreviewHeight"
        @change="sourceCodeDraft = $event"
      />

      <template #footer>
        <div class="flex justify-end gap-2.5">
          <n-button @click="showSourceModal = false">
            {{ t('common.translate.cancel') }}
          </n-button>
          <n-button type="primary" @click="applySourceCode">
            {{ t('common.translate.confirm') }}
          </n-button>
        </div>
      </template>
    </n-modal>

    <n-modal
      v-model:show="showPreviewModal"
      preset="card"
      :title="t('common.tiptap.previewTitle')"
      style="width: min(760px, 88vw)"
      :mask-closable="true"
    >
      <RichTextPreview
        :html="previewHtml"
        :height="Math.max(resolvedHeight, 320)"
        :show-theme-toggle="showPreviewTheme"
      />
    </n-modal>

    <div
      ref="surfaceRef"
      class="basic-tiptap-editor__surface relative rounded-xl transition-[border-color,box-shadow,background-color] duration-200"
      :class="[
        isFullscreen
          ? 'min-h-0 flex-1 overflow-hidden'
          : fixedHeight
            ? 'basic-tiptap-editor__surface--fixed'
            : 'min-h-[var(--tiptap-editor-height)] overflow-hidden',
        { 'basic-tiptap-editor__surface--disabled': disabled },
      ]"
      :style="editorStyle"
    >
      <div ref="hostRef" class="basic-tiptap-editor__content" />

      <div
        v-if="selectionBubbleStyle && selectionAiActions.length && !disabled && !readonly"
        class="basic-tiptap-editor__selection-bubble absolute z-20 flex items-center gap-1 rounded-2xl border p-1.5 shadow-xl backdrop-blur"
        :style="selectionBubbleStyle"
      >
        <button
          v-for="action in selectionAiActions"
          :key="action.key"
          type="button"
          class="basic-tiptap-editor__selection-action rounded-xl px-2.5 py-1.5 text-xs font-medium transition-colors"
          @click="openAiAction(action.key)"
        >
          {{ action.label }}
        </button>
      </div>

      <div
        v-if="slashPanel"
        class="basic-tiptap-editor__slash-panel absolute z-20 w-[min(420px,calc(100%-16px))] overflow-hidden rounded-2xl border shadow-2xl backdrop-blur"
        :style="slashPanelStyle"
      >
        <div class="basic-tiptap-editor__slash-panel-title border-b px-3 py-2 text-xs">
          {{ t('common.tiptap.slashPanelTitle') }}
        </div>
        <div class="max-h-[320px] overflow-y-auto p-2">
          <button
            v-for="(item, index) in slashPanel.items"
            :key="item.key"
            type="button"
            class="basic-tiptap-editor__slash-item flex w-full items-start gap-3 rounded-xl px-3 py-2 text-left transition-colors"
            :class="index === slashActiveIndex ? 'basic-tiptap-editor__slash-item--active' : ''"
            @mouseenter="slashActiveIndex = index"
            @click="runSlashItem(item.key)"
          >
            <span
              class="basic-tiptap-editor__slash-item-icon mt-0.5 inline-flex size-8 shrink-0 items-center justify-center rounded-lg"
            >
              <n-icon v-if="item.icon"><component :is="item.icon" /></n-icon>
              <n-icon v-else><AppstoreAddOutlined /></n-icon>
            </span>
            <span class="min-w-0 flex-1">
              <span class="block text-sm font-medium">{{ item.label }}</span>
              <span class="basic-tiptap-editor__slash-item-desc mt-0.5 block text-xs leading-5">
                {{ item.description }}
              </span>
            </span>
          </button>
        </div>
      </div>
    </div>

    <div class="basic-tiptap-editor__status flex flex-col gap-2 px-1 text-xs">
      <!-- 统计信息（左）与外部附加信息插槽（右）同行、顶部对齐；插槽内容随语言长度自适应换行 -->
      <div
        class="basic-tiptap-editor__metrics-row flex w-full flex-wrap items-start justify-between gap-x-4 gap-y-1"
      >
        <div class="basic-tiptap-editor__metrics inline-flex items-center gap-3">
          <span>{{ t('common.tiptap.charCount', { count: charCount }) }}</span>
          <span>{{ t('common.tiptap.wordCount', { count: wordCount }) }}</span>
        </div>
        <div v-if="$slots['status-extra']" class="basic-tiptap-editor__status-extra">
          <slot name="status-extra" />
        </div>
      </div>
      <div v-if="showSlashHint" class="basic-tiptap-editor__hint">
        {{ t('common.tiptap.slashHint') }}
      </div>
    </div>
  </n-el>
</template>

<script setup lang="ts">
  import { AppstoreAddOutlined } from '@vicons/antd';
  import HtmlCodeEditorPanel from '@/components/CodeEditor/HtmlCodeEditorPanel.vue';
  import RichTextPreview from '@/components/PhonePreview/RichTextPreview.vue';
  import type { TranslateLanguage } from '@/components/Translate/shared';
  import TiptapToolbar from './TiptapToolbar.vue';
  import { useBasicTiptapEditor } from './composables';
  import type {
    BasicTiptapEditorExpose,
    TiptapEditorProfile,
    TiptapImageUploadHandler,
  } from './types';

  interface Props {
    modelValue?: string;
    placeholder?: string;
    disabled?: boolean;
    readonly?: boolean;
    height?: string | number;
    /** 固定高度：开启后编辑区高度锁死为 height、内容超出内部滚动，不再随内容变高（默认关=随内容自适应） */
    fixedHeight?: boolean;
    profile?: TiptapEditorProfile;
    showToolbar?: boolean;
    showPreview?: boolean;
    /** 预览弹层是否展示浅色/深色切换（默认展示） */
    showPreviewTheme?: boolean;
    /** 是否展示底部「输入 / 唤起插入面板」提示（默认展示） */
    showSlashHint?: boolean;
    uploadImage?: TiptapImageUploadHandler;
    /** 提供此 prop 后启用多语言编辑模式 */
    translateModelValue?: Record<string, string>;
    fieldLabel?: string;
    showLabel?: boolean;
    languageList?: TranslateLanguage[];
    sourceLanguage?: string;
    showTranslateAction?: boolean;
  }

  const props = withDefaults(defineProps<Props>(), {
    modelValue: '',
    placeholder: '',
    disabled: false,
    readonly: false,
    height: 320,
    fixedHeight: false,
    profile: 'basic',
    showToolbar: true,
    showPreview: true,
    showPreviewTheme: true,
    showSlashHint: true,
    uploadImage: undefined,
    translateModelValue: undefined,
    fieldLabel: '',
    showLabel: true,
    languageList: undefined,
    sourceLanguage: 'zh',
    showTranslateAction: true,
  });

  const emit = defineEmits<{
    'update:modelValue': [value: string];
    change: [value: string];
    ready: [];
    'update:translateModelValue': [value: Record<string, string>];
    translateChange: [value: Record<string, string>];
  }>();

  const {
    t,
    // Translate mode
    isTranslateMode,
    currentLang,
    sortedLanguages,
    translating,
    handleTranslateAll,
    // Core refs
    surfaceRef,
    hostRef,
    editor,
    editorTick,
    // UI state
    isFullscreen,
    showPreviewModal,
    showSourceModal,
    sourceCodeDraft,
    slashActiveIndex,
    profileConfig,
    resolvedHeight,
    editorStyle,
    sourcePreviewHeight,
    // Derived data
    previewHtml,
    charCount,
    wordCount,
    quickActions,
    selectionAiActions,
    slashPanel,
    slashPanelStyle,
    selectionBubbleStyle,
    // Methods
    handleLinkRequest,
    handleImageRequest,
    openSourceModal,
    applySourceCode,
    openPreviewModal,
    toggleFullscreen,
    handleQuickAction,
    openAiAction,
    runSlashItem,
    // Expose
    expose: exposeApi,
  } = useBasicTiptapEditor(props, emit);

  // Suppress "unused variable" warnings — these refs are consumed by the template
  void hostRef;
  void surfaceRef;

  defineExpose<BasicTiptapEditorExpose>(exposeApi);
</script>

<style scoped lang="less">
  .basic-tiptap-editor {
    container-type: inline-size;
    container-name: tiptap-editor;
    color: var(--text-color);
  }

  .basic-tiptap-editor--fullscreen {
    position: fixed;
    inset: 1rem;
    z-index: 2100;
    padding: 1rem;
    border-radius: 1.5rem;
    background: linear-gradient(180deg, var(--body-color), var(--card-color));
    box-shadow:
      0 16px 40px rgba(15, 23, 42, 0.18),
      0 2px 8px rgba(15, 23, 42, 0.1);
  }

  .basic-tiptap-editor__translate-head {
    padding: 0 2px;
  }

  .basic-tiptap-editor__translate-label {
    color: #333639;
  }

  .basic-tiptap-editor__surface {
    border: 1px solid var(--border-color);
    background: var(--card-color);
  }

  // 固定高度模式：高度锁死为 --tiptap-editor-height，内容超出内部滚动（不随内容变高）
  .basic-tiptap-editor__surface--fixed {
    height: var(--tiptap-editor-height);
    overflow-y: auto;
  }

  .basic-tiptap-editor__surface:focus-within {
    border-color: var(--ui-accent-solid);
    box-shadow: 0 0 0 3px var(--ui-focus-ring);
  }

  .basic-tiptap-editor__surface--disabled {
    background: var(--action-color);
  }

  .basic-tiptap-editor__selection-bubble {
    border-color: var(--border-color);
    background: var(--popover-color);
  }

  .basic-tiptap-editor__selection-action {
    color: var(--text-color-2);
  }

  .basic-tiptap-editor__selection-action:hover {
    background: var(--ui-accent-soft);
    color: var(--ui-accent-solid);
  }

  .basic-tiptap-editor__slash-panel {
    border-color: var(--border-color);
    background: var(--popover-color);
  }

  .basic-tiptap-editor__slash-panel-title {
    border-color: var(--divider-color);
    color: var(--text-color-3);
  }

  .basic-tiptap-editor__slash-item {
    color: var(--text-color-2);
  }

  .basic-tiptap-editor__slash-item:hover,
  .basic-tiptap-editor__slash-item--active {
    background: var(--ui-accent-soft);
    color: var(--ui-accent-solid);
  }

  .basic-tiptap-editor__slash-item-icon {
    background: var(--action-color);
    color: var(--text-color-2);
  }

  .basic-tiptap-editor__slash-item-desc,
  .basic-tiptap-editor__status {
    color: var(--text-color-2);
  }

  .basic-tiptap-editor__hint {
    color: var(--text-color-3);
  }

  .basic-tiptap-editor__content {
    min-height: var(--tiptap-editor-height);
  }

  .basic-tiptap-editor__content :deep(.ar-tiptap-editor__content) {
    min-height: var(--tiptap-editor-height);
    padding: 14px 16px;
    outline: none;
    color: initial;
    line-height: 1.75;
    word-break: break-word;
  }

  .basic-tiptap-editor__content :deep(.ProseMirror) {
    min-height: var(--tiptap-editor-height);
    outline: none;
  }

  .basic-tiptap-editor__content :deep(.ProseMirror::selection),
  .basic-tiptap-editor__content :deep(.ProseMirror *::selection) {
    background: Highlight;
    color: HighlightText;
  }

  .basic-tiptap-editor__content :deep(.ProseMirror-selectednode) {
    outline: 2px solid rgba(148, 163, 184, 0.45);
    outline-offset: 2px;
  }

  .basic-tiptap-editor__content :deep(.ProseMirror p.is-editor-empty:first-child::before) {
    content: attr(data-placeholder);
    float: left;
    color: var(--text-color-3);
    pointer-events: none;
    height: 0;
  }

  .basic-tiptap-editor__content :deep(.ProseMirror h1),
  .basic-tiptap-editor__content :deep(.ProseMirror h2),
  .basic-tiptap-editor__content :deep(.ProseMirror h3) {
    margin: 0.75em 0 0.45em;
    line-height: 1.35;
    font-weight: 700;
  }

  .basic-tiptap-editor__content :deep(.ProseMirror h1) {
    font-size: 26px;
  }

  .basic-tiptap-editor__content :deep(.ProseMirror h2) {
    font-size: 22px;
  }

  .basic-tiptap-editor__content :deep(.ProseMirror h3) {
    font-size: 18px;
  }

  .basic-tiptap-editor__content :deep(.ProseMirror p),
  .basic-tiptap-editor__content :deep(.ProseMirror ul),
  .basic-tiptap-editor__content :deep(.ProseMirror ol),
  .basic-tiptap-editor__content :deep(.ProseMirror blockquote),
  .basic-tiptap-editor__content :deep(.ProseMirror table),
  .basic-tiptap-editor__content :deep(.ProseMirror div[data-type='callout-block']),
  .basic-tiptap-editor__content :deep(.ProseMirror p[data-type='status-block']),
  .basic-tiptap-editor__content :deep(.ProseMirror div[data-type='date-block']),
  .basic-tiptap-editor__content :deep(.ProseMirror div[data-type='ops-columns']) {
    margin: 0.65em 0;
  }

  .basic-tiptap-editor__content :deep(.ProseMirror ul),
  .basic-tiptap-editor__content :deep(.ProseMirror ol) {
    padding-left: 1.4em;
  }

  .basic-tiptap-editor__content :deep(.ProseMirror blockquote) {
    padding: 10px 14px;
    border-left: 4px solid rgba(148, 163, 184, 0.6);
    border-radius: 8px;
    background: rgba(148, 163, 184, 0.08);
  }

  .basic-tiptap-editor__content :deep(.ProseMirror a) {
    color: LinkText;
    text-decoration: underline;
  }

  .basic-tiptap-editor__content :deep(.ProseMirror img) {
    display: block;
    max-width: 100%;
    height: auto;
    border-radius: 10px;
  }

  .basic-tiptap-editor__content :deep(.ProseMirror table) {
    width: 100%;
    border-collapse: collapse;
    table-layout: fixed;
    overflow: hidden;
  }

  .basic-tiptap-editor__content :deep(.ProseMirror th),
  .basic-tiptap-editor__content :deep(.ProseMirror td) {
    border: 1px solid rgba(148, 163, 184, 0.24);
    padding: 8px 10px;
    vertical-align: top;
  }

  .basic-tiptap-editor__content :deep(.ProseMirror th) {
    background: rgba(148, 163, 184, 0.08);
    font-weight: 600;
  }

  .basic-tiptap-editor__content :deep(.ProseMirror .tiptap-callout) {
    border-radius: 16px;
    padding: 14px 16px;
    border: 1px solid rgba(148, 163, 184, 0.18);
    background: linear-gradient(135deg, rgba(248, 250, 252, 0.98), rgba(241, 245, 249, 0.96));
  }

  .basic-tiptap-editor__content :deep(.ProseMirror .tiptap-callout--info) {
    border-color: rgba(14, 165, 233, 0.22);
    background: linear-gradient(135deg, rgba(240, 249, 255, 0.98), rgba(224, 242, 254, 0.9));
  }

  .basic-tiptap-editor__content :deep(.ProseMirror .tiptap-callout--success) {
    border-color: rgba(34, 197, 94, 0.22);
    background: linear-gradient(135deg, rgba(240, 253, 244, 0.98), rgba(220, 252, 231, 0.9));
  }

  .basic-tiptap-editor__content :deep(.ProseMirror .tiptap-callout--warning) {
    border-color: rgba(245, 158, 11, 0.22);
    background: linear-gradient(135deg, rgba(255, 251, 235, 0.98), rgba(254, 243, 199, 0.9));
  }

  .basic-tiptap-editor__content :deep(.ProseMirror .tiptap-status) {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    border-radius: 999px;
    padding: 8px 14px;
    font-weight: 600;
    border: 1px solid rgba(14, 165, 233, 0.18);
    background: rgba(14, 165, 233, 0.08);
    color: #0369a1;
  }

  .basic-tiptap-editor__content :deep(.ProseMirror .tiptap-status--success) {
    border-color: rgba(34, 197, 94, 0.2);
    background: rgba(34, 197, 94, 0.12);
    color: #15803d;
  }

  .basic-tiptap-editor__content :deep(.ProseMirror .tiptap-status--warning) {
    border-color: rgba(245, 158, 11, 0.2);
    background: rgba(245, 158, 11, 0.12);
    color: #b45309;
  }

  .basic-tiptap-editor__content :deep(.ProseMirror .tiptap-date-block) {
    border-radius: 16px;
    border: 1px solid rgba(148, 163, 184, 0.18);
    background: linear-gradient(180deg, rgba(255, 255, 255, 0.98), rgba(248, 250, 252, 0.96));
    padding: 14px 16px;
  }

  .basic-tiptap-editor__content :deep(.ProseMirror .tiptap-date-block__meta) {
    font-size: 12px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 0.06em;
    opacity: 0.58;
  }

  .basic-tiptap-editor__content :deep(.ProseMirror .tiptap-date-block__value) {
    margin-top: 4px;
    font-size: 18px;
    font-weight: 700;
    color: inherit;
  }

  .basic-tiptap-editor__content :deep(.ProseMirror .tiptap-date-block__note) {
    margin-top: 8px;
    opacity: 0.72;
  }

  .basic-tiptap-editor__content :deep(.ProseMirror .tiptap-columns) {
    display: grid;
    grid-template-columns: repeat(2, minmax(0, 1fr));
    gap: 14px;
  }

  .basic-tiptap-editor__content :deep(.ProseMirror .tiptap-columns__item) {
    min-width: 0;
    border-radius: 16px;
    border: 1px solid rgba(148, 163, 184, 0.16);
    background: rgba(248, 250, 252, 0.85);
    padding: 12px 14px;
  }

  @container tiptap-editor (max-width: 767px) {
    .basic-tiptap-editor__status {
      align-items: flex-start;
    }

    .basic-tiptap-editor__metrics {
      flex-wrap: wrap;
    }

    .basic-tiptap-editor__content :deep(.ProseMirror .tiptap-columns) {
      grid-template-columns: 1fr;
    }
  }

  @container tiptap-editor (min-width: 768px) {
    .basic-tiptap-editor__status {
      flex-direction: row;
      align-items: center;
      justify-content: space-between;
    }
  }
</style>
