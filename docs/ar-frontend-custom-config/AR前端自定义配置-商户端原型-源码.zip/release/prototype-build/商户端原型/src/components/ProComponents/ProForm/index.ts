import ProForm from './ProForm.vue';

export { ProForm };
export default ProForm;
