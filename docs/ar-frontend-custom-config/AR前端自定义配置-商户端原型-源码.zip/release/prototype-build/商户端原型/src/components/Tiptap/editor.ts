import { computed, onBeforeUnmount, onMounted, ref, shallowRef, watch, type Ref } from 'vue';
import { Editor } from '@tiptap/core';
import { createTiptapExtensions } from './extensions';
import { getInitialEditorHtml, normalizeEditorHtml } from './html';
import type { TiptapEditorProfile } from './types';

interface UseTiptapEditorOptions {
  content: Ref<string>;
  editable: Ref<boolean>;
  placeholder: Ref<string>;
  profile: Ref<TiptapEditorProfile>;
  onUpdate: (value: string) => void;
  onReady?: () => void;
}

export function useTiptapEditor(options: UseTiptapEditorOptions) {
  const hostRef = ref<HTMLElement | null>(null);
  const editorRef = shallowRef<Editor | null>(null);
  const editorTick = ref(0);
  const isSyncingExternal = ref(false);

  const normalizedContent = computed(() => normalizeEditorHtml(options.content.value));

  const bumpEditorTick = () => {
    editorTick.value += 1;
  };

  const createEditor = () => {
    const editor = new Editor({
      element: null,
      content: getInitialEditorHtml(options.content.value),
      editable: options.editable.value,
      extensions: createTiptapExtensions({
        profile: options.profile,
        placeholder: options.placeholder,
      }),
      editorProps: {
        attributes: {
          class: 'ar-tiptap-editor__content',
        },
      },
      onCreate: () => {
        bumpEditorTick();
        options.onReady?.();
      },
      onUpdate: ({ editor: currentEditor }) => {
        if (isSyncingExternal.value) {
          bumpEditorTick();
          return;
        }

        options.onUpdate(normalizeEditorHtml(currentEditor.getHTML()));
        bumpEditorTick();
      },
      onSelectionUpdate: bumpEditorTick,
      onFocus: bumpEditorTick,
      onBlur: bumpEditorTick,
      onTransaction: bumpEditorTick,
    });

    if (hostRef.value) {
      editor.mount(hostRef.value);
    }

    editorRef.value = editor;
  };

  const destroyEditor = () => {
    editorRef.value?.destroy();
    editorRef.value = null;
  };

  function focus() {
    editorRef.value?.commands.focus();
  }

  function getHTML() {
    return editorRef.value
      ? normalizeEditorHtml(editorRef.value.getHTML())
      : normalizedContent.value;
  }

  function getJSON() {
    return editorRef.value?.getJSON() || null;
  }

  function setHTML(html: string) {
    const editor = editorRef.value;
    if (!editor) return;

    isSyncingExternal.value = true;
    editor.commands.setContent(getInitialEditorHtml(html), { emitUpdate: false });
    isSyncingExternal.value = false;
    bumpEditorTick();
  }

  function insertContent(content: string) {
    editorRef.value?.chain().focus().insertContent(getInitialEditorHtml(content)).run();
  }

  function replaceSelection(content: string) {
    editorRef.value
      ?.chain()
      .focus()
      .deleteSelection()
      .insertContent(getInitialEditorHtml(content))
      .run();
  }

  function getSelectionText() {
    const editor = editorRef.value;
    if (!editor) return '';

    const { from, to } = editor.state.selection;
    return editor.state.doc.textBetween(from, to, ' ');
  }

  onMounted(() => {
    createEditor();
  });

  onBeforeUnmount(() => {
    destroyEditor();
  });

  watch(normalizedContent, (nextHtml) => {
    const editor = editorRef.value;
    if (!editor) return;

    const currentHtml = normalizeEditorHtml(editor.getHTML());
    if (currentHtml === nextHtml) return;

    isSyncingExternal.value = true;
    editor.commands.setContent(getInitialEditorHtml(nextHtml), { emitUpdate: false });
    isSyncingExternal.value = false;
    bumpEditorTick();
  });

  watch(
    options.editable,
    (nextEditable) => {
      editorRef.value?.setEditable(nextEditable, false);
      bumpEditorTick();
    },
    { immediate: true },
  );

  return {
    hostRef,
    editor: editorRef,
    editorTick,
    focus,
    getHTML,
    getJSON,
    setHTML,
    insertContent,
    replaceSelection,
    getSelectionText,
  };
}
