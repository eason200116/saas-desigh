<script setup lang="ts">
  /**
   * 数值卡片
   * 包装 StatTrendCard 组件
   */
  import StatTrendCard from '../StatTrendCard.vue';
  interface Props {
    title: string;
    statisticList?: any[];
    loading?: boolean;
  }

  const props = withDefaults(defineProps<Props>(), {
    loading: false,
  });
</script>

<template>
  <n-spin :show="loading">
    <StatTrendCard :title="title" :statistic-list="statisticList" :show-chart="true" />
  </n-spin>
</template>

<script lang="ts">
  export default {
    name: 'NumberCard',
  };
</script>
