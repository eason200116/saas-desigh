<template>
  <div
    class="pro-drag-handle"
    :class="{ 'is-disabled': disabled }"
    :style="{ cursor: disabled ? 'not-allowed' : 'grab' }"
  >
    <n-icon :size="16">
      <HolderOutlined />
    </n-icon>
  </div>
</template>

<script lang="ts" setup>
  import { NIcon } from 'naive-ui';
  import { HolderOutlined } from '@vicons/antd';

  defineOptions({
    name: 'ProDragHandle',
  });

  defineProps({
    /** 禁用 */
    disabled: {
      type: Boolean,
      default: false,
    },
  });
</script>

<style lang="less" scoped>
  .pro-drag-handle {
    display: flex;
    align-items: center;
    justify-content: center;
    color: #999;
    transition: color 0.2s;

    &:hover:not(.is-disabled) {
      color: var(--n-primary-color);
    }

    &.is-disabled {
      opacity: 0.5;
    }
  }
</style>
