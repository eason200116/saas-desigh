/**
 * @description 会员详情弹窗内：把「当前会员所属商户(tenantId)」的时区写入表格时区上下文，
 * 让 proDateRange 等时间控件按会员商户时区展示，而非全局默认商户。
 * 弹窗内商户被锁定、无 tenantSelect，无法由 ProCrudTable 自动写入时区，需手动 setTimezoneId
 * （对齐 src/views/system/log 的写法；ProCrudTable 自身不做 tenantId → timezone 派生）。
 * @scope 仅供 src/components/MemberDetail 各 tab 复用。
 */
import { watch, type Ref } from 'vue';
import { useTenantOptions } from '@/hooks';
import type { ProCrudTableInstance, Recordable } from '@/components';
import { useMemberContext } from './useMemberContext';

export function useMemberTableTimezone<T extends Recordable = Recordable>(
  tableRef: Ref<ProCrudTableInstance<T> | null>,
) {
  const { tenantId } = useMemberContext();
  const { getTenantTimeZone } = useTenantOptions();

  // tableRef 挂载完成或会员商户变化时，把会员商户时区写入表格上下文；
  // tenantId 为空时写 null，由表格回退默认商户时区（与改动前行为一致）。
  watch(
    [tableRef, tenantId],
    () => {
      const id = tenantId.value;
      tableRef.value?.setTimezoneId(id != null ? getTenantTimeZone(id) || null : null);
    },
    { immediate: true, flush: 'post' },
  );
}
