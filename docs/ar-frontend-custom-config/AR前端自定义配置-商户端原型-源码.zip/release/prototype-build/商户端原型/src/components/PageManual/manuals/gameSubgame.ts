// 子游戏管理（总控端 admin · game_subgame）功能说明书。
// 锚定 src/views/game/subgame/index.vue + data.ts + components/SubGameEditModal.vue 真实控件（R53 实证、不臆造）。
// 标准 ProCrudTable 列表页：11 搜索项 + 18 列（2026-07-27 新增「支持设备端」「支持横竖屏」两列后由 16 列更正为 18 列，
// 经 awk/grep 实数核对）+ 顶部工具栏「批量启用 / 批量禁用」(配合 row-selection 多选)
// + 1 行操作「编辑」。本页没有「新增」按钮 —— 子游戏身份取自共享池 gameSubgamePool，非本页手工新建。

import type { PageManual } from '../types';

const manual: PageManual = {
  route: 'game_subgame',
  title: '子游戏管理',
  overview:
    '总控端维护自营子游戏目录（身份取自共享池 @/config/gameSubgamePool）：展示游戏身份（大类 / 厂商 / 子类 / 名称 / icon / 编码）、可搜索编辑的映射配置（联动「游戏映射管理」页）、可删除的支持币种，以及纯文字展示的支持设备端 / 支持横竖屏（2026-07-27 新增，均多选默认全选）、创建人前的「排序」列；可编辑单条（排序 / 分类 / 名称 / icon / 倍数 / RTP / 映射配置 / 支持设备端 / 支持横竖屏 / 状态 / 备注），也可多选行后批量启用 / 禁用。2026-07-28 新增「游戏icon上传」能力+列表「排序」列重新展示+「游戏名称」列改中英文两行展示；2026-07-29（R69）列表「游戏icon」列移到「游戏名称」列之后、「排序」列移到「创建人」列之前且列头文案由「排序号」改「排序」、编辑弹窗「游戏icon」字段移到「排序」字段正上方。列表按搜索条件过滤、默认居中展示（「游戏名称」因改两行文案例外改左对齐，R41）。',
  items: [
    // ============ 搜索区（点了联动，顺序同列表列序 R60）============
    {
      anchor: 'gameId',
      name: '游戏ID',
      group: '搜索',
      interaction: '文本输入。',
      dataSource: '用户输入。',
      logic:
        '游戏ID 精确匹配；未命中 ID 时退而按「游戏编码」模糊匹配（大小写不敏感），二者命中其一即算匹配。',
      limit: '选填；最多 50 字，仅拦控制字符（inputProps searchKw）。',
      edge: '空 = 不按此项筛。',
    },
    {
      anchor: 'categoryType',
      name: '大类',
      group: '搜索',
      interaction: '下拉单选、可清空。',
      dataSource:
        '游戏主类型主数据，来自共享池 @/config/gameMainTypePool（与「游戏厂商管理」搜索同一套，当前 12 类：老虎机 / 彩票 / 体育 / 真人娱乐场 / 竞技游戏 / 捕鱼 / 小游戏 / 棋牌 / 视讯直播 / 热门 / 精选 / 推荐）。',
      logic: '按大类精确匹配过滤。',
      limit: '选填。',
      edge: '不选 = 全部大类。',
    },
    {
      anchor: 'vendorCode',
      name: '厂商',
      group: '搜索',
      interaction: '下拉单选、可清空。',
      dataSource:
        '页面加载时调 api.game.subGameGetVendorOptions，从本页实际存在子游戏的厂商去重取值（非全量厂商池，避免选到无数据的厂商）。',
      logic: '按厂商编码精确匹配过滤。',
      limit: '选填。',
      edge: '不选 = 全部厂商。',
    },
    {
      anchor: 'subCategory',
      name: '子类（游戏分类）',
      group: '搜索',
      interaction: '下拉单选、可清空。',
      dataSource:
        '本地固定枚举 SUBCATEGORY_LIST，13 项：Video / Slot / Fish / Sport / ChessCard / small game / wingo / K3 / 5D / TrxWingo / VideoWinGo / MotoRace / LuckyWinGo。',
      logic: '按子类精确匹配过滤；与编辑弹窗「游戏分类」下拉同源。',
      limit: '选填。',
      edge: '不选 = 全部子类。',
    },
    {
      anchor: 'customCategory',
      name: '自定义分类',
      group: '搜索',
      interaction: '文本输入（仅数字），改由下拉调整为输入框（R60 三处同步：列表 / 弹窗 / 搜索）。',
      dataSource: '用户输入。',
      logic: '按自定义分类值包含匹配（trim 后 includes）。',
      limit: '选填；最多 30 位、仅允许数字（onlyDigits 校验器）。',
      edge: '空 = 不按此项筛；部分子游戏该字段本身为空（列表显示 --）。',
    },
    {
      anchor: 'gameName',
      name: '名称',
      group: '搜索',
      interaction: '文本输入、模糊匹配。',
      dataSource: '用户输入。',
      logic: '同时匹配游戏中文名与英文名（gameNameEn，非列表列、编辑弹窗才可见），不区分大小写。',
      limit: '选填；最多 50 字，仅拦控制字符（inputProps searchKw）。',
      edge: '空 = 不按名称筛。',
    },
    {
      anchor: 'isMapping',
      name: '映射配置（是否映射）',
      group: '搜索',
      interaction: '下拉单选：已映射 / 未映射，可清空。',
      dataSource:
        '非本页存储字段，实时按共享映射池 @/config/gameMappingPool 的 findMappingBySubGameId 判断。',
      logic: '筛选该子游戏是否已在「游戏映射管理」页建立映射。',
      limit: '选填。',
      edge: '不选 = 不按映射状态筛。',
    },
    {
      anchor: 'currency',
      name: '支持币种',
      group: '搜索',
      interaction: '下拉单选、可清空。',
      dataSource:
        '本地固定枚举 CURRENCY_LIST，8 项：CNY / USD / PHP / THB / VND / IDR / MYR / BRL。',
      logic: '筛出「支持币种」列包含所选币种的子游戏。',
      limit: '选填。',
      edge: '不选 = 不按币种筛。',
    },
    {
      anchor: 'createTimeRange',
      name: '创建时间',
      group: '搜索',
      interaction: '日期时间区间选择（精确到秒），带默认快捷区间预设，可清空。',
      dataSource: '用户选择，映射为 startCreateTime / endCreateTime 两个请求字段。',
      logic: '按创建时间区间过滤（字符串区间比较）。',
      limit: '最长跨度 90 天；不可选未来时间（allowFuture:false）。',
      edge: '不选 = 不按创建时间筛。',
    },
    {
      anchor: 'updateTimeRange',
      name: '最后修改时间',
      group: '搜索',
      interaction: '日期时间区间选择（精确到秒），带默认快捷区间预设，可清空。',
      dataSource: '用户选择，映射为 startUpdateTime / endUpdateTime 两个请求字段。',
      logic: '按最后修改时间区间过滤（字符串区间比较）。',
      limit: '最长跨度 90 天；不可选未来时间（allowFuture:false）。',
      edge: '不选 = 不按修改时间筛。',
    },
    {
      anchor: 'search_state',
      name: '状态（搜索）',
      group: '搜索',
      interaction: '下拉单选：启用 / 禁用（二态），可清空。',
      dataSource: '本地固定枚举（启用 = 1 / 禁用 = 0）。',
      logic: '按子游戏当前启停状态筛选列表。',
      limit: '选填。',
      edge: '不选 = 全部状态。',
    },
    {
      anchor: 'maintainState',
      name: '维护状态',
      group: '搜索',
      interaction: '下拉单选：维护中 / 正常，可清空。2026-07-23 新增，紧跟在「状态」搜索项之后。',
      dataSource:
        '本页独立字段 maintainState（本地 mock 造数，非取自 game/maintain 维护记录池，二者数据不互通）。',
      logic: '按维护状态精确匹配过滤。',
      limit: '选填。',
      edge: '不选 = 全部维护状态。',
    },

    // ============ 关键列（状态列点了联动）============
    {
      anchor: 'col_state',
      name: '游戏状态列',
      group: '列',
      interaction: '只读语义色 Tag：启用绿 / 禁用红，不可点。',
      dataSource: '行数据 state（1 = 启用 / 0 = 禁用）。',
      logic:
        '仅展示子游戏当前状态；要改状态走行操作「编辑」弹窗里的开关，或对多选行走顶部「批量启用 / 禁用」。',
      note: '本页有意破例 R47：列表去开关仅语义色 Tag 展示，切换移到编辑弹窗 / 批量按钮。原列名「状态」2026-07-23 改为「游戏状态」（与新增「维护状态」列并列区分），字段 state 本身不变。',
    },
    {
      anchor: 'col_maintainState',
      name: '维护状态列',
      group: '列',
      interaction: '只读语义色 Tag：维护中 warning 橙 / 正常 success 绿，不可点。',
      dataSource:
        '行数据 maintainState（1 = 维护中 / 0 = 正常），本页独立 mock 字段，非取自 game/maintain 维护记录池。',
      logic: '仅展示子游戏当前维护状态，无编辑入口（不在编辑弹窗字段内）。',
      limit: '2026-07-23 新增列，只读，无编辑入口。',
    },

    // ============ 操作（顶部工具栏 2 个批量按钮 + 1 行操作）============
    {
      anchor: 'act_batchEnable',
      name: '批量启用（顶部工具栏）',
      group: '操作',
      interaction:
        '先用列表左侧复选框（row-selection）多选行，再点顶部「批量启用」，弹二次确认框确认后执行。',
      dataSource: '选中行的 id 集合（tableRef.getSelectedRowKeys()）。',
      logic: '调 api.game.subGameBatchUpdateState({ ids, state:1 })，成功后清空选中并刷新列表。',
      limit: '未选中任何行时点击 → 仅弹警告提示，不弹确认框。',
      edge: '二次确认框可取消；取消不发请求。',
    },
    {
      anchor: 'act_batchDisable',
      name: '批量禁用（顶部工具栏）',
      group: '操作',
      interaction: '先用列表左侧复选框多选行，再点顶部「批量禁用」，弹二次确认框确认后执行。',
      dataSource: '选中行的 id 集合（tableRef.getSelectedRowKeys()）。',
      logic: '调 api.game.subGameBatchUpdateState({ ids, state:0 })，成功后清空选中并刷新列表。',
      limit: '未选中任何行时点击 → 仅弹警告提示，不弹确认框。',
      edge: '二次确认框可取消；取消不发请求。',
    },
    {
      anchor: 'act_edit',
      name: '行操作 · 编辑',
      group: '操作',
      interaction:
        '点击开编辑弹窗（1040px 宽，标题带厂商/游戏编码）：中文名 / 英文名 / 游戏分类 / 最大倍数 / 最大倍数投注额 / RTP / 映射配置(可搜索选择) / 游戏icon(上传) / 排序 / 状态(下拉) / 支持设备端(多选下拉·默认全选) / 支持横竖屏(多选下拉·默认全选) / 支持币种(可删除标签·横排·代码（中文名）) / 备注。游戏icon 位于映射配置下方、排序正上方（2026-07-28 新增，2026-07-29 R69 微改动由「英文名/游戏分类下方」移到此处）；支持设备端 / 支持横竖屏 / 排序 / 状态 同排展示；支持币种位于备注上方；「自定义分类」输入框已删除（2026-07-21）；「维护状态」不在弹窗字段内（仅搜索+列表）。',
      dataSource:
        '回显调 api.game.subGameGetDetail({ id })；映射配置可在弹窗内搜索厂商 + 游戏后选择（2026-07-20 改为可编辑），保存时随 targetVendor/targetGameCode 写回共享映射池；支持币种展示为可删除 Tag（本体字段 currencyList，2026-07-23 改为「可删除、不可新增」——点 Tag 上的 × 即从列表移除该币种，随整体表单一起保存，弹窗内无新增入口）；排序为 2026-07-23 新增字段（本体字段 sort，数字输入，不填即 0）；游戏icon（本体字段 gameIcon）为 2026-07-28 新增字段，行级、默认按厂商编码+英文名生成 SVG 占位图，编辑弹窗可上传真图覆盖（dataURL 直存，原型无对象存储）；支持设备端(terminalList) / 支持横竖屏(orientationList) 为 2026-07-27 新增字段，均多选、默认全选（PC/H5 二选 · 横屏/竖屏 二选；2026-07-27 由 PC/H5/原生 三选订正为二选，去掉「原生」），旧数据缺失时前端按全选兜底。',
      logic:
        '保存调 api.game.subGameSave，成功后刷新列表；映射配置清空厂商/游戏即解除映射；支持币种删除后随保存一并落库。',
      limit:
        '中文名 / 英文名 / 游戏分类必填（红星）；最大倍数 / 最大倍数投注额 / RTP / 排序 不填即按 0 处理，备注最多 50 字；具体后端校验规则待 5190 核实。',
      edge: '校验不通过阻止保存并提示；保存成功后弹窗自动关闭。',
    },
  ],

  // ============ 字段介绍 tab（仅列表的列 + 定义；顺序同列表列序 R44）============
  fields: [
    { name: '游戏ID', def: '子游戏的唯一编号。' },
    {
      name: '排序',
      def: '本体字段 sort（数字，可在编辑弹窗修改，不填即 0）；不影响列表实际排序逻辑，列表仍按最后修改时间倒序展示（2026-07-28 列表列重新展示，弹窗字段本身 2026-07-23 已加回）。',
    },
    { name: '大类', def: '该子游戏所属的游戏主类型（取自游戏主类型配置池）。' },
    { name: '厂商', def: '提供该子游戏的第三方厂商。' },
    {
      name: '子类',
      def: '子游戏所属的游戏分类（Slot / Fish / wingo 等 13 项枚举，与编辑弹窗「游戏分类」同源）。',
    },
    { name: '自定义分类', def: '运营自定义的分类编号（数字），未设置显示 --。' },
    {
      name: '游戏icon',
      def: '本体字段 gameIcon，行级图标，默认按厂商编码+英文名生成占位图，可在编辑弹窗上传真图覆盖，未设置显示 --（2026-07-28 新增，推翻 2026-07-14「不再恢复」旧决定）。',
    },
    {
      name: '名称',
      def: '子游戏的中文/英文名称，列表两行展示（CN:/EN: 前缀，2026-07-28 由仅中文改中英文两行，随之列对齐由居中改左对齐 R41）。',
    },
    { name: '编码', def: '子游戏在厂商侧的短码。' },
    {
      name: '映射配置',
      def: '该子游戏在「游戏映射管理」页配置的映射目标，格式「厂商-游戏名（游戏ID）」，未映射显示 --。',
    },
    {
      name: '支持币种',
      def: '该子游戏可结算的币种清单。编辑弹窗内竖版标签排列、每个币种以「代码（中文名）」格式展示（如 CNY（人民币）），可点标签 × 删除。',
    },
    {
      name: '支持设备端',
      def: '该子游戏支持在哪些端展示：PC / H5，多选，默认全选（2026-07-27 新增）。列表纯文字展示（顿号分隔，不用彩色 Tag），编辑弹窗为多选下拉。',
    },
    {
      name: '支持横竖屏',
      def: '该子游戏支持横屏还是竖屏展示：横屏 / 竖屏，多选，默认全选（2026-07-27 新增）。列表纯文字展示（顿号分隔，不用彩色 Tag），编辑弹窗为多选下拉。',
    },
    { name: '最大倍数', def: '该子游戏允许的最大倍数。' },
    { name: '最大倍数投注额', def: '该子游戏对应的最大投注额度。' },
    {
      name: '游戏状态',
      def: '子游戏当前启用 / 禁用状态。原列名「状态」2026-07-23 改为「游戏状态」。',
    },
    {
      name: '维护状态',
      def: '子游戏当前是否处于维护中；本页独立字段，与 game/maintain 维护记录池无关、不共享数据（2026-07-23 新增）。',
    },
    { name: '创建人', def: '创建该子游戏记录的操作账号。' },
    { name: '创建时间', def: '子游戏记录创建时间（按商户时区展示）。' },
    { name: '最后修改人', def: '最近一次修改该子游戏的操作账号。' },
    { name: '最后修改时间', def: '子游戏记录最近修改时间（按商户时区展示）。' },
  ],
};

export default manual;
