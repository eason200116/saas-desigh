<template>
  <div class="refresh-action-group">
    <n-button
      v-if="showAuto"
      :type="autoRefreshing ? 'default' : 'primary'"
      size="small"
      @click="$emit('toggle-auto')"
    >
      {{ autoLabel }}
    </n-button>

    <n-button
      size="small"
      quaternary
      circle
      :loading="manualLoading"
      :title="resolvedManualTitle"
      @click="$emit('manual-refresh')"
    >
      <template #icon>
        <n-icon><ReloadOutlined /></n-icon>
      </template>
    </n-button>
  </div>
</template>

<script setup lang="ts">
  import { computed } from 'vue';
  import { useI18n } from 'vue-i18n';
  import { NButton, NIcon } from 'naive-ui';
  import { ReloadOutlined } from '@vicons/antd';

  const { t } = useI18n();

  const props = withDefaults(
    defineProps<{
      showAuto?: boolean;
      autoRefreshing?: boolean;
      countdownText?: string;
      manualLoading?: boolean;
      manualTitle?: string;
    }>(),
    {
      showAuto: true,
      autoRefreshing: false,
      countdownText: '00:00',
      manualLoading: false,
      manualTitle: '',
    },
  );

  defineEmits<{
    (e: 'toggle-auto'): void;
    (e: 'manual-refresh'): void;
  }>();

  const autoLabel = computed(() => {
    if (!props.autoRefreshing) return t('common.autoRefresh');
    return `${t('common.autoRefresh')} ${props.countdownText}`;
  });

  const resolvedManualTitle = computed(() => props.manualTitle || t('common.refresh'));
</script>

<style lang="less" scoped>
  .refresh-action-group {
    display: flex;
    align-items: center;
    gap: 8px;
  }
</style>
