// 提现类型管理（商户端 tenant · finance_withdraw_type_page）功能说明书。
// 锚定 src/views/finance/withdrawType/index.vue 容器 + 2 个子 Tab（withdrawCategory 提现大类 /
// withdrawChannel 提现通道）各自的 index.vue/data.ts/form.ts/useXxxPage.ts/编辑弹窗真实控件
// （R53 实证、不臆造）。容器只是 n-tabs 壳（读 route.meta.tabs），2 个子 Tab 各自独立的搜索表单 +
// 列表 + 新增/编辑操作，互不共用组件——区别于 riskControlSameIp 那种"单表多维度换皮"。

import type { PageManual } from '../types';

const manual: PageManual = {
  route: 'finance_withdraw_type_page',
  title: '提现类型管理',
  overview:
    '商户端「财务管理 › 提现类型管理」页，容器是一个 2 标签页壳（提现大类 / 提现通道），两个标签页完全独立、互不共用组件：「提现大类」维护面向会员展示的出款分类（图标/额度/费率/快捷金额档位/可用时段）；「提现通道」维护每个大类背后实际对接的三方支付通道（映射码/通道名称/币种/权重/金额区间），并提供"代付测试"工具直接调用三方接口联调。2026-07-21 核实代码后如实记录 3 处真实缺陷（均未修复，只记录）：①「提现通道」新增流程依赖的商户通道树接口 `/WithdrawChannel/GetMerchantChannelTree` 当前 mock 恒返回空数据，导致新增弹窗的级联通道选择器永远没有可选项，必填校验无法通过，新增提现通道当前在本原型环境下无法经 UI 走完整流程；②「提现通道」的编辑保存（withdrawChannelUpdate）与新增保存（BatchAdd）两个 mock 都只回"成功"、不真正写回底层数据数组，保存后提示成功但刷新列表看不到变化（对照「删除」是真删的，这是历史遗留的不对称）；③「提现通道」行操作"代付测试"弹窗里，进入弹窗自动加载"代付类型"下拉的 mock 函数返回单个对象而非数组，一旦切到"代付拉单测试"内部 Tab，页面里把该值 `.map()` 成下拉选项的计算属性会抛运行时错误；同弹窗里加载"银行/账号候选"下拉的 mock 函数与预期字段（银行名/账号/收款人/IFSC/手机号）完全对不上，即便绕开报错这几个下拉也恒为空。「提现大类」Tab 额外发现一处更轻微的假持久化：「今日提现总次数配置」小弹窗保存后提示成功，但读取接口恒返回写死的次数值，重新打开看不到刚保存的数字。',
  items: [
    // ============ 容器：Tab 切换 ============
    {
      anchor: 'tab_switch',
      name: '2 个子页 Tab 切换（提现大类 / 提现通道）',
      group: '操作',
      interaction:
        '点顶部 Tab 切换，2 个 Tab 各自独立的搜索表单 + 列表 + 新增/编辑操作，不是同一张表换维度，也不共用编辑弹窗。',
      dataSource: '从当前路由 meta.tabs 读取配置（useRouteTabs），默认展示「提现大类」Tab。',
      logic:
        '默认 keepAlive（各 Tab 切走后状态不丢，含分页/筛选）；容器内含一段"布局高度链补丁"逻辑（给祖先 .layout-main 挂高度撑满 class），与两个子 Tab 的业务无关。',
      note: '容器组件 src/views/finance/withdrawType/index.vue 本身只是壳，不含独立业务控件；实际控件都在两个子 Tab 自己的 index.vue 里。',
    },

    // ============ Tab①提现大类：搜索 ============
    {
      anchor: 'category_merchant',
      name: '商户（提现大类 Tab，搜索区）',
      group: '搜索',
      interaction: '下拉单选（商户选择器 ProTenantSelect，架构级不可清空，见《交互规范》§3）。',
      dataSource: '全站商户列表。',
      logic:
        '按选中商户过滤大类列表；切换商户会联动重新拉取该商户下的"提现大类"（前台显示名称）下拉选项。',
      limit: '搜索表单项配了 showRequireMark 红星提示 + 组件本身 clearable:false 架构级不可清空。',
      edge: '查询区点"重置"时会同步把"提现大类"下拉恢复到重置后默认商户对应的选项（handleSearchReset 显式处理，非框架自动行为）。',
    },
    {
      anchor: 'category_customName',
      name: '提现大类（提现大类 Tab，搜索区，前台显示名称下拉）',
      group: '搜索',
      interaction: '下拉单选，可搜索可清空。',
      dataSource: '按当前选中商户调用 getSelectList({tenantId}) 拉取该商户名下所有大类的 customName，去重后作为选项。',
      logic: '按选中的显示名称精确过滤列表。',
      limit: '选填。',
      edge: '这里的"提现大类"指运营自定义的前台展示分类（customName 字段），与列表"内置提现大类"列（系统枚举）是两个不同字段，同名不同义。',
    },

    // ============ Tab①提现大类：列 ============
    {
      anchor: 'col_category_icons',
      name: '选中前图标/选中后图标列（提现大类 Tab）',
      group: '列',
      interaction: '两张缩略图并排展示（28×28），可点击预览大图（NImage previewDisabled:false）。',
      dataSource: '行数据 iconUrl / selectedIconUrl，经 getFullImageUrl 补全域名后展示。',
      logic: '图标为空时显示"--"占位，不触发预览。',
    },
    {
      anchor: 'col_category_state',
      name: '状态列（提现大类 Tab，启用/禁用开关）',
      group: '列',
      interaction: '开关（ConfirmSwitch），点击弹二次确认框（弹窗文案"确认启用/禁用？"）确认后才真正切换，命中 R47。',
      dataSource: '行数据 state（0/1）。',
      logic: '确认后调用 withdrawCategoryUpdateState 提交，成功后整表 reload 并提示"更新成功"。',
      edge: '点取消则开关视觉复位，不发起请求。',
    },

    // ============ Tab①提现大类：操作 ============
    {
      anchor: 'category_todayTotalConfig',
      name: '今日提现总次数配置（提现大类 Tab，表格左上角按钮）',
      group: '操作',
      interaction: '点表格左上角按钮打开小弹窗（宽420px），内含当前查询商户名称（只读）+ "总次数"数字输入框（最小0、整数、不显示步进箭头）。',
      dataSource: '弹窗打开时调用 getWithCount({tenantId}) 取当前配置值；商户取自查询区当前选中商户（tableRef.getSearchParams().tenantId）。',
      logic: '若查询区尚未选商户会提示"请选择商户"且不弹窗（理论上商户恒有值，属兜底分支）；点确认先校验总次数是否为非负整数，通过后调用 setWithCount 提交，成功后提示"更新成功"并关闭弹窗。',
      limit: '总次数必须是 ≥0 的整数，非法值会被拦截并弹警告提示，不会静默失败。',
      edge:
        '⚠️ 核实代码后发现：setWithCount 的 mock 实现只是把提交的值原样回显，并没有真正写入任何持久化存储；而 getWithCount 的 mock 无论传什么参数都恒返回写死的 withCount:5——也就是说保存操作会提示"更新成功"，但下次重新打开该弹窗看到的仍是固定的 5，不会回显上一次实际保存过的数字，如实记录、非本次引入也未修复。',
    },
    {
      anchor: 'category_edit',
      name: '编辑（提现大类 Tab，行操作按钮）',
      group: '操作',
      interaction:
        '点行内"编辑"打开弹窗（WithdrawCategoryEditModal，宽600px），含选中前/后图标上传×2、商户（只读）、内置提现大类（只读）、提现大类名称、每日提现次数、提现费率(%)、排序、状态（单选启用/禁用）、最小/最大提现金额、快捷提现金额（6~12档可增减）、收取费率金额范围（ProNumberRange）、提现提示（多行文本）、可用时间段（起止两个时间选择器）。',
      dataSource: '打开时调用 withdrawCategoryGet({id, tenantId}) 取详情回填；内置提现大类选项来自静态字典 withdrawCategoryEnumList（common 源），非独立接口。',
      logic:
        '保存前校验：两张图标必传、大类名称非空、费率需在 0~1 之间、排序为非负整数、最小/最大金额大小关系合法、可用时段起止合法、快捷金额档位数不足 6 档会标红拦截且不提交；校验通过后调用 withdrawCategoryUpdate 落库，若状态发生变化会额外调用 withdrawCategoryUpdateState；两者都成功才提示"更新成功"并关闭弹窗。',
      limit: '快捷提现金额需配置 6~12 个档位（不足标红拦截，命中 R53 保存校验红框规范）；提现费率 0~1（展示为百分比）；金额类字段最多 12 位整数 + 2 位小数。',
      note: '"商户"和"内置提现大类"两个字段编辑态均为只读展示（灰底输入框），不可在本弹窗改归属或改系统大类。',
    },

    // ============ Tab②提现通道：搜索 ============
    {
      anchor: 'channel_merchant',
      name: '商户（提现通道 Tab，搜索区）',
      group: '搜索',
      interaction: '下拉单选可搜索（商户选择器，架构级不可清空）。',
      dataSource: '全站商户列表。',
      logic: '切换商户会清空"三方映射码/通道ID-名称/三方商户昵称-商户号/通道币种"四个联动字段，并按新商户重新计算这些下拉的可选项（前端本地过滤，不重新发请求，命中"字典派生层"设计）。',
    },
    {
      anchor: 'channel_thirdChannelCode',
      name: '三方映射码（提现通道 Tab，搜索区）',
      group: '搜索',
      interaction: '下拉单选可搜索可清空，依赖已选商户。',
      dataSource: '字典派生层 useWithdrawChannelDictionary：按 tenantId + state=1 从 tenantPayChannelList 取 payCode 去重，且仅保留 sysPayChannelList 里 inOutType="Withdraw" 方向的映射码（避免误显示充值方向的映射码）。',
      logic: '切换后联动清空"通道ID-名称/提现大类/通道币种/三方商户昵称-商户号"。',
      edge: '商户未选时选项为空（依赖商户）。',
    },
    {
      anchor: 'channel_channelId',
      name: '通道ID/名称（提现通道 Tab，搜索区）',
      group: '搜索',
      interaction: '下拉单选可搜索可清空，依赖商户 + 三方映射码 + 通道币种。',
      dataSource: '字典派生（tenantPayChannelList 按 tenantId+payCode+sysCurrency+state=1 过滤），选项展示为「通道关系ID → 出款显示名称」。',
    },
    {
      anchor: 'channel_merchantName',
      name: '三方商户昵称/商户号（提现通道 Tab，搜索区）',
      group: '搜索',
      interaction: '下拉单选可搜索可清空，依赖商户 + 三方映射码。',
      dataSource: '字典派生（thirdPayMerchantList 按同集团 orgId + payCode 过滤），选项展示为「昵称(商户号)」拼接串。',
      logic: '按选中的拼接串精确匹配过滤（透传给列表接口的 merchantName 参数按 includes 匹配行数据 merchantCode）。',
    },
    {
      anchor: 'channel_channelCategoryId',
      name: '提现大类（提现通道 Tab，搜索区）',
      group: '搜索',
      interaction: '下拉单选可搜索可清空，依赖已选商户（不依赖映射码）。',
      dataSource: '字典派生（withdrawCategoryList 按 tenantId 过滤），是租户级自定义大类 ID，非系统内置枚举。',
    },
    {
      anchor: 'channel_sysCurrency',
      name: '通道币种（提现通道 Tab，搜索区）',
      group: '搜索',
      interaction: '下拉单选可搜索可清空，依赖商户 + 三方映射码。',
      dataSource: '字典派生（tenantPayChannelList 按 tenantId+payCode+state=1 后取 sysCurrency 去重）。',
    },
    {
      anchor: 'channel_state',
      name: '状态（提现通道 Tab，搜索区）',
      group: '搜索',
      interaction: '下拉单选可清空，固定 2 个选项。',
      dataSource: '固定选项：启用(1) / 禁用(0)，非字典来源。',
      logic: '按选中值精确过滤列表（不选=不按状态筛）。',
    },

    // ============ Tab②提现通道：列 ============
    {
      anchor: 'col_channel_info',
      name: '通道信息列（提现通道 Tab，四行结构）',
      group: '列',
      interaction: '纯展示四行，不可点：通道ID / 通道名称[字典ID] / 出款显示名称 / 三方映射码（标签）。',
      dataSource: '行数据 id/channelId/customName/payCode；通道名称经 dynamicDict.sysPayChannelList 字典反查（字段已从接口下线，改由字典查名）。',
      note: '与「提现通道」页搜索区里独立的"通道ID/名称"下拉是同一批数据的两种呈现（一个用于筛选，一个用于列表展示），渲染逻辑与「充值通道」页共用同一个工厂函数（channelColumnRenderers.ts）。',
    },
    {
      anchor: 'col_channel_state',
      name: '状态列（提现通道 Tab，启用/禁用开关）',
      group: '列',
      interaction: '开关（ConfirmSwitch），点击弹二次确认框确认后才真正切换，命中 R47。',
      dataSource: '行数据 state（0/1）。',
      logic: '确认后调用 withdrawChannelUpdateState，成功后触发字典失效重拉 + 整表 reload。',
      note: '与下面「可用状态」列是两个独立概念：本列是"商户侧是否启用该通道"，可主动操作；「可用状态」是三方通道自身的运行态，本页只读展示、不可直接操作。',
    },
    {
      anchor: 'col_channel_channelState',
      name: '可用状态列（提现通道 Tab，三方通道运行态）',
      group: '列',
      interaction: '只读彩色标签，不可点。',
      dataSource: '行数据 channelState（0=总控通道关闭）/ merchantState（0=三方商户关闭）。',
      logic: '按优先级判定：channelState=0 → 显示"总控通道关闭"（红）；否则 merchantState=0 → 显示"三方商户关闭"（红）；否则 channelState=1 → 显示"可用"（绿）；其余情况显示"--"。',
    },

    // ============ Tab②提现通道：操作 ============
    {
      anchor: 'channel_add',
      name: '新增（提现通道 Tab，表格左上角按钮）',
      group: '操作',
      interaction:
        '点表格左上角"新增"打开弹窗（WithdrawChannelEditModal，宽620px），含商户 / 三方映射码 / 通道名称（级联选择器 ChannelCascadeSelect，按"三方商户"分组、组内单选具体通道）/ 通道币种（选中通道后自动带出、只读）/ 提现大类（选中通道后自动拉取候选，通常默认选中第一项）/ 出款显示名称 / 三方通道编码 / 自动出款权重 / 自动关闭阈值 / 提现金额区间（ProNumberRange）/ 是否整百提现（单选）/ 状态（单选）/ 备注。',
      dataSource: '"通道名称"级联选择器的数据来自 POST /WithdrawChannel/GetMerchantChannelTree（按商户+三方映射码请求），选中通道后会带 channelId 再请求一次同接口拉取该通道可用的"提现大类"候选。',
      logic: '校验通过后调用 http.post("/WithdrawChannel/BatchAdd", ...) 提交；成功后提示"新增成功"并关闭弹窗、刷新列表+字典缓存。',
      limit: '商户 / 三方映射码 / 通道（级联树单选）/ 提现大类 / 出款显示名称 / 提现金额区间 均为必填；出款显示名称最多 20 字；自动出款权重 0~9999；自动关闭阈值 0~999999999（整数）；提现金额区间最多 12 位整数 + 2 位小数、起止大小关系需合法。',
      edge:
        '⚠️ 核实代码后发现两处真实缺陷：①级联选择器背后的商户通道树接口 /WithdrawChannel/GetMerchantChannelTree 当前 mock（components/data.ts 的 Proxy stub）无论传什么参数都恒返回 data:null，归一化后是空的商户分组/空的通道列表——也就是说"通道名称"级联下拉在新增流程里永远没有任何可选项，必填的 selectedTreeChannelKey 校验无法通过，新增提现通道当前在本原型环境下无法经 UI 完整走通，如实记录、不修复；②即便绕开①，提交调用的 BatchAdd 与「编辑」调用的 withdrawChannelUpdate 两个 mock 都只返回成功、并未真正把数据写入底层数组 WITHDRAW_CHANNELS，保存后提示成功、但刷新列表看不到新增/修改结果（对照本 Tab 的"删除"操作是真删的，说明新增/编辑的假持久化是历史遗留、并非本次改动引入）。',
    },
    {
      anchor: 'channel_edit',
      name: '编辑（提现通道 Tab，行操作按钮）',
      group: '操作',
      interaction: '点行内"编辑"打开同一弹窗；商户 / 三方映射码 / 通道名称 / 提现大类 四项在编辑态均锁定只读（灰底禁用），仅可改出款显示名称 / 三方通道编码 / 自动出款权重 / 自动关闭阈值 / 提现金额区间 / 是否整百提现 / 状态 / 备注。',
      dataSource: '打开时调用 withdrawChannelGet({id}) 取详情回填。',
      logic: '提交调用 withdrawChannelUpdate，成功后提示"更新成功"并刷新列表+字典缓存。',
      edge: '⚠️ 同 channel_add 缺陷②：withdrawChannelUpdate 的 mock 只返回成功、不真正写回 WITHDRAW_CHANNELS，编辑保存后刷新列表看不到修改生效，如实记录、不修复。',
    },
    {
      anchor: 'channel_delete',
      name: '删除（提现通道 Tab，行操作按钮）',
      group: '操作',
      interaction: '点行内"删除"，按钮类型为 createActionColumn 的内置 delete 语义（点击弹二次确认）。',
      logic: '确认后调用 withdrawChannelDelete({id})，成功后提示删除成功并刷新列表+字典缓存。',
      note: '与新增/编辑不同，删除的 mock 是真的从底层数组里 splice 掉该行，删除后条数会真实减少。',
    },
    {
      anchor: 'channel_payoutTest',
      name: '代付测试（提现通道 Tab，行操作按钮）',
      group: '操作',
      interaction: '点行内"代付测试"打开弹窗（WithdrawPayoutTestModal，宽860px），左侧纵向 4 个 Tab：查询通道余额 / 代付拉单测试 / 代付订单查询 / 代付回调测试；顶部横条只读展示通道ID / 出款显示名称 / 通道名称 / 三方映射码 / 币种（取自当前行数据）。',
      dataSource: '进入弹窗自动请求该通道币种对应的"代付类型"下拉选项，并默认选中第一项后再拉取该类型下的测试资料（银行名/收款人/账号/IFSC/手机号等）供级联下拉选择。',
      logic:
        '"查询通道余额"Tab 点按钮即查；"代付拉单测试"Tab 按选中的代付类型（银行卡/UPI/USDT/电子钱包/PIX等）动态显示不同必填字段组合（如 USDT 显示网络协议+钱包地址，银行卡显示银行名+收款人+账号+IFSC），提交后把生成的订单号自动带入"代付订单查询"和"代付回调测试"两个 Tab 的输入框；"代付订单查询"Tab 按订单号查状态；"代付回调测试"Tab 提交 JSON 请求头+回调体模拟三方回调通知。四个 Tab 各自的请求地址/请求体/响应体/错误日志均可折叠展开查看。',
      limit: '"代付拉单测试"提交前校验：代付类型必选，且当前类型要求的字段组合均不能为空，金额必填；"代付订单查询"订单号必填；"代付回调测试"回调内容必填。',
      edge:
        '⚠️ 核实代码后发现一处真实的 mock 数据形状不匹配：进入弹窗自动调用的取"代付类型"下拉的接口，其 mock 实现返回的是单个对象（{tenantId,sysCurrency,withdrawCategoryId,...}）而不是数组，但页面把响应直接赋给 typeOptions（预期是下拉选项数组）；一旦用户切换到"代付拉单测试"Tab，模板里把 typeOptions 转成下拉选项的计算属性会对这个非数组对象调用 .map()，大概率抛出运行时错误（已核实 n-tab-pane 默认 displayDirective:"if"，即该 Tab 面板只在被点开时才渲染，故报错时机是"切到该 Tab 时"而非"弹窗一打开就报错"）。同时，另一个用来加载选中类型后"银行/账号候选"下拉的接口，其 mock 数据字段（id/value/label/name/code/sysCurrency，更像是大类枚举）跟页面期望的字段（银行名/账号/收款人姓名/IFSC码/手机号）完全对不上，即便绕开前面的报错，这几个下拉选项也会恒为空。以上均如实记录、不修复。',
    },
  ],

  // ============ 字段介绍 tab（按各自 Tab 列表列真实列序；仅列表列 + 定义）============
  fields: [
    // ---- 提现大类 Tab（16 列，同 withdrawCategory/index.vue tableColumns 顺序）----
    { name: '「提现大类」商户', def: '该条大类配置所属商户，标签形式展示。' },
    { name: '「提现大类」ID', def: '该条大类配置的唯一编号。' },
    { name: '「提现大类」选中前图标', def: '会员在提现方式列表里未选中该大类时展示的图标。' },
    { name: '「提现大类」选中后图标', def: '会员在提现方式列表里选中该大类后展示的图标。' },
    { name: '「提现大类」提现大类', def: '运营自定义的前台展示名称（如"IMPS 快速出款"），即 customName 字段。' },
    { name: '「提现大类」内置提现大类', def: '系统内置的提现大类枚举（如银行卡/USDT/UPI/PIX等），标签展示，决定该大类的底层业务类型。' },
    { name: '「提现大类」单会员当日可提现次数', def: '同一会员在自然日内可使用该大类发起提现的最大次数。' },
    { name: '「提现大类」最小提现金额', def: '单笔提现允许的最小金额。' },
    { name: '「提现大类」最大提现金额', def: '单笔提现允许的最大金额。' },
    { name: '「提现大类」快捷提现金额', def: '前台展示给会员一键选择的快捷金额档位列表（斜杠分隔）。' },
    { name: '「提现大类」手续费率', def: '该大类收取的提现手续费比例（展示为百分比）。' },
    { name: '「提现大类」收取手续费区间', def: '手续费的收取范围：单笔提现金额落在此区间内才收取手续费，为空表示不限制。' },
    { name: '「提现大类」可用时间段', def: '该大类每天可发起提现的起止时间段。' },
    { name: '「提现大类」排序', def: '控制该大类在前台提现方式列表里的展示先后顺序，数值越小越靠前。' },
    { name: '「提现大类」最后修改人', def: '最近一次编辑该大类配置的操作人账号。' },
    { name: '「提现大类」最后修改时间', def: '最近一次编辑该大类配置的时间。' },
    { name: '「提现大类」状态', def: '该大类是否对会员开放使用（启用/禁用）。' },

    // ---- 提现通道 Tab（15 列，同 withdrawChannel/index.vue tableColumns 顺序）----
    { name: '「提现通道」商户', def: '该条通道配置所属商户，标签形式展示。' },
    {
      name: '「提现通道」通道信息',
      def: '四行复合信息：通道ID（本条记录主键）/ 通道名称（含字典 ID）/ 出款显示名称（运营自定义）/ 三方映射码（标签展示）。',
    },
    { name: '「提现通道」三方商户昵称/商户号', def: '该通道对接的三方支付商户的昵称与商户编号，两行展示。' },
    { name: '「提现通道」通道币种', def: '该通道处理的结算币种（如 INR/USDT/BRL），标签展示。' },
    {
      name: '「提现通道」通道余额',
      def: '两行复合信息：三方通道当前余额 / 该余额最近一次同步更新的时间。',
    },
    { name: '「提现通道」自动出款权重', def: '同一大类下多个可用通道之间自动分单的权重值，权重越高被自动选中的概率越大。' },
    { name: '「提现通道」提现大类', def: '该通道归属的租户级自定义大类展示名称。' },
    { name: '「提现通道」内置提现大类', def: '该通道归属大类对应的系统内置枚举分类，标签展示。' },
    { name: '「提现通道」状态', def: '该通道是否被本商户启用（可主动开关切换）。' },
    { name: '「提现通道」可用状态', def: '三方通道自身的运行态（总控通道是否关闭 / 三方商户是否关闭 / 可用），只读，不可在本页直接操作。' },
    { name: '「提现通道」自动关闭阈值', def: '通道余额低于该阈值时，系统会自动关闭该通道，避免余额不足导致代付失败。' },
    { name: '「提现通道」提现金额区间', def: '该通道单笔允许处理的最小~最大提现金额。' },
    { name: '「提现通道」备注', def: '运营对该通道配置的补充说明文字。' },
    { name: '「提现通道」最后修改人', def: '最近一次编辑该通道配置的操作人账号。' },
    { name: '「提现通道」最后修改时间', def: '最近一次编辑该通道配置的时间。' },
  ],
};

export default manual;
