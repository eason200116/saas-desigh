<template>
  <table class="summary-table">
    <colgroup>
      <col v-for="(w, i) in actualColWidths" :key="i" :style="{ width: w }" />
    </colgroup>
    <tbody>
      <tr v-for="(row, idx) in rows" :key="idx">
        <td class="summary-table__label">{{ row.label }}</td>
        <td v-if="amountColIndex > 1" :colspan="amountColIndex - 1" />
        <td class="summary-table__amount">
          {{ t('components.summaryTable.amountLabel') }}
          <span class="summary-table__value" :class="getAmountClass(row.amount)">{{
            row.amount
          }}</span>
        </td>
        <td v-if="remainCols > 0" :colspan="remainCols" />
      </tr>
    </tbody>
  </table>
</template>

<script setup lang="ts">
  import { computed, ref, onMounted, nextTick } from 'vue';
  import { useI18n } from 'vue-i18n';

  interface SummaryRow {
    label: string;
    amount: string | number;
  }

  const props = withDefaults(
    defineProps<{
      /** 合计行数据 */
      rows: SummaryRow[];
      /** 金额显示在第几列（从 0 开始） */
      amountColIndex?: number;
      /** 手动传列宽（优先级低于自动检测） */
      columns?: { width?: number | string }[];
    }>(),
    {
      amountColIndex: 2,
      columns: undefined,
    },
  );

  const { t } = useI18n();

  // 自动从相邻的 NDataTable 获取实际列宽
  const detectedWidths = ref<string[]>([]);

  onMounted(async () => {
    await nextTick();
    // 向上查找同级的 n-data-table，读取 <col> 宽度
    const el = document.querySelector('.summary-table');
    const parent = el?.parentElement;
    if (!parent) return;
    const table = parent.querySelector('.n-data-table table colgroup');
    if (!table) return;
    const cols = table.querySelectorAll('col');
    detectedWidths.value = Array.from(cols).map((col) => col.style.width || 'auto');
  });

  const actualColWidths = computed(() => {
    // 优先用自动检测的宽度
    if (detectedWidths.value.length) return detectedWidths.value;
    // 其次用手动传入的 columns
    if (props.columns?.length) {
      return props.columns.map((col) => {
        const w = col.width;
        if (!w) return 'auto';
        return typeof w === 'number' ? `${w}px` : w;
      });
    }
    return [];
  });

  const remainCols = computed(() => {
    const total = actualColWidths.value.length;
    return Math.max(0, total - props.amountColIndex - 1);
  });

  function getAmountClass(amount: string | number) {
    const str = String(amount || '');
    if (str.startsWith('-')) return 'summary-table__value--negative';
    if (str.startsWith('+')) return 'summary-table__value--positive';
    return '';
  }
</script>

<style scoped>
  .summary-table {
    width: 100%;
    font-size: 12px;
    border-collapse: collapse;
    table-layout: fixed;
  }
  .summary-table td {
    padding: 8px 12px;
    border-bottom: 1px solid #f0f0f0;
    border-right: 1px solid #f0f0f0;
    color: #595959;
  }
  .summary-table td:last-child {
    border-right: 0;
  }
  .summary-table tr:last-child td {
    border-bottom: 0;
  }
  .summary-table tr:nth-child(odd) td {
    background: #fafafa;
  }
  .summary-table tr:nth-child(even) td {
    background: #f5f5f5;
  }
  .summary-table__label {
    font-weight: 500;
    color: #262626;
  }
  .summary-table__amount {
    color: #595959;
  }
  .summary-table__value {
    font-weight: 600;
    font-variant-numeric: tabular-nums;
  }
  .summary-table__value--positive {
    color: #16a34a;
  }
  .summary-table__value--negative {
    color: #dc2626;
  }
</style>
