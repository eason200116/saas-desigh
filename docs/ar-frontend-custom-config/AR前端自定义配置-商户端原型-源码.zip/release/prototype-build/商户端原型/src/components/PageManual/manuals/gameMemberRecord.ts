// 会员资金账变（总控端 admin · game_member_record）功能说明书。
// 总-5(2026-07-20) 重做：1:1照抄商户端 finance/fundChange 结构；2026-07-22 页面改名并移除「集团」筛选；
// 2026-07-23 路由入口从「游戏管理 › 游戏会员管理」迁移到「财务管理 › 资金账务」分组（与商户端资金账变
// 入口对齐），页面路径 /game/member/record → /finance/memberRecord，route 字段保持 game_member_record 不变。
// 锚定 src/views/game/member/record/{index.vue,recordConfig.ts,useRecordPage.ts,data.ts} 真实控件（R53 实证）。

import type { PageManual } from '../types';

const manual: PageManual = {
  route: 'game_member_record',
  title: '会员资金账变',
  overview:
    '总控端查询会员游戏钱包的资金变动（账变）流水，1:1照抄商户端「资金账变」结构：商户单选必填（红星），会员ID / 订单号 / 账变类型 / 操作人 四选一必填其一才能查询，账变类型为主类型-子类型(-厂商-游戏)可勾选树。顶部汇总条显示当前页与全部命中的账变金额总计（正绿负红）。金额列左对齐（R61），备注列排最后（R66）。操作列可编辑备注。菜单归属「财务管理 › 资金账务」分组（2026-07-23 由「游戏管理 › 游戏会员管理」迁入，与商户端「资金账变」入口对齐）。',
  items: [
    {
      anchor: 'm_tenantId',
      name: '商户',
      group: '搜索',
      interaction: '下拉单选，必填（红星），排搜索区最前。',
      dataSource: 'MerchantFilterSelect 全站商户选项。',
      logic: '按商户筛选账变记录。',
      limit: '必填，未选点查询红框+红字。',
      edge: '—',
    },
    {
      anchor: 'm_userID',
      name: '会员ID',
      group: '搜索',
      interaction: '文本输入，仅数字。',
      dataSource: '用户输入。',
      logic: '按会员ID筛选。',
      limit: '选填；属「会员ID/订单号/账变类型/操作人」四选一必填其一。',
      edge: '四者都空点查询 → toast 红字提示拦截。',
    },
    {
      anchor: 'm_orderNum',
      name: '订单号',
      group: '搜索',
      interaction: '文本输入。',
      dataSource: '用户输入。',
      logic: '按账变订单号筛选。',
      limit: '选填；属四选一必填其一。',
      edge: '—',
    },
    {
      anchor: 'm_type',
      name: '账变类型',
      group: '搜索',
      interaction: '可勾选树下拉，多选、级联（子类型/厂商/游戏三层）。',
      dataSource: '全站共享字典 @/constants/financialType。',
      logic: '按账变类型（含商-5新增的跟单冻结扣款/解冻加钱）筛选，勾父级联动全选其下。',
      limit: '选填；属四选一必填其一。',
      edge: '游戏类子类型可展开厂商/游戏两层。',
    },
    {
      anchor: 'm_reserved',
      name: '操作人',
      group: '搜索',
      interaction: '文本输入。',
      dataSource: '用户输入。',
      logic: '按编辑备注的操作人筛选。',
      limit: '选填；属四选一必填其一。',
      edge: '—',
    },
    {
      anchor: 'm_timeRange',
      name: '时间范围',
      group: '搜索',
      interaction: '日期时间范围（精确到秒，占2列，默认today）。',
      dataSource: '用户选择。',
      logic: '按账变时间筛选。',
      limit:
        '选填；单次查询区间最长6个月（maxDays:180，商-6/2026-07-21，与商户端 finance/fundChange 联动同改）。',
      edge: '—',
    },
  ],

  fields: [
    { name: '商户', def: '发生账变的会员所属商户。' },
    { name: '会员ID', def: '会员在平台侧的唯一ID，可点跳会员详情。' },
    { name: '订单号', def: '本次账变的唯一订单号。' },
    { name: '账变类型', def: '主类型-子类型(-厂商-游戏)，如"游戏-投注·自研·WinGo"。' },
    { name: '币种', def: '账变金额的币种（按商户解析）。' },
    { name: '账变前金额', def: '本次账变发生前的钱包余额（左对齐）。' },
    { name: '账变金额', def: '本次变动的金额（正绿负红，带正负号，左对齐）。' },
    { name: '账变后金额', def: '本次账变发生后的钱包余额（左对齐）。' },
    { name: '账变时间', def: '账变发生时间（按商户时区展示）。' },
    { name: '操作人', def: '编辑本条备注的操作人。' },
    { name: '备注说明', def: '本条账变的备注文字，可通过操作列「编辑备注」修改。' },
  ],
};

export default manual;
