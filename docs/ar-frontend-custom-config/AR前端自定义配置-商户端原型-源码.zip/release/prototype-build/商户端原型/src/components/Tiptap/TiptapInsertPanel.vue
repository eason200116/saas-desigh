<template>
  <div
    class="tiptap-insert-panel flex h-[300px] w-[400px] max-w-[calc(100vw-32px)] flex-col gap-3 overflow-hidden p-3"
    :style="themeStyle"
  >
    <n-input
      v-model:value="query"
      size="medium"
      clearable
      :placeholder="t('common.tiptap.insertSearchPlaceholder')"
    />

    <div class="flex flex-wrap gap-1">
      <button
        v-for="group in visibleGroups"
        :key="group.key"
        type="button"
        class="tiptap-insert-panel__group inline-flex items-center gap-1 rounded-full border px-3 py-1.5 text-[12px] font-medium leading-5 transition-colors"
        :class="activeGroup === group.key ? 'tiptap-insert-panel__group--active' : ''"
        @click="activeGroup = group.key"
      >
        <span>{{ group.label }}</span>
        <span
          class="tiptap-insert-panel__group-count inline-flex min-w-5 items-center justify-center rounded-full px-1.5 py-0.5 text-[12px] leading-none"
          :class="activeGroup === group.key ? 'tiptap-insert-panel__group-count--active' : ''"
        >
          {{ group.count }}
        </span>
      </button>
    </div>

    <n-scrollbar class="min-h-0 flex-1 pr-1">
      <div v-if="groupedItems.length" class="flex flex-col gap-4">
        <section v-for="group in groupedItems" :key="group.key" class="space-y-2">
          <div
            class="tiptap-insert-panel__section-title px-1 text-[12px] font-semibold uppercase tracking-[0.06em]"
          >
            {{ group.label }}
          </div>

          <div class="grid auto-rows-fr grid-cols-2 gap-2">
            <button
              v-for="item in group.items"
              :key="item.key"
              type="button"
              class="tiptap-insert-panel__item flex min-w-0 items-start gap-3 rounded-xl border px-3 py-2.5 text-left transition-colors"
              :class="isActionEnabled(item) ? '' : 'tiptap-insert-panel__item--disabled'"
              :disabled="!isActionEnabled(item)"
              @click="handleSelect(item.key)"
            >
              <span
                class="tiptap-insert-panel__item-icon mt-0.5 inline-flex size-8 shrink-0 items-center justify-center rounded-lg"
              >
                <n-icon v-if="item.icon"><component :is="item.icon" /></n-icon>
                <n-icon v-else><AppstoreAddOutlined /></n-icon>
              </span>
              <span class="min-w-0 flex-1">
                <span class="tiptap-insert-panel__item-title block text-sm font-medium">
                  {{ item.label }}
                </span>
                <span class="tiptap-insert-panel__item-desc mt-1 block text-[12px] leading-5">
                  {{ item.description }}
                </span>
              </span>
            </button>
          </div>
        </section>
      </div>

      <div
        v-else
        class="tiptap-insert-panel__empty rounded-xl border border-dashed px-4 py-8 text-center text-sm"
      >
        {{ t('common.tiptap.insertEmpty') }}
      </div>
    </n-scrollbar>
  </div>
</template>

<script setup lang="ts">
  import { computed, ref, watch, type CSSProperties } from 'vue';
  import { AppstoreAddOutlined } from '@vicons/antd';
  import { useI18n } from 'vue-i18n';
  import { useThemeVars } from 'naive-ui';
  import {
    TIPTAP_QUICK_ACTION_GROUP_ORDER,
    createQuickActionGroupLabelMap,
    groupQuickActionItems,
  } from './actions';
  import type { TiptapQuickActionGroup, TiptapQuickActionItem } from './types';

  interface Props {
    items?: TiptapQuickActionItem[];
    disabled?: boolean;
    open?: boolean;
    canRun?: (item: TiptapQuickActionItem) => boolean;
  }

  const props = withDefaults(defineProps<Props>(), {
    items: () => [],
    disabled: false,
    open: false,
    canRun: undefined,
  });

  const emit = defineEmits<{
    select: [key: string];
  }>();

  const { t } = useI18n();
  const themeVars = useThemeVars();
  const query = ref('');
  const activeGroup = ref<'all' | TiptapQuickActionGroup>('all');
  const themeStyle = computed<CSSProperties>(() => ({
    '--tiptap-panel-bg': themeVars.value.popoverColor,
    '--tiptap-panel-card-bg': themeVars.value.cardColor,
    '--tiptap-panel-muted-bg': themeVars.value.actionColor,
    '--tiptap-panel-hover-bg': themeVars.value.hoverColor,
    '--tiptap-panel-border': themeVars.value.borderColor,
    '--tiptap-panel-text': themeVars.value.textColor1,
    '--tiptap-panel-text-2': themeVars.value.textColor2,
    '--tiptap-panel-text-3': themeVars.value.textColor3,
    '--tiptap-panel-primary': themeVars.value.primaryColor,
    '--tiptap-panel-primary-soft': themeVars.value.primaryColorSuppl,
  }));

  const groupLabelMap = computed(() => createQuickActionGroupLabelMap(t));

  const visibleGroups = computed(() => [
    {
      key: 'all' as const,
      label: t('common.all'),
      count: props.items.length,
    },
    ...TIPTAP_QUICK_ACTION_GROUP_ORDER.map((groupKey) => ({
      key: groupKey,
      label: groupLabelMap.value[groupKey],
      count: props.items.filter((item) => item.group === groupKey).length,
    })).filter((group) => group.count > 0),
  ]);

  const groupedItems = computed(() =>
    groupQuickActionItems(props.items, {
      query: query.value,
      activeGroup: activeGroup.value,
      groupLabelMap: groupLabelMap.value,
    }),
  );

  watch(
    () => props.open,
    (open) => {
      if (open) return;
      query.value = '';
      activeGroup.value = 'all';
    },
  );

  watch(
    () => props.items,
    (items) => {
      if (activeGroup.value !== 'all' && !items.some((item) => item.group === activeGroup.value)) {
        activeGroup.value = 'all';
      }
    },
    { deep: true },
  );

  function isActionEnabled(item: TiptapQuickActionItem) {
    if (props.disabled) return false;
    return props.canRun ? props.canRun(item) : true;
  }

  function handleSelect(key: string) {
    emit('select', key);
  }
</script>

<style scoped>
  .tiptap-insert-panel {
    background: var(--tiptap-panel-bg);
    color: var(--tiptap-panel-text);
  }

  .tiptap-insert-panel__group {
    border-color: var(--tiptap-panel-border);
    background: var(--tiptap-panel-card-bg);
    color: var(--tiptap-panel-text-2);
  }

  .tiptap-insert-panel__group:hover {
    border-color: var(--tiptap-panel-text-3);
    color: var(--tiptap-panel-text);
  }

  .tiptap-insert-panel__group--active {
    border-color: var(--tiptap-panel-primary);
    background: var(--tiptap-panel-primary-soft);
    color: var(--tiptap-panel-primary);
  }

  .tiptap-insert-panel__group-count {
    background: var(--tiptap-panel-muted-bg);
    color: var(--tiptap-panel-text-3);
  }

  .tiptap-insert-panel__group-count--active {
    background: var(--tiptap-panel-primary);
    color: #fff;
  }

  .tiptap-insert-panel__section-title {
    color: var(--tiptap-panel-text-3);
  }

  .tiptap-insert-panel__item {
    border-color: var(--tiptap-panel-border);
    background: var(--tiptap-panel-card-bg);
  }

  .tiptap-insert-panel__item:hover {
    border-color: var(--tiptap-panel-border);
    background: var(--tiptap-panel-hover-bg);
  }

  .tiptap-insert-panel__item:hover .tiptap-insert-panel__item-icon {
    background: var(--tiptap-panel-card-bg);
    color: var(--tiptap-panel-text);
  }

  .tiptap-insert-panel__item:hover .tiptap-insert-panel__item-title {
    color: var(--tiptap-panel-text);
  }

  .tiptap-insert-panel__item:hover .tiptap-insert-panel__item-desc {
    color: var(--tiptap-panel-text-2);
  }

  .tiptap-insert-panel__item--disabled {
    cursor: not-allowed;
    background: var(--tiptap-panel-muted-bg);
    opacity: 0.55;
  }

  .tiptap-insert-panel__item-icon {
    background: var(--tiptap-panel-muted-bg);
    color: var(--tiptap-panel-text-2);
  }

  .tiptap-insert-panel__item-title {
    color: var(--tiptap-panel-text);
  }

  .tiptap-insert-panel__item-desc,
  .tiptap-insert-panel__empty {
    color: var(--tiptap-panel-text-3);
  }

  .tiptap-insert-panel__empty {
    border-color: var(--tiptap-panel-border);
  }
</style>
