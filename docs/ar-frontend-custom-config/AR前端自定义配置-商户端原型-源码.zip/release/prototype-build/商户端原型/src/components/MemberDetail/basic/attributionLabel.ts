/**
 * 会员详情·归因卡片 / 括号数据标注 的「显示处翻译」工具。
 *
 * 原则（与 enum 显示映射一致）：
 * - 绝不改 src/api/index.ts 的 mock 原始中文值（改了会破坏中文态 + 逻辑比较）。
 * - 只在渲染处把已知中文短语映射成 i18n 文案；中文态 i18n 值＝原中文片段，替换后等于不变。
 * - 动态数据（邀请码 AGENT100 / 渠道名 Facebook-鲸鱼01 / 代理ID / 域名 / 真实姓名 Raj·李四 / 等级 L3）
 *   不在映射表里 → 自动原样保留。
 */

type TFn = (key: string, params?: Record<string, any>) => string;

/**
 * 整句映射：归因漏斗各字段的 mock 值是固定 demo 句，整句替换最稳（避免 token 拼接语序问题）。
 * key = mock 原始中文整句，value = i18n key（zh 值＝原句 / en 值＝译句）。
 */
const FULL_PHRASE_I18N: Record<string, string> = {
  邀请来源: 'member.detail.basic.attrPhrase.inviteSource',
  '正常邀请（个人邀请）': 'member.detail.basic.attrPhrase.normalInvitePersonal',
  '正常邀请（个人）': 'member.detail.basic.attrPhrase.normalInvitePersonalShort',
  '（正常邀请）': 'member.detail.basic.attrPhrase.normalInviteParen',
  '从 Facebook-鲸鱼01 渠道进入后手填个人邀请码（无广告标识）':
    'member.detail.basic.attrPhrase.sourceDescDemo',
  '主归因 邀请来源 渠道': 'member.detail.basic.attrPhrase.collectMainDemo',
  '注册时间 / IP / 设备 / 包名（见下方注册信息）': 'member.detail.basic.attrPhrase.collectMoreDemo',
  '主归因 / 注册渠道 / 注册时间 / 设备 / IP（归因快照，永不改写）':
    'member.detail.basic.attrPhrase.retainFixedDemo',
  '代理关系（上级 / 一级代理可后台划转）': 'member.detail.basic.attrPhrase.retainAdjustableDemo',
};

/**
 * 模板映射：含动态数据（邀请码 / 渠道编码 / 代理ID / 人名 / 设备名）的固定结构串，
 * 用正则抽出动态片段后用 i18n 插值（zh 模板＝原中文结构 / en 模板＝英文结构，括号与间隔符也英文化）。
 */
const PHRASE_TEMPLATES: Array<{
  re: RegExp;
  key: string;
  params: (m: RegExpMatchArray) => Record<string, any>;
}> = [
  // 设备：'Android（壳包）' / 'iOS（壳包）' → 'Android (Shell)' / 'iOS (Shell)'
  {
    re: /^(.+?)（壳包）$/,
    key: 'member.detail.basic.bracketTpl.shell',
    params: (m) => ({ name: m[1] }),
  },
  // 'ag010（代理专属链接）' → 'ag010 (Agent Link)'
  {
    re: /^(.+?)（代理专属链接）$/,
    key: 'member.detail.basic.bracketTpl.agentLink',
    params: (m) => ({ value: m[1] }),
  },
  // 'www.sit-inr.com（主站域名）' → 'www.sit-inr.com (Main Domain)'
  {
    re: /^(.+?)（主站域名）$/,
    key: 'member.detail.basic.bracketTpl.mainDomain',
    params: (m) => ({ value: m[1] }),
  },
  // 'm.sit-inr.com（推广域名）' → 'm.sit-inr.com (Promo Domain)'
  {
    re: /^(.+?)（推广域名）$/,
    key: 'member.detail.basic.bracketTpl.promoDomain',
    params: (m) => ({ value: m[1] }),
  },
  // '1250001（总代·Raj）' → '1250001 (Super Agent · Raj)'（Raj 人名保留）
  {
    re: /^(.+?)（总代·(.+?)）$/,
    key: 'member.detail.basic.bracketTpl.superAgentNamed',
    params: (m) => ({ id: m[1], name: m[2] }),
  },
  // 'Raj（总代）' → 'Raj (Super Agent)'（代理线表格 nickname；Raj 人名保留）
  {
    re: /^(.+?)（总代）$/,
    key: 'member.detail.basic.bracketTpl.superAgentSuffix',
    params: (m) => ({ name: m[1] }),
  },
  // '个人邀请码 AGENT100（手填）' → 'Personal Invite Code AGENT100 (Manual)'
  {
    re: /^个人邀请码\s+(\S+)（手填）$/,
    key: 'member.detail.basic.attrPhrase.inviteCodeManual',
    params: (m) => ({ code: m[1] }),
  },
  // '填了邀请码 AGENT100' → 'Filled invite code AGENT100'
  {
    re: /^填了邀请码\s+(\S+)$/,
    key: 'member.detail.basic.attrPhrase.filledInviteCode',
    params: (m) => ({ code: m[1] }),
  },
  // 'apk-fb-me001-01，邀请码 AGENT100' → 'apk-fb-me001-01, invite code AGENT100'
  {
    re: /^(.+?)，邀请码\s+(\S+)$/,
    key: 'member.detail.basic.attrPhrase.channelWithCode',
    params: (m) => ({ channel: m[1], code: m[2] }),
  },
  // '1级·总代' → 'Level 1 · Super Agent'（代理线表格 level，亦由 useBasicInfo 处理；此处兜底）
  {
    re: /^(\d+)级·总代$/,
    key: 'member.detail.basic.bracketTpl.levelSuperAgent',
    params: (m) => ({ n: m[1] }),
  },
];

/**
 * 翻译归因漏斗字段值（整句优先 → 结构模板 → 原样兜底）。
 */
export function attrLabel(t: TFn, raw: any): any {
  if (raw == null || raw === '') return raw;
  const s = String(raw).trim();
  const full = FULL_PHRASE_I18N[s];
  if (full) return t(full);
  for (const tpl of PHRASE_TEMPLATES) {
    const m = s.match(tpl.re);
    if (m) return t(tpl.key, tpl.params(m));
  }
  // 未命中（纯数据 / 'ID（人名）' 如 '2250100（李四）'）→ 原样（李四是姓名，保留）
  return s;
}

/**
 * 翻译括号数据标注（设备 / 渠道 / 域名 / 代理 ID 串）。逻辑与 attrLabel 一致，
 * 命名独立以便 buildDetailData 语义清晰。
 */
export function bracketLabel(t: TFn, raw: any): any {
  return attrLabel(t, raw);
}

/**
 * 会员状态显示映射：enableStateList 字典只有中文，英文态会漏中文，
 * 故状态走 member.user.enabled/disabled（已有 zh=启用·禁用 / en=Enabled·Disabled）。
 * 入参可能是字典 label（启用/禁用）或数值 state（1/0）。
 */
export function stateLabel(t: TFn, raw: any, userState?: any): any {
  const s = String(raw ?? '').trim();
  if (s === '启用' || userState === 1 || userState === '1') return t('member.user.enabled');
  if (s === '禁用' || userState === 0 || userState === '0') return t('member.user.disabled');
  return raw;
}

/**
 * 备注 remark 显示映射：备注是「逗号分隔的有限标签（+ 自由文本）」。
 * 按中文/英文逗号拆分，每段命中已知标签映射则翻译，未命中（纯自由文本）原样。
 * 复用 member.user.enum.remark.* 既有键 + 新增 followUpDeposit。
 */
const REMARK_TOKEN_I18N: Record<string, string> = {
  高价值客户: 'member.user.enum.remark.highValue',
  风控关注: 'member.user.enum.remark.riskWatch',
  风控拉黑: 'member.user.enum.remark.riskBlock',
  推广拉新: 'member.user.enum.remark.acquisition',
  内部代理: 'member.user.enum.remark.internalAgent',
  'VIP 代理': 'member.user.enum.remark.vipAgent',
  VIP代理: 'member.user.enum.remark.vipAgent',
  已禁用: 'member.user.enum.remark.disabledTag',
  测试账号: 'member.user.enum.remark.test',
  'VIP 客户': 'member.user.enum.remark.vipClient',
  风控标记: 'member.user.enum.remark.riskFlag',
  跟进充值情况: 'member.user.enum.remark.followUpDeposit',
};
export function remarkLabel(t: TFn, raw: any): any {
  if (raw == null || raw === '') return raw;
  const s = String(raw);
  // 含 HTML 实体 / 标签的备注不拆分（保留原始编码供 getSafeHtml 渲染）
  if (/[<&]/.test(s)) return raw;
  const segs = s.split(/[，,]/).map((p) => p.trim());
  const translated = segs.map((seg) => {
    const key = REMARK_TOKEN_I18N[seg];
    return key ? t(key) : seg;
  });
  return translated.join(', ');
}
