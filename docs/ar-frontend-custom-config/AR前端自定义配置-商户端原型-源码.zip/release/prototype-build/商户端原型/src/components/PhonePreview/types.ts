export type PhonePreviewTerminal = 'pc' | 'h5' | 'app';

export interface PhonePreviewTerminalOption {
  label: string;
  value: PhonePreviewTerminal;
}

export interface PhonePreviewModel {
  /** 预览卡片标题。 */
  title: string;
  /** 右上角标签文案。 */
  tagLabel?: string;
  /** 右上角标签类型。 */
  tagType?: 'default' | 'info' | 'success' | 'warning' | 'error';
  /** 站点展示名称。 */
  siteName?: string;
  /** 当前租户展示名称。 */
  tenantLabel?: string;
  /** 预览根地址。 */
  baseUrl?: string;
  /** 各终端对应的 iframe 地址。 */
  iframeSrcMap: Partial<Record<PhonePreviewTerminal, string>>;
  /** 当前是否具备预览条件。 */
  canRender: boolean;
  /** 不可预览时的提示文案。 */
  emptyDescription: string;
  /** 新窗口打开按钮文案。 */
  openButtonText?: string;
  /** 默认选中的终端。 */
  defaultTerminal?: PhonePreviewTerminal;
  /** 可切换的终端列表。 */
  terminalOptions?: PhonePreviewTerminalOption[];
}
