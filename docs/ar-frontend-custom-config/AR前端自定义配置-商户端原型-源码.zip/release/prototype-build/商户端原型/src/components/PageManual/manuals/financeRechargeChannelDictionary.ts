// 充值通道字典（总控端 admin · finance_merchant_recharge_channel_page）功能说明书。
// 锚定 src/views/finance/rechargeType/rechargeChannelDictionary/index.vue + data.ts +
// components/{RechargeChannelDictionaryEditModal,PaymentChannelTestModal}.vue 真实控件（R53 实证、不臆造）。
// 路由 meta.roles:['admin']——虽然路由 name 里带 "merchant" 字样，但实际只在总控端(3200)可见，商户端(3100)访问不到，如实记录。
// 单表 ProCrudTable：外层 n-tabs 只有 1 个 tab-pane（无第二个 tab 可切），全站唯一维护充值通道基础数据的全局字典页，无商户筛选。

import type { PageManual } from '../types';

const manual: PageManual = {
  route: 'finance_merchant_recharge_channel_page',
  title: '充值通道字典',
  overview:
    '总控端「财务管理 › 充值配置」下的通道字典页（页内 Tab 文案"充值通道字典"），维护全平台可用的充值通道基础数据（三方映射码/通道编码/支付模式/内置充值大类/币种/网关地址等），供各商户在其充值渠道配置里选用；本页不带商户筛选，是跨商户共享的全局字典。页面用 n-tabs 包了一层，但内部只有 1 个 tab-pane（"充值通道字典"），没有第二个 tab 可切，属外层容器写法遗留，并非真正的多标签结构，故本说明书不建"切换 Tab"条目。系统内置的 8 个通道（payCode=SystemBuiltIn，id 固定为 9/3/0/1/82/156/157/158）在「三方映射码」列并列显示"内置"角标，操作列固定显示"--"占位，没有代收测试/编辑入口。',
  items: [
    // ============ 搜索区 ============
    {
      anchor: 'channelCategoryId',
      name: '内置充值大类',
      group: '搜索',
      interaction: '下拉单选，可清空，可搜索（filterable）。',
      dataSource:
        '下拉展开时才请求 api.recharge.rechargeChannelDictionaryGetRechargeCategoryEnumList()（按币种分键缓存，本搜索场景固定传"全币种"键，不随本页「充值币种」搜索项联动）。',
      logic:
        '选中后按 categoryId 过滤列表；选择（或清空）本项会联动把「三方映射码」「通道名称」两个搜索框已选值清空（onUpdate:value 里直接置 formModel.mappingCode/channelName = null）。',
      limit: '选填，可清空。',
      edge:
        '⚠️ 核实代码后发现：清空「三方映射码」「通道名称」只是重置这两项的已选值，并不会真正按大类过滤这两个下拉的候选列表——候选数据来自另一个接口 GetChannelSelectData，该接口不接受 categoryId 参数，如实记录，非本次引入。',
      note: '与「三方映射码」列上系统内置通道显示的"内置"角标是两个不同概念，只是都用了"内置"两字，注意别混淆。',
    },
    {
      anchor: 'mappingCode',
      name: '三方映射码',
      group: '搜索',
      interaction: "下拉单选，可清空，可搜索；声明 dependencies:['channelCategoryId']。",
      dataSource: "下拉展开时才请求 api.common.getChannelSelectData({channelType:'Recharge'})，取返回的 payCodes 列表。",
      logic:
        '选中后按 payCode 过滤列表；同时联动重置「通道名称」已选值，并按新选的映射码重新拉取通道名称候选（handleMappingCodeChange）；清空本项也会触发同样重置、通道名称候选回退为全量。',
      limit: '选填，可清空。',
      edge:
        "⚠️ 核实代码后发现：声明的 dependencies:['channelCategoryId'] 只是表单框架层面的依赖标记，本项候选列表实际不随「内置充值大类」变化（同上一条 edge），如实记录。",
    },
    {
      anchor: 'channelName',
      name: '通道名称',
      group: '搜索',
      interaction: "下拉单选，可清空，可搜索；声明 dependencies:['mappingCode', 'channelCategoryId']。",
      dataSource:
        '与「三方映射码」共用同一个 GetChannelSelectData 接口的 channelNames 字段；下拉展开时按当前已选「三方映射码」联动请求（handleChannelNameDropdown），未选映射码则拉全量。',
      logic:
        '下拉选项 value 用通道字典 id（非 name，避免同名不同 id 的记录被合并）；选中后 buildListRequest 直接下发 channelId = 该 id 精确过滤，不做 id→name 反查。',
      limit: '选填，可清空。',
      edge:
        '本页搜索区 6 项里，只有「三方映射码 → 通道名称」这一对存在真实的服务端候选过滤联动；「内置充值大类」「充值币种」都不参与这条联动链。',
    },
    {
      anchor: 'currency',
      name: '充值币种',
      group: '搜索',
      interaction: '下拉单选，可清空，可搜索。',
      dataSource: '下拉展开时请求同一个 GetChannelSelectData 接口的 sysCurrencies 字段（全量返回，不按其它已选项过滤）。',
      logic: '选中后按 sysCurrency 过滤列表。',
      limit: '选填，可清空。',
    },
    {
      anchor: 'payMode',
      name: '支付模式',
      group: '搜索',
      interaction: '下拉单选，可清空；下拉带 loading 态。',
      dataSource:
        '页面 onMounted 时即预取一次 + 下拉展开时兜底调用 api.recharge.getPayModeList()（真实返回 4 项：原生=1 / 二维码=2 / 唤醒=3 / H5=4）；请求失败才会回退到本地 createFallbackPayModeOptions()。',
      logic: '选中后按 payMode 过滤列表。',
      limit: '选填，可清空。',
      edge:
        '⚠️ 核实代码后发现真实缺陷：本地兜底选项 createFallbackPayModeOptions()（1=唤醒 / 2=原生 / 3=二维码，仅 3 项）与接口真实返回的 PAY_MODE_OPTIONS（1=原生 / 2=二维码 / 3=唤醒 / 4=H5，4 项）编号完全对不上——一旦真的走到兜底分支，下拉显示的"原生/二维码/唤醒"会与列表里同编号数据实际代表的支付模式互相错位，且缺 H5。当前 mock 版 getPayModeList 是纯本地函数、恒不抛错，兜底分支实际不可达（dormant），但代码本身确实存在这处不一致，如实记录，非本次引入，本次不修复。',
    },
    {
      anchor: 'status',
      name: '状态',
      group: '搜索',
      interaction: '下拉单选，可清空。',
      dataSource: '本地固定 2 项：启用(1) / 禁用(0)。',
      logic: '选中后按 state 过滤列表。',
      limit: '选填，可清空。',
    },

    // ============ 列 ============
    {
      anchor: 'col_state',
      name: '启用状态列（开关）',
      group: '列',
      interaction: '开关（ConfirmSwitch，切换需二次确认弹窗）。',
      dataSource: '行数据 state（1=启用 / 0=禁用）。',
      logic:
        '确认后调用 api.recharge.rechargeChannelDictionaryUpdateState({id, state}) 更新该行状态，成功后 Toast 提示并整表刷新（tableRef.reload()）。',
      limit: "系统内置通道（payCode==='SystemBuiltIn'）禁用该开关，恒不可切换。",
    },

    // ============ 操作 ============
    {
      anchor: 'act_test',
      name: '行操作 · 代收测试',
      group: '操作',
      interaction:
        '点击打开「代收测试」弹窗（PaymentChannelTestModal），弹窗内两个可折叠区块：拉单测试（输入金额 + 提交）、回调测试（请求头 / 回调 Body 两个 JSON 文本域 + 提交）。',
      logic:
        '两个提交按钮均只是本地延时 500ms 后弹成功 Toast（pullSubmitSuccess / callbackSubmitSuccess），不发真实请求，纯原型交互反馈。',
      edge:
        `⚠️ 核实代码后发现：index.vue 里 .recharge-channel-dictionary__action-btn--test .n-button__content { display: none; } 这条样式把本按钮"代收测试"四个字的可见文本隐藏掉了——「编辑」按钮没有这条覆盖、文字正常显示；本按钮本身仍可点击（onClick 逻辑未受影响），只是没有可见文案，如实记录，非本次引入，本次不修复。系统内置通道（payCode==='SystemBuiltIn'）行不显示此按钮，显示"--"占位。`,
    },
    {
      anchor: 'act_edit',
      name: '行操作 · 编辑',
      group: '操作',
      interaction:
        "点击打开编辑弹窗（RechargeChannelDictionaryEditModal），弹窗先以 loading 态打开，随后异步请求 api.recharge.rechargeChannelDictionaryGet({id}) 拉最新详情回填表单（不是直接复用列表行数据）。同一弹窗组件也承接新增模式（openDictionaryModal('create', …)），但见下方 edge。",
      dataSource:
        "弹窗内「内置充值大类」下拉单独按该行 sysCurrency 请求一次大类枚举（与搜索区『内置充值大类』复用的全量缓存是两份不同请求）；行 payCode==='ArbPayINR' 时改为跳过接口调用、大类下拉锁定只读（categoryLocked，禁用+不可清空），label 由 fallbackCategoryLabel 兜底显示。",
      logic:
        '表单含内置充值大类 / 通道名称 / 三方通道编码 / 网关地址 / 支付模式共 5 项，校验通过后调用 rechargeChannelDictionaryUpdate 提交，成功后 Toast 提示、关闭弹窗并整表刷新。',
      limit:
        '内置充值大类必选；通道名称必填、最多 30 字；三方通道编码选填、最多 200 字；网关地址必填、最多 50 字且须以 http:// 或 https:// 开头；支付模式必选。',
      edge:
        "⚠️ 核实代码后发现真实缺陷：本页搜索工具栏没有任何「新增」按钮——openDictionaryModal('create', …)、buildDictionaryPayload、api.recharge.rechargeChannelDictionaryAdd、i18n key finance.recharge.channel.addDictionary（\"新增充值通道字典\"）全部已实现且随时可用，但整个页面没有一处 UI 会以 mode='create' 调用它，新增功能当前完全不可达；对比同目录兄弟页 rechargeChannel/index.vue、rechargeCategory/index.vue 均在工具栏放了「新增」按钮，本页明显是遗漏了对应入口。另外 categoryLocked（大类下拉禁用+不可清空）只在 row.payCode==='ArbPayINR' 时触发，但当前 mock 的 8 条非内置数据里没有任何一条 payCode 是 ArbPayINR，该分支在本页现有数据下不会被触发。均如实记录，非本次引入，本次不修复。系统内置通道（payCode==='SystemBuiltIn'）行不显示此按钮，显示\"--\"占位。",
    },
  ],

  // ============ 字段介绍 tab（列序照页面；仅列表列 + 定义）============
  fields: [
    {
      name: '通道字典ID',
      def: '该充值通道字典记录的主键 id；系统内置的 8 个通道固定为 9 / 3 / 0 / 1 / 82 / 156 / 157 / 158。',
    },
    { name: '通道名称', def: '该通道的名称；超长省略号 + 悬浮提示（ellipsis tooltip）。' },
    {
      name: '三方映射码',
      def: "对接三方支付的映射码（payCode），以标签展示；系统内置通道该值固定为 SystemBuiltIn，额外并列展示一个\"内置\"角标（isBuiltInRow 判定：payCode==='SystemBuiltIn' 或 id 命中内置的 8 个 channelId 之一）。",
    },
    {
      name: '三方通道编码',
      def: '三方支付渠道自身的通道编码（thirdChannelCode），如 UPI / upi / UPIQR / wakeup 等；超长省略号 + 悬浮提示。',
    },
    {
      name: '支付模式',
      def: '该通道的支付交互方式：原生 / 二维码 / 唤醒 / H5（按字典 id 查名称，查不到显示"--"）。',
    },
    {
      name: '内置充值大类',
      def: '该通道归属的内置充值大类（如 Local Bank / Local UPI / 三方法币等），以彩色标签展示（按 categoryId 查 common 字典 rechargeCategoryEnumList）。',
    },
    { name: '充值币种', def: '该通道支持的充值币种（如 INR / USDT），以标签展示。' },
    { name: '网关地址', def: '三方支付网关的请求地址（thirdPayApiUrl）；超长省略号 + 悬浮提示。' },
    {
      name: '最后修改人',
      def: '最近一次更新该通道记录的操作人；字段为空时回退显示创建人（row.lastUpdateMan || row.creator）。',
    },
    { name: '最后修改时间', def: '该通道记录最近一次更新的时间，按当前操作商户所在时区显示（showTenantTimeZone）。' },
    {
      name: '启用状态',
      def: '该通道当前是否对外可用；可点击开关直接切换（系统内置通道锁定为恒启用、不可切换）。',
    },
  ],
};

export default manual;
