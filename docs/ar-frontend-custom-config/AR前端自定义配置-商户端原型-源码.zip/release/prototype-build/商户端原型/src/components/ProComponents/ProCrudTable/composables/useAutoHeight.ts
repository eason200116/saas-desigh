/**
 * @description ProCrudTable 自适应高度计算：跟踪容器、汇总区和底部工具栏高度，动态计算表格可用最大高度。
 * @author
 * @date 2026-04-17
 * @scope 仅用于 `src/components/ProComponents/ProCrudTable/composables/useAutoHeight.ts`
 */
import {
  ref,
  computed,
  inject,
  onMounted,
  onBeforeUnmount,
  watch,
  nextTick,
  type Ref,
  type ComputedRef,
} from 'vue';
import { useWindowSize } from '@vueuse/core';
import { ProTabsHeightContextKey } from '@/components/ProComponents/ProTabs';
import { LayoutContentRectKey } from '@/layout/contentRectContext';

export interface UseAutoHeightOptions {
  /** ProCrudTable 根元素（.pro-crud-table），用于自身高度计算 */
  rootRef: Ref<HTMLElement | null>;
  /** 表格滚动容器（.pro-crud-table__table-wrapper），用于 n-data-table max-height 计算 */
  containerRef: Ref<HTMLElement | null>;
  summaryRef?: Ref<HTMLElement | null>;
  footerRef: Ref<HTMLElement | null>;
  autoHeight: ComputedRef<boolean>;
  autoHeightOffset: ComputedRef<number>;
  maxHeight: ComputedRef<number | string | undefined>;
}

export interface UseAutoHeightReturn {
  /** n-data-table :max-height（表格主体的上限/目标高度） */
  actualMaxHeight: ComputedRef<number | string | undefined>;
  /**
   * ProCrudTable 根元素的目标高度（px）。
   * 让组件自己撑到 ceiling，不依赖父链 flex。autoHeight=false 时为 undefined（保留自然高度）。
   */
  containerHeight: ComputedRef<number | undefined>;
  recalculate: () => void;
  lockHeight: () => void;
  unlockHeight: () => void;
}

function normalizeHeightValue(value: number | string | undefined): number | undefined {
  if (value === undefined) return undefined;
  const num = typeof value === 'string' ? parseFloat(value) : value;
  return Number.isFinite(num) ? num : undefined;
}

export function useAutoHeight(options: UseAutoHeightOptions): UseAutoHeightReturn {
  const { height: windowHeight } = useWindowSize();
  // ceiling 三级优先级：
  //   1. ProTabs paneRect.bottom — 在 ProTabs 内（含弹窗嵌入），最准确
  //   2. Layout contentRect.bottom — 非 ProTabs 但在主 layout 内，已扣除 layout-content
  //      的 padding-bottom（避免 ProCrudTable 超出 8px 触发 overflow:auto 滚动）
  //   3. windowHeight — 兜底，覆盖独立 layout / Teleport 到 body 的弹窗根等场景
  const tabsHeightCtx = inject(ProTabsHeightContextKey, null);
  const layoutContentCtx = inject(LayoutContentRectKey, null);
  const ceiling = computed(() => {
    const paneBottom = tabsHeightCtx?.paneRect.value.bottom;
    if (typeof paneBottom === 'number' && paneBottom > 0) return paneBottom;
    const contentBottom = layoutContentCtx?.contentRect.value.bottom;
    if (typeof contentBottom === 'number' && contentBottom > 0) return contentBottom;
    return windowHeight.value;
  });
  const stableRootTop = ref(0);
  const stableContainerTop = ref(0);
  const stableSummaryHeight = ref(0);
  const stableFooterHeight = ref(0);
  // 我们的 actualMaxHeight 公式是 "wrapper 内除 summary/footer 外的剩余"，本意是 thead + body
  // 的预算。但 naive 的 :max-height 是 body 自身的最大高度（不含 thead），所以必须从公式里
  // 再扣掉 thead 实测高度，否则 body 多撑 thead 高度，触发 wrapper 内容溢出 / 视觉留白偏大。
  const stableTheadHeight = ref(0);
  const isHeightLocked = ref(false);
  const lockedHeight = ref<number | undefined>(undefined);

  let rootObserver: ResizeObserver | null = null;
  let containerObserver: ResizeObserver | null = null;
  let summaryObserver: ResizeObserver | null = null;
  let footerObserver: ResizeObserver | null = null;
  let theadObserver: ResizeObserver | null = null;

  /** 在 containerRef 内查 naive 的 thead 元素；找不到（异步数据未渲染）返回 null */
  function queryTheadEl(): HTMLElement | null {
    const el = options.containerRef.value?.querySelector('.n-data-table-thead');
    return el instanceof HTMLElement ? el : null;
  }

  function updatePositions() {
    if (options.rootRef.value) {
      stableRootTop.value = options.rootRef.value.getBoundingClientRect().top;
    }
    if (options.containerRef.value) {
      stableContainerTop.value = options.containerRef.value.getBoundingClientRect().top;
    }
    if (options.summaryRef?.value) {
      stableSummaryHeight.value = options.summaryRef.value.offsetHeight;
    }
    if (options.footerRef.value) {
      stableFooterHeight.value = options.footerRef.value.offsetHeight;
    }
    const theadEl = queryTheadEl();
    if (theadEl) {
      stableTheadHeight.value = theadEl.offsetHeight;
    }
  }

  function setupObservers() {
    cleanupObservers();
    if (options.rootRef.value) {
      rootObserver = new ResizeObserver(() => {
        if (!isHeightLocked.value) updatePositions();
      });
      rootObserver.observe(options.rootRef.value);
    }
    if (options.containerRef.value) {
      containerObserver = new ResizeObserver(() => {
        if (!isHeightLocked.value) updatePositions();
      });
      containerObserver.observe(options.containerRef.value);
    }
    if (options.summaryRef?.value) {
      summaryObserver = new ResizeObserver(() => {
        if (!isHeightLocked.value) updatePositions();
      });
      summaryObserver.observe(options.summaryRef.value);
    }
    if (options.footerRef.value) {
      footerObserver = new ResizeObserver(() => {
        if (!isHeightLocked.value) updatePositions();
      });
      footerObserver.observe(options.footerRef.value);
    }
    // thead 由 naive 内部渲染（异步可能晚到），首次 setupObservers 可能找不到。
    // 第二次（refs watch 触发 nextTick(setupObservers)）通常已就绪。
    const theadEl = queryTheadEl();
    if (theadEl) {
      theadObserver = new ResizeObserver(() => {
        if (!isHeightLocked.value) updatePositions();
      });
      theadObserver.observe(theadEl);
    }
  }

  function cleanupObservers() {
    rootObserver?.disconnect();
    containerObserver?.disconnect();
    summaryObserver?.disconnect();
    footerObserver?.disconnect();
    theadObserver?.disconnect();
    rootObserver = null;
    containerObserver = null;
    summaryObserver = null;
    footerObserver = null;
    theadObserver = null;
  }

  onMounted(() => {
    nextTick(() => {
      updatePositions();
      setupObservers();
    });
  });

  onBeforeUnmount(cleanupObservers);

  const observerSources: Ref<HTMLElement | null>[] = [
    options.rootRef,
    options.containerRef,
    options.footerRef,
  ];
  if (options.summaryRef) {
    observerSources.splice(2, 0, options.summaryRef);
  }

  watch(observerSources, () => nextTick(setupObservers));
  // 天花板变化（window resize 或 ProTabs pane 几何变化）→ container top 可能位移，重测
  watch([windowHeight, ceiling], updatePositions);

  const actualMaxHeight = computed(() => {
    if (options.maxHeight.value !== undefined) return options.maxHeight.value;
    if (isHeightLocked.value && lockedHeight.value !== undefined) return lockedHeight.value;
    if (options.autoHeight.value && stableContainerTop.value && ceiling.value) {
      // thead 基线 = naive size="small" 单行 thead 高度 ≈ 38px，已被下面的 -50 安全 buffer 覆盖。
      // 中文环境 thead 通常 1 行 = 38 → theadExtra = 0，不额外扣；
      // 英文环境 thead 易换 2 行 ≈ 76 → theadExtra = 38，body 收缩 38px，避免视觉空白变大。
      // 取 max(...,0) 是兜底：thead 异常小于基线时不变成负数。
      const THEAD_BASELINE = 38;
      const theadExtra = Math.max(stableTheadHeight.value - THEAD_BASELINE, 0);
      const available =
        ceiling.value -
        stableContainerTop.value -
        theadExtra -
        stableSummaryHeight.value -
        stableFooterHeight.value -
        options.autoHeightOffset.value -
        50;
      return Math.max(Math.floor(available), 200);
    }
    return undefined;
  });

  /**
   * ProCrudTable 根元素自身的目标高度：让组件自己撑到 ceiling，不靠父链 flex。
   * - autoHeight=false 时返回 undefined（保留自然高度，等价旧行为）
   * - rootTop / ceiling 还没就绪时返回 undefined（避免首帧闪烁到 200）
   *
   * 注意：这里**不**减 autoHeightOffset。该 offset 是 n-data-table body 的底部安全边距，
   * 已在 actualMaxHeight 中扣除一次。在容器层再减会双重计费，造成 .pro-crud-table 与
   * 父容器（ProTabs paneRect.bottom / viewport）之间出现 offset 大小的空白。
   */
  const containerHeight = computed<number | undefined>(() => {
    if (!options.autoHeight.value) return undefined;
    if (!stableRootTop.value || !ceiling.value) return undefined;
    const h = ceiling.value - stableRootTop.value;
    return Math.max(Math.floor(h), 200);
  });

  function recalculate() {
    nextTick(updatePositions);
  }

  function lockHeight() {
    lockedHeight.value = normalizeHeightValue(actualMaxHeight.value);
    isHeightLocked.value = true;
  }

  function unlockHeight() {
    nextTick(() => {
      updatePositions();
      requestAnimationFrame(() => {
        isHeightLocked.value = false;
        lockedHeight.value = undefined;
      });
    });
  }

  return { actualMaxHeight, containerHeight, recalculate, lockHeight, unlockHeight };
}
