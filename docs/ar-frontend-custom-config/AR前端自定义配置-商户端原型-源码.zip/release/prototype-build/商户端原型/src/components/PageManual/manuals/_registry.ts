// 说明书聚合表 —— import.meta.glob 自动收本目录下每个 <页>.ts（照 DevLocator spec-data/pages 先例）。
// 新增一页说明书：在 manuals/ 下加一个 <page>.ts，default 导出 PageManual、route 填路由 name 即可，无需改本文件。

import type { PageManual } from '../types';

const mods = import.meta.glob('./*.ts', { eager: true }) as Record<string, { default?: PageManual }>;

const BY_ROUTE: Record<string, PageManual> = {};
for (const path in mods) {
  if (path.endsWith('_registry.ts')) continue; // 跳过自己
  const m = mods[path]?.default;
  if (!m?.route) continue;
  BY_ROUTE[m.route] = m;
  for (const alias of m.routeAliases ?? []) BY_ROUTE[alias] = m;
}

function localize(manual: PageManual, locale?: string | null): PageManual {
  const localized = manual.locales?.[locale || ''];
  return localized ? { ...manual, ...localized } : manual;
}

/** 按路由 name 与可选页签上下文取说明书；语言缺失时回退根层简体中文。 */
export function getManual(
  routeName?: string | null,
  locale?: string | null,
  context?: string | null,
): PageManual | null {
  if (!routeName) return null;
  const manual = (context ? BY_ROUTE[`${routeName}:${context}`] : null) ?? BY_ROUTE[routeName];
  return manual ? localize(manual, locale) : null;
}
