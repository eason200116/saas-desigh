<template>
  <div class="brand-plate" :class="[`brand-plate--${variant}`]">
    <span v-if="resolvedBadge" class="brand-plate__badge">{{ resolvedBadge }}</span>
    <div class="brand-plate__body">
      <div class="brand-plate__logo-wrap">
        <ArLogo :size="logoSize" :label="label" :decorative="decorative" />
      </div>
      <div v-if="hasCopy" class="brand-plate__copy">
        <component :is="titleTag" v-if="resolvedTitle || $slots.title" class="brand-plate__title">
          <slot name="title">{{ resolvedTitle }}</slot>
        </component>
        <span v-if="subtitle || $slots.subtitle" class="brand-plate__subtitle">
          <slot name="subtitle">{{ subtitle }}</slot>
        </span>
      </div>
    </div>
  </div>
</template>

<script lang="ts" setup>
  /**
   * 品牌名片：把 ArLogo + 可选的 badge / 主标题 / 副标题 组合成统一的品牌身份块。
   * - variant=glass  : 大尺寸玻璃方框包 logo + 巨标题（用于深色 hero / 落地页）
   * - variant=inline : logo 横排在文字左侧（通用 header / 横幅）
   * - variant=stack  : logo 居顶、eyebrow 居中 + 标题（用于表单 panel head）
   * 颜色和品牌色板自动跟随 ArLogo（即 SOURCE_PALETTE + 主题色 transform）。
   */
  import { computed, useSlots } from 'vue';
  import ArLogo from './ArLogo.vue';

  defineOptions({ name: 'BrandPlate' });

  type BrandPlateVariant = 'glass' | 'inline' | 'stack';

  const props = withDefaults(
    defineProps<{
      variant?: BrandPlateVariant;
      logoSize?: number;
      /** 顶部小标签（uppercase pill / eyebrow） */
      badge?: string;
      /** 主标题文本（亦可用 #title 插槽） */
      title?: string;
      /** 副标题（亦可用 #subtitle 插槽） */
      subtitle?: string;
      /** 标题语义级别 */
      titleTag?: 'h1' | 'h2' | 'h3';
      /** ArLogo 的 aria-label */
      label?: string;
      /** ArLogo 是否设为装饰性（屏幕阅读器忽略） */
      decorative?: boolean;
    }>(),
    {
      variant: 'inline',
      logoSize: 56,
      titleTag: 'h2',
      decorative: true,
    },
  );

  const slots = useSlots();
  const resolvedBadge = computed(() => props.badge);
  const resolvedTitle = computed(() => props.title);
  const hasCopy = computed(
    () => !!(resolvedTitle.value || props.subtitle || slots.title || slots.subtitle),
  );
</script>

<style lang="less" scoped>
  .brand-plate {
    display: flex;
    flex-direction: column;
    gap: 14px;
    color: inherit;
  }

  .brand-plate__badge {
    display: inline-flex;
    align-items: center;
    align-self: flex-start;
    padding: 6px 14px;
    border: 1px solid currentColor;
    border-radius: 999px;
    font-size: 12px;
    font-weight: 700;
    letter-spacing: 0.18em;
    text-transform: uppercase;
    opacity: 0.78;
  }

  .brand-plate__body {
    display: flex;
    align-items: center;
    gap: 18px;
  }

  .brand-plate__logo-wrap {
    display: flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
  }

  .brand-plate__copy {
    display: flex;
    flex-direction: column;
    gap: 4px;
    min-width: 0;
  }

  .brand-plate__title {
    margin: 0;
    font-weight: 700;
    line-height: 1.08;
    letter-spacing: -0.03em;
  }

  .brand-plate__subtitle {
    font-size: 13px;
    color: currentColor;
    opacity: 0.72;
  }

  // ─── glass：登录 hero 风格（深色背景 + 玻璃方框 logo + 巨标题） ───
  .brand-plate--glass {
    .brand-plate__badge {
      padding: 8px 14px;
      border-color: rgb(255 255 255 / 0.18);
      background: rgb(255 255 255 / 0.12);
      font-size: 13px;
      letter-spacing: 0.12em;
      backdrop-filter: blur(10px);
      opacity: 1;
    }

    .brand-plate__logo-wrap {
      width: 104px;
      height: 104px;
      border-radius: 28px;
      background: rgb(255 255 255 / 0.14);
      box-shadow:
        inset 0 1px 0 rgb(255 255 255 / 0.16),
        0 18px 40px rgb(3 12 30 / 0.16);
      backdrop-filter: blur(12px);
    }

    .brand-plate__title {
      font-size: clamp(44px, 5vw, 56px);
      letter-spacing: -0.04em;
    }
  }

  // ─── inline：横排（logo 左 + 文字右），适合通用 banner / header ───
  .brand-plate--inline {
    .brand-plate__title {
      font-size: 22px;
    }
  }

  // ─── stack：纵排（badge eyebrow 上、logo 中、title 下），适合表单 head ───
  .brand-plate--stack {
    align-items: center;
    gap: 8px;
    text-align: center;

    .brand-plate__badge {
      align-self: center;
      padding: 0;
      border: none;
      background: transparent;
      font-size: 12px;
      letter-spacing: 0.18em;
      color: var(--ui-accent-solid, currentColor);
      opacity: 1;
    }

    .brand-plate__body {
      flex-direction: column;
      gap: 8px;
    }

    .brand-plate__copy {
      align-items: center;
    }

    .brand-plate__title {
      font-size: 32px;
      color: #20314f;
    }
  }

  @media (max-width: 1240px) {
    .brand-plate--glass {
      .brand-plate__logo-wrap {
        width: 92px;
        height: 92px;
      }
    }
  }

  @media (max-width: 768px) {
    .brand-plate--stack .brand-plate__title {
      font-size: 24px;
    }
  }
</style>
