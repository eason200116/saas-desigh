// 分组管理（商户端 tenant · member_group_manage）功能说明书。
// 锚定 src/views/member/groupManage/index.vue + data.ts + components/{MemberGroupFormModal,DataDisplayConfigModal}.vue 真实控件（R53 实证、不臆造）。
// 单表 ProCrudTable：系统结构型分组（默认/黑名单/代理，按查询商户各生成一套、恒置顶冻结前 3 行）+ 自定义分组（含用户自建黑名单，单商户单行、同商户可多行）。
// 新增/编辑走 MemberGroupFormModal；行「分组配置」走同一弹窗 3 Tab（功能使用权限 / 数据隐藏权限 / 数据隐藏天数权限），后两个 Tab 复用 DataDisplayConfigModal（按 mode 切换渲染同一份数据、底部统一保存）。
// 页面与三个子组件当前均未挂 data-manual 锚点，本说明书条目暂不联动面板点击高亮，仅供阅读（对齐同模块既有先例 riskControlSameIp.ts 现状）。
// 另有 components/GroupOpLogPopover.vue（含同目录 data.ts 的 buildGroupOpLog）：组件本身完整实现，但未在 index.vue 或站内任何其它文件引用/挂载，当前是孤儿组件；本说明书不为其编写交互条目（如实记录，非本次引入）。

import type { PageManual } from '../types';

const manual: PageManual = {
  route: 'member_group_manage',
  title: '分组管理',
  overview:
    '商户端「会员管理 › 分组管理」页，单表（ProCrudTable）内呈现两类分组：①系统结构型分组（默认分组 / 黑名单分组 / 代理分组），按当前查询商户各生成一套、恒置顶冻结在列表前 3 行；②自定义分组（含用户自建的黑名单分组），每行一个商户 + 一个分组，同一商户可有多行。商户搜索项单选必填（R63），未选商户时列表整体为空。新增/编辑走独立弹窗 MemberGroupFormModal；每行「分组配置」统一走同一个弹窗（3 Tab：功能使用权限 / 数据隐藏权限 / 数据隐藏天数权限），后两个 Tab 复用子组件 DataDisplayConfigModal（按 mode="hide"|"days" 切换渲染同一份数据、底部统一保存）。系统默认 / 黑名单分组只读查看；黑名单分组（系统 / 自建）没有数据类两个 Tab。',
  items: [
    // ============ 搜索区 ============
    {
      anchor: 'merchant',
      name: '商户',
      group: '搜索',
      interaction: '下拉单选（MerchantFilterSelect，multiple:false → 架构级不可清空，见《交互规范》§3 商户选择器）。',
      dataSource: '全站商户列表；默认预填当前左上角选中的商户（defaultTenantId，商户端专属，总控端为 null 不预填）。',
      logic: '按选中商户过滤系统分组行与自定义分组行；未选商户时列表整体为空（mock 层 tenantId 为空直接返回空数组，非前端拦截报错）。',
      limit:
        '必填（红星 showRequireMark + requiredRule）；单选、不可清空——商户单选必填规则（R63）。',
      edge: '不可清空、有预填时恒有值；不选商户点查询 → 列表按空态展示，无本页专属提示文案。',
    },
    {
      anchor: 'groupName',
      name: '分组名称',
      group: '搜索',
      interaction: '文本输入。',
      dataSource: '用户输入。',
      logic: '按分组名称做包含匹配（非前缀/全等），同时作用于系统分组行与自定义分组行。',
      limit: '选填；最多 50 字，普通文本字符（inputProps("name")，即 searchKw/name 预设）。',
      edge: '空 = 不按名称筛，仅按商户（+ 创建时间，若已选）过滤。',
    },
    {
      anchor: 'createTimeRange',
      name: '创建时间',
      group: '搜索',
      interaction:
        '日期时间区间选择（proDateRange，精确到秒），另带 quickDate 快捷选项（quick-date="createTimeRange"，含"全部"一键清空按钮 quick-date-allow-clear）。',
      dataSource: '用户选择，或点快捷按钮。',
      logic:
        '仅过滤自定义分组行（含用户自建黑名单）的创建时间；系统结构型分组行（默认/黑名单/代理）不受时间筛选影响、恒定显示（代码注释明确此为设计如此，非遗漏）。',
      limit: '最多跨 90 天（标准档，对齐《交互规范》§0 时间查询"标准档"分级）；不可选未来（allowFuture:false）。',
      edge: '空 = 不按时间筛，系统行和全部自定义行都显示（仍受分页与商户/名称筛选约束）。',
    },

    // ============ 工具栏操作 ============
    {
      anchor: 'act_add',
      name: '新增分组',
      group: '操作',
      interaction: '点击打开「新增分组」弹窗（MemberGroupFormModal，mode="add"）。',
      logic:
        '弹窗内默认分组类型="自定义分组"；保存后 saveMemberGroup 往自定义分组列表顶部插入一条新行，关闭弹窗并整表刷新。',
    },
    {
      anchor: 'act_refresh',
      name: '刷新',
      group: '操作',
      interaction: '点击重新加载表格数据（tableRef.reload()），沿用当前搜索条件与分页。',
    },

    // ============ 列 ============
    {
      anchor: 'col_memberCount',
      name: '分组人数列',
      group: '列',
      interaction: '数字以可点击蓝字链接形式展示（跳转类控件，非纯展示）。',
      dataSource: '行数据 memberCount。',
      logic:
        '点击跳转「会员列表」(`member_user` 路由)，query 携带该行商户 tenantId + 分组名 groupName；据本页代码注释，会员列表侧会用这两个参数预填"商户""会员分组"搜索项并自动查询（方案A·2026-07-07）。',
    },

    // ============ 行操作（按行类型分 3 个入口） ============
    {
      anchor: 'act_row_customEdit',
      name: '行操作 · 编辑（自定义分组行）',
      group: '操作',
      interaction: '点击打开编辑弹窗（MemberGroupFormModal，mode="edit"，携带该行完整数据含 id）。',
      logic:
        '弹窗内商户/分组名称/累计门槛三项/备注/状态均可编辑并正常回填；保存走 saveMemberGroup 的"edit + id 命中"分支，原地更新该行、刷新整表。',
      edge:
        '自定义分组编辑态商户选择器仍是可改的下拉（非只读文本）——代码未把商户锁定为只读，理论上可以把一个自定义分组行改挂到另一个商户下（如实记录，代码未做额外限制）。',
    },
    {
      anchor: 'act_row_agentEdit',
      name: '行操作 · 编辑（代理分组行）',
      group: '操作',
      interaction: '点击打开编辑弹窗（MemberGroupFormModal，mode="edit"，fixedMerchant=true）。',
      logic: '弹窗内分组类型/商户均固定只读文本，仅分组名称/累计门槛三项/备注/状态可编辑。',
      edge:
        '✅ 已修复（2026-07-21）：openAgentEdit 曾经传给弹窗的行对象只有 groupType/groupName/tenantId/merchant/state 五项，缺 id 与 rechargeAmountGte/rechargeCountGte/betAmountGte/remark，导致累计门槛三项显示为 0、且保存因缺 id 误判为"新增"插入重复行。现已补全 id + 三项改名映射（rechargeAmountGte←row.rechargeAmount 等，因列表行字段与表单字段名不同）+ remark，累计门槛三项与备注能正确回填列表真实值，保存走"edit + id 命中"分支原地更新该代理系统行。',
    },
    {
      anchor: 'act_row_systemView',
      name: '行操作 · 查看编辑（默认 / 黑名单系统行）',
      group: '操作',
      interaction: '点击打开只读查看弹窗（MemberGroupFormModal，mode="edit"，readonly=true）。',
      logic: '全部字段禁用展示，仅"关闭"按钮，无法保存。',
      edge:
        '✅ 已修复（2026-07-21）：openSystemView 曾经同样只传 groupType/groupName/tenantId/merchant/state 五项，「默认分组」因 showThresholds=true 会把三个累计门槛输入框渲染出来但显示 0（而非列表真实累计值）。现已补全 id + 三项改名映射（rechargeAmountGte←row.rechargeAmount 等）+ remark，「默认分组」的三框能正确显示列表真实累计值；「黑名单分组」因 showThresholds=false 这三框本就不显示，不受影响。',
    },
    {
      anchor: 'act_row_groupConfig',
      name: '行操作 · 分组配置 / 查看分组配置',
      group: '操作',
      interaction: '点击打开「分组配置」弹窗（单弹窗 3 Tab：功能使用权限 / 数据隐藏权限 / 数据隐藏天数权限），标题固定带该行归属商户。',
      dataSource:
        '打开时先请求 getGroupFeatureRights（决定功能 Tab 内容）；非只读且非黑名单分组时再请求 getGroupDataDisplay（决定后两个数据 Tab 内容）。',
      logic:
        '只读锁定（permLocked）= 系统默认/黑名单行（isSystem 且类型属默认/黑名单）；黑名单分组（系统或用户自建）一律没有「数据隐藏权限/数据隐藏天数权限」两个 Tab（isBlacklistType 命中即隐藏，2026-07-11 拍板）；代理分组与自定义分组均可编辑功能 Tab 且含两个数据 Tab。',
      note: '默认停在"功能使用权限" Tab（activeCfgTab 初始 "perm"）。',
    },

    // ============ 弹窗一：MemberGroupFormModal（新增/编辑/查看） ============
    {
      anchor: 'form_merchant',
      name: '弹窗 · 商户',
      group: '操作',
      interaction: '只读/固定商户场景显示禁用文本框；可编辑场景为 MerchantFilterSelect 单选下拉。',
      logic: '只读（readonly）或商户固定（fixedMerchant，代理类型级编辑）时显示禁用文本；否则为可选下拉。',
      limit: '非只读且非固定商户时必填（校验 tenantId 非 null）。',
      edge: '只读/固定场景显示文本来自 getTenantLabel(tenantId, merchant) 格式化的"商户号(商户名)"，非表单联动重新计算。',
    },
    {
      anchor: 'form_groupType',
      name: '弹窗 · 分组类型',
      group: '操作',
      interaction: '仅"新增"模式（mode=add 且非只读）显示下拉选择；其余场景显示禁用文本。',
      dataSource: '下拉选项固定 2 项：自定义分组 / 黑名单分组（选不了"默认分组""代理分组"——这两类只能是系统内置，不能经此弹窗新建）。',
      logic: '选"自定义分组"或"黑名单分组" → 显示"分组名称"输入框（showGroupName）；黑名单分组额外隐藏 3 个累计门槛输入框（showThresholds=false）。',
      limit: '新增模式下必填（下拉恒有默认值 custom，校验主要为红星标识 + 兜底）。',
    },
    {
      anchor: 'form_groupName',
      name: '弹窗 · 分组名称',
      group: '操作',
      interaction: '文本输入，仅"自定义分组/黑名单分组"两种可命名类型时显示。',
      dataSource: '用户输入。',
      logic: '保存时非自定义/黑名单类型（如查看态的默认/代理）不使用该输入框的值，而是自动取分组类型译名。',
      limit: '显示时必填（校验非空）；50 字预设（INPUT_PRESETS.name）。',
    },
    {
      anchor: 'form_thresholds',
      name: '弹窗 · 累计门槛三项（需累计充值金额 / 需累计充值次数 / 需累计有效流水）',
      group: '操作',
      interaction: '三个数字输入框（n-input-number，min=0），黑名单分组（showThresholds=false）时整组隐藏。',
      dataSource: '用户输入；与列表同名三列（rechargeAmount/rechargeCount/betAmount）是同一份数据，表单字段名带 Gte 后缀。',
      logic: '保存时原样写回 CUSTOM_ROWS 对应行的 rechargeAmount/rechargeCount/betAmount，列表刷新后可见更新结果。',
      limit: '最小值 0，无上限；只读时禁用。',
      edge: '见「行操作 · 编辑（代理分组行）」「行操作 · 查看编辑」两条：这两个入口传入弹窗的行对象缺这三项，会显示 0 而非列表真实值。',
    },
    {
      anchor: 'form_remark',
      name: '弹窗 · 备注',
      group: '操作',
      interaction: '多行文本域（2 行），带字数统计。',
      dataSource: '用户输入。',
      limit: '200 字预设（INPUT_PRESETS.remark）。',
      edge: '系统结构型分组（默认/黑名单/代理）本身没有 remark 数据来源，查看/编辑这些行时该框恒为空。',
    },
    {
      anchor: 'form_state',
      name: '弹窗 · 状态',
      group: '操作',
      interaction: '开关（n-switch），开=启用、关=禁用。',
      logic: '只读时禁用不可切换；新增默认开启。',
    },
    {
      anchor: 'form_save',
      name: '弹窗 · 保存（确定/取消）',
      group: '操作',
      interaction: '只读模式仅显示"关闭"按钮（无确定按钮）；可编辑模式显示"取消"+"确定"。',
      logic:
        '点确定先做表单校验（分组名称/分组类型/商户按各自规则），通过后调用 saveMemberGroup；成功提示 Toast 并关闭弹窗、触发列表 reload；失败会提示接口返回的 msg 文案（mock 恒为成功，不会真的走到失败分支）。',
      edge: '只读模式下 handleSave 一进函数就 return，即使强行触发也不会调用保存接口。',
    },

    // ============ 弹窗二 Tab1：功能使用权限 ============
    {
      anchor: 'cfg_tab_feature_list',
      name: '功能使用权限 · 勾选列表（基础 + 代理两个分区）',
      group: '操作',
      interaction: '每项一个复选框（n-checkbox）+ 右侧"前端已开启/已关闭该功能"状态文字，双列卡片布局。',
      dataSource:
        '基础功能 8 项固定列表（登录/提现/充值/投注/保险箱/红包/邀请注册/删除全部数据，其中"邀请注册"仅系统旧黑名单分组隐藏）；代理功能 3 项（我的邀请/团队报表/佣金明细）仅代理分组行才有、其余分组该分区不显示。',
      logic:
        '勾选=允许该分组会员使用此功能；初始勾选态按分组类型走固定/散点规则：默认分组全勾、黑名单分组全不勾、自定义分组新增分组全勾、代理分组按 (序号+分组id)%2 散点（保证多组数据不同，R32）。',
      limit: '只读锁定（系统默认/黑名单行）时复选框禁用、不显示"全选/清空"按钮。',
    },
    {
      anchor: 'cfg_tab_feature_batch',
      name: '功能使用权限 · 全选 / 清空',
      group: '操作',
      interaction: '两个小按钮，仅非只读时显示。',
      logic: '全选 = 把基础+代理全部功能 id 塞进已勾选集合；清空 = 已勾选集合清零；均为纯前端操作，未点"保存权限"前不落地。',
    },
    {
      anchor: 'cfg_tab_feature_save',
      name: '功能使用权限 · 保存权限',
      group: '操作',
      interaction: '点击提交当前勾选结果。',
      logic:
        '调用 saveGroupFeatureRights({id, groupType, rightIds}) 成功后提示 Toast 并关闭整个分组配置弹窗（不触发整表刷新，因为列表列里没有直接展示功能权限的字段）。',
      edge:
        '⚠️ 核实代码后发现：saveGroupFeatureRights 是纯 mock 空实现（恒返回 success，不写回任何内存态数据源）。关闭再重开同一行的分组配置，看到的是 getGroupFeatureRights 按分组类型/id 重新算出的同一份确定性结果，不是刚才保存的勾选状态——如实记录，非本次引入。',
    },

    // ============ 弹窗二 Tab2+3：数据隐藏权限 / 数据隐藏天数权限（DataDisplayConfigModal 复用） ============
    {
      anchor: 'cfg_tab_data_table',
      name: '数据隐藏权限 / 数据隐藏天数权限 · 表格',
      group: '操作',
      interaction:
        '同一个子组件 DataDisplayConfigModal 按 mode="hide"|"days" 渲染不同的表：hide 模式每行是"开关（是否隐藏）+ 隐藏/显示状态文字"，days 模式每行是"天数数字输入框"。字段名旁有"?"图标，悬停显示该字段的业务定义。',
      dataSource:
        '两个 Tab 共享同一份 basic/agent 数据（父层 dataBasic/dataAgent），由 getGroupDataDisplay 按分组类型+id 生成；基础数据 8 项（交易记录/下注记录/充值记录/提现记录/自研游戏注单记录/收款信息/游戏统计/VIP数据），代理数据 12 项仅代理分组行有。',
      logic:
        '在任一 Tab 里编辑（拖动开关或改天数）会直接改父层数组里对应对象的属性（同一份引用），因此切换 hide/days 两个 Tab 互不丢失彼此的编辑；黑名单分组（系统/自建）两个 Tab 都不显示（父层 showDataTab 已排除）。',
      limit: '天数框 min=0、整数（precision 0）；校验失败的行会被 status="error" 标红（红框，由父层 dataInvalid 集合驱动）。',
    },
    {
      anchor: 'cfg_tab_data_save',
      name: '数据隐藏权限 / 数据隐藏天数权限 · 保存',
      group: '操作',
      interaction: '两个 Tab 底部共用一个"保存"按钮（在弹窗 footer，而非 DataDisplayConfigModal 组件内部）。',
      logic:
        '点击先校验所有"天数"类行（非负、非空），有问题则跳到"数据隐藏天数权限" Tab 并弹错误 Toast 点名第一个出错字段；全部通过则弹二次确认预览框（列出基础/代理 × 显隐/天数 全部改动内容），确认后调用 saveGroupDataDisplay 提交。',
      edge:
        '⚠️ 核实代码后发现：saveGroupDataDisplay 同样是纯 mock 空实现（恒返回 success，不写回任何内存态数据源）。发布成功提示后会关闭弹窗并整表刷新，但列表列里没有直接展示这些数据显示配置的字段，刷新看不出差异；再次打开同一行分组配置，数据隐藏/天数两个 Tab 又是 getGroupDataDisplay 按公式重新生成的同一份结果，并非刚保存的值——如实记录，非本次引入。',
    },
  ],

  // ============ 字段介绍 tab（列序照页面；仅列表列 + 定义）============
  fields: [
    {
      name: '商户',
      def: '该分组所属的商户；系统结构型分组（默认/黑名单/代理）与自定义分组均归属一个指定商户（不再有"全部商户"汇总行），展示为"商户号(商户名)"（renderTenantTag）。',
    },
    {
      name: '分组类型',
      def: '分组的类型标签：默认分组 / 黑名单分组 / 代理分组 / 自定义分组；系统黑名单的新旧两个变体（用于区分是否含"邀请注册"权限项）在列表上 Tag 都统一显示为"黑名单分组"。',
    },
    {
      name: '分组名称',
      def: '分组的名称。系统默认/代理分组固定显示类型译名；系统黑名单分组显示原始组名（"旧黑名单分组"/"新黑名单分组"，用于新旧区分）；自定义分组（含用户自建黑名单）显示新增/编辑时填写的名称。',
    },
    {
      name: '分组人数',
      def: '归属该分组的会员数量；数字为可点击链接，跳转会员列表并预筛该商户 + 该分组名。',
    },
    {
      name: '需累计充值金额',
      def: '加入该分组所需达到的累计充值金额门槛（新增/编辑弹窗同一份数据，字段名 rechargeAmountGte）；黑名单分组（系统/自建）无此概念，显示"- -"。',
    },
    {
      name: '需累计充值次数',
      def: '加入该分组所需达到的累计充值次数门槛；黑名单分组显示"- -"。',
    },
    {
      name: '需累计有效流水',
      def: '加入该分组所需达到的累计有效投注流水门槛；黑名单分组显示"- -"。',
    },
    {
      name: '创建时间',
      def: '该分组行的创建时间；系统结构型分组三行固定显示 2026-01-01（mock 模板值），不代表真实创建时间。',
    },
    {
      name: '最后更新时间',
      def: '该分组最近一次编辑保存的时间；仅 saveMemberGroup（新增/编辑弹窗保存）会更新它，分组配置弹窗（功能权限/数据显示）保存不影响此字段。',
    },
    {
      name: '状态',
      def: '该分组的启用/禁用状态；当前用只读 Tag 展示（绿色"启用"/灰色"禁用"），不是可点切换的开关，需要通过编辑弹窗内的状态开关修改。',
    },
  ],
};

export default manual;
