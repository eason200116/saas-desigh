<template>
  <n-popconfirm
    :show="showConfirm"
    @update:show="showConfirm = $event"
    @positive-click="handleConfirm"
    @negative-click="showConfirm = false"
  >
    <template #trigger>
      <n-switch :value="innerValue" :disabled="disabled" @update:value="handleChange">
        <template #checked>{{ t('common.yes') }}</template>
        <template #unchecked>{{ t('common.no') }}</template>
      </n-switch>
    </template>
    {{ confirmText }}
  </n-popconfirm>
</template>

<script setup lang="ts">
  import { ref, computed } from 'vue';
  import { useI18n } from 'vue-i18n';

  const props = defineProps<{
    value?: number | string | null;
    disabled?: boolean;
  }>();

  const emit = defineEmits<{
    (e: 'confirm', value: number): void;
  }>();

  const { t } = useI18n();

  const showConfirm = ref(false);
  const pendingValue = ref<number>(0);

  const innerValue = computed(() => Number(props.value) === 1);

  const confirmText = computed(() =>
    pendingValue.value === 1 ? t('common.confirmEnable') : t('common.confirmDisable'),
  );

  const handleChange = (val: boolean) => {
    pendingValue.value = val ? 1 : 0;
    showConfirm.value = true;
  };

  const handleConfirm = () => {
    emit('confirm', pendingValue.value);
    showConfirm.value = false;
  };
</script>
