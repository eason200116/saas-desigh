// VIP等级统计（商户端 tenant · operations_vipLevelCount）功能说明书。
// 锚定 src/views/operations/vipLevelCount/index.vue + data.ts 真实控件（R53 实证、不臆造）。
// 纯只读统计页，无新增/编辑/删除，无操作列。

import type { PageManual } from '../types';

const manual: PageManual = {
  route: 'operations_vipLevelCount',
  title: 'VIP等级统计',
  overview:
    '商户端「运营管理 › VIP等级统计」页，纯只读统计页，展示各VIP等级当前的会员分布人数与占比。' +
    '"会员数"列可点击直接下钻跳转到「会员列表」页并按该VIP等级预筛选。2026-07-22核实代码未发现真实缺陷' +
    '（本页无任何写操作，仅查询展示，逻辑简单可靠）。',
  items: [
    {
      anchor: 'merchant',
      name: '商户',
      group: '搜索',
      interaction: '下拉筛选。',
    },
    {
      anchor: 'reset',
      name: '重置',
      group: '搜索',
      interaction: 'ProCrudTable内置重置按钮。',
    },
    {
      anchor: 'col_userCount',
      name: '会员数（可点击）',
      group: '列',
      interaction: '蓝字可点。',
      logic: '点击跳转「会员列表」页，并按该VIP等级预筛选自动查询。',
    },
  ],
  fields: [
    { name: '商户（列）', def: '该统计行所属商户，标签展示。' },
    { name: '等级ID', def: 'VIP等级的编号。' },
    { name: '等级名称', def: '该VIP等级的展示名称。' },
    { name: '会员数', def: '当前处于该VIP等级的会员数量，见交互条目 col_userCount。' },
    { name: '占比', def: '该等级会员数占该商户全部会员的比例，进度条展示。' },
  ],
};

export default manual;
