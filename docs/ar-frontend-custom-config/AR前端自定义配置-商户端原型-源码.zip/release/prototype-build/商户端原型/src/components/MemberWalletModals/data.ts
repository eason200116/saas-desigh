// 占位 data.ts —— components 层占位，UI 跑得起来不报模块缺失
// 视图调用形态保持源项目一致：const { data, result } = await api.<module>.<method>(req);

// ─── 新增/编辑/删除 override（修复：5 个子页保存/删除此前恒假成功、不真正写回内存列表）───
// 各子页自己的 data.ts 是「类型/银行名称」枚举 + 行数据的唯一真源，本文件只做方法路由转发，
// 不重复持有数据（真正的读写逻辑留在各子页 data.ts，与其 GET_xxx_LIST 数组同一处维护）
import { api as bankCardPageApi } from '@/views/member/bankCard/bankCard/data';
import { api as usdtPageApi } from '@/views/member/bankCard/usdt/data';
import { api as cpfPageApi } from '@/views/member/bankCard/cpf/data';
import { api as walletPageApi } from '@/views/member/bankCard/wallet/data';
import { api as upiPageApi } from '@/views/member/bankCard/upi/data';

// ─── 「类型/银行名称」枚举 override（修复：4 个子页新增弹窗必填下拉此前恒空、无法提交）───
// 值与各自子页 data.ts 行数据的 bankId/bankNameStr 完全对齐（R53 实证），编辑已有记录时下拉能精确
// 回显，不依赖 useTypeOptions 的 ensureOption 兜底。响应形状对齐两类消费方约定：
//   - BankCardEditModal 经 AsyncSelect request，需 data 为扁平数组 + 字段名 id/name
//   - useTypeOptions.ts 的 createTypeLoader 同样解构 data 为扁平数组 + 字段名 id/name
const BANK_TYPES = [
  { id: 1, name: 'State Bank of India' },
  { id: 2, name: 'HDFC Bank' },
  { id: 4, name: 'Banco do Brasil' },
  { id: 5, name: 'Vietcombank' },
  { id: 6, name: 'ICICI Bank' },
  { id: 7, name: 'Axis Bank' },
];
const USDT_PROTOCOL_TYPES = [
  { id: 21, name: 'TRC20' },
  { id: 22, name: 'ERC20' },
  { id: 23, name: 'BEP20' },
];
const CPF_WALLET_TYPES = [
  { id: 11, name: 'CPF' },
  { id: 12, name: 'EMAIL' },
  { id: 13, name: 'PHONE' },
  { id: 14, name: 'CNPJ' },
  { id: 15, name: 'Random' },
];
const EWALLET_TYPES = [
  { id: 31, name: 'GCash' },
  { id: 32, name: 'PayMaya' },
  { id: 33, name: 'KBZpay' },
  { id: 34, name: 'NAGAD' },
  { id: 35, name: 'GrabPay' },
];

const v1platformOverride: Record<string, (...args: any[]) => Promise<any>> = {
  getBankTypeList: async () => ({ code: 0, result: true, data: BANK_TYPES, msg: 'success' }),
  getUsdtTypeList: async () => ({
    code: 0,
    result: true,
    data: USDT_PROTOCOL_TYPES,
    msg: 'success',
  }),
  getCpfTypeList: async () => ({ code: 0, result: true, data: CPF_WALLET_TYPES, msg: 'success' }),
  getWalletTypeList: async () => ({ code: 0, result: true, data: EWALLET_TYPES, msg: 'success' }),

  // 转发到各子页真实实现，直接改各自的内存列表（与该子页列表 reload 读取的是同一份数组）
  addUserBankCard: bankCardPageApi.v1platform.addUserBankCard,
  updateUserBankCard: bankCardPageApi.v1platform.updateUserBankCard,
  addUserUsdt: usdtPageApi.v1platform.addUserUsdt,
  updateUserUsdt: usdtPageApi.v1platform.updateUserUsdt,
  addUserCpf: cpfPageApi.v1platform.addUserCpf,
  updateUserCpf: cpfPageApi.v1platform.updateUserCpf,
  addUserWallet: walletPageApi.v1platform.addUserWallet,
  updateUserWallet: walletPageApi.v1platform.updateUserWallet,
  addUPI: upiPageApi.v1platform.addUPI,
  updateUPI: upiPageApi.v1platform.updateUPI,
};

function placeholder(mod: string, method: string) {
  return async (..._args: any[]) => {
    console.warn('[component data placeholder] api.' + mod + '.' + method + ' not implemented');
    return { code: 0, result: true, data: null, msg: 'placeholder' };
  };
}

export const api: any = new Proxy(
  {},
  {
    get(_t, mod: string) {
      return new Proxy(
        {},
        {
          get(_, method: string) {
            if (mod === 'v1platform' && v1platformOverride[method]) {
              return v1platformOverride[method];
            }
            return placeholder(mod, method);
          },
        },
      );
    },
  },
);

// 兼容：组件如直接 import http
export const http: any = new Proxy(
  {},
  {
    get(_t, method: string) {
      return async (..._args: any[]) => {
        console.warn('[component http placeholder] http.' + method + ' not implemented');
        return { code: 0, result: true, data: null, msg: 'placeholder' };
      };
    },
  },
);
