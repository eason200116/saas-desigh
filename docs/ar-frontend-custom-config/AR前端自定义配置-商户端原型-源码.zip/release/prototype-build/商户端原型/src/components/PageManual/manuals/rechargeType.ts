// 充值类型管理（商户端 tenant · finance_merchant_recharge_type_page）功能说明书。
// 锚定 src/views/finance/rechargeType/index.vue 容器 + 2 个子 Tab（rechargeCategory 充值大类 /
// rechargeChannel 充值通道）各自的 index.vue/data.ts/form.ts/useXxxPage.ts/编辑弹窗真实控件
// （R53 实证、不臆造）。容器只是 n-tabs 壳（读 route.meta.tabs），2 个子 Tab 各自独立的搜索表单 +
// 列表 + 新增/编辑操作，互不共用组件——结构同批次已完成的「提现类型管理」页
// （withdrawType.ts），区别于 riskControlSameIp 那种"单表多维度换皮"。

import type { PageManual } from '../types';

const manual: PageManual = {
  route: 'finance_merchant_recharge_type_page',
  title: '充值类型管理',
  overview:
    '商户端「财务管理 › 充值类型管理」页，容器是一个 2 标签页壳（充值大类 / 充值通道），两个标签页完全独立、互不共用组件：「充值大类」维护面向会员展示的充值分类（图标/内置大类/会员最大待支付单数/快捷充值金额档位）；「充值通道」维护每个大类背后实际对接的三方支付通道（映射码/通道名称/币种/轮询权重/成功率统计/金额区间），并提供"代收测试"工具直接调用三方接口联调。「充值大类」行操作「充值通道管理」可一键跳转「充值通道」Tab 并带上该大类的商户+ID 作为预筛选条件。2026-07-21 核实代码后如实记录 4 处真实缺陷（均未修复，只记录）：①「充值大类」新增保存（rechargeCategoryAdd）只回"成功"、不真正写入底层数组，reload 后看不到新增行，但同页「编辑」（rechargeCategoryUpdate）是真实写回的，新增/编辑持久化行为不对称；②「充值通道」新增流程比①更严重——"三方映射码"下拉在新增态无条件返回空数组（`getPayCodeOptions` 的 `row?...:[]` 分支），级联通道选择器依赖的商户通道树接口 `/RechargeChannel/GetMerchantChannelTree` 的 mock 同样恒返回 `data:null`，两个数据源双双落空，新增充值通道当前在本原型环境下连第一个必填字段（三方映射码）都选不出来，无法通过 UI 走完整个流程；③「充值通道」编辑保存（`http.post("/RechargeChannel/Update")`）同样只回"成功"、不真正写回底层数组 `CHANNEL_LIST`——但如果编辑时顺带切换了"状态"，状态会通过另一个独立调用（`rechargeChannelUpdateState`）真实持久化，也就是说编辑保存后只有"状态"改动能在 reload 后看到，其余字段修改会被打回原值（对照本 Tab「删除」是真删的）；④「充值通道」行操作"代收测试"弹窗的 3 个内部子 Tab（拉单测试/UTR测试/回调测试）调用的 mock（`rechargeChannel/components/data.ts`）全部无条件返回 `data:null`，三个结果面板（`v-if="pullResult/utrResult/callbackResult"`）因此完全不会渲染，且弹窗内全程没有任何成功提示，点提交后除短暂 loading 外用户看不到任何反馈。',
  items: [
    // ============ 容器：Tab 切换 ============
    {
      anchor: 'tab_switch',
      name: '2 个子页 Tab 切换（充值大类 / 充值通道）',
      group: '操作',
      interaction:
        '点顶部 Tab 切换，2 个 Tab 各自独立的搜索表单 + 列表 + 新增/编辑操作，不是同一张表换维度，也不共用编辑弹窗。',
      dataSource: '从当前路由 meta.tabs 读取配置（useRouteTabs），默认展示「充值大类」Tab。',
      logic:
        '默认 keepAlive（各 Tab 切走后状态不丢，含分页/筛选）；「充值大类」Tab 行操作「充值通道管理」会调用容器 handleGoChannel：把该行的 tenantId + id（作为 channelCategoryId）写入 channelSearchParams 并切到「充值通道」Tab，「充值通道」Tab 拿到这份 props 作为查询区初始值预筛选；容器内含一段"布局高度链补丁"逻辑（给祖先 .layout-main 挂高度撑满 class），与两个子 Tab 的业务无关。',
      note: '容器组件 src/views/finance/rechargeType/index.vue 本身只是壳，不含独立业务控件；实际控件都在两个子 Tab 自己的 index.vue 里。',
    },

    // ============ Tab①充值大类：搜索 ============
    {
      anchor: 'category_merchant',
      name: '商户（充值大类 Tab，搜索区）',
      group: '搜索',
      interaction: '下拉单选（tenantSelect，架构级不可清空）。',
      dataSource: '全站商户列表。',
      logic:
        '按选中商户过滤大类列表；切换商户会同步清空查询区"充值大类"筛选值，并联动重新拉取该商户下的"充值大类"（前台显示名称）下拉选项（按商户缓存，未命中缓存才发起请求）。',
      limit: '搜索表单项配了 showRequireMark 红星提示 + 组件本身 clearable:false 架构级不可清空。',
    },
    {
      anchor: 'category_customName',
      name: '充值大类（充值大类 Tab，搜索区，前台显示名称下拉）',
      group: '搜索',
      interaction: '下拉单选，可搜索可清空（span 占 2 列宽）。',
      dataSource:
        '按当前选中商户调用 getSelectList({tenantId}) 拉取该商户名下所有大类记录的 customName 去重后作为选项。',
      logic: '按选中的显示名称精确过滤列表。',
      limit: '选填。',
      edge:
        '这里的"充值大类"筛选项实际按 customName（运营自定义的前台展示名称，如"Local UPI"）过滤，与列表"内置充值大类"列（系统枚举 rechargeCategory 字段）是两个不同字段，同名不同义——本页语境下"充值大类"就是指一条具体的大类配置记录本身，"内置充值大类"才是它归属的系统底层分类。',
    },
    {
      anchor: 'category_reset',
      name: '重置（充值大类 Tab，搜索表单）',
      group: '操作',
      interaction: '点击搜索表单「重置」按钮。',
      logic:
        '除清空搜索表单各字段外，额外调用 updateSearchTenantId 把内部 searchTenantId 状态同步恢复为重置后的默认商户，从而让"充值大类"下拉的可选项跟着恢复到默认商户对应的选项集合（handleSearchReset 显式处理，非框架自动行为）。',
    },

    // ============ Tab①充值大类：列 ============
    {
      anchor: 'col_category_iconPair',
      name: '选中前图标/选中后图标列（充值大类 Tab）',
      group: '列',
      interaction: '两张缩略图并排展示（28×28），可点击预览大图（NImage previewDisabled:false）。',
      dataSource: '行数据 iconUrl / selectedIconUrl，经 getFullImageUrl 补全域名后展示。',
      logic: '图标为空时显示"--"占位，不触发预览。',
    },
    {
      anchor: 'col_category_state',
      name: '状态列（充值大类 Tab，启用/禁用开关）',
      group: '列',
      interaction:
        '开关（ConfirmSwitch），点击弹二次确认框确认后才真正切换，命中 R47。',
      dataSource: '行数据 state（0/1）。',
      logic:
        '确认后调用 rechargeCategoryUpdateState 提交，成功后整表 reload 并提示"更新成功"；该 mock 会真实写回底层数组，reload 后状态变化能正确看到。',
      edge: '点取消则开关视觉复位，不发起请求。',
    },

    // ============ Tab①充值大类：操作 ============
    {
      anchor: 'category_add',
      name: '新增（充值大类 Tab，表格左上角按钮）',
      group: '操作',
      interaction: '点表格左上角"新增"打开弹窗（RechargeTypeEditModal，宽600px）；按钮是否显示跟随查询区当前选中商户的门控条件。',
      dataSource: 'canAddCategory 门控：读取查询区当前商户的 siteBuildStatus 字段。',
      logic:
        '商户处于"配置中"（siteBuildStatus===0）时按钮隐藏；未选商户、商户信息未加载到、或商户已上线（非0）时按钮均显示。打开弹窗后需选商户（默认带入查询区当前商户）/内置充值大类（选中商户后异步加载该商户可选的系统大类枚举）/上传选中前图标+选中后图标（均必传，70×70，jpg/png/webp）/填前台显示名称（最多50字）/排序（非负整数）/会员最大待支付单数（非负整数，0表示不限制）/配置快捷充值金额（默认6档，每档含金额+赠送类型[赠送比率/固定金额]+赠送数额，可增减，档位数须落在6~12之间，不足会标红拦截且不提交）。',
      limit: '两张图标、内置充值大类、商户、前台显示名称均为必填；快捷充值金额需配置 6~12 个档位（不足标红拦截，命中 R53 保存校验红框规范）。',
      edge:
        '⚠️ 核实代码后发现：保存调用的 rechargeCategoryAdd mock（rechargeCategory/data.ts）只返回 `{result:true, data:{id:Date.now(),...req}}`，并未把新记录真正 push 进底层数组 CATEGORY_LIST——点确认后提示"新增成功"，但列表 reload 后看不到这条新记录；对照本 Tab「编辑」（rechargeCategoryUpdate）是真实写回的（`CATEGORY_LIST[idx] = {...CATEGORY_LIST[idx], ...req}`），同页新增/编辑两个操作的持久化行为不对称，如实记录、不修复。',
    },
    {
      anchor: 'category_edit',
      name: '编辑（充值大类 Tab，行操作按钮）',
      group: '操作',
      interaction: '点行内"编辑"打开同一弹窗（RechargeTypeEditModal），字段集合与"新增"完全一致；商户 / 内置充值大类两个下拉在编辑态锁定为禁用（不可改归属）。',
      dataSource: '打开时调用 rechargeCategoryGet({id, tenantId}) 取详情回填。',
      logic: '其余字段（图标×2/前台显示名称/排序/会员最大待支付单数/快捷充值金额）均可改；保存调用 rechargeCategoryUpdate。',
      edge:
        '与「新增」相反，本操作的保存是真实生效的：mock 直接把提交内容合并进 CATEGORY_LIST 对应记录，reload 后能看到修改结果。',
    },
    {
      anchor: 'category_manageChannel',
      name: '充值通道管理（充值大类 Tab，行操作按钮）',
      group: '操作',
      interaction: '点行内"充值通道管理"，不弹窗，直接触发 Tab 切换。',
      logic:
        '向容器 emit go-channel 事件，携带 {id, tenantId}；容器 handleGoChannel 把 tenantId 和 id（作为 channelCategoryId）写入 channelSearchParams 并调用 handleTabUpdate 切到「充值通道」Tab，该 Tab 拿到这份预筛选值作为查询区初始条件自动加载对应数据。',
      note: '这是本页唯一的跨 Tab 联动入口；反向（在「充值通道」Tab 操作后跳回「充值大类」）不存在。',
    },

    // ============ Tab②充值通道：搜索 ============
    {
      anchor: 'channel_merchant',
      name: '商户（充值通道 Tab，搜索区）',
      group: '搜索',
      interaction: '下拉单选可搜索（普通 select + tenantOptions，架构级不可清空）。',
      dataSource: '全站商户列表。',
      logic: '切换商户会清空"三方映射码/通道ID-名称/三方商户昵称-商户号/充值大类"四个联动字段，并按新商户重新计算这些下拉的可选项（前端本地过滤字典派生层数据，不重新发请求）。',
    },
    {
      anchor: 'channel_payCode',
      name: '三方映射码（充值通道 Tab，搜索区）',
      group: '搜索',
      interaction: '下拉单选可搜索可清空，依赖已选商户。',
      dataSource: '字典派生层 useRechargeChannelDictionary：按 tenantId + state=1 从 tenantPayChannelList 取 payCode 去重，且仅保留 sysPayChannelList 里 inOutType="Recharge" 方向的映射码（避免误显示提现方向的映射码）。',
      logic: '切换后联动清空"通道ID-名称/充值大类/通道币种/三方商户昵称-商户号"。',
      edge: '商户未选时选项为空（依赖商户）。',
    },
    {
      anchor: 'channel_channelId',
      name: '通道ID/名称（充值通道 Tab，搜索区）',
      group: '搜索',
      interaction: '下拉单选可搜索可清空，依赖商户 + 三方映射码 + 通道币种。',
      dataSource: '字典派生（tenantPayChannelList 按 tenantId+payCode+sysCurrency 过滤，不额外过滤 state），选项展示为「通道关系ID → 前台显示名称」；切换币种后会保留原已选通道（三级 fallback：先查带币种、再查不限币种、最后裸 id 兜底）。',
    },
    {
      anchor: 'channel_thirdMerchantName',
      name: '三方商户昵称/商户号（充值通道 Tab，搜索区）',
      group: '搜索',
      interaction: '下拉单选可搜索可清空，依赖商户 + 三方映射码。',
      dataSource: '字典派生（thirdPayMerchantList 按同集团 orgId + payCode 过滤），选项展示为「昵称(商户号)」拼接串。',
      logic: '按选中的拼接串精确匹配过滤（透传给列表接口的 merchantName 参数按行数据 merchantCode 做 includes 匹配）。',
    },
    {
      anchor: 'channel_channelCategoryId',
      name: '充值大类（充值通道 Tab，搜索区）',
      group: '搜索',
      interaction: '下拉单选可搜索可清空，依赖已选商户（不依赖映射码）。',
      dataSource: '字典派生（rechargeCategoryList 按 tenantId 过滤，已强制 state=1，即只列出「充值大类」Tab 里已启用的大类），是租户级自定义大类 ID（对应「充值大类」Tab 某条记录的 id），非系统内置枚举。',
    },
    {
      anchor: 'channel_sysCurrency',
      name: '通道币种（充值通道 Tab，搜索区）',
      group: '搜索',
      interaction: '下拉单选可搜索可清空，依赖商户 + 三方映射码。',
      dataSource: '字典派生（tenantPayChannelList 按 tenantId+payCode 过滤后取 sysCurrency 去重）。',
    },
    {
      anchor: 'channel_state',
      name: '状态（充值通道 Tab，搜索区）',
      group: '搜索',
      interaction: '下拉单选可清空，固定 2 个选项。',
      dataSource: '固定选项：启用(1) / 禁用(0)，非字典来源。',
      logic: '按选中值精确过滤列表（不选=不按状态筛）。',
    },
    {
      anchor: 'channel_reset',
      name: '重置（充值通道 Tab，搜索表单）',
      group: '操作',
      interaction: '点击搜索表单「重置」按钮。',
      logic:
        '把商户恢复为默认商户、把"充值大类"筛选清空为未选中——即使当前查询条件是从「充值大类」Tab"充值通道管理"跳转带来的预筛选，点重置后这份预筛选也会被清空（isResetTriggered 状态锁），并且在本次停留期间不会自动恢复，除非重新从「充值大类」Tab 再跳一次。',
      edge:
        '这是本页时序最复杂的一处逻辑：父页再次跳转（defaultSearchParams 变化）会用 flush:"sync" 的 watch 解锁 isResetTriggered，确保"再跳转一次→再点重置"这类连续操作下预筛选能正确回填、重置也能一次点击就清空，不需要点两次——细节详见源码注释，交互效果对用户是"点一下就干净清空"。',
    },

    // ============ Tab②充值通道：列 ============
    {
      anchor: 'col_channel_info',
      name: '通道信息列（充值通道 Tab，四段结构）',
      group: '列',
      interaction: '纯展示四段，不可点：通道ID / 通道名称[字典ID] / 前台显示名称 / 三方映射码（标签，系统内置通道额外叠加"内置"标签）。',
      dataSource:
        '行数据 id(或channelId)/channelId/customName/payCode(或thirdChannelCode)；通道名称经 dynamicDict.sysPayChannelList 字典反查；"内置"判定 = 映射码等于 SystemBuiltIn 或 channelId 落在预置系统内置通道 ID 集合内。',
      note: '与「充值通道」页搜索区里独立的"通道ID/名称"下拉是同一批数据的两种呈现（一个用于筛选，一个用于列表展示），渲染逻辑与「提现通道」页共用同一个工厂函数（channelColumnRenderers.ts）。',
    },
    {
      anchor: 'col_channel_successRate',
      name: '成功率统计列（充值通道 Tab，2×2 网格）',
      group: '列',
      interaction: '纯展示 2 行 × 2 列（近10分钟/近30分钟 红色一行，近1小时/近24小时 绿色一行），不可点。',
      dataSource:
        '双数据源 fallback：优先解析行数据 successRateInfo 原始字符串（按换行/分号/竖线切 4 段）；该字段为空时退回 4 个独立数值字段 recent{15,30,1h,24h}xxxCount（0~1 小数）格式化成百分比展示。',
      logic: '当前 mock 全部 8 条记录 successRateInfo 均为空串，因此实际渲染路径恒走"4 个独立数值字段"这条 fallback 分支，字符串解析分支目前是设计上预留、暂未被现有 mock 数据触发的正常兜底路径，非缺陷。',
      note: '红/绿配色固定，不随主题（浅色/深色）切换。',
    },
    {
      anchor: 'col_channel_state',
      name: '状态列（充值通道 Tab，启用/禁用开关）',
      group: '列',
      interaction: '开关（ConfirmSwitch），点击弹二次确认框确认后才真正切换，命中 R47。',
      dataSource: '行数据 state（0/1）。',
      logic: '确认后调用 rechargeChannelUpdateState，成功后触发字典失效重拉 + 整表 reload；该接口会真实写回底层数组，reload 后状态变化能正确看到。',
      note: '与右侧「可用状态」列是两个独立概念：本列是"商户侧是否启用该通道"，可主动操作；「可用状态」是三方通道自身的运行态，本页只读展示、不可直接操作。',
    },
    {
      anchor: 'col_channel_channelState',
      name: '可用状态列（充值通道 Tab，三方通道运行态）',
      group: '列',
      interaction: '只读彩色标签，不可点。',
      dataSource: '行数据 channelState（0=总控通道关闭）/ merchantState（0=三方商户关闭）。',
      logic: '按优先级判定：channelState=0 → 显示"总控通道关闭"（红）；否则 merchantState=0 → 显示"三方商户关闭"（红）；否则 channelState=1 → 显示"可用"（绿）；其余情况显示"--"。',
    },

    // ============ Tab②充值通道：操作 ============
    {
      anchor: 'channel_add',
      name: '新增（充值通道 Tab，表格左上角按钮）',
      group: '操作',
      interaction:
        '点表格左上角"新增"打开弹窗（RechargeChannelEditModal，宽860px），含商户 / 三方映射码 / 通道名称（级联选择器 ChannelCascadeSelect，按"三方商户"分组、组内单选具体通道，每个通道带"充值大类"徽标 + "已绑定/未绑定"状态）/ 通道币种（选中通道后自动带出、只读）/ 充值大类（选中通道后自动拉取该通道可绑的候选大类，通常默认选中第一项）/ 前台显示名称 / 三方通道编码 / 轮询权重（0~1,000,000）+ 只读的"实时权重"框 / 可见充值等级（多选，来自当前登录商户的充值等级列表）/ 可用时间段（起止两个时间选择器）/ 充值金额区间（ProNumberRange）/ 手续费（仅当"通道币种=VND"时显示，0~1）/ 备注 / 状态（单选启用/禁用）。',
      dataSource: '"通道名称"级联选择器与"三方映射码"下拉的数据均来自 POST /RechargeChannel/GetMerchantChannelTree（按商户+映射码请求）；选中通道后会带 channelId 再请求一次同接口拉取该通道可用的"充值大类"候选。',
      limit: '商户 / 三方映射码 / 通道（级联树单选）/ 充值大类 / 前台显示名称 / 可用时间段 / 充值金额区间 均为必填；三方通道编码最多200字符；备注最多300字。',
      edge:
        '⚠️ 核实代码后发现一处比"保存是否生效"更前置、更严重的缺陷：新增态"三方映射码"下拉的数据源有两条——商户通道树接口返回的 payCodes 列表，以及外部传入的 getPayCodeOptions 兜底；但 useRechargeChannelPage.ts 里 `getPayCodeOptions: (tenantId) => (row ? getSearchPayCodeOptions(tenantId) : [])` 在新增态（row 未传）无条件返回空数组，而商户通道树接口 /RechargeChannel/GetMerchantChannelTree 的 mock（rechargeChannel/components/data.ts 的 http 是 Proxy stub，任意方法恒返回 data:null）归一化后 payCodes 同样是空数组——两个数据源双双落空，导致"三方映射码"下拉在新增流程里永远没有可选项，连带下游"通道名称"级联选择器、"充值大类"候选也都拿不到数据，必填校验无法通过，新增充值通道当前在本原型环境下无法经 UI 走完整个流程（比"点确认后数据没真的存上"更前置）；即便绕开这一层，提交调用的 http.post("/RechargeChannel/BatchAdd", ...) 同样只回成功、不真正把数据写入底层数组 CHANNEL_LIST（对照本 Tab 的"删除"操作是真删的，说明新增/编辑的假持久化是历史遗留、并非本次改动引入）。以上均如实记录、不修复。',
    },
    {
      anchor: 'channel_edit',
      name: '编辑（充值通道 Tab，行操作按钮）',
      group: '操作',
      interaction: '点行内"编辑"打开同一弹窗；商户 / 三方映射码 / 通道名称（改为普通下拉而非级联树）/ 充值大类 四项在编辑态均锁定只读（禁用态），仅可改前台显示名称 / 三方通道编码 / 轮询权重 / 可见充值等级 / 可用时间段 / 充值金额区间 / 手续费（若通道币种=VND）/ 备注 / 状态。',
      dataSource: '打开时调用 rechargeChannelGet({id}) 取详情回填。',
      logic: '提交调用 http.post("/RechargeChannel/Update", ...)；若本次编辑同时改动了"状态"，会额外单独调用 rechargeChannelUpdateState 同步状态。',
      edge:
        '⚠️ 核实代码后发现：http.post("/RechargeChannel/Update") 的 mock 只回成功，不真正写回 CHANNEL_LIST 数组；但"状态"字段走的是独立的 rechargeChannelUpdateState 调用，该接口会真实修改 CHANNEL_LIST 里对应行的 state——也就是说编辑保存后，只有"状态"这一项改动能在 reload 后真实看到，前台显示名称/权重/可见等级/时间段/金额区间/手续费/备注等其余字段的修改会在 reload 后被打回编辑前的原值，如实记录、不修复。',
    },
    {
      anchor: 'channel_delete',
      name: '删除（充值通道 Tab，行操作按钮）',
      group: '操作',
      interaction: '点行内"删除"，按钮类型为 createActionColumn 的内置 delete 语义（点击弹二次确认）；系统内置通道（channelId 落在预置集合内）不显示该按钮。',
      logic: '确认后调用 rechargeChannelDelete({id})，成功后提示删除成功并刷新列表+字典缓存。',
      note: '与新增/编辑不同，删除的 mock 是真的从底层数组里 splice 掉该行，删除后条数会真实减少。',
    },
    {
      anchor: 'channel_collectionTest',
      name: '代收测试（充值通道 Tab，行操作按钮）',
      group: '操作',
      interaction:
        '点行内"代收测试"打开弹窗（RechargeCollectionTestModal，宽860px，系统内置通道即三方映射码=SystemBuiltIn 时不显示该按钮），左侧纵向 3 个 Tab：拉单测试 / UTR测试（仅当前行 isSupportUtrTest===true 才显示该 Tab，8 条 mock 数据里只有 1 条为 true）/ 回调测试；顶部横条只读展示通道ID / 前台显示名称 / 通道名称 / 三方映射码 / 币种（取自当前行数据）。',
      dataSource:
        '"拉单测试"提交金额（法币或 USDT，输入框限制只能填数字和小数点）；"UTR测试"提交订单号+UTR号；"回调测试"提交 JSON 请求头（选填但填了必须合法 JSON）+ 回调 Body（必填）。三个提交分别调用 testRechargeSubmit / testUTRSubmit / testRechargeNotify。',
      logic:
        '拉单测试提交成功后会把返回的订单号自动带入 UTR测试 Tab 的订单号输入框；四个字段（请求地址/请求体/请求日志/响应体）+ 错误日志区域用折叠面板展示，供逐项核对联调结果。',
      limit: '拉单测试金额必填且需 > 0；UTR测试订单号与UTR号均必填；回调测试回调 Body 必填。',
      edge:
        '⚠️ 核实代码后发现：本弹窗 `./data` 就近解析到 rechargeChannel/components/data.ts（与上一级目录 rechargeChannel/data.ts 里同名但更丰富的 testRechargeSubmit/testUTRSubmit/testRechargeNotify 是两份独立定义，弹窗实际吃的是 components/ 这份最简版），三个函数全部无条件返回 `data: null`。后果：①拉单测试 `pullResult.value = response?.data ?? null` 恒为 null，模板 `v-if="pullResult"` 恒假，结果面板完全不渲染（不是"字段名对不上显示 --"，是整块结果区域都不出现）；UTR测试、回调测试同理，结果面板也都不会出现。②三处提交函数全程没有任何 message.success 调用，点提交后除短暂 loading 外用户看不到任何成功反馈，也没有报错——从交互上看像是"点了没反应"。③即便后续把 mock 补成返回数据，也需注意模板/代码读取的字段名是 orderNo（`response?.data?.orderNo`），与上一级目录那份未被使用的 testRechargeSubmit 返回的字段名 orderId 不一致，是叠加的第二层隐患。以上均如实记录、不修复。',
    },
  ],

  // ============ 字段介绍 tab（按各自 Tab 列表列真实列序；仅列表列 + 定义）============
  fields: [
    // ---- 充值大类 Tab（11 列，同 rechargeCategory/index.vue tableColumns 顺序）----
    { name: '「充值大类」商户', def: '该条大类配置所属商户，标签形式展示。' },
    { name: '「充值大类」ID', def: '该条大类配置的唯一编号。' },
    { name: '「充值大类」选中前图标/选中后图标', def: '会员在充值方式列表里未选中/选中该大类时分别展示的图标，两张并排。' },
    { name: '「充值大类」充值大类', def: '运营自定义的前台展示名称（如"Local UPI"），即 customName 字段。' },
    { name: '「充值大类」内置充值大类', def: '系统内置的充值大类枚举（如 Local Bank / Local UPI / Local USDT / 三方法币 / 三方USDT / ARPay 等），标签展示，决定该大类的底层业务类型。' },
    { name: '「充值大类」会员最大待支付单数', def: '同一会员同时可拥有的该大类"待支付"充值订单上限，0 表示不限制。' },
    { name: '「充值大类」快捷充值金额', def: '前台展示给会员一键选择的快捷金额档位列表（斜杠分隔）。' },
    { name: '「充值大类」状态', def: '该大类是否对会员开放使用（启用/禁用）。' },
    { name: '「充值大类」排序', def: '控制该大类在前台充值方式列表里的展示先后顺序，数值越小越靠前。' },
    { name: '「充值大类」最后修改人', def: '最近一次编辑该大类配置的操作人账号。' },
    { name: '「充值大类」最后修改时间', def: '最近一次编辑该大类配置的时间，按所属商户时区显示。' },

    // ---- 充值通道 Tab（17 列，同 rechargeChannel/index.vue tableColumns 顺序）----
    { name: '「充值通道」商户', def: '该条通道配置所属商户，标签形式展示。' },
    {
      name: '「充值通道」通道信息',
      def: '四段复合信息：通道ID（本条记录主键）/ 通道名称（含字典 ID）/ 前台显示名称（运营自定义）/ 三方映射码（标签展示，系统内置通道额外叠加"内置"标签）。',
    },
    { name: '「充值通道」三方商户昵称/商户号', def: '该通道对接的三方支付商户的昵称与商户编号，两行展示。' },
    { name: '「充值通道」通道币种', def: '该通道处理的结算币种（如 INR/USDT/MYR），标签展示。' },
    {
      name: '「充值通道」成功率统计',
      def: '2×2 网格：近10分钟/近30分钟（红色）、近1小时/近24小时（绿色）四段成功率数值，衡量该通道近期充值成功比例。',
    },
    { name: '「充值通道」轮询权重', def: '两行复合信息：预设权重（可编辑配置） / 实时权重（系统按运行状况动态调整后的当前值，只读），权重越高越容易被自动分单选中。' },
    { name: '「充值通道」充值大类', def: '该通道归属的租户级自定义大类展示名称（对应「充值大类」Tab 某条记录）。' },
    { name: '「充值通道」内置充值大类', def: '该通道归属大类对应的系统内置枚举分类，标签展示。' },
    { name: '「充值通道」状态', def: '该通道是否被本商户启用（可主动开关切换）。' },
    { name: '「充值通道」可用状态', def: '三方通道自身的运行态（总控通道是否关闭 / 三方商户是否关闭 / 可用），只读，不可在本页直接操作。' },
    { name: '「充值通道」可见充值等级', def: '限定仅哪些会员充值等级可见/可用该通道，为空表示不限制（展示"全部"）。' },
    { name: '「充值通道」可用时间段', def: '该通道每天可被会员使用的起止时间段。' },
    { name: '「充值通道」充值金额区间', def: '该通道单笔允许处理的最小~最大充值金额。' },
    { name: '「充值通道」手续费', def: '该通道收取的充值手续费比例，仅 VND 币种通道存在该项差异（展示为百分比）。' },
    { name: '「充值通道」备注', def: '运营对该通道配置的补充说明文字。' },
    { name: '「充值通道」最后修改人', def: '最近一次编辑该通道配置的操作人账号。' },
    { name: '「充值通道」最后修改时间', def: '最近一次编辑该通道配置的时间，按所属商户时区显示。' },
  ],
};

export default manual;
