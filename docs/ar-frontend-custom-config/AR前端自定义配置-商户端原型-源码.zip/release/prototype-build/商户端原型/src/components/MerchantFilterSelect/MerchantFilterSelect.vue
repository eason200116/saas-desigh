<template>
  <!--
    商户筛选下拉。两种模式：
    - multiple=true（默认）：多选 + 顶部「全部」互斥。搜索区/弹窗通用。
    - multiple=false：单选（不含「全部」），用于「仅单选 + 必填」场景（如会员列表）；不可清空，须选一个商户。
    默认商户（2026-07-16 用户定「商户下拉必须有默认商户，多选也要」）：
    - 值为空（null/undefined/[]，含清空、重置）→ 自动写回商户列表第一个（单选=首个 id，多选=[首个 id]）。
    - 显式「全部」([0]) 是明确的查询语义（不过滤），不覆盖——运行时仍可主动选「全部」。
    - 级联场景（options 按集团过滤）写回过滤后子集的第一个。
  -->
  <n-select
    :value="displayValue"
    :options="mergedOptions"
    :multiple="multiple"
    :filterable="filterable"
    :clearable="multiple"
    :disabled="disabled"
    :max-tag-count="maxTagCount"
    :placeholder="resolvedPlaceholder"
    @update:value="handleUpdate"
  />
</template>

<script setup lang="ts">
  import { computed, watch } from 'vue';
  import { NSelect, type SelectOption } from 'naive-ui';
  import { useI18n } from 'vue-i18n';
  import { useTenantOptions } from '@/hooks';
  import { MERCHANT_ALL_LABEL, MERCHANT_ALL_VALUE } from './constants';

  const { t } = useI18n();

  defineOptions({ name: 'MerchantFilterSelect' });

  const props = withDefaults(
    defineProps<{
      value?: number | number[] | null;
      // 多选(默认) / 单选。单选用于「仅单选+必填」筛选。
      multiple?: boolean;
      // 是否可搜索过滤，默认 true（全站沿用）；个别页可传 false 关闭下拉搜索
      filterable?: boolean;
      maxTagCount?: number | 'responsive';
      disabled?: boolean;
      // 自定义商户选项（如按集团过滤后的子集）；不传则用角色默认全量商户。
      options?: SelectOption[];
      placeholder?: string;
    }>(),
    {
      multiple: true,
      filterable: true,
      maxTagCount: 'responsive',
      disabled: false,
      placeholder: '全部',
    },
  );
  const emit = defineEmits<{ (e: 'update:value', value: number | number[]): void }>();

  // tenantOptions 已按角色返回扁平商户列表（商户端=自身可见商户；总控端=全部商户扁平）。
  // defaultTenantId = 激活商户 → tenantList[0] 兜底链，与老写法 tenantSelect(ProField) 的默认语义全站一致（R68）。
  const { tenantOptions, defaultTenantId } = useTenantOptions();

  // 多选模式顶部加「全部」；单选模式不加（必选一个具体商户）。
  const mergedOptions = computed<SelectOption[]>(() => {
    const base = (props.options ??
      (tenantOptions.value as unknown as SelectOption[])) as SelectOption[];
    return props.multiple ? [{ label: t('common.all'), value: MERCHANT_ALL_VALUE }, ...base] : base;
  });

  // 占位文案：外部显式传了非默认 placeholder 则用其值；否则按模式取默认（单选=请选择商户 / 多选=全部）。
  const resolvedPlaceholder = computed(() => {
    if (props.placeholder !== MERCHANT_ALL_LABEL) return props.placeholder;
    return props.multiple ? t('common.all') : t('common.selectMerchant');
  });

  function toArray(value?: number | number[] | null): number[] {
    if (Array.isArray(value)) return value;
    return value == null ? [] : [value];
  }

  // 默认商户：优先 defaultTenantId（激活商户→tenantList[0] 兜底链，与 tenantSelect 全站同语义），
  // 它不在当前可选项里（如级联按集团过滤后的子集）时退到选项第一个；跳过「全部」哨兵与禁用项。
  const firstMerchantId = computed<number | undefined>(() => {
    const base = ((props.options ??
      (tenantOptions.value as unknown as SelectOption[])) ?? []) as SelectOption[];
    const selectable = base.filter(
      (o) => o.value !== MERCHANT_ALL_VALUE && o.value != null && !o.disabled,
    );
    if (!selectable.length) return undefined;
    const preferred = defaultTenantId.value;
    if (preferred != null && selectable.some((o) => Number(o.value) === Number(preferred)))
      return preferred;
    return selectable[0].value as number;
  });

  // 空值自动写回默认商户（2026-07-16 用户定：商户下拉必须有默认商户，多选也要）。
  // 触发时机：挂载即查(immediate) + 商户列表就绪 + 值被清空/重置。
  // 「全部」([0]) 有值不为空 → 不写回；写回后值非空，watch 再进即短路，无死循环。
  watch(
    [() => props.value, firstMerchantId],
    ([val, first]) => {
      if (first == null) return; // 商户列表未就绪（异步加载中 / 级联未选上游）
      if (toArray(val as number | number[] | null | undefined).length) return; // 已有值（含「全部」）
      emit('update:value', props.multiple ? [first as number] : (first as number));
    },
    { immediate: true },
  );

  // 多选：空值视觉回显「全部」；单选：取单值
  const displayValue = computed<number[] | number | null>(() => {
    if (!props.multiple) {
      const v = Array.isArray(props.value) ? props.value[0] : props.value;
      return v == null ? null : v;
    }
    const arr = toArray(props.value);
    return arr.length ? arr : [MERCHANT_ALL_VALUE];
  });

  function handleUpdate(next: number | number[]) {
    // 单选：直接回传单值
    if (!props.multiple) {
      emit('update:value', next as number);
      return;
    }
    const arr = Array.isArray(next) ? next : [];
    if (!arr.length) {
      emit('update:value', [MERCHANT_ALL_VALUE]);
      return;
    }
    const last = arr[arr.length - 1];
    if (last === MERCHANT_ALL_VALUE) {
      // 刚点「全部」→ 仅保留全部
      emit('update:value', [MERCHANT_ALL_VALUE]);
      return;
    }
    // 点了具体商户 → 去掉「全部」
    emit(
      'update:value',
      arr.filter((v) => v !== MERCHANT_ALL_VALUE),
    );
  }
</script>
