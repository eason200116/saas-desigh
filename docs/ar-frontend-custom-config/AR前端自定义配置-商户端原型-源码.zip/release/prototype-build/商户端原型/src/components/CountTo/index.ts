import CountTo from './CountTo.vue';

export { CountTo };
export default CountTo;
