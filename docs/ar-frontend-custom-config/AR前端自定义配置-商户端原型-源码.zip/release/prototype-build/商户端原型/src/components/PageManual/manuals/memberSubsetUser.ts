// 下级会员（商户端 tenant · member_subsetUser）功能说明书。
// 锚定 src/views/member/subsetUser/index.vue 真实控件（R53 实证、不臆造）——本页目录下只有
// index.vue 一个文件，没有同目录 data.ts；数据逻辑收在全局 hook src/hooks/useUser.ts 的
// fetchSubsetUserPageList + src/api/index.ts 的 v1platform.getSubsetUserPageList override
// （buildSubsetUserList / buildSubsetUserRow），属全局共享模式，非本页遗漏两件套。
// 双重身份：① 独立路由 /member/subsetUser（仅商户端 roles:['tenant']）；② 同时是「提现工单详情」
// 弹窗（src/views/finance/withdrawOrder/workbench/components/WorkbenchOrderDetailModal.vue）里
// 可通过右上角下拉动态添加的 3 个懒加载页签之一，内嵌时按订单/会员所属商户锁定查询上下文。
// 单表 ProCrudTable：纯查询报表页，无新增/编辑/删除/批量/导出/操作列，唯一交互出口是「会员ID」
// 列可点跳转会员详情弹窗。页面当前未挂 data-manual 锚点，本说明书条目暂不联动面板点击高亮，
// 仅供阅读（对齐同模块既有先例 riskControlSameIp.ts / memberGroupManage.ts 现状）。

import type { PageManual } from '../types';

const manual: PageManual = {
  route: 'member_subsetUser',
  title: '下级会员',
  overview:
    '商户端「会员管理 › 下级会员」页，按指定「代理ID」查询该代理名下的下级会员列表（含相对层级 Lv1~Lv6、直属/全部下级人数、投注/充值/提现/返佣/账户金额等累计数据 + 底部汇总行）。页面默认不自动加载数据（auto-load:false），必须先填写必填项「代理ID」再点查询，否则列表保持为空。纯查询报表页，无新增/编辑/删除/批量/导出/操作列，唯一可点交互是「会员ID」列跳转会员详情弹窗。本页无独立 data.ts，数据逻辑收在全局 hook useUser.fetchSubsetUserPageList + api/index.ts 的 v1platform.getSubsetUserPageList override（buildSubsetUserList/buildSubsetUserRow）。同时具备双重身份：既是独立路由（仅商户端可见），也是「提现工单详情」弹窗（WorkbenchOrderDetailModal）里可动态添加的懒加载页签之一，内嵌时按订单/会员所属商户锁定查询上下文（真实锁定机制见「商户」条目 edge 说明）。',
  items: [
    // ============ 搜索区 ============
    {
      anchor: 'merchant',
      name: '商户',
      group: '搜索',
      interaction: '下拉单选（MerchantFilterSelect，multiple:false → 架构级不可清空，见《交互规范》§3 商户选择器）。',
      dataSource:
        '全站商户列表；默认预填当前左上角选中商户（defaultTenantId，商户端专属）；内嵌提现工单详情弹窗时优先取订单/会员所属商户（memberCtx.tenantId）。',
      logic:
        '过滤下级会员列表按选中商户；内嵌场景下 loadData 的请求参数固定用 forcedTenantId 覆盖 params.tenantId，实际生效的永远是订单/会员所属商户。',
      limit: '必填（红星 showRequireMark）；单选、不可清空——命中 R63（本页商户与会员ID类字段同屏出现）。',
      edge:
        '⚠️ 核实代码后发现两处真实缺陷：①merchantSearchColumn(...) 调用未传 disabled，商户下拉在内嵌场景下 UI 层面仍可点击/切换，代码注释"商户被锁定""搜索字段被禁用"与控件实际状态不完全一致——真正的锁定只体现在上面 logic 所述的请求参数层覆盖，用户在下拉里选别的商户不会反映到实际查询结果，只是视觉上可以点，此项尚未修复。②【已于 2026-07-21 修复】rules:[requiredRule(...)] 里的 requiredRule 此前全文件未被 import（`@/utils` barrel 不导出 formValidate.ts，vite.config.ts 唯一的 Components() 插件只自动注册 Naive UI 组件、不解析裸函数标识符）；searchColumns 是 computed，模板 :search-columns="searchColumns" 挂载时立即求值，此前这行代码必然执行——导致标准路由访问与内嵌页签场景都会在页面挂载瞬间抛 ReferenceError: requiredRule is not defined，不是仅校验环节失效，是整页级crash，且 pnpm build（esbuild 只转译不解析标识符）测不出这类问题。现已补上 import { requiredRule } from \'@/utils/formValidate\'；，并经 pnpm typecheck 核实该标识符引用错误已消失、build 通过——排查中同时发现全站另有 3 处同款缺陷（member/smsCode 在本次修复前 dev_eason 主库已先行修复，operations/agentAudit、operations/feedback 与本页同批修复），均已一并处理。',
    },
    {
      anchor: 'relativeId',
      name: '代理ID',
      group: '搜索',
      interaction: '文本输入。',
      dataSource: '用户输入。',
      logic: '意图按该代理ID查出其名下的下级会员列表（每行是该代理某一层级的下级会员）。',
      limit: '必填（formItemProps.required:true 显示星号）；仅数字，至多9位（inputProps(\'intNum\')）。',
      edge:
        '前端强制校验：值为空时 loadData() 直接短路，不发请求、弹「代理ID不能为空」提示（message.error），列表清空。⚠️ 核实代码后发现：只要非空，其具体数值对返回结果无影响——mock buildSubsetUserList 只读取 tenantId 做过滤，未读取 relativeId，任何数字都会返回同一批按商户过滤的数据。如实记录，非本次引入。',
    },
    {
      anchor: 'userId',
      name: '下级ID',
      group: '搜索',
      interaction: '文本输入。',
      dataSource: '用户输入。',
      logic: '意图按会员ID过滤下级会员列表。',
      limit:
        '选填；仅允许输入数字字符（componentProps.allowInput:onlyDigits）。⚠️ 与同页「代理ID」用 inputProps(\'intNum\')（9位上限）的写法不同，本字段直接写 allowInput 未套预设、未设置 maxlength，位数无上限——如实记录写法不一致，非报错。',
      edge: '⚠️ 核实代码后发现：mock 未读取该参数，填任何值都不影响返回结果。如实记录，非本次引入。',
    },
    {
      anchor: 'userName',
      name: '会员账号',
      group: '搜索',
      interaction: '文本输入。',
      dataSource: '用户输入。',
      logic: '意图按会员账号过滤。',
      limit: '选填；最多20位，仅字母数字下划线（inputProps(\'account\')）。',
      edge: '⚠️ 核实代码后发现：mock 未读取该参数，不影响返回结果。如实记录，非本次引入。',
    },
    {
      anchor: 'minLv',
      name: '最小层级',
      group: '搜索',
      interaction: '下拉单选（dictSelect，字典 subsetUserLevelList，来源 v1）。',
      dataSource: '字典 Lv1~Lv6（src/api/index.ts V1_DICTIONARY.subsetUserLevelList）。',
      logic: '意图配合「最大层级」框定下级相对层级区间过滤。',
      limit: '选填，可清空。',
      edge:
        '⚠️ 核实代码后发现：mock 未读取该参数，不影响返回结果；且 mock 行数据 lv 实际只会生成 1~3（buildSubsetUserList 用 `1 + (i % 3)`），4~6 在样例数据里不会出现，但字典选项本身仍展示 Lv1~Lv6 全量。如实记录，非本次引入。',
    },
    {
      anchor: 'maxLv',
      name: '最大层级',
      group: '搜索',
      interaction: '下拉单选（dictSelect，字典 subsetUserLevelList，来源 v1，与「最小层级」同一字典）。',
      dataSource: '字典 Lv1~Lv6。',
      logic: '意图配合「最小层级」框定下级相对层级区间过滤。',
      limit: '选填，可清空。',
      edge: '⚠️ 核实代码后发现：mock 未读取该参数，不影响返回结果。如实记录，非本次引入。',
    },
    {
      anchor: 'phoneType',
      name: '注册设备',
      group: '搜索',
      interaction: '下拉单选（dictSelect，字典 phoneTypeList，来源 v1）。',
      dataSource: '字典固定7种设备（H5/PC/Android/IOS/Android（壳包）/IOS（壳包）/PWA，命中 R20）。',
      logic: '意图按注册设备类型过滤。',
      limit: '选填，可清空。',
      edge: '⚠️ 核实代码后发现：mock 未读取该参数，不影响返回结果。如实记录，非本次引入。',
    },
    {
      anchor: 'userState',
      name: '会员状态',
      group: '搜索',
      interaction: '下拉单选（dictSelect，字典 userStateList，来源 v1）。',
      dataSource: '字典2项（0=禁用/1=启用）。',
      logic: '意图按会员账号启用/禁用状态过滤。',
      limit: '选填，可清空。',
      edge:
        '⚠️ 核实代码后发现：mock 未读取该参数，不影响返回结果；列表「会员状态」列本身仍按行数据真实 userState 值显示（mock 规则 `userId % 7 === 0 ? 0 : 1`），只是搜索框选择不影响哪些行被返回。如实记录，非本次引入。',
    },
    {
      anchor: 'dateRange',
      name: '注册日期',
      group: '搜索',
      interaction:
        '日期时间区间选择（proDateRange，精确到秒），配合工具栏快捷按钮（quick-date="dateRange"，quick-date-allow-clear 一键清空）。',
      dataSource: '用户选择，或点工具栏快捷按钮。',
      logic: '意图按会员注册时间过滤；展平写回 form.startTime / form.endTime。',
      limit: '最多跨90天（标准档，对齐《交互规范》§0 时间查询"标准档"分级）；不可选未来（allowFuture:false）。',
      edge: '⚠️ 核实代码后发现：mock 未读取 startTime/endTime，不影响返回结果。如实记录，非本次引入。',
    },
    {
      anchor: 'tradeTimeRange',
      name: '交易时间',
      group: '搜索',
      interaction:
        '日期时间区间选择（proDateRange，精确到秒），面板自带内置快捷选项（shortcutPreset:\'default\'，与「注册日期」走工具栏 quick-date 快捷按钮是不同入口）。',
      dataSource: '用户选择。',
      logic: '意图按交易时间过滤；展平写回 form.upStartTime / form.upEndTime。',
      limit: '最多跨90天（标准档）；不可选未来（allowFuture:false）。',
      edge: '⚠️ 核实代码后发现：mock 未读取 upStartTime/upEndTime，不影响返回结果。如实记录，非本次引入。',
    },
    {
      anchor: 'vipLevel',
      name: 'VIP等级',
      group: '搜索',
      interaction: '下拉单选（普通 select，非 dictSelect）。',
      dataSource:
        'useUser().getOptions(\'vipLevelList\') —— 走独立接口 api.v1platform.getVipLevelList 拉取并按商户缓存，不是 v1/common 字典体系；外观与 dictSelect 一致但数据源机制不同。',
      logic: '意图按 VIP 等级过滤。',
      limit: '选填，可清空。',
      edge:
        '⚠️ 核实代码后发现：mock buildSubsetUserList 未读取该参数，不影响返回结果；列表「VIP等级」列展示的是行数据自带的 vipLevelStr（如"VIP2"），与本搜索框选中值无关联验证。如实记录，非本次引入。',
    },
    {
      anchor: 'remark',
      name: '备注',
      group: '搜索',
      interaction: '文本输入。',
      dataSource: '用户输入。',
      logic: '意图按备注模糊过滤。',
      limit: '选填，最多200字（inputProps(\'remark\')）。',
      edge:
        '⚠️ 核实代码后发现：mock buildSubsetUserRow 里 remark 恒为空串 \'\'，本搜索框填任何关键词都不会匹配到数据（没有非空备注可匹配），列表「备注」列也因此恒为空。如实记录，非本次引入。',
    },

    // ============ 列 ============
    {
      anchor: 'col_memberId',
      name: '会员ID列',
      group: '列',
      interaction: '数字以可点击蓝字链接形式展示（跳转类控件，非纯展示，renderMemberIdLink）。',
      dataSource: '行数据 userId + tenantId。',
      logic: '点击跳转「会员详情」弹窗（openMemberDetailModal，来自 useUser hook，全站通用会员详情组件）。',
    },
  ],

  // ============ 字段介绍 tab（列序照页面；仅列表列 + 定义）============
  fields: [
    { name: '商户', def: '该下级会员所属的商户，展示为"商户号(商户名)"（renderTenantTag）。' },
    {
      name: '会员ID',
      def: '该下级会员的会员ID；数字为可点击链接，点击跳转会员详情弹窗查看该会员完整信息。',
    },
    { name: '会员账号', def: '该会员的登录账号。' },
    { name: 'VIP等级', def: '该会员当前的VIP等级（如"VIP2"）。' },
    { name: '上级ID', def: '该会员的直接上级（推荐人/上线）会员ID。' },
    {
      name: '相对层级',
      def: '该会员相对于所查询「代理ID」的层级深度（Lv1~Lv6，数字越大层级越深）。',
    },
    { name: '直属下级', def: '该会员名下直接下级（一级）的会员数量。' },
    { name: '全部下级', def: '该会员名下全部层级下级会员的总数量（含间接下级）。' },
    { name: '注册日期', def: '该会员的注册时间，按所属商户时区展示；支持按此列排序。' },
    {
      name: '会员状态',
      def: '该会员账号的启用/禁用状态；只读标签展示（绿色"启用"/红色"禁用"），本页无编辑入口。',
    },
    { name: '在线状态', def: '该会员当前是否在线；只读标签展示（"在线"/"离线"）。' },
    { name: '注册设备', def: '该会员注册时使用的设备类型（H5/PC/Android/IOS 等）。' },
    {
      name: '黑名单状态',
      def: '该会员是否被列入黑名单；只读标签展示（"正常"/"黑名单"），本页无编辑入口。',
    },
    { name: '投注(金额/次)', def: '该会员的累计投注金额与投注次数（金额、次数两行展示）。' },
    { name: '充值(金额/次)', def: '该会员的累计充值金额与充值次数。' },
    { name: '提现(金额/次)', def: '该会员的累计提现金额与提现次数。' },
    { name: '返佣(金额/次)', def: '该会员的累计返佣金额与返佣次数。' },
    { name: '账户金额', def: '该会员当前的账户余额；支持按此列排序。' },
    { name: '备注', def: '该会员的备注信息；⚠️ 当前 mock 恒为空串，本列展示恒为空（如实记录）。' },
  ],
};

export default manual;
