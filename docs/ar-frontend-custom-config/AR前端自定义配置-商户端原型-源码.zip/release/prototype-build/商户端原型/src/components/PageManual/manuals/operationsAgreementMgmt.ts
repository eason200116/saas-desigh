// 协议管理（商户端 tenant · operations_agreementMgmt）功能说明书。
// 锚定 src/views/operations/agreementMgmt/index.vue + data.ts 真实控件（R53 实证、不臆造）。
// 页面形态特殊：非 ProCrudTable 列表页，是「按商户+协议类型+语言」编辑的多语言富文本内容页
// （由 V1 隐私协议/风险协议/玩法指引 3个独立页面合并而来）。

import type { PageManual } from '../types';

const manual: PageManual = {
  route: 'operations_agreementMgmt',
  title: '协议管理',
  overview:
    '商户端「运营管理 › 协议管理」页，维护3类协议文本（隐私协议/风险协议/玩法指引），每类协议按' +
    '"所选商户的配套语言"逐语言编辑富文本内容。操作顺序固定：①先选协议类型(Tab) → ②再选配置商户' +
    '(MerchantSwitchBar，必选) → ③编辑器按该商户配套语言展开逐语言内容(富文本，切商户/类型自动加载' +
    '并保留上次保存内容) → ④保存(二次确认后即生效)。' +
    '2026-07-22核实代码：本页保存逻辑(saveAgreement)真实写回内存STORE(按商户+类型+语言三维隔离)，' +
    '刷新/切换后能看到保存结果，未发现假成功问题，是本次说明书铺开任务里少数完全正常的页面之一。',
  items: [
    {
      anchor: 'type_tab',
      name: '协议类型切换（隐私协议/风险协议/玩法指引）',
      group: '操作',
      interaction: '横排Tab，点击切换，默认停在"隐私协议"。',
      logic: '切换类型会按当前已选商户重新加载该类型逐语言内容。',
    },
    {
      anchor: 'merchant',
      name: '配置商户',
      group: '搜索',
      interaction: 'MerchantSwitchBar单选商户组件，必选（页面加载后自动选中首个商户）。',
      logic: '切换商户会按当前协议类型、该商户的配套语言集重新加载内容；未选商户时编辑器不显示。',
    },
    {
      anchor: 'editor',
      name: '协议内容编辑器（逐语言）',
      group: '搜索',
      interaction:
        '富文本编辑器，语言集随所选商户的配套语言联动展开，逐语言分别编辑，无需额外操作直接输入。',
      dataSource:
        '语言集来自 getMerchantLanguageCodes(tenantId)，不同商户支持的语言子集不同（至少含中文/英文）。',
    },
    {
      anchor: 'act_save',
      name: '保存',
      group: '操作',
      interaction: '主色大按钮，点击弹二次确认，确认后才真正保存。',
      logic:
        '保存当前协议类型下该商户全部语言的内容，成功后回填"最后更新时间"+"最后修改人"并刷新编辑器内容。',
    },
  ],
  fields: [
    {
      name: '最后更新时间',
      def: '当前协议类型+商户下，全部语言版本中最近一次保存的时间（取最大值）。',
    },
    { name: '最后修改人', def: '最近一次保存该协议内容的操作人账号。' },
  ],
};

export default manual;
