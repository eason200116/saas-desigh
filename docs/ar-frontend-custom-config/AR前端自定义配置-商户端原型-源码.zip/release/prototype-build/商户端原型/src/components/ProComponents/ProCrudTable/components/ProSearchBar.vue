<template>
  <ProForm
    :form="form"
    :label-width="finalLabelWidth"
    :label-placement="labelPlacement"
    :size="size"
    class="pro-search-form"
    @keydown.enter.prevent="handleSearch"
  >
    <div
      ref="contentRef"
      class="pro-search-form-content"
      :class="{ 'is-flex-layout': layout === 'flex' }"
      :style="containerStyle"
    >
      <template v-for="column in visibleColumns" :key="column.path">
        <div
          v-if="isColumnVisible(column)"
          class="pro-search-form-item"
          :style="getItemStyle(column)"
        >
          <n-form-item
            v-if="column.render"
            :path="column.path"
            :label="column.label"
            :label-width="column.labelWidth"
            :show-label="showLabel"
            :rule="column.rules"
            v-bind="column.formItemProps"
          >
            <component :is="renderColumn(column)" />
          </n-form-item>
          <ProField
            v-else
            :path="column.path"
            :label="column.label"
            :label-message="column.labelMessage"
            :label-width="column.labelWidth"
            :value-type="column.valueType || 'text'"
            :component="column.component"
            :component-props="column.componentProps"
            :default-value="column.defaultValue"
            :rules="column.rules"
            :required="column.required"
            :required-message="column.requiredMessage"
            :placeholder="column.placeholder"
            :options="column.options"
            :field-mapping="column.fieldMapping"
            :show="column.show"
            :disabled="column.disabled"
            :readonly="column.readonly"
            :dependencies="column.dependencies"
            :transform-in="column.transformIn"
            :transform-out="column.transformOut"
            :form-item-props="{ showLabel, ...column.formItemProps }"
            :span="column.span"
          />
        </div>
      </template>

      <div v-if="showActions" class="pro-search-form-actions" :style="actionsStyle">
        <div ref="actionsInnerRef" class="pro-search-form-actions-inner">
          <slot name="suffix" :overflow="isOverflow">
            <n-space :wrap="false" :justify="isOverflow ? 'end' : 'start'">
              <n-button
                v-if="searchButtonProps !== false"
                type="primary"
                size="small"
                v-bind="mergedSearchButtonProps"
                @click="handleSearch"
              >
                <template #icon>
                  <n-icon><SearchOutlined /></n-icon>
                </template>
                <slot name="search-text">{{ t('components.proSearchForm.search') }}</slot>
              </n-button>

              <n-button
                v-if="resetButtonProps !== false"
                size="small"
                v-bind="mergedResetButtonProps"
                @click="handleReset"
              >
                <template #icon>
                  <n-icon><ReloadOutlined /></n-icon>
                </template>
                <slot name="reset-text">{{ t('common.reset') }}</slot>
              </n-button>
              <ProAdvancedSearchTrigger v-if="hasAdvancedColumns">
                <ProAdvancedSearchPanel />
              </ProAdvancedSearchTrigger>
              <n-button
                v-if="showCollapseButton && collapseButtonProps !== false"
                text
                type="primary"
                size="small"
                v-bind="mergedCollapseButtonProps"
                @click="handleToggleCollapse"
              >
                <slot name="collapse-text">
                  {{
                    t(
                      form.collapsed.value
                        ? 'components.proSearchForm.expand'
                        : 'components.proSearchForm.collapse',
                    )
                  }}
                </slot>
                <template #icon>
                  <n-icon
                    :size="COLLAPSE_CHEVRON_ICON_SIZE"
                    class="pro-search-form-collapse-icon"
                    :class="{ 'pro-search-form-collapse-icon--expanded': !form.collapsed.value }"
                  >
                    <ChevronDown />
                  </n-icon>
                </template>
              </n-button>
            </n-space>
          </slot>
        </div>
      </div>
    </div>
  </ProForm>
</template>

<script lang="ts" setup>
  import { computed, ref, type PropType } from 'vue';
  import { NButton, NSpace, NIcon, NFormItem, type ButtonProps } from 'naive-ui';
  import { SearchOutlined, ReloadOutlined } from '@vicons/antd';
  import { ChevronDown } from '@vicons/ionicons5';
  import { useI18n } from 'vue-i18n';
  import ProForm from '../../ProForm/ProForm.vue';
  import ProField from '../../ProField/ProField.vue';
  import ProAdvancedSearchTrigger from './ProAdvancedSearchTrigger.vue';
  import ProAdvancedSearchPanel from './ProAdvancedSearchPanel.vue';
  import { useProCrudTableContextSafe } from '../../context/crudTableContext';
  import { useResponsiveGrid } from '../composables/useResponsiveGrid';
  import { useAutoLabelWidth } from '../composables/useAutoLabelWidth';
  import { AUTO_LABEL_WIDTH } from '../constants';
  import type { Recordable, ProSearchFormColumn, CreateProSearchFormReturn } from '../../types';

  defineOptions({ name: 'ProSearchBar' });

  /** 与 `ProCrudTable` 中间折叠条箭头同尺寸，保证两处旋转动画观感一致 */
  const COLLAPSE_CHEVRON_ICON_SIZE = 14;

  const props = defineProps({
    form: { type: Object as PropType<CreateProSearchFormReturn<any>>, required: true },
    columns: { type: Array as PropType<ProSearchFormColumn[]>, default: () => [] },
    searchButtonProps: {
      type: [Object, Boolean] as PropType<Partial<ButtonProps> | false>,
      default: () => ({}),
    },
    resetButtonProps: {
      type: [Object, Boolean] as PropType<Partial<ButtonProps> | false>,
      default: () => ({}),
    },
    collapseButtonProps: {
      type: [Object, Boolean] as PropType<Partial<ButtonProps> | false>,
      default: () => ({}),
    },
    showSuffixGridItem: { type: Boolean, default: true },
    showLabel: { type: Boolean, default: true },
    labelWidth: { type: [Number, String] as PropType<number | string>, default: AUTO_LABEL_WIDTH },
    labelPlacement: { type: String as PropType<'left' | 'top'>, default: 'left' },
    size: { type: String as PropType<'small' | 'medium' | 'large'>, default: 'small' },
    layout: { type: String as PropType<'grid' | 'flex'>, default: 'grid' },
    componentWidth: { type: [Number, String] as PropType<number | string>, default: 200 },
    xGap: { type: [Number, String] as PropType<number | string>, default: 12 },
    yGap: { type: [Number, String] as PropType<number | string>, default: 8 },
    cols: { type: [Number, String] as PropType<number | string>, default: 4 },
    collapsedRows: { type: Number, default: 1 },
    autoSpan: { type: Boolean, default: false },
    /** 外部加载态（通常由表格请求 loading 注入），用于搜索/重置按钮的联动防连击 */
    loading: { type: Boolean, default: false },
  });

  const emit = defineEmits<{
    (e: 'search', values: Recordable): void;
    (e: 'reset'): void;
    (e: 'collapse', collapsed: boolean): void;
  }>();

  const { t } = useI18n();
  const ctx = useProCrudTableContextSafe();
  const hasAdvancedColumns = computed(() => (ctx?.advancedColumns.value.length ?? 0) > 0);
  const showActions = computed(() => props.showSuffixGridItem || hasAdvancedColumns.value);

  const contentRef = ref<HTMLElement | null>(null);
  const actionsInnerRef = ref<HTMLElement | null>(null);
  const containerEl = computed<HTMLElement | null>(() => contentRef.value);

  // composables — 响应式网格 + 折叠/展开统一处理
  const {
    containerStyle,
    getItemStyle,
    visibleColumns,
    isColumnVisible,
    isOverflow,
    showCollapseButton,
    actionsStyle,
  } = useResponsiveGrid({
    cols: computed(() => props.cols),
    layout: computed(() => props.layout),
    xGap: computed(() => props.xGap),
    yGap: computed(() => props.yGap),
    componentWidth: computed(() => props.componentWidth),
    labelWidth: computed(() => props.labelWidth),
    labelPlacement: computed(() => props.labelPlacement),
    autoSpan: computed(() => props.autoSpan),
    containerRef: containerEl,
    actionsRef: actionsInnerRef,
    form: props.form,
    columns: computed(() => props.columns),
    collapsedRows: computed(() => props.collapsedRows),
    showActions,
  });

  // 自治 label 宽度：canvas 离屏测量当前可见列 label 的最大像素宽度，
  // 完全绕过 NForm 的 maxChildLabelWidthRef 共享 ref 锁死 0 的 race condition。
  //
  // 启用条件：labelPlacement='left' 时**始终启用**（除非 top 布局）。
  // props.labelWidth 数字（如 ProCrudTable 默认 80）作为 minWidth/fallback 兜底：
  //   - 中文短 label 测出 ~70 → clamp 到 80 → 视觉与历史行为一致
  //   - 英文/越南/印尼长 label 测出 120-180 → 实际渲染 120-180 → 多语言完整显示
  // props.labelWidth='auto' 或非数字时，minWidth 走 hook 默认 60。
  const allLabels = computed(() =>
    visibleColumns.value
      .filter(isColumnVisible)
      .map((col) => col.label ?? '')
      .filter((s) => typeof s === 'string' && s.length > 0),
  );

  const isAutoLabelMode = computed(() => props.labelPlacement === 'left');

  const labelWidthFallback = computed(() =>
    typeof props.labelWidth === 'number' ? props.labelWidth : 80,
  );

  const autoMeasuredLabelWidth = useAutoLabelWidth({
    labels: allLabels,
    containerRef: contentRef,
    enabled: isAutoLabelMode,
    minWidth: labelWidthFallback,
    fallback: labelWidthFallback,
  });

  const finalLabelWidth = computed(() => {
    if (props.labelPlacement === 'top') return undefined;
    return autoMeasuredLabelWidth.value;
  });

  // 防连击：本地搜索锁 + 外部 loading 共同决定按钮与 enter 键是否可触发，
  // 覆盖校验耗时（isSearching）+ 表格请求耗时（props.loading）全程。
  const isSearching = ref(false);
  const isBusy = computed(() => isSearching.value || props.loading);

  // 按钮属性
  const mergedSearchButtonProps = computed(() => {
    const base = props.searchButtonProps === false ? {} : { ...props.searchButtonProps };
    return {
      ...base,
      loading: isBusy.value || Boolean(base.loading),
      disabled: isBusy.value || Boolean(base.disabled),
    };
  });
  const mergedResetButtonProps = computed(() => {
    const base = props.resetButtonProps === false ? {} : { ...props.resetButtonProps };
    return {
      ...base,
      disabled: isBusy.value || Boolean(base.disabled),
    };
  });
  const mergedCollapseButtonProps = computed(() =>
    props.collapseButtonProps === false ? {} : { ...props.collapseButtonProps },
  );

  // 事件处理
  async function handleSearch() {
    if (isBusy.value) return;
    isSearching.value = true;
    try {
      const result = await props.form.search();
      emit('search', result);
    } catch {
      // 验证失败
    } finally {
      isSearching.value = false;
    }
  }

  function handleReset() {
    if (isBusy.value) return;
    props.form.reset();
    emit('reset');
  }

  function handleToggleCollapse() {
    props.form.toggleCollapsed();
    emit('collapse', props.form.collapsed.value);
  }

  function renderColumn(column: ProSearchFormColumn) {
    if (!column.render) return null;
    return column.render({
      formModel: props.form.values.value,
      field: column.path,
      setValue: (value: any) => props.form.setFieldValue(column.path, value),
    });
  }

  defineExpose({
    getSearchParams: () => props.form.getSearchParams(),
    search: handleSearch,
    reset: handleReset,
  });
</script>

<style lang="less" scoped>
  .pro-search-form-content {
    width: 100%;
  }

  .pro-search-form {
    // 多语言下 label 必须单行完整显示（测试硬性要求），
    // 强制 nowrap 是 useAutoLabelWidth 测量算法之外的保险，
    // 即使测量瞬间失准也不允许 wrap，宁可文字横向溢出。
    ::v-deep(.n-form-item-label) {
      white-space: nowrap;
    }

    ::v-deep(.n-form-item) {
      margin-bottom: 8px;

      /**
       * ⚠️ 搜索表单验证提示样式 —— 请勿修改！
       * 将 NFormItem 的 feedback 区域折叠为零高度，
       * 验证提示浮动显示在输入框下方（translateY(2px)）。
       * 如果改回负值偏移会导致提示跑到输入框上方，与产品要求不符。
       */
      .n-form-item-feedback-wrapper {
        min-height: 0 !important;
        height: 0 !important;
        overflow: visible !important;
        padding: 0 !important;
        margin: 0 !important;
        transition: none !important;
        pointer-events: none;

        .n-form-item-feedback {
          position: relative;
          z-index: 10;
          font-size: 11px;
          line-height: 1;
          padding: 2px 8px;
          border-radius: 4px;
          white-space: nowrap;
          width: fit-content;
          /* 验证提示显示在输入框下方，禁止改为负值偏移 */
          transform: translateY(2px);
        }
      }
    }

    .pro-search-form-collapse-icon {
      transform-origin: center;
      transition: transform 0.22s cubic-bezier(0.4, 0, 0.2, 1);
    }

    .pro-search-form-collapse-icon--expanded {
      transform: rotate(180deg);
    }
  }

  .pro-search-form-content.is-flex-layout {
    .pro-search-form-item {
      flex: 0 0 auto;

      ::v-deep(.n-form-item) {
        grid-template-columns: auto var(--pro-search-component-width, 200px);
      }
    }
  }

  .pro-search-form-actions {
    justify-self: end;
    padding-right: 6px;
    /* 提升层级，避免「展开/收起」按钮被下方表格 sticky header 遮住 */
    position: relative;
    z-index: 2;
  }

  .pro-search-form-actions-inner {
    display: flex;
    align-items: center;
    justify-content: flex-end;
    gap: 12px;
    flex-wrap: wrap;
  }

  .pro-search-form-actions-trigger {
    display: flex;
    align-items: center;
  }
</style>
