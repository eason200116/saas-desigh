<template>
  <n-popover trigger="click" placement="bottom-end" :width="220">
    <template #trigger>
      <n-button size="small">
        <template #icon>
          <n-icon :size="14">
            <SettingOutlined />
          </n-icon>
        </template>
        {{ t('components.proColumnSetting.customColumns') }}
      </n-button>
    </template>

    <div class="column-setting-panel">
      <div class="column-setting-panel__header">
        <n-checkbox
          :checked="isAllChecked"
          :indeterminate="isIndeterminate"
          @update:checked="handleCheckAll"
        >
          {{ t('components.proColumnSetting.columnDisplay') }}
        </n-checkbox>
        <n-button text size="small" @click="handleReset">
          {{ t('common.reset') }}
        </n-button>
      </div>

      <div ref="listRef" class="column-setting-panel__list">
        <div
          v-for="(item, index) in sortedSettings"
          :key="item.key"
          :data-key="item.key"
          :data-fixed="item.fixed ? '1' : '0'"
          :data-locked="isLockFixed(item.key) ? '1' : '0'"
          class="column-setting-panel__item"
        >
          <n-icon
            v-if="!isLockFixed(item.key)"
            class="column-setting-panel__drag-handle"
            :size="14"
          >
            <HolderOutlined />
          </n-icon>
          <span v-else class="column-setting-panel__drag-handle is-disabled" />
          <n-checkbox
            :checked="item.visible"
            @update:checked="() => ctx.toggleColumnVisibility(item.key)"
          >
            <ColumnSettingTitle :column-key="item.key" />
          </n-checkbox>
          <n-icon
            class="column-setting-panel__pin-btn"
            :class="{ 'is-pinned': !!item.fixed || isLockFixed(item.key), 'is-locked': isLockFixed(item.key) }"
            :size="14"
            @click="() => !isLockFixed(item.key) && ctx.toggleColumnFixed(item.key)"
          >
            <PushpinFilled v-if="item.fixed || isLockFixed(item.key)" />
            <PushpinOutlined v-else />
          </n-icon>
          <div
            v-if="
              item.fixed && !sortedSettings[index + 1]?.fixed && index < sortedSettings.length - 1
            "
            class="column-setting-panel__divider"
          />
        </div>
      </div>
    </div>
  </n-popover>
</template>

<script lang="ts" setup>
  import {
    computed,
    defineComponent,
    h,
    nextTick,
    onBeforeUnmount,
    onActivated,
    onDeactivated,
    onMounted,
    ref,
    type VNode,
    watch,
  } from 'vue';
  import { NPopover, NButton, NIcon, NCheckbox } from 'naive-ui';
  import { SettingOutlined, HolderOutlined, PushpinOutlined, PushpinFilled } from '@vicons/antd';
  import { useI18n } from 'vue-i18n';
  import Sortable from 'sortablejs';
  import { useProCrudTableContext } from '../../context/crudTableContext';
  import type { ProColumn } from '../../types';

  defineOptions({ name: 'ProColumnSettingPanel' });

  const ctx = useProCrudTableContext();
  const { t } = useI18n();

  const listRef = ref<HTMLElement | null>(null);
  let sortableInstance: Sortable | null = null;

  // 锁定冻结的列(如操作列):不可取消冻结、不可拖拽排序,仅允许显隐
  const lockFixedKeys = computed(
    () => new Set(ctx.columns.value.filter((c) => c.lockFixed).map((c) => String(c.key))),
  );
  const isLockFixed = (key: string) => lockFixedKeys.value.has(key);

  const sortedSettings = computed(() =>
    [...ctx.columnSettings.value].sort((a, b) => {
      // 锁定列永远排最后，与表格渲染保持一致
      const la = isLockFixed(a.key) ? 1 : 0;
      const lb = isLockFixed(b.key) ? 1 : 0;
      if (la !== lb) return la - lb;
      return a.order - b.order;
    }),
  );

  const visibleCount = computed(() => ctx.columnSettings.value.filter((s) => s.visible).length);
  const isAllChecked = computed(() => visibleCount.value === ctx.columnSettings.value.length);
  const isIndeterminate = computed(
    () => visibleCount.value > 0 && visibleCount.value < ctx.columnSettings.value.length,
  );

  type ColumnTitleContent = string | VNode;

  function getColumnTitle(key: string): ColumnTitleContent {
    const col = ctx.columns.value.find((c: ProColumn) => String(c.key) === key);
    if (!col) return key;
    if (col.columnSettingTitle) return col.columnSettingTitle;
    if (typeof col.title === 'function') return col.title();
    return col.title ?? key;
  }

  const ColumnSettingTitle = defineComponent({
    name: 'ColumnSettingTitle',
    props: {
      columnKey: {
        type: String,
        required: true,
      },
    },
    setup(props) {
      return () => {
        const title = getColumnTitle(props.columnKey);
        return typeof title === 'string'
          ? title
          : h('span', { class: 'column-setting-panel__title' }, [title]);
      };
    },
  });

  function handleCheckAll(checked: boolean) {
    ctx.setAllVisible(checked);
  }

  function handleReset() {
    ctx.resetColumnSetting();
  }

  function destroySortable() {
    try {
      sortableInstance?.destroy();
    } catch {
      /* ignore */
    }
    sortableInstance = null;
  }

  function initSortable() {
    if (!listRef.value) return;
    destroySortable();
    sortableInstance = Sortable.create(listRef.value, {
      animation: 200,
      handle: '.column-setting-panel__drag-handle',
      filter: '[data-locked="1"]', // 锁定冻结列不可拖拽
      onMove: (evt) => {
        // 不可拖到锁定列(操作列)之后,保持其末位
        if (evt.related.getAttribute('data-locked') === '1') return false;
        const draggedFixed = evt.dragged.getAttribute('data-fixed') === '1';
        const relatedFixed = evt.related.getAttribute('data-fixed') === '1';
        if (draggedFixed !== relatedFixed) return false;
      },
      onEnd: () => {
        if (!listRef.value) return;
        const items = listRef.value.querySelectorAll('[data-key]');
        const keys = Array.from(items).map((el) => (el as HTMLElement).dataset.key!);
        ctx.updateColumnOrder(keys);
      },
    });
  }

  onMounted(() => nextTick(initSortable));
  onActivated(() => nextTick(initSortable));
  watch(listRef, (el) => {
    if (el) nextTick(initSortable);
  });
  onDeactivated(destroySortable);
  onBeforeUnmount(destroySortable);
</script>

<style lang="less" scoped>
  .column-setting-panel {
    &__header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding-bottom: 8px;
      border-bottom: 1px solid var(--n-divider-color, #efeff5);
      margin-bottom: 4px;
    }

    &__list {
      max-height: 300px;
      overflow-y: auto;
    }

    &__item {
      display: flex;
      align-items: center;
      gap: 8px;
      padding: 5px 0;
      cursor: default;
      position: relative;
    }

    &__drag-handle {
      cursor: grab;
      color: #999;
      flex-shrink: 0;
      width: 14px;

      &:active {
        cursor: grabbing;
      }

      &:hover {
        color: #666;
      }

      &.is-disabled {
        cursor: default;
      }
    }

    &__pin-btn {
      margin-left: auto;
      cursor: pointer;
      color: #999;
      flex-shrink: 0;
      transition: color 0.2s;

      &:hover {
        color: #666;
      }

      &.is-pinned {
        color: var(--n-text-color-focus, #18a058);
      }

      // 锁定冻结列:常驻冻结色、不可点击取消
      &.is-locked {
        cursor: not-allowed;
        color: var(--n-text-color-focus, #18a058);
        opacity: 0.55;

        &:hover {
          color: var(--n-text-color-focus, #18a058);
        }
      }
    }

    &__divider {
      position: absolute;
      left: 0;
      right: 0;
      bottom: -1px;
      height: 1px;
      background: var(--n-divider-color, #efeff5);
    }

    &__title {
      display: inline-flex;
      align-items: center;
      min-width: 0;
    }
  }
</style>
