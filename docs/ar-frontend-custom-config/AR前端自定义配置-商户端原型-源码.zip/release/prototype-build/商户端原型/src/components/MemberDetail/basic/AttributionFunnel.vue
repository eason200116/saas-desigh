<template>
  <!--
    归因脉络漏斗：注册时一次性固化的「18 种归因穷举判定」结果可视化。
    顶部 chips 概览（命中编码 / 触发 / 来源 / 邀请类型）+ 5 步卡片（来源→入口→注册→采集→留存）。
    数据来自 mock attributionFunnel，纯展示组件。
  -->
  <div class="attr-funnel">
    <!-- 顶部概览 chips -->
    <div class="attr-funnel__summary">
      <span class="attr-funnel__chip attr-funnel__chip--hit">{{
        t('member.detail.basic.funnel.hitLabel')
      }}</span>
      <span class="attr-funnel__chip attr-funnel__chip--code">{{ data.hit || '--' }}</span>
      <span class="attr-funnel__chip"
        >{{ t('member.detail.basic.funnel.triggerLabel') }}：{{ tr(data.trigger) || '--' }}</span
      >
      <span class="attr-funnel__sep">→</span>
      <span class="attr-funnel__chip attr-funnel__chip--accent">{{ tr(data.source) || '--' }}</span>
      <span class="attr-funnel__sep">→</span>
      <span class="attr-funnel__chip attr-funnel__chip--accent">{{
        tr(data.inviteType) || '--'
      }}</span>
    </div>

    <!-- 5 步卡片 -->
    <div class="attr-funnel__steps">
      <template v-for="(step, i) in steps" :key="step.key">
        <div class="attr-funnel__card" :class="{ 'attr-funnel__card--accent': step.accent }">
          <div class="attr-funnel__card-title">{{ step.title }}</div>

          <!-- ① 来源 -->
          <template v-if="step.key === 'source'">
            <span class="attr-funnel__tag"
              >{{ t('member.detail.basic.funnel.sourceLabel') }}：{{
                tr(data.source) || '--'
              }}</span
            >
            <p class="attr-funnel__desc">{{ tr(data.sourceDesc) }}</p>
          </template>

          <!-- ② 入口 -->
          <template v-else-if="step.key === 'entry'">
            <div class="attr-funnel__row">
              <span class="attr-funnel__k">{{ t('member.detail.basic.funnel.channelLabel') }}</span>
              <span class="attr-funnel__v">{{ tr(data.entryChannel) || '--' }}</span>
            </div>
            <div class="attr-funnel__row">
              <span class="attr-funnel__k">{{ t('member.detail.basic.funnel.domainLabel') }}</span>
              <span class="attr-funnel__v">{{ tr(data.entryDomain) || '--' }}</span>
            </div>
          </template>

          <!-- ③ 注册 -->
          <template v-else-if="step.key === 'register'">
            <p class="attr-funnel__highlight"
              >{{ tr(data.registerInvite)
              }}<span class="attr-funnel__sub">{{ tr(data.registerInviteSub) }}</span></p
            >
            <div class="attr-funnel__row">
              <span class="attr-funnel__k">{{
                t('member.detail.basic.funnel.bindAgentLabel')
              }}</span>
              <span class="attr-funnel__v">{{ tr(data.bindAgent) || '--' }}</span>
            </div>
            <div class="attr-funnel__row">
              <span class="attr-funnel__k">{{
                t('member.detail.basic.funnel.firstAgentLabel')
              }}</span>
              <span class="attr-funnel__v">{{ tr(data.firstAgent) || '--' }}</span>
            </div>
          </template>

          <!-- ④ 采集 -->
          <template v-else-if="step.key === 'collect'">
            <p class="attr-funnel__desc attr-funnel__desc--strong">{{ tr(data.collectMain) }}</p>
            <p class="attr-funnel__desc">{{ tr(data.collectChannel) }}</p>
            <p class="attr-funnel__desc attr-funnel__desc--muted">{{ tr(data.collectMore) }}</p>
          </template>

          <!-- ⑤ 留存 -->
          <template v-else>
            <p class="attr-funnel__desc"
              ><span class="attr-funnel__k">{{ t('member.detail.basic.funnel.fixedLabel') }}：</span
              >{{ tr(data.retainFixed) }}</p
            >
            <p class="attr-funnel__desc"
              ><span class="attr-funnel__k attr-funnel__k--edit"
                >{{ t('member.detail.basic.funnel.adjustableLabel') }}：</span
              >{{ tr(data.retainAdjustable) }}</p
            >
          </template>
        </div>
        <span v-if="i < steps.length - 1" class="attr-funnel__arrow">→</span>
      </template>
    </div>
  </div>
</template>

<script setup lang="ts">
  import { computed } from 'vue';
  import { useI18n } from 'vue-i18n';
  import { attrLabel } from './attributionLabel';

  defineOptions({ name: 'AttributionFunnel' });

  const props = defineProps<{ data: Record<string, any> }>();
  const { t } = useI18n();

  // 归因漏斗字段值是 mock 中文整句，显示处翻译（中文态原样、英文态译；动态值如邀请码/渠道/姓名保留）
  const tr = (raw: any) => attrLabel(t, raw);

  // 5 步固定结构；①来源 / ③注册 为命中路径高亮卡
  const steps = computed(() => [
    { key: 'source', accent: true, title: t('member.detail.basic.funnel.step1Title') },
    { key: 'entry', accent: false, title: t('member.detail.basic.funnel.step2Title') },
    { key: 'register', accent: true, title: t('member.detail.basic.funnel.step3Title') },
    { key: 'collect', accent: false, title: t('member.detail.basic.funnel.step4Title') },
    { key: 'retain', accent: false, title: t('member.detail.basic.funnel.step5Title') },
  ]);
  // 显式引用 props 以避免未使用告警（模板通过 data 访问）
  void props;
</script>

<style lang="less" scoped>
  .attr-funnel {
    border: 1px solid #fde68a;
    border-radius: 8px;
    background: #fffbeb;
    padding: 12px;
  }

  .attr-funnel__summary {
    display: flex;
    flex-wrap: wrap;
    align-items: center;
    gap: 6px;
    margin-bottom: 12px;
  }

  .attr-funnel__chip {
    display: inline-flex;
    align-items: center;
    padding: 2px 8px;
    font-size: 12px;
    color: #92400e;
    background: #fef3c7;
    border: 1px solid #fcd34d;
    border-radius: 4px;
    white-space: nowrap;

    &--hit {
      color: #fff;
      background: #f59e0b;
      border-color: #f59e0b;
    }

    &--code {
      font-weight: 700;
      color: #b45309;
    }

    &--accent {
      color: #c2410c;
      background: #ffedd5;
      border-color: #fdba74;
    }
  }

  .attr-funnel__sep {
    color: #d97706;
    font-size: 13px;
  }

  .attr-funnel__steps {
    display: flex;
    align-items: stretch;
    gap: 6px;
    overflow-x: auto;
  }

  .attr-funnel__card {
    flex: 1 1 0;
    min-width: 150px;
    padding: 10px;
    background: #fff;
    border: 1px solid #f0f0f0;
    border-radius: 8px;

    &--accent {
      background: #fff7ed;
      border-color: #fdba74;
    }
  }

  .attr-funnel__card-title {
    margin-bottom: 8px;
    font-size: 12px;
    font-weight: 600;
    color: #ea580c;
  }

  .attr-funnel__tag {
    display: inline-block;
    margin-bottom: 6px;
    padding: 1px 7px;
    font-size: 12px;
    color: #c2410c;
    background: #ffedd5;
    border-radius: 4px;
  }

  .attr-funnel__highlight {
    margin: 0 0 6px;
    font-size: 13px;
    font-weight: 600;
    color: #c2410c;
  }

  .attr-funnel__sub {
    margin-left: 2px;
    font-size: 12px;
    font-weight: 400;
    color: #9a3412;
  }

  .attr-funnel__row {
    display: flex;
    flex-direction: column;
    gap: 1px;
    padding: 3px 0;
    font-size: 12px;
    line-height: 1.5;
  }

  .attr-funnel__k {
    flex-shrink: 0;
    color: #94a3b8;

    &--edit {
      color: #2563eb;
    }
  }

  .attr-funnel__v {
    color: #1e293b;
    font-weight: 500;
    overflow-wrap: anywhere;
  }

  .attr-funnel__desc {
    margin: 0 0 4px;
    font-size: 12px;
    line-height: 1.5;
    color: #475569;
    word-break: break-all;

    &--strong {
      color: #1e293b;
      font-weight: 500;
    }

    &--muted {
      color: #94a3b8;
    }
  }

  .attr-funnel__arrow {
    display: flex;
    align-items: center;
    color: #fdba74;
    font-size: 16px;
  }
</style>
