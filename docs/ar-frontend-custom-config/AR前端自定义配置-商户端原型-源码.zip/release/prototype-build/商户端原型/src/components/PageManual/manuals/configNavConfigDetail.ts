// 导航配置详情/游戏导航工作台（商户端 tenant · configCenter_navConfigDetail）功能说明书。
// 锚定 src/views/config/navConfig/detail/index.vue(薄包装) →
// src/views/operations/siteList/gameNav/index.vue(实体workspace) +
// shared/WorkspaceSideNav.vue + PhonePreview 真实控件（R53 实证、不臆造）。
// 隐藏路由(菜单不显，激活态回指navConfig列表)，从「导航配置」卡片点击进入；:tenantId真实路由参数。
// 9个板块编辑区各自是独立懒加载组件(HomeDataPanel/HeaderNavPanel/SidebarPanel/BottomNavPanel/
// BannerPanel/NoticePanel/PromoPanel/FooterPanel/RealtimePanel)，字段级内容属工作台自身范畴，
// 此处只文档化本页壳层控件(返回/板块切换/工具栏操作/预览折叠)，与品牌配置内嵌工作台同一documentation深度取舍。

import type { PageManual } from '../types';

const manual: PageManual = {
  route: 'configCenter_navConfigDetail',
  title: '导航配置详情（游戏导航工作台）',
  overview:
    '「导航配置」卡片点击后进入的独立详情页(隐藏路由，左侧菜单激活态仍指向导航配置列表)。左侧竖排切到' +
    '9个板块：分类楼层/顶部导航/侧边栏/底部导航/轮播横幅/公告消息/推广区块/页脚配置/实时数据，每个板块' +
    '各自懒加载对应编辑组件。顶部工具栏按当前板块动态给出操作按钮：多数板块="重置修改/保存草稿/发布' +
    '版本"三个；"底部导航"板块特殊="重置修改/保存底部导航"(无独立发布态，按端Web/H5/APP各自独立配置)。' +
    '右侧手机实时预览可折叠。校验失败时(底部导航板块除外)编辑区顶部显示错误清单。' +
    '9个板块字段级内容属该共享工作台自身范畴，非本页独有，此处只文档化壳层控件；如需板块内部字段' +
    '细节应另建工作台自身的功能说明书。2026-07-22核实代码未发现真实缺陷。',
  items: [
    {
      anchor: 'handleBack',
      name: '返回',
      group: '操作',
      interaction: '按钮，返回「导航配置」列表页。',
    },
    {
      anchor: 'panelSwitch',
      name: '板块切换',
      group: '搜索',
      interaction: '左侧竖排导航，点击切到对应板块编辑区；未保存改动切换前会二次确认是否放弃。',
    },
    {
      anchor: 'toolbarAction',
      name: '工具栏操作（重置/保存草稿/发布版本，或重置/保存底部导航）',
      group: '操作',
      interaction: '按当前板块动态展示对应按钮；"发布版本"会二次确认(覆盖线上配置提示)后才真正生效，"保存草稿"不弹确认直接暂存。',
      edge: '"底部导航"板块无发布态，只有重置+保存(saveBottomNav)，因按Web/H5/APP三端各自独立配置、无需统一发布节点。',
    },
    {
      anchor: 'previewToggle',
      name: '预览·折叠/展开',
      group: '操作',
      interaction: '右侧手机预览区把手，点击折叠/展开，折叠后中间编辑区自动扩满。',
    },
  ],
  fields: [
    { name: '分类楼层(homeData)', def: '首页游戏分类楼层的排布与绑定配置。' },
    { name: '顶部导航(headerNav)', def: '页面顶部导航栏的入口配置。' },
    { name: '侧边栏(sidebar)', def: '侧边栏导航入口配置。' },
    { name: '底部导航(bottomNav)', def: '按Web/H5/APP三端各自独立维护的底部导航栏配置。' },
    { name: '轮播横幅(banner)', def: '首页轮播Banner配置。' },
    { name: '公告消息(notice)', def: '首页公告/消息展示配置。' },
    { name: '推广区块(promo)', def: '首页推广位区块配置。' },
    { name: '页脚配置(footer)', def: '页面底部页脚区配置。' },
    { name: '实时数据(realtime)', def: '首页实时数据展示区配置(如在线人数/中奖播报等)。' },
    { name: '配置状态标签', def: '已发布/草稿/存在未保存修改/独立配置/待补版型/待保存/已同步，随当前板块与改动状态展示。' },
  ],
};

export default manual;
