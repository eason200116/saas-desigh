/**
 * SettingConfig - 通用配置组件
 *
 * @example
 * ```vue
 * <template>
 *   <SettingConfig :items="settingItems" :api="settingApi" />
 * </template>
 *
 * <script setup lang="ts">
 * import { SettingConfig, type SettingItemConfig, type SettingApiConfig } from '@/components/SettingConfig';
 *
 * const settingItems: SettingItemConfig[] = [
 *   { key: 'isOpen', type: 'switch', label: '开关', desc: '是否启用' },
 *   { key: 'amount', type: 'number', label: '金额', suffix: '元', rules: [{ min: 0 }] },
 * ];
 *
 * const settingApi: SettingApiConfig = {
 *   get: () => api.module.getConfig(),
 *   update: (params) => api.module.updateConfig(params),
 *   log: (params) => api.operations.getListUpdateLog(params),
 * };
 * </script>
 * ```
 */

export { default as SettingConfig } from './SettingConfig.vue';

export type {
  ControlType,
  SettingRule,
  SettingItemConfig,
  SettingValue,
  SettingLogRecord,
  SettingApiConfig,
  SettingConfigProps,
  SettingConfigExpose,
} from './types';
