import type { VNode } from 'vue';
import type { DataTableColumn, DataTableProps, DataTableRowKey } from 'naive-ui';
import type {
  ProFieldValueType,
  ProComponentType,
  ProValueEnum,
  ProAsyncOptions,
  ProFieldMapping,
  Recordable,
} from './common';

export interface ProTenantTimeZoneDisplayOptions {
  /** 搜索表单中的商户字段，默认 `tenantId` */
  searchTenantIdKey?: string;
  /** 行数据中的商户字段，默认 `tenantId` */
  rowTenantIdKey?: string;
  /** 自定义时间格式，使用 date-fns 格式化模板 */
  format?: string;
}

/** 列导出元数据 */
export type ProColumnExport = false | string | { key: string; title?: string }[];

/**
 * ProDataTable 列定义 (pro-naive-ui 风格)
 */
export interface ProColumn<T extends Recordable = Recordable> extends Omit<
  DataTableColumn<T>,
  'key' | 'render' | 'title'
> {
  /** 列标识 */
  key: keyof T | string;

  /** 列标题 */
  title?: string | (() => VNode);

  /** 自定义列面板展示文案，仅用于列设置等纯文本场景 */
  columnSettingTitle?: string;

  /** 日期类列是否展示商户时区，并按当前商户时区转换数值型时间戳 */
  showTenantTimeZone?: boolean | ProTenantTimeZoneDisplayOptions;

  /** 日期格式化模板 */
  dateFormat?: string;

  /** 数据索引 (key 别名) */
  dataIndex?: keyof T | string;

  /**
   * 导出元数据（驱动 ProCrudTable 自动拼 exportTitle）：
   * - 省略 → 默认按 { 字段名(dataIndex ?? key): 列标题 } 导出
   * - false → 不导出（操作列/选择列/纯展示列）
   * - string → 后端字段名 ≠ 列 key 时写真实字段；标题复用列 title
   * - { key; title? }[] → 复合/嵌套列拆成多列；title 缺省回退列标题
   */
  export?: ProColumnExport;

  /** 值类型 */
  valueType?: ProFieldValueType;

  /** 值枚举映射 */
  valueEnum?: ProValueEnum;

  /** 在表格中隐藏 */
  hideInTable?: boolean;

  /** 在搜索表单中隐藏 */
  hideInSearch?: boolean;

  /** 可复制 */
  copyable?: boolean;

  /** 文本省略 */
  ellipsis?: boolean | { tooltip?: boolean | Recordable; lineClamp?: number };

  /** 可排序（Naive UI DataTableBaseColumn.sortable 兼容：true 默认排序 / 'custom' 由后端托管） */
  sortable?: boolean | 'custom';

  /** 默认排序 */
  defaultSortOrder?: 'ascend' | 'descend' | false;

  /** 可筛选 */
  filterable?: boolean;

  /** 筛选选项 */
  filterOptions?: { label: string; value: any }[];

  /** 默认筛选值 */
  defaultFilterValue?: any;

  /** 列顺序 */
  order?: number;

  /** 条件显示 */
  ifShow?: boolean | ((column: ProColumn<T>) => boolean) | true;

  /** 锁定冻结：列设置面板中不可取消该列的右侧冻结、不可拖拽排序，仅允许显隐（如操作列） */
  lockFixed?: boolean;

  /** 可编辑 */
  editable?: boolean;

  /** 编辑组件 */
  editComponent?: ProComponentType;

  /** 编辑组件属性 */
  editComponentProps?: Recordable;

  /** 编辑验证规则 */
  editRules?: any[];

  /** 编辑选项 */
  editOptions?: ProAsyncOptions;

  /** 编辑选项字段映射 */
  editFieldMapping?: ProFieldMapping;

  /** 自定义编辑渲染 */
  editRender?: (context: ProColumnEditContext<T>) => VNode;

  /**
   * 自定义渲染。
   * 第 4 参 `timezone` 仅当列开启 `showTenantTimeZone` 时由框架按
   * 「搜索栏 → activeTenantId → 行级 tenantId」解析出商户时区（IANA 字符串）
   * 后注入，用于和列标题时区后缀同源，避免行内时间与列标题双轨。
   */
  render?: (
    rowData: T,
    rowIndex: number,
    column: ProColumn<T>,
    timezone?: string,
  ) => VNode | string | number | null;

  /** 标题 tooltip */
  titleTooltip?: string;
}

/**
 * 列编辑上下文
 */
export interface ProColumnEditContext<T extends Recordable = Recordable> {
  row: T;
  rowIndex: number;
  column: ProColumn<T>;
  value: any;
  setValue: (value: any) => void;
  isEditing: boolean;
  save: () => Promise<boolean>;
  cancel: () => void;
}

/**
 * ProDataTable 扩展 Props (pro-naive-ui 风格)
 */
export interface ProDataTableExtendProps<T extends Recordable = Recordable> {
  /** 标题 */
  title?: string;

  /** 标题 tooltip */
  tooltip?: string | string[];

  /** 表格卡片配置 */
  tableCardProps?: Recordable;

  /** 拖拽排序配置 */
  dragSortOptions?: ProTableDragSortOptions<T>;
}

/**
 * ProDataTable Props (继承 DataTableProps)
 */
export interface ProDataTableProps<T extends Recordable = Recordable>
  extends Omit<DataTableProps, 'columns' | 'rowKey'>, ProDataTableExtendProps<T> {
  /** 列定义 */
  columns: ProColumn<T>[];

  /** 当前搜索参数，供列渲染按搜索态联动 */
  searchParams?: Recordable;

  /** 弹性高度 */
  flexHeight?: boolean;

  /** 行键 */
  rowKey?: string | ((row: T) => DataTableRowKey);
}

/**
 * 拖拽排序配置
 */
export interface ProTableDragSortOptions<T extends Recordable = Recordable> {
  /** 动画时长 */
  animation?: number;

  /** 拖拽手柄选择器 */
  handle?: string | boolean;

  /** 拖拽结束回调 */
  onEnd?: (event: { oldIndex: number; newIndex: number }, data: T[]) => void;

  /** 禁用拖拽 */
  disabled?: boolean | ((row: T, index: number) => boolean);
}

/**
 * ProDataTable 实例方法 (pro-naive-ui 风格)
 */
export interface ProDataTableInstance<_T extends Recordable = Recordable> {
  /** 排序 */
  sort: (columnKey: string | null, order: 'ascend' | 'descend' | false) => void;

  /** 翻页 */
  page: (page: number) => void;

  /** 筛选 */
  filter: (filters: Recordable | null) => void;

  /** 获取筛选 */
  filters: (filters: Recordable | null) => void;

  /** 清除排序 */
  clearSorter: () => void;

  /** 清除单个筛选 */
  clearFilter: (columnKey: string) => void;

  /** 清除所有筛选 */
  clearFilters: () => void;

  /** 滚动到 */
  scrollTo: (options: { top?: number; left?: number; row?: number }) => void;

  /** 导出 CSV */
  downloadCsv: (options?: { fileName?: string }) => void;
}

/**
 * 列类型渲染器
 */
export interface ProColumnTypeRenderer<T extends Recordable = any> {
  /** 渲染函数 */
  render: (value: any, row: T, index: number, column: ProColumn<T>) => VNode | string | null;
  /** 默认属性 */
  defaultProps?: Recordable;
  /** 值转换 */
  transform?: (value: any) => any;
}

/**
 * 内置列类型
 */
export type ProColumnType =
  | 'text'
  | 'number'
  | 'money'
  | 'percent'
  | 'date'
  | 'datetime'
  | 'time'
  | 'tag'
  | 'tags'
  | 'status'
  | 'progress'
  | 'image'
  | 'link'
  | 'action'
  | 'boolean'
  | 'code'
  | 'copy'
  | 'index'
  | 'selection'
  | 'expand'
  | 'drag';
