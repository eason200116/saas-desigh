// 渠道管理（商户端 tenant · operations_channelConfig）功能说明书。
// 锚定 src/views/operations/channelConfig/index.vue + ChannelConfigFormModal.vue + data.ts 真实控件（R53 实证、不臆造）。

import type { PageManual } from '../types';

const manual: PageManual = {
  route: 'operations_channelConfig',
  title: '渠道管理',
  overview:
    '商户端「运营管理 › 渠道管理」页，维护推广渠道基础信息（官方渠道/推广渠道两类），域名地址级联取自' +
    '「域名管理」当前商户已配置的域名。支持批量调整"推广链接"开关状态（该操作mock真实生效，是本页唯一' +
    '正确落库的写操作）。' +
    '2026-07-22核实代码发现两处情况：①新增/编辑保存(saveChannelConfig)与删除(deleteChannel)均只返回成功、' +
    '不真正写回底层数组ALL_LIST；②data.ts里还定义了 getChannelDetail(渠道详情查询)和 duplicateChannel(复制' +
    '渠道)两个mock方法，且详情弹窗组件 ChannelDetailModal.vue 也已经建好(含投放埋点/关联活动等详情字段)，但' +
    'index.vue完全没有导入或触发这两者(全仓grep确认零引用)——行操作只有"编辑"1个按钮，没有"详情"或"复制"。' +
    '如实记录，未修复。',
  items: [
    {
      anchor: 'merchant',
      name: '商户',
      group: '搜索',
      interaction: '下拉筛选。',
    },
    {
      anchor: 'keyword',
      name: '渠道ID/渠道名/渠道编码',
      group: '搜索',
      interaction: '文本框，合并单框查询，支持一次输入多个(逗号/空格/换行分隔)，任一关键词命中任一字段即算命中。',
    },
    {
      anchor: 'reset',
      name: '重置',
      group: '搜索',
      interaction: 'ProCrudTable内置重置按钮。',
    },
    {
      anchor: 'act_add',
      name: '新增',
      group: '操作',
      interaction: '主色按钮，点击打开新增弹窗（720px宽）。',
      logic:
        '弹窗字段：商户(单选，编辑态置灰) → 渠道ID(保存后自动生成，只读展示) → 渠道类型(下拉：官方渠道/' +
        '推广渠道) → 渠道名(≤50字) → 渠道编码(留空自动生成，带问号说明规则) → 域名类型(下拉，先选，选项来自' +
        '"域名管理"当前商户已配置的域名类型，未选商户前禁用) → 域名地址(下拉，后选，随域名类型级联，带问号' +
        '说明来源) → 备注 → 状态(开关)。',
    },
    {
      anchor: 'act_batchPromotion',
      name: '批量设置推广链接',
      group: '操作',
      interaction: '需先勾选至少1行才可点击（未勾选置灰，按钮带"新"角标）；点击先弹选择框(开启/关闭二选一)，再弹二次确认。',
      logic: '确认后批量修改勾选行的"是否推广链接"字段——这是本页唯一真实生效写回底层数据的操作。',
    },
    {
      anchor: 'act_edit',
      name: '编辑',
      group: '操作',
      interaction: '每行常驻，点击打开编辑弹窗（字段同新增，回显当前值）。',
    },
  ],
  fields: [
    { name: '商户（列）', def: '该渠道所属商户，标签展示。' },
    { name: '渠道ID', def: '格式CHyyyymmddNNN，全局唯一，新增时自动生成。' },
    { name: '渠道类型', def: '官方渠道(蓝)/推广渠道(橙)。' },
    { name: '渠道名', def: '该渠道的展示名称。' },
    { name: '渠道编码', def: '会员注册归因用的渠道标识码。' },
    { name: '域名地址', def: '该渠道关联的域名URL，取自"域名管理"页当前商户已配置的域名。' },
    { name: '状态', def: '启用(绿)/停用(灰)。' },
    { name: '创建时间', def: '该渠道记录的创建时间。' },
    { name: '创建人', def: '创建该渠道记录的操作人账号。' },
    { name: '最后修改时间', def: '该渠道记录最近一次编辑的时间。' },
    { name: '最后修改人', def: '最近一次编辑该渠道记录的操作人账号。' },
    { name: '备注', def: '补充说明信息，为空展示"--"。' },
  ],
};

export default manual;
