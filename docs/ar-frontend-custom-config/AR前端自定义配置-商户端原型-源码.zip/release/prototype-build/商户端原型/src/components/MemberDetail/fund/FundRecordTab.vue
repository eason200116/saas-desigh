<template>
  <ProCrudTable
    ref="fundTableRef"
    :columns="columns"
    :search-columns="searchColumns"
    :search-initial-values="searchInitialValues"
    :action-column="actionColumn"
    :request="loadData"
    row-key="finanID"
    :search-cols="'1 s:2 m:3 l:4 xl:5 2xl:5'"
    :summary="summary"
    :search-default-collapsed="false"
    :quick-date="{ field: 'timeRange', allowClear: true }"
    :auto-height="false"
    :max-height="tableMaxHeight"
  >
    <template #table-header>
      <ExportButton
        v-permission="['Member:FinanceRecord:Export']"
        :loading="exportLoading"
        @click="handleFundExport"
      />
    </template>
  </ProCrudTable>
</template>

<script setup lang="ts">
  import { computed, inject, type Ref } from 'vue';
  import { ProCrudTable, ExportButton } from '@/components';
  import { useFundRecord } from './useFundRecord';
  import { MEMBER_DETAIL_HAS_HISTORY_BAR } from '../useMemberContext';

  const {
    fundTableRef,
    columns,
    searchColumns,
    searchInitialValues,
    actionColumn,
    summary,
    loadData,
    handleFundExport,
    exportLoading,
  } = useFundRecord();

  const hasHistoryBar = inject<Ref<boolean> | undefined>(MEMBER_DETAIL_HAS_HISTORY_BAR, undefined);
  const tableMaxHeight = computed(() => (hasHistoryBar?.value ? 400 : 440));

  // 模板 ref 绑定，抑制 TS6133 未读警告
  void fundTableRef;
</script>
