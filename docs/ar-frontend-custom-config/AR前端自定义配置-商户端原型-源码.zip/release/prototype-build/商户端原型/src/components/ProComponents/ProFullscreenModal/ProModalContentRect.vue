<!--
/**
 * @description 弹窗内容区几何信息 provider：在弹窗 content slot 外包一层，测量并 provide
 *   LayoutContentRectKey（与 layout/index.vue 同 key），让被嵌入弹窗的 ProCrudTable 等
 *   "撑满父容器"组件 inject 到弹窗的真实可视底，而不是回退到 viewport 兜底。
 *
 *   解决场景：独立页面（如 LotteryTab / 会员银行卡管理）被复用到弹窗内时，原本依赖
 *   layout-content 或 ProTabs 的 ceiling 在弹窗里都 inject 不到，useAutoHeight 走 windowHeight
 *   兜底导致 max-height 算得比弹窗可用高度大，出现底部留白 / 表格被裁。
 *
 *   inject 就近覆盖原理：Vue 的 provide/inject 子组件优先取最近祖先的 provide。
 *   弹窗内容被 Teleport 到 body，从 layout 树脱离，但本 wrapper 在弹窗内 provide 同 key，
 *   于是弹窗内所有 ProCrudTable 优先拿到 wrapper 的 contentRect。
 * @date 2026-05-23
 * @scope src/components/ProComponents/ProFullscreenModal/ProModalContentRect.vue
 */
-->
<template>
  <div ref="rootRef" class="pro-modal-content-rect">
    <slot />
  </div>
</template>

<script setup lang="ts">
  import { onBeforeUnmount, onMounted, provide, ref } from 'vue';
  import { LayoutContentRectKey, type LayoutContentRect } from '@/layout/contentRectContext';

  defineOptions({ name: 'ProModalContentRect' });

  const rootRef = ref<HTMLElement | null>(null);
  const contentRect = ref<LayoutContentRect>({ top: 0, bottom: 0, height: 0 });

  // viewport 底部为弹窗 NCard 留出的安全边距（外 margin + 内 padding-bottom + footer 余量）。
  // 多数 naive-ui modal 默认上下各 5vh 外边距 + NCard padding-bottom 24px，80px 是综合估值。
  // 偏大无副作用（ProCrudTable wrapper 自带 overflow:hidden），偏小才会让表格压到弹窗外。
  const VIEWPORT_BOTTOM_RESERVE = 80;

  function measure() {
    const el = rootRef.value;
    if (!el) return;
    const rect = el.getBoundingClientRect();
    // top 用本 wrapper 真实位置（受 NCard 标题高度影响，但不受 content 高度循环依赖影响）。
    // bottom 不能用 rect.bottom：当 NCard 未显式设 height（DEFAULT_NORMAL_MODAL_STYLE 只设 width）
    // 时，content 区高度依内容撑开，首帧 rect.height ≈ 0 → rect.bottom ≈ rect.top → useAutoHeight
    // 拿到的 ceiling 比 containerTop 还小，actualMaxHeight 坍缩到兜底 200px，表格只显示几行。
    // 改用 viewport - 预留底，让 ceiling 稳定且不受 NCard 内容高度反馈影响。
    const top = rect.top;
    const viewportBottom = window.innerHeight - VIEWPORT_BOTTOM_RESERVE;
    // 兜底：极端情况下 viewportBottom <= top（弹窗超低或被裁剪），至少给 200px 高度避免 ceiling 倒挂
    const bottom = Math.max(viewportBottom, top + 200);
    const next: LayoutContentRect = {
      top,
      bottom,
      height: bottom - top,
    };
    const cur = contentRect.value;
    if (cur.top !== next.top || cur.bottom !== next.bottom || cur.height !== next.height) {
      contentRect.value = next;
    }
  }

  provide(LayoutContentRectKey, { contentRect });

  let resizeObserver: ResizeObserver | null = null;

  onMounted(() => {
    measure();
    if (typeof ResizeObserver !== 'undefined' && rootRef.value) {
      resizeObserver = new ResizeObserver(() => measure());
      // content-box 模式让 padding 变化也能被捕获（防御性，本组件目前无 padding）
      resizeObserver.observe(rootRef.value, { box: 'content-box' });
    }
    window.addEventListener('resize', measure);
  });

  onBeforeUnmount(() => {
    resizeObserver?.disconnect();
    resizeObserver = null;
    window.removeEventListener('resize', measure);
  });
</script>

<style lang="less" scoped>
  // 必须 100% 撑满 NCard__content（弹窗内容区），否则 measure 拿到的是空 div 高度，
  // ceiling 算成 0 反而比 viewport 兜底更糟。
  // display: flex + flex-direction: column 与 NCard__content 的 height: 100% 配合，
  // 让 slot 内容（被嵌组件根 div）拿到完整高度，原本 height:100% / flex:1 写法不破坏。
  .pro-modal-content-rect {
    display: flex;
    flex-direction: column;
    height: 100%;
    min-height: 0;
  }
</style>
