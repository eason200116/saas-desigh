<template>
  <n-select
    v-model:value="modelValue"
    :options="selectOptions"
    :loading="loading"
    v-bind="$attrs"
    @update:value="handleChange"
  >
    <template v-if="$slots.empty" #empty>
      <slot name="empty" />
    </template>
  </n-select>
</template>

<script setup lang="ts">
  import { ref, computed, onMounted, watch } from 'vue';
  import type { SelectOption as NSelectOption } from 'naive-ui';
  import {
    useDictionary,
    preloadDictionary,
    type DictionarySource,
    type DictionaryType,
    type DynamicDictionaryKey,
    type SelectOption,
  } from './useDictionary';

  export type { SelectOption } from './useDictionary';

  export interface FieldMapping {
    label: string;
    value: string;
  }

  /**
   * 三种数据来源（优先级从高到低）：
   *   1. options       静态选项（最高优先级，覆盖 dictKey 与 request）
   *   2. dictKey       字典模式：与 source 配合，自动从 useDictionary 取数据
   *   3. request       自定义异步：兼容旧调用方式，dictKey 启用时该 prop 失效
   *
   * 字典模式案例：
   *   <AsyncSelect dict-key="thirdPayMerchantList" source="dynamic" v-model:value="merchantId" />
   */
  interface Props {
    /** 字典 key（与 source 配合，自动从 useDictionary 拉取 options） */
    dictKey?: DictionaryType;
    /** 字典源（dictKey 启用时生效），默认沿用 useDictionary 的 'common' */
    source?: DictionarySource;
    /** 字段映射覆盖（dictKey 模式下可定制；不传则走 useDictionary 的候选探测） */
    labelField?: string;
    valueField?: string;

    /** 自定义异步请求（与 dictKey 互斥，dictKey 优先） */
    request?: () => Promise<{ data: any[] }>;
    /** 静态选项（最高优先级，覆盖 dictKey 与 request） */
    options?: SelectOption[];
    /** request 模式专用：响应字段映射 */
    fieldMapping?: FieldMapping;
    /** request 模式专用：响应数据自定义转换 */
    transform?: (data: any[]) => SelectOption[];
    /** 挂载时立即触发 request（仅 request 模式生效；dictKey 模式由字典内部控制） */
    immediate?: boolean;
  }

  const props = withDefaults(defineProps<Props>(), {
    source: 'common',
    immediate: true,
  });

  const emit = defineEmits<{
    change: [
      value: string | number | string[] | number[] | null,
      option: SelectOption | SelectOption[] | null,
    ];
  }>();

  const modelValue = defineModel<string | number | string[] | number[] | null>();

  // 字典模式：useDictionary 内部处理 dynamic 源的懒加载与缓存
  const dict = useDictionary({ source: props.source });
  const dictOptions = computed<SelectOption[]>(() => {
    if (!props.dictKey) return [];
    const raw = dict.getOptions(props.dictKey, {
      source: props.source,
      labelField: props.labelField,
      valueField: props.valueField,
    });
    // dict-key 与 transform 组合：transform 接收的是已拼成 SelectOption 的项（保留了原始字段 spread），
    // 用于"前端再处理"场景（如本地 i18n 覆盖 label）
    return props.transform ? props.transform(raw) : raw;
  });

  // 自定义 request 模式（保留向后兼容）
  const remoteOptions = ref<SelectOption[]>([]);
  const loading = ref(false);
  const error = ref<Error | null>(null);

  // 优先级：options > dictKey > remoteOptions
  const computedOptions = computed<SelectOption[]>(() => {
    if (props.options) return props.options;
    if (props.dictKey) return dictOptions.value;
    return remoteOptions.value;
  });
  const selectOptions = computed<NSelectOption[]>(() => computedOptions.value as NSelectOption[]);

  const fetchOptions = async () => {
    if (!props.request || props.dictKey) return; // dictKey 模式不走 request
    loading.value = true;
    error.value = null;
    try {
      const response = await props.request();
      const data = response.data ?? [];
      if (props.transform) {
        remoteOptions.value = props.transform(data);
      } else if (props.fieldMapping) {
        const { label, value } = props.fieldMapping;
        remoteOptions.value = data.map((item) => ({
          label: item[label],
          value: item[value],
          ...item,
        }));
      } else {
        remoteOptions.value = data;
      }
    } catch (err) {
      error.value = err as Error;
      console.error('[AsyncSelect] fetch error:', err);
    } finally {
      loading.value = false;
    }
  };

  const handleChange = (value: string | number | string[] | number[] | null) => {
    if (Array.isArray(value)) {
      const set = new Set(value.map((v) => String(v)));
      emit(
        'change',
        value,
        computedOptions.value.filter((it) => set.has(String(it.value))),
      );
      return;
    }
    const opt = computedOptions.value.find((it) => it.value === value) ?? null;
    emit('change', value, opt);
  };

  const refresh = () => fetchOptions();

  // dynamic 源的 dict-key：mount 时显式 preload 避免依赖 computed lazy 触发时机
  function ensureDictPreloaded() {
    if (props.dictKey && props.source === 'dynamic') {
      void preloadDictionary([props.dictKey as DynamicDictionaryKey]);
    }
  }

  onMounted(() => {
    if (props.immediate && props.request && !props.dictKey) fetchOptions();
    ensureDictPreloaded();
  });

  watch(
    () => [props.request, props.dictKey, props.source] as const,
    ([req, dk]) => {
      if (req && !dk) fetchOptions();
      ensureDictPreloaded();
    },
  );

  defineExpose({
    options: computedOptions,
    loading,
    error,
    refresh,
  });
</script>
