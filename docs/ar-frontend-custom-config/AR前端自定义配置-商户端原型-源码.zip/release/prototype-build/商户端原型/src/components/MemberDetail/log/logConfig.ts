import { h } from 'vue';
import { NTag } from 'naive-ui';
import { renderRichText, type ProColumn } from '@/components';
import {
  operationPathParts,
  moduleLabel,
  loginPathLabel,
  bizLabel,
  bizPath,
} from '@/views/system/platformLog/data';

/**
 * 会员系统日志 —— 搜索列配置。
 * 对齐系统管理-系统日志（src/views/system/platformLog）：操作路径(级联) + 关键字 + 操作时间；
 * 去商户维度（会员详情商户已锁定）。列序按目标站系统日志（R44/R60）。
 */
export function createLogSearchColumns(t: (key: string) => string, operationPathOptions: any[]) {
  return [
    // 操作路径：模块 → 操作页面 → 操作控件 合并为一个级联筛选，可选到任一级（含「（全部）」按模块/页面整体筛）。
    {
      path: 'operationPath',
      label: t('system.platformLog.operationPath'),
      valueType: 'cascader' as const,
      options: operationPathOptions,
      componentProps: {
        clearable: true,
        // 可输入搜索 + 模糊匹配：关键词命中 模块/页面/控件 路径任一层即展示（不区分大小写）。
        filterable: true,
        filter: (pattern: string, _option: any, path: any[]) =>
          path.some((o) =>
            String(o?.label ?? '')
              .toLowerCase()
              .includes(String(pattern).trim().toLowerCase()),
          ),
        placeholder: t('system.platformLog.selectOperationPath'),
        // 单选叶子（选「（全部）」叶子即按 模块/页面 整体筛）；非叶子仅展开下一级。
        checkStrategy: 'child',
        virtualScroll: false,
        menuProps: { class: 'platlog-op-cascader-menu' },
        themeOverrides: {
          columnWidth: '320px',
          menuHeight: 'calc(var(--n-option-height) * 12)',
        },
      },
    },
    {
      path: 'keyWords',
      label: t('system.platformLog.keyword'),
      valueType: 'text' as const,
      componentProps: {
        clearable: true,
        placeholder: t('system.platformLog.keywordPlaceholder'),
      },
    },
    {
      path: 'timeRange',
      label: t('common.operationTime'),
      valueType: 'proDateRange' as const,
      order: 99,
      span: 2,
      componentProps: {
        valueFormat: 'string',
        displayFormat: 'yyyy-MM-dd HH:mm:ss',
        maxDays: 180,
        allowFuture: false,
        shortcuts: false,
        showTime: true,
        // 展平写回：起 → form.startTime，止 → form.endTime
        modelKeys: ['startTime', 'endTime'],
      },
    },
  ];
}

/**
 * 会员系统日志 —— 表格列配置。
 * 对齐系统管理-系统日志：操作路径(模块›页面›控件+类型标签) / 操作内容 / 关键词 / 操作人 / 操作时间；
 * 去商户列（会员详情商户已锁定）；其余(IP/所在地/系统/浏览器/状态)收入「详情」弹窗（Info.vue）。
 */
export function createLogColumns(t: (key: string) => string, locale: string): ProColumn[] {
  return [
    {
      // 操作路径：模块(标签) › 页面 › 控件 + 类型(标签)；登录日志显示「后台登录」标签。换行完整展示(R41 居左)
      key: 'operationPath',
      title: t('system.platformLog.operationPath'),
      width: 360,
      align: 'left',
      titleAlign: 'center',
      render: (row) => {
        const p = operationPathParts(row as any);
        if (p.isLogin) {
          return h(
            NTag,
            { size: 'small', type: 'warning', bordered: false },
            { default: () => loginPathLabel(t) },
          );
        }
        const sep = () => h('span', { style: 'color:#c0c4cc;margin:0 2px;' }, '›');
        const nodes = [
          h(
            NTag,
            { size: 'small', type: 'info', bordered: false },
            { default: () => moduleLabel(p.module, t) },
          ),
          sep(),
          h('span', { style: 'color:#606266;' }, bizPath(p.location, locale)),
        ];
        // 2026-07-16 用户要求：控件后不再跟「控件类型」绿色 Tag，只显控件名（与筛选级联/详情弹窗统一口径）
        if (p.control) {
          nodes.push(
            sep(),
            h('span', { style: 'color:#1f2329;font-weight:500;' }, bizLabel(p.control, locale)),
          );
        }
        return h(
          'div',
          { style: 'display:flex;align-items:center;flex-wrap:wrap;gap:2px 4px;line-height:1.7;' },
          nodes,
        );
      },
    },
    {
      // 操作内容：完整展示（不截断、自动换行）；含后端 HTML 编码片段时 renderRichText 解码消毒
      key: 'logInfo',
      title: t('system.platformLog.operationContent'),
      width: 320,
      align: 'left',
      titleAlign: 'center',
      render: (row) =>
        h('div', { style: 'white-space:normal;word-break:break-word;line-height:1.5;' }, [
          renderRichText((row as any).logInfo, { html: true }),
        ]),
    },
    {
      // 关键词：本条操作的关键标识/简称
      key: 'keyword',
      title: t('system.platformLog.keywordColumn'),
      width: 150,
      align: 'left',
      titleAlign: 'center',
      ellipsis: { tooltip: true },
      render: (row) => (row as any).logTitle || '-',
    },
    {
      key: 'userName',
      title: t('system.platformLog.operator'),
      width: 160,
      ellipsis: { tooltip: true },
    },
    {
      key: 'logDateStr',
      title: t('common.operationTime'),
      width: 180,
      showTenantTimeZone: true,
    },
    // 其余字段（用户IP/所在地、系统、浏览器、状态、变更详情等）收入「详情」弹窗，见 system/platformLog/components/Info.vue
  ];
}
