<template>
  <n-el
    tag="div"
    class="zoned-date-range-panel relative my-1 w-fit min-w-[600px] rounded bg-[var(--card-color)] text-[var(--text-color)]"
  >
    <span
      class="pointer-events-none absolute right-3 -top-[8px] z-10 text-sm leading-4 text-[var(--primary-color)]"
      :title="timezoneDisplay"
    >
      {{ timezoneOffsetDisplay }}
    </span>
    <div
      v-if="showTime"
      class="flex w-full items-center justify-between gap-2 border-b border-[var(--border-color)] py-2"
    >
      <n-input
        :value="startDateText"
        readonly
        size="small"
        class="min-w-0 flex-1"
        :placeholder="t('common.dateRange.placeholder')"
      />
      <ZonedTimeFields
        :value="draft.start"
        :timezone-id="timezoneId"
        @update:value="handleStartTimeUpdate"
      />
      <n-input
        :value="endDateText"
        readonly
        size="small"
        class="min-w-0 flex-1"
        :placeholder="t('common.dateRange.placeholder')"
      />
      <ZonedTimeFields
        :value="draft.end"
        :timezone-id="timezoneId"
        @update:value="handleEndTimeUpdate"
      />
    </div>

    <div class="grid justify-center [grid-template-columns:auto_1px_auto]">
      <ZonedCalendarGrid
        :year="leftMonth.year"
        :month="leftMonth.month"
        :timezone-id="timezoneId"
        :selected-start="draft.start"
        :selected-end="draft.end"
        :hovered-date="hoveredDate"
        :disabled-date="isDateDisabled"
        :allow-future="allowFuture"
        @prev-year="goLeftPrevYear"
        @prev="goLeftPrevMonth"
        @next="goLeftNextMonth"
        @next-year="goLeftNextYear"
        @select="handleDateSelect"
        @hover-date="handleHoverDate"
        @jump-to="goLeftJumpTo"
      />
      <div class="w-px bg-[var(--divider-color)]" />
      <ZonedCalendarGrid
        :year="rightMonth.year"
        :month="rightMonth.month"
        :timezone-id="timezoneId"
        :selected-start="draft.start"
        :selected-end="draft.end"
        :hovered-date="hoveredDate"
        :disabled-date="isDateDisabled"
        :allow-future="allowFuture"
        @prev-year="goRightPrevYear"
        @prev="goRightPrevMonth"
        @next="goRightNextMonth"
        @next-year="goRightNextYear"
        @select="handleDateSelect"
        @hover-date="handleHoverDate"
        @jump-to="goRightJumpTo"
      />
    </div>

    <div
      class="flex items-center justify-between gap-3 border-t border-[var(--border-color)] px-4 pt-2"
    >
      <ProQuickDateButtons
        v-if="currentShortcuts.length"
        :shortcuts="currentShortcuts"
        :model-value="activeShortcutIndex"
        size="tiny"
        secondary
        class="min-w-0 flex-1"
        @select="(_, item) => handleShortcut(item)"
      />
      <div class="ml-auto flex flex-none items-center gap-2">
        <span
          v-if="errorMessage"
          class="max-w-[220px] truncate text-xs text-[var(--error-color)]"
          >{{ errorMessage }}</span
        >
        <n-button size="small" @click="handleReset">{{ t('common.dateRange.reset') }}</n-button>
        <n-button type="primary" size="small" :disabled="!!errorMessage" @click="handleConfirm">
          {{ t('common.dateRange.confirm') }}
        </n-button>
      </div>
    </div>
  </n-el>
</template>

<script setup lang="ts">
  import { computed, toRef } from 'vue';
  import { useI18n } from 'vue-i18n';
  import { NButton, NEl, NInput } from 'naive-ui';
  import ProQuickDateButtons from '../ProQuickDateButtons.vue';
  import type { ProDateRangePickerProps } from '../../types';
  import { useZonedDateRange } from '../composables/useZonedDateRange';
  import { formatParts, formatUtcMsInZone } from '../utils/zonedDateMath';
  import ZonedCalendarGrid from './ZonedCalendarGrid.vue';
  import ZonedTimeFields from './ZonedTimeFields.vue';

  defineOptions({ name: 'ZonedDateRangePanel' });

  const props = withDefaults(defineProps<ProDateRangePickerProps>(), {
    value: null,
    valueFormat: 'timestamp',
    valueStringPattern: 'yyyy-MM-dd HH:mm:ss',
    timezone: null,
    maxDays: 31,
    allowFuture: false,
    shortcuts: undefined,
    shortcutPreset: 'default',
    showTime: true,
    bindCalendarMonths: false,
    defaultTime: undefined,
  });

  const emit = defineEmits<{
    'update:value': [value: [number, number] | [string, string] | null];
    confirm: [value: [number, number] | [string, string]];
    reset: [];
  }>();

  const { t } = useI18n();

  const {
    draft,
    hoveredDate,
    errorMessage,
    timezoneId,
    leftMonth,
    rightMonth,
    currentShortcuts,
    activeShortcutIndex,
    goLeftPrevYear,
    goLeftPrevMonth,
    goLeftNextMonth,
    goLeftNextYear,
    goRightPrevYear,
    goRightPrevMonth,
    goRightNextMonth,
    goRightNextYear,
    goLeftJumpTo,
    goRightJumpTo,
    handleDateSelect,
    handleHoverDate,
    handleStartTimeUpdate,
    handleEndTimeUpdate,
    handleShortcut,
    handleReset,
    handleConfirm,
    isDateDisabled,
  } = useZonedDateRange({
    value: toRef(props, 'value'),
    valueFormat: toRef(props, 'valueFormat'),
    valueStringPattern: toRef(props, 'valueStringPattern'),
    timezone: toRef(props, 'timezone'),
    showTime: toRef(props, 'showTime'),
    maxDays: toRef(props, 'maxDays'),
    allowFuture: toRef(props, 'allowFuture'),
    shortcuts: toRef(props, 'shortcuts'),
    shortcutPreset: toRef(props, 'shortcutPreset'),
    bindCalendarMonths: toRef(props, 'bindCalendarMonths'),
    defaultTime: toRef(props, 'defaultTime'),
    onUpdateValue: (value) => emit('update:value', value),
    onConfirm: (value) => emit('confirm', value),
    onReset: () => emit('reset'),
  });

  const startDateText = computed(() =>
    draft.value.start ? formatParts(draft.value.start, 'yyyy-MM-dd') : '',
  );
  const endDateText = computed(() =>
    draft.value.end ? formatParts(draft.value.end, 'yyyy-MM-dd') : '',
  );
  const timezoneOffsetDisplay = computed(() => {
    const offset = formatUtcMsInZone(Date.now(), timezoneId.value, 'XXX');
    return offset === 'Z' ? 'UTC+00:00' : `UTC${offset}`;
  });
  const timezoneDisplay = computed(() => `${timezoneOffsetDisplay.value} ${timezoneId.value}`);
</script>
