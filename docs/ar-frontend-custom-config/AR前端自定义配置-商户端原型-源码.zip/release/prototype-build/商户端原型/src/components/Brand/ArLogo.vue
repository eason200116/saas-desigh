<template>
  <span class="ar-logo" :style="sizeStyle" v-html="logoSvg" />
</template>

<script lang="ts" setup>
  import { computed } from 'vue';
  import { useProjectSettingStore } from '@/store/modules';
  import { BRAND_HEIGHT, BRAND_WIDTH, createBrandSvgMarkup } from './svg';

  let logoIdSeed = 0;

  const props = withDefaults(
    defineProps<{
      size?: number | string;
      color?: string;
      decorative?: boolean;
      label?: string;
    }>(),
    {
      size: 32,
      decorative: true,
      label: 'AR',
    },
  );

  const projectStore = useProjectSettingStore();
  const instanceId = `ar-logo-${logoIdSeed++}`;

  const sizeStyle = computed(() => ({
    aspectRatio: `${BRAND_WIDTH} / ${BRAND_HEIGHT}`,
    height: formatSize(props.size),
  }));

  const logoSvg = computed(() =>
    createBrandSvgMarkup({
      decorative: props.decorative,
      idPrefix: instanceId,
      isDark: false,
      label: props.label,
      themeColor: props.color || projectStore.appearance.themeColor,
    }),
  );

  function formatSize(size: number | string) {
    return typeof size === 'number' ? `${size}px` : size;
  }
</script>

<style lang="less" scoped>
  .ar-logo {
    display: block;
    flex: none;
    line-height: 0;
  }

  .ar-logo ::v-deep(svg) {
    display: block;
    width: 100%;
    height: 100%;
    overflow: visible;
  }
</style>
