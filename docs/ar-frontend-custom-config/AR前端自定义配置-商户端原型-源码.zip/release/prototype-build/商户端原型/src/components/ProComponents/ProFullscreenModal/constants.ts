/**
 * @description ProFullscreenModal 共享常量：全屏 / 常态弹窗样式预设。业务层可直接引用，避免在多处重复定义 100vw/100vh 全屏样式与默认常态宽度。
 * @date 2026-05-08
 * @scope src/components/ProComponents/ProFullscreenModal
 */

import type { CSSProperties } from 'vue';

/**
 * 全屏样式：100vw × 100vh，移除外边距与圆角，铺满整个视口。
 * 与 records/workbench 历史本地常量等价，统一为单一来源。
 */
export const MODAL_FULLSCREEN_STYLE: CSSProperties = {
  width: '100vw',
  height: '100vh',
  maxWidth: '100vw',
  margin: '0',
  borderRadius: '0',
};

/**
 * 默认常态样式（业务方未传 normalStyle 时使用）。
 * 1100px 取 records/workbench(1410)、dailyStats(1500)、orderDetail(1600) 的中位数下偏，
 * 适合多数详情弹窗；业务方有特定宽度诉求时通过 normalStyle 覆盖即可。
 */
export const DEFAULT_NORMAL_MODAL_STYLE: CSSProperties = {
  width: 'min(1100px, 95vw)',
};
