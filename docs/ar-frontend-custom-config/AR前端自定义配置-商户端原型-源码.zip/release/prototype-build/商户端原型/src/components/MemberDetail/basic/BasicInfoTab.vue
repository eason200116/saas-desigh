<template>
  <div class="detail-sections" :class="{ 'detail-sections--onepage': detailData.basicOnePage }">
    <div
      v-for="section in detailData.basicSections"
      :key="section.key"
      class="detail-section"
      :class="{ 'detail-section--wide': section.wide, 'detail-section--keep-next': section.groupNext }"
    >
      <div class="detail-section__header">
        <h4 class="detail-section__title">
          {{ section.title }}
          <!-- 迁移期「新」分区标识，受 NEW_MARK_ENABLED 控制（buildDetailData 写入 isNew） -->
          <span v-if="section.isNew" class="ar-newmark">新</span>
          <!-- 「归因介绍」收成注册信息标题旁的「?」，点击弹气泡完整展示归因脉络（2026-07-14 用户要求·仅样板 1100002）。
               气泡给足宽度(920)让 5 张步骤卡完整横排不被裁切；内容过高时整体纵向滚动（scrollable + maxHeight）。 -->
          <n-popover
            v-if="section.funnel && detailData.basicOnePage"
            trigger="click"
            placement="bottom-start"
            :width="920"
            scrollable
            :style="{ maxHeight: '72vh' }"
          >
            <template #trigger>
              <span class="detail-cell__help detail-cell__help--click">?</span>
            </template>
            <div class="detail-funnel-pop__title">{{ section.funnel.title }}</div>
            <AttributionFunnel :data="section.funnel.data" />
          </n-popover>
        </h4>
        <!-- 头部开关按钮（是否领取返佣 / 是否对上级返佣） -->
        <div v-if="section.headerSwitches" class="detail-section__switches">
          <span v-for="sw in section.headerSwitches" :key="sw.key" class="detail-section__switch">
            <span class="detail-section__switch-label">{{ sw.label }}</span>
            <n-switch
              :value="sw.value"
              size="small"
              @update:value="(v) => handleToggleSwitch(sw, v)"
            />
          </span>
        </div>
        <!-- 头部右侧说明（如「最后3次登录」的同IP登录数合计）；带 headerNoteJump 时可点击跳列表 -->
        <a
          v-if="section.headerNote && section.headerNoteJump"
          class="detail-section__note detail-cell__link"
          @click="handleJumpMemberList({ jumpQuery: section.headerNoteJump })"
          >{{ section.headerNote }}</a
        >
        <span v-else-if="section.headerNote" class="detail-section__note">{{
          section.headerNote
        }}</span>
      </div>

      <!-- 打码进度行（打码/洗码版块，独占一行）：已完成打码量/需要打码量 X/Y +「修改」(编辑需要打码量) + 进度条 + 达标/未达标；
           进度=已完成÷需要；改需要打码量后进度条(详情+列表)联动。R49 随内容自适应 -->
      <div
        v-if="section.progress"
        class="detail-code-prog"
        :class="{ 'detail-code-prog--stacked': detailData.basicOnePage }"
      >
        <div class="detail-code-prog__nums">
          <div class="detail-code-prog__numsleft">
            <span class="detail-code-prog__names">
            {{ section.progress.doneLabel }}
            <n-tooltip v-if="section.progress.doneTip" trigger="hover" placement="top">
              <template #trigger><span class="detail-cell__help">?</span></template>
              {{ section.progress.doneTip }}
            </n-tooltip>
            /
            {{ section.progress.needLabel }}
            <n-tooltip v-if="section.progress.needTip" trigger="hover" placement="top">
              <template #trigger><span class="detail-cell__help">?</span></template>
              {{ section.progress.needTip }}
            </n-tooltip>
          </span>
            <span class="detail-code-prog__value"
              >{{ section.progress.done }} / {{ section.progress.need }}</span
            >
          </div>
          <n-button
            v-if="section.progress.editActionKey"
            class="detail-code-prog__edit"
            type="primary"
            ghost
            size="small"
            @click="
              handleItemAction(section.key, {
                actionKey: section.progress.editActionKey,
                value: section.progress.need,
              })
            "
          >
            {{ section.progress.editLabel }}
          </n-button>
          <!-- 操作记录入口（仅样板 1100002）：紧跟「需要打码量·修改」按钮右侧 -->
          <MemberOpLogPopover
            v-if="section.progress.editOpLog"
            :page="section.progress.editOpLog.page"
            :item="section.progress.editOpLog.item"
          />
        </div>
        <div class="detail-code-prog__bar">
          <div class="code-prog" :class="{ 'code-prog--done': section.progress.reached }">
            <div class="code-prog__fill" :style="{ width: section.progress.pct + '%' }"></div>
            <span class="code-prog__pct">{{ section.progress.pct }}%</span>
          </div>
          <span
            class="code-badge"
            :class="section.progress.reached ? 'code-badge--done' : 'code-badge--todo'"
            >{{
              section.progress.reached
                ? section.progress.reachedText
                : section.progress.unreachedText
            }}</span
          >
        </div>
      </div>

      <!-- 路径图 / 流程图（归因链路、代理关系链）；代理链可点击查看逐级详情。
           「点击查看逐级详情」链接移到下方「代理明细」折叠头右侧，与其同行对齐 -->
      <MemberChain
        v-if="section.chain"
        :nodes="section.chain"
        :compact="detailData.basicOnePage"
        :clickable="!!(section.agentLine && section.agentLine.length)"
        @view="handleViewAgentLine(section)"
      />

      <div
        v-if="section.items && section.items.length"
        class="detail-grid"
        :style="{ gridTemplateColumns: `repeat(${section.columns}, minmax(0, 1fr))` }"
      >
        <template v-for="(item, idx) in section.items" :key="item.label || `sub-${idx}`">
          <div
            v-if="item.subHeader"
            class="detail-grid__subheader"
            :style="{ gridColumn: '1 / -1' }"
            >{{ item.subHeader }}</div
          >
          <!-- 复合格：左值(上下) + 右侧「同登录X数」计数(可下钻)，非独立列（会员风控最后3次登录） -->
          <div
            v-else-if="item.sameCount"
            class="detail-cell detail-cell--compound"
            :style="item.span ? { gridColumn: `span ${item.span}` } : undefined"
          >
            <div class="detail-cell__main">
              <span class="detail-cell__label">{{ item.label }}</span>
              <span class="detail-cell__value">{{ item.value }}</span>
            </div>
            <div class="detail-cell__side">
              <span class="detail-cell__side-label">{{ item.sameCount.label }}</span>
              <a
                v-if="item.sameCount.jumpQuery"
                class="detail-cell__side-value detail-cell__link"
                @click="handleJumpMemberList(item.sameCount)"
                >{{ item.sameCount.value }}</a
              >
              <span v-else class="detail-cell__side-value">{{ item.sameCount.value }}</span>
            </div>
          </div>
          <div
            v-else
            class="detail-cell"
            :class="{ 'detail-cell--stack': item.stack, 'detail-cell--switch': item.itemSwitch }"
            :style="item.span ? { gridColumn: `span ${item.span}` } : undefined"
          >
            <span class="detail-cell__label">
              {{ item.label }}
              <span v-if="item.isNew" class="ar-newmark">新</span>
              <span v-if="item.changed" class="ar-changemark">改</span>
              <n-tooltip v-if="item.tip" trigger="hover" placement="top">
                <template #trigger>
                  <span class="detail-cell__help">?</span>
                </template>
                {{ item.tip }}
              </n-tooltip>
            </span>
            <span
              class="detail-cell__value"
              :class="[
                item.highlight ? `highlight--${item.highlight}` : '',
                item.highlightBold ? 'highlight--bold' : '',
                item.ellipsis ? 'detail-cell__value--fill' : '',
              ]"
            >
              <span
                v-if="item.html"
                :class="{ 'detail-html-ellipsis': item.ellipsis }"
                v-html="getSafeHtml(String(item.displayValue ?? item.value ?? ''))"
              ></span>
              <a v-else-if="item.link" class="detail-cell__link" @click="handleViewInviter(item)">{{
                item.value
              }}</a>
              <!-- 同IP/同设备人数 → 点击跳会员列表下钻 -->
              <a
                v-else-if="item.jumpQuery"
                class="detail-cell__link"
                @click="handleJumpMemberList(item)"
                >{{ item.value }}</a
              >
              <!-- 会员状态：直接开关（R47），点击 → 二次确认 → 切换 -->
              <span
                v-else-if="item.stateSwitch"
                style="display: inline-flex; align-items: center; gap: 8px"
              >
                <n-switch
                  :value="item._userState === 1"
                  size="small"
                  @update:value="(v) => handleToggleState(item, v)"
                />
                <span>{{ item.value }}</span>
              </span>
              <!-- 行内开关（是否领取返佣 / 是否对上级返佣，R47）：点击 → 二次确认 → 切换 -->
              <span
                v-else-if="item.itemSwitch"
                style="display: inline-flex; align-items: center; gap: 8px"
              >
                <n-switch
                  :value="item.switchValue"
                  size="small"
                  @update:value="(v) => handleToggleSwitch({ label: item.label, value: item.switchValue }, v)"
                />
              </span>
              <template v-else>{{ item.value }}</template>
              <span
                v-if="item.timeZoneLabel"
                style="
                  font-size: 12px;
                  font-weight: 400;
                  color: #999;
                  margin-left: 4px;
                  flex-shrink: 0;
                "
                >({{ item.timeZoneLabel }})</span
              >
              <n-button
                v-if="item.actionKey"
                type="primary"
                ghost
                size="small"
                style="margin-left: auto; flex-shrink: 0"
                @click="handleItemAction(section.key, item)"
              >
                {{ item.actionLabel }}
              </n-button>
              <!-- 操作记录入口（仅样板 1100002，由 buildDetailData 写 item.opLog 门控）：紧跟控件/「修改」按钮右侧 -->
              <MemberOpLogPopover
                v-if="item.opLog"
                :page="item.opLog.page"
                :item="item.opLog.item"
              />
            </span>
          </div>
        </template>
      </div>

      <!-- 会员风控·注册风控卡 + 最后3次登录卡（方案3 竖版分组卡片，仅样板1100002）：注册聚合3行 & 每次登录各一张卡，套同款卡片样式；「最后3次登录信息」小标题已删 -->
      <template v-if="section.registerCard || (section.loginGroups && section.loginGroups.length)">
        <!-- 注册风控卡：与「最后N次登录卡」同构——卡头 标题+注册时间；每行 注册IP/设备/指纹的值 + 同X注册数（可下钻风控页） -->
        <div v-if="section.registerCard" class="detail-login-card">
          <div class="detail-login-card__head">
            <span class="detail-login-card__seq">{{ section.registerCard.title }}</span>
            <span v-if="section.registerCard.time" class="detail-login-card__time"
              >{{ section.registerCard.time
              }}<span v-if="section.registerCard.timeZoneLabel" class="detail-login-card__tz">{{
                section.registerCard.timeZoneLabel
              }}</span></span
            >
          </div>
          <div class="detail-login-card__body">
            <div
              v-for="(r, ri) in section.registerCard.rows"
              :key="`rc-${ri}`"
              class="detail-login-card__row"
            >
              <span class="detail-login-card__label">{{ r.label }}</span>
              <span class="detail-login-card__val">
                <span class="detail-login-card__v">{{ r.value }}</span>
                <!-- 「同X数」组（2026-07-16 用户确认）：整组居右；>1 可点下钻、≤1 纯文本；「·」分隔点随居右取消 -->
                <span v-if="r.count" class="detail-login-card__same">
                  <span class="detail-login-card__clabel">{{ r.count.label }}</span>
                  <a
                    v-if="r.count.jumpQuery"
                    class="detail-login-card__cnt detail-cell__link"
                    @click="handleJumpMemberList(r.count)"
                    >{{ r.count.value }}</a
                  >
                  <span v-else class="detail-login-card__cnt">{{ r.count.value }}</span>
                </span>
              </span>
            </div>
          </div>
        </div>
        <div v-for="(g, gi) in section.loginGroups" :key="`lg-${gi}`" class="detail-login-card">
          <div class="detail-login-card__head">
            <span class="detail-login-card__seq">{{ g.seq }}</span>
            <span class="detail-login-card__time"
              >{{ g.time
              }}<span v-if="g.timeZoneLabel" class="detail-login-card__tz">{{
                g.timeZoneLabel
              }}</span></span
            >
          </div>
          <div class="detail-login-card__body">
            <div
              v-for="(r, ri) in g.rows"
              :key="`lgr-${gi}-${ri}`"
              class="detail-login-card__row"
            >
              <span class="detail-login-card__label">{{ r.label }}</span>
              <span class="detail-login-card__val">
                <span class="detail-login-card__v">{{ r.value }}</span>
                <!-- 「同X数」组（2026-07-16 用户确认）：整组居右；>1 可点下钻、≤1 纯文本；「·」分隔点随居右取消 -->
                <span v-if="r.count" class="detail-login-card__same">
                  <span class="detail-login-card__clabel">{{ r.count.label }}</span>
                  <a
                    v-if="r.count.jumpQuery"
                    class="detail-login-card__cnt detail-cell__link"
                    @click="handleJumpMemberList(r.count)"
                    >{{ r.count.value }}</a
                  >
                  <span v-else class="detail-login-card__cnt">{{ r.count.value }}</span>
                </span>
              </span>
            </div>
          </div>
        </div>
      </template>

      <!-- 归因脉络漏斗（注册信息·归因段）：样板1100002 改由版块标题旁「?」点击弹气泡完整展示（见上方 n-popover，
           2026-07-14 用户要求·撤销 07-13 的内联常展开）；非样板仍 n-collapse 可折叠、不受影响 -->
      <n-collapse
        v-if="section.funnel && !detailData.basicOnePage"
        class="detail-collapse"
        :default-expanded-names="[]"
      >
        <n-collapse-item :title="section.funnel.title" name="funnel">
          <AttributionFunnel :data="section.funnel.data" />
        </n-collapse-item>
      </n-collapse>

      <!-- 代理明细：常展开、无收缩按钮（原 n-collapse 折叠改静态；标题行右侧保留「点击查看逐级详情」） -->
      <div v-if="section.collapsible" class="detail-collapse detail-collapse--static">
        <div
          class="detail-collapse__bar"
          :class="{ 'detail-collapse__bar--nolabel': detailData.basicOnePage }"
        >
          <!-- 「代理明细」标题文案：一页看完视图(1100002)隐藏，仅保留右侧「点击查看逐级详情」链接 -->
          <span v-if="!detailData.basicOnePage" class="detail-collapse__title">{{
            section.collapsible.label
          }}</span>
          <a
            v-if="section.agentLine && section.agentLine.length"
            class="detail-cell__link"
            @click.stop="handleViewAgentLine(section)"
            >{{ section.chainHint }}</a
          >
        </div>
        <div
          class="detail-grid"
          :style="{
            gridTemplateColumns: `repeat(${section.collapsible.columns}, minmax(0, 1fr))`,
          }"
        >
          <template
            v-for="(item, idx) in section.collapsible.items"
            :key="item.label || `csub-${idx}`"
          >
            <div
              v-if="item.subHeader"
              class="detail-grid__subheader"
              :style="{ gridColumn: '1 / -1' }"
              >{{ item.subHeader }}</div
            >
            <div v-else class="detail-cell" :class="{ 'detail-cell--switch': item.itemSwitch }">
              <span class="detail-cell__label">
                {{ item.label }}
                <span v-if="item.isNew" class="ar-newmark">新</span>
                <span v-if="item.changed" class="ar-changemark">改</span>
              </span>
              <span
                class="detail-cell__value"
                :class="[item.highlight ? `highlight--${item.highlight}` : '']"
              >
                <span
                  v-if="item.html"
                  v-html="getSafeHtml(String(item.displayValue ?? item.value ?? ''))"
                ></span>
                <!-- 行内开关（是否领取返佣 / 是否对上级返佣，R47）：折叠区也需渲染开关 -->
                <span
                  v-else-if="item.itemSwitch"
                  style="display: inline-flex; align-items: center; gap: 8px"
                >
                  <n-switch
                    :value="item.switchValue"
                    size="small"
                    @update:value="
                      (v) => handleToggleSwitch({ label: item.label, value: item.switchValue }, v)
                    "
                  />
                </span>
                <template v-else>{{ item.value }}</template>
                <!-- 操作记录入口（仅样板 1100002）：代理明细折叠区的返佣开关右侧 -->
                <MemberOpLogPopover
                  v-if="item.opLog"
                  :page="item.opLog.page"
                  :item="item.opLog.item"
                />
              </span>
            </div>
          </template>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
  import { getSafeHtml } from '@/utils';
  import { useMemberContext } from '../useMemberContext';
  import { useBasicInfo } from './useBasicInfo';
  import MemberChain from './MemberChain.vue';
  import AttributionFunnel from './AttributionFunnel.vue';
  import MemberOpLogPopover from '../shared/MemberOpLogPopover.vue';

  const { detailData } = useMemberContext();
  const {
    handleItemAction,
    handleToggleState,
    handleToggleSwitch,
    handleViewAgentLine,
    handleViewInviter,
    handleJumpMemberList,
  } = useBasicInfo();
</script>

<style lang="less" scoped>
  /* 行内开关格：开关与标题垂直居中对齐（覆盖 .detail-cell 默认 baseline·2026-07-13 用户要求） */
  .detail-cell.detail-cell--switch {
    align-items: center !important;
  }
  /* 用户备注等 html 值：最多一行、超出省略号（2026-07-13 用户要求）；含换行(br)也压成一行、完整内容点「修改」看 */
  .detail-html-ellipsis {
    flex: 1;
    min-width: 0;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
  .detail-html-ellipsis :deep(br) {
    display: none;
  }
  // 迁移期「新」标：刻意低调（小字 + 低饱和琥珀 + 极浅底），与全局 newMark / MegaMenu 一致
  .ar-newmark {
    display: inline-flex;
    align-items: center;
    margin-left: 4px;
    padding: 0 5px;
    font-size: 10px;
    line-height: 15px;
    font-weight: 400;
    letter-spacing: 0.5px;
    color: #c08a4a;
    background: #faf4ec;
    border-radius: 3px;
  }

  // 字段名后的「?」问号：悬停展示该字段释义（灰色小圈，同列表列头风格）
  .detail-cell__help {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 14px;
    height: 14px;
    margin-left: 4px;
    border: 1px solid #cbd5e1;
    border-radius: 50%;
    color: #94a3b8;
    font-size: 11px;
    line-height: 1;
    cursor: help;
    vertical-align: middle;

    /* 点击型问号（归因介绍）：点开气泡 → 手型光标，区别于悬停释义的 help 光标 */
    &--click {
      cursor: pointer;

      &:hover {
        color: #64748b;
        border-color: #94a3b8;
      }
    }
  }

  /* 归因介绍气泡（样板1100002）：标题 + 归因脉络漏斗；宽度由 n-popover width=920 给足，5 张步骤卡完整横排不裁切 */
  .detail-funnel-pop__title {
    margin-bottom: 8px;
    font-size: 13px;
    font-weight: 600;
    color: #374151;
  }

  .detail-section__header {
    display: flex;
    align-items: center;
    gap: 16px;
  }

  .detail-section__switches {
    display: flex;
    align-items: center;
    gap: 20px;
    margin-left: auto;
  }

  .detail-section__note {
    margin-left: auto;
    font-size: 12px;
    color: #64748b;
  }

  .detail-section__switch {
    display: inline-flex;
    align-items: center;
    gap: 7px;
    font-size: 12px;
    color: #64748b;
  }

  .detail-collapse {
    margin-top: 10px;

    // 折叠头（归因介绍 / 代理明细）按项目 UI 规范：与分区标题一致的字号/字重/颜色，收紧内边距
    :deep(.n-collapse-item) {
      margin-top: 0;
    }
    :deep(.n-collapse-item__header) {
      padding-top: 10px;
      font-size: 13px;
      font-weight: 600;
      color: #111827;
    }
    // 头部右侧链接与标题基线对齐、常规字重
    :deep(.n-collapse-item__header-extra) {
      font-size: 12px;
      font-weight: 400;
    }
    :deep(.n-collapse-item__content-inner) {
      padding-top: 8px;
    }

    // 静态常展开(代理明细·去折叠按钮)：标题行 label 左 + 链接右，同款字号字重
    &--static {
      margin-top: 8px;
    }
    &__bar {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 8px;
      padding-top: 8px;
    }
    // 一页看完(1100002)：删「代理明细」标题后，剩下的「点击查看逐级详情」链接左对齐 + 收紧上间距
    &__bar--nolabel {
      justify-content: flex-start;
      padding-top: 0;
    }
    &__title {
      font-size: 13px;
      font-weight: 600;
      color: #111827;
    }
  }

  .detail-cell__link {
    color: #2563eb;
    cursor: pointer;

    &:hover {
      text-decoration: underline;
    }
  }

  // 会员风控·最后3次登录 → 竖版分组卡片（方案3，仅样板1100002一页看完）：每次登录一张卡（时间做卡头 + IP/设备/指纹卡内行·各带同登录X数可下钻）
  .detail-login__subhead {
    background: #eff6ff;
    color: #1e3a8a;
    font-weight: 600;
    font-size: 12px;
    padding: 4px 8px;
    border-radius: 4px;
    margin: 10px 0 8px;
  }
  .detail-login-card {
    border: 1px solid #e5e7eb;
    border-radius: 8px;
    overflow: hidden;
    margin-bottom: 8px;

    &__head {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 8px;
      background: #f8fafc;
      padding: 5px 10px;
      font-size: 12px;
    }
    &__seq {
      /* 2026-07-16 用户要求：基本信息内红字改回默认色。卡片序号(第N次登录/注册风控标题)
         由红 #dc2626 改默认黑 #111827；字重 600 保留(卡头标题性质，同 section 标题) */
      color: #111827;
      font-weight: 600;
      white-space: nowrap;
    }
    &__time {
      color: #111827;
    }
    &__tz {
      color: #9ca3af;
      margin-left: 4px;
      font-size: 11px;
    }
    &__body {
      padding: 6px 10px;
    }
    &__row {
      display: flex;
      align-items: baseline;
      gap: 8px;
      padding: 3px 0;
      font-size: 13px;
      line-height: 1.5;
    }
    // 注册风控卡行：无「同X数」，计数值右对齐更整齐
    &__row--kv &__val {
      text-align: right;
    }
    &__label {
      color: #6b7280;
      flex-shrink: 0;
      min-width: 52px;
    }
    &__val {
      color: #111827;
      word-break: break-all;
      flex: 1;
      /* 2026-07-16 用户确认「同X数」居右：值区改 flex，让计数组推到行右边缘；值超长时整组下折（R49） */
      display: flex;
      flex-wrap: wrap;
      align-items: baseline;
    }
    /* 「同X数」组容器（2026-07-16 用户确认居右）：标签+数字整组靠行右，数字跨行右对齐成列 */
    &__same {
      margin-left: auto;
      padding-left: 8px;
      white-space: nowrap;
    }
    &__dot {
      /* 「·」分隔点已随 2026-07-16 居右取消、模板不再引用；样式保留备一行回退 */
      color: #d1d5db;
      margin: 0 2px;
    }
    &__clabel {
      color: #6b7280;
      font-size: 12px;
    }
    &__cnt {
      /* 颜色不在此写死：>1 可点时由 .detail-cell__link 给跳转蓝；≤1 不可点回落默认色（R65） */
      font-weight: 600;
      margin-left: 4px;
    }
  }

  // 「打码进度行」独占一行（打码/洗码版块）：左 已完成/需要 X/Y +「修改」，右 进度条 + 达标 badge；进度=已完成÷需要（R49 随内容自适应换行）
  .detail-code-prog {
    display: flex;
    flex-wrap: wrap;
    align-items: center;
    gap: 10px 20px;
    margin: 0 0 14px;
    padding: 10px 12px;
    background: #f8fafc;
    border-radius: 8px;
  }

  .detail-code-prog__nums {
    display: flex;
    align-items: center;
    gap: 8px;
    flex-wrap: wrap;
  }

  .detail-code-prog__names {
    font-size: 13px;
    color: #475569;
    font-weight: 500;
    display: inline-flex;
    align-items: center;
    gap: 4px;
  }

  .detail-code-prog__value {
    font-size: 13px;
    color: #1e293b;
    font-weight: 600;
    white-space: nowrap;
  }

  .detail-code-prog__bar {
    display: flex;
    align-items: center;
    gap: 8px;
  }

  .code-prog {
    position: relative;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    min-width: 140px;
    height: 18px;
    padding: 0 8px;
    border-radius: 9px;
    overflow: hidden;
    background: #eef2f7;
    font-size: 11px;
    color: #334155;
  }

  .code-prog__fill {
    position: absolute;
    left: 0;
    top: 0;
    bottom: 0;
    border-radius: 9px;
    background: #bfdbfe;
    z-index: 0;
  }

  .code-prog--done .code-prog__fill {
    background: #86efac;
  }

  .code-prog__pct {
    position: relative;
    z-index: 1;
    font-weight: 500;
  }

  .code-badge {
    font-size: 11px;
    padding: 1px 8px;
    border-radius: 6px;
    white-space: nowrap;
  }

  .code-badge--done {
    color: #16a34a;
    background: #dcfce7;
  }

  .code-badge--todo {
    color: #b45309;
    background: #fef3c7;
  }

  /* onepage(1100002) 打码进度：①标题+数值(左·上下) ②修改按钮(右·跨两行垂直居中) ③进度条铺满+标识 */
  /* 修改按钮居右（非样板：names/value 靠左、按钮 margin-left:auto 推到最右；onepage 已 space-between） */
  .detail-code-prog__edit {
    margin-left: auto;
  }
  .detail-code-prog__numsleft {
    display: contents; /* 非样板：names/value 仍与修改按钮同排(原样) */
  }
  .detail-code-prog--stacked {
    flex-direction: column;
    align-items: stretch;
    gap: 6px;
  }
  .detail-code-prog--stacked .detail-code-prog__nums {
    width: 100%;
    display: flex;
    align-items: center; /* 修改按钮跨 标题+数值 两行垂直居中 */
    justify-content: space-between;
    gap: 8px;
  }
  .detail-code-prog--stacked .detail-code-prog__numsleft {
    display: flex;
    flex-direction: column;
    gap: 2px;
    min-width: 0;
  }
  .detail-code-prog--stacked .detail-code-prog__bar {
    width: 100%;
  }
  .detail-code-prog--stacked .code-prog {
    flex: 1;
  }
</style>
