// VIP记录（商户端 tenant · operations_vipRecord）功能说明书。
// 锚定 src/views/operations/vipRecord/index.vue(Tab壳) + 2个子Tab
// src/views/operations/vipRewardLog/index.vue(VIP奖励发放记录) + src/views/operations/vipOpLog/index.vue(VIP升降级记录)
// + 各自 data.ts 真实控件（R53 实证、不臆造）。目录分散在3处，一份说明书覆盖全部。

import type { PageManual } from '../types';

const manual: PageManual = {
  route: 'operations_vipRecord',
  title: 'VIP记录',
  overview:
    '商户端「运营管理 › VIP记录」页，容器是一个2标签页壳（VIP奖励发放记录 reward 默认 / VIP升降级记录 levelChange），' +
    '两个标签页完全独立、组件目录物理上也不在同一处（分别复用既有的 vipRewardLog、vipOpLog 两个页面组件）：' +
    '「VIP奖励发放记录」列出每笔VIP奖励(升级礼包/每月奖励)的发放与领取情况；「VIP升降级记录」列出VIP经验值' +
    '变动/保级成功失败/升降级共6种日志事件，每行可查看只读详情弹窗。两个Tab均为纯查询记录页（无新增/编辑/删除），' +
    '数据均为真实mock(36条/30条)，未发现列表数据缺失问题。' +
    '2026-07-22核实代码发现1处：「VIP升降级记录」工具栏的"导出"按钮点击只弹出一条通用提示' +
    '(message.info)，没有任何真实导出/下载逻辑——是全站唯一一个纯占位、完全未实现的导出按钮（其它页面的' +
    'ExportButton要么真生成CSV、要么至少走一遍完整的选格式+下载流程）。如实记录，未修复。',
  items: [
    {
      anchor: 'tab_switch',
      name: '2个子页Tab切换（VIP奖励发放记录/VIP升降级记录）',
      group: '操作',
      interaction: '横排Tab，点击切换，默认停在"VIP奖励发放记录"。',
    },

    // ============ VIP奖励发放记录 Tab ============
    {
      anchor: 'reward_merchant',
      name: '商户（VIP奖励发放记录·必选）',
      group: '搜索',
      interaction: '下拉单选，红星必填；未选点查询红框+红字提示。',
      limit: '单选必填（R63）。',
    },
    {
      anchor: 'reward_userId',
      name: '会员ID（VIP奖励发放记录）',
      group: '搜索',
      interaction: '文本框，可清空。',
    },
    {
      anchor: 'reward_vipLevel',
      name: 'VIP等级（VIP奖励发放记录）',
      group: '搜索',
      interaction: '下拉单选，可清空；选项VIP0~VIP10共11级。',
    },
    {
      anchor: 'reward_rewardType',
      name: '奖励类型（VIP奖励发放记录）',
      group: '搜索',
      interaction: '下拉单选，可清空；选项：升级礼包/每月奖励。',
    },
    {
      anchor: 'reward_claimState',
      name: '领取状态（VIP奖励发放记录）',
      group: '搜索',
      interaction: '下拉单选，可清空；选项：未领取/已领取。',
    },
    {
      anchor: 'reward_grantTime',
      name: '发放时间（VIP奖励发放记录）',
      group: '搜索',
      interaction: '日期时间区间选择，精确到秒，最长跨度90天，不允许选未来日期。',
      limit: '最长跨度90天。',
    },
    {
      anchor: 'reward_reset',
      name: '重置（VIP奖励发放记录）',
      group: '搜索',
      interaction: 'ProCrudTable内置重置按钮。',
    },
    {
      anchor: 'col_reward_userId',
      name: '会员ID（VIP奖励发放记录·列，可点击）',
      group: '列',
      interaction: '蓝字可点。',
      logic: '点击打开全站共用「会员详情」弹窗。',
    },

    // ============ VIP升降级记录 Tab ============
    {
      anchor: 'oplog_merchant',
      name: '商户（VIP升降级记录·必选）',
      group: '搜索',
      interaction: '下拉单选，红星必填；未选点查询红框+红字提示。',
      limit: '单选必填（R63）。',
    },
    {
      anchor: 'oplog_userId',
      name: '会员ID（VIP升降级记录）',
      group: '搜索',
      interaction: '文本框，可清空。',
    },
    {
      anchor: 'oplog_orderNo',
      name: '订单号（VIP升降级记录）',
      group: '搜索',
      interaction: '文本框，可清空。',
    },
    {
      anchor: 'oplog_logType',
      name: '日志类型（VIP升降级记录）',
      group: '搜索',
      interaction: '下拉单选，可清空；选项：保级成功/保级失败/VIP升级/经验值奖励/经验值降级/保级失败降级共6种。',
    },
    {
      anchor: 'oplog_createDate',
      name: '记录时间（VIP升降级记录·必选）',
      group: '搜索',
      interaction: '日期时间区间选择，精确到秒，最长跨度90天，不允许选未来日期。',
      limit: '必填（未选点查询会校验拦截）+最长跨度90天，是本页与"VIP奖励发放记录"Tab发放时间(选填)不同的地方。',
    },
    {
      anchor: 'oplog_reset',
      name: '重置（VIP升降级记录）',
      group: '搜索',
      interaction: 'ProCrudTable内置重置按钮。',
    },
    {
      anchor: 'act_oplog_export',
      name: '导出（VIP升降级记录）',
      group: '操作',
      interaction: '工具栏按钮，点击后仅弹出一条通用提示信息。',
      edge: '纯占位，没有真实导出/下载逻辑，是全站唯一一个完全未实现的导出按钮。',
    },
    {
      anchor: 'col_oplog_userId',
      name: '会员ID（VIP升降级记录·列，可点击）',
      group: '列',
      interaction: '蓝字可点。',
      logic: '点击打开全站共用「会员详情」弹窗。',
    },
    {
      anchor: 'act_oplog_detail',
      name: '查看（VIP升降级记录·行操作）',
      group: '操作',
      interaction: '每行常驻，蓝字按钮，点击打开只读详情弹窗。',
      logic: '详情弹窗以描述列表(n-descriptions)形式展示该条记录全部字段：商户/订单号/时间/会员ID/日志类型/领取类型/领取值/经验值/累计经验值/详情说明/状态。',
    },
  ],
  fields: [
    { name: '商户（VIP奖励发放记录·列）', def: '该条记录所属商户，标签展示。' },
    { name: '会员ID（VIP奖励发放记录·列）', def: '该奖励发放给的会员，见交互条目 col_reward_userId。' },
    { name: 'VIP等级（VIP奖励发放记录·列）', def: '会员触发该奖励时所处的VIP等级，橙色Tag「VIPn」展示。' },
    { name: '奖励类型（VIP奖励发放记录·列）', def: '升级礼包/每月奖励，蓝色Tag展示。' },
    { name: '奖励金额（VIP奖励发放记录·列）', def: '该笔奖励的金额数值，保留两位小数。' },
    { name: '领取状态（VIP奖励发放记录·列）', def: '未领取(灰)/已领取(绿)Tag展示。' },
    { name: '发放时间（VIP奖励发放记录·列）', def: '该笔奖励的发放时间。' },
    { name: '领取时间（VIP奖励发放记录·列）', def: '会员实际领取该奖励的时间。' },
    { name: '商户（VIP升降级记录·列）', def: '该条日志所属商户，标签展示。' },
    { name: '订单号（VIP升降级记录·列）', def: '该条日志关联的业务订单号。' },
    { name: '时间（VIP升降级记录·列）', def: '该条日志的记录时间。' },
    { name: '会员ID（VIP升降级记录·列）', def: '该条日志涉及的会员，见交互条目 col_oplog_userId。' },
    { name: '日志类型（VIP升降级记录·列）', def: '6种事件类型，Tag按语义分色：升级/保级成功=绿，降级/保级失败=红，其余=蓝。' },
    { name: '领取类型（VIP升降级记录·列）', def: '积分/余额，两种奖励发放载体。' },
    { name: '领取值（VIP升降级记录·列）', def: '该次事件实际发放/扣减的数值。' },
    { name: '经验值（VIP升降级记录·列）', def: '该次事件产生的经验值变动量。' },
    { name: '累计经验值（VIP升降级记录·列）', def: '该次事件发生后会员的经验值总量。' },
    { name: '详情说明（VIP升降级记录·列）', def: '该条日志的补充文字说明。' },
  ],
};

export default manual;
