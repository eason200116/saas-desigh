// 同IP/设备检测（商户端 tenant · riskControl_sameIp）功能说明书。
// 锚定 src/views/riskControl/sameIp/index.vue + data.ts 真实控件（R53 实证、不臆造）。
// 单表 6-Tab 聚合页：同一张 ProCrudTable + 同一套搜索区，切 Tab 只换查询维度(tab参数)和列/搜索项文案，组件结构不变。

import type { PageManual } from '../types';

const manual: PageManual = {
  route: 'riskControl_sameIp',
  title: '同IP/设备检测',
  overview:
    '商户端风控页，用于排查同一 IP / 设备 / 浏览器指纹被多个会员共用的异常情况。顶部 6 个 Tab（同注册IP / 同注册设备 / 同注册浏览器指纹 / 同登录IP / 同登录设备 / 同登录浏览器指纹）共用同一张表格与同一套搜索条件，切 Tab 只换查询维度和列/搜索项标签文案，不改变页面结构。支持从「会员详情 › 会员风控」跳入并自动定位到指定维度、预填关键词。',
  items: [
    // ============ 搜索区 ============
    {
      anchor: 'merchant',
      name: '商户',
      group: '搜索',
      interaction: '下拉单选（商户选择器，架构级不可清空，见《交互规范》§3 商户选择器）。',
      dataSource: '全站商户列表。',
      logic: '按选中商户过滤当前维度的检测结果；点「人数」跳会员列表时带上商户上下文。',
      limit:
        '必填（红星 showRequireMark + requiredRule）；单选、不可清空——命中 R63（本页商户与会员ID同屏出现，商户必单选+必填）。',
      edge: '不可清空，恒有值，不存在「未选商户」态。',
    },
    {
      anchor: 'memberId',
      name: '会员ID',
      group: '搜索',
      interaction: '文本输入。',
      dataSource: '用户输入。',
      logic: '意图按会员ID过滤检测结果。',
      limit: '选填；仅数字（inputProps intNum，最多9位）。',
      edge:
        '⚠️ 核实代码后发现：当前 mock（sameIpGetPageList）只读取 tab / tenantId / keyword 三个参数过滤，并未读取 memberId——本字段目前是"能填但不影响查询结果"的占位态，如实记录待补，非本次遗漏。',
    },
    {
      anchor: 'keyword',
      name: '维度关键词（随 Tab 变化：注册IP / 注册设备号 / 注册浏览器指纹 / 登录IP / 登录设备号 / 登录浏览器指纹）',
      group: '搜索',
      interaction: '文本输入，label 随当前 Tab 切换（如切到「同登录浏览器指纹」Tab，label 显示「登录浏览器指纹」）。',
      dataSource: '用户输入。',
      logic: '按维度值模糊匹配过滤（dimValue 字符串 includes，不区分大小写）。',
      limit: '选填；最多 50 字（inputProps searchKw）。',
      edge: '空 = 不按关键词筛，仅按当前商户过滤。',
    },
    {
      anchor: 'dateRange',
      name: '日期',
      group: '搜索',
      interaction: '日期区间选择（proDateRange，含时分秒）。',
      dataSource: '用户选择。',
      logic: '意图按最近时间过滤。',
      limit:
        '最多跨 90 天（标准档，对齐《交互规范》§0 时间查询"标准档"分级）；不可选未来（allowFuture:false）。',
      edge:
        '⚠️ 核实代码后发现：同 memberId，当前 mock 未读取 dateRange 参数、不影响返回结果，如实记录待补，非本次臆造遗漏。',
    },

    // ============ 操作 ============
    {
      anchor: 'tab_switch',
      name: '6 个维度 Tab 切换',
      group: '操作',
      interaction:
        '点顶部 Tab 切换检测维度：同注册IP / 同注册设备 / 同注册浏览器指纹 / 同登录IP / 同登录设备 / 同登录浏览器指纹。',
      logic:
        '切 Tab 只更换查询用的 tab 参数 + 对应列/搜索项的显示文案，表格结构和商户/日期等其它筛选条件保持不变，自动重新加载数据。',
      note: '支持从「会员详情 › 会员风控」跳入：URL query 带 tab 直接定位到指定维度 Tab，带 keyword 预填关键词搜索框。',
    },
    {
      anchor: 'col_memberCount',
      name: '人数列（随 Tab 变化：同注册IP人数 / … / 同登录浏览器指纹人数）',
      group: '列',
      interaction: '数字以可点击蓝字链接形式展示（跳转类控件，非纯展示）。',
      dataSource: '行数据 memberCount（该维度值命中的会员数量）。',
      logic:
        '点击跳转「会员列表」(`/member/user`)，query 携带当前维度筛选条件（如 registerIp=命中的IP值），方便直接查看命中同一 IP/设备/指纹的具体会员。',
    },
  ],

  // ============ 字段介绍 tab（列序照页面；仅列表列 + 定义）============
  fields: [
    {
      name: '商户',
      def: '命中该维度值的商户；一个 IP / 设备 / 指纹可能同时命中多个商户站点，全部并列展示为商户标签。',
    },
    {
      name: '维度值（随 Tab 变化：注册IP / 注册设备号 / 注册浏览器指纹 / 登录IP / 登录设备号 / 登录浏览器指纹）',
      def: '当前 Tab 对应维度的具体检测值——IP 地址、设备唯一标识号，或浏览器指纹字符串（基于设备/浏览器特征生成的唯一标识）。',
    },
    {
      name: '人数（随 Tab 变化：同注册IP人数 / … / 同登录浏览器指纹人数）',
      def: '命中该维度值的会员数量；点击可跳转「会员列表」查看具体是哪些会员。',
    },
    { name: '最近时间', def: '该维度值最近一次注册或登录的时间，按当前操作商户所在时区显示。' },
  ],
};

export default manual;
