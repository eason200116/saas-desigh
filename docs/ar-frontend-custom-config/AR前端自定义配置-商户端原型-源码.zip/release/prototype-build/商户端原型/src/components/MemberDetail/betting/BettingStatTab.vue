<template>
  <ProCrudTable
    ref="bettingStatTableRef"
    :columns="columns"
    :search-columns="searchColumns"
    :action-column="actionColumn"
    :request="loadData"
    row-key="gameCode"
    search-layout="flex"
    :summary="summary"
    :search-default-collapsed="false"
    quick-date="timeRange"
    :auto-height="false"
    :max-height="tableMaxHeight"
  />
</template>

<script setup lang="ts">
  import { computed, inject, type Ref } from 'vue';
  import { ProCrudTable } from '@/components';
  import { useBettingStat } from './useBettingStat';
  import { MEMBER_DETAIL_HAS_HISTORY_BAR } from '../useMemberContext';

  const { bettingStatTableRef, columns, searchColumns, actionColumn, loadData, summary } =
    useBettingStat();

  // 顶部多会员切换条会占 ~40px：有则 430，无则 470；非弹窗场景（inject 缺失）按无历史栏处理
  const hasHistoryBar = inject<Ref<boolean> | undefined>(MEMBER_DETAIL_HAS_HISTORY_BAR, undefined);
  const tableMaxHeight = computed(() => (hasHistoryBar?.value ? 430 : 470));

  // 模板 ref 绑定，抑制 TS6133 未读警告
  void bettingStatTableRef;
</script>
