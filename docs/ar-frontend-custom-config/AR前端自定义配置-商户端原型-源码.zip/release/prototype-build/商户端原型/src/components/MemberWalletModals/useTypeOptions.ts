import { ref, type Ref } from 'vue';
import type { SelectOption } from 'naive-ui';
import { api } from './data';

/**
 * 银行卡管理模块共享的枚举选项缓存
 * - 按 tenantId 缓存，切换商户自动重新请求
 * - 同一 tenantId 下并发调用只发一次请求
 */

type TypeOption = SelectOption & { label: string; value: number };

type TypeListApi = (params: {
  tenantId?: number;
  pageNo: number;
  pageSize: number;
  orderBy: string;
}) => Promise<{ data?: { id: number; name: string }[] | null }>;

/** 创建带 tenantId 缓存 + 并发锁的枚举加载器 */
function createTypeLoader(apiFn: TypeListApi, options: Ref<TypeOption[]>, pageSize = 100) {
  let cachedTenant: number | undefined;
  let pending: Promise<void> | null = null;

  return async (tenantId?: number) => {
    if (cachedTenant === tenantId && options.value.length > 0) return;
    if (pending) return pending;

    cachedTenant = tenantId;
    pending = (async () => {
      try {
        const { data } = await apiFn({ tenantId, pageNo: 1, pageSize, orderBy: 'Asc' });
        options.value = (data ?? []).map((item) => ({ label: item.name, value: item.id }));
      } catch {
        options.value = [];
      } finally {
        pending = null;
      }
    })();
    return pending;
  };
}

// 3 种枚举的响应式选项（银行卡 Tab 使用 AsyncSelect，不在此管理）
const walletOptions = ref<TypeOption[]>([]);
const cpfOptions = ref<TypeOption[]>([]);
const usdtOptions = ref<TypeOption[]>([]);

const loadWalletOptions = createTypeLoader(api.v1platform.getWalletTypeList, walletOptions);
const loadCpfOptions = createTypeLoader(api.v1platform.getCpfTypeList, cpfOptions);
const loadUsdtOptions = createTypeLoader(api.v1platform.getUsdtTypeList, usdtOptions);

// ─── 编辑兜底工具 ───

/** 归一化字符串：去空格、转小写 */
function normalize(s: string) {
  return s.replace(/\s+/g, '').toLowerCase();
}

/**
 * 确保选项列表中有与当前值匹配的项，让 Select 正确回显
 * - 值已存在 → 直接返回
 * - label 相似（如 "FastUPI" vs "Fast UPI"）→ 替换匹配项的 value
 * - 都不匹配 → 插入兜底选项
 */
function ensureOption(
  options: TypeOption[],
  value: number | null | undefined,
  fallbackLabel?: string,
): TypeOption[] {
  if (value == null) return options;
  if (options.some((o) => o.value === value)) return options;

  if (fallbackLabel) {
    const target = normalize(fallbackLabel);
    const idx = options.findIndex((o) => normalize(o.label) === target);
    if (idx >= 0) {
      const patched = [...options];
      patched[idx] = { ...patched[idx], value };
      return patched;
    }
  }

  return [{ label: fallbackLabel ?? String(value), value }, ...options];
}

export function useTypeOptions() {
  return {
    walletOptions,
    cpfOptions,
    usdtOptions,
    loadWalletOptions,
    loadCpfOptions,
    loadUsdtOptions,
    ensureOption,
  };
}
