<template>
  <n-popover ref="popover" placement="bottom" trigger="click">
    <template #trigger>
      <n-button class="min-w-[80px]" :disabled="isDisabled"><slot></slot></n-button>
    </template>
    <div class=" ">
      <div class="mb-4">
        <div class="font-bold mb-2">{{ title }}</div>
        <n-input-number
          :disabled="isDisabled"
          :placeholder="t('common.configValuePlaceholder')"
          v-model:value="configValue"
          :min="0"
          :show-button="false"
          clearable
        />
      </div>
      <n-space class="justify-center">
        <n-button size="small" class="mr-2" @click="onClosed">{{ t('common.cancel') }}</n-button>
        <n-button
          type="primary"
          size="small"
          :loading="loading"
          @click="onConfirm"
          :disabled="isDisabled"
          >{{ t('common.confirm') }}</n-button
        >
      </n-space>
    </div>
  </n-popover>
</template>
<script setup lang="ts">
  import { NButton, useMessage } from 'naive-ui';
  import { ref, watch, computed } from 'vue';
  import { useI18n } from 'vue-i18n';
  const props = defineProps<{
    value: number | undefined;
    beforeClose?: Function | Promise<any>;
    title?: string;
  }>();
  const emit = defineEmits(['confirm']);
  const message = useMessage();
  const { t } = useI18n();
  const popover = ref();
  const loading = ref(false);
  const configValue = ref(props.value || 0);
  const isDisabled = computed(() => false);
  const onClosed = () => {
    popover.value?.setShow(false);
  };
  const onConfirm = async () => {
    if (props.beforeClose) {
      try {
        loading.value = true;
        let result: any;
        if (props.beforeClose instanceof Function) {
          result = props.beforeClose(configValue.value);
        } else {
          //@ts-ignore
          result = await props.beforeClose(configValue.value);
        }
        message.success(t('common.edit_success'));
        if (result instanceof Promise) {
          await result;
        }
        onClosed();
      } catch (e) {
        console.log(e);
      } finally {
        loading.value = false;
      }
      return;
    }
    // emit('confirm',configValue.value);
    // onClosed()
  };
  watch(
    () => props.value,
    (val) => {
      configValue.value = Number(val || 0);
    },
  );
</script>
