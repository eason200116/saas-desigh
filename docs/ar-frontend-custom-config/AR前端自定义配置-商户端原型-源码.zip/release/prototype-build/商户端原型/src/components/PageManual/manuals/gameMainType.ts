// 游戏主类型配置（总控端 admin · game_main_type）功能说明书。
// 锚定 src/views/game/mainType/index.vue + data.ts + components/MainTypeFormModal.vue 真实控件（R53 实证、不臆造）。
// 标准 ProCrudTable 列表页：2 搜索项 + 9 列 + 顶部「新增主类型」+ 2 行操作（编辑 / 删除）。

import type { PageManual } from '../types';

const manual: PageManual = {
  route: 'game_main_type',
  title: '游戏主类型配置',
  overview:
    '总控端维护「游戏主类型」（即游戏大类）这份主数据——游戏厂商管理、子游戏管理等页面里「游戏大类」下拉的选项都来自这里，本页是那份数据的源头（约 12 类，不写死）。可搜索、新增 / 编辑 / 删除主类型，并启停其状态。',
  items: [
    // ============ 搜索区 ============
    {
      anchor: 'typeName',
      name: '主类型名称',
      group: '搜索',
      interaction: '文本输入、模糊匹配。',
      dataSource: '用户输入。',
      logic: '按主类型名称模糊筛选。',
      limit: '选填；最多 50 字（inputProps searchKw）。',
      edge: '空 = 不按名称筛。',
    },
    {
      anchor: 'state',
      name: '状态（搜索）',
      group: '搜索',
      interaction: '下拉单选：启用 / 禁用（二态）。',
      dataSource: '本地枚举（启用 = 1 / 禁用 = 0）。',
      logic: '按启停状态筛选。',
      limit: '选填。',
      edge: '不选 = 全部状态。',
    },

    // ============ 关键列（状态列）============
    {
      anchor: 'col_state',
      name: '状态列',
      group: '列',
      interaction: '只读 Tag：启用绿 / 禁用红（二态），不可点。',
      dataSource: '行数据 state（0 禁用 / 1 启用）。',
      logic: '仅展示主类型状态；改状态走行操作「编辑」弹窗内的开关。',
      note: '本页 R47 反转（列内只读 Tag、开关移入编辑弹窗），与 game/platform、game/game 同口径（用户拍板）。',
    },

    // ============ 操作（顶部新增 + 2 行操作）============
    {
      anchor: 'act_add',
      name: '新增主类型（顶部）',
      group: '操作',
      interaction: '点击顶部「新增主类型」打开表单弹窗（约 560px，MainTypeFormModal）：填主类型名称（中 / 英）、编码、排序、状态后保存。',
      logic: '保存后刷新列表。',
      limit: '表单校验（代码可见）：主类型名称、编码、排序均必填（主类型名称 maxlength 50，INPUT_PRESETS.name）；编码为英文短名（示例 electronic）。',
    },
    {
      anchor: 'act_edit',
      name: '行操作 · 编辑',
      group: '操作',
      interaction: '点击打开同一表单弹窗（约 560px，新增/编辑共用），回显该行主类型配置。',
      logic: '保存后刷新列表。',
      note: '编辑态「编码」字段禁用（:disabled=!isCreate，仅新增可填、编码不可改）。',
    },
    {
      anchor: 'act_delete',
      name: '行操作 · 删除',
      group: '操作',
      interaction: '点击直接删除该主类型（代码中为直接调用删除、当前无二次确认弹窗）。',
      logic: '调用 api.game.gameMainTypeDelete 后刷新列表。',
      edge: '删除不可撤销；该主类型是否被厂商 / 子游戏引用、删除是否级联，待 5190 核实。',
    },
  ],

  // ============ 字段介绍 tab（列序照页面；仅列表列 + 定义）============
  fields: [
    { name: 'ID', def: '主类型记录的唯一编号。' },
    { name: '主类型名称', def: '游戏大类的名称（如老虎机、体育博彩、真人娱乐场等）。' },
    { name: '编码', def: '主类型的英文编码（如 electronic），供程序识别引用。' },
    { name: '排序', def: '主类型在下拉 / 展示中的顺序，数值越小越靠前。' },
    { name: '状态', def: '主类型当前状态：启用 / 禁用。' },
    { name: '创建人', def: '创建该主类型的操作账号。' },
    { name: '创建时间', def: '主类型记录创建时间（按商户时区展示）。' },
    { name: '最后更新时间', def: '主类型记录最近一次修改时间（按商户时区展示）。' },
    { name: '最后操作人', def: '最近一次修改该主类型的操作账号。' },
  ],
};

export default manual;
