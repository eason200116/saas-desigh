import { h, computed, reactive, ref } from 'vue';
import { useI18n } from 'vue-i18n';
import { NInput, useModal } from 'naive-ui';
import { createActionColumn, type ProCrudTableInstance, type Recordable } from '@/components';
import {
  buildFinancialTypeCascaderOptions,
  buildFinancialTypeLabelMap,
  expandFinancialTypeValue,
  parseFinancialTypeMatchers,
} from '@/constants/financialType';
// 原型无后端：FinanceRecordReq 本地按 any 处理（源走 @/api/v1platform 真实类型）
type FinanceRecordReq = any;
import { useUser, useTenantOptions, useTableExport } from '@/hooks';
import { currency } from '@/utils';
import { useMemberContext, useQueryReload, MEMBER_DETAIL_CHILD_Z_INDEX } from '../useMemberContext';
import { useMemberTableTimezone } from '../useMemberTableTimezone';
import { createFundColumns, createFundSearchColumns } from './fundConfig';

/**
 * 账变信息 Tab 的业务逻辑
 */
export function useFundRecord() {
  const { t, locale } = useI18n();
  const { memberId, tenantId: ctxTenantId, globalTimeRange } = useMemberContext();
  // 【已铺开·2026-07-14 用户确认】「资金账变·对齐财务」（树选择 + typeMatchers + 账变时间列置于余额后备注前 + Tab 名「资金账变」）
  // 原为样板 1100002 试点（2026-07-13 收窄），验收后对全部会员生效，故恒为 true。
  // 保留变量以便一行收回（改回 Number(memberId.value) === 1100002 即恢复「账变记录」级联态）。
  const isSample = computed(() => true);
  const {
    message,
    formatDateTimeStr,
    fetchFinanceRecordPageList,
    exportFinanceRecord,
    updateFinanceRemark,
    getTenantId,
  } = useUser();
  const { getTenantCurrency, renderTenantDateTimeColumnTitle } = useTenantOptions();
  const modal = useModal();

  const fundTableRef = ref<ProCrudTableInstance | null>(null);
  // 账变时间 picker 按会员所属商户时区展示（而非全局默认商户）
  useMemberTableTimezone(fundTableRef);
  const fundStatSummary = reactive({ pageAmount: '0.00', grandTotalAmount: '0.00' });

  // 账变类型级联选项 / 标签映射均取自单一数据源 @/constants/financialType（随语言切换）
  const typeCascaderOptions = computed(() => buildFinancialTypeCascaderOptions(locale.value));
  const typeLabelMap = computed(() => buildFinancialTypeLabelMap(locale.value));

  // 搜索列（computed 以响应语言切换）；isSample 决定账变类型控件=树(样板)/级联(其它)
  const searchColumns = computed(() =>
    createFundSearchColumns(t, typeCascaderOptions.value, isSample.value),
  );

  // 表格列（computed 以响应语言切换，账变时间列标题追加商户时区）
  const columns = computed(() => {
    const cols = createFundColumns(t, getTenantCurrency, typeLabelMap.value, isSample.value);
    const timeCol = cols.find((c) => c.key === 'time');
    if (timeCol && typeof timeCol.title === 'string') {
      timeCol.title = renderTenantDateTimeColumnTitle(
        timeCol.title,
        ctxTenantId.value ?? getTenantId(),
      );
    }
    return cols;
  });

  // 操作列（无 UpdateRemark 权限时 createActionColumn 会返回 undefined，整列隐藏）
  const actionColumn = createActionColumn(() => ({
    actions: [
      {
        label: t('member.detail.fund.editRemark'),
        type: 'primary',
        onClick: (row) => handleFundRemark(row),
      },
    ],
    width: 100,
  }));

  function handleFundRemark(row) {
    const remarkRef = ref(row.remarkDisplay && row.remarkDisplay !== '--' ? row.remarkDisplay : '');
    const inst = modal.create({
      zIndex: MEMBER_DETAIL_CHILD_Z_INDEX,
      title: t('member.detail.fund.editRemarkTitle', { orderNo: row.orderNo }),
      preset: 'dialog',
      class: 'w-[500px]',
      showIcon: false,
      content: () =>
        h(NInput, {
          type: 'textarea',
          rows: 4,
          placeholder: t('member.detail.fund.remarkPlaceholder'),
          value: remarkRef.value,
          onUpdateValue: (val) => {
            remarkRef.value = val;
          },
        }),
      positiveText: t('common.save'),
      negativeText: t('common.cancel'),
      onPositiveClick: async () => {
        inst.loading = true;
        try {
          // 嵌入弹窗时按订单商户更新备注
          const { code, msg } = await updateFinanceRemark(
            row.finanID,
            remarkRef.value,
            ctxTenantId.value ?? null,
          );
          if (code !== 0) {
            message.error(msg || t('member.detail.fund.editRemarkFailed'));
            return false;
          }
          message.success(t('member.detail.fund.editRemarkSuccess'));
          row.remarkDisplay = remarkRef.value || '--';
          fundTableRef.value?.reload();
        } catch {
          message.error(t('member.detail.fund.editRemarkFailed'));
          return false;
        } finally {
          inst.loading = false;
        }
      },
    });
  }

  /**
   * 导出参数构建：会员详情弹窗内固定会员/商户；时间缺省回退会员详情全局时间范围；
   * 并把搜索列别名（orderNo/changeType/operator）映回后端字段（orderNum/type/reserved）。
   * isExport/pageSize/exportTitle/时区/文件名由 useTableExport 统一补齐。
   */
  function buildExportParams(searchParams: Recordable): FinanceRecordReq {
    let startTime: string | undefined = searchParams?.startTime;
    let endTime: string | undefined = searchParams?.endTime;
    if (!startTime || !endTime) {
      const fallback = globalTimeRange.value;
      if (Array.isArray(fallback) && fallback.length === 2) {
        startTime = formatDateTimeStr(fallback[0]);
        endTime = formatDateTimeStr(fallback[1]);
      }
    }
    const req: FinanceRecordReq = {
      userID: String(memberId.value),
      // 嵌入弹窗时强制使用订单商户
      tenantId: ctxTenantId.value ?? getTenantId(),
      pageNo: 1,
      pageSize: 10000,
      orderBy: 'Desc',
    };
    if (searchParams?.orderNo) req.orderNum = searchParams.orderNo;
    // 账变类型取值（pilot 收窄）：样板 typeMatchers（树·与财务同源 mock）/ 其它会员 type（级联 → expandFinancialTypeValue 展开子类型 code），与列表一致
    if (isSample.value) {
      const typeMatchers = parseFinancialTypeMatchers(searchParams?.changeType);
      if (typeMatchers.length > 0) req.typeMatchers = typeMatchers;
    } else {
      const typeCodes = expandFinancialTypeValue(searchParams?.changeType);
      if (typeCodes.length > 0) req.type = typeCodes;
    }
    if (searchParams?.operator) req.reserved = searchParams.operator;
    if (startTime) req.startTime = startTime;
    if (endTime) req.endTime = endTime;
    return req;
  }

  // 导出账变记录：复用 useTableExport（exportTitle 按列 export 元数据生成、时区、下载、loading 统一处理）
  const { exportLoading, handleExport: handleFundExport } = useTableExport(fundTableRef, {
    request: exportFinanceRecord,
    fileName: () => t(isSample.value ? 'member.detail.tabs.fundSample' : 'member.detail.tabs.fund'),
    buildParams: buildExportParams,
  });

  // 汇总行（NaiveUI summary，返回数组 = 多行）
  const amountColor = (val: string) => (String(val).startsWith('-') ? '#dc2626' : '#16a34a');
  const renderAmountCell = (val: string) => ({
    value: h('span', { style: `color: ${amountColor(val)}; font-weight: 600` }, val),
  });

  const summary = () => [
    {
      orderNo: { value: t('common.summary.pageTotal') },
      amount: renderAmountCell(fundStatSummary.pageAmount),
    },
    {
      orderNo: { value: t('common.summary.total') },
      amount: renderAmountCell(fundStatSummary.grandTotalAmount),
    },
  ];

  // 加载数据
  async function loadData(params) {
    // modelKeys 展平后直接读分字段；若用户未选且无列默认值，fallback 到会员详情的全局时间范围
    let startTime = params?.startTime as string | undefined;
    let endTime = params?.endTime as string | undefined;
    if (!startTime || !endTime) {
      const fallback = globalTimeRange.value;
      if (Array.isArray(fallback) && fallback.length === 2) {
        startTime = formatDateTimeStr(fallback[0]);
        endTime = formatDateTimeStr(fallback[1]);
      }
    }
    try {
      const reqParams: any = {
        userID: String(memberId.value),
        // 嵌入弹窗时强制使用订单商户
        tenantId: ctxTenantId.value ?? getTenantId(),
        pageNo: params?.pageNo ?? 1,
        pageSize: params?.pageSize ?? 10,
        orderBy: 'Desc',
      };
      if (params?.orderNo) reqParams.orderNum = params.orderNo;
      // 账变类型取值（pilot 收窄·2026-07-13）：
      //   样板 1100002 → 树多选值(子类型 code / 厂商 v: / 游戏 gm:)解析为 typeMatchers，与财务·资金账变同源 mock（只认 typeMatchers）。
      //   其它会员 → 原级联值经 expandFinancialTypeValue 展开为子类型 code 数组写 reqParams.type（保持原「账变记录」行为）。
      if (isSample.value) {
        const typeMatchers = parseFinancialTypeMatchers(params?.changeType);
        if (typeMatchers.length > 0) reqParams.typeMatchers = typeMatchers;
      } else {
        const typeCodes = expandFinancialTypeValue(params?.changeType);
        if (typeCodes.length > 0) reqParams.type = typeCodes;
      }
      if (params?.operator) reqParams.reserved = params.operator;
      if (startTime) reqParams.startTime = startTime;
      if (endTime) reqParams.endTime = endTime;

      const finRes = await fetchFinanceRecordPageList(reqParams);
      const list = (finRes?.list || []).map((item) => ({
        finanID: item.finanID,
        tenantId: item.tenantId,
        orderNo: item.orderNum || '--',
        type: item.type,
        typeTone: item.isDeduct ? 'danger' : 'success',
        isDeduct: item.isDeduct,
        amount: item.amount ?? 0,
        beforeBalance: item.beforeAmount ?? 0,
        afterBalance: item.backAmount ?? 0,
        remarkDisplay: item.remarkDisplay || item.remark || '--',
        operator: item.reserved || '--',
        time: item.addTimeStr || '--',
      }));

      const resSummary = finRes?.summary;
      const fmtSigned = (n) => {
        if (n == null) return '--';
        const str = currency(n);
        return String(str).startsWith('-') ? str : `+${str}`;
      };
      fundStatSummary.pageAmount = fmtSigned(resSummary?.pageSumAmount);
      fundStatSummary.grandTotalAmount = fmtSigned(resSummary?.amountSum);

      return { list, total: finRes?.totalCount ?? 0 };
    } catch (e) {
      console.error('加载账变记录失败', e);
      return { list: [], total: 0 };
    }
  }

  useQueryReload('fund', fundTableRef);

  // 搜索初始值（账变默认走列内 defaultShortcut: 'today'，此处提供空对象占位绑定）
  const searchInitialValues = computed<Recordable>(() => ({}));

  return {
    fundTableRef,
    columns,
    searchColumns,
    searchInitialValues,
    actionColumn,
    summary,
    loadData,
    handleFundExport,
    exportLoading,
  };
}
