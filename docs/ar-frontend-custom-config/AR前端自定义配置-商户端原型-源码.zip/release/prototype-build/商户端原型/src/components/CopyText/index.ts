export { default as CopyText } from './copy.vue';
