<template>
  <n-popover placement="bottom" trigger="click" @update:show="(val) => popoverChange(val)">
    <template #trigger>
      <n-button quaternary type="info" class="mr-2"><slot></slot></n-button>
    </template>
    <n-data-table
      size="small"
      :columns="columns"
      :data="popoverData"
      :pagination="false"
      :bordered="false"
    />
  </n-popover>
</template>
<script setup lang="ts">
  import { NButton } from 'naive-ui';
  const props = defineProps<{
    popoverData: any[];
    columns: any[];
    configKey?: string;
  }>();
  const emit = defineEmits(['confirm']);
  const popoverChange = (show: boolean) => {
    if (show) {
      emit('confirm', props.configKey);
    }
  };
</script>
