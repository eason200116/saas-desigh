import type { Ref } from 'vue';
import StarterKit from '@tiptap/starter-kit';
import Underline from '@tiptap/extension-underline';
import Link from '@tiptap/extension-link';
import { BackgroundColor, Color, TextStyle } from '@tiptap/extension-text-style';
import TextAlign from '@tiptap/extension-text-align';
import Placeholder from '@tiptap/extension-placeholder';
import Image from '@tiptap/extension-image';
import { Table } from '@tiptap/extension-table';
import TableRow from '@tiptap/extension-table-row';
import TableCell from '@tiptap/extension-table-cell';
import TableHeader from '@tiptap/extension-table-header';
import { CalloutBlock, DateBlock, OpsColumn, OpsColumns, StatusBlock } from './blocks';
import { getEditorProfileConfig } from './profiles';
import type { TiptapEditorProfile } from './types';

interface CreateTiptapExtensionsOptions {
  profile: Ref<TiptapEditorProfile>;
  placeholder: Ref<string>;
}

export function createTiptapExtensions(options: CreateTiptapExtensionsOptions) {
  const profileConfig = getEditorProfileConfig(options.profile.value);

  return [
    StarterKit.configure({
      heading: {
        levels: [1, 2, 3],
      },
    }),
    Underline,
    Link.configure({
      openOnClick: false,
      autolink: true,
      linkOnPaste: true,
      defaultProtocol: 'https',
    }),
    TextStyle,
    Color.configure({
      types: ['textStyle'],
    }),
    BackgroundColor.configure({
      types: ['textStyle'],
    }),
    TextAlign.configure({
      types: ['heading', 'paragraph'],
    }),
    Placeholder.configure({
      placeholder: () => options.placeholder.value || '',
    }),
    ...(profileConfig.allowAdvancedBlocks
      ? [CalloutBlock, StatusBlock, DateBlock, OpsColumns, OpsColumn]
      : []),
    ...(profileConfig.allowImages ? [Image] : []),
    ...(profileConfig.allowTables
      ? [
          Table.configure({
            resizable: true,
          }),
          TableRow,
          TableHeader,
          TableCell,
        ]
      : []),
  ];
}
