<script setup lang="ts">
  /**
   * 留存图卡片
   */
  import { computed } from 'vue';
  import { useI18n } from 'vue-i18n';
  import Chart1 from '@/components/Chart/chart1.vue';
  import BaseChartCard from './BaseChartCard.vue';
  import { generateRetentionConfig } from '../chartConfigs';
  import type { CardConfig, RetentionDataPoint } from '../types';

  interface Props {
    title: string;
    data: RetentionDataPoint[];
    config: CardConfig;
    height?: string | number;
    loading?: boolean;
    showToggle?: boolean;
  }

  const props = withDefaults(defineProps<Props>(), {
    height: 220,
    loading: false,
    showToggle: true,
  });

  const { t } = useI18n();

  // 是否有数据
  const hasData = computed(() => props.data && props.data.length > 0);

  // 生成图表配置
  const chartConfig = computed(() => {
    if (!hasData.value) return null;
    return generateRetentionConfig(props.data, props.config, t);
  });

  // 表格列配置
  const tableColumns = computed(() => [
    { title: t('analytics.common.day'), key: 'day_diff' },
    { title: t('analytics.common.retainedUsers'), key: 'retained_users' },
  ]);
</script>

<template>
  <BaseChartCard
    :title="title"
    :height="height"
    :loading="loading"
    :show-toggle="showToggle"
    :has-data="hasData"
  >
    <template #chart="{ height: h }">
      <Chart1 v-if="chartConfig" :config="chartConfig" :height="h" />
    </template>
    <template #table="{ maxHeight }">
      <n-data-table
        :columns="tableColumns"
        :data="data"
        :bordered="false"
        size="small"
        :max-height="maxHeight"
      />
    </template>
  </BaseChartCard>
</template>

<script lang="ts">
  export default {
    name: 'RetentionChartCard',
  };
</script>
