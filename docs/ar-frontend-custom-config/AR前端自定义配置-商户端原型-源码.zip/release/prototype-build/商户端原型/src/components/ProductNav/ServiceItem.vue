<template>
  <div class="service-item">
    <div class="service-item__main" @click="handleClick">
      <n-icon v-if="item.icon" class="service-item__icon" :size="16">
        <component :is="item.icon" />
      </n-icon>
      <span class="service-item__title">{{ t(item.title) }}</span>
      <n-icon
        v-if="hasTabs"
        class="service-item__arrow"
        :class="{ 'service-item__arrow--expanded': expanded }"
        :size="14"
        @click.stop="toggleExpand"
      >
        <ChevronDownOutline />
      </n-icon>
    </div>
    <!-- Tab list (expandable) -->
    <n-collapse-transition :show="expanded && hasTabs">
      <div class="service-item__tabs">
        <div
          v-for="tab in item.tabs"
          :key="tab.key"
          class="service-item__tab"
          @click="handleTabClick(tab.key)"
        >
          <span class="service-item__tab-dot"></span>
          <span class="service-item__tab-title">{{ t(tab.title) }}</span>
        </div>
      </div>
    </n-collapse-transition>
  </div>
</template>

<script setup lang="ts">
  import { computed, ref } from 'vue';
  import { useI18n } from 'vue-i18n';
  import { ChevronDownOutline } from '@vicons/ionicons5';
  import type { ServiceItem as ServiceItemType } from './types';

  const props = defineProps<{
    item: ServiceItemType;
  }>();

  const emit = defineEmits<{
    navigate: [routeName: string];
    navigateTab: [routeName: string, tabKey: string];
  }>();

  const { t } = useI18n();
  const expanded = ref(false);

  const hasTabs = computed(() => props.item.tabs && props.item.tabs.length > 0);

  const toggleExpand = () => {
    if (hasTabs.value) {
      expanded.value = !expanded.value;
    }
  };

  const handleClick = () => {
    if (hasTabs.value) {
      toggleExpand();
    } else {
      emit('navigate', props.item.key);
    }
  };

  const handleTabClick = (tabKey: string) => {
    emit('navigateTab', props.item.key, tabKey);
  };
</script>

<style lang="less" scoped>
  .service-item {
    &__main {
      display: flex;
      align-items: center;
      padding: 8px 12px;
      border-radius: 4px;
      cursor: pointer;
      transition: background-color 0.2s;

      &:hover {
        background-color: rgba(24, 160, 88, 0.08);
      }
    }

    &__icon {
      margin-right: 8px;
      color: #666;
      flex-shrink: 0;
    }

    &__title {
      flex: 1;
      font-size: 14px;
      color: #333;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }

    &__arrow {
      color: #999;
      transition: transform 0.2s;
      flex-shrink: 0;

      &--expanded {
        transform: rotate(180deg);
      }
    }

    &__tabs {
      padding-left: 36px;
      padding-bottom: 4px;
    }

    &__tab {
      display: flex;
      align-items: center;
      padding: 6px 12px;
      border-radius: 4px;
      cursor: pointer;
      transition: background-color 0.2s;

      &:hover {
        background-color: rgba(24, 160, 88, 0.08);
      }
    }

    &__tab-dot {
      width: 4px;
      height: 4px;
      border-radius: 50%;
      background-color: #999;
      margin-right: 8px;
      flex-shrink: 0;
    }

    &__tab-title {
      font-size: 13px;
      color: #666;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }
  }
</style>
