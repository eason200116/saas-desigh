// 商户字典：国家/币种/语言管理（总控端 admin 专属 · tenant_dictionary）功能说明书。
// 锚定 src/views/tenant/dictionary/index.vue + components/{Country,Currency,Language}Tab.vue +
// components/{Country,Currency,Language}FormModal.vue + components/data.ts 真实控件（R53 实证、不臆造）。
// 本文件为首次建档（此前该页从未有说明书，面板一直显示"待补充"）。三个 Tab 的 .vue 源码目前均无
// data-manual 属性，故本文件各 anchor 暂无法与页面控件产生点击高亮联动（后续若给页面补 data-manual
// 属性可联动，本次严格未改动这 6 个功能组件文件，故未一并补）。
//
// 2026-07-27（本次，R83 arv3-executor 执行；功能代码由他人完成、经总PM确认无误，本次为验证+
// R62 文档反补）：
// ① 三个新增/编辑弹窗内的下拉框（国家代码/时区/币种代码/语言代码）此前 DictSelect source='group'
//   取不到数据、下拉恒为空，改为 source='dynamic' 后从 src/components/DictSelect/data.ts 新增的
//   4 个字典常量（时区 45 项/国家 46 项/币种 52 项/语言 40 项）取数，问题修复。配套在
//   src/components/DictSelect/useDictionary.ts 的 DYNAMIC_FIELD_MAP 里为这 4 个字典键注册
//   { label:'label', value:'value' } 映射（这 4 个字典自身已是 { value, label } 形态，原样透传）。
// ② 语言管理 Tab 移除列表「操作」列（含唯一的「编辑」按钮及其弹窗调用逻辑），该 Tab 现仅保留顶部
//   「新增语言」入口，无编辑功能——产品既定决定，非缺陷。国家管理/币种管理两个 Tab 不受影响，仍各自
//   保留「编辑」入口。
// ③ 三个 Tab 列表「最后修改时间」列头统一由 common.updateTime 改为 common.last_modify_time
//   （与「最后修改人」common.last_modify_user 配套，R82 命名规范），仅列头 i18n key 变化，字段本身
//   （row.lastUpdateTime）与展示格式不变。

import type { PageManual } from '../types';

const manual: PageManual = {
  route: 'tenant_dictionary',
  title: '商户字典（国家/币种/语言）',
  overview:
    "「商户管理 › 配置管理」页（路由 tenant_dictionary，meta.roles:['admin']，仅总控端可见，商户端不出现该菜单），" +
    '维护三类全局字典——国家、币种、语言，供商户端各业务模块的下拉选择使用。页面为 3 个平级 Tab（国家管理/' +
    '币种管理/语言管理，默认激活国家管理），每个 Tab 各自独立的列表 + 新增/编辑弹窗，互不影响、无跨 Tab 联动，' +
    '页面本身也无搜索筛选区。国家管理、币种管理两个 Tab 结构一致：列表顶部「新增」按钮 + 末列「操作」列的' +
    '「编辑」按钮（withOpLogCorner 包裹，悬浮显示操作日志角标）；语言管理 Tab 仅有顶部「新增」按钮，无编辑' +
    '入口（2026-07-27 本次改动移除，见下）。三个 Tab 的新增/编辑弹窗均为同一组件（isEdit 由是否传入 detail' +
    ' 判定），弹窗宽度统一 600px。2026-07-27 本次三点改动：①三个弹窗内的编码类下拉框由取不到数据的' +
    " source='group' 修复为 source='dynamic'；②语言管理 Tab 移除编辑入口；③三个 Tab 列表「最后修改时间」" +
    '列头 i18n key 统一。',
  items: [
    // ============ 国家管理 Tab（CountryTab.vue + CountryFormModal.vue）============
    {
      anchor: 'country_col_countryCode',
      name: '【国家管理】国家代码列',
      group: '列',
      interaction: '只读 Tag（NTag info 蓝框），不可点。',
      dataSource: '行数据 countryCode；空值兜底显示"--"。',
    },
    {
      anchor: 'country_col_countryName',
      name: '【国家管理】国家名称列',
      group: '列',
      interaction: '纯文本展示，不可点。',
      dataSource: '行数据 countryName。',
    },
    {
      anchor: 'country_col_timeZoneCode',
      name: '【国家管理】时区代码列',
      group: '列',
      interaction: '只读 Tag（NTag info 蓝框），不可点。',
      dataSource: '行数据 timeZoneCode；空值兜底显示"--"。',
    },
    {
      anchor: 'country_col_timeZone',
      name: '【国家管理】时区列',
      group: '列',
      interaction: '纯文本展示，不可点。',
      dataSource: '行数据 timeZone（如"印度(+5:30)"这类中文展示名）。',
    },
    {
      anchor: 'country_col_phoneArea',
      name: '【国家管理】手机区号列',
      group: '列',
      interaction: '只读 Tag（NTag warning 橙框），不可点。',
      dataSource: '行数据 phoneArea；空值兜底显示"--"。',
    },
    {
      anchor: 'country_col_phoneLen',
      name: '【国家管理】手机号长度列',
      group: '列',
      interaction: '纯文本展示，不可点。',
      dataSource:
        '行数据 phoneLen；由新增/编辑弹窗提交时拼接而成——最小长度等于最大长度时存单值（如"10"），' +
        '不等时存"最小-最大"区间（如"7-10"）。',
    },
    {
      anchor: 'country_act_add',
      name: '【国家管理】新增（顶部）',
      group: '操作',
      interaction: '点击打开「新增国家」弹窗（CountryFormModal，宽 600px）。',
      logic: '提交成功（api.tenant.countryAdd 返回 code:0）后弹窗关闭 + 触发主表 reload。',
    },
    {
      anchor: 'country_act_edit',
      name: '【国家管理】编辑（行操作）',
      group: '操作',
      interaction:
        '列表末列「操作」列的「编辑」按钮，withOpLogCorner 包裹（悬浮显示"国家配置"操作日志角标，' +
        '角标标题取该行 countryName）。',
      dataSource: '点击行 = 该行完整记录，作为 detail 传给 CountryFormModal。',
      logic:
        '打开「编辑国家」弹窗，isEdit=true（由 detail?.countryCode 判定）；提交成功（countryUpdate 返回' +
        ' code:0）后弹窗关闭 + 触发主表 reload。',
    },
    {
      anchor: 'country_form_countryCode',
      name: '【国家管理】弹窗 · 国家代码',
      group: '操作',
      interaction:
        'DictSelect 下拉，filterable + clearable，选项展示格式"{代码} - {中文名}"（renderCodeLabel）。' +
        '编辑态只读（disabled=isEdit）。选中后自动带出「国家名称」（@change 回填 formData.countryName）。',
      dataSource:
        "2026-07-27 本次改动：source 由 'group'（取不到数据，下拉恒为空）改为 'dynamic'，现从" +
        ' src/components/DictSelect/data.ts 的 COUNTRY_DICTIONARY_LIST（46 项，如 IND/BRA/THA…）取数。',
      logic: '选中值同时驱动 formData.countryCode 与 formData.countryName 两个字段。',
      limit: '必填（表单校验 required，change 触发）。',
      edge: "修复前（source='group'）该下拉点开无任何选项可选，是本次改动要修复的核心问题。",
    },
    {
      anchor: 'country_form_timeZone',
      name: '【国家管理】弹窗 · 时区',
      group: '操作',
      interaction:
        'DictSelect 下拉，filterable + clearable，选项展示格式"{代码} - {中文名}"（renderCodeLabel）。' +
        '新增/编辑两态均可编辑。',
      dataSource:
        "2026-07-27 本次改动：source 由 'group'（取不到数据）改为 'dynamic'，现从" +
        ' src/components/DictSelect/data.ts 的 TIME_ZONE_DICTIONARY_LIST（45 项，value 为 IANA 时区名如' +
        ' Asia/Kolkata，label 为"国家名(+UTC偏移)"如"印度(+5:30)"）取数。',
      limit: '必填（表单校验 required，blur 触发）。',
      edge: '修复前同「国家代码」，下拉恒为空。',
    },
    {
      anchor: 'country_form_phoneArea',
      name: '【国家管理】弹窗 · 手机区号',
      group: '操作',
      interaction: '文本输入框，受 INPUT_PRESETS.name 字符约束限制。',
      dataSource: '用户输入。',
      limit: '必填（blur 触发）。',
    },
    {
      anchor: 'country_form_phoneLen',
      name: '【国家管理】弹窗 · 手机号长度',
      group: '操作',
      interaction: '两个数字输入框并排（最小~最大），各自范围 1~15。',
      dataSource: '用户输入。',
      logic:
        '提交时拼接：最小等于最大存单值，否则存"最小-最大"区间字符串（见 country_col_phoneLen）。',
      limit: '两格均必填；校验最小值不能大于最大值（否则报错拦截提交）。',
    },

    // ============ 币种管理 Tab（CurrencyTab.vue + CurrencyFormModal.vue）============
    {
      anchor: 'currency_col_currencyCode',
      name: '【币种管理】币种代码列',
      group: '列',
      interaction: '只读 Tag（NTag info 蓝框），不可点。',
      dataSource: '行数据 currencyCode；空值兜底显示"--"。',
    },
    {
      anchor: 'currency_col_currencyName',
      name: '【币种管理】币种名称列',
      group: '列',
      interaction: '纯文本展示，不可点。',
      dataSource: '行数据 currencyName。',
    },
    {
      anchor: 'currency_col_currencyMarkCode',
      name: '【币种管理】币种符号列',
      group: '列',
      interaction: '只读 Tag（NTag warning 橙框），不可点。',
      dataSource: '行数据 currencyMarkCode；空值兜底显示"--"。',
    },
    {
      anchor: 'currency_col_currencyRate',
      name: '【币种管理】汇率列',
      group: '列',
      interaction: '纯文本展示，不可点。',
      dataSource: '行数据 currencyRate，含义为"USDT → 法币"汇率（列头 i18n 文案已注明）。',
    },
    {
      anchor: 'currency_act_add',
      name: '【币种管理】新增（顶部）',
      group: '操作',
      interaction: '点击打开「新增币种」弹窗（CurrencyFormModal，宽 600px）。',
      logic: '提交成功（currencyAdd 返回 code:0）后弹窗关闭 + 触发主表 reload。',
    },
    {
      anchor: 'currency_act_edit',
      name: '【币种管理】编辑（行操作）',
      group: '操作',
      interaction:
        '列表末列「操作」列的「编辑」按钮，withOpLogCorner 包裹（悬浮显示"货币配置"操作日志角标，' +
        '角标标题取该行 currencyName）。',
      dataSource: '点击行 = 该行完整记录，作为 detail 传给 CurrencyFormModal。',
      logic:
        '打开「编辑币种」弹窗，isEdit=true（由 detail?.currencyCode 判定）；提交成功（currencyUpdate' +
        ' 返回 code:0）后弹窗关闭 + 触发主表 reload。',
    },
    {
      anchor: 'currency_form_currencyCode',
      name: '【币种管理】弹窗 · 币种代码',
      group: '操作',
      interaction:
        'DictSelect 下拉，filterable + clearable，选项展示格式"{代码} - {中文名}"（renderCodeLabel）。' +
        '编辑态只读（disabled=isEdit）。选中后自动带出「币种名称」（@change 回填 formData.currencyName）。',
      dataSource:
        "2026-07-27 本次改动：source 由 'group'（取不到数据）改为 'dynamic'，现从" +
        ' src/components/DictSelect/data.ts 的 CURRENCY_DICTIONARY_LIST（52 项，如 INR/USD/USDT…）取数。',
      logic: '选中值同时驱动 formData.currencyCode 与 formData.currencyName 两个字段。',
      limit: '必填（change 触发）。',
      edge: '修复前该下拉点开无任何选项可选。提交时仅传 currencyCode/currencyRate 两个字段（currencyName 不随表单一起提交，非本次改动引入，如实记录）。',
    },
    {
      anchor: 'currency_form_currencyRate',
      name: '【币种管理】弹窗 · 汇率',
      group: '操作',
      interaction: '数字输入框，精度 6 位小数，最小值 0。',
      dataSource: '用户输入；新增态默认值 1。',
      limit: '必填（数字类型校验，blur 触发）。',
    },

    // ============ 语言管理 Tab（LanguageTab.vue + LanguageFormModal.vue）============
    {
      anchor: 'language_col_languageCode',
      name: '【语言管理】语言代码列',
      group: '列',
      interaction: '只读 Tag（NTag info 蓝框），不可点。',
      dataSource: '行数据 languageCode；空值兜底显示"--"。',
    },
    {
      anchor: 'language_col_languageName',
      name: '【语言管理】语言名称列',
      group: '列',
      interaction: '纯文本展示，不可点。',
      dataSource: '行数据 languageName。',
    },
    {
      anchor: 'language_act_add',
      name: '【语言管理】新增（顶部）',
      group: '操作',
      interaction:
        '点击打开「新增语言」弹窗（LanguageFormModal，宽 600px），本 Tab 唯一的写入入口。',
      logic: '提交成功（languageAdd 返回 code:0）后弹窗关闭 + 触发主表 reload。',
      edge:
        '2026-07-27 本次改动：本 Tab 列表末列「操作」列（含唯一的「编辑」按钮）已整体移除' +
        '（action-column、createActionColumn/withOpLogCorner 的 import、actionColumn 常量、handleEdit ' +
        '函数全部删除），故本 Tab 现在列表侧完全没有编辑入口——仅能新增，不能编辑已有记录，产品既定决定。' +
        'LanguageFormModal.vue 组件本身仍保留 isEdit/detail/languageUpdate 的完整编辑态代码分支（未被删除），' +
        '只是当前列表侧没有任何地方会带 detail 调用它，故编辑态在本页实际处于未使用状态。',
    },
    {
      anchor: 'language_form_languageCode',
      name: '【语言管理】弹窗 · 语言代码',
      group: '操作',
      interaction:
        'DictSelect 下拉，filterable + clearable，选项展示格式"{代码} - {中文名}"（renderCodeLabel）。' +
        '编辑态只读（disabled=isEdit，当前列表侧不会触发编辑态，见 language_act_add 的 edge 说明）。' +
        '选中后自动带出「语言名称」（@change 回填 formData.languageName）。',
      dataSource:
        "2026-07-27 本次改动：source 由 'group'（取不到数据）改为 'dynamic'，现从" +
        ' src/components/DictSelect/data.ts 的 LANGUAGE_DICTIONARY_LIST（40 项，如 en/zh/hi…）取数。',
      logic: '选中值同时驱动 formData.languageCode 与 formData.languageName 两个字段。',
      limit: '必填（change 触发）。',
      edge: '修复前该下拉点开无任何选项可选。',
    },
  ],

  // ============ 字段介绍 tab（按 Tab 分组，列序照各自列表；仅列表列 + 定义）============
  fields: [
    { name: '【国家管理】国家代码', def: '该国家的代码标识（如 IND）。' },
    { name: '【国家管理】国家名称', def: '该国家的中文名称（如"印度"）。' },
    { name: '【国家管理】时区代码', def: '该国家关联的 IANA 时区标识（如 Asia/Kolkata）。' },
    {
      name: '【国家管理】时区',
      def: '该国家所属时区的中文展示名，含 UTC 偏移量（如"印度(+5:30)"）。',
    },
    { name: '【国家管理】手机区号', def: '该国家的手机号国际区号（如 91）。' },
    {
      name: '【国家管理】手机号长度',
      def: '该国家手机号的合法位数，单值或"最小-最大"区间（如"10"或"7-10"）。',
    },
    { name: '【国家管理】创建人', def: '创建该国家字典记录的操作账号。' },
    { name: '【国家管理】创建时间', def: '该国家字典记录的创建时间。' },
    {
      name: '【国家管理】最后修改人',
      def: '最近一次更新该国家字典记录的操作账号（common.last_modify_user）。',
    },
    {
      name: '【国家管理】最后修改时间',
      def: '该国家字典记录最近一次更新的时间。2026-07-27 本次改动：列头 i18n key 由 common.updateTime 统一改为 common.last_modify_time（与「最后修改人」配套，R82 命名规范），仅列头文案 key 变化，字段本身与展示格式不变。',
    },
    { name: '【币种管理】币种代码', def: '该币种的代码标识（如 INR）。' },
    { name: '【币种管理】币种名称', def: '该币种的中文名称（如"印度卢比"）。' },
    { name: '【币种管理】币种符号', def: '该币种的展示符号标识。' },
    { name: '【币种管理】汇率', def: '该币种相对 USDT 的兑换汇率（USDT → 法币方向）。' },
    { name: '【币种管理】创建人', def: '创建该币种字典记录的操作账号。' },
    { name: '【币种管理】创建时间', def: '该币种字典记录的创建时间。' },
    {
      name: '【币种管理】最后修改人',
      def: '最近一次更新该币种字典记录的操作账号（common.last_modify_user）。',
    },
    {
      name: '【币种管理】最后修改时间',
      def: '该币种字典记录最近一次更新的时间。2026-07-27 本次改动：列头 i18n key 统一为 common.last_modify_time，口径同「国家管理」。',
    },
    { name: '【语言管理】语言代码', def: '该语言的代码标识（如 en、zh）。' },
    { name: '【语言管理】语言名称', def: '该语言的中文名称（如"英语"）。' },
    { name: '【语言管理】创建人', def: '创建该语言字典记录的操作账号。' },
    { name: '【语言管理】创建时间', def: '该语言字典记录的创建时间。' },
    {
      name: '【语言管理】最后修改人',
      def: '最近一次更新该语言字典记录的操作账号（common.last_modify_user）。',
    },
    {
      name: '【语言管理】最后修改时间',
      def: '该语言字典记录最近一次更新的时间。2026-07-27 本次改动：列头 i18n key 统一为 common.last_modify_time，口径同「国家管理」。',
    },
  ],
};

export default manual;
