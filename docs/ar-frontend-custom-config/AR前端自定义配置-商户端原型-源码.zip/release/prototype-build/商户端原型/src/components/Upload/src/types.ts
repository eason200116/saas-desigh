import type { UploadProps } from 'naive-ui';
/**
 * 图片信息
 */
export interface ImageInfo {
  /** 图片标识 (文件名或路径) */
  key: string;
  /** 完整 URL */
  url: string;
}

/**
 * 上传结果
 */
export interface UploadResult {
  /** 文件标题/名称 */
  title: string;
  /** 文件 URL */
  src: string;
}

/**
 * 图片尺寸信息
 */
export interface ImageDimensions {
  /** 宽度 (像素) */
  width: number;
  /** 高度 (像素) */
  height: number;
  /** 文件大小 (字节) */
  size: number;
}

/**
 * BasicUpload 组件 Props
 */
export interface BasicUploadProps extends /* @vue-ignore */ Partial<UploadProps> {
  /** 接受的文件类型 */
  accept?: string;
  /** 帮助文本 */
  helpText?: string;
  /** 最大文件大小 (KB) */
  maxSize?: number;
  /** 最大上传数量 */
  maxNumber?: number;
  /** 图片列表值 */
  value?: string[];
  /** 上传框宽度 (像素) */
  width?: number;
  /** 上传框高度 (像素) */
  height?: number;
  /** 预览框宽度 (可选，默认同 width) */
  previewWidth?: number;
  /** 是否验证图片尺寸 */
  verifySize?: boolean;
  /** OSS 文件类型 */
  fileType?: any;
  /** 是否返回完整路径 */
  fullPath?: boolean;
  /** 是否只读模式 */
  readonly?: boolean;
  /** 预览/回显时使用的商户 ID，用于解析租户 OSS 域名 */
  tenantId?: string | number | null;
  /** 自定义上传路径 */
  customPath?: string;
  /** 上传前的额外验证函数 */
  beforeUploadExtra?: (file: File, dimensions: ImageDimensions) => boolean | Promise<boolean>;
  /** 是否启用裁剪 */
  enableCrop?: boolean;
  /** 裁剪比例 */
  cropAspectRatio?: number;
  /** 裁剪输出宽度 */
  cropOutputWidth?: number;
  /** 裁剪输出高度 */
  cropOutputHeight?: number;
  /** 裁剪弹窗标题 */
  cropTitle?: string;
}

/**
 * BasicUpload 组件实例方法
 */
export interface BasicUploadInstance {
  /** 设置图片列表 */
  setImages: (images: string[]) => void;
  /** 获取图片列表 */
  getImages: () => string[];
  /** 清空图片列表 */
  clear: () => void;
}

/**
 * 默认接受的图片类型
 */
export const DEFAULT_ACCEPT = 'jpg,png,jpeg,svg,gif,webp';

/**
 * Accept presets for common use cases
 */
export const ACCEPT_PRESETS = {
  /** Default image types (with gif): jpg,png,jpeg,svg,gif,webp */
  IMAGE: DEFAULT_ACCEPT,
  /** Static image types (no gif): png,jpg,jpeg,svg,webp */
  STATIC: 'png,jpg,jpeg,svg,webp',
  /** Image types with ico support (for favicon etc.): png,ico,jpg,jpeg,svg,webp */
  ICON: 'png,ico,jpg,jpeg,svg,webp',
  /** Photo only types (no vector/animation): jpg,png,jpeg,webp */
  PHOTO: 'jpg,png,jpeg,webp',
} as const;

/**
 * 默认最大文件大小 (10MB in KB)
 */
export const DEFAULT_MAX_SIZE = 10240;

/**
 * 默认尺寸
 */
export const DEFAULT_SIZE = 80;
