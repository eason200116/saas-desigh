<template>
  <div class="merchant-switch-bar">
    <span class="merchant-switch-bar__label">
      <span v-if="required" class="merchant-switch-bar__req">*</span>商户
    </span>
    <n-select
      :value="value ?? undefined"
      :options="tenantOptions"
      filterable
      size="small"
      class="merchant-switch-bar__sel"
      placeholder="请选择商户"
      @update:value="onChange"
    />
    <span class="merchant-switch-bar__hint">切换商户查看 / 配置其对应参数</span>
    <div v-if="$slots.extra" class="merchant-switch-bar__extra">
      <slot name="extra" />
    </div>
    <div v-if="$slots.actions" class="merchant-switch-bar__actions">
      <slot name="actions" />
    </div>
  </div>
</template>

<script lang="ts" setup>
  // 配置表单页通用「商户切换条」：顶部选商户，切换后由宿主页按商户加载/保存配置。
  // 原型无后端：切换仅触发宿主 load()，mock 返回演示数据。
  import { onMounted } from 'vue';
  import { NSelect } from 'naive-ui';
  import { useTenantOptions } from '@/hooks';

  defineOptions({ name: 'MerchantSwitchBar' });

  const props = defineProps<{ value?: number | null; required?: boolean }>();
  const emit = defineEmits<{
    (e: 'update:value', v: number): void;
    (e: 'change', v: number): void;
  }>();

  const { tenantOptions, defaultTenantId } = useTenantOptions();

  function onChange(v: number) {
    emit('update:value', v);
    emit('change', v);
  }

  // 首次进入：若未指定商户，默认选当前用户首个商户
  onMounted(() => {
    if ((props.value === undefined || props.value === null) && defaultTenantId.value != null) {
      onChange(defaultTenantId.value as number);
    }
  });
</script>

<style lang="less" scoped>
  .merchant-switch-bar {
    // 冻结配置商户行：滚动时固定在内容区顶部（系统配置各类型统一交互）
    position: sticky;
    top: 0;
    z-index: 20;
    display: flex;
    align-items: center;
    gap: 10px;
    margin: 0 0 12px;
    padding: 10px 14px;
    background: #f8fafc;
    border: 1px solid #e2e8f0;
    border-radius: 8px;

    &__label {
      font-size: 13px;
      font-weight: 600;
      color: #1e293b;
    }
    // 必填红星（opt-in·仅 required=true 时显示，如协议管理「配置商户」）
    &__req {
      color: #dc2626;
      margin-right: 2px;
      font-weight: 600;
    }
    &__sel {
      width: 240px;
    }
    &__hint {
      font-size: 12px;
      color: #94a3b8;
    }
    &__extra {
      display: flex;
      align-items: center;
      gap: 8px;
    }
    &__actions {
      margin-left: auto;
      display: flex;
      align-items: center;
      gap: 8px;
    }
  }
</style>
