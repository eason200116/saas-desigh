<template>
  <n-popover trigger="manual" placement="bottom" :show="showEdit" @clickoutside="showEdit = false">
    <template #trigger>
      <n-button :disabled="disabled" size="small" quaternary type="info" @click="openEdit">
        {{ displayValue }}{{ suffix }}
      </n-button>
    </template>
    <div class="number-edit">
      <n-input-number
        ref="inputRef"
        v-model:value="editValue"
        :min="computedMin"
        :max="computedMax"
        :precision="computedPrecision"
        :show-button="false"
        size="small"
        :placeholder="t('common.pleaseInput')"
        v-bind="props.props"
        @keyup.enter="handleConfirm"
      >
        <template v-if="suffix" #suffix>{{ suffix }}</template>
      </n-input-number>
      <n-space justify="end" size="small" class="mt-2">
        <n-button size="tiny" @click="showEdit = false">
          {{ t('common.cancel') }}
        </n-button>
        <n-button size="tiny" type="primary" @click="handleConfirm">
          {{ t('common.confirm') }}
        </n-button>
      </n-space>
    </div>
  </n-popover>
</template>

<script setup lang="ts">
  import { ref, computed, nextTick } from 'vue';
  import { useI18n } from 'vue-i18n';
  import type { SettingRule } from '../types';

  const props = defineProps<{
    value?: number | string | null;
    disabled?: boolean;
    suffix?: string;
    rules?: SettingRule[];
    props?: Record<string, unknown>;
  }>();

  const emit = defineEmits<{
    (e: 'confirm', value: number): void;
  }>();

  const { t } = useI18n();

  const showEdit = ref(false);
  const editValue = ref<number | null>(null);
  const inputRef = ref();

  const displayValue = computed(() => props.value ?? 0);

  const computedMin = computed(() => props.rules?.[0]?.min ?? undefined);
  const computedMax = computed(() => props.rules?.[0]?.max ?? undefined);
  const computedPrecision = computed(() => (props.rules?.[0]?.integer ? 0 : 2));

  const openEdit = () => {
    if (props.disabled) return;
    editValue.value = Number(props.value) || 0;
    showEdit.value = true;
    nextTick(() => {
      inputRef.value?.focus();
    });
  };

  const handleConfirm = () => {
    if (editValue.value !== null) {
      emit('confirm', editValue.value);
    }
    showEdit.value = false;
  };
</script>

<style scoped>
  .number-edit {
    width: 160px;
  }
</style>
