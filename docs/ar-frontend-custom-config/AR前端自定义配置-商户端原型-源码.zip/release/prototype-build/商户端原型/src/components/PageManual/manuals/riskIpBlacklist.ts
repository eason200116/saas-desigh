// 会员IP黑名单（商户端 tenant · riskControl_ipBlacklist）功能说明书。
// 锚定 src/views/system/ipBlacklist/index.vue + data.ts + components/BlacklistFormModal.vue 真实控件（R53 实证、不臆造）。
// 路由挂在「风控管理·异常检测」分组下（原属系统管理，2026-07-01 迁运营管理，近期再迁风控管理），
// 组件文件因"迁路由不搬文件夹"历史惯例仍留在 views/system/ipBlacklist/。

import type { PageManual } from '../types';

const manual: PageManual = {
  route: 'riskControl_ipBlacklist',
  title: '会员IP黑名单',
  overview:
    '商户端「风控管理 › IP黑名单」页，用于维护会员访问黑名单：按 IP 地址 + 封禁类型（禁止登录/禁止注册）拉黑限制。支持单条新增（弹窗，可一次填多个 IP 用逗号/换行分隔，各自入库一条记录）、批量导入（独立弹窗，粘贴或上传 CSV/TXT，本地实时校验 IPv4 格式并去重，单次识别上限500条）、编辑（仅可改封禁类型/原因/备注/状态，商户与IP创建后锁定不可再改）、删除。核实代码后如实记录 2 处真实缺陷（均未修复，只记录）：①组件 `defineOptions` 名仍是迁移前的 `operations_ipBlacklist`（index.vue:159），与当前路由 name `riskControl_ipBlacklist` 不一致——路由 `meta.keepAlive:true` 且 `router/guards.ts` 按路由 name 把 `riskControl_ipBlacklist` 塞进 `keep-alive` 的 `include` 列表，但 Vue `<keep-alive :include>` 实际按组件自身注册名匹配，两者对不上导致本页 keepAlive 实际不生效（每次离开再进来筛选条件/分页会被重置），是迁移时命名漏改，非"故意不缓存"；②mock 字段 `hitCount`（命中次数）与对应 i18n 文案 `system.ipBlacklist.hit_count`（"命中次数"）都已就绪，但列表 `tableColumns` 里从未展示这一列，是有数据、有文案但未接入 UI 的孤儿字段。',
  items: [
    // ============ 搜索区 ============
    {
      anchor: 'merchant',
      name: '商户',
      group: '搜索',
      interaction:
        '下拉多选（MerchantFilterSelect 默认多选模式），顶部含「全部」选项，选「全部」与选具体商户互斥（选一个会清空另一个）。',
      dataSource: '全站商户列表（角色默认全量商户）。',
      logic:
        '按选中商户集合过滤黑名单记录（matchMerchantFilter：命中「全部」或未选值时不过滤，否则按记录 tenantId 是否落在所选集合内匹配）。',
      limit:
        '选填、可清空、可搜索过滤选项；值为空/清空时组件级自动回填商户列表第一个商户（全站 MerchantFilterSelect 通用默认值兜底，非本页定制）。',
      edge:
        '⚠️ 核实代码后发现：本搜索项与「新增/编辑/批量导入」三个弹窗内的商户下拉不是同一控件也不同文案——弹窗内是普通单选 n-select（无「全部」选项，disabled 于编辑态），本搜索项是 MerchantFilterSelect 多选；i18n label 也不同，本搜索项用 common.merchant（"商户"），三个弹窗统一用 system.ipBlacklist.merchant（"封禁商户"），同一概念两种叫法，如实记录、不擅自统一。',
    },
    {
      anchor: 'ip',
      name: 'IP地址',
      group: '搜索',
      interaction: '文本输入（单行）。',
      dataSource: '用户输入。',
      logic: '按 IP 字符串做 includes 子串匹配（非精确相等、非网段/前缀匹配），如输入"45.155"能命中"45.155.205.231"。',
      limit:
        '选填；字符级仅允许数字/点/冒号/十六进制字符（inputProps(\'ip\')，maxlength 45，字符集兼容 IPv6 书写但本页业务数据实际只有 IPv4）。',
    },
    {
      anchor: 'remark',
      name: '原因/备注',
      group: '搜索',
      interaction: '文本输入（单行）。',
      dataSource: '用户输入。',
      logic:
        '同时对「拉黑原因」reason 与「备注」remark 两个字段做不区分大小写的子串匹配，命中任一即算匹配——并非字面意义只搜备注，label 已按实际行为标注为"原因/备注"。',
      limit: '选填；最多 50 字（inputProps(\'searchKw\')）。',
    },
    {
      anchor: 'banType',
      name: '封禁类型',
      group: '搜索',
      interaction: '下拉多选，超出宽度的选中标签折叠为数字（maxTagCount:\'responsive\'）。',
      dataSource: '固定 2 项：禁止登录(1) / 禁止注册(2)。',
      logic: '按行 banType 数组与所选类型集合是否有交集过滤（.some 命中即算）；一条记录可同时含多个封禁类型。',
      limit: '选填，不选=不按类型筛。',
    },
    {
      anchor: 'state',
      name: '状态',
      group: '搜索',
      interaction: '下拉单选。',
      dataSource: '固定 3 项：全部 / 开启（对应"拉黑生效"）/ 关闭（对应"已解除"）。',
      logic: '精确匹配 state 字段（1/0）；不选=全部，不按状态筛。',
    },

    // ============ 操作 ============
    {
      anchor: 'btn_add',
      name: '新增（表格左上角按钮）',
      group: '操作',
      interaction:
        '点表格左上角"新增"打开弹窗（BlacklistFormModal，宽600px，标题"新增会员IP黑名单"）；打开前会先关闭批量导入弹窗、清空编辑态。',
      dataSource: '弹窗内商户下拉选项来自 useTenantOptions()；商户默认值待该 hook 就绪后一次性回填第一个可用商户。',
      logic:
        '弹窗字段：商户（单选下拉，必填）/ IP地址（多行文本框，3~6行自适应，支持一次填多个IP用中文逗号/英文逗号/换行分隔，逐个校验、逐条各自入库）/ 封禁类型（复选框，禁止登录+禁止注册可都选）/ 拉黑原因（单行文本，必填，最多50字）/ 备注（多行文本，选填，最多100字）/ 状态开关（新增默认开启）。确认后调用 ipBlacklistAdd，按 IP 列表逐条 unshift 进底层数组——真实新增，reload 后能看到。',
      limit: '商户必选；IP地址必填且每个都需通过 IPv4 格式校验（校验失败会提示具体是哪个IP不合法）；封禁类型至少选一项；拉黑原因必填。',
    },
    {
      anchor: 'btn_batchImport',
      name: '批量导入（表格左上角按钮）',
      group: '操作',
      interaction:
        '点表格左上角"批量导入"打开独立弹窗（宽600px，标题"批量导入会员IP黑名单"）；打开前会先关闭新增/编辑弹窗，并把批量表单重置为干净状态（不残留上次输入）。',
      dataSource:
        '弹窗内商户下拉选项同样来自 useTenantOptions()（与新增弹窗共用同一份 tenantOptions，但两个弹窗互相独立、互不联动）。',
      logic:
        '弹窗字段：商户（单选下拉，必填，校验是手写在 confirmBatchImport 函数里的 message.warning 提示，不是走 n-form rules）/ IP列表文本框（6行，最多5000字，支持逗号/分号/空格/换行混合分隔，实时识别合法IPv4并去重，单次识别上限500条，识别数与忽略数实时显示在文本框下方）/「选择文件」按钮（仅接受 .csv/.txt，读取内容追加到文本框、不覆盖已有）/「下载导入模板」按钮（本地生成含表头"IP地址"+两行示例IP的CSV并触发浏览器下载，不发请求）/封禁类型（复选框，默认勾选"禁止登录"）/封禁原因（单行文本，选填，留空用默认值"批量导入"）/备注（多行文本，选填，最多100字）。确认导入前若未识别到有效IP或未选商户会分别提示拦截；成功后按识别出的每个IP各 unshift 一条新记录（真实写入），并提示"成功导入 N 条"。',
      limit: '识别到的有效IP列表不能为空；商户必选；其余字段选填。',
      edge:
        '⚠️ 若原样重新上传「下载导入模板」生成的CSV文件，文件首行表头文字"IP地址"会被当作一个待识别 token，因不是合法IPv4格式被自动计入"忽略"计数、不会报错中断，只是不会被当成一条黑名单记录——属优雅降级，非缺陷。',
    },
    {
      anchor: 'act_edit',
      name: '编辑（行操作按钮）',
      group: '操作',
      interaction:
        '点行内"编辑"，打开同一个 BlacklistFormModal（标题变为"编辑会员IP黑名单"），回填该行数据；商户下拉与IP地址文本框均被禁用（disabled），不可修改，IP文本框同时收起为单行高度。',
      dataSource: '直接用当前行内存数据回填，未单独请求详情接口。',
      logic:
        '仅封禁类型/拉黑原因/备注/状态开关四项可编辑；确认后调用 ipBlacklistUpdate，真实写回底层数组对应记录（reload 后能看到修改结果，最后修改人/最后修改时间同步更新）。',
      limit: '拉黑原因必填；封禁类型至少选一项。',
      edge:
        '⚠️ 核实代码后发现：表单校验器 ipValidator 里有"编辑态若一次填了多个IP要报错"的分支（ip_edit_single_only），但编辑态IP文本框本身已被禁用，用户无法在编辑态修改出多个IP，这条校验分支在当前UI下是永远不会被触发的死分支，如实记录、非本次引入。',
    },
    {
      anchor: 'act_delete',
      name: '删除（行操作按钮）',
      group: '操作',
      interaction: '点行内"删除"，createActionColumn 内置 delete 语义按钮，点击先弹二次确认框。',
      logic: '确认后调用 ipBlacklistDelete，真实从底层数组 splice 掉该行（reload 后条数真实减少）。',
    },
  ],

  // ============ 字段介绍 tab（列序照页面 tableColumns 真实顺序；仅列表列 + 定义）============
  fields: [
    {
      name: '商户',
      def: '该条黑名单记录归属的商户（renderTenantTag，"商户号(商户名)"标签展示）；一条记录仅归属一个商户（tenantId 为单值非数组）。',
    },
    { name: 'IP地址', def: '被拉黑限制的IPv4地址。' },
    { name: '封禁类型', def: '该IP被限制的行为，标签展示，可同时含多个：禁止登录（红色）/ 禁止注册（橙色）。' },
    { name: '拉黑原因', def: '新增/批量导入时填写的拉黑理由，纯文字说明。' },
    { name: '备注', def: '补充说明信息，为空展示"--"。' },
    { name: '创建人', def: '创建该条黑名单记录的操作人账号。' },
    { name: '创建时间', def: '该条记录的创建时间，按所属商户时区显示。' },
    { name: '最后修改人', def: '最近一次编辑该记录的操作人账号。' },
    { name: '最后修改时间', def: '最近一次编辑该记录的时间，按所属商户时区显示。' },
    {
      name: '状态',
      def: '当前是否拉黑生效：开启=拉黑生效中，关闭=已解除；只读展示，需通过「编辑」弹窗里的状态开关修改。',
    },
  ],
};

export default manual;
