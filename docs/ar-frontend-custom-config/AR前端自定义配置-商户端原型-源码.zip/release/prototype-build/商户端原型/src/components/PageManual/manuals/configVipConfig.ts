// VIP配置（商户端 tenant · configCenter_vipConfig）功能说明书。
// 锚定 src/views/config/vipConfig/index.vue + shared/ConfigWorkspaceBar.vue + ConfigSideNav.vue +
// MerchantConfigLog.vue + data.ts 真实控件（R53 实证、不臆造）。
// 页面无 ProSearchForm/ProCrudTable，全自研 UI；商户配置 tab 与模版配置 tab（ConfigWorkspaceBar，
// template-only+versioning+group-by-currency 模式）共用等级表/经验值编辑区。

import type { PageManual } from '../types';

const manual: PageManual = {
  route: 'configCenter_vipConfig',
  title: 'VIP配置',
  overview:
    '商户端「配置中心 › VIP配置」页，融合方案：顶部「商户配置」「模版配置」2个tab。商户配置tab先选货币' +
    '再多选商户(chip)，配置来源=应用模版配置/自定义(仅单选商户可自定义)；模版配置tab是可增删改的模版画廊，' +
    '模版可套用到多个商户。两个tab共用同一套VIP等级表(11级·14项数值)+经验值兑换配置，行内编辑、保存前二次' +
    '确认弹窗预览、超上限红框拦截。左侧ConfigSideNav为配置中心通用导航(目前仅收录VIP配置/返佣配置2个入口，' +
    '返佣配置等其余页尚未加入)。版本化：商户配置版本与模版版本各自minor自增，模版有更新时商户chip标"🔔有新版"。' +
    '2026-07-22核实代码未发现真实缺陷(全部保存路径均真实落库到LEVEL_STORE/EXP_STORE/TEMPLATE_DATA)。',
  items: [
    // ===== 商户配置 tab =====
    {
      anchor: 'tab_merchant',
      name: '商户配置（tab）',
      group: '搜索',
      interaction: '默认选中的tab。',
    },
    {
      anchor: 'tab_template',
      name: '模版配置（tab）',
      group: '搜索',
      interaction: '点击切换；离开该tab会自动退出新建/编辑模版态，避免草稿残留。',
    },
    {
      anchor: 'mchCur',
      name: '货币（商户配置tab）',
      group: '搜索',
      interaction: '横向滚动chip单选，支持鼠标拖动+两端箭头；切换货币会清空已选商户。',
      logic: '12个国家/货币码，先选货币才能选商户(同货币商户才在同一chip列表里)。',
    },
    {
      anchor: 'mchFilter',
      name: '搜索商户',
      group: '搜索',
      interaction: '文本框，按商户名模糊过滤下方chip列表。',
    },
    {
      anchor: 'selectAllMch',
      name: '全选',
      group: '搜索',
      interaction: '按钮，勾选当前货币下所有商户chip；勾选数>1自动把配置来源切到"应用模版配置"。',
    },
    {
      anchor: 'clearMch',
      name: '清空',
      group: '搜索',
      interaction: '按钮，取消所有已选商户chip。',
    },
    {
      anchor: 'toggleMch',
      name: '商户chip（勾选）',
      group: '搜索',
      interaction:
        '点击勾选/取消；chip第2排显示该商户当前配置来源(模版名/复制自哪个商户/自定义)+是否有新版可更新。',
      logic: '单选一个商户→立即载入该商户配置到下方等级表；多选→隐藏可编辑表，仅能批量应用来源。',
    },
    {
      anchor: 'mchSrc',
      name: '配置来源（单选）',
      group: '搜索',
      interaction: '单选：应用模版配置 / 自定义；多选商户时"自定义"选项禁用。',
      logic: '切到"自定义"且原来源非空会解除模板绑定(detachTemplate)。',
    },
    {
      anchor: 'pickTpl',
      name: '选择模版',
      group: '搜索',
      interaction: '下拉，仅列当前货币下的模版；默认自动选中第一个。',
    },
    {
      anchor: 'ws_curChip',
      name: '货币（模版配置tab画廊）',
      group: '搜索',
      interaction: '横向滚动chip单选(同商户配置tab货币行样式独立)，仅展示该货币下的模版卡片。',
    },
    // ===== 操作 =====
    {
      anchor: 'applySource',
      name: '应用',
      group: '操作',
      interaction:
        '按钮，仅"应用模版配置"来源时出现；点击弹二次确认(展示来源+目标商户列表)→确认后生效落库。',
      logic: '应用后该商户chip来源标签更新、版本号minor+1、写入商户配置记录。',
    },
    {
      anchor: 'applyFromMch',
      name: '应用其他商户配置',
      group: '操作',
      interaction:
        '按钮(位于"正在配置"栏)，打开弹窗：下拉选同货币的源商户→只读预览其等级表+经验值→点"应用"确认覆盖当前商户。',
      logic: '弹窗内下拉/确认按钮未单独加data-manual锚点，属该按钮触发的同一功能范围。',
    },
    {
      anchor: 'updateToLatest',
      name: '立即更新',
      group: '操作',
      interaction:
        '按钮，仅当前商户应用的模版有更新版本时出现；点击把模版最新版应用到该商户并生效。',
    },
    {
      anchor: 'editLevel_row',
      name: 'VIP等级表·行内编辑',
      group: '操作',
      interaction:
        '每行"编辑"按钮进入行内编辑(14项数值可改)，编辑态出现保存/取消/清空/恢复4个按钮；保存前超上限的项标红框+hover错因，超限阻止保存；保存弹二次确认预览→确认后即生效落库。',
      limit: '各字段独立上限：经验值/赠送金额≤99999999、奖励≤9999999、百分比类≤100、次数类≤999。',
    },
    {
      anchor: 'editExp',
      name: '经验值配置·编辑',
      group: '操作',
      interaction: '"编辑"按钮进入输入态→"保存"弹二次确认预览确认落库，或"取消"放弃。',
      limit: '兑换金额上限9999999，超限红框+阻止保存。',
    },
    {
      anchor: 'ws_addTemplate',
      name: '＋新增模板',
      group: '操作',
      interaction:
        '按钮，最多10个模板(满额隐藏)；点击进入新建草稿态(名称输入+货币锁定为当前选中货币)。',
    },
    {
      anchor: 'ws_saveTemplateDraft',
      name: '保存（新建模板草稿）',
      group: '操作',
      interaction: '按钮，草稿名称+等级表内容一并提交为新模版；同行"取消"放弃草稿。',
    },
    {
      anchor: 'ws_selectTemplate',
      name: '模板卡片（点击进入编辑）',
      group: '操作',
      interaction: '点击卡片名称或右上角"编辑"按钮，载入该模版内容到等级表进入编辑态。',
    },
    {
      anchor: 'ws_deleteTemplate',
      name: '删除模板',
      group: '操作',
      interaction: '卡片右上角红色按钮，删除该模版。',
    },
    {
      anchor: 'ws_viewAllMerchant',
      name: '查看更多（商户）',
      group: '操作',
      interaction: '模板卡片已应用商户超过展示上限时出现，点击打开"查看全部"弹窗(带搜索)。',
    },
    {
      anchor: 'ws_editMeta',
      name: '编辑（模板名称/币种）',
      group: '操作',
      interaction: '编辑模板态下的按钮，点击后名称变可输入框；币种编辑态锁定不可改(仅新建时可选)。',
    },
    {
      anchor: 'ws_saveMeta',
      name: '保存（模板名称）',
      group: '操作',
      interaction: '按钮，确认修改模版名称；同行"取消"放弃改名。',
    },
    {
      anchor: 'ws_applyMchToTpl',
      name: '应用其他商户配置（到模板）',
      group: '操作',
      interaction:
        '编辑模板态按钮，打开弹窗选一个同币种商户→用其配置整体覆盖当前正在编辑的模版内容。',
    },
    {
      anchor: 'openMerchantCfgLog',
      name: '商户配置记录',
      group: '操作',
      interaction:
        '按钮(工具行右侧)，打开只读弹窗展示该页全局商户配置变更流水(跨商户)，仅展示最新10条。',
      dataSource:
        'configOpLog.ts 的 getMerchantCfgLog；列：序号/商户/版本号/配置来源/模版名称/最后修改人/修改时间/修改内容。',
    },
    // ===== 其它（展示态）=====
    {
      anchor: 'previewArea',
      name: '来源预览区（只读）',
      group: '其它',
      interaction:
        '选中"应用模版配置"或"应用其他商户配置"后，应用前先只读预览将套用的等级表+经验值配置。',
    },
    {
      anchor: 'sourceInfo',
      name: '正在配置·来源/版本/状态',
      group: '其它',
      interaction:
        '"正在配置"栏展示当前商户名+配置来源(自定义/模版名/复制自哪个商户)+配置版本号+状态标签(未配置/待发布/已发布)。',
    },
    {
      anchor: 'chipSrc',
      name: 'chip·配置来源与版本标识',
      group: '其它',
      interaction: '商户chip第2排的来源标签(自定义/模版名/复制自XX)+"🔔有新版"或"已最新"徽标。',
    },
    {
      anchor: 'batchTip',
      name: '批量提示',
      group: '其它',
      interaction: '多选商户时出现的提示文案，告知将批量应用到N个商户。',
    },
    {
      anchor: 'ws_boundMerchants',
      name: '模板·已绑定商户/版本',
      group: '其它',
      interaction: '编辑模板栏展示该模版当前版本号+已应用的商户列表(超3个可"查看全部")。',
    },
    {
      anchor: 'navToggle',
      name: '左侧配置导航',
      group: '其它',
      interaction:
        '可展开/收起；展开态含搜索框(按配置项名称模糊搜)+页面入口卡片，点击跳转对应配置页；收起态显示竖排短标签。',
    },
  ],
  fields: [
    { name: '名称（列）', def: 'VIP等级名，固定VIP0~VIP10共11级。' },
    { name: '升级经验', def: '升到该等级所需累计经验值。' },
    { name: '保级经验', def: '维持该等级所需的周期内最低经验值。' },
    { name: '扣除经验', def: '未达保级标准时扣减的经验值。' },
    { name: '升级奖励', def: '升到该等级一次性发放的奖励金额。' },
    { name: '月度奖励', def: '该等级每月可领取的奖励金额。' },
    { name: '充值奖励%', def: '该等级充值时按比例赠送的百分比。' },
    { name: '赠送上限', def: '该等级各类赠送金额的累计上限。' },
    {
      name: '电子/真人/体育/彩票/棋牌洗码率%',
      def: '该等级各游戏品类的有效流水返还比例，5个品类各一列。',
    },
    { name: '结算日', def: '该等级奖励的结算周期节点。' },
    { name: '单日提款次数上限', def: '该等级会员每日可提款的最大次数。' },
    { name: '月奖励领取次数', def: '月度奖励每月可领取的次数上限。' },
    {
      name: '经验值兑换规则',
      def: '"有效投注 n (货币) = 1点经验值"的换算比例n，商户/模版各自独立配置。',
    },
    { name: '配置来源', def: '当前商户VIP配置的来源：自定义 / 应用了某模版 / 复制自某商户。' },
    { name: '配置版本', def: '该商户或模版的配置版本号，每次应用/编辑minor自增。' },
  ],
};

export default manual;
