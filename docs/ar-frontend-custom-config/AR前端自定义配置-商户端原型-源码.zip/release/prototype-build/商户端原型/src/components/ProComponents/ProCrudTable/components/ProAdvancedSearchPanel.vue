<template>
  <!-- 顶栏 -->
  <div class="pro-advanced-search__header">
    <div class="pro-advanced-search__header-main">
      <div class="pro-advanced-search__title">
        {{ t('components.proAdvancedSearch.panelTitle') }}
      </div>
      <span v-if="pinEditing" class="pro-advanced-search__pin-hint">
        {{ t('components.proAdvancedSearch.pinHint', { max: ctx.maxPinCount.value }) }}
      </span>
    </div>
    <n-button
      text
      type="primary"
      size="small"
      @click="pinEditing ? handleCancelPin() : handleStartPin()"
    >
      {{
        pinEditing
          ? t('components.proAdvancedSearch.cancelEdit')
          : t('components.proAdvancedSearch.quickEdit')
      }}
    </n-button>
  </div>

  <!-- 筛选模式 -->
  <div v-if="!pinEditing" class="pro-advanced-search__body">
    <ProForm
      :form="ctx.advancedSearchForm"
      :label-width="advancedSearchLabelWidth"
      label-placement="left"
      size="small"
    >
      <div ref="advancedLayoutRef" class="pro-advanced-search__layout">
        <section
          v-for="section in sections"
          :key="section.group"
          class="pro-advanced-search__section"
        >
          <div class="pro-advanced-search__section-title">
            {{ section.group }}
          </div>
          <div
            class="pro-advanced-search__grid"
            :class="{ 'is-flex-layout': ctx.searchLayout.value === 'flex' }"
            :style="advancedContainerStyle"
          >
            <div
              v-for="column in section.columns"
              :key="column.path"
              class="pro-advanced-search__item"
              :style="getAdvancedItemStyle(column)"
            >
              <n-form-item
                v-if="column.render"
                :path="column.path"
                :label="column.label"
                :label-width="column.labelWidth"
                :show-feedback="false"
              >
                <component :is="renderColumn(column)" />
              </n-form-item>
              <ProField
                v-else
                :path="column.path"
                :label="column.label"
                :label-width="column.labelWidth"
                :value-type="column.valueType || 'text'"
                :component="column.component"
                :component-props="column.componentProps"
                :default-value="column.defaultValue"
                :rules="column.rules"
                :placeholder="column.placeholder"
                :options="column.options"
                :field-mapping="column.fieldMapping"
                :show="column.show"
                :disabled="column.disabled"
                :readonly="column.readonly"
                :dependencies="column.dependencies"
                :transform-in="column.transformIn"
                :transform-out="column.transformOut"
                :form-item-props="{ showFeedback: false, ...column.formItemProps }"
              />
            </div>
          </div>
        </section>
      </div>
    </ProForm>
  </div>

  <!-- 钉选模式 -->
  <div v-else class="pro-advanced-search__body">
    <section
      v-for="section in allSections"
      :key="section.group"
      class="pro-advanced-search__section"
    >
      <div class="pro-advanced-search__section-title">{{ section.group }}</div>
      <div class="pro-advanced-search__pin-grid">
        <div
          v-for="column in section.columns"
          :key="column.path"
          class="pro-advanced-search__pin-item"
          :class="{
            'is-checked': ctx.userPinnedPaths.value.includes(column.path),
            'is-disabled':
              !ctx.userPinnedPaths.value.includes(column.path) &&
              ctx.userPinnedPaths.value.length >= ctx.maxPinCount.value,
          }"
          @click="handlePinItemClick(column.path)"
        >
          <n-checkbox
            :checked="ctx.userPinnedPaths.value.includes(column.path)"
            :disabled="
              !ctx.userPinnedPaths.value.includes(column.path) &&
              ctx.userPinnedPaths.value.length >= ctx.maxPinCount.value
            "
            @click.stop
            @update:checked="(val: boolean) => handlePinToggle(column.path, val)"
          />
          <span>{{ column.label }}</span>
        </div>
      </div>
    </section>
  </div>

  <!-- 底部 -->
  <div class="pro-advanced-search__footer">
    <!-- 筛选模式 -->
    <template v-if="!pinEditing">
      <div class="pro-advanced-search__footer-left">
        <n-tag
          v-for="tag in activeTags"
          :key="tag.path"
          size="small"
          closable
          @close="clearField(tag.path)"
        >
          {{ tag.label }}: {{ tag.displayValue }}
        </n-tag>
      </div>
      <div class="pro-advanced-search__footer-right">
        <n-button size="small" @click="close">{{ t('common.cancel') }}</n-button>
        <n-button size="small" :disabled="activeTags.length === 0" @click="handleClearAll">{{
          t('components.proAdvancedSearch.clearAll')
        }}</n-button>
        <n-button size="small" type="primary" @click="handleApply">{{
          t('components.proAdvancedSearch.apply')
        }}</n-button>
      </div>
    </template>
    <!-- 编辑快捷区模式 -->
    <template v-else>
      <div class="pro-advanced-search__footer-left">
        <span class="pro-advanced-search__pin-count">
          {{
            t('components.proAdvancedSearch.pinCount', {
              count: ctx.userPinnedPaths.value.length,
              max: ctx.maxPinCount.value,
            })
          }}
        </span>
      </div>
      <div class="pro-advanced-search__footer-right">
        <n-button size="small" @click="handleCancelPin">{{ t('common.cancel') }}</n-button>
        <n-button
          size="small"
          :disabled="ctx.userPinnedPaths.value.length === 0"
          @click="handleClearAllPins"
          >{{ t('components.proAdvancedSearch.clearAll') }}</n-button
        >
        <n-button size="small" @click="handleResetPin">{{ t('common.reset') }}</n-button>
      </div>
    </template>
  </div>
</template>

<script lang="ts" setup>
  import { computed, ref, watch, nextTick, onBeforeUnmount, type CSSProperties } from 'vue';
  import { NButton, NCheckbox, NFormItem, NTag } from 'naive-ui';
  import { useI18n } from 'vue-i18n';
  import ProForm from '../../ProForm/ProForm.vue';
  import ProField from '../../ProField/ProField.vue';
  import { format } from 'date-fns';
  import { useProCrudTableContext } from '../../context/crudTableContext';
  import { useResponsiveGrid } from '../composables/useResponsiveGrid';
  import { useAutoLabelWidth } from '../composables/useAutoLabelWidth';
  import { getDateFormat } from '../../utils/placeholder';
  import type { Recordable, ProSearchFormColumn } from '../../types';

  defineOptions({ name: 'ProAdvancedSearchPanel' });

  interface SectionItem {
    group: string;
    columns: ProSearchFormColumn[];
  }

  const ctx = useProCrudTableContext();
  const { t } = useI18n();

  const lockedPanelHeight = ref<number | null>(null);

  function getPanelElement(): HTMLElement | null {
    return document.querySelector('.pro-advanced-search__panel');
  }

  function clearPanelHeightLock() {
    const panel = getPanelElement();
    if (!panel) return;
    panel.style.height = '';
    panel.style.minHeight = '';
  }

  async function syncPanelHeightLock() {
    await nextTick();
    const panel = getPanelElement();
    if (!panel) return;
    if (lockedPanelHeight.value == null) {
      lockedPanelHeight.value = Math.ceil(panel.getBoundingClientRect().height);
    }
    const height = `${lockedPanelHeight.value}px`;
    panel.style.height = height;
    panel.style.minHeight = height;
  }

  watch(
    () => ctx.advancedSearchOpen.value,
    async (val) => {
      if (val) {
        pinEditing.value = false;
        lockedPanelHeight.value = null;
        await syncPanelHeightLock();
      } else {
        lockedPanelHeight.value = null;
        clearPanelHeightLock();
      }
    },
  );

  // ============ 分组 ============
  const sections = computed<SectionItem[]>(() => groupByField(ctx.advancedColumns.value));

  const allSections = computed<SectionItem[]>(() => {
    const allColumns = ctx.searchColumns.value;
    const pinnable = allColumns.filter((col) => col.pin !== undefined || col.group);
    return pinnable.length ? groupByField(pinnable) : groupByField(allColumns);
  });

  function groupByField(columns: ProSearchFormColumn[]): SectionItem[] {
    const map = new Map<string, ProSearchFormColumn[]>();
    for (const col of columns) {
      const group = col.group || t('components.proAdvancedSearch.groupOther');
      if (!map.has(group)) map.set(group, []);
      map.get(group)!.push(col);
    }
    return Array.from(map, ([group, columns]) => ({ group, columns }));
  }

  const advancedLayoutRef = ref<HTMLElement | null>(null);

  // 自治 label 宽度：与 ProSearchBar 同源策略，**始终启用** canvas 离屏测量。
  // ctx.searchLabelWidth 数字（默认 80）作为 minWidth/fallback 兜底：
  //   - 中文短 label 视觉与历史一致（clamp 到 80）
  //   - 英文/越南/印尼长 label 自动扩展到测量值（多语言完整显示）
  // 同时绕过 NForm 共享 ref 在弹窗反复开关 / i18n 切换下被锁死 0 的 race。
  const advancedLabels = computed(() =>
    ctx.advancedColumns.value
      .map((c) => c.label ?? '')
      .filter((s): s is string => typeof s === 'string' && s.length > 0),
  );
  const isAdvancedAutoMode = computed(() => true);
  const advancedLabelFallback = computed(() =>
    typeof ctx.searchLabelWidth.value === 'number' ? ctx.searchLabelWidth.value : 80,
  );
  const advancedSearchLabelWidth = useAutoLabelWidth({
    labels: advancedLabels,
    containerRef: advancedLayoutRef,
    enabled: isAdvancedAutoMode,
    minWidth: advancedLabelFallback,
    fallback: advancedLabelFallback,
  });

  const {
    currentCols: advancedCurrentCols,
    containerStyle: advancedContainerStyle,
    getColumnSpan: getAdvancedColumnSpan,
    getItemStyle: getAdvancedFlexItemStyle,
  } = useResponsiveGrid({
    cols: ctx.searchCols,
    layout: ctx.searchLayout,
    xGap: ctx.searchXGap,
    yGap: ctx.searchYGap,
    componentWidth: ctx.searchComponentWidth,
    labelWidth: ctx.searchLabelWidth,
    labelPlacement: computed(() => 'left' as const),
    autoSpan: ctx.searchAutoSpan,
    containerRef: advancedLayoutRef,
  });

  interface AdvancedPlacement {
    row: number;
    start: number;
    span: number;
  }

  function placeAdvancedSectionColumns(columns: ProSearchFormColumn[], gridCols: number) {
    const placements = new Map<string, AdvancedPlacement>();
    const queue = columns.map((col) => ({
      col,
      span: Math.max(1, Math.min(getAdvancedColumnSpan(col), gridCols)),
    }));
    const placed = new Set<string>();
    let currentRow = 1;
    let rowUsed = 0;
    let i = 0;

    while (i < queue.length) {
      const { col, span } = queue[i];
      if (placed.has(col.path)) {
        i += 1;
        continue;
      }

      if (rowUsed + span > gridCols) {
        const remaining = gridCols - rowUsed;
        if (remaining > 0) {
          let filled = false;
          for (let j = i + 1; j < queue.length; j += 1) {
            const candidate = queue[j];
            if (!placed.has(candidate.col.path) && candidate.span <= remaining) {
              placements.set(candidate.col.path, {
                row: currentRow,
                start: rowUsed + 1,
                span: candidate.span,
              });
              placed.add(candidate.col.path);
              rowUsed += candidate.span;
              filled = true;
              break;
            }
          }
          if (filled) continue;
        }
        currentRow += 1;
        rowUsed = 0;
      }

      placements.set(col.path, {
        row: currentRow,
        start: rowUsed + 1,
        span,
      });
      placed.add(col.path);
      rowUsed += span;
      i += 1;
    }

    return placements;
  }

  const advancedPlacements = computed(() => {
    const gridCols = Math.max(advancedCurrentCols.value, 1);
    const placements = new Map<string, AdvancedPlacement>();
    for (const section of sections.value) {
      const sectionPlacements = placeAdvancedSectionColumns(section.columns, gridCols);
      sectionPlacements.forEach((placement, path) => placements.set(path, placement));
    }
    return placements;
  });

  function getAdvancedItemStyle(column: ProSearchFormColumn): CSSProperties {
    if (ctx.searchLayout.value === 'flex') return getAdvancedFlexItemStyle(column);
    const placement = advancedPlacements.value.get(column.path);
    if (!placement) return {};
    return {
      gridColumn: `${placement.start} / ${placement.start + placement.span}`,
      gridRow: `${placement.row}`,
    };
  }

  // ============ 筛选条件标签 ============
  interface ActiveTag {
    path: string;
    label: string;
    displayValue: string;
  }

  const activeTags = computed<ActiveTag[]>(() => {
    const values = ctx.advancedSearchForm.values.value as Recordable;
    const tags: ActiveTag[] = [];
    for (const col of ctx.advancedColumns.value) {
      const val = values[col.path];
      if (val === undefined || val === null || val === '') continue;
      if (Array.isArray(val) && val.length === 0) continue;
      tags.push({
        path: col.path,
        label: col.label || col.path,
        displayValue: formatTagValue(val, col),
      });
    }
    return tags;
  });

  const DATE_VALUE_TYPES = new Set([
    'date',
    'datetime',
    'dateRange',
    'datetimeRange',
    'time',
    'timeRange',
    'week',
    'month',
    'year',
    'quarter',
    'proDateRange',
  ]);

  function getDateFormatStr(col: ProSearchFormColumn): string {
    // proDateRange 优先从 componentProps.displayFormat 取
    if (col.valueType === 'proDateRange') {
      const props =
        typeof col.componentProps === 'function' ? col.componentProps({}) : col.componentProps;
      return props?.displayFormat || 'yyyy-MM-dd';
    }
    return getDateFormat(col.valueType as any);
  }

  function formatTimestamp(ts: unknown, fmt: string): string {
    if (typeof ts !== 'number') return String(ts);
    try {
      return format(ts, fmt);
    } catch {
      return String(ts);
    }
  }

  function formatTagValue(val: unknown, col: ProSearchFormColumn): string {
    const vt = col.valueType || 'text';

    // 日期/时间类型：timestamp → 格式化字符串
    if (DATE_VALUE_TYPES.has(vt)) {
      const fmt = getDateFormatStr(col);
      if (Array.isArray(val)) {
        return val.map((v) => formatTimestamp(v, fmt)).join(' ~ ');
      }
      return formatTimestamp(val, fmt);
    }

    if (Array.isArray(val)) {
      if (col.options) {
        const opts = typeof col.options === 'function' ? [] : col.options;
        const labels = val.map((v) => opts.find((o: any) => o.value === v)?.label ?? v);
        return labels.join(', ');
      }
      return val.join(', ');
    }
    if (col.options) {
      const opts = typeof col.options === 'function' ? [] : col.options;
      const matched = opts.find((o: any) => o.value === val);
      if (matched) return String(matched.label);
    }
    return String(val);
  }

  function clearField(path: string) {
    ctx.advancedSearchForm.setFieldValue(path, undefined);
  }

  function handleClearAll() {
    for (const col of ctx.advancedColumns.value) {
      ctx.advancedSearchForm.setFieldValue(col.path, undefined);
    }
  }

  function handleApply() {
    ctx.handleSearch(ctx.advancedSearchForm.getSearchParams());
    ctx.advancedSearchOpen.value = false;
  }

  function close() {
    ctx.advancedSearchOpen.value = false;
  }

  function renderColumn(column: ProSearchFormColumn) {
    if (!column.render) return null;
    return column.render({
      formModel: ctx.advancedSearchForm.values.value,
      field: column.path,
      setValue: (val: any) => ctx.advancedSearchForm.setFieldValue(column.path, val),
    });
  }

  // ============ 钉选模式 ============
  const pinEditing = ref(false);

  function handleStartPin() {
    pinEditing.value = true;
  }

  function handleCancelPin() {
    pinEditing.value = false;
  }

  function handleResetPin() {
    const defaults = (ctx.searchColumns.value || [])
      .filter((col) => col.pin !== false)
      .map((col) => col.path);
    ctx.userPinnedPaths.value = defaults;
  }

  function handleClearAllPins() {
    ctx.userPinnedPaths.value = [];
  }

  function handlePinItemClick(path: string) {
    const paths = ctx.userPinnedPaths.value;
    const isChecked = paths.includes(path);
    if (!isChecked && paths.length >= ctx.maxPinCount.value) return;
    handlePinToggle(path, !isChecked);
  }

  function handlePinToggle(path: string, checked: boolean) {
    const paths = ctx.userPinnedPaths.value;
    if (checked && paths.length < ctx.maxPinCount.value) {
      ctx.userPinnedPaths.value = [...paths, path];
    } else if (!checked) {
      ctx.userPinnedPaths.value = paths.filter((p) => p !== path);
    }
  }

  onBeforeUnmount(() => {
    clearPanelHeightLock();
  });
</script>

<style lang="less">
  /* 面板内容样式（容器样式由 ProAdvancedSearchTrigger 管理） */
  .pro-advanced-search__header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 12px;
    padding: 10px 20px 0;
    flex-shrink: 0;
  }

  .pro-advanced-search__header-main {
    display: flex;
    flex: 1;
    min-width: 0;
    align-items: center;
    gap: 8px;
  }

  .pro-advanced-search__title {
    flex-shrink: 0;
    font-size: 15px;
    font-weight: 600;
    line-height: 22px;
    color: #1f2329;
  }

  .pro-advanced-search__pin-hint {
    min-width: 0;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    font-size: 12px;
    color: #999;
    line-height: 18px;
  }

  .pro-advanced-search__body {
    flex: 1;
    overflow-y: auto;
    padding: 12px 20px 8px;

    // 多语言下 label 必须单行完整显示（测试硬性要求），
    // 强制 nowrap 是 useAutoLabelWidth 测量算法之外的保险。
    .n-form-item-label {
      white-space: nowrap;
    }

    .n-form-item-label.n-form-item-label--right-mark {
      padding: 0 6px 0 0;
    }
  }

  .pro-advanced-search__section + .pro-advanced-search__section {
    margin-top: 12px;
    padding-top: 6px;
    border-top: 1px dashed #efeff5;
  }

  .pro-advanced-search__section-title {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    margin-bottom: 10px;
    font-size: 13px;
    font-weight: 600;
    color: #333;
  }

  .pro-advanced-search__item {
    min-width: 0;

    .n-form-item {
      margin-bottom: 8px;
    }
  }

  .pro-advanced-search__grid.is-flex-layout {
    .pro-advanced-search__item {
      flex: 0 0 auto;

      .n-form-item {
        grid-template-columns: auto var(--pro-search-component-width, 200px);
      }
    }
  }

  .pro-advanced-search__pin-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(min(100%, 180px), 220px));
    gap: 8px 12px;
    align-content: start;
    justify-content: flex-start;

    @media (max-width: 1535px) {
      grid-template-columns: repeat(auto-fill, minmax(min(100%, 168px), 1fr));
    }

    @media (max-width: 639px) {
      grid-template-columns: repeat(auto-fill, minmax(min(100%, 144px), 1fr));
    }
  }

  .pro-advanced-search__pin-item {
    display: flex;
    align-items: center;
    gap: 6px;
    min-width: 0;
    min-height: 36px;
    padding: 6px 10px;
    border: 1px solid #efeff5;
    border-radius: 6px;
    font-size: 13px;
    color: #333;
    cursor: pointer;
    transition: all 0.15s;

    &:hover {
      border-color: #2080f0;
    }
    &.is-checked {
      border-color: #2080f0;
      background: rgba(32, 128, 240, 0.06);
      color: #2080f0;
    }
    &.is-disabled {
      cursor: not-allowed;
      opacity: 0.5;
    }
  }

  .pro-advanced-search__footer {
    flex-shrink: 0;
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 10px 20px;
    border-top: 1px solid #efeff5;
  }

  .pro-advanced-search__footer-left {
    flex: 1;
    min-width: 0;
    display: flex;
    flex-wrap: wrap;
    align-items: center;
    gap: 6px;
    overflow: hidden;
    max-height: 52px;
  }

  .pro-advanced-search__footer-right {
    flex-shrink: 0;
    display: flex;
    align-items: center;
    gap: 8px;
  }

  .pro-advanced-search__pin-count {
    font-size: 12px;
    color: #999;
  }
</style>
