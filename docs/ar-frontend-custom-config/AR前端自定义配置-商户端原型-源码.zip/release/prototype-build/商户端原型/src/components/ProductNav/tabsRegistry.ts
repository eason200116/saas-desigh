import type { TabConfig } from './types';

/**
 * Product navigation tab registry.
 * Scoped to ProductNav because no other runtime path consumes it.
 */
export const tabsRegistry: Record<string, TabConfig[]> = {
  tenant_frontStyle: [
    {
      key: 'style',
      title: 'tenant.picture.styleTab',
    },
    {
      key: 'image',
      title: 'tenant.picture.imageTab',
    },
    {
      key: 'category',
      title: 'tenant.picture.categoryTab',
    },
  ],
  tenant_dictionary: [
    {
      key: 'country',
      title: 'tenant.dictionary.countryTab',
    },
    {
      key: 'currency',
      title: 'tenant.dictionary.currencyTab',
    },
    {
      key: 'language',
      title: 'tenant.dictionary.languageTab',
    },
  ],
};
