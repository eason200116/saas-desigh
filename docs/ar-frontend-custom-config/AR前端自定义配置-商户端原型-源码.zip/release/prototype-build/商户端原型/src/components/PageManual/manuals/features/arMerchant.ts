import type { ManualFeaturePoint } from '../../types';

// PRD 对照只存在内容数据层；prdSection / prdFeatureId 不会传给前台展示。
export const merchantLayoutListZh: ManualFeaturePoint[] = [
  { prdSection: '第 10 节／商户端／版面列表查询', title: '查看与筛选版面', details: { purpose: '查看当前商户已下派版面、默认标记及发布状态，并按名称、ID或默认状态筛选。', prerequisites: '需要“版面查看”，商户必须在当前登录授权范围内。', areas: '列表显示名称、ID、状态、默认标记、备注、创建及最后修改信息。', workflow: '确认当前商户，输入名称或 ID、选择默认状态后搜索；重置可回到完整列表。', permissions: '只有查看权限时列表、详情、预览与记录均为只读。', effects: '查询不会改变版面、线上内容或商户范围。', unavailable: '没有下派版面时显示空状态，不从其他来源补入版面。', recovery: '加载失败时重试并保留上次成功数据；范围不一致时返回有权商户。' } },
  { prdSection: '第 10 节／商户端／复制版面', title: '复制版面', details: { purpose: '将现有商户版面立即复制为新 ID、新名称的独立草稿。', prerequisites: '需要“版面查看＋配置管理”，来源版面仍在授权与下派范围内。', workflow: '从版面操作选择复制，填写并确认新名称；建立成功后直接进入新版面编辑页。', permissions: '无配置管理时不能复制。', effects: '新草稿完整带入来源版面的模板／主题引用、结构、内容、翻译、素材与游戏选择；不承接域名、默认状态、排程、发布状态或版本与操作记录。', unavailable: '来源数据过期或发生版本冲突时不能直接复制。', recovery: '刷新来源状态后重试，或先处理基准更新。' } },
  { prdSection: '第 10 节／商户端／查看与编辑入口', title: '进入查看或编辑', details: { purpose: '从列表进入版面详情、配置与多端预览。', prerequisites: '查看需要“版面查看”；修改与保存另需“配置管理”。', workflow: '选择目标版面的查看或编辑，完成后返回列表核对状态。', permissions: '仅查看时编辑控件只读，但说明与预览仍可使用。', effects: '单纯进入或返回不会重置列表筛选、分页或商户范围。', unavailable: '版面已不在下派范围或商户不一致时不能进入编辑。', recovery: '返回有权列表并重新选择仍有效的版面。' } },
  { prdSection: '第 10 节／商户端／设为默认', title: '设为默认版面', details: { purpose: '指定当前商户唯一默认版面，作为新主域名建议与安全回退候选。', prerequisites: '需要“版面查看＋配置管理”，版面必须已发布且至少有有效主域名。', workflow: '在目标已发布版面选择设为默认并确认。', permissions: '无配置管理时不能改变默认状态。', effects: '同一商户只保留一个默认版面；不会改变既有主域名绑定。', unavailable: '尚未配置、草稿、已排程、发布失败或已回滚状态不能直接设为默认。', recovery: '状态冲突时刷新列表，再选择当前合资格版面。' } },
  { prdSection: '第 10 节／商户端／域名管理入口', title: '管理主域名绑定', details: { purpose: '从版面配置查看当前关系，并把商户自行新增的合资格主域名绑定到目标版面。', prerequisites: '查看需要“版面查看”；新增主域名与变更绑定需要“配置管理”，域名须先在域名管理建立并通过验证。', workflow: '先到域名管理新增主域名，再回版面配置打开目标版面的域名管理，选择一个或多个尚未绑定的有效主域名并保存；既有绑定须先解除，才能另行绑定其他版面。', permissions: '只有查看权限时关系只读；配置管理可建立或解除绑定。', effects: '一个版面可应用多个主域名；每个主域名同一时间只能绑定一个版面；管理绑定不会修改版面内容。', unavailable: '非主域名、未验证、无效或已绑定域名不能直接加入；不允许从一个版面直接切换到另一个版面。', recovery: '重新加载最新关系；如需使用其他版面，先从现有关系解除，再到目标版面建立新绑定。' } },
  { prdSection: '第 10 节／商户端／发布与排程状态', title: '查看发布与排程状态', details: { purpose: '识别尚未配置、草稿、已排程、已发布、发布失败与已回滚状态。', prerequisites: '需要“版面查看”。', areas: '状态栏与操作记录显示当前结果；排程执行前依当前有效商户覆盖或下派保底渲染。', workflow: '回到列表查看状态，再按需要进入编辑器或操作记录处理。', permissions: '查看状态不需要配置或发布权限。', effects: '查看状态不改变当前有效内容。', unavailable: '状态数据过期时不能据此继续受保护操作。', recovery: '刷新列表取得最新状态与失败原因；商户配置失效时直接展示下派保底。' } },
  { prdSection: '第 10 节／商户端／回滚', title: '执行回滚', details: { purpose: '把版面恢复到合资格的历史成功发布内容。', prerequisites: '需要“版面查看＋发布管理”，目标为最近 10 次且 180 天内的成功发布。', workflow: '打开操作记录，选择合资格发布、确认全部已绑主域名与待执行排程处理后回滚。', permissions: '无发布管理时只能查看记录，不能回滚。', effects: '回滚原子作用于全部有效已绑主域名，并建立新的成功发布记录，不覆盖历史。', unavailable: '没有合资格成功发布、没有有效主域名或商户状态不允许时不能回滚。', recovery: '失败时不应用任何部分回滚内容，继续展示当前有效商户覆盖或完整下派保底；按原因修正后重新发起。' } },
  { prdSection: '第 10 节／商户端／操作记录', title: '查看操作记录', details: { purpose: '追踪建立、保存、复制、封存、默认、预览、基准同步、域名、发布、排程、取消及回滚结果。', prerequisites: '需要“版面查看”，记录仅限授权商户范围。', areas: '记录包含操作者、角色、商户、来源端、时区、对象、动作、结果、摘要及失败原因，并保留 180 天。', workflow: '从列表打开操作记录，按目标版面核对动作与结果。', permissions: '记录为只读；查看不等于拥有配置或发布权限。', effects: '查看记录不会重置筛选或改变版面状态。', recovery: '加载失败时重试；跨页操作完成后刷新记录。' } },
  { prdSection: '第 10 节／商户端／删除与封存', title: '删除或封存版面', details: { purpose: '删除未使用草稿，或封存已有发布历史的版面。', prerequisites: '需要“版面查看＋配置管理”，并先检查发布、域名与排程状态。', workflow: '符合条件的草稿使用删除；曾发布的版面解除绑定后使用封存。', permissions: '无配置管理时不能删除或封存。', effects: '删除移除未使用草稿；封存保留发布与操作记录。', unavailable: '只有草稿、从未发布、无域名绑定且无排程时可删除。', recovery: '条件不符时先处理绑定与排程，再按可用封存路径操作。' } },
];


export const merchantLayoutEditorZh: ManualFeaturePoint[] = [
  { prdSection: '第 10 节／商户端／版面身份与基准', title: '确认版面与保底', details: { purpose: '确认名称、ID、代码模板、主题、状态及下派保底后再编辑商户内容。', prerequisites: '需要“版面查看”，版面仍在下派范围且商户与路由一致。', areas: '页首显示版面身份、只读代码模板、主题、备注与状态；版面编辑页不展示域名字段，域名关系统一在版面配置的域名管理处理。', workflow: '编辑前核对保底更新结果与启用语言；需要查看、新增或解除主域名绑定时返回版面配置。', permissions: '查看权限可读取数据；无配置管理时不能修改。', effects: '模板更新应用新代码骨架与能力，版面更新只更新保底快照，都不覆盖商户覆盖。', unavailable: '商户范围不一致或下派已失效时不能继续编辑。', recovery: '返回授权列表并重新加载有效版面。' } },
  { prdSection: '第 10 节／商户端／多语文案', title: '维护多语文案', details: { purpose: '为商户已启用语言维护导航、分类与区块文案。', prerequisites: '需要“版面查看＋配置管理”；可编辑语言来自商户管理。', areas: '在区块配置与语言页签填写标题、说明及其他允许文案。', workflow: '切换目标语言，逐区块填写文案并保存草稿。', permissions: '无配置管理时语言内容只读。', effects: '发布时按目标语言→商户默认语言→总控英文基准回退。', unavailable: '默认语言必填文案缺失会阻挡发布；其他语言缺失只警告并回退。', recovery: '语言清单变化且有未保存内容时先保存或放弃，再加载最新语言。' } },
  { prdSection: '第 10 节／商户端／素材与链接', title: '维护素材与链接', details: { purpose: '在总控允许范围内维护图片、图标与链接。', prerequisites: '需要“版面查看＋配置管理”，素材类型与链接范围受总控基准限制。', areas: '在区块配置选择或填写允许素材与链接。', workflow: '选择区块，更新素材／链接，通过校验后保存。', permissions: '无配置管理时素材只读。', effects: '保存只更新草稿；发布后才应用到线上。', unavailable: '格式、尺寸、必填或允许范围不符时不能发布。', recovery: '按素材提示更换合资格内容并重新保存、预览。' } },
  { prdSection: '第 10 节／商户端／显示与排序', title: '调整显示与同层排序', details: { purpose: '控制非必备项目是否显示，并调整模板允许的同层顺序。', prerequisites: '需要“版面查看＋配置管理”，组件类型、ID、层级与必备插槽保持只读。', areas: '在内容结构调整显示状态及同层排序。', workflow: '选择非必备项目设置显示，并拖动或选择同层顺序后保存。', permissions: '无配置管理时结构只读。', effects: '不会改变组件识别或总控模板结构。', unavailable: '必备插槽不能隐藏，跨层级排序不可用。', recovery: '校验失败时恢复必备结构与合法顺序后再保存。' } },
  { prdSection: '第 10 节／商户端／游戏配置', title: '配置商户游戏', details: { purpose: '选择商户已开通且总控允许的场馆、分类与子游戏。', prerequisites: '需要“版面查看＋配置管理”，选择范围为两端有效范围交集。', areas: '在游戏区块选择场馆、分类与子游戏。', workflow: '逐区块选择游戏，确认必备游戏区块至少一个 active 子游戏并保存。', permissions: '无配置管理时游戏选择只读。', effects: '发布后线上仅显示本次有效选择。', unavailable: 'maintenance 只保留既有选择且不可新选；disabled／unavailable 不得发布；每区块最多 50 个。', recovery: '没有可选结果时检查总控允许池、商户开通范围与游戏状态。' } },
  { prdSection: '第 10 节／商户端／保存草稿', title: '保存草稿', details: { purpose: '保存当前商户覆盖，不改变当前有效展示。', prerequisites: '需要“版面查看＋配置管理”，版面与商户状态允许编辑。', workflow: '完成一组编辑后点击保存草稿，确认结果再预览。', permissions: '无配置管理时不能保存；权限撤销后内容保留供复制。', effects: '只更新商户草稿；当前有效商户覆盖继续展示，若无有效覆盖则显示下派保底。', unavailable: '必填格式错误、商户停用或版本冲突时不能保存。', recovery: '依提示修正；冲突时重新加载或另存副本。' } },
  { prdSection: '第 10 节／商户端／多端预览', title: '执行多端预览', details: { purpose: '检查当前草稿在设备、启用语言与保底条件下的效果。', prerequisites: '需要“版面查看”，草稿须满足预览校验。', areas: '手机端以 375×812 预览；PC 端以 1920 为基准宽度并依画面可用宽度自适应，高度随内容延伸且不限制；可切换启用语言。编辑与预览区均不提供域名绑定字段。', workflow: '保存后逐一切换设备与语言，确认文案、素材、游戏与保底结果。', permissions: '查看权限即可预览。', effects: '预览不写入线上，也不会重置表单、语言页签或游戏选择。', unavailable: '必备结构或必要数据不完整时不能完成有效预览。', recovery: '按提示修正后重新保存与预览；失效覆盖预览只展示完整保底，不混用部分失效数据。' } },
  { prdSection: '第 10 节／商户端／立即发布', title: '立即发布', details: { purpose: '将当前合资格商户覆盖立即发布到该版面全部有效已绑主域名。', prerequisites: '需要“版面查看＋发布管理”、至少一个有效主域名及全部发布校验通过。', workflow: '完成预览，点击立即发布，确认全部主域名与既有排程处理后提交。', permissions: '无发布管理时不能发布；发布权限不自动允许修改配置。', effects: '原子应用到全部有效已绑主域名，并建立成功发布记录，不支持只选部分域名。', unavailable: '配置中商户、停用商户、无有效域名或校验失败时不可发布。', recovery: '失败时保留草稿但不应用任何部分覆盖，所有域名直接展示完整下派保底；修正后重试。' } },
  { prdSection: '第 10 节／商户端／建立排程', title: '建立发布排程', details: { purpose: '按商户时区安排未来时间发布当前合资格草稿。', prerequisites: '需要“版面查看＋发布管理”、有效主域名与通过发布校验。', workflow: '选择排程，设定至少当前时间后 5 分钟的时间并确认。', permissions: '无发布管理时不能建立排程。', effects: '排程执行前继续展示当前有效商户覆盖；若无有效覆盖则展示完整下派保底。成功执行后作用于全部有效已绑主域名。', unavailable: '每版面只允许一笔待执行排程。', recovery: '建立失败时保留草稿；刷新排程状态并修正时间或阻挡条件。' } },
  { prdSection: '第 10 节／商户端／取消排程', title: '取消待执行排程', details: { purpose: '停止尚未执行的版面发布排程。', prerequisites: '需要“版面查看＋发布管理”，且存在待执行排程。', workflow: '打开排程数据，确认目标时间与版面后取消。', permissions: '无发布管理时只能查看排程。', effects: '取消后继续展示当前有效商户覆盖；若无有效覆盖则展示完整下派保底。操作结果写入记录。', unavailable: '已执行、已取消或不存在的排程不能再次取消。', recovery: '状态过期时刷新；若排程已执行，依发布结果决定是否回滚。' } },
  { prdSection: '第 10 节／商户端／回滚', title: '执行回滚', details: { purpose: '恢复最近 10 次且 180 天内的合资格成功发布。', prerequisites: '需要“版面查看＋发布管理”、有效主域名及合资格历史记录。', workflow: '从操作记录选择成功发布，确认全部主域名与既有排程处理后回滚。', permissions: '无发布管理时不能回滚。', effects: '原子作用于全部有效已绑主域名并形成新的成功发布记录。', unavailable: '没有合资格记录或商户状态不允许时不可回滚。', recovery: '失败时不应用任何部分回滚内容，继续展示当前有效商户覆盖或完整下派保底；依失败原因处理后重新发起。' } },
  { prdSection: '第 10 节／跨端同步／总控模板与版面更新', title: '应用模板能力与保底更新', details: { purpose: '自动应用新代码模板骨架与最新下派保底，同时完整保留商户覆盖。', prerequisites: '版面仍在有效下派范围，新模板或版面快照已生效。', workflow: '系统自动更新骨架能力与保底快照，编辑者只需查看差异与必要的相容提示。', permissions: '查看权限可读取更新结果；更新不要求商户确认或重新发布。', effects: '稳定组件 ID 继续应用商户覆盖；被移除插槽的旧值保留于数据与记录但不展示，插槽相容恢复时可继续应用。', unavailable: '新骨架下覆盖失效时，不混合展示其部分内容。', recovery: '覆盖失效时直接使用更新后的完整保底，商户数据不被覆盖或删除。' } },
  { prdSection: '第 10 节／商户端／未保存与并发处理', title: '处理未保存内容与并发更新', details: { purpose: '避免离开、权限变化或多页签更新时遗失商户草稿。', prerequisites: '适用于有未保存内容、数据过期或版本冲突的状态。', workflow: '离开时选择保存、放弃或取消；冲突时重新加载或另存副本。', permissions: '权限撤销后页面转只读，内容只供复制。', effects: '取消离开会保留表单、语言页签、游戏选择与未保存内容。', unavailable: '冲突版本不能覆盖最新数据。', recovery: '复制需要保留的内容，再重新加载或另存副本。' } },
];


export const merchantDomainZh: ManualFeaturePoint[] = [
  { prdSection: '第 10 节／域名管理／列表查询', title: '查看与搜索域名', details: { purpose: '按商户、域名类型或网址查找主域名、推广域名与防封谷歌页。', prerequisites: '需要页面查看权限，且商户在当前授权范围内。', areas: '列表显示商户、域名 ID、类型、网址、绑定版面、状态、建立／修改与备注。', workflow: '选择商户与类型，输入完整或部分网址后搜索；重置可恢复列表。', permissions: '仅查看时列表与说明只读。', effects: '搜索不改变域名或版面关系。', unavailable: '无权商户数据不会显示。', recovery: '加载失败时重试并保留上次成功数据。' } },
  { prdSection: '第 10 节／域名管理／新增域名', title: '新增域名', details: { purpose: '由商户在自身授权范围建立新的主域名、推广域名或防封谷歌页记录。', prerequisites: '需要域名管理与“配置管理”权限，且只能新增当前商户数据。', workflow: '点击新增，选择类型，填写 https:// 网址、状态与备注后保存；新增主域名通过验证后，回版面配置为目标版面建立绑定。', permissions: '无配置管理时新增入口隐藏或禁用。', effects: '新增只建立域名数据；合资格主域名须另行在版面配置绑定后才应用版面。', unavailable: '网址必填、唯一、以 https:// 开头且最多 50 字；备注最多 500 字。', recovery: '重复或格式错误时保留表单，修正后再保存。' } },
  { prdSection: '第 10 节／域名管理／编辑域名数据', title: '编辑域名数据', details: { purpose: '维护既有域名的网址、类型允许字段、状态与备注。', prerequisites: '需要域名管理与“配置管理”权限；既有记录的商户不可变更。', workflow: '从列表点击编辑，修改允许字段并保存；版面绑定需返回版面配置处理。', permissions: '无配置管理时表单只读。', effects: '保存只更新域名数据，不会发布、切换或变更已绑定版面。', unavailable: '网址重复、格式或长度不符时不能保存；已绑定版面不可直接切换。', recovery: '保存失败时保留表单内容；如需使用其他版面，先在版面配置解除现有绑定，再到目标版面另行绑定。' } },
  { prdSection: '第 10 节／域名管理／首次绑定版面', title: '绑定主域名版面', details: { purpose: '从版面配置为目标版面选择一个或多个尚未绑定的合资格主域名。', prerequisites: '需要“配置管理”；域名已由当前商户在域名管理建立、已验证且有效，版面来自总控下派且仍有效。', workflow: '进入版面配置，打开目标版面的域名管理，选择一个或多个未绑定主域名并保存。', permissions: '无配置管理时关系只读；发布另受“发布管理”控制。', effects: '一个版面可应用多个主域名；每个主域名同一时间只能绑定一个版面；无有效商户覆盖时展示该版面的完整下派保底。', unavailable: '推广域名、防封页、未验证、无效或已绑定主域名不能直接加入；已绑定主域名不可直接切换至其他版面。', recovery: '没有可选域名时检查类型、验证、有效、总控下派与绑定状态；需要使用其他版面时，先解除现有关系再另行绑定。' } },
  { prdSection: '第 10 节／域名管理／停用域名', title: '停用域名', details: { purpose: '停止指定域名对外服务，同时保留数据与版面关系。', prerequisites: '需要域名管理与“配置管理”权限。', workflow: '编辑域名状态为停用并确认保存。', permissions: '无配置管理时不能变更状态。', effects: '域名停止对外服务，但绑定、内容与记录保留。', unavailable: '状态已被其他操作改变时不能覆盖。', recovery: '刷新最新状态后再决定是否停用。' } },
  { prdSection: '第 10 节／域名管理／恢复域名', title: '恢复有效域名', details: { purpose: '让已恢复验证与有效条件的域名重新提供服务。', prerequisites: '需要域名管理与“配置管理”，并已通过所需验证。', workflow: '确认验证与有效状态后，将域名恢复启用。', permissions: '无配置管理时不能恢复。', effects: '恢复后展示当前有效商户覆盖；没有有效覆盖时展示已绑定版面的完整下派保底。', unavailable: '仍未验证或无效时不能作为发布域名恢复使用。', recovery: '完成验证或有效性处理后重新加载并启用。' } },
  { prdSection: '第 10 节／域名管理／过期或删除', title: '处理过期或删除域名', details: { purpose: '终止不再可用的域名关系，并清理相关待执行动作。', prerequisites: '需要域名管理与“配置管理”，并确认受影响的版面与排程。', workflow: '确认域名过期或删除，检查系统解除关系与排程结果。', permissions: '无配置管理时不能执行。', effects: '解除版面绑定并取消相关待执行排程；版面内容与操作记录保留。', unavailable: '并发更新时后续提交不能覆盖第一笔成功结果。', recovery: '重新加载关系并核对取消结果；失败时维持原绑定与有效展示。' } },
  { prdSection: '第 10 节／域名管理／并发与异常', title: '处理并发与保存异常', details: { purpose: '避免重复网址、旧版本与多页签操作覆盖有效域名关系。', prerequisites: '适用于重复、数据过期、保存失败或并发冲突。', workflow: '读取业务提示，修正输入或重新加载，再提交一次。', permissions: '权限撤销时未提交内容只供复制，不能保存。', effects: '失败不改变当前绑定，表单内容保留。', unavailable: '并发操作以第一笔成功为准，后续旧版本禁止覆盖。', recovery: '重新加载最新数据；无可选项目时检查下派、类型、验证和有效状态。' } },
];


const merchantI18nZh: ManualFeaturePoint[] = [
  { prdSection: '', prdFeatureId: 'I18N-01', title: '读取语言来源与保留内容', details: { purpose: '按商户已启用语言显示可编辑内容，并在语言停用时保留翻译。', prerequisites: '需要“版面查看”；语言清单来自商户语言设置。', areas: '语言页签固定显示商户默认语言，并只列出当前启用语言。', workflow: '加载语言清单，选择目标语言；停用语言隐藏，重新启用后恢复原内容。', permissions: '查看可切换语言；配置管理才可修改内容，语言启停仍由来源功能管理。', effects: '停用不会删除翻译，新语言建立空内容并提示补齐。', unavailable: '没有启用语言时提示返回语言设置；清单更新时不清除未保存输入。', recovery: '先保存或保留当前输入，再加载最新语言清单。' } },
  { prdSection: '', prdFeatureId: 'I18N-02', title: '编辑多语内容与必填校验', details: { purpose: '按稳定内容识别维护各语言文字与素材，并完成默认语言必填。', prerequisites: '需要“版面查看＋配置管理”，且语言来源已加载。', areas: '在区块配置与语言页签编辑标题、说明、素材及允许内容。', workflow: '逐语言输入内容、检查长度与必填、保存；发布时按提示定位缺失内容。', permissions: '无配置管理时内容只读；查看权限仍可切换语言。', effects: '各语言内容分开保存；素材可共用或按语言覆盖。', unavailable: '默认语言必填缺失、超长或素材失效会阻挡发布。', recovery: '修正定位到的语言与内容；冲突时保留输入并重新加载。' } },
  { prdSection: '', prdFeatureId: 'I18N-03', title: '检查固定回退链与 RTL', details: { purpose: '确认缺值时的固定显示顺序与阿拉伯文 RTL 排版。', prerequisites: '需要“版面查看”，并已选择预览语言。', areas: '预览会标示目前使用目标语言、商户默认语言或总控英文内容。', workflow: '依次检查目标语言、商户默认语言、总控英文的显示结果，再检查 RTL。', permissions: '查看权限即可预览；回退不会赋予编辑权限。', effects: '回退内容只用于显示，不会回写目标语言。', unavailable: '默认语言必填仍须完成；RTL 不反转数字与品牌。', recovery: '按语言与内容提示补值，再重新预览。' } },
];


const merchantGamesZh: ManualFeaturePoint[] = [
  { prdSection: '', prdFeatureId: 'GAME-01', title: '按平台、分类与子游戏选择', details: { purpose: '按固定层级配置游戏平台、分类与子游戏。', prerequisites: '需要“版面查看＋配置管理”，并已建立游戏区块。', areas: '游戏区块依次显示平台、分类及子游戏。', workflow: '先选平台，再选分类与子游戏；切换上层前确认受影响项目。', permissions: '查看可浏览；配置管理才可选择或清除。', effects: '确认切换后清除不属于新上层范围的下层选择，稳定 ID 不变。', unavailable: '未选上层时下层不可选；空来源显示空状态。', recovery: '取消切换可保留原值；来源更新后重新加载。' } },
  { prdSection: '', prdFeatureId: 'GAME-02', title: '限制为商户允许范围交集', details: { purpose: '只提供总控可用与商户已开通范围的交集。', prerequisites: '需要“版面查看”，且游戏平台与商户允许范围可读取。', areas: '搜索与选择结果只显示交集内项目，既有失效项会被标示。', workflow: '加载或搜索交集，移除失效或越权项目后保存。', permissions: '配置管理可调整选择；商户隔离在查看与提交时同时生效。', effects: '草稿保留失效项目供定位，线上会隐藏未授权项目。', unavailable: '空交集显示原因，不能以直接网址加入越权项目。', recovery: '检查总控范围、商户开通与游戏状态后重算。' } },
  { prdSection: '', prdFeatureId: 'GAME-03', title: '设置游戏区块并完成发布校验', details: { purpose: '设置数量、排序与精选，并在发布前重算交集与游戏状态。', prerequisites: '已选择交集内游戏，且需要相应配置或发布管理权限。', areas: '游戏区块属性与发布问题清单显示数量、排序、精选及状态。', workflow: '完成区块设置并保存；发布前检查有效、维护、停用与已移除状态。', permissions: '配置管理可设置；发布管理才可提交发布。', effects: '发布后只显示允许且有效的项目；维护项目依显示规则标示。', unavailable: '空交集、停用、已移除、数量不合法或失效 ID 会阻挡发布。', recovery: '商户配置无效或发布失败时直接展示完整下派保底，不混用部分失效游戏；修正后重新校验。' } },
];


// 旧版摘要在数据层替换为 V1.0 的独立功能点，前台不会把不连续操作混在同一段。
merchantLayoutEditorZh.splice(4, 1, ...merchantGamesZh);
merchantLayoutEditorZh.splice(1, 1, ...merchantI18nZh);

const MERCHANT_PRD_REFERENCE: Record<string, string> = {
  'MER-00': '2.1／MER-00｜商户端产品边界',
  'MER-01': '3.3／MER-01｜商户列表、编辑与保存',
  'MER-02': '3.3／MER-02｜商户预览与发布校验',
  'MER-03': '3.3／MER-03｜立即发布',
  'MER-04': '3.3／MER-04｜排程发布、取消与取代',
  'MER-05': '5.1／MER-05｜发布版本与回滚',
  'DSP-02': '3.2／DSP-02｜模板能力与保底同步',
  'DOM-01': '5.2／DOM-01｜主域名资格与绑定',
  'DOM-02': '5.2／DOM-02｜已绑主域名切换限制',
  'DOM-03': '5.2／DOM-03｜设为默认与域名失效',
  'I18N-01': '5.3／I18N-01｜商户语言来源与内容保留',
  'I18N-02': '5.3／I18N-02｜多语编辑与必填校验',
  'I18N-03': '5.3／I18N-03｜固定回退链与 RTL',
  'GAME-01': '5.4／GAME-01｜平台、分类与子游戏阶层',
  'GAME-02': '5.4／GAME-02｜商户允许范围交集',
  'GAME-03': '5.4／GAME-03｜游戏区块设定与发布校验',
  'AUD-01': '5.5／AUD-01｜审计查询与保留',
  'PERM-01': '2.2／PERM-01｜角色权限与入口',
  'PERM-02': '2.2／PERM-02｜商户身份与数据隔离',
};

function bindMerchantPrdReferences(points: ManualFeaturePoint[], ids: string[]) {
  if (points.length !== ids.length) throw new Error('PageManual PRD mapping count mismatch');
  points.forEach((point, index) => {
    const prdFeatureId = ids[index];
    point.prdFeatureId = prdFeatureId;
    point.prdSection = MERCHANT_PRD_REFERENCE[prdFeatureId];
  });
}

merchantLayoutListZh.unshift(
  { prdSection: '', prdFeatureId: 'PERM-01', title: '按角色权限使用功能', details: { purpose: '依查看、编辑与发布管理权限控制入口及操作。', prerequisites: '角色权限已由 V3 角色管理配置。', areas: '列表、编辑器、预览、发布、回滚与记录会呈现允许的只读或可操作状态。', workflow: '确认当前角色与可见入口，再执行获授权操作。', permissions: '有版面查看即可打开本说明书；编辑、发布、排程与回滚需相应权限。', effects: '查看与阅读不会改变权限或产品数据。', unavailable: '无查看权限时入口与直接地址均受阻挡；权限收回后后续操作立即失效。', recovery: '由管理员补齐权限后重新进入，不提交权限失效前的旧操作。' } },
  { prdSection: '', prdFeatureId: 'PERM-02', title: '保持商户数据隔离', details: { purpose: '确保登录商户只能查看和变更自己的版面、域名、发布与记录。', prerequisites: '登录内容包含有效商户身份，页面路由与数据所属商户一致。', areas: '列表、详情、预览、发布、域名、语言、游戏及记录均应用同一商户范围。', workflow: '进入页面时核对当前商户；范围不一致时返回有权列表。', permissions: '商户隔离同时作用于查看和提交，不能以直接地址绕过。', effects: '合法操作只更新当前登录商户，其他商户与总控基准不变。', unavailable: '越权时不显示目标商户名称、数据或是否存在。', recovery: '返回授权商户入口并重新选择有效数据。' } },
);

const merchantListPrdIds = ['PERM-01', 'PERM-02', 'MER-01', 'MER-01', 'MER-01', 'MER-01', 'DOM-03', 'DOM-01', 'MER-00', 'MER-05', 'AUD-01', 'MER-05'];
const merchantEditorPrdIds = ['MER-01', 'I18N-01', 'I18N-02', 'I18N-03', 'MER-01', 'MER-01', 'GAME-01', 'GAME-02', 'GAME-03', 'MER-01', 'MER-02', 'MER-03', 'MER-04', 'MER-04', 'MER-05', 'DSP-02', 'MER-01'];
const merchantDomainPrdIds = ['DOM-01', 'DOM-01', 'DOM-01', 'DOM-01', 'DOM-03', 'DOM-03', 'DOM-03', 'DOM-02'];

bindMerchantPrdReferences(merchantLayoutListZh, merchantListPrdIds);
bindMerchantPrdReferences(merchantLayoutEditorZh, merchantEditorPrdIds);
bindMerchantPrdReferences(merchantDomainZh, merchantDomainPrdIds);
