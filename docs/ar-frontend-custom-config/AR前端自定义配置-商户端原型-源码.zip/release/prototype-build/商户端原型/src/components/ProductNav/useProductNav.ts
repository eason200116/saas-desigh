/**
 * Hook for generating product navigation data from route configuration
 * Full version: Includes all modules (game, member, report, operations, tenant, system)
 */
import { computed, ref } from 'vue';
import { storeToRefs } from 'pinia';
import { useI18n } from 'vue-i18n';
import { useRouter } from 'vue-router';
import type { RouteRecordRaw } from 'vue-router';
import { useAsyncRouteStore } from '@/store/modules';
import type { Category, ServiceItem, SearchResultItem, TabConfig } from './types';
import { tabsRegistry } from './tabsRegistry';

// Route module icons mapping
import {
  PeopleOutline,
  BarChartOutline,
  ConstructOutline,
  BusinessOutline,
  OptionsSharp,
  GameControllerOutline,
} from '@vicons/ionicons5';

/**
 * Module configuration
 * Maps route module name to category config
 */
const MODULE_CONFIG: Record<string, { title: string; icon: typeof PeopleOutline; sort: number }> = {
  game: {
    title: 'productNav.game',
    icon: GameControllerOutline,
    sort: 1,
  },
  member: {
    title: 'productNav.member',
    icon: PeopleOutline,
    sort: 2,
  },
  report: {
    title: 'productNav.report',
    icon: BarChartOutline,
    sort: 3,
  },
  operations: {
    title: 'productNav.operations',
    icon: ConstructOutline,
    sort: 4,
  },
  tenant: {
    title: 'productNav.tenant',
    icon: BusinessOutline,
    sort: 5,
  },
  system: {
    title: 'productNav.system',
    icon: OptionsSharp,
    sort: 6,
  },
};

// All module names
const ALL_MODULES = ['game', 'member', 'report', 'operations', 'tenant', 'system'];

export function useProductNav() {
  const { t } = useI18n();
  const router = useRouter();
  const asyncRouteStore = useAsyncRouteStore();
  const { menus: storeMenus } = storeToRefs(asyncRouteStore);

  const searchKeyword = ref('');

  /**
   * Recursively collect leaf routes (routes with components, not just containers)
   */
  const collectLeafRoutes = (
    routes: RouteRecordRaw[],
    moduleName: string,
    collected: ServiceItem[],
    parentPath: string = '',
  ) => {
    routes.forEach((route) => {
      const routeName = route.name as string;
      if (!routeName) return;

      // Skip hidden routes
      if (route.meta?.hidden) return;

      // Build full path
      const fullPath = route.path.startsWith('/')
        ? route.path
        : parentPath
          ? `${parentPath}/${route.path}`
          : `/${moduleName}/${route.path}`;

      // If has children, recursively process
      if (route.children && route.children.length > 0) {
        collectLeafRoutes(route.children as RouteRecordRaw[], moduleName, collected, fullPath);
      } else {
        // This is a leaf route (actual page)
        // Get tabs config for this route
        const routeTabs = tabsRegistry[routeName];
        let filteredTabs: TabConfig[] | undefined;

        if (routeTabs) {
          filteredTabs = routeTabs;
          if (filteredTabs.length === 0) filteredTabs = undefined;
        }

        const serviceItem: ServiceItem = {
          key: routeName,
          title: (route.meta?.title as string) || routeName,
          path: fullPath,
          icon: route.meta?.icon as ServiceItem['icon'],
          tabs: filteredTabs,
        };

        collected.push(serviceItem);
      }
    });
  };

  /**
   * Generate categories from store menus (already filtered by permissions)
   * This uses the same data source as the sidebar menu
   */
  const categories = computed<Category[]>(() => {
    // Get menus from store - these are already filtered by permissions
    const menus = storeMenus.value || [];
    const categoryMap = new Map<string, Category>();

    // Find module root routes from menus
    ALL_MODULES.forEach((moduleName) => {
      const moduleConfig = MODULE_CONFIG[moduleName];
      if (!moduleConfig) return;

      // Find the root route for this module
      const rootRoute = menus.find((route) => route.name === moduleName);
      if (!rootRoute) return;

      // Collect leaf routes
      const items: ServiceItem[] = [];
      if (rootRoute.children) {
        collectLeafRoutes(
          rootRoute.children as RouteRecordRaw[],
          moduleName,
          items,
          rootRoute.path,
        );
      }

      if (items.length > 0) {
        categoryMap.set(moduleName, {
          key: moduleName,
          title: moduleConfig.title,
          icon: moduleConfig.icon,
          items,
        });
      }
    });

    // Sort categories by config sort order
    const sortedCategories = Array.from(categoryMap.values()).sort((a, b) => {
      const sortA = MODULE_CONFIG[a.key]?.sort ?? 999;
      const sortB = MODULE_CONFIG[b.key]?.sort ?? 999;
      return sortA - sortB;
    });

    return sortedCategories;
  });

  /**
   * Search results filtered by keyword
   */
  const searchResults = computed<SearchResultItem[]>(() => {
    if (!searchKeyword.value.trim()) return [];

    const keyword = searchKeyword.value.toLowerCase();
    const results: SearchResultItem[] = [];

    categories.value.forEach((category) => {
      const categoryTitle = t(category.title);

      category.items.forEach((item) => {
        const itemTitle = t(item.title);

        // Match page title
        if (itemTitle.toLowerCase().includes(keyword)) {
          results.push({
            key: item.key,
            title: itemTitle,
            path: item.path,
            categoryTitle,
          });
        }

        // Match tab titles
        if (item.tabs) {
          item.tabs.forEach((tab) => {
            const tabTitle = t(tab.title);
            if (tabTitle.toLowerCase().includes(keyword)) {
              // path 仅用于搜索结果展示；实际跳转走 navigateToTab(result.key, result.tabKey)
              // 不要把 ?tab=xxx 拼在 path 里 —— vue-router 4 的 path 字段只接受纯路径，
              // 一旦后续有人把 result.path 错传给 router.push({ path }) 会触发 No match found
              results.push({
                key: item.key,
                title: `${itemTitle} - ${tabTitle}`,
                path: item.path,
                categoryTitle,
                tabKey: tab.key,
              });
            }
          });
        }
      });
    });

    return results;
  });

  /**
   * Navigate to a service item by route name
   */
  const navigateTo = (routeName: string) => {
    router.push({ name: routeName });
  };

  /**
   * Navigate to a specific tab
   */
  const navigateToTab = (routeName: string, tabKey: string) => {
    // Use route name instead of path to let Vue Router resolve the correct path
    router.push({
      name: routeName,
      query: { tab: tabKey },
    });
  };

  return {
    categories,
    searchKeyword,
    searchResults,
    navigateTo,
    navigateToTab,
  };
}
