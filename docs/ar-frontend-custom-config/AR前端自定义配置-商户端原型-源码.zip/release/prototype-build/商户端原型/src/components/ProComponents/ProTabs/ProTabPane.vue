<!--
/**
 * @description ProTabs 的子面板组件。在 mount 时通过 inject 注册自己到父容器，根据 displayDirective
 *   决定挂载/销毁策略；激活与否由父 ProTabs 透传的 activeKey 控制，仅切换 v-show。slot-based 模式
 *   下每个 pane 各自持有一个组件实例，无需 KeepAlive 即可实现"切换不重建"。
 * @date 2026-05-22
 * @scope src/components/ProComponents/ProTabs
 */
-->
<template>
  <div
    v-if="shouldRender"
    v-show="isActive"
    :class="['pro-tab-pane', { 'pro-tab-pane--active': isActive }]"
    role="tabpanel"
    :aria-hidden="!isActive"
  >
    <component v-if="component" :is="component" />
    <slot v-else />
  </div>
</template>

<script setup lang="ts">
  import { computed, inject, onBeforeUnmount, onMounted, ref, toRef, watch } from 'vue';
  import type { Component } from 'vue';
  import { usePermission } from '@/hooks/web/usePermission';
  import { ProTabsContextKey, type ProTabPaneDisplayDirective } from './context';

  defineOptions({ name: 'ProTabPane' });

  const props = withDefaults(
    defineProps<{
      /** Tab 唯一标识，对应 ProTabs v-model:value */
      name: string;
      /** 显示标题（已 i18n 后的字符串） */
      tab: string;
      /**
       * 内容组件（异步/同步/markRaw 后的 Component 均可）。
       * 与 default slot 互斥：传 component 时 slot 被忽略；
       * 需要给内层传 props/listeners 等场景请改用 default slot。
       */
      component?: Component;
      /** 是否禁用点击 */
      disabled?: boolean;
      /**
       * 权限码列表（OR 语义，任一命中即可见）。空数组/undefined = 不过滤。
       * 未命中权限时该 pane 不注册到父容器 → nav 看不到、内容也不渲染。
       * 与 useRouteTabs 上游过滤是并行的两道防线，互不冲突。
       */
      permissions?: string[];
      /**
       * 渲染策略：
       * - 'lazy' （默认）首次激活才挂载，之后 v-show 切换，等价 <KeepAlive> 缓存
       * - 'show' 立即挂载所有 pane，v-show 切换
       * - 'if'   激活才挂载，离开即销毁（无缓存）
       */
      displayDirective?: ProTabPaneDisplayDirective;
    }>(),
    {
      component: undefined,
      disabled: false,
      permissions: undefined,
      displayDirective: 'lazy',
    },
  );

  const ctx = inject(ProTabsContextKey, null);
  if (!ctx) {
    throw new Error('[ProTabPane] 必须放在 <ProTabs> 内使用');
  }

  const isActive = computed(() => ctx.activeKey.value === props.name);
  const displayDirective = toRef(props, 'displayDirective');

  // 权限闸：empty / undefined = 全部放行（OR 语义沿用 usePermission.hasPermission）
  const { hasPermission } = usePermission();
  const canShow = computed(() => {
    const list = props.permissions;
    if (!list || list.length === 0) return true;
    return hasPermission(list);
  });

  // lazy 策略：第一次激活后置位，之后即使切走也保留 DOM
  const hasBeenActive = ref(isActive.value);
  watch(
    isActive,
    (v) => {
      if (v) hasBeenActive.value = true;
    },
    { immediate: true },
  );

  /** 真实渲染开关：无权限 → 不渲染；否则按 displayDirective 决定 */
  const shouldRender = computed(() => {
    if (!canShow.value) return false;
    switch (displayDirective.value) {
      case 'show':
        return true;
      case 'if':
        return isActive.value;
      case 'lazy':
      default:
        return hasBeenActive.value;
    }
  });

  // 注册到父容器：用 registered flag 守护，避免权限动态变化时重复 register / 漏 unregister
  let registered = false;

  function tryRegister() {
    if (registered) return;
    ctx!.registerPane({
      name: props.name,
      tab: computed(() => props.tab),
      disabled: computed(() => !!props.disabled),
      displayDirective: computed(() => displayDirective.value),
    });
    registered = true;
  }

  function tryUnregister() {
    if (!registered) return;
    ctx!.unregisterPane(props.name);
    registered = false;
  }

  onMounted(() => {
    if (canShow.value) tryRegister();
  });

  // 权限运行时变化（罕见但合法）：动态注册/反注册保证 nav 与权限实时一致
  watch(canShow, (now) => {
    if (now) tryRegister();
    else tryUnregister();
  });

  onBeforeUnmount(tryUnregister);
</script>

<style lang="less" scoped>
  .pro-tab-pane {
    flex: 1;
    min-height: 0;
    display: flex;
    flex-direction: column;
  }
</style>
