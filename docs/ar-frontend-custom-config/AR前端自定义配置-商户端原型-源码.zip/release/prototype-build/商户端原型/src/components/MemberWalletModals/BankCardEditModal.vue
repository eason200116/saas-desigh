<template>
  <n-form ref="formRef" :model="formData" :rules="rules" label-placement="top">
    <n-grid :cols="2" :x-gap="14">
      <n-form-item-gi :label="t('member.bankCard.merchant')" path="tenantId">
        <n-select
          v-if="!lockTenantId"
          v-model:value="formData.tenantId"
          :options="tenantOptions"
          filterable
          clearable
          :placeholder="t('common.select_placeholder', { label: t('member.bankCard.merchant') })"
        />
        <n-input v-else :value="getTenantName(formData.tenantId)" disabled />
      </n-form-item-gi>
      <n-form-item-gi :label="t('member.bankCard.userId')" path="userId">
        <n-input
          v-model:value="formData.userId"
          :disabled="lockUserId"
          :allow-input="onlyDigits"
          :placeholder="t('common.input_placeholder', { label: t('member.bankCard.userId') })"
        />
      </n-form-item-gi>
      <n-form-item-gi :label="t('member.bankCard.bankName')" path="bankId">
        <AsyncSelect
          v-model:value="formData.bankId"
          :request="fetchBankList"
          :field-mapping="{ label: 'name', value: 'id' }"
          filterable
          clearable
          :placeholder="t('common.select_placeholder', { label: t('member.bankCard.bankName') })"
        />
      </n-form-item-gi>
      <n-form-item-gi :label="t('member.bankCard.beneficiaryName')" path="beneficiaryName">
        <n-input
          v-model:value="formData.beneficiaryName"
          :placeholder="
            t('common.input_placeholder', { label: t('member.bankCard.beneficiaryName') })
          "
        />
      </n-form-item-gi>
      <n-form-item-gi :label="t('member.bankCard.accountNo')" path="accountNo">
        <n-input
          v-model:value="formData.accountNo"
          :placeholder="t('common.input_placeholder', { label: t('member.bankCard.accountNo') })"
        />
      </n-form-item-gi>
      <n-form-item-gi :label="t('member.bankCard.mobileNO')">
        <n-input
          v-model:value="formData.mobileNO"
          :placeholder="t('common.input_placeholder', { label: t('member.bankCard.mobileNO') })"
        />
      </n-form-item-gi>
      <n-form-item-gi :label="t('member.bankCard.ifscCode')">
        <n-input
          v-model:value="formData.ifscCode"
          :placeholder="t('common.input_placeholder', { label: t('member.bankCard.ifscCode') })"
        />
      </n-form-item-gi>
      <n-form-item-gi :label="t('member.bankCard.email')">
        <n-input
          v-model:value="formData.email"
          :placeholder="t('common.input_placeholder', { label: t('member.bankCard.email') })"
        />
      </n-form-item-gi>
      <n-form-item-gi :label="t('member.bankCard.province')">
        <n-input
          v-model:value="formData.bankProvinceCode"
          :placeholder="t('common.input_placeholder', { label: t('member.bankCard.province') })"
        />
      </n-form-item-gi>
      <n-form-item-gi :label="t('member.bankCard.city')">
        <n-input
          v-model:value="formData.bankCityCode"
          :placeholder="t('common.input_placeholder', { label: t('member.bankCard.city') })"
        />
      </n-form-item-gi>
      <n-form-item-gi :label="t('member.bankCard.branch')" :span="2">
        <n-input
          v-model:value="formData.bankBranchAddress"
          :placeholder="t('common.input_placeholder', { label: t('member.bankCard.branch') })"
        />
      </n-form-item-gi>
    </n-grid>
  </n-form>
  <n-space justify="end" :style="{ marginTop: '16px' }">
    <n-button @click="emit('cancel')">{{ t('common.cancel') }}</n-button>
    <n-button type="primary" :loading="loading" @click="handleSubmit">
      {{ t('common.confirm') }}
    </n-button>
  </n-space>
</template>

<script setup lang="ts">
  import { reactive, ref, computed } from 'vue';
  import type { FormInst, FormRules } from 'naive-ui';
  import { useI18n } from 'vue-i18n';
  import { useMessage } from 'naive-ui';
  import { useTenantOptions } from '@/hooks';
  import { onlyDigits } from '@/utils';
  import { api } from './data';
  import { AsyncSelect } from '@/components';

  const props = defineProps<{
    mode: 'add' | 'edit';
    record?: any | null;
    // 新增模式下可由调用方预填商户/会员，例如会员详情 - 钱包信息 tab
    initial?: { tenantId?: number | null; userId?: string | number | null } | null;
  }>();

  const emit = defineEmits<{
    (e: 'cancel'): void;
    (e: 'confirm'): void;
  }>();

  const { t } = useI18n();
  const message = useMessage();
  const { tenantOptions, getTenantName, defaultTenantId } = useTenantOptions();

  const isEdit = computed(() => props.mode === 'edit');
  // 新增模式下如果调用方通过 initial 预填了商户/会员，则锁死不可编辑
  const lockTenantId = computed(() => isEdit.value || props.initial?.tenantId != null);
  const lockUserId = computed(() => isEdit.value || props.initial?.userId != null);
  const formRef = ref<FormInst | null>(null);
  const loading = ref(false);

  const formData = reactive({
    tenantId:
      props.record?.tenantId ?? props.initial?.tenantId ?? defaultTenantId.value ?? undefined,
    userId:
      props.record?.userId != null
        ? String(props.record.userId)
        : props.initial?.userId != null
          ? String(props.initial.userId)
          : '',
    bankId: props.record?.bankId ?? null,
    beneficiaryName: props.record?.beneficiaryName ?? '',
    accountNo: props.record?.accountNo ?? '',
    mobileNO: props.record?.mobileNO ?? '',
    ifscCode: props.record?.ifscCode ?? '',
    email: props.record?.email ?? '',
    bankProvinceCode: props.record?.bankProvinceCode ?? '',
    bankCityCode: props.record?.bankCityCode ?? '',
    bankBranchAddress: props.record?.bankBranchAddress ?? '',
  });

  const rules: FormRules = {
    tenantId: {
      required: true,
      type: 'number',
      message: t('common.select_placeholder', { label: t('member.bankCard.merchant') }),
      trigger: 'change',
    },
    userId: [
      {
        required: true,
        message: t('common.input_placeholder', { label: t('member.bankCard.userId') }),
        trigger: 'blur',
      },
      {
        pattern: /^\d+$/,
        message: t('member.bankCard.userIdIntegerOnly'),
        trigger: ['blur', 'input'],
      },
    ],
    bankId: {
      required: true,
      type: 'number',
      message: t('common.select_placeholder', { label: t('member.bankCard.bankName') }),
      trigger: 'change',
    },
    beneficiaryName: {
      required: true,
      message: t('common.input_placeholder', { label: t('member.bankCard.beneficiaryName') }),
      trigger: 'blur',
    },
    accountNo: {
      required: true,
      message: t('common.input_placeholder', { label: t('member.bankCard.accountNo') }),
      trigger: 'blur',
    },
  };

  // 银行下拉异步请求
  function fetchBankList() {
    return api.v1platform.getBankTypeList({
      tenantId: formData.tenantId ?? undefined,
      pageSize: 999,
      pageNo: 1,
      orderBy: 'Asc',
    });
  }

  async function handleSubmit() {
    try {
      await formRef.value?.validate();
    } catch {
      return;
    }
    loading.value = true;
    try {
      // 接口通过 bankId 关联银行（后端会根据 ID 解析银行名）
      const basePayload = {
        userId: Number(formData.userId),
        bankId: formData.bankId ?? undefined,
        beneficiaryName: formData.beneficiaryName,
        accountNo: formData.accountNo,
        mobileNO: formData.mobileNO || undefined,
        ifscCode: formData.ifscCode || undefined,
        email: formData.email || undefined,
        bankProvinceCode: formData.bankProvinceCode || undefined,
        bankCityCode: formData.bankCityCode || undefined,
        bankBranchAddress: formData.bankBranchAddress || undefined,
        tenantId: formData.tenantId,
      };
      const { result, msg } = isEdit.value
        ? await api.v1platform.updateUserBankCard({ bId: props.record!.bId, ...basePayload })
        : await api.v1platform.addUserBankCard(basePayload);
      if (!result) {
        message.error(msg);
        return;
      }
      message.success(t('member.bankCard.saveSuccess'));
      emit('confirm');
    } catch {
      message.error(t('common.requestFailed'));
    } finally {
      loading.value = false;
    }
  }
</script>
