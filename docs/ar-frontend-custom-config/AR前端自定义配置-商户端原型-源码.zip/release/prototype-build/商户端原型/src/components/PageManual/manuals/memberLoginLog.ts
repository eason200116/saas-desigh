// 登录记录（商户端 tenant · member_login_log）功能说明书。
// 锚定 src/views/member/loginLog/index.vue + data.ts 真实控件（R53 实证、不臆造）。
// 单表 ProCrudTable：纯查询型登录日志页，无新增/编辑/删除/导出等操作入口，无行内操作列，也无独立弹窗/抽屉组件。
// 页面当前未挂 data-manual 锚点，本说明书条目暂不联动面板点击高亮，仅供阅读（对齐同批次 riskControlSameIp.ts / memberGroupManage.ts 现状）。
// 命名说明：路由 meta.title 对应 i18n menu.json 的 member_loginLog 键、以及 member.loginLog.title 键，均实际渲染为「登录记录」，故本说明书 title 取「登录记录」；
// docs/published/interaction-spec-draft.html §0 时间查询表格里称本页"登录日志"，与原型实际渲染名不一致——文档与原型不一致，以原型为准（R55），如实记录，未改动该文档。

import type { PageManual } from '../types';

const manual: PageManual = {
  route: 'member_login_log',
  title: '登录记录',
  overview:
    '商户端「会员管理 › 登录记录」页，单表（ProCrudTable）展示会员每次登录的明细：设备类型 / 浏览器指纹 / 设备ID / 登录IP与地区 / 登录时间，供安全与风控排查用。纯查询型日志页——无新增/编辑/删除/导出按钮，无行内操作列，也无独立弹窗或抽屉组件；表格右上角仍保留 ProCrudTable 内置的默认列设置图标（组件通用行为，非本页定制）。',
  items: [
    // ============ 搜索区 ============
    {
      anchor: 'merchant',
      name: '商户',
      group: '搜索',
      interaction: '下拉单选（商户选择器，架构级不可清空，见《交互规范》§3 商户选择器）。',
      dataSource:
        "全站商户列表；默认预填当前左上角选中的商户（defaultTenantId）。本页 meta.roles 仅含 'tenant'，仅商户端可访问，正常场景下该值恒有效。",
      logic: '按选中商户过滤登录日志列表。',
      limit:
        '必填（红星 showRequireMark + requiredRule）；单选、不可清空——本页商户与会员ID同屏出现，命中商户单选必填规则（R63）。',
      edge: '不可清空、有预填时恒有值；不存在"未选商户"态。',
    },
    {
      anchor: 'userId',
      name: '会员ID',
      group: '搜索',
      interaction: '文本输入，placeholder 明确提示"支持多ID查询，以空格隔开"。',
      dataSource: '用户输入。',
      logic:
        '按空格切分成多个关键词，任一关键词与会员ID存在包含关系（非精确相等）即命中该行（ids.some(id=>r.userId.includes(id))）。',
      limit: '选填；仅数字与空格（onlyDigitsWithSpace 校验器）。',
      edge: '空 = 不按会员ID筛。',
    },
    {
      anchor: 'fingerprint',
      name: '浏览器指纹',
      group: '搜索',
      interaction: '文本输入。',
      dataSource: '用户输入。',
      logic: '按浏览器指纹字符串做包含匹配。',
      limit: '选填；最多 50 字，只拦控制字符（inputProps("searchKw")）。',
      edge: '空 = 不按指纹筛。',
    },
    {
      anchor: 'deviceId',
      name: '设备ID',
      group: '搜索',
      interaction: '文本输入。',
      dataSource: '用户输入。',
      logic: '按设备ID字符串做包含匹配。',
      limit: '选填；最多 50 字，只拦控制字符（inputProps("searchKw")）。',
      edge: '空 = 不按设备ID筛。',
    },
    {
      anchor: 'ip',
      name: '登录IP',
      group: '搜索',
      interaction: '文本输入。',
      dataSource: '用户输入。',
      logic: '按IP字符串做包含匹配（非精确网段匹配）。',
      limit: '选填；最多 45 位，仅数字/点/冒号/十六进制字符（inputProps("ip")，兼容 IPv6）。',
      edge: '空 = 不按IP筛。',
    },
    {
      anchor: 'timeRange',
      name: '登录时间',
      group: '搜索',
      interaction:
        '日期时间区间选择（proDateRange，精确到秒），另带内置 quickDate 快捷选项按钮（quick-date="timeRange"）；未开 quick-date-allow-clear，故无"全部"一键清空按钮（这点与同模块「分组管理」的创建时间不同）。',
      dataSource: '用户选择，或点快捷按钮。',
      logic: '意图按登录时间过滤列表。',
      limit:
        '最多跨 90 天（标准档，对齐《交互规范》§0 时间查询"标准档"分级）；不可选未来（allowFuture:false）。',
      edge:
        '⚠️ 核实代码后发现：loadDataTable 组装请求参数时只挑了 tenantId/userId/ip/deviceId/fingerprint/pageNo/pageSize 七项传给 api.member.getLoginLogPage，未包含 timeRange 或任何 startTime/endTime；mock 侧函数体也只读取这 7 个字段做过滤。即选择日期区间或点快捷按钮，界面上看起来生效（按钮高亮/框内显示日期），但实际完全不影响返回的列表结果——如实记录待补，非本次引入。',
    },

    // ============ 列 ============
    {
      anchor: 'col_userId',
      name: '会员ID列',
      group: '列',
      interaction: '以可点击蓝字链接形式展示（跳转类控件，非纯展示）。',
      dataSource: '行数据 userId + tenantId。',
      logic: '点击打开「会员详情」弹窗（openMemberDetailModal），定位到该会员。',
    },
  ],

  // ============ 字段介绍 tab（列序照页面；仅列表列 + 定义）============
  fields: [
    { name: '商户', def: '该条登录记录归属的商户，展示为"商户号(商户名)"（renderTenantTag）。' },
    { name: '会员ID', def: '登录账号所属的会员ID；蓝字可点击，跳转该会员的会员详情弹窗。' },
    {
      name: '设备名',
      def: '本次登录使用的设备类型，固定7种（R20）：H5 / PC / Android / iOS / Android（壳包）/ iOS（壳包）/ PWA。',
    },
    {
      name: '浏览器指纹',
      def: '基于设备/浏览器特征生成的唯一标识字符串，用于识别同一物理设备的多次登录；本列带「新」标（迁移期临时标记，标识本轮新增列）。',
    },
    {
      name: '设备ID',
      def: '登录设备的唯一标识号；本列带「新」标（迁移期临时标记，标识本轮新增列）。',
    },
    {
      name: '登录IP / 登录地区',
      def: '同一列内上下两行展示：上行为登录IP地址，下行为按IP解析出的地区（国家/省州），灰色小字。',
    },
    { name: '登录时间', def: '该条记录的登录发生时间。' },
  ],
};

export default manual;
