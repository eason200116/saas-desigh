// 商户筛选下拉的「全部」选项约定。
// 真实商户 id 均为正整数，用 0 作为「全部」哨兵值不会与之冲突。
export const MERCHANT_ALL_VALUE = 0;
export const MERCHANT_ALL_LABEL = '全部';

/**
 * 商户多选筛选匹配：列表 mock 统一用它判断某行是否命中「商户」筛选。
 *
 * MerchantFilterSelect 是多选，值为 number[]（如 [1048, 1050]）；不选 / 选「全部」时为 [0]。
 * 兼容历史单值（number）与空值：
 * - 筛选值为空、或包含「全部」哨兵(0) → 不过滤，全部命中
 * - 否则 → 行 tenantId 在所选 id 集合内才命中
 *
 * @param rowTenantId 当前行的商户 id
 * @param filterValue 搜索表单传来的商户筛选值（number[] | number | null | undefined）
 */
export function matchMerchantFilter(
  rowTenantId: number | string | null | undefined,
  filterValue: unknown,
): boolean {
  const arr = Array.isArray(filterValue)
    ? filterValue
    : filterValue === undefined || filterValue === null || filterValue === ''
      ? []
      : [filterValue];
  const ids = arr.map((v) => Number(v)).filter((n) => Number.isFinite(n));
  if (!ids.length || ids.includes(MERCHANT_ALL_VALUE)) return true;
  return ids.includes(Number(rowTenantId));
}
