// 人工充值管理（商户端 tenant · finance_manual_recharge_page）功能说明书。
// 锚定 src/views/finance/manualRecharge/index.vue 容器 + 3 个子 Tab（manualRecharge 人工充值 /
// manualRechargeAuditList 人工充值审核列表 / manualRechargeAuditRecords 人工充值审核记录）各自的
// index.vue/data.ts/组件真实控件（R53 实证、不臆造）。容器只是 ProTabs 壳（读 route.meta.tabs），
// 3 个子 Tab 完全独立、互不共用组件——「人工充值」是直接渲染在页面里的查询+表单操作台（不是列表页，
// 无 ProCrudTable），「审核列表」「审核记录」是标准 ProCrudTable 列表页，结构上更接近同批次已完成的
// rechargeType.ts（"1 路由 N 独立子 Tab"），区别在于本页 3 个子 Tab 形态互不相同（表单页 + 2 个列表页）。

import type { PageManual } from '../types';

const manual: PageManual = {
  route: 'finance_manual_recharge_page',
  title: '人工充值管理',
  overview:
    '商户端「财务管理 › 人工充值」页，容器是一个 3 标签页壳（人工充值 / 人工充值审核列表 / 人工充值审核记录），3 个标签页完全独立、互不共用组件。「人工充值」不是列表页，是客服/运营给指定会员手动充值或扣减余额的操作台：先按商户+会员Id 查询会员信息，再选存款类型（人工存款/彩金充值/USDT充值/提款/彩金扣除/提现退回）填金额+备注提交，也可整页右上角「批量人工充值」走 Excel 批量导入（上传→预校验→二次确认表头预览→一键操作）；单笔达到阈值（人工存款/彩金充值/USDT充值且金额绝对值≥5000）会转入待审核状态，而非直接到账。「人工充值审核列表」用于处理这些待审核申请，支持单条/批量通过或拒绝。「人工充值审核记录」是全量操作台账（含免审核自动通过、审核通过、审核拒绝三种终态），只读无操作列。2026-07-21 核实代码后如实记录 5 类真实问题，已于 2026-07-22 修复：①两个审核 Tab 搜索区的字段名与 mock 过滤函数参数名重新逐项对齐——会员ID（userId↔原 memberId）、操作人（creator↔原 operator）、审核记录 Tab 的审核状态（state↔原 auditStatus）、审核人（auditor）均已改为读取真实提交的参数名；「操作类型/子类型」级联展开的 `req.type`/`req.fundType`、「操作时间」`req.beginCreateTime`/`req.endCreateTime`、审核记录 Tab 「审核时间」`req.beginAuditTime`/`req.endAuditTime` 现均接入真实过滤逻辑（时间区间用 `new Date()` 解析比较）。②`src/api/index.ts` 的 `V1_DICTIONARY` 已补上缺失的 `manualRechargeTypeList` 级联字典（一级：人工充值/修改会员密码/修改银行卡；人工充值下二级 7 个子类型，编码沿用 Tab①`PLAY_TYPE_OPTIONS` 真实码值），两个审核 Tab 的「操作类型」级联下拉不再是空的。③两个审核 Tab 的行对象字段已按列定义实际读取的 key 重新对齐（userId/userName/type/fundType/creator + 审核列表 createTime、审核记录 createTimeStr/auditTimeStr/auditorRemark），`type`/`fundType` 存字典码值而非文案原文；审核记录 Tab 新增 `amount` 字段（人工充值类行回填真实金额，改密码/改银行卡等非资金类行为 `null` 按现有兜底规则显示"-"）。④通过/拒绝/批量通过/批量拒绝 4 个操作现在会真实修改 `manualRechargeAuditList/data.ts` 底层数组的 `state` 字段；「人工充值审核列表」相应改为只展示 `state===0`（待审核）的记录，通过/拒绝后 reload 即从列表消失。⑤「批量通过」弹窗的「充值金额上限」「排除相同会员ID」两个条件现由 mock 实际参与过滤：金额超过上限的记录跳过（保持待审核）；勾选排除重复后，本批次内同一会员ID 只处理排在前面的一条、其余保持待审核。下方各 items 的 edge 字段已同步刷新为修复后状态，详见各条目及 ChangeLogFab v1.9.150。',
  items: [
    // ============ 容器：Tab 切换 ============
    {
      anchor: 'tab_switch',
      name: '3 个子页 Tab 切换（人工充值 / 人工充值审核列表 / 人工充值审核记录）',
      group: '操作',
      interaction:
        '点顶部 Tab 切换，3 个 Tab 形态互不相同（人工充值是查询+表单操作台，其余 2 个是标准列表页）且各自独立，不共用组件、不共用数据。',
      dataSource: '从当前路由 meta.tabs 读取配置（useRouteTabs），默认停在「人工充值」Tab。',
      logic: '默认 keepAlive（各 Tab 切走后状态不丢，含分页/筛选/已查询的会员信息）。',
      note: '容器组件 src/views/finance/manualRecharge/index.vue 本身只是壳（ProTabs 包 3 个 ProTabPane），不含独立业务控件；实际控件都在 3 个子 Tab 自己的 index.vue 里。',
    },

    // ============ Tab①人工充值：查询区 ============
    {
      anchor: 'mr_merchant',
      name: '商户（人工充值 Tab，查询区）',
      group: '搜索',
      interaction: '下拉单选（ProTenantSelect，filterable 可搜索）。',
      dataSource: '全站商户列表；超管走级联 cascader，商户用户走扁平 select。',
      logic: '未选时组件自身 autoFill 逻辑会自动回填当前登录商户（defaultTenantId）；查询会员/批量导入均按当前选中商户请求。',
      limit: '架构级不可清空（组件内 clearable 硬编码为 false），查询区标 showRequireMark 红星提示必选。',
    },
    {
      anchor: 'mr_userId',
      name: '会员Id（人工充值 Tab，查询区）',
      group: '搜索',
      interaction: '文本输入，支持回车键直接触发查询（@keyup.enter）。',
      dataSource: '用户输入。',
      logic: '点击「查询」后按 userId 精确匹配 mock 会员库（3 条示例会员），未命中兜底展示第一条会员数据，而非"查无此人"空态。',
      limit: '仅允许输入数字，最多 9 位（INPUT_PRESETS.intNum）；未选商户或未填会员Id 点查询会分别提示"请选择商户"/"请输入会员Id"。',
      edge: '⚠️ 核实代码后发现：`getRechargeUserInfo` 的 mock 在 userId 未命中 `MEMBER_DB` 时会 `?? MEMBER_DB[0]` 兜底返回第一条会员的数据（而不是返回空/报错），即随便输入一个不存在的会员Id 点查询也会查出一条"看似正常"的会员信息，如实记录、不修复（本条不属于 2026-07-22 那批修复范围）。',
    },
    {
      anchor: 'mr_query',
      name: '查询（人工充值 Tab，查询区按钮）',
      group: '操作',
      interaction: '点击按钮或在会员Id 框内回车触发，按钮 loading 态跟随请求。',
      logic: '查到会员后，存款类型/打码量设置两个下拉会自动预选后端下发选项列表的第一项，免去用户再手动点一次；查询失败（result 为空）时清空右侧会员信息卡片。',
    },
    {
      anchor: 'mr_batchImport',
      name: '批量人工充值（人工充值 Tab，查询区按钮 + 弹窗）',
      group: '操作',
      interaction:
        '点击打开弹窗（BatchImportModal，宽 min(1100px,95vw)），弹窗内先「上传Excel」（仅 .xlsx/.xls）做预校验，校验结果显示在表格里（「校验信息」列：无误显示绿色"✓"，有问题显示红色具体原因文案；「状态」列执行前恒为空显示"--"）；确认无误后点「一键操作」，会先弹出带完整列头的二次确认预览表（汇总"共N条，通过X条，校验失败Y条"），确认后才真正提交执行，执行结果回填「状态」列为绿色"成功"/红色"失败" Tag。',
      dataSource:
        '上传调用 initBatchRechargeFile（返回双层 envelope，mock 固定 3 条示例行，其中 1 条因"会员ID不存在"标记校验失败）；执行调用 importBatchRechargeData，把预校验通过和失败的行原样整批回传后端执行。',
      logic:
        '批量导入弹窗只能在已选中商户后才能打开（按钮 :disabled="!currentTenantId"），且弹窗内提示"只支持单商户数据导入"；上传/执行均为独立弹窗内状态，关闭弹窗即销毁、不影响主页面查询状态；表格无数据时隐藏底部工具栏（清除表格数据/一键操作两个按钮仅在已有数据时显示）。',
      limit: '单次导入限制不超过 1 万 5 千条、文件大小不超过 4M（提示文案）；充值类型支持"彩金充值|默认|人工充值|彩金扣除"。',
      note: '「模板下载」按钮走全站统一的 useExcelTemplate 下载能力（EXCEL_TEMPLATE_KEYS.MANUAL_RECHARGE_BATCH 模板配置真实存在，非占位）。',
    },

    // ============ Tab①人工充值：会员信息展示 ============
    {
      anchor: 'mr_memberCard',
      name: '会员信息卡片（人工充值 Tab，查询结果展示区）',
      group: '其它',
      interaction: '纯展示，不可点；查询到会员前显示"暂无数据，请查询!"空态。',
      dataSource:
        '查询接口返回的会员详情：会员账号/昵称/会员Id/联系方式/平台余额/打码量/备注/账号类型/当日充值/会员分组/当日彩金充值，共 11 项两列对齐展示。',
      logic: '字符串类字段为空/undefined 统一兜底显示"--"；余额用醒目红色数值展示。',
      note: '「联系方式」和「会员账号」当前是同一个 mock 字段 userName（无独立联系方式字段），如实记录。',
    },

    // ============ Tab①人工充值：充值表单 ============
    {
      anchor: 'mr_playType',
      name: '存款类型（人工充值 Tab，充值表单）',
      group: '其它',
      interaction: '下拉单选，6 个固定选项：人工存款/彩金充值/USDT充值/提款/彩金扣除/提现退回；未查到会员前禁用。',
      dataSource: '会员查询接口下发的 playTypeSelectList（当前 mock 3 条会员该字段值相同，均为这 6 项）。',
      logic:
        '切换后联动清空「打码量设置」「指定倍数」「充值金额」三项；决定金额输入的正负号约束（人工存款/彩金充值/USDT充值/提现退回 需填正数，提款/彩金扣除 需填负数）与是否需要打码量设置（人工存款/彩金充值/USDT充值 三种才需要）；提交时彩金充值/彩金扣除 两种类型金额写入请求的 bonus 字段，其余四种写入 amount 字段（互斥路由，非独立输入框）。',
      limit: '必选（表单规则 required:true，自动显示红星，不需要模板显式 show-require-mark）。',
    },
    {
      anchor: 'mr_mosaic',
      name: '打码量设置（人工充值 Tab，充值表单，条件字段）',
      group: '其它',
      interaction: '下拉单选，仅当存款类型 ∈ {人工存款,彩金充值,USDT充值} 时出现；4 个选项：0倍/1倍/2倍/指定倍数。',
      dataSource: '会员查询接口下发的 mosaicSelectList。',
      logic: '选中"指定倍数"（value 为空字符串）会额外展开下一项「指定倍数」数字输入框。',
      limit:
        '出现时必选，但因该必填是自定义 validator 判定（非声明式 required:true），naive-ui 无法自动识别，模板显式加了 :show-require-mark="requiresMosaic" 才会显红星。',
    },
    {
      anchor: 'mr_mosaicCustom',
      name: '指定倍数（人工充值 Tab，充值表单，条件字段）',
      group: '其它',
      interaction: '数字输入框，仅当打码量设置选中"指定倍数"时出现。',
      dataSource: '用户输入。',
      logic: '出现时必填，非负整数（min:0，precision:0）。',
      limit: '同 mr_mosaic，validator 式必填，模板显式 :show-require-mark 显红星。',
    },
    {
      anchor: 'mr_amount',
      name: '存款金额 / U数量（人工充值 Tab，充值表单）',
      group: '其它',
      interaction: '数字输入框；存款类型=USDT充值(3) 时标签/占位文案切换为"U数量"，其余类型显示"存款金额"。',
      dataSource: '用户输入。',
      logic: '按存款类型联动正负号：人工存款/彩金充值/USDT充值/提现退回 只能填正数，提款/彩金扣除 只能填负数；填反、填 0、或数值恰好等于当前会员Id 均校验不通过。',
      limit: '必填，number 类型；min/max 随存款类型二选一生效（正数类型 min:0 无上限，负数类型 max:0 无下限）。',
    },
    {
      anchor: 'mr_remark',
      name: '备注（人工充值 Tab，充值表单）',
      group: '其它',
      interaction: '多行文本框（4 行），show-count 显示字数。',
      dataSource: '用户输入。',
      logic: '必填（与金额同属一条校验规则，未填时提示"备注和金额为必填项"）。',
      limit: '最多 100 字（模板显式 maxlength=100，非 INPUT_PRESETS.remark 预设的 200 字），字符过滤仍复用 remark 预设（不可输入特殊控制字符）。',
    },
    {
      anchor: 'mr_submit',
      name: '充值（人工充值 Tab，充值表单提交按钮）',
      group: '操作',
      interaction: '点击提交，未查到会员或表单未通过校验时禁用/拦截。',
      dataSource: '提交调用 submitManualRecharge。',
      logic:
        '业务约定：存款类型 ∈ {人工存款,彩金充值,USDT充值} 且金额绝对值 ≥ 5000 时进入待审核状态（提示"人工充值成功！（待审核）"），否则直接到账（提示"人工充值成功！"）；提交成功后整个查询+表单区域重置（商户选择保留）。',
      limit: '提交前统一走表单 rules 校验：存款类型必选/打码量条件必填/指定倍数条件必填/金额必填且符号匹配且不等于会员Id/备注必填。',
    },
    {
      anchor: 'mr_reset',
      name: '重置（人工充值 Tab，充值表单）',
      group: '操作',
      interaction: '点击清空查询结果与充值表单。',
      logic: '清空已查询的会员信息卡片、充值表单全部字段、以及"已查询"标记（回到初始空态）；不清空已选中的商户。',
    },

    // ============ Tab②人工充值审核列表：搜索 ============
    {
      anchor: 'al_merchant',
      name: '商户（人工充值审核列表 Tab，搜索区）',
      group: '搜索',
      interaction: '下拉单选（merchantSearchColumn，架构级不可清空）。',
      dataSource: '全站商户列表。',
      logic: '按选中商户过滤待审核列表。',
      limit: '必填（红星 showRequireMark + requiredRule）——命中 R63。',
    },
    {
      anchor: 'al_userId',
      name: '会员ID（人工充值审核列表 Tab，搜索区）',
      group: '搜索',
      interaction: '数字输入框，可清空。',
      dataSource: '用户输入。',
      limit: '选填，非负整数（precision:0, min:0）。',
      edge:
        '2026-07-22 已修复：mock 过滤函数 filterAndPaginate（manualRechargeAuditList/data.ts）已改为读取 req.userId 并按包含匹配过滤 row.userId，填写会员ID 现能正确过滤列表（2026-07-21 曾如实记录为未修复缺陷，详见 ChangeLogFab v1.9.150）。',
    },
    {
      anchor: 'al_operationType',
      name: '操作类型（人工充值审核列表 Tab，搜索区，操作类型+子类型级联）',
      group: '搜索',
      interaction: '二级级联下拉（cascadeSelect，span 占 2 列），一级"操作类型"、二级"子类型"。',
      dataSource: '字典 getRawData("manualRechargeTypeList")（useDictionary source=v1）。',
      logic: '选中后通过 modelKeys 展平为 req.type / req.fundType 两个参数。',
      edge:
        '2026-07-22 已修复：①src/api/index.ts 的 V1_DICTIONARY 已补上 manualRechargeTypeList 级联字典（人工充值/修改会员密码/修改银行卡三个一级分类，人工充值下 7 个二级子类型），下拉不再是空的；②mock 过滤函数已按 req.type / req.fundType 精确匹配过滤列表，级联选择现能正确生效（2026-07-21 曾如实记录为未修复缺陷，详见 ChangeLogFab v1.9.150）。',
    },
    {
      anchor: 'al_createTimeRange',
      name: '操作时间（人工充值审核列表 Tab，搜索区）',
      group: '搜索',
      interaction: '起止时间选择（proDateRange，精确到秒，span 占 2 列），工具栏另有 quick-date 快捷按钮。',
      dataSource: '用户选择。',
      logic: '通过 modelKeys 展平为 req.beginCreateTime / req.endCreateTime。',
      edge: '2026-07-22 已修复：mock 过滤函数已读取 req.beginCreateTime / req.endCreateTime，用 new Date() 解析后按区间比较过滤列表，选择时间区间现能正确生效（2026-07-21 曾如实记录为未修复缺陷，详见 ChangeLogFab v1.9.150）。',
    },
    {
      anchor: 'al_creator',
      name: '操作人（人工充值审核列表 Tab，搜索区）',
      group: '搜索',
      interaction: '文本输入，可清空。',
      dataSource: '用户输入。',
      limit: '选填，人名字符集（inputProps("name")）。',
      edge:
        '2026-07-22 已修复：mock 过滤函数已改为读取 req.creator 并按包含匹配过滤，与列真实字段 creator 对齐（2026-07-21 曾如实记录为未修复缺陷，详见 ChangeLogFab v1.9.150）。',
    },
    {
      anchor: 'al_reset',
      name: '重置（人工充值审核列表 Tab，搜索表单）',
      group: '操作',
      interaction: '点击「重置」按钮清空搜索表单全部字段并重新加载。',
    },

    // ============ Tab②人工充值审核列表：列 ============
    {
      anchor: 'col_al_userName',
      name: '会员账号列（人工充值审核列表 Tab）',
      group: '列',
      interaction: '纯文本展示，不可点。',
      dataSource: '列 key 为 userName。',
      edge:
        '2026-07-22 已修复：mock 行对象（manualRechargeAuditList/data.ts 的 AUDIT_LIST_ROWS）已补齐 userName 字段，正确显示会员账号。本 Tab 「会员ID」「操作类型」「子类型」「操作时间」「操作人」4 列与本列同批修复（行对象字段名统一对齐列定义读取的 key），下面各列 edge 不再重复整段说明，只标具体修复结果（2026-07-21 曾如实记录为未修复缺陷，详见 ChangeLogFab v1.9.150）。',
    },
    {
      anchor: 'col_al_userId',
      name: '会员ID列（人工充值审核列表 Tab）',
      group: '列',
      interaction: '可点蓝字跳会员详情（renderMemberIdLink，全站统一规范）。',
      dataSource: '列 render 读取 row.userId + row.tenantId。',
      edge:
        '2026-07-22 已修复：行对象已补齐 userId 字段，renderMemberIdLink 现能正确渲染可点蓝字链接，点击跳转会员详情（2026-07-21 曾如实记录为未修复缺陷，详见 ChangeLogFab v1.9.150）。',
    },
    {
      anchor: 'col_al_type',
      name: '操作类型列（人工充值审核列表 Tab）',
      group: '列',
      interaction: '彩色标签展示，不可点。',
      dataSource: '列 render 用 getOperationTypeLabel(row.type) 查字典树取名称。',
      edge:
        '2026-07-22 已修复：行对象已补齐 type 字段（存 manualRechargeTypeList 字典码值），getOperationTypeLabel 现能查到匹配项，正确显示操作类型名称（2026-07-21 曾如实记录为未修复缺陷，详见 ChangeLogFab v1.9.150）。',
    },
    {
      anchor: 'col_al_fundType',
      name: '子类型列（人工充值审核列表 Tab）',
      group: '列',
      interaction: '彩色标签展示，不可点。',
      dataSource: '列 render 用 getFundTypeLabel(row.type, row.fundType) 查字典树二级取名称。',
      edge: '2026-07-22 已修复：行对象已补齐 fundType 字段，getFundTypeLabel 现能查到匹配项，正确显示子类型名称（2026-07-21 曾如实记录为未修复缺陷，详见 ChangeLogFab v1.9.150）。',
    },
    {
      anchor: 'col_al_createTime',
      name: '操作时间列（人工充值审核列表 Tab）',
      group: '列',
      interaction: '纯文本展示，不可点。',
      dataSource: '列 key 为 createTime，showTenantTimeZone 开启（按商户时区展示）。',
      edge: '2026-07-22 已修复：行对象已补齐 createTime 字段，showTenantTimeZone 渲染路径现能正确按商户时区显示操作时间（2026-07-21 曾如实记录为未修复缺陷，详见 ChangeLogFab v1.9.150）。',
    },
    {
      anchor: 'col_al_creator',
      name: '操作人列（人工充值审核列表 Tab）',
      group: '列',
      interaction: '纯文本展示，不可点。',
      dataSource: '列 key 为 creator。',
      edge: '2026-07-22 已修复：行对象已补齐 creator 字段，正确显示操作人。本 Tab 9 列现已全部对齐 mock 数据正常显示（2026-07-21 曾如实记录为未修复缺陷，详见 ChangeLogFab v1.9.150）。',
    },

    // ============ Tab②人工充值审核列表：操作 ============
    {
      anchor: 'al_approve',
      name: '通过（人工充值审核列表 Tab，行操作按钮）',
      group: '操作',
      interaction: '点击弹二次确认框："确认通过该笔人工充值申请？通过后将立即放款，不可撤销。"',
      dataSource: '确认后调用 manualRechargeApprove({ids:[row.id], tenantId})。',
      logic: '成功后提示"操作成功"并 reload 列表。',
      edge:
        '2026-07-22 已修复：mock manualRechargeApprove 现按 ids 定位待审核行（state===0）真实写回 state=1；filterAndPaginate 已改为只展示 state===0 的记录，通过后 reload 该行即从「审核列表」消失（2026-07-21 曾如实记录为未修复缺陷，详见 ChangeLogFab v1.9.150）。',
    },
    {
      anchor: 'al_reject',
      name: '拒绝（人工充值审核列表 Tab，行操作按钮）',
      group: '操作',
      interaction: '点击打开弹窗（RejectModal，宽440px），填「拒绝备注」后确认。',
      dataSource: '确认后调用 manualRechargeReject({ids:[row.id], remark, tenantId})。',
      limit: '拒绝备注必填（trim 后非空才算有效），最多 500 字。',
      edge: '2026-07-22 已修复：mock manualRechargeReject 现按 ids 定位待审核行真实写回 state=2，拒绝后 reload 该行同样从「审核列表」消失（2026-07-21 曾如实记录为未修复缺陷，详见 ChangeLogFab v1.9.150）。',
    },
    {
      anchor: 'al_batchApprove',
      name: '批量通过（人工充值审核列表 Tab，工具栏批量操作）',
      group: '操作',
      interaction:
        '先勾选表格行（checkbox 多选），再点工具栏「批量通过」打开弹窗（宽440px），可选填「充值金额上限」（大于该金额的记录不审核，0 表示不审核会直接跳过、留空表示不按金额过滤）+「排除相同会员ID」复选框，确认后提交。',
      dataSource: '确认后调用 manualRechargeApprove({ids:选中行id数组, maxAmount, excludeDuplicateUserId, tenantId})。',
      logic: '前端有一处真实生效的拦截：金额填 0 时不会发起请求，直接提示"金额填写为 0，已跳过审核"并关闭弹窗。',
      edge:
        '2026-07-22 已修复：mock manualRechargeApprove 现真实读取 maxAmount / excludeDuplicateUserId 两个参数——金额超过上限的选中行跳过（保持待审核）；勾选「排除相同会员ID」后，本批次内同一会员ID 只处理排在前面的一条，其余保持待审核；未超限且不重复的选中行真实写回 state=1（2026-07-21 曾如实记录为未修复缺陷，详见 ChangeLogFab v1.9.150）。',
    },
    {
      anchor: 'al_batchReject',
      name: '批量拒绝（人工充值审核列表 Tab，工具栏批量操作）',
      group: '操作',
      interaction: '先勾选表格行，再点工具栏「批量拒绝」，复用与 al_reject 相同的 RejectModal 弹窗（填拒绝备注后确认）。',
      dataSource: '确认后调用 manualRechargeReject({ids:选中行id数组, remark, tenantId})。',
      edge:
        '2026-07-22 已修复：与 al_reject 同批修复，mock manualRechargeReject 现真实写回选中行 state=2（2026-07-21 曾如实记录为未修复缺陷，详见 ChangeLogFab v1.9.150）。另有一处次要细节仍如实记录、未改动：i18n 预留了 auditList.batchRejectTitle="批量审核拒绝"，但代码里弹窗标题不分单条/批量，统一固定用 auditList.reject="拒绝"，这个专属批量标题文案实际从未被引用（非功能性问题，不影响使用，不属于本次修复范围）。',
    },

    // ============ Tab③人工充值审核记录：搜索 ============
    {
      anchor: 'ar_merchant',
      name: '商户（人工充值审核记录 Tab，搜索区）',
      group: '搜索',
      interaction: '下拉单选（merchantSearchColumn，架构级不可清空）。',
      dataSource: '全站商户列表。',
      logic: '按选中商户过滤记录列表。',
      limit: '必填（红星 showRequireMark + requiredRule）——命中 R63。',
    },
    {
      anchor: 'ar_userId',
      name: '会员ID（人工充值审核记录 Tab，搜索区）',
      group: '搜索',
      interaction: '数字输入框，可清空。',
      limit: '选填，非负整数。',
      edge: '2026-07-22 已修复：mock 过滤函数 filterAndPaginate（manualRechargeAuditRecords/data.ts）已改为读取 req.userId 并按包含匹配过滤，与 al_userId 同批修复（2026-07-21 曾如实记录为未修复缺陷，详见 ChangeLogFab v1.9.150）。',
    },
    {
      anchor: 'ar_operationType',
      name: '操作类型（人工充值审核记录 Tab，搜索区，操作类型+子类型级联）',
      group: '搜索',
      interaction: '二级级联下拉（cascadeSelect，span 占 2 列）。',
      dataSource: '字典 getRawData("manualRechargeTypeList")（同 al_operationType）。',
      edge:
        '2026-07-22 已修复：字典 manualRechargeTypeList 已补齐；mock 过滤函数已改为读取级联真实提交的 req.type / req.fundType（原读取的 req.operationType 从未被提交过），与 al_operationType 同批修复（2026-07-21 曾如实记录为未修复缺陷，详见 ChangeLogFab v1.9.150）。',
    },
    {
      anchor: 'ar_state',
      name: '审核状态（人工充值审核记录 Tab，搜索区）',
      group: '搜索',
      interaction: '下拉单选，可清空（dictSelect）。',
      dataSource: '字典 manualRechargeRecordStateList（V1_DICTIONARY 里真实存在，3 个选项：审核中/通过/拒绝，与列表「审核状态」列同源）。',
      edge:
        '2026-07-22 已修复：mock 过滤函数已改为读取 req.state 并按数值精确匹配（原读取的 req.auditStatus 字符串枚举已随行对象重构一并移除，state 现是唯一的审核状态字段），选择审核状态现能正确过滤（2026-07-21 曾如实记录为未修复缺陷，详见 ChangeLogFab v1.9.150）。',
    },
    {
      anchor: 'ar_creator',
      name: '操作人（人工充值审核记录 Tab，搜索区）',
      group: '搜索',
      interaction: '文本输入，可清空。',
      limit: '选填，人名字符集。',
      edge: '2026-07-22 已修复：mock 过滤函数已补上 req.creator 的包含匹配过滤，与 al_creator 同批修复（2026-07-21 曾如实记录为未修复缺陷，详见 ChangeLogFab v1.9.150）。',
    },
    {
      anchor: 'ar_auditor',
      name: '审核人（人工充值审核记录 Tab，搜索区）',
      group: '搜索',
      interaction: '文本输入，可清空。',
      limit: '选填，人名字符集。',
      edge: '2026-07-22 已修复：mock 过滤函数已补上 req.auditor 的包含匹配过滤（2026-07-21 曾如实记录为未修复缺陷，详见 ChangeLogFab v1.9.150）。',
    },
    {
      anchor: 'ar_createTimeRange',
      name: '操作时间（人工充值审核记录 Tab，搜索区）',
      group: '搜索',
      interaction: '起止时间选择（proDateRange，精确到秒，span 占 2 列），工具栏另有 quick-date 快捷按钮。',
      edge: '2026-07-22 已修复：mock 过滤函数已补上 req.beginCreateTime/endCreateTime 的区间过滤，与 al_createTimeRange 同机制（new Date() 解析比较，2026-07-21 曾如实记录为未修复缺陷，详见 ChangeLogFab v1.9.150）。',
    },
    {
      anchor: 'ar_auditTimeRange',
      name: '审核时间（人工充值审核记录 Tab，搜索区）',
      group: '搜索',
      interaction: '起止时间选择（proDateRange，精确到秒，span 占 2 列，自带面板内快捷选项 shortcuts:true）。',
      edge: '2026-07-22 已修复：mock 过滤函数已补上 req.beginAuditTime/endAuditTime 的区间过滤；未审核行 auditTimeStr 为空字符串，自动跳过区间比较不参与过滤（2026-07-21 曾如实记录为未修复缺陷，详见 ChangeLogFab v1.9.150）。',
    },
    {
      anchor: 'ar_reset',
      name: '重置（人工充值审核记录 Tab，搜索表单）',
      group: '操作',
      interaction: '点击「重置」按钮清空搜索表单全部字段并重新加载。',
    },

    // ============ Tab③人工充值审核记录：列 ============
    {
      anchor: 'col_ar_userName',
      name: '会员账号列（人工充值审核记录 Tab）',
      group: '列',
      interaction: '纯文本展示，不可点。',
      dataSource: '列 key 为 userName。',
      edge:
        '2026-07-22 已修复：mock 行对象（manualRechargeAuditRecords/data.ts 的 AUDIT_RECORDS）已补齐 userName 字段。本 Tab 「会员ID」「操作类型」「子类型」「金额」「操作人」「操作时间」「审核备注」几列与本列同批修复（行对象字段名统一对齐列定义读取的 key），下面各列 edge 不再重复整段说明，只标具体修复结果（2026-07-21 曾如实记录为未修复缺陷，详见 ChangeLogFab v1.9.150）。',
    },
    {
      anchor: 'col_ar_userId',
      name: '会员ID列（人工充值审核记录 Tab）',
      group: '列',
      interaction: '可点蓝字跳会员详情。',
      dataSource: '列 render 读取 row.userId + row.tenantId（renderMemberIdLink）。',
      edge: '2026-07-22 已修复：行对象已补齐 userId 字段，renderMemberIdLink 现能正确渲染可点蓝字链接（2026-07-21 曾如实记录为未修复缺陷，详见 ChangeLogFab v1.9.150）。',
    },
    {
      anchor: 'col_ar_type',
      name: '操作类型列（人工充值审核记录 Tab）',
      group: '列',
      interaction: '彩色标签展示，不可点。',
      dataSource: '列 render 用 getOperationTypeLabel(row.type)。',
      edge: '2026-07-22 已修复：行对象已补齐 type 字段，getOperationTypeLabel 现能正确显示操作类型名称（2026-07-21 曾如实记录为未修复缺陷，详见 ChangeLogFab v1.9.150）。',
    },
    {
      anchor: 'col_ar_fundType',
      name: '子类型列（人工充值审核记录 Tab）',
      group: '列',
      interaction: '彩色标签展示，不可点。',
      dataSource: '列 render 用 getFundTypeLabel(row.type, row.fundType)。',
      edge: '2026-07-22 已修复：行对象已补齐 fundType 字段，getFundTypeLabel 现能正确显示子类型名称（2026-07-21 曾如实记录为未修复缺陷，详见 ChangeLogFab v1.9.150）。',
    },
    {
      anchor: 'col_ar_amount',
      name: '金额列（人工充值审核记录 Tab）',
      group: '列',
      interaction: '纯文本展示，不可点。',
      dataSource: '列 key 为 amount。',
      edge:
        '2026-07-22 已修复：AuditRecordRow 接口已补上 amount: number | null 字段。人工充值类行回填内容描述里的真实金额；修改会员密码/修改银行卡等非资金类行没有实际金额，值为 null，按 ProDataTable 兜底规则显示单杠"-"（这是当前设计上的正常状态，不是缺陷）（2026-07-21 曾如实记录为未修复缺陷，详见 ChangeLogFab v1.9.150）。',
    },
    {
      anchor: 'col_ar_state',
      name: '审核状态列（人工充值审核记录 Tab）',
      group: '列',
      interaction: '彩色标签展示，不可点：审核中(警示黄)/通过(成功绿)/拒绝(错误红) 三态。',
      dataSource: '列 render 用 renderStatusTag(row.state, {0:审核中,1:通过,2:拒绝})。',
      logic: '本列字段名与 mock 行数据真实对得上（row.state 存在，取值 0/1/2 与映射表精确匹配），2026-07-21 核实代码时本列即已正常工作、未受当时其它字段错位问题影响。',
    },
    {
      anchor: 'col_ar_creator',
      name: '操作人列（人工充值审核记录 Tab）',
      group: '列',
      interaction: '纯文本展示，不可点。',
      dataSource: '列 key 为 creator。',
      edge: '2026-07-22 已修复：行对象已补齐 creator 字段，正确显示操作人（2026-07-21 曾如实记录为未修复缺陷，详见 ChangeLogFab v1.9.150）。',
    },
    {
      anchor: 'col_ar_createTime',
      name: '操作时间列（人工充值审核记录 Tab）',
      group: '列',
      interaction: '纯文本展示，不可点。',
      dataSource: '列 key 为 createTimeStr，showTenantTimeZone 开启。',
      edge: '2026-07-22 已修复：行对象已补齐 createTimeStr 字段，showTenantTimeZone 渲染路径现能正确按商户时区显示操作时间（2026-07-21 曾如实记录为未修复缺陷，详见 ChangeLogFab v1.9.150）。',
    },
    {
      anchor: 'col_ar_auditTime',
      name: '审核时间列（人工充值审核记录 Tab）',
      group: '列',
      interaction: '纯文本展示，不可点。',
      dataSource: '列 key 为 auditTimeStr，showTenantTimeZone 开启。',
      edge:
        '2026-07-22 已修复：行对象已补齐 auditTimeStr 字段，showTenantTimeZone 渲染路径现能正确按商户时区显示审核时间；待审核行（auditTimeStr 为空字符串）正确显示空态，不参与时区格式化。本 Tab 14 列现已全部对齐 mock 数据正常显示（2026-07-21 曾如实记录为未修复缺陷，详见 ChangeLogFab v1.9.150）。',
    },
    {
      anchor: 'col_ar_auditorRemark',
      name: '审核备注列（人工充值审核记录 Tab）',
      group: '列',
      interaction: '纯文本展示，超长省略+悬浮 tooltip。',
      dataSource: '列 key 为 auditorRemark。',
      edge: '2026-07-22 已修复：行对象字段名已由 auditRemark 改为 auditorRemark，与列定义读取的 key 完全一致，正确显示审核备注（2026-07-21 曾如实记录为未修复缺陷，详见 ChangeLogFab v1.9.150）。',
    },
  ],

  // ============ 字段介绍 tab（按各自 Tab 列表列真实列序；仅列表列 + 定义；Tab①是表单页无列表列，不出现在此） ============
  fields: [
    // ---- Tab②人工充值审核列表（9 列，同 manualRechargeAuditList/index.vue tableColumns 顺序）----
    { name: '「人工充值审核列表」ID', def: '该条待审核记录的唯一编号。' },
    { name: '「人工充值审核列表」商户', def: '该条申请所属商户，标签形式展示。' },
    { name: '「人工充值审核列表」会员账号', def: '发起该笔操作对应的会员账号。' },
    { name: '「人工充值审核列表」会员ID', def: '发起该笔操作的会员唯一编号，可点击跳转会员详情。' },
    { name: '「人工充值审核列表」操作类型', def: '本次操作的一级分类（如人工充值），标签展示。' },
    { name: '「人工充值审核列表」子类型', def: '本次操作的二级分类（如人工存款），标签展示。' },
    { name: '「人工充值审核列表」操作时间', def: '该笔申请的发起时间，按所属商户时区显示。' },
    { name: '「人工充值审核列表」操作人', def: '发起该笔操作的后台账号。' },
    { name: '「人工充值审核列表」操作内容', def: '本次操作的完整描述文案（含充值金额/打码倍数/类型/备注等拼接信息）。' },

    // ---- Tab③人工充值审核记录（14 列，同 manualRechargeAuditRecords/index.vue tableColumns 顺序）----
    { name: '「人工充值审核记录」ID', def: '该条操作记录的唯一编号。' },
    { name: '「人工充值审核记录」商户', def: '该条记录所属商户，标签形式展示。' },
    { name: '「人工充值审核记录」会员账号', def: '发起该笔操作对应的会员账号。' },
    { name: '「人工充值审核记录」会员ID', def: '发起该笔操作的会员唯一编号，可点击跳转会员详情。' },
    { name: '「人工充值审核记录」操作类型', def: '本次操作的一级分类，标签展示。' },
    { name: '「人工充值审核记录」子类型', def: '本次操作的二级分类，标签展示。' },
    { name: '「人工充值审核记录」金额', def: '本次操作涉及的金额；非资金类操作（如改密码/改银行卡）没有金额，显示"-"。' },
    { name: '「人工充值审核记录」操作内容', def: '本次操作的完整描述文案。' },
    { name: '「人工充值审核记录」审核状态', def: '该笔操作的最终审核结果：审核中 / 通过 / 拒绝，彩色标签区分。' },
    { name: '「人工充值审核记录」操作人', def: '发起该笔操作的后台账号。' },
    { name: '「人工充值审核记录」操作时间', def: '该笔操作的发起时间，按所属商户时区显示。' },
    { name: '「人工充值审核记录」审核人', def: '审批该笔申请的后台账号（免审核自动通过时显示 system）。' },
    { name: '「人工充值审核记录」审核时间', def: '该笔申请完成审核的时间，按所属商户时区显示。' },
    { name: '「人工充值审核记录」审核备注', def: '审核人填写的通过/拒绝说明（免审核自动通过时显示固定文案"无需审核，自动通过"）。' },
  ],
};

export default manual;
