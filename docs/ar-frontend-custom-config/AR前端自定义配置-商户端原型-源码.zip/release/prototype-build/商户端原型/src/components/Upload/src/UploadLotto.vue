<template>
  <div class="basic-upload">
    <div class="basic-upload__list">
      <div
        v-for="(item, index) in imageList"
        :key="item"
        :class="['basic-upload__item', { 'basic-upload__item--compact': compact }]"
        :style="itemStyle"
      >
        <div class="basic-upload__item-content">
          <div class="basic-upload__image">
            <img :src="getImageUrl(item)" alt="uploaded" />
          </div>

          <div v-if="!disabled" class="basic-upload__actions">
            <n-icon
              v-if="width > 80"
              :size="18"
              class="basic-upload__action"
              @click="handlePreview(item)"
            >
              <EyeOutlined />
            </n-icon>
            <n-icon
              v-if="!readonly"
              :size="18"
              class="basic-upload__action"
              @click="handleRemove(index)"
            >
              <DeleteOutlined />
            </n-icon>
          </div>
        </div>
      </div>

      <div v-if="canUpload">
        <n-upload
          v-bind="uploadProps"
          :custom-request="handleUpload"
          :file-list-style="{ display: 'none' }"
          :on-before-upload="handleBeforeUpload"
        >
          <n-spin :show="uploading" size="small">
            <slot>
              <div
                class="basic-upload__trigger"
                :class="{ 'basic-upload__trigger--uploading': uploading }"
                :style="itemStyle"
              >
                <div class="basic-upload__trigger-content">
                  <n-icon :size="18">
                    <PlusOutlined />
                  </n-icon>
                  <span v-if="width > 80" class="basic-upload__trigger-text">
                    {{ t('common.upload_image') }}
                  </span>
                </div>
                <span v-if="uploading && width > 80" class="basic-upload__loading-text">
                  {{ t('common.loading') }}
                </span>
              </div>
            </slot>
          </n-spin>
        </n-upload>
      </div>
    </div>

    <n-alert v-if="helpText" :title="t('common.tip')" type="info" class="mt-2">
      {{ helpText }}
    </n-alert>
  </div>
</template>

<script setup lang="ts">
  import { h, ref, computed, watch, type CSSProperties } from 'vue';
  import {
    useMessage,
    useDialog,
    useModal,
    type UploadCustomRequestOptions,
    type UploadFileInfo,
  } from 'naive-ui';
  import { EyeOutlined, DeleteOutlined, PlusOutlined } from '@vicons/antd';
  import { useI18n } from 'vue-i18n';
  import { encodeImageWithJsquash } from '@/hooks';
  import { ImageCropper } from '@/components';
  import { componentSetting } from '@/hooks/setting';
  import { getFullImageUrl } from '@/utils';
  import type { ImageDimensions, BasicUploadInstance } from './types';
  import { DEFAULT_ACCEPT, DEFAULT_MAX_SIZE, DEFAULT_SIZE } from './types';

  defineOptions({
    name: 'UploadLotto',
  });

  const props = withDefaults(
    defineProps<{
      accept?: string;
      helpText?: string;
      maxSize?: number;
      maxNumber?: number;
      value?: string[];
      width?: number;
      height?: number;
      previewWidth?: number;
      verifySize?: boolean;
      fileType?: any;
      fullPath?: boolean;
      readonly?: boolean;
      disabled?: boolean;
      tenantId: number;
      customPath?: number;
      beforeUploadExtra?: (file: File, dimensions: ImageDimensions) => boolean | Promise<boolean>;
      compact?: boolean;
      enableCrop?: boolean;
      cropAspectRatio?: number;
      cropOutputWidth?: number;
      cropOutputHeight?: number;
      cropTitle?: string;
    }>(),
    {
      accept: DEFAULT_ACCEPT,
      helpText: '',
      maxSize: DEFAULT_MAX_SIZE,
      maxNumber: Infinity,
      value: () => [],
      width: DEFAULT_SIZE,
      height: DEFAULT_SIZE,
      previewWidth: 0,
      verifySize: false,
      fileType: 'other' as any,
      fullPath: false,
      readonly: false,
      disabled: false,
      tenantId: -1,
      customPath: 1,
      compact: false,
      enableCrop: false,
      cropAspectRatio: 0,
      cropOutputWidth: 0,
      cropOutputHeight: 0,
      cropTitle: '',
    },
  );

  const emit = defineEmits<{
    (e: 'update:value', value: string[]): void;
    (e: 'uploadChange', value: string): void;
    (e: 'delete', value: string[]): void;
  }>();

  const { t } = useI18n();
  const message = useMessage();
  const dialog = useDialog();
  const modal = useModal();

  const imageList = ref<string[]>([]);
  const urlMap = ref<Record<string, string>>({});
  const uploading = ref(false);
  const blockedUploadIds = new Map<string, number>();

  const FILE_TYPE_ALIAS_MAP: Record<string, string[]> = {
    jpg: ['jpeg', 'image/jpg', 'image/jpeg'],
    jpeg: ['jpg', 'image/jpg', 'image/jpeg'],
    png: ['image/png'],
    gif: ['image/gif'],
    webp: ['image/webp'],
    svg: ['svg+xml', 'image/svg', 'image/svg+xml'],
    ico: ['icon', 'x-icon', 'vnd.microsoft.icon', 'image/x-icon', 'image/vnd.microsoft.icon'],
  };
  const IMAGE_DIMENSION_EXTENSIONS = new Set([
    'jpg',
    'jpeg',
    'png',
    'gif',
    'webp',
    'svg',
    'bmp',
    'ico',
    'avif',
  ]);

  const itemStyle = computed<CSSProperties>(() => ({
    width: `${props.previewWidth || props.width}px`,
    height: `${props.previewWidth || props.height}px`,
  }));

  const canUpload = computed(() => imageList.value.length < props.maxNumber);

  const acceptTypes = computed(() => props.accept.split(',').map((item) => item.trim()));

  const uploadProps = computed(() => ({
    accept: acceptTypes.value.map((type) => `.${type}`).join(','),
    disabled: props.disabled || uploading.value,
  }));

  function getImageUrl(path: string): string {
    const url = urlMap.value[path] || path;
    return getFullImageUrl(url);
  }

  function checkFileType(fileType: string): boolean {
    return componentSetting.upload.fileType.includes(fileType);
  }

  function normalizeAcceptType(type: string): string {
    return type.trim().toLowerCase().replace(/^\./, '');
  }

  function getFileExtension(fileName: string): string {
    const match = /\.([^.]+)$/.exec(fileName.toLowerCase());
    return match?.[1] || '';
  }

  function canMeasureImageDimensions(file: File): boolean {
    if (file.type.toLowerCase().startsWith('image/')) {
      return true;
    }

    return IMAGE_DIMENSION_EXTENSIONS.has(getFileExtension(file.name));
  }

  function createTypeVariantSet(type: string): Set<string> {
    const normalizedType = normalizeAcceptType(type);
    const typeVariants = new Set<string>();
    if (!normalizedType) {
      return typeVariants;
    }

    typeVariants.add(normalizedType);

    const slashSegments = normalizedType.split('/');
    const subtype = slashSegments.length > 1 ? normalizeAcceptType(slashSegments[1] || '') : '';
    if (subtype) {
      typeVariants.add(subtype);
      typeVariants.add(normalizeAcceptType(subtype.split('+')[0] || ''));
      const suffix = normalizeAcceptType(subtype.split('.').pop() || '');
      if (suffix) {
        typeVariants.add(suffix);
      }
    }

    const aliasTypes = FILE_TYPE_ALIAS_MAP[normalizedType] || [];
    aliasTypes.forEach((aliasType) => {
      typeVariants.add(normalizeAcceptType(aliasType));
    });

    return typeVariants;
  }

  function getAcceptedTypesForValidation(): string[] {
    if (props.accept === DEFAULT_ACCEPT) {
      return [...acceptTypes.value, ...componentSetting.upload.fileType];
    }
    return acceptTypes.value;
  }

  function isAcceptedFileType(file: File): boolean {
    const acceptedTypes = getAcceptedTypesForValidation();
    if (acceptedTypes.length === 0) {
      return true;
    }

    const fileTypeCandidates = new Set<string>();
    const fileExtension = getFileExtension(file.name);
    if (fileExtension) {
      createTypeVariantSet(fileExtension).forEach((typeVariant) => {
        fileTypeCandidates.add(typeVariant);
      });
    }

    createTypeVariantSet(file.type).forEach((typeVariant) => {
      fileTypeCandidates.add(typeVariant);
    });

    return acceptedTypes.some((acceptedType) => {
      const acceptedVariants = createTypeVariantSet(acceptedType);
      return Array.from(acceptedVariants).some((typeVariant) =>
        fileTypeCandidates.has(typeVariant),
      );
    });
  }

  function markBlockedUpload(fileId?: string): void {
    if (!fileId) {
      return;
    }

    const now = Date.now();
    blockedUploadIds.set(fileId, now);

    blockedUploadIds.forEach((timestamp, currentFileId) => {
      if (now - timestamp > 5000) {
        blockedUploadIds.delete(currentFileId);
      }
    });
  }

  function consumeBlockedUpload(fileId?: string): boolean {
    if (!fileId) {
      return false;
    }

    const isBlocked = blockedUploadIds.has(fileId);
    if (isBlocked) {
      blockedUploadIds.delete(fileId);
    }
    return isBlocked;
  }

  function isCroppableFile(file: File): boolean {
    const mime = file.type.toLowerCase();
    const name = file.name.toLowerCase();
    if (mime === 'image/jpeg' || mime === 'image/png' || mime === 'image/webp') {
      return true;
    }
    return /\.(jpg|jpeg|png|webp)$/i.test(name);
  }

  function isWebpConvertibleFile(file: File, fallbackType = ''): boolean {
    const mime = (file.type || fallbackType).toLowerCase();
    if (mime === 'image/jpeg' || mime === 'image/png') {
      return true;
    }

    const name = file.name.toLowerCase();
    return /\.(jpg|jpeg|png)$/i.test(name);
  }

  function formatSize(bytes: number, decimals = 2): string {
    if (bytes === 0) return '0 Bytes';
    if (bytes >= 1024 * 1024) {
      return (bytes / (1024 * 1024)).toFixed(decimals) + ' MB';
    }
    return bytes.toFixed(decimals) + ' KB';
  }

  function getImageDimensions(file: File): Promise<ImageDimensions> {
    return new Promise((resolve, reject) => {
      const img = new Image();
      img.src = URL.createObjectURL(file);
      img.onload = () => {
        const dimensions: ImageDimensions = {
          width: img.width,
          height: img.height,
          size: file.size,
        };
        URL.revokeObjectURL(img.src);
        resolve(dimensions);
      };
      img.onerror = (error) => {
        URL.revokeObjectURL(img.src);
        reject(error);
      };
    });
  }

  function openCropModal(file: File): Promise<File | null> {
    return new Promise((resolve) => {
      const modalInstance = modal.create({
        preset: 'card',
        title: props.cropTitle || t('common.upload.preview'),
        style: { width: '720px' },
        content: () =>
          h(ImageCropper, {
            file,
            aspectRatio: props.cropAspectRatio,
            outputWidth: props.cropOutputWidth,
            outputHeight: props.cropOutputHeight,
            onCancel: () => {
              modalInstance.destroy();
              resolve(null);
            },
            onConfirm: (blob: Blob) => {
              modalInstance.destroy();
              resolve(
                new File([blob], file.name, {
                  type: blob.type || file.type,
                  lastModified: Date.now(),
                }),
              );
            },
          }),
      });
    });
  }

  // 原型阶段：本地 blob URL 模拟上传，无真实接口
  async function uploadToLottoOss(file: File | Blob): Promise<{ value: string }> {
    const url = URL.createObjectURL(file);
    return { value: url };
  }

  function handlePreview(path: string) {
    const url = getImageUrl(path);
    modal.create({
      preset: 'card',
      title: t('common.upload.preview'),
      bordered: false,
      style: { width: '520px' },
      content: () => h('img', { src: url, class: 'w-full', alt: 'preview' }),
    });
  }

  function handleRemove(index: number) {
    dialog.info({
      title: t('common.tip'),
      content: t('common.upload.deleteConfirm'),
      positiveText: t('common.confirm'),
      negativeText: t('common.cancel'),
      onPositiveClick: () => {
        imageList.value.splice(index, 1);
        emit('delete', imageList.value);
        emit('update:value', imageList.value);
      },
    });
  }

  async function handleBeforeUpload({ file }: { file: UploadFileInfo }): Promise<boolean> {
    const fileInfo = file.file as File;
    if (!fileInfo) {
      markBlockedUpload(file.id);
      return false;
    }

    const isImageType = canMeasureImageDimensions(fileInfo);

    if (props.verifySize && isImageType && !props.enableCrop) {
      const dimensions = await getImageDimensions(fileInfo);
      if (dimensions.width !== props.width || dimensions.height !== props.height) {
        markBlockedUpload(file.id);
        message.error(
          t('common.upload.fileSizeError', { width: props.width, height: props.height }),
        );
        return false;
      }
    }

    if (props.maxSize && fileInfo.size / 1024 >= props.maxSize) {
      markBlockedUpload(file.id);
      message.error(t('common.upload.fileMaxSizeError', { size: formatSize(props.maxSize, 0) }));
      return false;
    }

    const defaultTypes = DEFAULT_ACCEPT;
    const isValidType =
      props.accept === defaultTypes && checkFileType(fileInfo.type)
        ? true
        : isAcceptedFileType(fileInfo);

    if (!isValidType && acceptTypes.value.length > 0) {
      markBlockedUpload(file.id);
      message.warning(
        t('common.upload.fileTypeError', {
          types:
            props.accept === defaultTypes
              ? componentSetting.upload.fileType.join(',')
              : acceptTypes.value.join(','),
        }),
      );
      return false;
    }

    if (props.beforeUploadExtra) {
      const dimensions = await getImageDimensions(fileInfo);
      const result = props.beforeUploadExtra(fileInfo, dimensions);
      const passed = result instanceof Promise ? await result : result;
      if (!passed) {
        markBlockedUpload(file.id);
      }
      return passed;
    }

    return true;
  }

  async function handleUpload({ file, onFinish, onError }: UploadCustomRequestOptions) {
    if (consumeBlockedUpload(file.id)) {
      onFinish();
      return;
    }

    const uploadSourceFile = file.file as File | null;
    if (!uploadSourceFile) {
      onError();
      return;
    }

    uploading.value = true;
    try {
      let uploadFile: File | Blob = uploadSourceFile;
      let sourceFile = uploadSourceFile;
      const fileType = file.type || '';
      let filename = file.name;

      if (props.enableCrop && sourceFile && isCroppableFile(sourceFile)) {
        const croppedFile = await openCropModal(sourceFile);
        if (!croppedFile) {
          onFinish();
          return;
        }
        uploadFile = croppedFile;
        sourceFile = croppedFile;
        filename = croppedFile.name;
      }

      const shouldConvertToWebp = isWebpConvertibleFile(sourceFile, fileType);

      if (shouldConvertToWebp) {
        try {
          const webpBlob = await encodeImageWithJsquash({
            source: sourceFile,
            mimeType: 'image/webp',
            quality: 92,
          });
          const sourceName = sourceFile.name || file.name;
          const nextName = sourceName.replace(/\.\w+$/i, '.webp');
          filename = nextName === sourceName ? `${sourceName}.webp` : nextName;
          const webpFile = new File([webpBlob], filename, {
            type: 'image/webp',
            lastModified: Date.now(),
          });
          uploadFile = webpFile;
          sourceFile = webpFile;
        } catch (error) {
          console.warn('WebP conversion skipped, fallback to original file.', error);
        }
      }

      const result = await uploadToLottoOss(uploadFile);
      const imageKey = result.value;

      imageList.value.push(imageKey);

      emit('uploadChange', imageKey);
      emit('update:value', imageList.value);
      message.success(t('common.upload.uploadSuccess'));
      onFinish();
    } catch (error) {
      console.error('Upload error:', error);
      message.error(t('common.upload.uploadError'));
      onError();
    } finally {
      uploading.value = false;
    }
  }

  function setImages(images: string[] | string) {
    imageList.value = [];
    urlMap.value = {};
    if (Array.isArray(images)) {
      imageList.value = images.filter(Boolean);
    } else if (images) {
      imageList.value.push(images);
    }
  }

  function getImages(): string[] {
    return [...imageList.value];
  }

  function clear() {
    imageList.value = [];
    urlMap.value = {};
  }

  watch(
    () => props.value,
    (newVal) => {
      if (newVal) {
        setImages(newVal);
        return;
      }
      clear();
    },
    { immediate: true },
  );

  defineExpose<BasicUploadInstance>({
    setImages,
    getImages,
    clear,
  });
</script>

<style lang="less" scoped>
  .basic-upload {
    width: 100%;

    &__list {
      display: flex;
      flex-wrap: wrap;
      align-items: center;
      gap: 8px;
    }

    &__item {
      position: relative;
      padding: 8px;
      border: 1px solid #d9d9d9;
      border-radius: 4px;
      display: flex;
      justify-content: center;
      align-items: center;
      overflow: hidden;

      &--compact {
        padding: 0;
      }

      &:hover .basic-upload__actions {
        opacity: 1;
      }

      &:hover &-content::before {
        opacity: 1;
      }
    }

    &__item-content {
      position: relative;
      width: 100%;
      height: 100%;

      &::before {
        content: '';
        position: absolute;
        inset: 0;
        z-index: 1;
        background-color: rgba(0, 0, 0, 0.5);
        opacity: 0;
        transition: opacity 0.3s;
      }
    }

    &__image {
      width: 100%;
      height: 100%;
      display: flex;
      justify-content: center;
      align-items: center;

      img {
        max-width: 100%;
        max-height: 100%;
        object-fit: contain;
      }
    }

    &__actions {
      position: absolute;
      top: 50%;
      left: 50%;
      z-index: 10;
      transform: translate(-50%, -50%);
      display: flex;
      align-items: center;
      gap: 8px;
      opacity: 0;
      transition: opacity 0.3s;
    }

    &__action {
      color: rgba(255, 255, 255, 0.85);
      cursor: pointer;
      transition: color 0.2s;

      &:hover {
        color: #fff;
      }
    }

    &__trigger {
      position: relative;
      border: 1px dashed #d9d9d9;
      border-radius: 4px;
      background: #fafafa;
      cursor: pointer;
      display: flex;
      justify-content: center;
      align-items: center;
      transition: border-color 0.3s;

      &:hover {
        border-color: var(--ui-accent-solid);
      }

      &--uploading {
        cursor: not-allowed;
      }
    }

    &__trigger-content {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      color: #999;
      gap: 4px;
    }

    &__trigger-text,
    &__loading-text {
      font-size: 12px;
      line-height: 1.2;
    }

    &__loading-text {
      position: absolute;
      left: 50%;
      bottom: 10px;
      transform: translateX(-50%);
      color: #999;
    }
  }
</style>
