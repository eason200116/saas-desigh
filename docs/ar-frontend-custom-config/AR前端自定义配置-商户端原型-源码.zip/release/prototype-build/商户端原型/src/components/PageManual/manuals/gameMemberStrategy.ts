// 策略明细（总控端 admin · game_member_strategy）功能说明书。
// 锚定 src/views/game/member/strategy/index.vue + data.ts 真实控件（R53 实证、不臆造）。
// 标准 ProCrudTable 列表页：7 搜索项（商户为普通单选、本页无代理合并）+ 13 列 + 策略 Tag；纯查询、无行操作。

import type { PageManual } from '../types';

const manual: PageManual = {
  route: 'game_member_strategy',
  title: '策略明细',
  overview:
    '总控端查询会员的自动投注策略（对刷 / 跟投 / 对冲）执行明细：按商户、子游戏、策略类型、币种、会员ID、策略单号、创建时间筛选。查看每条策略的开启 / 结束、期数、投注金额、输赢额、盈利率。投注 / 输赢列左对齐（R61），输赢额 / 盈利率带正负语义色。本页只查询、无行操作。',
  items: [
    {
      anchor: 'merchant',
      name: '商户',
      group: '搜索',
      interaction: '下拉单选、必选（本页为普通单选，无「所属代理」合并）。',
      dataSource: '选项来自 MEMBER_MERCHANT_OPTIONS。',
      logic: '按商户筛选策略。',
      limit: '必填。',
      edge: '不选无法查询（表单校验拦截，提示「请选择商户」）。',
    },
    {
      anchor: 'memberId',
      name: '会员ID',
      group: '搜索',
      interaction: '文本输入、模糊匹配。',
      dataSource: '用户输入。',
      logic: '按平台会员ID筛选。',
      limit: '选填；最多 50 字（searchKw）。',
      edge: '空 = 不按会员ID筛。',
    },
    {
      anchor: 'strategyNo',
      name: '策略单号',
      group: '搜索',
      interaction: '文本输入、模糊匹配。',
      dataSource: '用户输入。',
      logic: '按策略单号筛选。',
      limit: '选填；最多 50 字。',
      edge: '空 = 不按策略单号筛。',
    },
    {
      anchor: 'subGame',
      name: '子游戏',
      group: '搜索',
      interaction: '下拉单选、可清空。',
      dataSource: '选项来自 STRATEGY_SUBGAME_OPTIONS。',
      logic: '按子游戏筛选。',
      limit: '选填。',
      edge: '不选 = 全部子游戏。',
    },
    {
      anchor: 'strategyType',
      name: '策略类型',
      group: '搜索',
      interaction: '下拉单选：对刷策略 / 跟投策略 / 对冲策略，可清空。',
      dataSource: '选项来自 STRATEGY_OPTIONS。',
      logic: '按策略类型筛选。',
      limit: '选填。',
    },
    {
      anchor: 'currency',
      name: '币种',
      group: '搜索',
      interaction: '下拉单选、可清空。',
      dataSource: '选项来自 MEMBER_CURRENCY_OPTIONS。',
      logic: '按币种筛选。',
      limit: '选填。',
    },
    {
      anchor: 'createTimeRange',
      name: '创建时间',
      group: '搜索',
      interaction: '日期时间范围选择（proDateRange，精确到秒）。',
      dataSource: '用户选择。',
      logic: '按策略创建时间范围筛选。',
      limit: '不可选未来（allowFuture false）。',
      edge: '空 = 不按创建时间筛。',
    },

    // ============ 关键列（策略列）============
    {
      anchor: 'col_strategy',
      name: '策略列',
      group: '列',
      interaction: '只读 Tag，按策略类型着色：对刷橙 / 对冲绿 / 跟投蓝。',
      dataSource: '行数据 strategyType / strategyText。',
      logic: '仅展示策略类型，不可点。',
    },
  ],

  // ============ 字段介绍 tab（列序照列表；仅列表列 + 定义）============
  fields: [
    { name: '商户', def: '策略所属会员的商户。' },
    { name: '会员ID', def: '执行该策略的会员平台ID。' },
    { name: '策略单号', def: '一条策略的唯一单号。' },
    { name: '子游戏', def: '该策略作用的子游戏。' },
    { name: '策略', def: '策略类型：对刷 / 跟投 / 对冲。' },
    { name: '币种', def: '该策略投注 / 结算的币种。' },
    { name: '开启时间', def: '策略开始执行的时间（按商户时区展示）。' },
    { name: '结束时间', def: '策略结束的时间。' },
    { name: '结束原因', def: '策略结束的原因（达到止盈 / 手动结束 / 进行中）。' },
    { name: '期数', def: '该策略执行的期数（计数列）。' },
    { name: '投注金额', def: '该策略累计投注金额。' },
    { name: '输赢额', def: '该策略累计净输赢（赢绿输红）。' },
    { name: '盈利率(%)', def: '该策略的盈利率百分比（正绿负红）。' },
  ],
};

export default manual;
