// 域名解析日志（商户端 tenant · operations_domainResolveLog）功能说明书。
// 锚定 src/views/operations/domainResolveLog/index.vue + data.ts 真实控件（R53 实证、不臆造）。
// V3 新增功能，V1旧后台无对应模块；纯只读查询页，无新增/编辑/删除。

import type { PageManual } from '../types';

const manual: PageManual = {
  route: 'operations_domainResolveLog',
  title: '域名解析日志',
  overview:
    '商户端「运营管理 › 域名解析日志」页，只读查询域名DNS解析健康检测记录（每条记录=某次对某域名的一次' +
    '解析检测结果），无新增/编辑/删除，行操作仅"详情"与"重新检测"两项。' +
    '2026-07-22核实代码发现："重新检测"按钮点击只弹出一条通用提示信息(message.info)，没有调用任何接口、' +
    '不会真正触发检测，是本页(以及全站同类占位按钮)里完全未实现的操作。如实记录，未修复。',
  items: [
    {
      anchor: 'merchant',
      name: '商户',
      group: '搜索',
      interaction: '下拉筛选。',
    },
    {
      anchor: 'domain',
      name: '域名',
      group: '搜索',
      interaction: '文本框，可清空，模糊匹配。',
    },
    {
      anchor: 'result',
      name: '检测结果',
      group: '搜索',
      interaction: '下拉单选，可清空；选项：成功/失败。',
    },
    {
      anchor: 'checkTime',
      name: '检测时间',
      group: '搜索',
      interaction: '日期时间区间选择，精确到秒，最长跨度90天，不允许选未来日期。',
      limit: '最长跨度90天。',
    },
    {
      anchor: 'reset',
      name: '重置',
      group: '搜索',
      interaction: 'ProCrudTable内置重置按钮。',
    },
    {
      anchor: 'act_detail',
      name: '详情',
      group: '操作',
      interaction: '每行常驻，默认色按钮，点击打开只读详情弹窗（440px宽）。',
      logic: '弹窗以描述列表展示该条记录全部字段：域名/域名类型/解析IP/检测节点/检测方式/TTL/检测结果/响应时间/检测时间。',
    },
    {
      anchor: 'act_recheck',
      name: '重新检测',
      group: '操作',
      interaction: '每行常驻，主色按钮，点击后弹出一条通用提示。',
      edge: '纯占位，不调用任何接口、不会真正触发重新检测，点击前后行数据无任何变化。',
    },
  ],
  fields: [
    { name: '商户（列）', def: '该检测记录所属商户，标签展示。' },
    { name: 'ID', def: '该检测记录的唯一编号。' },
    { name: '域名', def: '被检测的域名。' },
    { name: '域名类型', def: '主域名/推广域名/防封谷歌页/防封苹果页，Tag展示。' },
    { name: '解析IP', def: '该域名本次解析得到的IP地址。' },
    { name: '检测节点', def: '发起本次检测的节点位置。' },
    { name: '检测方式', def: '自动/手动，本次检测的触发方式。' },
    { name: '检测结果', def: '成功(绿)/失败(红)。' },
    { name: '响应时间', def: '本次解析检测的耗时，单位毫秒。' },
    { name: 'TTL', def: '该域名DNS记录的存活时间(秒)。' },
    { name: '检测时间', def: '本次检测的执行时间。' },
  ],
};

export default manual;
