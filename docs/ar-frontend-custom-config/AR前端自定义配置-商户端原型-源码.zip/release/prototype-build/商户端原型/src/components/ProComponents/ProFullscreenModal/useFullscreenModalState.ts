/**
 * @description 弹窗全屏状态层 composable：管理 isFullscreen ref + toggleFullscreen + currentStyle 三件套。是 ProFullscreenModal 基座的最底层，可单独使用以支持复杂场景（如 records/workbench 审单弹窗保留 elapsed 计时器与 Reviewing tag 的自定义标题）。
 * @date 2026-05-08
 * @scope src/components/ProComponents/ProFullscreenModal
 */

import { computed, ref, type ComputedRef, type CSSProperties, type Ref } from 'vue';
import { MODAL_FULLSCREEN_STYLE } from './constants';

export interface UseFullscreenModalStateReturn {
  /** 当前是否全屏 */
  isFullscreen: Ref<boolean>;
  /** 切换全屏状态 */
  toggleFullscreen: () => void;
  /** 显式设置全屏状态 */
  setFullscreen: (value: boolean) => void;
  /** 当前应该应用到 modal.style 的 CSSProperties；自动随 isFullscreen 变化 */
  currentStyle: ComputedRef<CSSProperties>;
}

/**
 * 弹窗全屏状态 composable。
 *
 * @param normalStyle 常态弹窗样式（默认在 currentStyle 里返回此值）
 * @param fullscreenStyle 全屏样式（默认 MODAL_FULLSCREEN_STYLE）
 */
export function useFullscreenModalState(
  normalStyle: CSSProperties,
  fullscreenStyle: CSSProperties = MODAL_FULLSCREEN_STYLE,
): UseFullscreenModalStateReturn {
  const isFullscreen = ref(false);

  const setFullscreen = (value: boolean) => {
    isFullscreen.value = value;
  };

  const toggleFullscreen = () => {
    isFullscreen.value = !isFullscreen.value;
  };

  const currentStyle = computed<CSSProperties>(() =>
    isFullscreen.value ? fullscreenStyle : normalStyle,
  );

  return { isFullscreen, toggleFullscreen, setFullscreen, currentStyle };
}
