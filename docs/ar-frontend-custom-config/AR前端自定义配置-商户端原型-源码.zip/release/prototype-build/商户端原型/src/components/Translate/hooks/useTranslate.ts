import { onBeforeUnmount, ref, type Ref } from 'vue';
import { useI18n } from 'vue-i18n';
import { useMessage } from 'naive-ui';
import { api } from '../data';
import { type TranslateLanguage, createLanguageCodeLookup, mapTranslationResults } from '../shared';

type UseTranslateOptions = {
  sourceLang: Ref<string>;
  sortedLanguages: Ref<TranslateLanguage[]>;
  getSourceContent: () => string | undefined;
  applyTranslatedMap: (translatedMap: Record<string, string>) => void;
  afterApply?: () => void;
  isSourceContentEmpty?: (content: string | undefined) => boolean;
};

function defaultIsSourceContentEmpty(content: string | undefined) {
  return !content?.trim();
}

/**
 * 通用翻译 Hook：统一处理多语言翻译请求、并发保护和提示文案。
 */
export function useTranslate(options: UseTranslateOptions) {
  const { t } = useI18n();
  const message = useMessage();
  const translating = ref(false);
  const isUnmounted = ref(false);
  let translateRequestId = 0;

  async function handleTranslateAll() {
    if (translating.value) return;

    const sourceContent = options.getSourceContent();
    const isEmpty = options.isSourceContentEmpty || defaultIsSourceContentEmpty;
    if (isEmpty(sourceContent)) {
      message.warning(t('common.translate.noSourceText'));
      return;
    }

    const targetLangs = options.sortedLanguages.value
      .filter((lang) => lang.code !== options.sourceLang.value)
      .map((lang) => lang.code);
    if (!targetLangs.length) return;

    translating.value = true;
    const requestId = ++translateRequestId;

    try {
      const { data } = await api.assistant.translate({
        content: sourceContent || '',
        targetLanguages: targetLangs,
        sourceLanguage: options.sourceLang.value,
      });

      if (isUnmounted.value || requestId !== translateRequestId) return;

      const translatedMap = mapTranslationResults(
        data?.translations,
        createLanguageCodeLookup(options.sortedLanguages.value),
      );
      options.applyTranslatedMap(translatedMap);
      options.afterApply?.();
      message.success(t('common.translate.success'));
    } catch {
      if (isUnmounted.value || requestId !== translateRequestId) return;
      message.error(t('common.translate.failed'));
    } finally {
      if (!isUnmounted.value && requestId === translateRequestId) {
        translating.value = false;
      }
    }
  }

  onBeforeUnmount(() => {
    isUnmounted.value = true;
    translateRequestId += 1;
  });

  return {
    translating,
    handleTranslateAll,
  };
}
