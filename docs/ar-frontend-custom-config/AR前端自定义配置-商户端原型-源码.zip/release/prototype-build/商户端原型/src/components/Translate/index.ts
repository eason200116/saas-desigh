import TranslateInput from './TranslateInput.vue';

export { TranslateInput };
