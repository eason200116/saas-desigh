export { default as TableAction } from './src/components/TableAction.vue';
export { default as Popconfirm } from './src/components/Popconfirm.vue';
export * from './src/types/tableAction';
export * from './src/createActionColumn';
