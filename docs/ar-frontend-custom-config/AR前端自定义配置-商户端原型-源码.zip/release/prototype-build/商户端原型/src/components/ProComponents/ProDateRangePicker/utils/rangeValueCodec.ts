import {
  endOfDay,
  formatParts,
  parseParts,
  partsToUtcMs,
  resolveTimezoneId,
  startOfDay,
  utcMsToParts,
  type ZonedDateTimeParts,
} from './zonedDateMath';

/**
 * 粘贴解析支持的分隔符与日期 pattern 集合。
 * 顺序：分隔符按"先长后短"排，避免 "to" 误匹配 "today" 子串（用 word boundary）。
 * 日期 pattern 按"信息量从多到少"排，先尝试带秒的格式。
 */
const RANGE_SEPARATORS = [' to ', '~', '→', '至', ',', '\t', '\n'];
const DATE_PATTERNS = [
  'yyyy-MM-dd HH:mm:ss',
  'yyyy-MM-dd HH:mm',
  'yyyy-MM-dd',
  'yyyy/MM/dd HH:mm:ss',
  'yyyy/MM/dd HH:mm',
  'yyyy/MM/dd',
  'yyyy.MM.dd HH:mm:ss',
  'yyyy.MM.dd',
];

/**
 * 尝试用所有候选 pattern 解析单个日期字符串；命中即返回 ZonedDateTimeParts。
 */
function tryParseAnyPattern(value: string): ZonedDateTimeParts | null {
  for (const pattern of DATE_PATTERNS) {
    const parts = parseParts(value, pattern);
    if (parts) return parts;
  }
  return null;
}

/**
 * 解析粘贴的范围文本，返回 wall-clock parts（不带时区，调用方按上下文 tz 编码）。
 * 支持 "yyyy-MM-dd HH:mm:ss ~ yyyy-MM-dd HH:mm:ss" / "to" / "至" 等多种分隔符。
 * 解析失败返回 null（调用方应静默忽略，不打断默认粘贴行为）。
 */
export function parsePastedRange(text: string): ZonedRangeDraft | null {
  const cleaned = text?.trim();
  if (!cleaned) return null;

  for (const sep of RANGE_SEPARATORS) {
    const idx = cleaned.indexOf(sep);
    if (idx <= 0 || idx + sep.length >= cleaned.length) continue;
    const rawStart = cleaned.slice(0, idx).trim();
    const rawEnd = cleaned.slice(idx + sep.length).trim();
    if (!rawStart || !rawEnd) continue;
    const start = tryParseAnyPattern(rawStart);
    const end = tryParseAnyPattern(rawEnd);
    if (start && end) return { start, end };
  }
  return null;
}

export type ExternalRangeValue = [number, number] | [string, string] | null;
export type OutboundRangeTuple = [number, number] | [string, string];

export interface ZonedRangeDraft {
  start: ZonedDateTimeParts | null;
  end: ZonedDateTimeParts | null;
}

export interface RangeValueCodecOptions {
  valueFormat: 'timestamp' | 'string';
  valueStringPattern: string;
  timezone: string | null | undefined;
}

export function decodeExternalValue(
  value: ExternalRangeValue,
  options: RangeValueCodecOptions,
): ZonedRangeDraft {
  if (!value || value.length !== 2) return { start: null, end: null };
  const [start, end] = value;
  const timezoneId = resolveTimezoneId(options.timezone);

  if (typeof start === 'number' && typeof end === 'number') {
    return {
      start: utcMsToParts(start, timezoneId),
      end: utcMsToParts(end, timezoneId),
    };
  }

  if (typeof start === 'string' && typeof end === 'string') {
    return {
      start: parseParts(start, options.valueStringPattern),
      end: parseParts(end, options.valueStringPattern),
    };
  }

  return { start: null, end: null };
}

export function encodeExternalValue(
  draft: ZonedRangeDraft,
  options: RangeValueCodecOptions,
): OutboundRangeTuple | null {
  if (!draft.start || !draft.end) return null;
  const timezoneId = resolveTimezoneId(options.timezone);

  if (options.valueFormat === 'string') {
    return [
      formatParts(draft.start, options.valueStringPattern),
      formatParts(draft.end, options.valueStringPattern),
    ];
  }

  return [partsToUtcMs(draft.start, timezoneId), partsToUtcMs(draft.end, timezoneId)];
}

export function normalizeDraftForConfirm(
  draft: ZonedRangeDraft,
  showTime: boolean,
): ZonedRangeDraft {
  if (!draft.start || !draft.end) return draft;

  if (showTime) {
    return {
      start: { ...draft.start, millisecond: 0 },
      end: { ...draft.end, millisecond: 999 },
    };
  }

  return {
    start: startOfDay(draft.start),
    end: endOfDay(draft.end),
  };
}
