/** Shared color swatch palette used by toolbar color pickers */
export const TIPTAP_COLOR_SWATCHES = [
  '#0f172a',
  '#334155',
  '#475569',
  '#2563eb',
  '#16a34a',
  '#ca8a04',
  '#dc2626',
  '#9333ea',
  '#ec4899',
  '#0f766e',
  '#fef08a',
  '#fde68a',
  '#fed7aa',
  '#fecaca',
  '#dbeafe',
  '#dcfce7',
];
