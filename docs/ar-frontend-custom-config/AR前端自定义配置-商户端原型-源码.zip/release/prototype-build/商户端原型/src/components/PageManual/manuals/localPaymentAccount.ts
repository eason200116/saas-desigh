// 本地代收代付账户（商户端 tenant · finance_local_payment_account_page）功能说明书。
// 锚定 src/views/finance/localPaymentAccount/index.vue 容器 + 4 个子 Tab（bankCard 银行卡信息 /
// upi UPI信息 / usdt USDT地址 / ewallet 电子钱包信息）各自的 index.vue/data.ts/form.ts/useXxxPage.ts/
// 编辑弹窗真实控件（R53 实证、不臆造）。容器只是 n-tabs 壳（读 route.meta.tabs），4 个子 Tab 各自独立的
// 搜索表单 + 列表 + 新增/编辑/删除，互不共用列/表单组件——仅共用 shared.ts 的充值等级标签渲染
// （renderLocalPaymentRechargeLevelTags）和弹窗防抖提交逻辑（useDebouncedModalSubmit），结构与已完成的
// 「充值类型管理」（rechargeType.ts，2 子Tab）「会员银行卡管理」（memberBankCard.ts，5 子Tab）同属一类
// "Tab壳+多个独立子页"页面。
//
// 与「会员银行卡管理」（member_bank_card）的关键区别：本页管理的是【商户自己的收款账号】（商户提供给会员
// 充值时使用的银行卡/UPI/USDT钱包/电子钱包），不是会员个人的钱包——4 个子 Tab 的行数据模型里均不含
// userId / 会员ID 字段，列表也没有可点击跳会员详情的列；"充值等级"列的含义是"哪些会员充值等级可见/可用
// 这个收款账号"，不是账号归属于某个会员。

import type { PageManual } from '../types';

const manual: PageManual = {
  route: 'finance_local_payment_account_page',
  title: '本地代收代付账户',
  overview:
    '商户端「财务管理 › 本地代收代付账户」页，容器是一个 4 标签页壳（银行卡信息 bank-card 默认 / UPI信息 upi / USDT地址 usdt / 电子钱包信息 ewallet），4 个标签页完全独立、互不共用列/表单组件：各自维护商户自己对外收款用的账号——银行卡信息 Tab 含银行名称/持卡人/卡号/支行/IFSC Code/二维码等字段，UPI信息 Tab 只有 UPI账号一个身份字段（最精简），USDT地址 Tab 含网络协议(TRC20/ERC20/BEP20/OMNI)/钱包地址/二维码，电子钱包信息 Tab 含钱包类型/持卡人/手机号（脱敏展示）。4 个 Tab 均支持按"单笔金额限制"和"每日限制统计（今日已收/日限制，含笔数+金额两维）"控制该收款账号的使用上限，并可勾选"可用充值等级"限定哪些会员等级能看到/使用该账号（不勾选=所有等级可见）。2026-07-21 核实代码后记录 4 处真实问题，2026-07-22 已全部修复：①4 个子 Tab 的"新增"保存 mock（`rechargeLocalBankAdd`/`rechargeLocalUpiAdd`/`rechargeLocalUsdtAdd`/`rechargeLocalEWalletAdd`）已改为构造完整记录并真正 push 进各自的底层数组（`BANK_CARDS`/`UPI_LIST`/`USDT_LIST`/`EWALLET_LIST`）——新增成功后列表 reload 能看到这条新记录，与"编辑"（`findIndex` 定位+赋值）和"删除"（`splice`）一样真实生效。②USDT地址 Tab `useUsdtPage.ts` 的 `buildListRequest` 已补上 `usdtType` 字段转发（原来只转发 tenantId/bankName/pageNo/orderBy/pageSize），选中「网络协议」点查询现在能正确按协议过滤列表；同时移除了该函数里对 `bankName` 的死代码转发（本 Tab 搜索区本就没有 bankName 这个搜索项）。③USDT地址 Tab 已补齐"单笔金额限制"/"日限制统计"概念，与另外 3 个 Tab 对齐：`UsdtRow` 新增 `minRechargeAmount`/`maxRechargeAmount`/`totalLimitCount`/`totalLimitAmount`/`currentTotalCount`/`currentTotalLimitAmount` 6 个字段（3 条既有示例数据已补上多样化取值）；表单（`LocalUsdtEditModal.vue`）在「钱包地址」和「可用充值等级」之间新增「单笔金额限制」（ProNumberRange）+ 固定日总笔数/日总限额两个输入框（布局照抄 UPI Tab）；列表 `renderAmountRange`/`renderDailyLimitStats` 从恒返回"--"的占位实现换成与银行卡信息 Tab 完全一致的真实读取渲染。④UPI信息、电子钱包信息两个 Tab 弹窗的"状态"字段已由 `n-radio-group`（启用/禁用单选）改为 `n-switch`；银行卡信息、USDT地址两个 Tab 弹窗原本完全没有暴露"状态"字段，已各自新增（布局上与「排序」并排一行），4 个 Tab 形态统一，命中 R47（启用/禁用状态在新增/编辑弹窗里一律用开关）。4 个 Tab 的新增/编辑提交统一采用"新记录默认 state=1（启用）入库，若表单选择禁用则额外补发一次 `rechargeLocalXxxUpdateState` 同步"的两段式提交（`syncStateIfNeeded`，与既有的编辑态状态变更同一套机制），新增接口本身不直接携带状态字段。',
  items: [
    // ============ 容器：Tab 切换 ============
    {
      anchor: 'tab_switch',
      name: '4 个子页 Tab 切换（银行卡信息 / UPI信息 / USDT地址 / 电子钱包信息）',
      group: '操作',
      interaction:
        '点顶部 Tab 切换，4 个 Tab 各自独立的搜索表单 + 列表 + 新增/编辑/删除，不共用列定义/表单组件，仅共用 shared.ts 里的充值等级标签渲染和弹窗防抖提交逻辑。',
      dataSource: '从当前路由 meta.tabs 读取配置（useRouteTabs，默认展示 key=bank-card 的「银行卡信息」）。',
      logic:
        '容器组件 src/views/finance/localPaymentAccount/index.vue 本身只是壳（`<component :is="activeComponent">` + KeepAlive），不含独立业务控件；实际控件都在 4 个子 Tab 自己的 index.vue 里。Tab 切走后各自的搜索/分页状态保留（KeepAlive）。',
      note: '4 个 Tab 组件名分别是 finance_local_payment_account_bank_card_tab / _upi_tab / _usdt_tab / _ewallet_tab，路由 name 统一是容器的 finance_local_payment_account_page（本说明书的联动锚点即挂在此路由下，4 个子 Tab 切换不改变路由 name）。',
    },

    // ============ 4 个 Tab 共用的「商户」 ============
    {
      anchor: 'merchant',
      name: '商户（4 个 Tab 均有，规则一致）',
      group: '搜索',
      interaction: '下拉单选（tenantSelect，架构级不可清空：`clearable: false`）。',
      dataSource: '全站商户列表。',
      logic:
        '按选中商户过滤当前 Tab 的记录列表；切换商户会触发 `onUpdateValue` 回调同步各 Tab 内部的 `searchTenantId` 状态，并联动重新拉取该商户对应的下拉选项（银行卡信息 Tab 的银行名称下拉、电子钱包信息 Tab 的钱包类型下拉均按商户懒加载缓存；UPI信息、USDT地址两个 Tab 无按商户变化的下拉，USDT地址 Tab 的协议下拉是全平台统一枚举、不区分商户）。',
      limit: '搜索表单项配了 `showRequireMark` 红星提示 + 组件本身 `clearable: false` 架构级不可清空（单选）。',
      edge: '4 个 Tab 均无「会员ID」搜索项（本页记录不归属具体会员），故此处的商户必选是"收款账号数据按商户维度隔离"的通用架构约束，非 R63 那种"商户+会员ID搭配"场景。',
    },

    // ============ Tab①银行卡信息：搜索区专属 ============
    {
      anchor: 'bc_bankName',
      name: '银行名称（银行卡信息 Tab，搜索区）',
      group: '搜索',
      interaction: '下拉单选，可搜索可清空。',
      dataSource: '按当前选中商户懒加载调用 `getBankSelectList({tenantId})`（按商户缓存，未命中缓存才发起请求；4 个预置商户 1050/1048/1021/1040 各有不同银行枚举，其余商户回退到 TTB/BBL/HDFC Bank/SBI 四家默认枚举）。',
      logic: '按选中银行名称精确过滤列表，mock 已真正接入（`filterAndPaginate` 里 `if (bankName) filtered = filtered.filter((r) => r.bankName === bankName)`）。',
      limit: '选填。',
    },
    {
      anchor: 'bc_holderName',
      name: '姓名（银行卡信息 Tab，搜索区，对应列「持卡人」）',
      group: '搜索',
      interaction: '文本输入，可清空。',
      dataSource: '用户输入。',
      logic: '按持卡人姓名模糊匹配（不区分大小写 includes）过滤，mock 已真正接入。',
      limit: '选填；`inputProps(\'name\')` 预设：maxlength 50，仅允许常规文本字符。',
    },
    {
      anchor: 'bc_accountNo',
      name: '卡号（银行卡信息 Tab，搜索区）',
      group: '搜索',
      interaction: '文本输入，可清空。',
      dataSource: '用户输入。',
      logic: '按卡号子串匹配（includes）过滤，mock 已真正接入。',
      limit: '选填；`inputProps(\'searchKw\')` 预设：maxlength 50，允许常规文本字符（未限制仅数字）。',
    },

    // ============ Tab②UPI信息：搜索区专属 ============
    {
      anchor: 'upi_accountNo',
      name: 'UPI账号（UPI信息 Tab，搜索区，本 Tab 除商户外唯一的搜索项）',
      group: '搜索',
      interaction: '文本输入，可清空。',
      dataSource: '用户输入。',
      logic: '按 UPI 账号子串匹配（includes）过滤，mock 已真正接入。',
      limit: '选填；`inputProps(\'searchKw\')` 预设：maxlength 50，允许常规文本字符。',
      note: 'UPI信息 Tab 是 4 个子 Tab 里搜索项最少的一个（仅"商户"+"UPI账号"两项），因为 UPI 本身没有"类型/协议"这类分类维度（与 USDT 的网络协议、电子钱包的钱包类型不同）。',
    },

    // ============ Tab③USDT地址：搜索区专属 ============
    {
      anchor: 'usdt_protocol',
      name: '网络协议（USDT地址 Tab，搜索区）',
      group: '搜索',
      interaction: '下拉单选，可清空。',
      dataSource: '调用 `getUsdtTypeSelectList` 返回固定 4 个协议：TRC20 / ERC20 / BEP20 / OMNI（不分商户，全平台统一枚举），下拉本身可正常打开并选中。',
      logic: '按选中协议过滤该 Tab 记录列表，`useUsdtPage.ts` 的 `buildListRequest` 转发 `params.usdtType`，mock 端 `filterAndPaginate` 按 `r.bankCode === usdtType` 过滤，2026-07-22 已修复生效。',
      edge:
        '2026-07-22 修复记录：此前 `buildListRequest` 组装列表请求参数时漏转发了 `usdtType`（只转发了 tenantId/bankName/pageNo/orderBy/pageSize），导致选中协议点查询后实际不按协议过滤；已补上转发，同时移除了同函数里对 `bankName` 的死代码转发（本 Tab 搜索区没有 bankName 这个搜索项）。',
    },

    // ============ Tab④电子钱包信息：搜索区专属 ============
    {
      anchor: 'ewallet_bankName',
      name: '钱包类型（电子钱包信息 Tab，搜索区）',
      group: '搜索',
      interaction: '下拉单选，可搜索可清空。',
      dataSource: '按当前选中商户懒加载调用 `getEWalletTypeSelectList({tenantId})`（按商户缓存；预置商户 1050/1048/1021 各有不同枚举，其余商户回退到 KBZPay/BKASH/Surecash 三个默认值）。',
      logic: '按选中钱包类型精确过滤列表，mock 已真正接入。',
      limit: '选填。',
    },
    {
      anchor: 'ewallet_holderName',
      name: '姓名（电子钱包信息 Tab，搜索区，对应列「持卡人」）',
      group: '搜索',
      interaction: '文本输入，可清空。',
      dataSource: '用户输入。',
      logic: '按持卡人姓名模糊匹配（不区分大小写 includes）过滤，mock 已真正接入。',
      limit: '选填；`inputProps(\'name\')` 预设：maxlength 50。',
    },
    {
      anchor: 'ewallet_accountNo',
      name: '手机号（电子钱包信息 Tab，搜索区，对应列「手机号」）',
      group: '搜索',
      interaction: '文本输入，可清空。',
      dataSource: '用户输入。',
      logic: '按手机号子串匹配（includes）过滤，mock 已真正接入。',
      limit: '选填；`inputProps(\'phone\')` 预设：maxlength 15，仅允许数字字符。',
      note: '搜索区填的是完整手机号（不脱敏，便于精确查找），但列表「手机号」列展示时会脱敏（见 col_accountNo）。',
    },

    // ============ 4 个 Tab 共用的「列」 ============
    {
      anchor: 'col_rechargeLevel',
      name: '充值等级列（「可用充值等级」列，4 个 Tab 均有，渲染逻辑完全共用）',
      group: '列',
      interaction: '纯展示彩色标签（NTag），不可点。',
      dataSource: '行数据 `rechargeLevel` 字符串（逗号分隔的等级值，或字面量 `"all"`）；4 个 Tab 共用同一个渲染函数 `renderLocalPaymentRechargeLevelTags`（定义于 `../shared.ts`），标签文案按 `common` 字典 `rechargeLevelList` 反查。',
      logic:
        '空值或 `"all"` 统一显示一个"所有"标签；否则按逗号拆分，每个 token 尝试匹配字典 value/label，未命中则原样兜底展示（并统一加 `lv` 前缀，如 `lv3`）。',
      note: '这一列的含义是"哪些会员充值等级可以看到/使用这个收款账号"，不是"这个账号属于哪个会员等级"。',
    },
    {
      anchor: 'col_qrCode',
      name: '二维码列（银行卡信息、USDT地址两个 Tab 独有，UPI信息、电子钱包信息没有此列）',
      group: '列',
      interaction: '40×40 缩略图（NImage），点击可预览大图（未设置 `previewDisabled`，走 NImage 默认预览行为）。',
      dataSource: '行数据 `qrCodeURL`（示例数据统一走 `api.qrserver.com` 生成的占位二维码图片）。',
      logic: '`qrCodeURL` 为空时显示"--"占位，不触发预览；两个 Tab 的渲染函数（各自 useXxxPage.ts 里的 `renderQrCode`）实现方式相同但各自独立定义（未做成共享函数）。',
      edge: 'UPI信息、电子钱包信息两个 Tab 的新增/编辑弹窗、列表都没有二维码相关字段/列，是 4 个 Tab 里仅银行卡信息和 USDT地址两类账号支持二维码收款方式，如实记录该差异（并非遗漏）。',
    },
    {
      anchor: 'col_amount_limits',
      name: '单笔金额限制 / 日限制统计（今日已收/日限制）两列（4 个 Tab 均有此两列标题，实际内容随 Tab 不同）',
      group: '列',
      interaction: '纯展示，不可点：「单笔金额限制」列为 `最小值~最大值` 文本；「日限制统计」列为上下两行——第一行"限制笔数：今日已收/日限制笔数"，第二行"限制金额：今日已收/日限制金额"。',
      dataSource: '行数据 `minRechargeAmount`/`maxRechargeAmount`（单笔区间）+ `currentTotalCount`/`totalLimitCount`（笔数）+ `currentTotalLimitAmount`/`totalLimitAmount`（金额）。',
      logic: '4 个 Tab 的渲染函数都真实读取行数据并格式化展示；两值都缺失时整体显示"--"。',
      edge:
        '2026-07-22 修复记录：USDT地址 Tab 此前是例外——`renderAmountRange`/`renderDailyLimitStats` 恒返回占位符"--"（不读取 row），且该 Tab 的新增/编辑弹窗没有金额区间/每日限额的填写入口、行数据类型 `UsdtRow` 也未定义这些字段（表单、数据模型、列表渲染三层整体缺失）。已补齐：`UsdtRow` 新增 6 个对应字段、表单新增 ProNumberRange+日总笔数/日总限额输入框、渲染函数换成与银行卡信息 Tab 一致的真实实现，4 个 Tab 现已对齐。',
    },
    {
      anchor: 'col_accountNo',
      name: '账号列（卡号 / UPI账号 / 钱包地址 / 手机号，4 个 Tab 各自的核心标识字段，行为略有不同）',
      group: '列',
      interaction: '纯文本展示；仅「银行卡信息」Tab 的卡号列额外带一个复制图标（`copyable: true`，点击复制到剪贴板）。',
      dataSource: '行数据 `accountNo`（4 个 Tab 语义不同：银行卡信息=卡号、UPI信息=UPI账号、USDT地址=钱包地址、电子钱包信息=手机号）。',
      logic: '银行卡信息/UPI信息/USDT地址 3 个 Tab 明文全量展示；电子钱包信息 Tab 经 `maskPhone` 脱敏展示（保留前3位+****+后4位）。',
      note: '「银行卡信息」Tab 的卡号列是 4 个 Tab 里唯一带复制按钮（`copyable`）的账号列，其余 3 个 Tab 均无此功能，如实记录该差异（非遗漏，纯粹是各 Tab 独立实现时的不同选择）。',
    },
    {
      anchor: 'col_state',
      name: '状态列（启用/禁用开关，4 个 Tab 均有，渲染逻辑完全共用模式）',
      group: '列',
      interaction: '开关（ConfirmSwitch），点击弹二次确认框确认后才真正切换，命中 R47。',
      dataSource: '行数据 `state`（1=启用/0=禁用）。',
      logic: '确认后调用对应 Tab 的 `rechargeLocalXxxUpdateState`，成功后更新行内 state 并整表 reload；4 个 Tab 的 mock 都会真实写回底层数组（`BANK_CARDS`/`UPI_LIST`/`USDT_LIST`/`EWALLET_LIST`），reload 后状态变化能正确看到——与"新增"操作的假持久化不同，状态切换是 4 个 Tab 里除"编辑""删除"外第三个真实生效的操作。',
      edge: '点取消则开关视觉复位，不发起请求。',
    },

    // ============ Tab①银行卡信息：操作 ============
    {
      anchor: 'bc_add',
      name: '新增银行卡（银行卡信息 Tab）',
      group: '操作',
      interaction:
        '点表格左上角"新增"打开弹窗（LocalBankCardEditModal，宽640px），填写商户/自定义昵称/银行名称/持卡人/卡号/支行/IFSC Code/排序/状态（开关，默认启用）/最小最大金额（ProNumberRange）/【固定】日总笔数/【固定】日总限额/可用充值等级（复选框组，不勾选=所有等级可见）/二维码（上传，104×104）/备注（textarea，maxlength 256）后点确认。',
      dataSource: '「银行名称」下拉走按商户懒加载的 `getBankSelectList`（与搜索区 bc_bankName 同源同缓存机制）；「充值等级」复选框选项走商户专属充值等级列表（`userStore.getTenantRechargeLevelList`），无商户专属配置时兜底显示通用等级字典。',
      logic: '商户/银行名称/持卡人/卡号为必填（`n-form` rules）；「最小/最大金额」有自定义校验（最小值不能大于最大值）；提交调用 `rechargeLocalBankAdd`（新记录默认 state=1 入库），若表单状态为禁用则额外补发 `rechargeLocalBankUpdateState` 同步（`syncStateIfNeeded`）；成功后关闭弹窗并刷新列表；提交前端有 300ms 防抖（`useDebouncedModalSubmit`，忙碌态下再次点击无效）。',
      limit: '商户/银行名称为下拉必选（change 触发）；持卡人/卡号为非空校验（blur 触发）；持卡人/支行走 `INPUT_PRESETS.name`（maxlength 50）；卡号走 `INPUT_PRESETS.searchKw`（maxlength 50）；IFSC Code 走 `INPUT_PRESETS.code`（maxlength 32，仅字母数字）；自定义昵称/排序/状态/最大最小金额/日总笔数/日总限额/充值等级/二维码/备注均为选填（状态默认"启用"）。',
      edge:
        '2026-07-22 修复记录：保存调用的 `rechargeLocalBankAdd` mock 此前只返回假成功、不写入 `BANK_CARDS`，已改为真正 push 完整记录，与本 Tab「编辑」（`rechargeLocalBankUpdate`，`findIndex`+赋值）一样真实生效；「状态」字段此前弹窗完全没有暴露，已新增开关控件（原来只有列表内 ConfirmSwitch 能改状态）。「二维码」上传字段在表单里显眼展示，但 `rules` 对象里并未包含 `qrCodeURL` 的必填校验，不上传也能提交成功——这一点保持原样、不属于本次修复范围。',
    },

    // ============ Tab②UPI信息：操作 ============
    {
      anchor: 'upi_add',
      name: '新增UPI（UPI信息 Tab）',
      group: '操作',
      interaction:
        '点表格左上角"新增"打开弹窗（LocalUpiEditModal，宽560px），填写商户/自定义昵称/UPI账号/最小最大金额（ProNumberRange）/【固定】日总笔数/【固定】日总限额/可用充值等级（复选框组）/排序/状态（单选：启用/禁用）/备注后点确认。',
      dataSource: '「充值等级」复选框选项同 bc_add，走商户专属充值等级列表兜底通用字典。',
      logic:
        '商户/UPI账号为必填；「最小/最大金额」有自定义校验；提交调用 `rechargeLocalUpiAdd`（新记录默认 state=1 入库）；若表单选择的"状态"为禁用（非默认的启用），成功后会额外补发一次 `rechargeLocalUpiUpdateState` 同步状态（`syncStateIfNeeded`，仅当期望状态为禁用时才补发）。',
      limit: 'UPI账号为非空校验（blur 触发）；自定义昵称/最大最小金额/日总笔数/日总限额/充值等级/排序/状态/备注均为选填（状态默认"启用"）。',
      edge:
        '2026-07-22 修复记录：「状态」此前用 `n-radio-group`（启用/禁用单选），与列表状态列的 ConfirmSwitch 开关不一致（R47），已改为 `n-switch`。保存调用的 `rechargeLocalUpiAdd` mock 此前只返回假成功、不写入 `UPI_LIST`，已改为真正 push 完整记录，与"编辑"操作一样真实生效。',
    },

    // ============ Tab③USDT地址：操作 ============
    {
      anchor: 'usdt_add',
      name: '新增USDT地址（USDT地址 Tab）',
      group: '操作',
      interaction:
        '点表格左上角"新增"打开弹窗（LocalUsdtEditModal，宽600px），填写商户/自定义昵称/网络协议/二维码（上传，104×104）/钱包地址/最小最大金额（ProNumberRange）/【固定】日总笔数/【固定】日总限额/可用充值等级（复选框组）/排序/状态（开关，默认启用）/备注后点确认。2026-07-22 起金额区间/每日限额/状态字段已与另外 3 个 Tab 对齐（此前没有）。',
      dataSource: '「网络协议」下拉实时按 `form.tenantId` 调用 `getUsdtTypeSelectList`（首次渲染先用父组件传入的选项兜底，之后按 tenantId 变化重新拉取；4 个协议不分商户，实际每次都返回同一份 TRC20/ERC20/BEP20/OMNI）。',
      logic: '商户/网络协议/钱包地址为必填；「最小/最大金额」有自定义校验（最小值不能大于最大值）；提交调用 `rechargeLocalUsdtAdd`（新记录默认 state=1 入库），若表单状态为禁用则额外补发 `rechargeLocalUsdtUpdateState` 同步（`syncStateIfNeeded`）；成功后关闭弹窗并刷新列表。',
      limit: '商户/网络协议为下拉必选（change 触发）；钱包地址为非空校验（blur 触发，走 `INPUT_PRESETS.searchKw`，maxlength 50）；自定义昵称走 `INPUT_PRESETS.name`（maxlength 50）；排序/状态/充值等级/最大最小金额/日总笔数/日总限额/二维码/备注均为选填。',
      edge:
        '2026-07-22 修复记录：保存调用的 `rechargeLocalUsdtAdd` mock 此前只返回假成功、不写入 `USDT_LIST`，已改为真正 push 完整记录，与"编辑"操作一样真实生效。二维码字段同 bc_add，未被 `rules` 强制必填——这一点保持原样、不属于本次修复范围。',
    },

    // ============ Tab④电子钱包信息：操作 ============
    {
      anchor: 'ewallet_add',
      name: '新增电子钱包（电子钱包信息 Tab）',
      group: '操作',
      interaction:
        '点表格左上角"新增"打开弹窗（LocalEwalletEditModal，宽640px），填写商户/自定义昵称/钱包类型/持卡人/手机号/最小最大金额（ProNumberRange）/【固定】日总笔数/【固定】日总限额/可用充值等级（复选框组）/状态（单选：启用/禁用）/排序/备注后点确认。本 Tab 弹窗没有二维码字段（与银行卡信息、USDT地址两个 Tab 不同）。',
      dataSource: '「钱包类型」下拉走按商户懒加载的 `getEWalletTypeSelectList`（与搜索区 ewallet_bankName 同源同缓存机制）。',
      logic:
        '商户/持卡人/钱包类型/手机号为必填；「最小/最大金额」有自定义校验；提交调用 `rechargeLocalEWalletAdd`（新记录默认 state=1 入库）；若表单"状态"为禁用，成功后额外补发 `rechargeLocalEWalletUpdateState` 同步（同 upi_add 的 `syncStateIfNeeded` 机制）。',
      limit: '持卡人走 `INPUT_PRESETS.name`（maxlength 50，必填 blur 触发）；手机号走 `INPUT_PRESETS.phone`（maxlength 15，仅数字，必填 blur 触发）；钱包类型为下拉必选（change 触发）；自定义昵称/最大最小金额/日总笔数/日总限额/充值等级/状态/排序/备注均为选填。',
      edge:
        '2026-07-22 修复记录：「状态」此前同样用 `n-radio-group`（启用/禁用单选），已与 upi_add 一起改为 `n-switch`（R47）。保存调用的 `rechargeLocalEWalletAdd` mock 此前只返回假成功、不写入 `EWALLET_LIST`，已改为真正 push 完整记录，与"编辑"操作一样真实生效。',
    },

    // ============ 编辑 / 删除（4 个 Tab 共用同一套模式） ============
    {
      anchor: 'edit_shared',
      name: '编辑（4 个 Tab 共用同一套交互模式）',
      group: '操作',
      interaction: '点行内「编辑」打开对应 Tab 的编辑弹窗，预填当前行数据；字段集合与「新增」完全一致，只是标题变为"修改本地XXX"、商户下拉锁定只读。',
      dataSource: '打开时调用对应 Tab 的 `rechargeLocalXxxGet({id, tenantId})` 取详情回填表单。',
      logic:
        '商户字段编辑态下锁定为禁用（`:disabled="isEditMode"`，不可改归属）；其余字段可改；校验规则与新增相同；提交调用对应 `rechargeLocalXxxUpdate`——4 个 Tab 的编辑保存均真实生效（mock 内 `findIndex` 定位后整条赋值回数组），reload 后修改结果可见，与"新增"操作的假持久化形成对照。',
    },
    {
      anchor: 'delete_shared',
      name: '删除（4 个 Tab 共用同一套交互模式）',
      group: '操作',
      interaction: '点行内「删除」，弹二次确认框（`dialog.warning`，内容"确定删除当前记录 ID {id} 吗？"）。',
      logic: '确认后调用对应 Tab 的 `rechargeLocalXxxDelete({id, tenantId})`，成功后提示"删除成功"并刷新列表；4 个 Tab 的 mock 均会真实从底层数组 `splice` 移除该行，reload 后条数同步减少，与"新增"的假持久化不同。',
    },
  ],

  // ============ 字段介绍 tab（按各自 Tab 列表列真实列序；仅列表列 + 定义）============
  fields: [
    // ---- 银行卡信息 Tab（19 列，同 bankCard/index.vue tableColumns 顺序）----
    { name: '「银行卡信息」商户', def: '该收款账号所属商户，标签形式展示。' },
    { name: '「银行卡信息」ID', def: '该收款账号记录的唯一编号。' },
    { name: '「银行卡信息」自定义昵称', def: '运营给该账号起的备注名，便于内部区分多个同类账号，为空显示"--"。' },
    { name: '「银行卡信息」银行名称', def: '该银行卡的开户银行（如 TTB / BBL / HDFC Bank），为空显示"--"。' },
    { name: '「银行卡信息」充值等级', def: '哪些会员充值等级可以看到/使用这个收款账号；不勾选=所有等级可见。' },
    { name: '「银行卡信息」持卡人', def: '该银行卡的持卡人姓名，明文全量展示，未脱敏。' },
    { name: '「银行卡信息」银行卡号', def: '银行卡号，明文全量展示，未脱敏，列头带复制图标（4 个 Tab 里唯一带复制功能的账号列）。' },
    { name: '「银行卡信息」支行', def: '开户支行名称，明文展示，为空显示"--"。' },
    { name: '「银行卡信息」IFSC Code', def: '印度银行系统的支行识别码，明文展示，为空显示"--"。' },
    { name: '「银行卡信息」二维码', def: '该账号的收款二维码缩略图，点击可预览大图，为空显示"--"。' },
    { name: '「银行卡信息」单笔金额限制', def: '该账号单笔充值允许的最小~最大金额区间，两值都缺失显示"--"。' },
    { name: '「银行卡信息」日限制统计(今日已收/日限制)', def: '两行：第一行为今日已收笔数/每日笔数上限，第二行为今日已收金额/每日金额上限。' },
    { name: '「银行卡信息」添加人', def: '创建该账号记录的操作人账号，为空显示"--"。' },
    { name: '「银行卡信息」创建时间', def: '该账号记录的新增时间，按所属商户时区显示。' },
    { name: '「银行卡信息」最后修改人', def: '最近一次编辑该账号记录的操作人账号，为空显示"--"。' },
    { name: '「银行卡信息」最后修改时间', def: '最近一次编辑该账号记录的时间，按所属商户时区显示。' },
    { name: '「银行卡信息」备注', def: '运营对该账号的补充说明文字，为空显示"--"。' },
    { name: '「银行卡信息」状态', def: '该账号是否对会员开放使用（启用/禁用）。' },
    { name: '「银行卡信息」排序', def: '控制该账号在同类账号中的展示先后顺序，数值越小越靠前。' },

    // ---- UPI信息 Tab（14 列，同 upi/index.vue tableColumns 顺序）----
    { name: '「UPI信息」商户', def: '该收款账号所属商户，标签形式展示。' },
    { name: '「UPI信息」ID', def: '该收款账号记录的唯一编号。' },
    { name: '「UPI信息」自定义昵称', def: '运营给该账号起的备注名，为空显示"--"。' },
    { name: '「UPI信息」UPI账号', def: 'UPI 收款标识（VPA），明文全量展示，未脱敏，为空显示"--"。' },
    { name: '「UPI信息」充值等级', def: '哪些会员充值等级可以看到/使用这个收款账号；不勾选=所有等级可见。' },
    { name: '「UPI信息」单笔金额限制', def: '该账号单笔充值允许的最小~最大金额区间，两值都缺失显示"--"。' },
    { name: '「UPI信息」日限制统计(今日已收/日限制)', def: '两行：第一行为今日已收笔数/每日笔数上限，第二行为今日已收金额/每日金额上限。' },
    { name: '「UPI信息」添加人', def: '创建该账号记录的操作人账号，为空显示"--"。' },
    { name: '「UPI信息」创建时间', def: '该账号记录的新增时间，按所属商户时区显示。' },
    { name: '「UPI信息」最后修改人', def: '最近一次编辑该账号记录的操作人账号，为空显示"--"。' },
    { name: '「UPI信息」最后修改时间', def: '最近一次编辑该账号记录的时间，按所属商户时区显示。' },
    { name: '「UPI信息」备注', def: '运营对该账号的补充说明文字，为空显示"--"。' },
    { name: '「UPI信息」状态', def: '该账号是否对会员开放使用（启用/禁用）。' },
    { name: '「UPI信息」排序', def: '控制该账号在同类账号中的展示先后顺序，数值越小越靠前。' },

    // ---- USDT地址 Tab（16 列，同 usdt/index.vue tableColumns 顺序）----
    { name: '「USDT地址」商户', def: '该收款账号所属商户，标签形式展示。' },
    { name: '「USDT地址」ID', def: '该收款账号记录的唯一编号。' },
    { name: '「USDT地址」自定义昵称', def: '运营给该账号起的备注名，为空显示"--"。' },
    { name: '「USDT地址」网络协议', def: '该地址所属链路类型：TRC20 / ERC20 / BEP20 / OMNI，为空显示"--"。' },
    { name: '「USDT地址」二维码', def: '该账号的收款二维码缩略图，点击可预览大图，为空显示"--"。' },
    { name: '「USDT地址」钱包地址', def: 'USDT 收款钱包地址，明文全量展示，未脱敏，为空显示"--"。' },
    { name: '「USDT地址」充值等级', def: '哪些会员充值等级可以看到/使用这个收款账号；不勾选=所有等级可见。' },
    { name: '「USDT地址」单笔金额限制', def: '该账号单笔充值允许的最小~最大金额区间，两值都缺失显示"--"（2026-07-22 起与另外 3 个 Tab 对齐，此前本 Tab 恒显示"--"）。' },
    { name: '「USDT地址」日限制统计(今日已收/日限制)', def: '两行：第一行为今日已收笔数/每日笔数上限，第二行为今日已收金额/每日金额上限（2026-07-22 起与另外 3 个 Tab 对齐，此前本 Tab 恒显示"--"）。' },
    { name: '「USDT地址」添加人', def: '创建该账号记录的操作人账号，为空显示"--"。' },
    { name: '「USDT地址」创建时间', def: '该账号记录的新增时间，按所属商户时区显示。' },
    { name: '「USDT地址」最后修改人', def: '最近一次编辑该账号记录的操作人账号，为空显示"--"。' },
    { name: '「USDT地址」最后修改时间', def: '最近一次编辑该账号记录的时间，按所属商户时区显示。' },
    { name: '「USDT地址」备注', def: '运营对该账号的补充说明文字，为空显示"--"。' },
    { name: '「USDT地址」状态', def: '该账号是否对会员开放使用（启用/禁用）。' },
    { name: '「USDT地址」排序', def: '控制该账号在同类账号中的展示先后顺序，数值越小越靠前。' },

    // ---- 电子钱包信息 Tab（16 列，同 ewallet/index.vue tableColumns 顺序）----
    { name: '「电子钱包信息」商户', def: '该收款账号所属商户，标签形式展示。' },
    { name: '「电子钱包信息」ID', def: '该收款账号记录的唯一编号。' },
    { name: '「电子钱包信息」自定义昵称', def: '运营给该账号起的备注名，为空显示"--"。' },
    { name: '「电子钱包信息」钱包类型', def: '电子钱包渠道（如 KBZPay / BKASH / Surecash / Rocket），为空显示"--"。' },
    { name: '「电子钱包信息」持卡人', def: '钱包持有人姓名，明文全量展示，未脱敏，为空显示"--"。' },
    { name: '「电子钱包信息」充值等级', def: '哪些会员充值等级可以看到/使用这个收款账号；不勾选=所有等级可见。' },
    { name: '「电子钱包信息」手机号', def: '钱包绑定手机号，脱敏展示：保留前3位+****+后4位（maskPhone），为空显示"--"。' },
    { name: '「电子钱包信息」单笔金额限制', def: '该账号单笔充值允许的最小~最大金额区间，两值都缺失显示"--"。' },
    { name: '「电子钱包信息」日限制统计(今日已收/日限制)', def: '两行：第一行为今日已收笔数/每日笔数上限，第二行为今日已收金额/每日金额上限。' },
    { name: '「电子钱包信息」添加人', def: '创建该账号记录的操作人账号，为空显示"--"。' },
    { name: '「电子钱包信息」创建时间', def: '该账号记录的新增时间，按所属商户时区显示。' },
    { name: '「电子钱包信息」最后修改人', def: '最近一次编辑该账号记录的操作人账号，为空显示"--"。' },
    { name: '「电子钱包信息」最后修改时间', def: '最近一次编辑该账号记录的时间，按所属商户时区显示。' },
    { name: '「电子钱包信息」备注', def: '运营对该账号的补充说明文字，为空显示"--"。' },
    { name: '「电子钱包信息」状态', def: '该账号是否对会员开放使用（启用/禁用）。' },
    { name: '「电子钱包信息」排序', def: '控制该账号在同类账号中的展示先后顺序，数值越小越靠前。' },
  ],
};

export default manual;
