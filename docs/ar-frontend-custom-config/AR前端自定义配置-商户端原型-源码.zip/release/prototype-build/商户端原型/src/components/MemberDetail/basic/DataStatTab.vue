<template>
  <!--
    数据统计 Tab（仅样板 1100002·试点门控）·布局（2026-07-13 调整）：
      · 顶部整行＝今日/累计数据（6 指标平铺 12 格，横铺占满宽度）
      · 下方两列：左＝充提明细（已去「充提明细」大标题、顶部即「充值信息」子块）、右＝奖励网格（活动/佣金/VIP/洗码）
      两列 align-items:flex-start → 「充值信息(左顶)」与「活动奖励信息(右顶)」顶边水平对齐（用户要求）。
    内容零改；复用 MemberDetailContent ::v-deep 的 .detail-section / .detail-grid / .detail-cell 样式。
  -->
  <div class="dsn-wrap">
    <!-- 时间区间：由会员详情顶部工具栏下放至此（本 Tab 仅样板 1100002 有）。
         结构/样式对齐「投注信息」的搜索区——那边是 ProCrudTable→ProSearchForm→ProFormItem(n-form-item) 渲染，
         故此处同样用 n-form-item（label-width 80 / 左置 / 无反馈行），并去掉原先手搓的灰底盒子（投注信息是白底无外壳）。
         无「查询」按钮：选完区间即生效（2026-07-14 用户选 B）——@change → apply() → queryVersion++ → 按新时间重载本 Tab。 -->
    <div v-if="timeQuery" class="dsn-timequery">
      <n-form
        inline
        label-placement="left"
        :label-width="80"
        :show-feedback="false"
        size="small"
      >
        <n-form-item :label="t('member.detail.betting.timeRange')">
          <div class="dsn-timequery__picker">
            <ProDateRangeInput
              v-model:value="timeRangeModel"
              :timezone="timeQuery.timezone.value"
              :placeholder="t('member.detail.betting.selectTimeRange')"
              display-format="yyyy-MM-dd"
              :show-time="false"
              :max-days="90"
              :allow-future="false"
              :shortcuts="false"
              :clearable="false"
              size="small"
              @change="timeQuery.apply()"
            />
          </div>
        </n-form-item>
      </n-form>
      <!-- 右上角「搜索 / 重置」：对齐投注信息搜索区（ProSearchBar 同款——搜索=primary+SearchOutlined，
           重置=默认+ReloadOutlined；文案复用 components.proSearchForm.search / common.reset，两命名空间启动即预热）。 -->
      <div class="dsn-timequery__actions">
        <n-button type="primary" size="small" @click="timeQuery.apply()">
          <template #icon>
            <n-icon><SearchOutlined /></n-icon>
          </template>
          {{ t('components.proSearchForm.search') }}
        </n-button>
        <n-button size="small" @click="handleResetTime">
          <template #icon>
            <n-icon><ReloadOutlined /></n-icon>
          </template>
          {{ t('common.reset') }}
        </n-button>
      </div>
    </div>

    <!-- 4 大类竖版 demo：仅样板会员 1100002（2026-07-16 用户需求·按会员门控）。
         字段全复用、按 充值|提现|投注|活动 四列重分组；其他会员走下方原版布局、零变化。 -->
    <DataStatGrouped v-if="isGroupedDemo" />

    <!-- 顶部整行：今日/累计数据（平铺 12 格） -->
    <DataStatCumulativeList
      v-if="!isGroupedDemo && topSection"
      :cumulative="topSection.cumulative"
      :title="topSection.title"
    />

    <!-- 下方两列：左＝充提明细 / 右＝奖励网格，顶边对齐 -->
    <div v-if="!isGroupedDemo" class="dsn-onepage">
      <!-- 左列：充提明细（充值信息 + 提现信息） -->
      <div class="dsn-col">
        <DataStatDepositWithdraw
          v-for="section in leftSections"
          :key="section.key"
          :dw="section.dw"
        />
      </div>

      <!-- 右列：奖励类 label/value 网格版块（活动/佣金/VIP/洗码） -->
      <div class="dsn-col">
        <div v-for="section in rightSections" :key="section.key" class="detail-section">
          <div class="detail-section__header">
            <h4 class="detail-section__title">{{ section.title }}</h4>
          </div>
          <div
            v-if="section.items && section.items.length"
            class="detail-grid"
            :style="{ gridTemplateColumns: `repeat(${section.columns}, minmax(0, 1fr))` }"
          >
            <template v-for="(item, idx) in section.items" :key="item.label || `dc-${idx}`">
              <div
                v-if="item.subHeader"
                class="detail-grid__subheader"
                :style="{ gridColumn: '1 / -1' }"
                >{{ item.subHeader }}</div
              >
              <div v-else-if="item.spacer" class="detail-cell detail-cell--spacer" />
              <div v-else class="detail-cell">
                <span class="detail-cell__label"
                  >{{ item.label }}<span v-if="item.changed" class="ar-changemark">改</span></span
                >
                <span
                  class="detail-cell__value"
                  :class="[
                    item.highlight ? `highlight--${item.highlight}` : '',
                    item.highlightBold ? 'highlight--bold' : '',
                  ]"
                >
                  {{ item.value }}
                  <span
                    v-if="item.timeZoneLabel"
                    style="
                      font-size: 12px;
                      font-weight: 400;
                      color: #999;
                      margin-left: 4px;
                      flex-shrink: 0;
                    "
                    >({{ item.timeZoneLabel }})</span
                  >
                </span>
              </div>
            </template>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
  import { computed, inject, watch } from 'vue';
  import { useI18n } from 'vue-i18n';
  import { startOfDay, endOfDay, subDays } from 'date-fns';
  import { SearchOutlined, ReloadOutlined } from '@vicons/antd';
  import { ProDateRangeInput } from '@/components';
  import { useUser } from '@/hooks';
  import { useMemberContext, MEMBER_DETAIL_TIME_QUERY } from '../useMemberContext';
  import DataStatCumulativeList from './DataStatCumulativeList.vue';
  import DataStatDepositWithdraw from './DataStatDepositWithdraw.vue';
  import DataStatGrouped from './DataStatGrouped.vue';

  const { t } = useI18n();
  const { detailData, lastWithdrawTime, memberId } = useMemberContext();

  /** 【已铺开·2026-07-16 用户确认】卡片化重排原为样板 1100002 试点（同日附图定稿+五轮微调验收），
   *  现对全部会员生效（含弹窗加宽 useMemberDetailModal.isOnePagePilot 同步铺开）。
   *  收回方式：改回 Number(memberId.value) === 1100002。 */
  const isGroupedDemo = computed(() => true);
  const { parseTimeStr } = useUser();

  // 「时间查询」由会员详情顶部工具栏下放到本 Tab（2026-07-14 用户要求）：
  // 状态仍在 MemberDetailShell（searchForm.timeRange），此处只做读写 + 触发查询，
  // 故其它 Tab（投注/日志/资金账变）拿它当兜底时间的行为不变。
  const timeQuery = inject(MEMBER_DETAIL_TIME_QUERY, undefined);
  const timeRangeModel = computed<[number, number] | null>({
    get: () => timeQuery?.timeRange.value ?? null,
    set: (v) => {
      if (timeQuery) timeQuery.timeRange.value = v;
    },
  });

  /** 默认时间区间——对齐「投注信息」的兜底链：上次提现时间 → 否则近 30 天；止＝今天 23:59:59。
   *  起点一律对齐到当天 00:00:00：控件已改按天（无时分秒·2026-07-16），若保留「上次提现时间」自带的时分秒，
   *  控件只显示日期、实际却从当天中途起算，显示与筛选对不上。 */
  function defaultTimeRange(): [number, number] {
    const ts = lastWithdrawTime.value ? parseTimeStr(lastWithdrawTime.value) : null;
    return [
      startOfDay(ts ?? subDays(new Date(), 30)).getTime(),
      endOfDay(new Date()).getTime(),
    ];
  }

  // 初始兜底：不给默认值控件就是空的、只显占位符（顶部日期本就 null 起步，样板会员若无 lastWithdrawTime 会永远空着），
  // 与投注信息「进来就带一段时间」的观感不一致。已有值（用户选过 / Shell 按上次提现时间填过）则不覆盖。
  watch(
    lastWithdrawTime,
    () => {
      if (!timeQuery || timeQuery.timeRange.value) return;
      timeQuery.timeRange.value = defaultTimeRange();
    },
    { immediate: true },
  );

  /** 「重置」：时间区间回默认值并立即重查（对齐投注信息搜索区的重置语义） */
  function handleResetTime() {
    if (!timeQuery) return;
    timeQuery.timeRange.value = defaultTimeRange();
    timeQuery.apply();
  }

  const sections = computed<any[]>(() => detailData.value.dataStatSections || []);
  // 今日/累计数据 → 顶部整行；充提明细 → 左列；其余奖励网格 → 右列。
  // 左右两列 flex-start 顶边对齐，使「充值信息(左)」与「活动奖励信息(右)」顶边水平对齐。
  const topSection = computed(() => sections.value.find((s: any) => s.type === 'cumulativeList'));
  const leftSections = computed(() =>
    sections.value.filter((s: any) => s.type === 'depositWithdraw'),
  );
  const rightSections = computed(() => {
    const raw = sections.value.filter(
      (s: any) => s.type !== 'cumulativeList' && s.type !== 'depositWithdraw',
    );
    // 活动/佣金/VIP/洗码 4 个奖励版块合并成一个「奖励与洗码」；不拆独立版块，但版块内按类型小标题分组（2026-07-13 用户要求·拆分类型不以版块形式）
    const rewardKeys = ['dcActivity', 'dcCommission', 'dcVip', 'dcWash'];
    const rewardSecs = rewardKeys
      .map((k) => raw.find((s: any) => s.key === k))
      .filter(Boolean) as any[];
    if (!rewardSecs.length) return raw;
    // 类型分组：活动、佣金 各一组；VIP奖励 + 洗码返水 合并为一组（2026-07-13 用户要求·合并VIP与洗码）
    const gActivity = raw.find((s: any) => s.key === 'dcActivity');
    const gCommission = raw.find((s: any) => s.key === 'dcCommission');
    const gVip = raw.find((s: any) => s.key === 'dcVip');
    const gWash = raw.find((s: any) => s.key === 'dcWash');
    const groups = [
      gActivity && { title: gActivity.title, items: gActivity.items || [] },
      gCommission && { title: gCommission.title, items: gCommission.items || [] },
      (gVip || gWash) && {
        // VIP奖励 + 洗码返水 合并为一个小标题分组
        title: [gVip?.title, gWash?.title].filter(Boolean).join(' / '),
        items: [...(gVip?.items || []), ...(gWash?.items || [])],
      },
    ].filter(Boolean) as any[];
    const merged = {
      key: 'dcRewardWash',
      title: t('member.detail.dataStat.rewardAndWash'),
      columns: 4, // 一行 4 个（2026-07-13 用户要求·由一行3个改4个）
      // 每组前插一个类型小标题做版块内分组（活动/佣金/「VIP奖励 / 洗码返水」）
      items: groups.flatMap((g: any) => [{ subHeader: g.title }, ...g.items]),
    };
    // 用合并版替换第一个奖励版块的位置、其余移除；非奖励版块（若有）保持原位
    const keySet = new Set(rewardKeys);
    let inserted = false;
    return raw.flatMap((s: any) => {
      if (!keySet.has(s.key)) return [s];
      if (inserted) return [];
      inserted = true;
      return [merged];
    });
  });
</script>

<style lang="less" scoped>
  /* 顶部整行(今日/累计) + 下方两列 flex；两列版块整块落列、绝不跨列拆分 */
  .dsn-wrap {
    display: flex;
    flex-direction: column;
    gap: 12px;
  }
  /* 时间区间（由顶部工具栏下放·样板1100002）：对齐「投注信息」搜索区——白底、无外壳盒子，
     标签交给 n-form-item 渲染（label-width 80 / 左置），故此处不再自定义标签样式。
     左＝时间区间，右上角＝搜索/重置（space-between 顶开，同投注信息）。 */
  .dsn-timequery {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 12px;
  }
  .dsn-timequery :deep(.n-form-item) {
    margin-bottom: 0;
  }
  .dsn-timequery__actions {
    display: flex;
    align-items: center;
    gap: 8px;
    flex-shrink: 0;
  }
  /* 改按天(yyyy-MM-dd·无时分秒)后文案变短，收回 280px——与顶部工具栏原日期控件（MemberDetailShell）同宽（R49） */
  .dsn-timequery__picker {
    width: 280px;
    flex-shrink: 0;
  }
  .dsn-onepage {
    display: flex;
    gap: 12px;
    align-items: flex-start;
  }
  .dsn-col {
    flex: 1;
    min-width: 0;
    display: flex;
    flex-direction: column;
    gap: 12px;
  }
  /* 格子排版（2026-07-16 用户要求）：充提数据 / 奖励与洗码 由「上下结构」改回横排（标题：数值 一行），
     即回落共享 .detail-cell 的 flex-direction:row（冒号也随基础样式回来）。
     原先此处有一条 .dsn-wrap :deep(.detail-cell) { flex-direction: column !important } 把本 Tab 全部格子
     强制成上下结构（2026-07-13），现已移除。仍需上下结构的两处改为各自挂共享 .detail-cell--stack 修饰：
       · 今日/累计合并格 → DataStatCumulativeList.vue
       · 首充/次充/三充（标题/金额/日期三行）→ DataStatDepositWithdraw.vue（按 dateNote 条件挂） */
</style>
