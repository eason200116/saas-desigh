import { ref } from 'vue';
import { api } from './data';
/**
 * 卡片数据管理 Composable
 */
export function useCardData() {
  const cards = ref<any[]>([]);
  const loadingCardIds = ref<Set<string>>(new Set());
  const loading = ref(false);
  const error = ref<string | null>(null);
  const requestId = ref(0);

  /**
   * 获取卡片列表含数据
   */
  const fetchCardsWithData = async (query: any): Promise<void> => {
    const currentRequestId = ++requestId.value;
    loading.value = true;
    error.value = null;

    try {
      const response = await api.event.listWithData(query);
      const data: any[] = Array.isArray(response) ? response : (response as any)?.data || [];
      if (currentRequestId !== requestId.value) return;

      // 按 sort 排序
      data.sort((a, b) => (a.sort || 0) - (b.sort || 0));
      cards.value = data;
    } catch (e: any) {
      if (currentRequestId !== requestId.value) return;
      error.value = e.message || '加载卡片失败';
      console.error('Failed to fetch cards with data:', e);
    } finally {
      if (currentRequestId === requestId.value) {
        loading.value = false;
      }
    }
  };

  /**
   * 清空卡片数据
   */
  const clearData = (): void => {
    requestId.value += 1;
    cards.value = [];
    error.value = null;
    loading.value = false;
  };

  return {
    cards,
    loadingCardIds,
    loading,
    error,
    fetchCardsWithData,
    clearData,
  };
}
