export interface TranslateLanguage {
  code: string;
  name: string;
}

export interface TranslationResultItem {
  languageCode?: string;
  languageName?: string;
  content?: string;
}

export const DEFAULT_TRANSLATE_LANGUAGES: TranslateLanguage[] = [
  { code: 'zh', name: '中文' },
  { code: 'en', name: 'English' },
];

const LANGUAGE_NAME_TO_CODE: Record<string, string> = {
  中文: 'zh',
  English: 'en',
  日本語: 'ja',
  한국어: 'ko',
  Français: 'fr',
  Deutsch: 'de',
  Español: 'es',
  Italiano: 'it',
  Polski: 'pl',
  Українська: 'uk',
  Português: 'pt',
  Русский: 'ru',
  العربية: 'ar',
  ไทย: 'th',
  'Tiếng Việt': 'vi',
  'Bahasa Indonesia': 'id',
  'Bahasa Melayu': 'ms',
  Nederlands: 'nl',
  Türkçe: 'tr',
  हिन्दी: 'hi',
};

function normalizeCode(code?: string): string {
  return (code || '').trim().toLowerCase();
}

export function resolveLanguages(
  customList?: TranslateLanguage[],
  storeList?: TranslateLanguage[],
): TranslateLanguage[] {
  const raw = customList?.length
    ? customList
    : storeList?.length
      ? storeList
      : DEFAULT_TRANSLATE_LANGUAGES;
  const deduped: TranslateLanguage[] = [];
  const seen = new Set<string>();

  for (const item of raw) {
    const code = normalizeCode(item?.code);
    const name = item?.name?.trim();
    if (!code || !name || seen.has(code)) continue;
    seen.add(code);
    deduped.push({ code, name });
  }

  return deduped.length ? deduped : DEFAULT_TRANSLATE_LANGUAGES;
}

export function resolveSourceLanguage(languages: TranslateLanguage[], preferred?: string): string {
  const preferredCode = normalizeCode(preferred);
  if (preferredCode && languages.some((lang) => lang.code === preferredCode)) {
    return preferredCode;
  }
  if (languages.some((lang) => lang.code === 'zh')) {
    return 'zh';
  }
  return languages[0]?.code || 'zh';
}

export function sortLanguages(
  languages: TranslateLanguage[],
  sourceLanguage: string,
): TranslateLanguage[] {
  const sourceCode = normalizeCode(sourceLanguage);
  const source = languages.find((lang) => lang.code === sourceCode);
  const english = languages.find((lang) => lang.code === 'en' && lang.code !== sourceCode);
  const others = languages.filter((lang) => lang.code !== sourceCode && lang.code !== 'en');

  const sorted: TranslateLanguage[] = [];
  if (source) sorted.push(source);
  if (english) sorted.push(english);
  sorted.push(...others);
  return sorted;
}

export function createLanguageCodeLookup(languages: TranslateLanguage[]): Map<string, string> {
  const lookup = new Map<string, string>();
  languages.forEach((lang) => {
    const code = normalizeCode(lang.code);
    if (!code || lookup.has(code)) return;
    lookup.set(code, lang.code);
  });
  return lookup;
}

export function mapTranslationResults(
  items: TranslationResultItem[] | undefined,
  codeLookup: Map<string, string>,
): Record<string, string> {
  const mapped: Record<string, string> = {};
  if (!Array.isArray(items) || !items.length) return mapped;

  for (const item of items) {
    const content = item?.content;
    if (typeof content !== 'string') continue;

    const candidates: string[] = [];
    if (item.languageCode) {
      candidates.push(item.languageCode);
    }
    if (item.languageName) {
      const rawName = item.languageName.trim();
      if (rawName) {
        candidates.push(LANGUAGE_NAME_TO_CODE[rawName] || rawName);
      }
    }

    let resolvedCode = '';
    for (const candidate of candidates) {
      const normalized = normalizeCode(candidate);
      if (!normalized || !codeLookup.has(normalized)) continue;
      resolvedCode = codeLookup.get(normalized) || '';
      break;
    }

    if (!resolvedCode) continue;
    mapped[resolvedCode] = content;
  }

  return mapped;
}
