import { getBrandPalette } from './theme';

export const BRAND_HEIGHT = 403;
export const BRAND_WIDTH = 394;
export const BRAND_VIEW_BOX = `0 0 ${BRAND_WIDTH} ${BRAND_HEIGHT}`;

const BRAND_RADIUS = 82;
const BRAND_GLYPH_A_PATH =
  'M128 24L40 224H74L92 184H164L182 224H216L128 24ZM107 148L128 98L149 148H107Z';
const BRAND_GLYPH_R_PATH =
  'M128 72H176C200 72 216 87 216 108C216 126 204 138 184 143L220 224H183L152 153H128V128H172C181 128 188 121 188 111C188 101 181 96 172 96H128V72Z';
const BRAND_GLYPH_TRANSFORM = 'translate(15 28) scale(1.4)';

export interface CreateBrandSvgOptions {
  decorative?: boolean;
  idPrefix?: string;
  isDark?: boolean;
  label?: string;
  themeColor?: string;
}

export function createBrandSvgMarkup(options: CreateBrandSvgOptions = {}) {
  const {
    decorative = true,
    idPrefix = 'ar-brand',
    isDark = false,
    label = 'AR',
    themeColor,
  } = options;
  const palette = getBrandPalette(themeColor, isDark);
  const ids = {
    background: `${idPrefix}-bg`,
    glow: `${idPrefix}-glow`,
    glyph: `${idPrefix}-glyph`,
    shadow: `${idPrefix}-shadow`,
    surface: `${idPrefix}-surface`,
    dot: `${idPrefix}-dot`,
  };
  const shadowOpacity = isDark ? 0.44 : 0.32;
  const escapedLabel = escapeXml(label);

  return `
<svg
  xmlns="http://www.w3.org/2000/svg"
  viewBox="${BRAND_VIEW_BOX}"
  fill="none"
  ${decorative ? 'aria-hidden="true"' : `role="img" aria-label="${escapedLabel}"`}
>
  ${decorative ? '' : `<title>${escapedLabel}</title>`}
  <defs>
    <linearGradient id="${ids.background}" x1="34" y1="364" x2="356" y2="39" gradientUnits="userSpaceOnUse">
      <stop offset="0" stop-color="${palette.backgroundStart}" />
      <stop offset="0.58" stop-color="${palette.backgroundMid}" />
      <stop offset="1" stop-color="${palette.backgroundEnd}" />
    </linearGradient>
    <radialGradient id="${ids.glow}" cx="0" cy="0" r="1" gradientUnits="userSpaceOnUse" gradientTransform="translate(328 31) rotate(121) scale(301 274)">
      <stop offset="0" stop-color="${palette.backgroundGlowStart}" />
      <stop offset="1" stop-color="${palette.backgroundGlowEnd}" />
    </radialGradient>
    <linearGradient id="${ids.surface}" x1="97" y1="41" x2="297" y2="185" gradientUnits="userSpaceOnUse">
      <stop offset="0" stop-color="${palette.surfaceStart}" />
      <stop offset="1" stop-color="${palette.surfaceEnd}" />
    </linearGradient>
    <linearGradient id="${ids.glyph}" x1="14%" y1="0" x2="84%" y2="100%">
      <stop offset="0" stop-color="${palette.glyphStart}" />
      <stop offset="1" stop-color="${palette.glyphEnd}" />
    </linearGradient>
    <linearGradient id="${ids.dot}" x1="18%" y1="6%" x2="82%" y2="92%">
      <stop offset="0" stop-color="${palette.glyphStart}" />
      <stop offset="0.24" stop-color="${palette.dotStart}" />
      <stop offset="1" stop-color="${palette.dotEnd}" />
    </linearGradient>
    <filter id="${ids.shadow}" x="-20%" y="-18%" width="150%" height="180%" color-interpolation-filters="sRGB">
      <feDropShadow dx="0" dy="8" stdDeviation="7" flood-color="${palette.shadowColor}" flood-opacity="${shadowOpacity}" />
    </filter>
  </defs>
  <rect width="${BRAND_WIDTH}" height="${BRAND_HEIGHT}" rx="${BRAND_RADIUS}" fill="url(#${ids.background})" />
  <rect width="${BRAND_WIDTH}" height="${BRAND_HEIGHT}" rx="${BRAND_RADIUS}" fill="url(#${ids.glow})" />
  <rect width="${BRAND_WIDTH}" height="${BRAND_HEIGHT}" rx="${BRAND_RADIUS}" fill="url(#${ids.surface})" />
  <rect
    x="1.5"
    y="1.5"
    width="${BRAND_WIDTH - 3}"
    height="${BRAND_HEIGHT - 3}"
    rx="${BRAND_RADIUS - 1.5}"
    stroke="${palette.outlineColor}"
    stroke-opacity="${isDark ? 0.2 : 0.28}"
    stroke-width="1.5"
  />
  <g filter="url(#${ids.shadow})" transform="${BRAND_GLYPH_TRANSFORM}">
    <path d="${BRAND_GLYPH_A_PATH}" fill="url(#${ids.glyph})" />
    <path d="${BRAND_GLYPH_R_PATH}" fill="url(#${ids.glyph})" />
  </g>
</svg>`.trim();
}

function escapeXml(value: string) {
  return value.replace(/[<>&"]/g, (character) => {
    switch (character) {
      case '<':
        return '&lt;';
      case '>':
        return '&gt;';
      case '&':
        return '&amp;';
      default:
        return '&quot;';
    }
  });
}
