<template>
  <div class="basic-upload">
    <!-- 图片列表 -->
    <div class="basic-upload__list">
      <div
        v-for="(item, index) in imageList"
        :key="item"
        :class="['basic-upload__item', { 'basic-upload__item--compact': compact }]"
        :style="itemStyle"
      >
        <div class="basic-upload__item-content">
          <!-- 图片预览 -->
          <div class="basic-upload__image">
            <img :src="getImageUrl(item)" alt="uploaded" />
          </div>

          <!-- 操作按钮 -->
          <div v-if="!disabled" class="basic-upload__actions">
            <n-icon
              v-if="width > 80"
              :size="18"
              class="basic-upload__action"
              @click="handlePreview(item)"
            >
              <EyeOutlined />
            </n-icon>
            <n-icon
              v-if="!readonly"
              :size="18"
              class="basic-upload__action"
              @click="handleRemove(index)"
            >
              <DeleteOutlined />
            </n-icon>
          </div>
        </div>
      </div>

      <!-- 上传按钮 -->
      <div v-if="canUpload">
        <n-upload
          v-bind="uploadProps"
          :custom-request="handleUpload"
          :file-list-style="{ display: 'none' }"
          @before-upload="handleBeforeUpload"
        >
          <n-spin :show="uploading" size="small">
            <slot>
              <div
                class="basic-upload__trigger"
                :class="{ 'basic-upload__trigger--uploading': uploading }"
                :style="itemStyle"
              >
                <div class="basic-upload__trigger-content">
                  <n-icon :size="18">
                    <PlusOutlined />
                  </n-icon>
                  <span v-if="width > 80" class="basic-upload__trigger-text">
                    {{ t('common.upload_image') }}
                  </span>
                </div>
                <span v-if="uploading && width > 80" class="basic-upload__loading-text">
                  {{ t('common.loading') }}
                </span>
              </div>
            </slot>
          </n-spin>
        </n-upload>
      </div>
    </div>

    <!-- 帮助文本 -->
    <n-alert v-if="helpText" :title="t('common.tip')" type="info" class="mt-2">
      {{ helpText }}
    </n-alert>
  </div>
</template>

<script setup lang="ts">
  import { h, ref, computed, watch, type CSSProperties } from 'vue';
  import {
    useMessage,
    useDialog,
    useModal,
    type UploadCustomRequestOptions,
    type UploadFileInfo,
  } from 'naive-ui';
  import { EyeOutlined, DeleteOutlined, PlusOutlined } from '@vicons/antd';
  import { useI18n } from 'vue-i18n';
  import { encodeImageWithJsquash } from '@/hooks';
  import { ImageCropper } from '@/components';
  import { componentSetting } from '@/hooks/setting';
  import { getFullImageUrl } from '@/utils';
  import type { ImageDimensions, BasicUploadInstance } from './types';
  import { DEFAULT_ACCEPT, DEFAULT_MAX_SIZE, DEFAULT_SIZE } from './types';

  defineOptions({
    name: 'BasicUpload',
  });

  // ===================== Props & Emits =====================
  const props = withDefaults(
    defineProps<{
      /** 接受的文件类型 */
      accept?: string;
      /** 帮助文本 */
      helpText?: string;
      /** 最大文件大小 (KB) */
      maxSize?: number;
      /** 最大上传数量 */
      maxNumber?: number;
      /** 图片列表值 */
      value?: string[];
      /** 上传框宽度 */
      width?: number;
      /** 上传框高度 */
      height?: number;
      /** 预览框宽度 */
      previewWidth?: number;
      /** 是否验证图片尺寸 */
      verifySize?: boolean;
      /** OSS 文件类型 */
      fileType?: any;
      /** 是否返回完整路径 */
      fullPath?: boolean;
      /** 是否只读 */
      readonly?: boolean;
      /** 是否禁用 */
      disabled?: boolean;
      /** 预览/回显时使用的商户 ID */
      tenantId?: string | number | null;
      /** 目录类型: 1=common, 2=apk, 3=skin, 4=icon, 5=appPackage, 6=banner */
      customPath?: number;
      /** 上传前额外验证 */
      beforeUploadExtra?: (file: File, dimensions: ImageDimensions) => boolean | Promise<boolean>;
      /** 紧凑模式 - 去掉内边距 */
      compact?: boolean;
      /** 是否启用裁剪 */
      enableCrop?: boolean;
      /** 裁剪比例 */
      cropAspectRatio?: number;
      /** 裁剪输出宽度 */
      cropOutputWidth?: number;
      /** 裁剪输出高度 */
      cropOutputHeight?: number;
      /** 裁剪弹窗标题 */
      cropTitle?: string;
    }>(),
    {
      accept: DEFAULT_ACCEPT,
      helpText: '',
      maxSize: DEFAULT_MAX_SIZE,
      maxNumber: Infinity,
      value: () => [],
      width: DEFAULT_SIZE,
      height: DEFAULT_SIZE,
      previewWidth: 0,
      verifySize: false,
      fileType: 'other' as any, // 对齐 any 的字符串联合类型
      fullPath: false,
      readonly: false,
      disabled: false,
      tenantId: null,
      customPath: 1,
      compact: false,
      enableCrop: false,
      cropAspectRatio: 0,
      cropOutputWidth: 0,
      cropOutputHeight: 0,
      cropTitle: '',
    },
  );

  const emit = defineEmits<{
    (e: 'update:value', value: string[]): void;
    (e: 'uploadChange', value: string): void;
    (e: 'delete', value: string[]): void;
  }>();

  // ===================== 状态 =====================
  const { t } = useI18n();
  const message = useMessage();
  const dialog = useDialog();
  const modal = useModal();

  const imageList = ref<string[]>([]);
  const urlMap = ref<Record<string, string>>({});
  const uploading = ref(false);

  // ===================== 计算属性 =====================
  const itemStyle = computed<CSSProperties>(() => ({
    width: `${props.previewWidth || props.width}px`,
    height: `${props.previewWidth || props.height}px`,
  }));

  const canUpload = computed(() => imageList.value.length < props.maxNumber);

  const acceptTypes = computed(() => props.accept.split(',').map((item) => item.trim()));

  const uploadProps = computed(() => ({
    accept: acceptTypes.value.map((t) => `.${t}`).join(','),
    disabled: props.disabled || uploading.value,
  }));

  // ===================== 工具函数 =====================
  /** 获取图片完整 URL */
  function getImageUrl(path: string): string {
    const url = urlMap.value[path] || path;
    return getFullImageUrl(url);
  }

  /** 检查文件类型 */
  function checkFileType(fileType: string): boolean {
    return componentSetting.upload.fileType.includes(fileType);
  }

  /** 是否可裁剪文件 */
  function isCroppableFile(file: File): boolean {
    const mime = file.type.toLowerCase();
    const name = file.name.toLowerCase();
    if (mime === 'image/jpeg' || mime === 'image/png' || mime === 'image/webp') {
      return true;
    }
    return /\.(jpg|jpeg|png|webp)$/i.test(name);
  }

  function isWebpConvertibleFile(file: File, fallbackType = ''): boolean {
    const mime = (file.type || fallbackType).toLowerCase();
    if (mime === 'image/jpeg' || mime === 'image/png') {
      return true;
    }

    const name = file.name.toLowerCase();
    return /\.(jpg|jpeg|png)$/i.test(name);
  }

  /** 格式化文件大小 */
  function formatSize(bytes: number, decimals = 2): string {
    if (bytes === 0) return '0 Bytes';
    if (bytes >= 1024 * 1024) {
      return (bytes / (1024 * 1024)).toFixed(decimals) + ' MB';
    }
    return bytes.toFixed(decimals) + ' KB';
  }

  /** 获取图片尺寸 */
  function getImageDimensions(file: File): Promise<ImageDimensions> {
    return new Promise((resolve, reject) => {
      const img = new Image();
      img.src = URL.createObjectURL(file);
      img.onload = () => {
        const dimensions: ImageDimensions = {
          width: img.width,
          height: img.height,
          size: file.size,
        };
        URL.revokeObjectURL(img.src);
        resolve(dimensions);
      };
      img.onerror = (error) => {
        URL.revokeObjectURL(img.src);
        reject(error);
      };
    });
  }

  /** 打开裁剪弹窗 */
  function openCropModal(file: File): Promise<File | null> {
    return new Promise((resolve) => {
      const modalInstance = modal.create({
        preset: 'card',
        title: props.cropTitle || t('common.upload.preview'),
        style: { width: '720px' },
        content: () =>
          h(ImageCropper, {
            file,
            aspectRatio: props.cropAspectRatio,
            outputWidth: props.cropOutputWidth,
            outputHeight: props.cropOutputHeight,
            onCancel: () => {
              modalInstance.destroy();
              resolve(null);
            },
            onConfirm: (blob: Blob) => {
              modalInstance.destroy();
              resolve(
                new File([blob], file.name, {
                  type: blob.type || file.type,
                  lastModified: Date.now(),
                }),
              );
            },
          }),
      });
    });
  }

  /** 上传图片（原型阶段：本地 blob URL 模拟，无真实接口） */
  async function uploadToHubOSS(params: {
    file: File | Blob;
    folder: number;
    filename?: string;
  }): Promise<{ url: string }> {
    const url = URL.createObjectURL(params.file);
    return { url };
  }

  // ===================== 事件处理 =====================
  /** 预览图片 */
  function handlePreview(path: string) {
    const url = getImageUrl(path);
    modal.create({
      preset: 'card',
      title: t('common.upload.preview'),
      bordered: false,
      style: { width: '520px' },
      content: () => h('img', { src: url, class: 'w-full', alt: 'preview' }),
    });
  }

  /** 删除图片 */
  function handleRemove(index: number) {
    dialog.info({
      title: t('common.tip'),
      content: t('common.upload.deleteConfirm'),
      positiveText: t('common.confirm'),
      negativeText: t('common.cancel'),
      onPositiveClick: () => {
        imageList.value.splice(index, 1);
        emit('delete', imageList.value);
        emit('update:value', imageList.value);
      },
    });
  }

  /** 上传前验证 */
  async function handleBeforeUpload({ file }: { file: UploadFileInfo }): Promise<boolean> {
    const fileInfo = file.file as File;
    if (!fileInfo) return false;

    const fileType = fileInfo.type?.split('/')[1] || '';
    const isImageType = ['jpg', 'png', 'jpeg'].includes(fileType);

    // 验证图片尺寸
    if (props.verifySize && isImageType && !props.enableCrop) {
      const dimensions = await getImageDimensions(fileInfo);
      if (dimensions.width !== props.width || dimensions.height !== props.height) {
        message.error(
          t('common.upload.fileSizeError', { width: props.width, height: props.height }),
        );
        return false;
      }
    }

    // 验证文件大小
    if (props.maxSize && fileInfo.size / 1024 >= props.maxSize) {
      message.error(t('common.upload.fileMaxSizeError', { size: formatSize(props.maxSize, 0) }));
      return false;
    }

    // 验证文件类型
    const defaultTypes = DEFAULT_ACCEPT;
    if (props.accept === defaultTypes) {
      if (!checkFileType(fileInfo.type) && acceptTypes.value.length > 0) {
        message.error(
          t('common.upload.fileTypeError', { types: componentSetting.upload.fileType.join(',') }),
        );
        return false;
      }
    } else {
      const isValidType = acceptTypes.value.some((ext) => fileInfo.type.includes(ext));
      if (!isValidType && acceptTypes.value.length > 0) {
        message.error(t('common.upload.fileTypeError', { types: acceptTypes.value.join(',') }));
        return false;
      }
    }

    // 额外验证
    if (props.beforeUploadExtra) {
      const dimensions = await getImageDimensions(fileInfo);
      const result = props.beforeUploadExtra(fileInfo, dimensions);
      return result instanceof Promise ? await result : result;
    }

    return true;
  }

  /** 自定义上传 */
  async function handleUpload({ file, onFinish, onError }: UploadCustomRequestOptions) {
    uploading.value = true;
    try {
      let uploadFile: File | Blob = file.file as File;
      let sourceFile = file.file as File;
      const fileType = file.type || '';
      let filename = file.name;

      if (props.enableCrop && sourceFile && isCroppableFile(sourceFile)) {
        const croppedFile = await openCropModal(sourceFile);
        if (!croppedFile) {
          onFinish();
          return;
        }
        uploadFile = croppedFile;
        sourceFile = croppedFile;
        filename = croppedFile.name;
      }

      // 仅对常规位图做 webp 转码，避免 svg/gif 等格式在解码阶段报错。
      const shouldConvertToWebp = isWebpConvertibleFile(sourceFile, fileType);

      if (shouldConvertToWebp) {
        try {
          const webpBlob = await encodeImageWithJsquash({
            source: sourceFile,
            mimeType: 'image/webp',
            quality: 92,
          });
          const sourceName = sourceFile.name || file.name;
          const nextName = sourceName.replace(/\.\w+$/i, '.webp');
          filename = nextName === sourceName ? `${sourceName}.webp` : nextName;
          const webpFile = new File([webpBlob], filename, {
            type: 'image/webp',
            lastModified: Date.now(),
          });
          uploadFile = webpFile;
          sourceFile = webpFile;
        } catch (error) {
          console.warn('WebP conversion skipped, fallback to original file.', error);
        }
      }

      // 上传到 Hub OSS
      const folder = props.customPath || 1;
      const result = await uploadToHubOSS({
        file: uploadFile,
        folder,
        filename,
      });

      const imageUrl = result.url;
      // 从 URL 中提取文件名作为 key
      const imageKey = props.fullPath ? imageUrl : imageUrl.split('/').pop() || imageUrl;

      // 保存映射关系
      urlMap.value[imageKey] = imageUrl;
      imageList.value.push(imageKey);

      emit('uploadChange', imageKey);
      emit('update:value', imageList.value);
      message.success(t('common.upload.uploadSuccess'));
      onFinish();
    } catch (error) {
      console.error('Upload error:', error);
      message.error(t('common.upload.uploadError'));
      onError();
    } finally {
      uploading.value = false;
    }
  }

  /** 设置图片列表 */
  function setImages(images: string[] | string) {
    imageList.value = [];
    urlMap.value = {};
    if (Array.isArray(images)) {
      imageList.value = images.filter(Boolean);
    } else if (images) {
      imageList.value.push(images);
    }
  }

  /** 获取图片列表 */
  function getImages(): string[] {
    return [...imageList.value];
  }

  /** 清空图片列表 */
  function clear() {
    imageList.value = [];
    urlMap.value = {};
  }

  // ===================== 监听 =====================
  watch(
    () => props.value,
    (newVal) => {
      if (newVal) {
        setImages(newVal);
      }
    },
    { immediate: true },
  );

  // ===================== 暴露方法 =====================
  defineExpose<BasicUploadInstance>({
    setImages,
    getImages,
    clear,
  });
</script>

<style lang="less" scoped>
  .basic-upload {
    width: 100%;

    &__list {
      display: flex;
      flex-wrap: wrap;
      align-items: center;
      gap: 8px;
    }

    &__item {
      position: relative;
      padding: 8px;
      border: 1px solid #d9d9d9;
      border-radius: 4px;
      display: flex;
      justify-content: center;
      align-items: center;
      overflow: hidden;

      &--compact {
        padding: 0;
      }

      &:hover .basic-upload__actions {
        opacity: 1;
      }

      &:hover &-content::before {
        opacity: 1;
      }
    }

    &__item-content {
      position: relative;
      width: 100%;
      height: 100%;

      &::before {
        content: '';
        position: absolute;
        inset: 0;
        z-index: 1;
        background-color: rgba(0, 0, 0, 0.5);
        opacity: 0;
        transition: opacity 0.3s;
      }
    }

    &__image {
      width: 100%;
      height: 100%;
      display: flex;
      justify-content: center;
      align-items: center;

      img {
        max-width: 100%;
        max-height: 100%;
        object-fit: contain;
      }
    }

    &__actions {
      position: absolute;
      top: 50%;
      left: 50%;
      z-index: 10;
      transform: translate(-50%, -50%);
      display: flex;
      align-items: center;
      gap: 8px;
      opacity: 0;
      transition: opacity 0.3s;
    }

    &__action {
      color: rgba(255, 255, 255, 0.85);
      cursor: pointer;
      transition: color 0.2s;

      &:hover {
        color: #fff;
      }
    }

    &__trigger {
      position: relative;
      border: 1px dashed #d9d9d9;
      border-radius: 4px;
      background: #fafafa;
      cursor: pointer;
      display: flex;
      justify-content: center;
      align-items: center;
      transition: border-color 0.3s;

      &:hover {
        border-color: var(--ui-accent-solid);
      }

      &--uploading {
        cursor: wait;
      }
    }

    &__trigger-content {
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 4px;
      color: #666;
      transition: opacity 0.2s ease;
    }

    &__trigger-text {
      font-size: 12px;
    }

    &__loading-text {
      position: absolute;
      right: 8px;
      bottom: 8px;
      font-size: 12px;
      color: var(--ui-accent-solid);
      line-height: 1;
    }
  }

  ::v-deep(.n-spin-container) {
    width: 100%;
    height: 100%;
  }

  ::v-deep(.n-base-loading) {
    color: var(--ui-accent-solid);
  }
</style>
