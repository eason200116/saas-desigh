import type { Component } from 'vue';
import BaseChartCard from './BaseChartCard.vue';
import TimeSeriesCard from './TimeSeriesCard.vue';
import PieChartCard from './PieChartCard.vue';
import FunnelTrendCard from './FunnelTrendCard.vue';
import RetentionChartCard from './RetentionChartCard.vue';
import PathChartCard from './PathChartCard.vue';
import TableCard from './TableCard.vue';
import NumberCard from './NumberCard.vue';

// 导出组件
export {
  BaseChartCard,
  TimeSeriesCard,
  PieChartCard,
  FunnelTrendCard,
  RetentionChartCard,
  PathChartCard,
  TableCard,
  NumberCard,
};

// 卡片类型到组件的映射
export const cardComponentMap: Record<string, Component> = {
  bar: TimeSeriesCard,
  line: TimeSeriesCard,
  bar_line: TimeSeriesCard,
  stacked: TimeSeriesCard,
  pie: PieChartCard,
  funnel: FunnelTrendCard,
  retention: RetentionChartCard,
  path: PathChartCard,
  table: TableCard,
  number: NumberCard,
};
