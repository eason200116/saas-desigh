<script setup lang="ts">
  /**
   * 表格卡片
   */
  import { computed } from 'vue';
  import { useI18n } from 'vue-i18n';
  import type { CardConfig, TableDataPoint } from '../types';

  interface Props {
    title: string;
    data: TableDataPoint[];
    config: CardConfig;
    height?: string | number;
    loading?: boolean;
  }

  const props = withDefaults(defineProps<Props>(), {
    height: 220,
    loading: false,
  });

  const { t } = useI18n();

  // 是否有数据
  const hasData = computed(() => props.data && props.data.length > 0);

  // 表格列配置
  const tableColumns = computed(() => [
    { title: t('analytics.common.time'), key: 'time' },
    {
      title: props.config.seriesName || t('analytics.common.value'),
      key: 'value',
    },
  ]);

  // 卡片整体高度套到 wrapper；table 内部 max-height 扣掉 header + body padding
  const wrapperHeight = computed(() =>
    typeof props.height === 'number' ? `${props.height}px` : props.height,
  );
  const maxHeight = computed(() => {
    const h = typeof props.height === 'number' ? props.height : parseInt(props.height as string);
    return Math.max(120, h - 46 - 24);
  });
</script>

<template>
  <div class="table-card" :style="{ height: wrapperHeight }">
    <!-- 卡片头部 -->
    <div class="table-card__header">
      <span class="table-card__title">{{ title }}</span>
    </div>

    <!-- 卡片内容 -->
    <div class="table-card__body">
      <n-spin :show="loading">
        <n-data-table
          v-if="hasData"
          :columns="tableColumns"
          :data="data"
          :bordered="false"
          size="small"
          :max-height="maxHeight"
        />
        <n-empty v-else :description="t('analytics.common.noData')" />
      </n-spin>
    </div>
  </div>
</template>

<script lang="ts">
  export default {
    name: 'TableCard',
  };
</script>

<style lang="less" scoped>
  .table-card {
    background: #fff;
    border: 1px solid #f0f0f0;
    border-radius: 8px;
    height: 100%;
    display: flex;
    flex-direction: column;

    &__header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 12px 16px;
      padding-right: 44px; // 给 dynamic-card-action 留出空间
      border-bottom: 1px solid #f0f0f0;
    }

    &__title {
      font-size: 14px;
      font-weight: 500;
      color: #262626;
      flex: 1;
    }

    &__body {
      flex: 1;
      min-height: 0;
      padding: 12px;
    }
  }

  // Dark theme
  .dark .table-card {
    background: #242b3d;
    border-color: #3a4459;

    &__title {
      color: #e5e7eb;
    }
  }
</style>
