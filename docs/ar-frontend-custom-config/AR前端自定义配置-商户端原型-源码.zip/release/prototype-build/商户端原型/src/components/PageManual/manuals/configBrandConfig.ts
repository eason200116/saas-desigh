// 品牌配置（商户端 tenant · configCenter_brandConfig）功能说明书。
// 锚定 src/views/config/brandConfig/index.vue + data.ts + 内嵌的
// src/views/operations/siteList/detail/index.vue(前台样式工作台壳，embedded模式) 真实控件（R53 实证、不臆造）。
// 1:1迁自ar-saas原型「运营管理→品牌配置」。2026-07-22核实：本页已改为纯内嵌模式(商户卡片点选→
// 下方直接切换展示，不再跳独立路由)，router里也已确认无 brandConfig/:tenantId 子路由——与更早一版
// 代码(曾有router.push到不存在路由的死链)不同，当前实现自洽无残留死链。

import type { PageManual } from '../types';

const manual: PageManual = {
  route: 'configCenter_brandConfig',
  title: '品牌配置',
  overview:
    '商户端「配置中心 › 品牌配置」页，1:1迁自ar-saas原型「运营管理→品牌配置」。顶部横向滚动的商户卡片' +
    '(点选不跳转，展示商户名+当前H5版型+最近修改时间)，选中后下方直接内嵌展示该商户的「前台样式工作台」' +
    '(复用src/views/operations/siteList/detail组件，embedded模式)，仅开放"版型"与"SEO"2个面板' +
    '(工作台原生共7个面板，本页按panel-keys精简)，且"版型"面板锁定只能配H5端(Web/APP置灰"开发中")。' +
    '工作台面板内部字段级细节(如版型具体参数/SEO标题关键词等)属该共享工作台自身范畴，非本页独有，此处' +
    '只文档化本页可见的壳层控件(商户切换/面板切换/重置/保存/预览折叠)。默认进页自动选中第一个商户。' +
    '2026-07-22核实代码未发现真实缺陷。',
  items: [
    {
      anchor: 'selectMerchant',
      name: '商户卡片（选择）',
      group: '搜索',
      interaction: '点击切换选中商户(不跳转路由)，下方工作台立即重载为该商户的配置；当前选中卡片高亮描边。',
    },
    {
      anchor: 'panelSwitch',
      name: '面板切换（版型/SEO）',
      group: '搜索',
      interaction: '工作台左侧竖排导航，点击切换编辑区展示"版型"或"SEO"面板；未保存的改动切换前会二次确认是否放弃。',
    },
    {
      anchor: 'resetPanel',
      name: '重置',
      group: '操作',
      interaction: '按钮，当前面板有改动时可点，点击放弃本面板未保存的修改、还原到载入时的值。',
    },
    {
      anchor: 'savePanel',
      name: '保存',
      group: '操作',
      interaction: '按钮，当前面板有改动时可点，点击提交该面板改动并落库生效。',
    },
    {
      anchor: 'previewToggle',
      name: '预览·折叠/展开',
      group: '操作',
      interaction: '右侧手机预览区把手，点击折叠(仅留16px把手)/展开，折叠后中间编辑区自动扩满。',
    },
  ],
  fields: [
    { name: '商户卡片·商户名', def: 'ID-商户名-国家（货币），取自站点信息，去除重复前缀。' },
    { name: '商户卡片·当前H5版型', def: '该商户前台移动端当前使用的版型名称。' },
    { name: '商户卡片·最近修改', def: '该商户前台样式配置最后一次修改的时间。' },
    { name: '版型面板', def: '维护Web与移动端版式、当前租户使用的主题；本页锁定仅H5可配，Web/APP显示"开发中"占位。' },
    { name: 'SEO面板', def: '维护前台站点的标题、关键词、描述与附加脚本。' },
  ],
};

export default manual;
