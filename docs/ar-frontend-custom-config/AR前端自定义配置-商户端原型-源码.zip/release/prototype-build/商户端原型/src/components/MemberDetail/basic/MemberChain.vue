<template>
  <!-- 路径图 / 流程图：归因链路、代理关系链等横向节点链（节点 + 箭头），按 V3 风格实现 -->
  <div class="member-chain-wrap">
    <!-- 紧凑模式(仅样板1100002)：铺满版块宽度的等宽级列，每列上「N级」下小字ID；完整层级(总代/直属上级/本会员)留悬停 -->
    <div v-if="compact" class="member-chain member-chain--levels">
      <template v-for="(node, i) in nodes" :key="`lv-${i}`">
        <n-tooltip trigger="hover" placement="top">
          <template #trigger>
            <div
              class="member-chain-lv"
              :class="{
                'member-chain-lv--member': node.kind === 'member',
                'member-chain-lv--group': node.kind === 'group',
              }"
            >
              <span class="member-chain-lv__level">{{ node.levelShort || node.level }}</span>
              <!-- 每个层级底下的 ID 点击直接复制（仅紧凑模式=样板1100002·2026-07-13 用户要求） -->
              <span
                class="member-chain-lv__id"
                :class="{ 'member-chain-lv__id--copyable': node.value }"
                @click.stop="copyId(node.value)"
                >{{ node.value || '--' }}</span
              >
            </div>
          </template>
          {{ node.level }}：{{ node.value || '--' }}
        </n-tooltip>
        <span v-if="i < nodes.length - 1" class="member-chain-lv__sep">›</span>
      </template>
    </div>
    <div
      v-else
      class="member-chain"
      :class="{ 'member-chain--clickable': clickable }"
      :title="clickable ? hint : undefined"
      @click="clickable && emit('view')"
    >
      <template v-for="(node, i) in nodes" :key="i">
        <div
          class="member-chain__node"
          :class="{
            'member-chain__node--member': node.kind === 'member',
            'member-chain__node--group': node.kind === 'group',
          }"
        >
          <span class="member-chain__level">
            {{ node.level }}
            <n-tooltip v-if="node.tip" trigger="hover" placement="top">
              <template #trigger>
                <span class="member-chain__qm" @click.stop>?</span>
              </template>
              {{ node.tip }}
            </n-tooltip>
          </span>
          <span class="member-chain__value">{{ node.value || '--' }}</span>
        </div>
        <span v-if="i < nodes.length - 1" class="member-chain__arrow">→</span>
      </template>
    </div>
    <span v-if="clickable && hint" class="member-chain__hint" @click="emit('view')">{{
      hint
    }}</span>
  </div>
</template>

<script setup lang="ts">
  defineOptions({ name: 'MemberChain' });

  import { useI18n } from 'vue-i18n';
  import { useMessage } from 'naive-ui';

  interface ChainNode {
    /** 层级名（渠道 / 一级代理 / 9级·直属上级 等） */
    level: string;
    /** 层级短名（仅「N级」，紧凑模式顶部展示；完整 level 留悬停） */
    levelShort?: string;
    /** 节点值 */
    value?: string | number | null;
    /** 悬浮说明（可选） */
    tip?: string;
    /** 节点类型：member=本会员高亮，group=集团高亮 */
    kind?: 'member' | 'group';
  }

  withDefaults(
    defineProps<{ nodes: ChainNode[]; clickable?: boolean; hint?: string; compact?: boolean }>(),
    {
      clickable: false,
      hint: '',
      compact: false,
    },
  );

  const emit = defineEmits<{ (e: 'view'): void }>();

  const { t } = useI18n();
  const message = useMessage();

  // 点击层级 ID → 复制到剪贴板 + 「已复制」提示（仅紧凑模式=样板1100002）；剪贴板不可用时降级 execCommand
  async function copyId(val: string | number | null | undefined) {
    if (val == null || val === '' || val === '--') return;
    const text = String(val);
    try {
      await navigator.clipboard.writeText(text);
      message.success(`${t('common.copy.copied')}：${text}`);
    } catch {
      try {
        const ta = document.createElement('textarea');
        ta.value = text;
        ta.style.position = 'fixed';
        ta.style.opacity = '0';
        document.body.appendChild(ta);
        ta.select();
        document.execCommand('copy');
        document.body.removeChild(ta);
        message.success(`${t('common.copy.copied')}：${text}`);
      } catch {
        message.error(t('common.copy.failed'));
      }
    }
  }
</script>

<style lang="less" scoped>
  .member-chain-wrap {
    display: flex;
    flex-direction: column;
  }

  .member-chain {
    display: flex;
    flex-wrap: wrap;
    align-items: stretch;
    gap: 6px;
    padding: 4px 0;
  }

  .member-chain--clickable {
    cursor: pointer;
    border-radius: 8px;
    transition: background 0.15s;

    &:hover {
      background: #f8fafc;
    }
  }

  .member-chain__hint {
    align-self: flex-end; /* 置于卡牌区右下角 */
    margin-top: 8px;
    color: #2563eb;
    font-size: 12px;
    cursor: pointer;

    &:hover {
      text-decoration: underline;
    }
  }

  .member-chain__node {
    display: flex;
    flex: 1 1 0; /* 等宽拉伸撑满整行，避免右侧留白；窄屏回退 min-width 后换行 */
    flex-direction: column;
    gap: 4px;
    min-width: 92px;
    padding: 8px 12px;
    background: #f8fafc;
    border: 1px solid #e2e8f0;
    border-radius: 8px;

    &--member {
      background: #eff6ff;
      border-color: #93c5fd;
    }

    &--group {
      background: #f0fdf4;
      border-color: #86efac;
    }
  }

  .member-chain__level {
    display: inline-flex;
    align-items: center;
    gap: 3px;
    font-size: 12px;
    color: #94a3b8;
  }

  .member-chain__qm {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 14px;
    height: 14px;
    font-size: 10px;
    color: #94a3b8;
    border: 1px solid #cbd5e1;
    border-radius: 50%;
    cursor: help;
  }

  .member-chain__value {
    font-size: 13px;
    font-weight: 600;
    color: #1e293b;
    white-space: nowrap;
  }

  .member-chain__arrow {
    display: flex;
    align-items: center;
    color: #cbd5e1;
    font-size: 14px;
  }

  /* 紧凑模式：铺满版块宽度的等宽级列(上「N级」+ 下小字ID)，整体做小 */
  .member-chain--levels {
    flex-wrap: wrap;
    align-items: stretch;
    gap: 3px;
    padding: 2px 0;
  }
  .member-chain-lv {
    display: flex;
    flex: 1 1 0; /* 等宽拉伸铺满版块宽度；窄屏回退 min-width 后换行 */
    flex-direction: column;
    align-items: center;
    gap: 0;
    min-width: 48px;
    padding: 3px 4px;
    background: #f8fafc;
    border: 1px solid #e2e8f0;
    border-radius: 6px;
    cursor: help;

    &--member {
      background: #eff6ff;
      border-color: #93c5fd;
    }
    &--group {
      background: #f0fdf4;
      border-color: #86efac;
    }
  }
  .member-chain-lv__level {
    font-size: 11px;
    font-weight: 600;
    color: #475569;
    white-space: nowrap;
    line-height: 1.35;
  }
  .member-chain-lv__id {
    font-size: 10px; /* 比层级小一点 */
    color: #94a3b8;
    text-align: center;
    line-height: 1.3;
    word-break: break-all;
  }
  /* 层级 ID 可点击复制：悬停变蓝+下划线（仅紧凑模式=样板1100002） */
  .member-chain-lv__id--copyable {
    cursor: pointer;
    transition: color 0.15s;

    &:hover {
      color: #2563eb;
      text-decoration: underline;
    }
  }
  .member-chain-lv__sep {
    display: flex;
    align-items: center;
    color: #cbd5e1;
    font-size: 11px;
  }
</style>
