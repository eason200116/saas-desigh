import type { QuickDateItem } from './quickDate';

export interface DateRangeValue {
  start: number;
  end: number;
}

/** 日期范围选择器的快捷项。结构与 `QuickDateItem` 一致，保留独立类型名仅用于语义区分 */
export type ShortcutItem = QuickDateItem;

/**
 * 日期范围选择器快捷项配置。
 * - false：隐藏快捷按钮
 * - true / undefined：显示内部默认快捷项
 * - ShortcutItem[]：显示外部自定义快捷项
 */
export type DateRangeShortcuts = boolean | ShortcutItem[];

/**
 * 日期范围选择器内置快捷项集合。
 * - `default`        : 9 项（today/yesterday/thisWeek/lastWeek/thisMonth/lastMonth/last7Days/last30Days/last60Days），
 *                     ProCrudTable 搜索区的系统标准快捷面板
 * - `simple`         : 4 项（today/yesterday/last7Days/last30Days）
 * - `report`         : 12 项（default 9 项 + last3/15/90Days），完整跨度
 * - `reportCompact`  : 6 项报表常用组合（today/yesterday/last3Days/近一周/last15Days/近一月）；
 *                     `近一周`/`近一月` 与 `last7Days`/`last30Days` 共享 ms range，仅中文 label 调整
 */
export type DateRangeShortcutPreset = 'default' | 'report' | 'reportCompact' | 'simple';

/** 默认选中的快捷项 key。自定义 shortcuts 时允许传入自定义 key。 */
export type DateRangeDefaultShortcut =
  | 'today'
  | 'yesterday'
  | 'thisWeek'
  | 'lastWeek'
  | 'thisMonth'
  | 'lastMonth'
  | 'last3Days'
  | 'last7Days'
  | 'last15Days'
  | 'last30Days'
  | 'last60Days'
  | 'last90Days'
  | (string & {});

/**
 * 日期范围选择器时区入参。
 * - string：强制使用该自定义时区
 * - false：强制 UTC，不读取 CrudTable 上下文和当前默认商户
 * - null / undefined：未显式设置，先读 CrudTable 上下文，再回退当前默认商户时区
 */
export type DateRangeTimezone = string | null | false;

export interface ProDateRangePickerProps {
  /** 当前值 [start, end]。number 元组用于 timestamp 模式；string 元组仅 valueFormat='string' 时生效 */
  value?: [number, number] | [string, string] | null;
  /**
   * 出站格式。
   *  - 'timestamp'（默认）：emit 毫秒时间戳
   *     · 传了 `timezone`：真实 UTC（面板 wall clock 按商户时区解释）
   *     · 没传 `timezone`：UTC+0 字面协议（面板 wall clock 字段原样编码成 UTC 字段）
   *  - 'string'：emit 按 `valueStringPattern` 格式化的字符串，**不做任何时区处理**（面板读出来啥字面就是啥字面）
   */
  valueFormat?: 'timestamp' | 'string';
  /**
   * valueFormat='string' 时输出/解析的字符串格式。
   * 不传时自动 fallback 到 `displayFormat`（让"UI 显示粒度 = form 存储粒度"这一最常见场景只声明一次）；
   * 两者都不传才走最终默认 `'yyyy-MM-dd HH:mm:ss'`。
   */
  valueStringPattern?: string;
  /** 商户时区。仅 valueFormat='timestamp' 时生效；具体优先级见 DateRangeTimezone。 */
  timezone?: DateRangeTimezone;
  /** 最大可选天数 */
  maxDays?: number;
  /** 是否允许选择未来日期 */
  allowFuture?: boolean;
  /** 快捷选项：false 隐藏，true/不传显示默认，数组使用外部自定义 */
  shortcuts?: DateRangeShortcuts;
  /** 默认快捷选项集合: default | report | simple */
  shortcutPreset?: DateRangeShortcutPreset;
  /** 初始为空时按快捷项 key 写入默认区间，例如 today / yesterday */
  defaultShortcut?: DateRangeDefaultShortcut;
  /** 是否显示时分秒选择 */
  showTime?: boolean;
  /** 占位符（触发器为空时显示） */
  placeholder?: string;
  /** 是否禁用 */
  disabled?: boolean;
  /** 是否可清除 */
  clearable?: boolean;
  /** 弹出框宽度（showTime=false 时生效；showTime=true 自动撑开） */
  popoverWidth?: number;
  /** 触发器显示格式（与 valueStringPattern 是不同概念：前者只控制 trigger 文本，后者控制 form value 字符串） */
  displayFormat?: string;
  /**
   * 起止双字段展平到 form。数组顺序 = [startKey, endKey]。
   * 设置后：初始化时从这两个字段读初值、交互时把起止值写回它们；
   * 自身 `update:value` 不再发射（聚合数组不再落 form 里，避免冗余）。
   * 仅在 ProField 包裹下生效（需要 form context）。
   */
  modelKeys?: string[];
  /**
   * 左右日历视图是否绑定连续。与 NDatePicker `bind-calendar-months` 同名同义。
   *  - `false`（默认，与原生 NDatePicker 默认一致）：左右独立视图，互不影响
   *  - `true`：右视图 = 左视图 + 1 月，箭头联动
   *
   * 默认值与 NDatePicker 原生默认（false）一致。如需保留早期联动行为，请显式传 true。
   */
  bindCalendarMonths?: boolean;
  /**
   * 用户选完日期但未编辑时分秒时自动填充的默认时间。
   * 与 NDatePicker `default-time` 同名同义。格式必须 `HH:mm:ss`。
   *  - `string`：起止使用同一时间，如 `'09:00:00'`
   *  - `[startStr, endStr]`：起止各自独立，如 `['00:00:00', '23:59:59']` 闭合到日内
   *  - 不传：保留现有硬编码（起点 `00:00:00`、终点 `23:59:59`）
   *
   * ⚠️ 不支持 NDatePicker 2.43.2+ 的函数形态 `(timestamp, position, value) => string`。
   *    调用方如需动态计算时分秒，请通过 watch + setFieldValue 自管。
   */
  defaultTime?: string | [string, string];
}
