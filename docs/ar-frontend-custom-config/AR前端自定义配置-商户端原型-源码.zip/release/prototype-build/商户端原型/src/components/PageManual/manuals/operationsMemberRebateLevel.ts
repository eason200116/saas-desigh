// 会员返佣等级（商户端 tenant · operations_memberRebateLevel）功能说明书。
// 锚定 src/views/operations/memberRebateLevel/index.vue + MemberRebateLevelFormModal.vue + RebateRateTableModal.vue
// + data.ts 真实控件（R53 实证、不臆造）。

import type { PageManual } from '../types';

const manual: PageManual = {
  route: 'operations_memberRebateLevel',
  title: '会员返佣等级',
  overview:
    '商户端「运营管理 › 会员返佣等级」页，为指定会员单独指定返佣等级（覆盖默认的动态返佣规则）。返佣模式' +
    '固定为"固定返佣"（表单里可见但禁用，不可改），仅固定返佣模式才有"生效日期区间"配置，等级本身可点击' +
    '查看该等级对应的完整费率表（只读弹窗）。' +
    '2026-07-22核实代码发现：新增/编辑保存(saveMemberRebateLevel)与删除(deleteMemberRebateLevel，含单条和' +
    '批量)均只返回成功、不真正写回底层数组，操作提示成功但列表刷新后看不到变化。如实记录，未修复。',
  items: [
    {
      anchor: 'merchant',
      name: '商户（必选）',
      group: '搜索',
      interaction: '下拉单选，红星必填；未选点查询红框+红字提示。',
      limit: '单选必填（R63）。',
    },
    {
      anchor: 'userId',
      name: '会员ID',
      group: '搜索',
      interaction: '文本框，可清空。',
    },
    {
      anchor: 'reset',
      name: '重置',
      group: '搜索',
      interaction: 'ProCrudTable内置重置按钮。',
    },
    {
      anchor: 'act_add',
      name: '新增',
      group: '操作',
      interaction: '主色按钮，点击打开新增弹窗（440px宽）。',
      logic:
        '弹窗字段：商户(单选，编辑态置灰) → 会员ID(编辑态置灰) → 返佣模式(下拉但禁用，固定显示"固定返佣") → ' +
        '返佣等级(下拉) → 生效日期区间(仅返佣模式=固定返佣时显示，日期范围选择)。',
    },
    {
      anchor: 'act_batchDelete',
      name: '批量删除',
      group: '操作',
      interaction: '需先勾选至少1行才可点击（未勾选置灰，按钮带勾选数量）；点击弹二次确认。',
    },
    {
      anchor: 'col_rebateLevel',
      name: '返佣等级（可点击，带虚线下划线提示）',
      group: '列',
      interaction: '蓝色Tag，形如"LvN"，带虚线下划线提示可点击。',
      logic: '点击打开只读「返佣等级费率表」弹窗（860px宽），展示该等级对应的完整返佣费率明细。',
    },
    {
      anchor: 'act_edit',
      name: '编辑',
      group: '操作',
      interaction: '每行常驻，点击打开编辑弹窗（字段同新增，回显当前值）。',
    },
    {
      anchor: 'act_delete',
      name: '删除',
      group: '操作',
      interaction: '每行常驻，点击弹二次确认。',
    },
  ],
  fields: [
    { name: '商户（列）', def: '该配置所属商户，标签展示。' },
    { name: '会员ID', def: '被单独指定返佣等级的会员编号，可点击进详情。' },
    { name: '返佣等级', def: '该会员当前指定的返佣等级，见交互条目 col_rebateLevel。' },
    { name: '已用天数', def: '该配置生效以来累计使用的天数，无适用场景时展示"-"。' },
    { name: '生效日期区间', def: '固定返佣模式下该配置的生效起止日期，无配置展示"-"。' },
    { name: '创建人', def: '创建该配置的操作人账号，无则展示"-"。' },
    { name: '创建时间', def: '该配置的创建时间。' },
    { name: '最后修改人', def: '最近一次编辑该配置的操作人账号，无则展示"-"。' },
    { name: '最后修改时间', def: '该配置最近一次编辑的时间。' },
  ],
};

export default manual;
