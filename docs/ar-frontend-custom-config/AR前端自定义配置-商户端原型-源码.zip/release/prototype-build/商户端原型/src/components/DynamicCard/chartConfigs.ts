import type {
  CardConfig,
  TimeSeriesDataPoint,
  DistributionDataPoint,
  FunnelDataPoint,
  RetentionDataPoint,
} from './types';

type TranslateFunc = (key: string) => string;

/**
 * 柱状图/折线图配置
 */
export function generateBarLineConfig(
  data: TimeSeriesDataPoint[],
  config: CardConfig,
  chartType: 'bar' | 'line',
  t: TranslateFunc,
): Record<string, any> {
  const hasSecondSeries = data.some((d) => d.value2 !== undefined);
  const seriesName1 = config.seriesName || t('analytics.common.value');
  const seriesName2 = config.seriesName2 || t('analytics.common.value2');

  const series: any[] = [
    {
      name: seriesName1,
      type: chartType,
      data: data.map((d) => d.value),
      itemStyle: { color: config.seriesColor || '#2080f0' },
      barMaxWidth: 40,
      smooth: chartType === 'line',
    },
  ];

  if (hasSecondSeries) {
    series.push({
      name: seriesName2,
      type: chartType,
      data: data.map((d) => d.value2 || 0),
      itemStyle: { color: config.seriesColor2 || '#18a058' },
      barMaxWidth: 40,
      smooth: chartType === 'line',
    });
  }

  return {
    tooltip: {
      trigger: 'axis',
      axisPointer: { type: chartType === 'bar' ? 'shadow' : 'line' },
    },
    legend: hasSecondSeries
      ? {
          data: [seriesName1, seriesName2],
          bottom: 0,
        }
      : undefined,
    grid: {
      left: '3%',
      right: '4%',
      bottom: hasSecondSeries ? '15%' : '3%',
      top: '10%',
      containLabel: true,
    },
    xAxis: {
      type: 'category',
      data: data.map((d) => d.time),
      axisLabel: { rotate: 45, fontSize: 10 },
    },
    yAxis: { type: 'value' },
    series,
  };
}

/**
 * 柱线混合图配置
 */
export function generateBarLineComboConfig(
  data: TimeSeriesDataPoint[],
  config: CardConfig,
  t: TranslateFunc,
): Record<string, any> {
  const seriesName1 = config.seriesName || t('analytics.common.value');
  const seriesName2 = config.seriesName2 || t('analytics.common.value2');

  return {
    tooltip: { trigger: 'axis' },
    legend: {
      data: [seriesName1, seriesName2],
      bottom: 0,
    },
    grid: {
      left: '3%',
      right: '4%',
      bottom: '15%',
      top: '10%',
      containLabel: true,
    },
    xAxis: {
      type: 'category',
      data: data.map((d) => d.time),
      axisLabel: { rotate: 45, fontSize: 10 },
    },
    yAxis: [
      { type: 'value', name: seriesName1 },
      { type: 'value', name: seriesName2 },
    ],
    series: [
      {
        name: seriesName1,
        type: 'bar',
        data: data.map((d) => d.value),
        itemStyle: { color: config.seriesColor || '#2080f0' },
        barMaxWidth: 40,
      },
      {
        name: seriesName2,
        type: 'line',
        yAxisIndex: 1,
        data: data.map((d) => d.value2 || 0),
        itemStyle: { color: config.seriesColor2 || '#18a058' },
        smooth: true,
      },
    ],
  };
}

/**
 * 堆叠图配置
 */
export function generateStackedConfig(
  data: TimeSeriesDataPoint[],
  config: CardConfig,
  t: TranslateFunc,
): Record<string, any> {
  const seriesName1 = config.seriesName || t('analytics.common.value');
  const seriesName2 = config.seriesName2 || t('analytics.common.value2');

  return {
    tooltip: {
      trigger: 'axis',
      axisPointer: { type: 'shadow' },
    },
    legend: {
      data: [seriesName1, seriesName2],
      bottom: 0,
    },
    grid: {
      left: '3%',
      right: '4%',
      bottom: '15%',
      top: '10%',
      containLabel: true,
    },
    xAxis: {
      type: 'category',
      data: data.map((d) => d.time),
      axisLabel: { rotate: 45, fontSize: 10 },
    },
    yAxis: { type: 'value' },
    series: [
      {
        name: seriesName1,
        type: 'bar',
        stack: 'total',
        data: data.map((d) => d.value),
        itemStyle: { color: config.seriesColor || '#2080f0' },
      },
      {
        name: seriesName2,
        type: 'bar',
        stack: 'total',
        data: data.map((d) => d.value2 || 0),
        itemStyle: { color: config.seriesColor2 || '#18a058' },
      },
    ],
  };
}

/**
 * 饼图配置
 */
export function generatePieConfig(
  data: DistributionDataPoint[],
  config: CardConfig,
  t: TranslateFunc,
): Record<string, any> {
  return {
    tooltip: {
      trigger: 'item',
      formatter: '{b}: {c} ({d}%)',
    },
    legend: {
      orient: 'vertical',
      right: 10,
      top: 'center',
      itemWidth: 10,
      itemHeight: 10,
      textStyle: { fontSize: 10 },
    },
    series: [
      {
        name: config.seriesName || t('analytics.common.distribution'),
        type: 'pie',
        radius: ['40%', '70%'],
        center: ['35%', '50%'],
        avoidLabelOverlap: false,
        itemStyle: {
          borderRadius: 5,
          borderColor: '#fff',
          borderWidth: 2,
        },
        label: { show: false },
        data: data,
      },
    ],
  };
}

/**
 * 漏斗图配置
 */
export function generateFunnelConfig(
  data: FunnelDataPoint[],
  config: CardConfig,
  t: TranslateFunc,
): Record<string, any> {
  const maxCount = Math.max(...data.map((d) => d.count), 1);
  const funnelData = data.map((d) => ({
    name: d.name,
    value: Math.round((d.count / maxCount) * 100),
    realValue: d.count,
    percentage: d.percentage,
  }));

  const countLabel = t('analytics.trafficDashboard.funnel.tooltipCount');
  const rateLabel = t('analytics.trafficDashboard.funnel.tooltipRate');

  return {
    tooltip: {
      trigger: 'item',
      formatter: (params: any) => {
        return `${params.name}<br/>${countLabel}: ${params.data.realValue}<br/>${rateLabel}: ${params.data.percentage}%`;
      },
    },
    series: [
      {
        name: config.seriesName || t('analytics.common.funnel'),
        type: 'funnel',
        left: '10%',
        top: 20,
        bottom: 20,
        width: '80%',
        min: 0,
        max: 100,
        minSize: '20%',
        maxSize: '100%',
        sort: 'descending',
        gap: 2,
        label: {
          show: true,
          position: 'inside',
          formatter: (params: any) => `${params.name}\n${params.data.realValue}`,
        },
        data: funnelData,
      },
    ],
  };
}

/**
 * 留存图配置
 */
export function generateRetentionConfig(
  data: RetentionDataPoint[],
  config: CardConfig,
  t: TranslateFunc,
): Record<string, any> {
  const sortedData = [...data].sort((a, b) => a.day_diff - b.day_diff);
  const day0Users = sortedData[0]?.retained_users || 1;

  return {
    tooltip: {
      trigger: 'axis',
      formatter: (params: any) => {
        const point = params[0];
        const retention = ((point.value / day0Users) * 100).toFixed(2);
        return `第${point.name}天<br/>留存用户: ${point.value}<br/>留存率: ${retention}%`;
      },
    },
    grid: {
      left: '3%',
      right: '4%',
      bottom: '3%',
      top: '10%',
      containLabel: true,
    },
    xAxis: {
      type: 'category',
      data: sortedData.map((d) => d.day_diff),
      name: t('analytics.common.day'),
      axisLabel: { fontSize: 10 },
    },
    yAxis: {
      type: 'value',
      name: t('analytics.common.users'),
    },
    series: [
      {
        name: t('analytics.common.retainedUsers'),
        type: 'line',
        data: sortedData.map((d) => d.retained_users),
        smooth: true,
        areaStyle: { opacity: 0.3 },
        itemStyle: { color: config.seriesColor || '#2080f0' },
      },
    ],
  };
}

/**
 * 路径图配置（桑基图）
 */
export function generatePathConfig(
  data: any[],
  _config: CardConfig,
  _t: TranslateFunc,
): Record<string, any> {
  // 路径数据需要转换为桑基图格式
  // 假设 data 格式为 [{ source, target, value }]
  const nodes = new Set<string>();
  data.forEach((d) => {
    nodes.add(d.source);
    nodes.add(d.target);
  });

  return {
    tooltip: {
      trigger: 'item',
      triggerOn: 'mousemove',
    },
    series: [
      {
        type: 'sankey',
        layout: 'none',
        emphasis: { focus: 'adjacency' },
        data: Array.from(nodes).map((name) => ({ name })),
        links: data.map((d) => ({
          source: d.source,
          target: d.target,
          value: d.value,
        })),
        lineStyle: {
          color: 'gradient',
          curveness: 0.5,
        },
      },
    ],
  };
}

/**
 * 根据卡片类型生成图表配置
 */
export function generateChartConfig(
  cardType: string,
  data: any[],
  config: CardConfig,
  t: TranslateFunc,
): Record<string, any> | null {
  switch (cardType) {
    case 'bar':
      return generateBarLineConfig(data, config, 'bar', t);
    case 'line':
      return generateBarLineConfig(data, config, 'line', t);
    case 'bar_line':
      return generateBarLineComboConfig(data, config, t);
    case 'stacked':
      return generateStackedConfig(data, config, t);
    case 'pie':
      return generatePieConfig(data, config, t);
    case 'funnel':
      return generateFunnelConfig(data, config, t);
    case 'retention':
      return generateRetentionConfig(data, config, t);
    case 'path':
      return generatePathConfig(data, config, t);
    default:
      return null;
  }
}
