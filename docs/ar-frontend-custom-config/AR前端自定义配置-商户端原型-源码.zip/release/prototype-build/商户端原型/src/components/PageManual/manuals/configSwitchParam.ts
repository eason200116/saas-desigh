// 开关参数配置（商户端 tenant · configCenter_switchParam）功能说明书。
// 锚定 src/views/config/switchParam/index.vue + shared/ConfigOpLogPopover.vue +
// system/sysParam/components/SysParamField.vue + data.ts 真实控件（R53 实证、不臆造）。
// 本页是融合页（方案2 双Tab）：聚合「配置开关」(configSwitch，~58项) + 「系统参数配置」
// (sysParam，7大类多组参数)，源两页路由仍在但已 hidden(菜单不显)，本页是唯一可达入口。

import type { PageManual } from '../types';

const manual: PageManual = {
  route: 'configCenter_switchParam',
  title: '开关参数配置',
  overview:
    '商户端「配置中心 › 开关参数配置」页，融合「开关配置」+「系统参数配置」为2个Tab。核心联动规则：' +
    '①部分开关"开启"后会在该开关卡片下方展开专属的系统参数配置项(如"代理审核机制"开启后展开"审核天数"参数)，' +
    '"关闭"则收起；②已挂到某开关下的参数，从"系统参数配置"Tab里去重去掉，不会两处重复出现。左侧目录支持' +
    '按分类跳转+全页配置项(开关+参数，跨两个Tab)模糊搜索，命中后自动展开所在卡片/分类并高亮定位。保存按' +
    '"板块"分别进行(每个开关卡片/每个参数分类各自一个"保存"按钮)，无整页统一保存；数值类参数校验min/max，' +
    '超限红框+指名哪项配错。2026-07-22核实代码未发现真实缺陷(全部保存路径均调用真实API，仅为mock不落库' +
    '属原型统一特性，非本页独有缺陷)。',
  items: [
    {
      anchor: 'tab_switch',
      name: '开关配置（tab）',
      group: '搜索',
      interaction: '默认选中的tab，标题旁数字为该类目下开关总数。',
    },
    {
      anchor: 'tab_param',
      name: '系统参数配置（tab）',
      group: '搜索',
      interaction: '点击切换，标题旁数字为已去重后的参数总数。',
    },
    {
      anchor: 'tenantId',
      name: '商户',
      group: '搜索',
      interaction: '单一商户条，必选(红星标记)；切换后重新加载该商户的开关+参数取值。',
      limit: '必选，未选无法查看/编辑配置内容。',
    },
    {
      anchor: 'navToggle',
      name: '左侧目录·展开/收起',
      group: '搜索',
      interaction: '点击切换目录栏展开(显示分类列表+搜索框)/收起(仅保留窄栏)。',
    },
    {
      anchor: 'navQuery',
      name: '左侧目录·搜索',
      group: '搜索',
      interaction: '文本框，按配置项标题模糊搜索，结果跨开关配置+系统参数两个Tab汇总展示。',
    },
    {
      anchor: 'navItem',
      name: '左侧目录·分类项',
      group: '搜索',
      interaction: '点击滚动定位到右侧对应分类卡片/分组，并高亮当前所在分类；随页面滚动自动同步高亮。',
    },
    {
      anchor: 'navResult',
      name: '左侧目录·搜索结果项',
      group: '搜索',
      interaction: '点击自动切到该项所在Tab，若在已折叠的开关卡片内会自动展开，滚动定位并短暂高亮该控件。',
    },
    {
      anchor: 'cardToggle',
      name: '开关卡片·折叠/展开',
      group: '操作',
      interaction: '点击卡片标题栏(▸/▾箭头)折叠/展开该分组下的全部开关项。',
    },
    {
      anchor: 'onSaveSwitchGroup',
      name: '保存（开关板块）',
      group: '操作',
      interaction: '每个开关卡片右上角独立按钮，点击弹二次确认(展示该组开关总数+已开启数)→确认后该组即生效落库。',
      limit: '若该组内有开关展开的嵌入参数为数值型且超出min/max，保存前先红框拦截+指名哪个参数配错，不弹确认框。',
    },
    {
      anchor: 'formSwitch',
      name: '开关（本体）',
      group: '操作',
      interaction: '每个开关项右侧的开关控件，切换即改本地表单值(需点所在卡片"保存"才真正提交)；标"含配置项"紫色徽标的开关，开启后卡片下方会展开对应参数配置区。',
    },
    {
      anchor: 'onSaveParamCategory',
      name: '保存（参数板块）',
      group: '操作',
      interaction: '每个参数分类标题栏右侧独立按钮，点击校验该分类内数值字段→通过则弹二次确认→确认后该分类即生效落库。',
    },
    {
      anchor: 'paramField',
      name: '参数字段（控件）',
      group: '操作',
      interaction: '按字段类型渲染对应控件(见下方字段说明)；数值类超范围时输入框标红框，保存时拦截并指名哪项配错。',
    },
    {
      anchor: 'opLogIcon',
      name: '操作记录',
      group: '操作',
      interaction: '每个开关名/参数名旁小图标，点击弹出该配置项最近的操作记录(时间/操作人/内容)，仅查看。',
    },
  ],
  fields: [
    { name: '整数（control=int）', def: '数字输入框，仅整数，受min/max范围限制。' },
    { name: '小数（control=float）', def: '数字输入框，支持小数(默认步进0.01)，受min/max范围限制。' },
    { name: '下拉（control=select）', def: '单选下拉框，选项固定枚举。' },
    { name: '多选（control=checkbox）', def: '多选复选组，独占整行。' },
    { name: '开关（control=switch）', def: '嵌入参数区内的开/关型子参数。' },
    { name: '文本（control=text，默认）', def: '单行文本输入框，未声明control类型的字段默认按文本处理。' },
    { name: '含配置项徽标', def: '标在开关名后的紫色"含配置项"徽标，表示该开关开启后会展开专属参数配置区。' },
    { name: '"开关"类目', def: '登录安全/验证码/充提/活动奖励等约58项功能开关，按业务分组归类展示。' },
    { name: '"系统参数"类目', def: '7大类参数分组(去重后)，每类下再分若干子分组，每个参数字段的具体含义见字段名旁悬浮说明(desc)。' },
  ],
};

export default manual;
