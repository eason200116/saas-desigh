// 期号管理（总控端 admin · lottery_issue）功能说明书。
// 锚定 src/views/lottery/issue/index.vue + data.ts + components/IssueDetailModal.vue 真实控件（R53 实证、不臆造）。
// 标准 ProCrudTable 列表页：5 搜索项 + 16 列 + 2 行操作（详情 / 取消注单，无顶部新增）+ 工具栏自动/手动刷新。
// 2026-07-24 Eason 确认删除「彩蛋加成/彩蛋金额/个人加成」3 列（原 19 列减至 16 列），R84 四处核实
// 筛选区/新增表单/编辑表单/详情弹窗均未引用，纯列表列专属字段，已随列一并从 fields 清单移除。
// 详情弹窗（IssueDetailModal，1000px）= 只展示「按币种投注统计」8 列表格
// （币种/投注人数/订单数/投注金额/手续费/返奖金额/平台盈利/返奖率），不再展示其它基本信息字段；
// 币种/投注人数/订单数三列用浅色圆角标签(n-tag)展示，其余纯文本（2026-07-23 Eason 二次确认还原此版）。
// 2026-07-23 二次改：自动刷新 UI 由「工具栏右上角下拉按钮」搬到「工具栏左上角开关 + 4 个间隔按钮」
// （今日/昨日等快捷日期按钮左边），手动刷新圆按钮原位不动，仍在右上角。

import type { PageManual } from '../types';

const manual: PageManual = {
  route: 'lottery_issue',
  title: '期号管理',
  overview:
    '总控端查看自研彩票各游戏的开奖期号，以及每期的投注 / 派奖 / 盈利统计。可查看期号详情、对未结算的期号取消注单（状态置为已取消）。列表含大量金额与统计列，金额类列左对齐（R61）。列表工具栏左上角（快捷日期按钮左边）提供自动刷新开关 + 间隔按钮，右上角提供手动刷新。',
  items: [
    // ============ 搜索区 ============
    {
      anchor: 'gameName',
      name: '游戏名称',
      group: '搜索',
      interaction: '下拉单选、可清空。',
      dataSource:
        '选项来自本页数据去重（data.ts GAME_NAME_OPTIONS = ALL_LIST 的游戏名称去重），当前 5 项：TRX Win / K3 快三 / 5D 彩 / Bingo18 / WinGo 1分钟。',
      logic: '按所选游戏名称精确匹配筛选期号。',
      limit: '选填。',
      edge: '不选 = 不按游戏名筛。',
    },
    {
      anchor: 'issueNo',
      name: '期号',
      group: '搜索',
      interaction: '文本输入、模糊匹配、可清空。',
      dataSource: '用户输入。',
      logic: '按期号模糊筛选。',
      limit: '选填；最多 50 字（inputProps searchKw）。',
      edge: '空 = 不按期号筛。',
    },
    {
      anchor: 'drawType',
      name: '开奖类型',
      group: '搜索',
      interaction: '下拉单选：正常开奖 / 赢率开奖，可清空。',
      dataSource: '本地枚举（正常开奖 = 1 / 赢率开奖 = 2）。',
      logic: '按开奖类型筛选。',
      limit: '选填。',
      edge: '不选 = 全部类型。',
    },
    {
      anchor: 'status',
      name: '状态（搜索）',
      group: '搜索',
      interaction: '下拉单选：已开奖 / 待开奖 / 已取消（三态），可清空。',
      dataSource: '本地枚举（已开奖 = 1 / 待开奖 = 0 / 已取消 = 2）。',
      logic: '按期号状态筛选。',
      limit: '选填。',
      edge: '不选 = 全部状态。',
    },
    {
      anchor: 'timeRange',
      name: '时间',
      group: '搜索',
      interaction: '日期时间范围选择（proDateRange，精确到时分秒）。',
      dataSource: '用户选择。',
      logic: '按时间范围筛选期号（data.ts issueGetPageList 按开始时间 startTime 做比较过滤）。',
      limit: '最多跨 90 天、不可选未来（maxDays 90 / allowFuture false）。',
      edge: '空 = 不按时间筛。',
      note: '本页表格顶部还带 ProCrudTable 内建快捷日期按钮（quick-date="timeRange" + allow-clear：今天/近7天/…/所有），点选即回填本时间区间。',
    },

    // ============ 关键列（状态列）============
    {
      anchor: 'col_status',
      name: '状态列',
      group: '列',
      interaction: '只读 Tag（圆角）：已开奖绿 / 待开奖橙 / 已取消灰，不可点。',
      dataSource: '行数据 status（0 待开奖 / 1 已开奖 / 2 已取消）。',
      logic: '仅展示期号状态；点行操作「取消注单」会把状态置为「已取消」。',
    },

    // ============ 操作（2 行操作，无顶部新增）============
    {
      anchor: 'act_detail',
      name: '行操作 · 详情',
      group: '操作',
      interaction:
        '点击打开期号详情弹窗（1000px，IssueDetailModal）查看该期「按币种投注统计」8 列表格（币种/投注人数/订单数/投注金额/手续费/返奖金额/平台盈利/返奖率）。',
      logic: '只读展示，不修改数据。',
    },
    {
      anchor: 'act_cancelBet',
      name: '行操作 · 取消注单',
      group: '操作',
      interaction: '点击弹二次确认框（dialog.warning：确认 / 取消）。',
      logic: '确认后调用 api.lottery.issueCancelBet，把该期号状态置为「已取消」并刷新列表。',
      edge: '仅「已取消」的行不显示此按钮（已开奖行仍可点，用户拍板）；真实取消范围（是否退款/回滚流水）待 5190 核实。',
    },

    // ============ 工具栏 · 自动刷新（左上角，2026-07-23 由下拉改为开关+间隔按钮） ============
    {
      anchor: 'autoRefreshControls',
      name: '工具栏 · 自动刷新（开关 + 间隔按钮）',
      group: '工具栏',
      interaction:
        '位于表格左上角、「今天/昨天」等快捷日期按钮左边：一个开关 + 4 个间隔按钮（15秒 / 30秒 / 1分钟 / 5分钟）。初始态开关灰色关闭且禁用点不动、4 按钮均未选中；点任一间隔按钮＝开关自动开启（蓝）并立即按该间隔开始刷新，该按钮变选中态（蓝框）；已开启时点其它间隔按钮＝直接切换间隔；已开启时点开关本身＝关闭刷新，视觉全部打回初始态（开关灰 + 禁用、4 按钮都不选中）。',
      dataSource:
        '前端定时器（每秒递减 remainSeconds，归零触发一次 reloadTable 并重置）；刷新间隔为用户点选的值（15/30/60/300 秒）。',
      logic:
        '点间隔按钮调用 handleSelectAutoRefreshInterval(seconds)：置 autoRefreshSeconds + autoRefreshing=true + 重启定时器；点开关调用 toggleAutoRefresh()：autoRefreshing=false + 清定时器；两者最终都按当前查询条件调用 reloadTable 重新拉取期号列表。',
      limit:
        '列表当前无数据时（如筛选后 0 条），开关与 4 个间隔按钮全部禁用，不可点击（listEmpty 联动）。',
      edge: '离开页面自动清除定时器（onUnmounted），不残留后台轮询；关闭后再次开启必须重新点选间隔（不记忆上次选中项，因关闭即回到初始态）。',
    },

    // ============ 工具栏 · 手动刷新（右上角，原位不动） ============
    {
      anchor: 'refreshControls',
      name: '工具栏 · 手动刷新',
      group: '工具栏',
      interaction: '表格右上角「手动刷新」圆形图标按钮，点击立即刷新当前列表（带 loading）。',
      dataSource: '按当前查询条件重新拉取期号列表。',
      logic:
        '调用 reloadTable；同时会重置自动刷新的倒计时（沿用当前选中的自动刷新间隔，不影响自动刷新的开关状态）。',
      edge: 'loading 中重复点击不重入（manualLoading 守卫）。',
    },
  ],

  // ============ 字段介绍 tab（列序照页面；仅列表列 + 定义）============
  fields: [
    { name: '游戏名称', def: '该期号所属的彩票游戏。' },
    { name: '期号', def: '一期开奖的唯一编号。' },
    { name: '币种', def: '该期投注 / 结算的币种。' },
    { name: '状态', def: '期号状态：已开奖 / 待开奖 / 已取消。' },
    { name: '开始时间', def: '该期开始接受投注的时间（按商户时区展示）。' },
    { name: '开奖时间', def: '该期开奖的时间。' },
    { name: '开奖结果', def: '该期开出的号码 / 结果。' },
    { name: '总和', def: '开奖结果的总和值（用于大小单双等玩法判定）。' },
    { name: '开奖类型', def: '正常开奖 / 赢率开奖。' },
    { name: '投注人数', def: '该期参与投注的去重用户数。' },
    { name: '订单数', def: '该期产生的投注订单总数。' },
    { name: '投注金额', def: '该期投注总额。' },
    { name: '手续费', def: '该期收取的手续费合计。' },
    { name: '总返奖金额', def: '该期派发给中奖玩家的返奖总额。' },
    { name: '平台盈利', def: '该期平台的盈亏（投注 − 返奖 等）。' },
    { name: '返奖率', def: '该期返奖金额占投注金额的百分比。' },
  ],
};

export default manual;
