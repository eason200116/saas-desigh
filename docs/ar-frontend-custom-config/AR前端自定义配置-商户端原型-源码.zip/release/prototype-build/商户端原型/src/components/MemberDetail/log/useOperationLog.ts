/**
 * 会员详情 - 「系统日志」Tab（原「操作记录」，已去子 Tab 合并为单列表）业务逻辑。
 *
 * 会员维度：展示「针对当前会员」的后台操作记录（会员管理模块），按会员 ID + 所属商户取数。
 * 列/搜索对齐系统管理-系统日志（src/views/system/platformLog）：操作路径(级联) + 关键字 + 操作时间；
 *   去商户维度（会员详情商户已锁定）；「详情」弹窗复用系统日志 Info.vue。
 *
 * 原型说明：取数走组件本地 mock（../data 的 api.v1platform.getMemberSysLogPageList），不发真实 HTTP。
 */
import { computed, h, ref } from 'vue';
import { useMessage, useModal } from 'naive-ui';
import { useI18n } from 'vue-i18n';
import { createActionColumn, type ProColumn, type ProCrudTableInstance } from '@/components';
import { useUser } from '@/hooks';
import { i18n, loadNamespace } from '@/i18n';
import { buildOperationPathOptions } from '@/views/system/platformLog/data';
import PlatformLogInfo from '@/views/system/platformLog/components/Info.vue';
import { api } from '../data';
import { useMemberContext, useQueryReload, MEMBER_DETAIL_CHILD_Z_INDEX } from '../useMemberContext';
import { useMemberTableTimezone } from '../useMemberTableTimezone';
import { createLogColumns, createLogSearchColumns } from './logConfig';

export function useOperationLog() {
  // 嵌入会员详情时当前路由 namespace 为 member，系统日志列/搜索使用 system.* 文案，
  // 此处按需拉取一次；loadNamespace 幂等，切语言时由 switchLocale 自动重新加载。
  void loadNamespace(i18n.global.locale.value, 'system');

  const { t, locale } = useI18n();
  const message = useMessage();
  const modal = useModal();
  const { memberId, tenantId: ctxTenantId, globalTimeRange } = useMemberContext();
  const { formatDateTimeStr, getTenantId } = useUser();

  const logTableRef = ref<ProCrudTableInstance | null>(null);
  // 操作时间 picker 按会员所属商户时区展示（而非全局默认商户）
  useMemberTableTimezone(logTableRef);

  // 操作路径级联选项（模块 → 操作页面 → 操作控件）；标签随语言译（固定小集合）
  const operationPathOptions = computed(() => buildOperationPathOptions(t, locale.value));

  // 搜索列（computed 以响应语言切换）
  const searchColumns = computed(() => createLogSearchColumns(t, operationPathOptions.value));

  // 表格列（computed 以响应语言切换）
  const columns = computed<ProColumn[]>(() => createLogColumns(t, locale.value));

  // 首屏默认：操作路径不预选
  const searchInitialValues = computed(() => ({ operationPath: null }));

  // 操作列：详情（复用系统日志 Info.vue）
  const actionColumn = createActionColumn(() => ({
    width: 90,
    actions: [
      {
        label: t('common.detail'),
        onClick: (row) => handleInfo(row),
      },
    ],
  }));

  function handleInfo(record: any) {
    modal.create({
      zIndex: MEMBER_DETAIL_CHILD_Z_INDEX,
      title: t('system.platformLog.detailTitle'),
      content: () => h(PlatformLogInfo, { record }),
      preset: 'card',
      bordered: false,
      closable: true,
      maskClosable: true,
      style: { width: '960px', maxWidth: 'calc(100vw - 32px)' },
    });
  }

  // 加载数据（会员维度：userId + 所属商户）
  async function loadData(params: any) {
    // modelKeys 展平后直接读分字段；若用户未选且无列默认值，fallback 到会员详情的全局时间范围
    let startTime = params?.startTime as string | undefined;
    let endTime = params?.endTime as string | undefined;
    if (!startTime || !endTime) {
      const fallback = globalTimeRange.value;
      if (Array.isArray(fallback) && fallback.length === 2) {
        startTime = formatDateTimeStr(fallback[0]);
        endTime = formatDateTimeStr(fallback[1]);
      }
    }

    try {
      const { data, result } = await api.v1platform.getMemberSysLogPageList({
        userId: Number(memberId.value),
        // 嵌入弹窗时强制使用会员所属商户
        tenantId: ctxTenantId.value ?? getTenantId(),
        operationPath: params?.operationPath ?? undefined,
        keyWords: String(params?.keyWords ?? '').trim() || undefined,
        startTime: startTime || undefined,
        endTime: endTime || undefined,
        pageNo: params?.pageNo ?? 1,
        pageSize: params?.pageSize ?? 10,
        orderBy: params?.sortOrder === 'ascend' ? 'Asc' : 'Desc',
      });
      if (!result) return { list: [], total: 0 };
      return { list: data?.list ?? [], total: data?.totalCount ?? 0 };
    } catch (e) {
      console.error('加载系统日志失败', e);
      return { list: [], total: 0 };
    }
  }

  useQueryReload('log', logTableRef);

  return {
    logTableRef,
    columns,
    searchColumns,
    actionColumn,
    searchInitialValues,
    loadData,
  };
}
