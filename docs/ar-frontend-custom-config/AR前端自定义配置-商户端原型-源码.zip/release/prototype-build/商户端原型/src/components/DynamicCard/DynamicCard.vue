<script setup lang="ts">
  import { computed, h } from 'vue';
  import { useI18n } from 'vue-i18n';
  import { NIcon } from 'naive-ui';
  import {
    EllipsisVertical,
    CreateOutline,
    TrashOutline,
    SwapHorizontalOutline,
  } from '@vicons/ionicons5';
  import { cardComponentMap } from './charts';
  import type { any, TimeSeriesDataPoint } from './types';

  interface Props {
    card: any;
    loading?: boolean;
    height?: string | number;
    showToggle?: boolean;
    showActions?: boolean;
  }

  const props = withDefaults(defineProps<Props>(), {
    loading: false,
    height: 220,
    showToggle: true,
    showActions: true,
  });

  const emit = defineEmits<{
    refresh: [cardId: string];
    edit: [cardId: string];
    delete: [cardId: string];
    move: [cardId: string];
  }>();

  const { t, te } = useI18n();

  /**
   * 解析卡片标题：按后端返回的 cardName 反查 i18n（系统预置卡片），未命中保留后端原文。
   * 适用范围：4 个流量大屏系统预置卡片（今日PV / 今日UV / 今日事件数 / PV/UV 趋势）。
   * 用户自建卡片仍走后端 name，不受影响。
   */
  const CARD_NAME_TO_I18N_KEY: Record<string, string> = {
    今日PV: 'analytics.trafficDashboard.cardNames.todayPv',
    今日UV: 'analytics.trafficDashboard.cardNames.todayUv',
    今日事件数: 'analytics.trafficDashboard.cardNames.todayEvents',
    'PV/UV 趋势': 'analytics.trafficDashboard.cardNames.pvUvTrend',
    'Google 自然流量': 'analytics.trafficDashboard.cardNames.googleOrganicTraffic',
    'Google Ads 流量': 'analytics.trafficDashboard.cardNames.googleAdsTraffic',
    广告点击趋势: 'analytics.trafficDashboard.cardNames.adClickTrend',
    落地页访问趋势: 'analytics.trafficDashboard.cardNames.landingPageTrend',
    渠道分布: 'analytics.trafficDashboard.cardNames.channelDistribution',
    广告计划分布: 'analytics.trafficDashboard.cardNames.adPlanDistribution',
    创意素材分布: 'analytics.trafficDashboard.cardNames.creativeDistribution',
    推广转化漏斗: 'analytics.trafficDashboard.cardNames.promotionFunnel',
    次日留存: 'analytics.trafficDashboard.cardNames.day1Retention',
    '3日留存': 'analytics.trafficDashboard.cardNames.day3Retention',
    '7日留存': 'analytics.trafficDashboard.cardNames.day7Retention',
    '页面访问 TOP10': 'analytics.trafficDashboard.cardNames.pageViewTop10',
    页面点击占比: 'analytics.trafficDashboard.cardNames.pageClickRate',
    平台分布: 'analytics.trafficDashboard.cardNames.platformDistribution',
    今日注册人数: 'analytics.trafficDashboard.cardNames.todayRegisterCount',
    今日首充人数: 'analytics.trafficDashboard.cardNames.todayFirstDepositCount',
    今日登录人数: 'analytics.trafficDashboard.cardNames.todayLoginCount',
    今日首充金额: 'analytics.trafficDashboard.cardNames.todayFirstDepositAmount',
    注册趋势: 'analytics.trafficDashboard.cardNames.registerTrend',
    首充趋势: 'analytics.trafficDashboard.cardNames.firstDepositTrend',
    登录趋势: 'analytics.trafficDashboard.cardNames.loginTrend',
    '注册→首充漏斗': 'analytics.trafficDashboard.cardNames.registerToFirstDepositFunnel',
  };
  const resolveCardName = (cardName: string) => {
    const key = CARD_NAME_TO_I18N_KEY[cardName];
    return key && te(key) ? t(key) : cardName;
  };

  // 获取对应的图表组件
  const chartComponent = computed(() => {
    const cardType = props.card.type;
    return cardComponentMap[cardType] || null;
  });

  // 操作菜单选项
  const actionOptions = computed(() => [
    {
      label: t('common.edit'),
      key: 'edit',
      icon: () => h(NIcon, null, { default: () => h(CreateOutline) }),
    },
    {
      label: t('common.moveTo'),
      key: 'move',
      icon: () => h(NIcon, null, { default: () => h(SwapHorizontalOutline) }),
    },
    {
      type: 'divider',
      key: 'd1',
    },
    {
      label: t('common.delete'),
      key: 'delete',
      icon: () => h(NIcon, null, { default: () => h(TrashOutline) }),
    },
  ]);

  // 处理操作菜单选择
  const handleActionSelect = (key: string) => {
    switch (key) {
      case 'edit':
        emit('edit', props.card.cardId);
        break;
      case 'delete':
        emit('delete', props.card.cardId);
        break;
      case 'move':
        emit('move', props.card.cardId);
        break;
    }
  };

  // 判断是否为数值卡片
  const isNumberCard = computed(() => props.card.type === 'number');

  // 后端 any.count 被生成器误转为 Record<string,any>，运行时实际是 number
  function toCount(value: unknown): number {
    return typeof value === 'number' ? value : 0;
  }

  // 从 statisticList 转换时序数据：第 1 个系列填 value，第 2 个系列填 value2
  const timeSeriesData = computed<TimeSeriesDataPoint[]>(() => {
    const statisticList = props.card.statisticList || [];
    if (statisticList.length === 0) return [];

    const firstSeries = statisticList[0]?.calcData || [];
    const secondSeries = statisticList[1]?.calcData || [];

    return firstSeries.map((item, index) => ({
      time: item.happenDate,
      value: toCount(item.count),
      value2: secondSeries[index] ? toCount(secondSeries[index].count) : undefined,
    }));
  });

  // 饼图数据：每个 statisticList item 是一个分类，name=calcName / value=calcTotail
  const distributionData = computed(() => {
    const statisticList = props.card.statisticList || [];
    return statisticList.map((s, index) => ({
      name: s.calcName || `系列${index + 1}`,
      value: typeof s.calcTotail === 'number' ? s.calcTotail : 0,
    }));
  });

  // 路径（桑基）数据：后端约定 calcData[0..n] 中 happenDate 编码 source>target，
  // 暂时无规范字段，先把 statisticList 透传给 PathChartCard 自己消化
  const pathData = computed(() => props.card.statisticList || []);

  // 计算传递给子组件的 props
  const chartProps = computed<Record<string, unknown>>(() => {
    const cardType = props.card.type;
    const baseProps = {
      title: resolveCardName(props.card.cardName),
      height: props.height,
      loading: props.loading,
      showToggle: props.showToggle,
    };

    // 数值卡片特殊处理
    if (cardType === 'number') {
      return {
        ...baseProps,
        statisticList: props.card.statisticList,
      };
    }

    // 漏斗卡片特殊处理
    if (cardType === 'funnel') {
      // 从 config.calcRule 获取步骤名称
      const calcRule = props.card.config?.calcRule || [];
      const calcData = props.card.statisticList?.[0]?.calcData || [];
      const data = calcData.map((item, index) => ({
        name:
          calcRule[index]?.calcName ||
          t('analytics.trafficDashboard.funnel.defaultStep', { count: index + 1 }),
        count: toCount(item.count),
        percentage: item.percentage,
      }));

      return {
        ...baseProps,
        data,
        config: props.card.config,
        conversionPeriod: props.card.conversionCycle
          ? t('analytics.trafficDashboard.funnel.daysWithCount', {
              count: props.card.conversionCycle,
            })
          : undefined,
        showFunnelToggle: props.showToggle,
      };
    }

    // 饼图：data 形状是 {name, value}，不能复用 timeSeriesData
    if (cardType === 'pie') {
      return {
        ...baseProps,
        data: distributionData.value,
        config: props.card.config,
      };
    }

    // 路径图：sankey 数据由子组件按 statisticList 自行解析
    if (cardType === 'path') {
      return {
        ...baseProps,
        data: pathData.value,
        config: props.card.config,
      };
    }

    // 其他时序型卡片（bar / line / bar_line / stacked / table / retention）
    return {
      ...baseProps,
      data: timeSeriesData.value,
      config: props.card.config,
      chartType: cardType,
    };
  });
</script>

<template>
  <div class="dynamic-card-wrapper" :class="{ 'dynamic-card-wrapper--number': isNumberCard }">
    <!-- 动态组件渲染 -->
    <component :is="chartComponent" v-if="chartComponent" v-bind="chartProps" />

    <!-- 操作菜单 -->
    <n-dropdown
      v-if="showActions"
      trigger="click"
      :options="actionOptions"
      @select="handleActionSelect"
    >
      <n-button quaternary size="tiny" class="dynamic-card-action">
        <template #icon>
          <n-icon><EllipsisVertical /></n-icon>
        </template>
      </n-button>
    </n-dropdown>
  </div>
</template>

<script lang="ts">
  export default {
    name: 'DynamicCard',
  };
</script>

<style lang="less" scoped>
  .dynamic-card-wrapper {
    position: relative;
    // 高度交给内部 BaseChartCard / TableCard / NumberCard 各自的 wrapper 决定，
    // 这里强制 100% 反而会在 n-gi 没有显式高度时塌成 0
    height: auto;

    .dynamic-card-action {
      position: absolute;
      top: 12px;
      right: 16px;
      opacity: 0;
      transition: opacity 0.2s;
      z-index: 10;
    }

    &:hover .dynamic-card-action {
      opacity: 1;
    }

    &--number {
      .dynamic-card-action {
        top: 12px;
        right: 16px;
      }
    }
  }
</style>
