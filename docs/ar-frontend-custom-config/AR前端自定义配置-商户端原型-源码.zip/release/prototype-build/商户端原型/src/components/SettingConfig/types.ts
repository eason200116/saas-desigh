/**
 * SettingConfig 组件类型定义
 * @description 通用配置组件，支持 AST 提取
 */

/** 控件类型 */
export type ControlType = 'switch' | 'number' | 'range' | 'select' | 'text';

/** 校验规则 */
export interface SettingRule {
  min?: number;
  max?: number;
  integer?: boolean;
  required?: boolean;
  message?: string;
}

/** 配置项定义（静态，AST 可提取） */
export interface SettingItemConfig {
  /** settingKey */
  key: string;
  /** 控件类型 */
  type: ControlType;
  /** 显示标签 */
  label: string;
  /** 描述文字 */
  desc?: string;
  /** 后缀文字（输入框内） */
  suffix?: string;
  /** 单位文字（显示在控件后，仅 number/range 生效） */
  unit?: string;
  /** 校验规则 */
  rules?: SettingRule[];
  /** 选项（select 用，字典 key 或静态数组） */
  options?: string | Array<{ label: string; value: string | number }>;
  /** 控件额外属性 */
  props?: Record<string, unknown>;
}

/** 后端返回的配置值结构 */
export interface SettingValue {
  settingKey: string;
  settingName?: string;
  value1: string | number | null;
  value2?: string | number | null;
}

/** 日志记录 */
export interface SettingLogRecord {
  updateTime: string;
  operatorName: string;
  updateContent: string;
}

/** API 配置 */
export interface SettingApiConfig {
  /** 获取配置 */
  get: () => Promise<{ data: Record<string, SettingValue> }>;
  /** 更新配置 */
  update: (params: {
    settingKey: string;
    value1: string;
    value2?: string;
  }) => Promise<{ code: number }>;
  /** 获取日志（可选，默认使用 api.operations.getListUpdateLog） */
  log?: (params: { settingKey: string }) => Promise<{ data: SettingLogRecord[] }>;
}

/** 组件 Props */
export interface SettingConfigProps {
  /** 配置项列表 */
  items: SettingItemConfig[];
  /** API 配置 */
  api: SettingApiConfig;
  /** 表单数据（外部传入时使用） */
  modelValue?: Record<string, SettingValue>;
  /** 是否自动加载 */
  autoLoad?: boolean;
  /** 每行显示的配置项数量，默认 1 */
  columns?: 1 | 2 | 3;
}

/** 组件暴露的方法 */
export interface SettingConfigExpose {
  /** 重新加载数据 */
  reload: () => Promise<void>;
  /** 获取表单数据 */
  getFormData: () => Record<string, SettingValue>;
}
