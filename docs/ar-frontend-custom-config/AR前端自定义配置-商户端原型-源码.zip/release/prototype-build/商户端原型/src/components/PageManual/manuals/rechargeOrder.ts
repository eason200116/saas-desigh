// 充值订单管理（商户端 tenant · finance_recharge_order_page）功能说明书。
// 锚定 src/views/finance/rechargeOrder/index.vue 容器 + 4 个子 Tab（thirdPartyPending 三方待入款 /
// bankUpiDeposit 本地待入款 / depositRecords 全部入款记录 / autoSmsRecords 直充短信）各自的
// index.vue/data.ts/form.ts/use*Page.ts 真实控件（R53 实证、不臆造）。容器只是 ProTabs 壳（读
// route.meta.tabs），4 个子 Tab 各自独立的搜索表单 + 列表 + 操作，彼此差异较大（不是同构重复的 CRUD
// 模式，例如「直充短信」全页只读无操作列、「本地待入款」独有自动刷新+批量取消+行多选、「全部入款记录」
// 是字段最全的主记录视图），故本说明书 anchor 按 Tab 前缀区分，不跨 Tab 共用——区别于 memberBankCard
// 那种 5 Tab 高度同构、大量字段可共享 anchor 的情况。
//
// 2026-07-21 核实代码后如实记录 4 处真实问题（均未修复，只记录）：
// ①「直充短信」Tab 会员ID 列样式做成可点蓝字（cursor-pointer + 蓝字 + hover 下划线，与其余 3 个 Tab
//   视觉一致）但完全没有绑定 onClick（useAutoSmsRecordsPage.ts 该列 render 只有一个裸 h('a',...)），
//   点击没有任何反应；对照同页其余 3 个 Tab 的会员ID 列都真实调用 openMemberDetail 跳转会员详情弹窗。
// ②「直充短信」Tab 商户搜索项 formItemProps 配了 showRequireMark 红星必选提示，但 componentProps
//   显式传了 clearable:true——按 ProTenantSelect.vue 的实现（n-select 先写死 :clearable="false"，
//   之后 v-bind="$attrs" 展开外部 componentProps，Vue 同名属性按模板源码顺序后者覆盖前者），外部传入
//   的 clearable:true 会覆盖架构默认的不可清空锁，导致本 Tab 商户下拉理论上可以被清空，与「视觉必选」
//   的红星提示矛盾；其余 3 个 Tab 均未在 componentProps 里传 clearable，维持不可清空。
// ③「本地待入款」Tab 的 useBankUpiDepositPage.ts 完整实现并导出了 handleSearch（立即刷新表格+重置
//   自动刷新倒计时），但 index.vue 的解构列表里没有取用它，页面模板上也没有任何按钮绑定它——是一个
//   实现完整却未接入任何 UI 入口的孤立函数（与①相反：这处是"逻辑有、UI没接"）。
// ④「全部入款记录」Tab 与「三方待入款」/「本地待入款」两个 Tab 的"确认订单"类按钮显示条件不一致：
//   「全部入款记录」用 canConfirmRechargeOrder（rechargeState===0 待支付 或 ===2 支付失败 才显示，
//   已充值(1)时隐藏，业务上说得通——已充值订单没必要再补单）；「三方待入款」「本地待入款」两个 Tab
//   都是更宽松的 rechargeState!==2（待支付、已充值都显示，仅已取消才隐藏）——即同样"已充值"状态的
//   订单，后两个 Tab 仍会显示确认/确认订单按钮可再次点击，「全部入款记录」则不会，如实记录这一显示
//   条件差异，不确定是否有意为之。
// 另：shared/RechargeOrderQuickDateToolbar.vue + shared/useRechargeQuickDate.ts 经项目全文 grep
// 确认是死代码——除彼此互相引用外，没有任何一个 Tab 的 index.vue 导入过它们（4 个 Tab 均直接用
// ProCrudTable 内置的 quick-date prop 走快捷日期，未使用这套独立工具栏组件），不产生任何真实 DOM，
// 故不建立 manual item，仅在此处如实记录。

import type { PageManual } from '../types';

const manual: PageManual = {
  route: 'finance_recharge_order_page',
  title: '充值订单管理',
  overview:
    '商户端「财务管理 › 充值订单管理」页，容器是一个 4 标签页壳（三方待入款 / 本地待入款 / 全部入款记录 / 直充短信，默认展示"三方待入款"），4 个 Tab 各自独立的搜索表单 + 列表，彼此结构差异较大：「三方待入款」「本地待入款」聚焦当前待处理订单（本地待入款额外支持自动刷新、批量取消、图片凭证核对），「全部入款记录」是全量历史订单的主记录视图（搜索项和列数量全页最多），「直充短信」是全页唯一的只读 Tab（无操作列），展示银行短信与充值订单的自动匹配结果。顶部「消息中心」弹窗可对「三方待入款」「本地待入款」两个 Tab 按商户深链跳转并预筛选"待支付"状态（另 2 个 Tab 没有这个入口）。2026-07-21 核实代码后如实记录 4 处真实问题（详见文件头注释）：①「直充短信」会员ID 列样式可点但无 onClick；②「直充短信」商户搜索项红星必选与 componentProps 显式 clearable:true 矛盾，理论上可清空；③「本地待入款」的 handleSearch 函数实现完整但未接入任何按钮；④「全部入款记录」与另外两个待处理 Tab 的"确认订单"类按钮显示条件不一致（已充值状态下是否还显示按钮）。上述 4 处已于 2026-07-22 逐个修复：①接入 useMemberDetailModal().openMemberDetail 跳转会员详情，与其余 3 个 Tab 对齐；②去掉 componentProps 里的 clearable:true 覆盖，恢复不可清空；③在 index.vue 工具栏补一个"查询"按钮调用 handleSearch（核实发现配套 i18n key 早已备好但未被引用，判定为遗漏非废弃逻辑）——此项已于 2026-07-24 按开发站口径回退：移除该"查询"按钮，本地待入款改为纯自动刷新 +「手动刷新」提示，handleSearch 仅保留在 composable 内不接入 UI；④「三方待入款」「本地待入款」两个 Tab 的"确认订单"/"确认"按钮改为复用 canConfirmRechargeOrder，与「全部入款记录」统一为"已充值即隐藏"。详见 ChangeLogFab v1.9.147。另有 shared 目录下 2 个死代码文件（RechargeOrderQuickDateToolbar.vue + useRechargeQuickDate.ts，未被任何 Tab 引用），因无真实 DOM 不建 item，仅记录，与上述 4 处修复无关、未改动。',
  items: [
    // ============ 容器：Tab 切换 ============
    {
      anchor: 'tab_switch',
      name: '4 个子页 Tab 切换（三方待入款 / 本地待入款 / 全部入款记录 / 直充短信）',
      group: '操作',
      interaction:
        '点顶部 Tab 切换，4 个 Tab 各自独立的搜索表单 + 列表（+ 部分 Tab 独有的操作），不是同一张表换维度。',
      dataSource:
        '从当前路由 meta.tabs 读取配置（useRouteTabs），默认展示"三方待入款"（useRouteTabs("thirdPartyPending")）。',
      logic:
        '4 个 Tab 均 keepAlive（route.meta.keepAlive=true 且各 tab 未单独设 keepAlive:false），切走后状态不丢（含分页/筛选/自动刷新状态）；当前 Tab 同步进 URL query，可直接带 query 定位到指定 Tab。',
      note: '容器组件 src/views/finance/rechargeOrder/index.vue 本身只是壳（读 route.meta.tabs 渲染 ProTabs），不含独立业务控件；顶部「消息中心」弹窗（src/layout/components/Header/MessageBadge.vue）针对"三方待入款"/"本地待入款"两个 Tab 有专门的按商户跳转入口（带 tenantId + rechargeState=0 预筛选），该入口属于全局 Header 组件，不在本页范围内。',
    },

    // ============ Tab①三方待入款：搜索 ============
    {
      anchor: 'tpp_tenant',
      name: '商户（三方待入款 Tab，搜索区）',
      group: '搜索',
      interaction: '下拉单选（tenantSelect，架构级不可清空）。',
      dataSource: '全站商户列表。',
      logic:
        '按选中商户过滤列表；切换商户会清空"通道ID/名称"筛选值，并联动重新拉取该商户下的通道下拉选项。',
      limit: '搜索表单项配了 showRequireMark 红星提示 + 组件本身不可清空。',
    },
    {
      anchor: 'tpp_memberId',
      name: '会员ID（三方待入款 Tab，搜索区）',
      group: '搜索',
      interaction: '文本输入。',
      dataSource: '用户输入。',
      logic: '按会员ID精确匹配过滤。',
      limit: '选填；仅允许输入数字字符，最长 9 位（INPUT_PRESETS.intNum）。',
    },
    {
      anchor: 'tpp_orderNo',
      name: '订单号（三方待入款 Tab，搜索区）',
      group: '搜索',
      interaction: '文本输入。',
      dataSource: '用户输入。',
      logic: '按订单号子串匹配（includes）过滤。',
      limit: '选填；最长 50 字。',
    },
    {
      anchor: 'tpp_channel',
      name: '通道ID/名称（三方待入款 Tab，搜索区）',
      group: '搜索',
      interaction: '下拉单选可搜索可清空，依赖已选商户。',
      dataSource:
        '按当前商户拉取通道原始列表后，过滤掉展示名（label）里含"local"字样的选项——即本 Tab 只列三方通道，不含本地通道。',
      logic: '按选中的通道关系ID精确过滤列表。',
      edge: '商户未选时选项为空（依赖商户）。',
    },
    {
      anchor: 'tpp_rechargeState',
      name: '订单状态（三方待入款 Tab，搜索区）',
      group: '搜索',
      interaction: '单选下拉，可清空。仅暴露「待支付 / 已取消」两态。',
      dataSource: '从字典 rechargeStateList 过滤 value=0/2 得到（待入款场景只关注这两态）。',
      logic: '对齐开发站新增（原型此前回填/列/请求已支持，仅缺此搜索控件）。',
      edge: '留空=待支付+已取消全部。',
    },
    {
      anchor: 'tpp_timeRange',
      name: '下单时间（三方待入款 Tab，搜索区）',
      group: '搜索',
      interaction:
        '日期时间区间选择（proDateRange），面板旁另有独立快捷日期按钮组（quick-date="timeRange"，与面板内快捷项二选一，不重复）。',
      dataSource: '默认快捷项"今天"；最大可选跨度 1095 天（3 年）。',
      limit: '选填，可清空。',
    },
    {
      anchor: 'tpp_reset',
      name: '重置（三方待入款 Tab，搜索表单）',
      group: '操作',
      interaction: '点击搜索表单「重置」按钮。',
      logic:
        '除清空搜索表单各字段外，额外调用 updateSearchTenantId 把内部 searchTenantId 状态同步恢复为默认商户，让"通道ID/名称"下拉的可选项跟着恢复到默认商户对应的选项集合（handleReset 显式处理，非框架自动行为）。',
    },

    // ============ Tab①三方待入款：列 ============
    {
      anchor: 'tpp_col_tenant',
      name: '商户列（三方待入款 Tab）',
      group: '列',
      interaction: '标签展示，不可点。',
      dataSource:
        '接口不回显 tenantId，前端按"本次请求实际提交的商户"回填展示（lastRequestTenantId）。',
    },
    {
      anchor: 'tpp_col_userId',
      name: '会员ID列（三方待入款 Tab）',
      group: '列',
      interaction: '数字以可点击蓝字链接形式展示（跳转类控件）。',
      dataSource: '行数据 userId + tenantId。',
      logic:
        '点击调用 openMemberDetail(userId, tenantId) 打开会员详情弹窗（全站统一的会员ID可点规范）。',
    },
    {
      anchor: 'tpp_col_memberInfo',
      name: '会员信息列（三方待入款 Tab）',
      group: '列',
      interaction: '纯展示三行：充值等级 / VIP等级 / 会员状态（正常绿色、禁用红色），不可点。',
      dataSource:
        '与「本地待入款」「全部入款记录」两个 Tab 共用同一渲染函数 renderMemberInfoBlock；会员状态查公共字典 enableStateList。',
    },
    {
      anchor: 'tpp_col_orderNo',
      name: '订单号列（三方待入款 Tab）',
      group: '列',
      interaction: '纯文本展示，超长省略并 tooltip 提示，不可点。',
      dataSource: '行数据 orderNo。',
    },
    {
      anchor: 'tpp_col_customerInfo',
      name: '客户入款信息列（三方待入款 Tab）',
      group: '列',
      interaction: '纯展示持卡人 + 银行卡号（长号 hover 出 tooltip 全文），不可点。',
      dataSource:
        '解析行数据 customerInfo/receiveInfo JSON 取持卡人与卡号，取不到则退回 customAccountName/customAccountNo/receiveAccountNo。',
      edge: '本 Tab 是独立内联解析（parseCustomerInfo/parseReceiveInfo 两个局部函数），未走「本地待入款」「全部入款记录」共用的 shared/customerInfoColumn.ts 渲染函数——三处呈现效果相近但代码实现不是同一份，如实记录这一实现层差异（非用户可见的行为缺陷）。',
    },
    {
      anchor: 'tpp_col_channelName',
      name: '通道名称列（三方待入款 Tab）',
      group: '列',
      interaction: '纯文本"ID → 通道名"格式展示，不可点。',
      dataSource:
        '行数据 tenantChannelId，按字典 tenantPayChannelList 反查 customName；未命中显示"--"。',
      note: '本列只有"通道ID→名称"一种呈现，没有「本地待入款」「全部入款记录」那种"本地收款信息 / 三方通道"二选一分支——因三方待入款场景不涉及本地收款信息。',
    },
    {
      anchor: 'tpp_col_amount',
      name: '充值发起金额列（三方待入款 Tab）',
      group: '列',
      interaction: '纯展示，可按该列排序（点表头）。',
      dataSource:
        '行数据 amount；USDT 大类订单（按 sysCategoryId 或通道名含"usdt"判定）额外展示兑换比例与 USDT 数量两行。',
    },
    {
      anchor: 'tpp_col_state',
      name: '订单状态列（三方待入款 Tab）',
      group: '列',
      interaction: '彩色标签展示，不可点。',
      dataSource:
        '行数据 rechargeState（0待支付黄/1已充值绿/2支付失败红），与搜索下拉同源字典 rechargeStateList。',
    },
    {
      anchor: 'tpp_col_createTime',
      name: '下单时间列（三方待入款 Tab）',
      group: '列',
      interaction: '纯展示，按所属商户时区格式化，不可点。',
      dataSource: '行数据 createTime。',
    },

    // ============ Tab①三方待入款：汇总条 ============
    {
      anchor: 'tpp_summaryBar',
      name: '汇总条（三方待入款 Tab，表格下方）',
      group: '其它',
      interaction: '纯展示两行统计，不可点、不可交互。',
      dataSource:
        '"页面总计"=当前这一页已加载数据的客户端聚合（buildPageSummary）；"总计"=接口返回的 summary 字段（对全部筛选结果的服务端聚合），二者概念不同、不是同一个数。',
      logic:
        '统计行的"金额："标签会用 JS 测量"充值发起金额"表头单元格的横向位置，动态对齐到该列正下方（amountColumnLeft，随语言切换/窗口缩放重新测量）。',
    },

    // ============ Tab①三方待入款：操作 ============
    {
      anchor: 'tpp_confirmOrder',
      name: '确认订单（三方待入款 Tab，行操作按钮）',
      group: '操作',
      interaction:
        '点行内"确认订单"打开补单弹窗，填"补单金额"（默认等于发起金额，不可超过发起金额）+ 备注后确认。',
      dataSource: '与「全部入款记录」Tab 共用同一套弹窗组件 useConfirmRechargeOrderModal。',
      logic: '确认后调用补单接口，成功后关闭弹窗、提示成功并刷新列表。',
      limit: '补单金额必填且不能大于发起金额；备注必填。',
      edge: '2026-07-22 已修复：本按钮显示条件已改为复用 useRechargeStateRenderer 导出的 canConfirmRechargeOrder（仅待支付/支付失败才显示，已充值时隐藏），与「全部入款记录」Tab 统一（2026-07-21 曾如实记录为 rechargeState!==2 的更宽松判断、与「全部入款记录」不一致，详见 ChangeLogFab v1.9.147）。',
    },

    // ============ Tab②本地待入款：搜索 ============
    {
      anchor: 'bud_tenant',
      name: '商户（本地待入款 Tab，搜索区）',
      group: '搜索',
      interaction: '下拉单选（tenantSelect，架构级不可清空）。',
      dataSource: '全站商户列表。',
      logic:
        '按选中商户过滤列表；切换商户会清空"充值大类"筛选值，并联动重新拉取该商户下的充值大类下拉选项。',
      limit: '搜索表单项配了 showRequireMark 红星提示 + 组件本身不可清空。',
    },
    {
      anchor: 'bud_memberId',
      name: '会员ID（本地待入款 Tab，搜索区）',
      group: '搜索',
      interaction: '文本输入。',
      dataSource: '用户输入。',
      logic: '按会员ID精确匹配过滤。',
      limit: '选填；仅允许输入数字字符，最长 9 位。',
    },
    {
      anchor: 'bud_orderNo',
      name: '订单号（本地待入款 Tab，搜索区）',
      group: '搜索',
      interaction: '文本输入。',
      dataSource: '用户输入。',
      limit: '选填；最长 50 字。',
    },
    {
      anchor: 'bud_cardType',
      name: '充值大类（本地待入款 Tab，搜索区）',
      group: '搜索',
      interaction: '下拉单选可搜索可清空，依赖已选商户。',
      dataSource:
        '按当前商户拉取全部充值大类后，只保留展示名含"local"字样的选项——即本 Tab 只列本地大类，不含三方大类。',
      logic: '按选中的大类ID精确过滤。',
      edge: '商户未选时选项为空。',
    },
    {
      anchor: 'bud_plainFilters',
      name: '收款卡号 / 客户入款卡号 / TransID（本地待入款 Tab，搜索区）',
      group: '搜索',
      interaction: '均为文本输入框，可正常输入、清空。',
      dataSource: '用户输入。',
      logic:
        '分别按收款账号（receiveAccountNo）/客户入款账号（customAccountNo）/交易流水号（transactionId）子串匹配过滤，三项互相独立、可同时使用。',
      limit: '均选填；无预设长度限制以外的特殊格式校验（普通 clearable 文本框）。',
    },
    {
      anchor: 'bud_memberLevel',
      name: '会员充值等级（本地待入款 Tab，搜索区）',
      group: '搜索',
      interaction: '下拉单选可搜索可清空。',
      dataSource: '取自字典 vipLevelList。',
      logic: '按选中等级精确过滤。',
    },
    {
      anchor: 'bud_rechargeState',
      name: '订单状态（本地待入款 Tab，搜索区）',
      group: '搜索',
      interaction: '单选下拉，可清空。仅暴露「待支付 / 已取消」两态。',
      dataSource: '从字典 rechargeStateList 过滤 value=0/2 得到。',
      logic: '对齐开发站新增（原型此前缺此搜索项）。',
      edge: '留空=待支付+已取消全部。',
    },
    {
      anchor: 'bud_timeRange',
      name: '下单时间（本地待入款 Tab，搜索区）',
      group: '搜索',
      interaction: '日期时间区间选择，另有独立快捷日期按钮组（quick-date="timeRange"）。',
      dataSource: '默认快捷项"今天"；最大可选跨度 1095 天。',
      limit: '选填，可清空。',
    },
    {
      anchor: 'bud_reset',
      name: '重置（本地待入款 Tab，搜索表单）',
      group: '操作',
      interaction: '点击搜索表单「重置」按钮。',
      logic:
        '除清空搜索表单各字段外，额外调用 updateSearchTenantId 把商户恢复为默认商户，联动恢复"充值大类"下拉为该商户对应的本地大类选项集合。',
    },

    // ============ Tab②本地待入款：列 ============
    {
      anchor: 'bud_col_tenant',
      name: '商户列（本地待入款 Tab）',
      group: '列',
      interaction: '标签展示，不可点。',
      dataSource: '接口不回显 tenantId，前端按本次请求实际提交的商户回填展示。',
    },
    {
      anchor: 'bud_col_userId',
      name: '会员ID列（本地待入款 Tab）',
      group: '列',
      interaction: '数字以可点击蓝字链接形式展示（跳转类控件）。',
      dataSource: '行数据 userId + tenantId。',
      logic: '点击调用 openMemberDetail(userId, tenantId) 打开会员详情弹窗。',
    },
    {
      anchor: 'bud_col_memberInfo',
      name: '会员信息列（本地待入款 Tab）',
      group: '列',
      interaction: '纯展示三行：充值等级 / VIP等级 / 会员状态，不可点。',
      dataSource: '与「三方待入款」「全部入款记录」共用同一渲染函数 renderMemberInfoBlock。',
    },
    {
      anchor: 'bud_col_orderNo',
      name: '订单号列（本地待入款 Tab）',
      group: '列',
      interaction: '纯文本展示，不可点。',
      dataSource: '行数据 orderNo。',
    },
    {
      anchor: 'bud_col_customerInfo',
      name: '客户入款信息列（本地待入款 Tab）',
      group: '列',
      interaction: '纯展示持卡人 + 银行卡号（长号 hover 出 tooltip 全文），不可点。',
      dataSource:
        '与「全部入款记录」共用同一渲染函数 renderCustomerInfo（shared/customerInfoColumn.ts）。',
    },
    {
      anchor: 'bud_col_transferProof',
      name: '转账凭证列（本地待入款 Tab）',
      group: '列',
      interaction:
        '缩略图展示（64×48），可点击预览大图（NImage previewDisabled:false）；未上传时显示"未上传"文字占位。',
      dataSource: '行数据 transferProofUrl。',
      edge: '图片加载失败时用内嵌 SVG 兜底占位图（文字"加载失败"），不会显示浏览器默认裂图图标。',
    },
    {
      anchor: 'bud_col_receiveInfo',
      name: '本地收款信息/通道名称列（本地待入款 Tab）',
      group: '列',
      interaction: '纯展示多行文本，不可点；按 receiveInfo 是否含本地账户信息二选一分支展示。',
      dataSource:
        '与「全部入款记录」共用同一渲染函数 renderReceiveInfoOrChannel：本地收款分支展示银行名称/持卡人/卡号/IFSCCode（EWallet、本地USDT 两个大类隐藏 IFSCCode 改强制展示 TransactionID）；否则展示三方通道分支（通道ID→名称）。',
    },
    {
      anchor: 'bud_col_rechargeCategory',
      name: '充值大类列（本地待入款 Tab）',
      group: '列',
      interaction: '纯文本展示，不可点。',
      dataSource: '行数据 rechargeCategoryName。',
    },
    {
      anchor: 'bud_col_amount',
      name: '充值发起金额列（本地待入款 Tab）',
      group: '列',
      interaction: '纯展示，可按该列排序。',
      dataSource: '行数据 amount；USDT 大类订单额外展示兑换比例与 USDT 数量两行。',
    },
    {
      anchor: 'bud_col_state',
      name: '订单状态列（本地待入款 Tab）',
      group: '列',
      interaction: '彩色标签展示，不可点。',
      dataSource: '行数据 rechargeState，与搜索下拉同源字典。',
    },
    {
      anchor: 'bud_col_orderTime',
      name: '下单时间列（本地待入款 Tab）',
      group: '列',
      interaction: '纯展示，按所属商户时区格式化，不可点。',
      dataSource: '行数据 createTime。',
    },

    // ============ Tab②本地待入款：汇总条 ============
    {
      anchor: 'bud_summaryBar',
      name: '汇总条（本地待入款 Tab，表格下方）',
      group: '其它',
      interaction: '纯展示两行统计，不可点、不可交互。',
      dataSource:
        '"页面总计"=当前页客户端聚合；"总计"=接口返回的服务端聚合（含总订单数/总金额/USDT 数量）。',
    },

    // ============ Tab②本地待入款：操作 ============
    {
      anchor: 'bud_pause',
      name: '暂停（本地待入款 Tab，表格左上角按钮）',
      group: '操作',
      interaction: '点击后关闭本页自动刷新；按钮在"已暂停"状态下禁用。',
      dataSource:
        '本 Tab 默认开启 10 秒自动刷新倒计时（进入页面即启动），旁边同步展示"N 秒后开始刷新"文字。',
      logic: '暂停后倒计时停止，需点"继续"重新开始。',
    },
    {
      anchor: 'bud_resume',
      name: '继续（本地待入款 Tab，表格左上角按钮）',
      group: '操作',
      interaction:
        '点击后从 10 秒重新开始自动刷新倒计时；按钮在"自动刷新中"状态下禁用（与"暂停"按钮互斥）。',
      logic:
        '倒计时归零时触发一次表格 reload，随后重新开始下一轮 10 秒倒计时；页面切走（onDeactivated）/卸载会停止计时器，避免后台空转。',
    },
    {
      anchor: 'bud_batchCancel',
      name: '批量取消（本地待入款 Tab，表格左上角按钮）',
      group: '操作',
      interaction:
        '先勾选表格行首复选框多选（row-selection），再点"批量取消"，按钮旁会显示已选中笔数；未选中任何行时按钮禁用。',
      dataSource: '当前表格勾选的行（getSelectedRows）。',
      logic:
        '点击后弹二次确认框，确认后调用批量取消接口；若选中的行里有缺失订单号的数据会直接拦截报错；若选中的行跨了不同商户也会直接拦截报错（一次只能批量取消同一商户的订单）；接口支持部分成功，会分别提示"全部成功/部分成功（成功N笔失败N笔）/全部失败"三种结果文案。',
      limit: '需至少选中 1 行；选中行必须同商户、都要有订单号。',
    },
    {
      anchor: 'bud_confirm',
      name: '确认（本地待入款 Tab，行操作按钮）',
      group: '操作',
      interaction: '点行内"确认"，弹二次确认框（标题"确认上分"，内容带订单号），确认后提交。',
      logic:
        '订单号缺失时直接报错拦截、不弹确认框；确认后调用本地充值确认接口，成功提示并刷新列表。',
      edge: '2026-07-22 已修复：显示条件已改为复用 canConfirmRechargeOrder，与「全部入款记录」Tab 统一为"已充值即隐藏"（2026-07-21 曾如实记录为更宽松的 rechargeState!==2，详见 ChangeLogFab v1.9.147）；同行「取消」按钮显示条件不属本次统一范围，维持 rechargeState!==2 不变。',
    },
    {
      anchor: 'bud_cancel',
      name: '取消（本地待入款 Tab，行操作按钮）',
      group: '操作',
      interaction:
        '点行内"取消"，弹二次确认框（提示"此操作将取消该订单，后续到账需在充值订单处补单"），确认后提交。',
      logic: '订单号缺失时直接报错拦截、不弹确认框；确认后调用取消接口，成功提示并刷新列表。',
    },

    // ============ Tab③全部入款记录：搜索 ============
    {
      anchor: 'dr_tenant',
      name: '商户（全部入款记录 Tab，搜索区）',
      group: '搜索',
      interaction: '下拉单选（tenantSelect，架构级不可清空）。',
      dataSource: '全站商户列表。',
      logic:
        '切换商户会清空"充值大类"和"通道ID/名称"两个联动字段，并按新商户重新拉取充值大类下拉选项。',
      limit: '搜索表单项配了 showRequireMark 红星提示 + 组件本身不可清空。',
    },
    {
      anchor: 'dr_cardType',
      name: '充值大类（全部入款记录 Tab，搜索区）',
      group: '搜索',
      interaction: '下拉单选可搜索可清空，依赖已选商户。',
      dataSource:
        '按当前商户拉取该商户全部充值大类（本地+三方均含，不像「本地待入款」/「三方待入款」两个 Tab 那样按 local 关键字过滤）。',
      logic: '切换后联动清空"通道ID/名称"。',
      edge: '商户未选时选项为空。',
    },
    {
      anchor: 'dr_channel',
      name: '通道ID/名称（全部入款记录 Tab，搜索区）',
      group: '搜索',
      interaction:
        '下拉单选可搜索可清空，依赖已选商户；若已选"充值大类"，下拉只展示该大类下的通道。',
      dataSource:
        '按当前商户+当前选中大类拉取通道原始列表（不按 local/三方过滤，含全部通道——是全页唯一不做 local/三方筛选的通道下拉）。',
      logic: '按选中的通道关系ID精确过滤列表。',
    },
    {
      anchor: 'dr_memberId',
      name: '会员ID（全部入款记录 Tab，搜索区）',
      group: '搜索',
      interaction: '文本输入。',
      dataSource: '用户输入。',
      limit: '选填；仅允许输入数字字符，最长 9 位。',
    },
    {
      anchor: 'dr_orderNo',
      name: '订单号（全部入款记录 Tab，搜索区）',
      group: '搜索',
      interaction: '文本输入。',
      limit: '选填；最长 50 字。',
    },
    {
      anchor: 'dr_plainFilters',
      name: '收款卡号 / 客户入款卡号 / TransID（全部入款记录 Tab，搜索区）',
      group: '搜索',
      interaction: '均为文本输入框，可正常输入、清空。',
      dataSource: '用户输入。',
      logic: '分别按收款账号/客户入款账号/交易流水号子串匹配过滤，三项互相独立。',
      limit: '均选填。',
    },
    {
      anchor: 'dr_orderStatus',
      name: '订单状态（全部入款记录 Tab，搜索区）',
      group: '搜索',
      interaction: '下拉单选可清空（dictSelect）。',
      dataSource: '字典 rechargeStateList（common 源）：待支付/已充值/支付失败。',
      logic: '按选中状态精确过滤。',
    },
    {
      anchor: 'dr_memberLevel',
      name: '会员充值等级（全部入款记录 Tab，搜索区）',
      group: '搜索',
      interaction: '下拉单选可搜索可清空。',
      dataSource: '取自字典 vipLevelList。',
    },
    {
      anchor: 'dr_vipLevel',
      name: 'VIP等级（全部入款记录 Tab，搜索区）',
      group: '搜索',
      interaction: '下拉单选可搜索可清空。',
      dataSource: '取自字典 vipLevelList。',
      edge: '⚠️ 核实代码后发现："会员充值等级"与"VIP等级"这两个概念不同的筛选项，当前实现取的是同一个字典 key vipLevelList，下拉选项列表目前完全相同，如实记录这一数据源重叠（不确定是否有专门的充值等级字典尚未接入）。',
    },
    {
      anchor: 'dr_rechargeCountRange',
      name: '充值次数（全部入款记录 Tab，搜索区，区间）',
      group: '搜索',
      interaction: '两个数字输入框并排（最小值-最大值），均可清空，仅接受非负整数。',
      dataSource: '用户输入。',
      logic:
        '最小值大于最大值时两个输入框均标红，并在下方展示错误提示文字；点查询前会二次拦截，此时不会真正发起请求（并弹一次警告提示）。',
      limit: '均选填；非负整数。',
    },
    {
      anchor: 'dr_amountRange',
      name: '充值发起金额（全部入款记录 Tab，搜索区，区间）',
      group: '搜索',
      interaction: '两个数字输入框并排（最小值-最大值），均可清空，仅接受非负数。',
      dataSource: '用户输入。',
      logic: '最小值大于最大值时两个输入框均标红并提示，查询前会拦截、不发起请求。',
      limit: '均选填；非负数。',
    },
    {
      anchor: 'dr_timeRange',
      name: '下单时间（全部入款记录 Tab，搜索区）',
      group: '搜索',
      interaction: '日期时间区间选择，另有独立快捷日期按钮组（quick-date="timeRange"）。',
      limit: '选填，可清空。',
    },
    {
      anchor: 'dr_completeTimeRange',
      name: '完成时间（全部入款记录 Tab，搜索区）',
      group: '搜索',
      interaction: '日期时间区间选择，与"下单时间"相互独立、可同时使用。',
      limit: '选填，可清空。',
    },
    {
      anchor: 'dr_reset',
      name: '重置（全部入款记录 Tab，搜索表单）',
      group: '操作',
      interaction: '点击搜索表单「重置」按钮。',
      logic:
        '除清空搜索表单各字段外，额外把商户恢复为默认商户（联动恢复充值大类下拉选项）、并把内部记录的"当前选中充值大类ID"清空，连带让"通道ID/名称"下拉恢复展示该商户下全部通道（不再受大类过滤限制）。',
    },

    // ============ Tab③全部入款记录：列 ============
    {
      anchor: 'dr_col_tenant',
      name: '商户列（全部入款记录 Tab）',
      group: '列',
      interaction: '标签展示，不可点。',
      dataSource: '接口不回显 tenantId，前端按本次请求实际提交的商户回填展示。',
    },
    {
      anchor: 'dr_col_userId',
      name: '会员ID列（全部入款记录 Tab）',
      group: '列',
      interaction: '数字以可点击蓝字链接形式展示（跳转类控件）。',
      dataSource: '行数据 userId + tenantId。',
      logic: '点击调用 openMemberDetail(userId, tenantId) 打开会员详情弹窗。',
    },
    {
      anchor: 'dr_col_memberInfo',
      name: '会员信息列（全部入款记录 Tab）',
      group: '列',
      interaction: '纯展示三行：充值等级 / VIP等级 / 会员状态，不可点。',
      dataSource: '与「三方待入款」「本地待入款」共用同一渲染函数 renderMemberInfoBlock。',
    },
    {
      anchor: 'dr_col_orderNo',
      name: '订单号列（全部入款记录 Tab）',
      group: '列',
      interaction: '纯文本展示，超长省略并 tooltip 提示，不可点。',
    },
    {
      anchor: 'dr_col_customerInfo',
      name: '客户入款信息列（全部入款记录 Tab）',
      group: '列',
      interaction: '纯展示持卡人 + 银行卡号，不可点。',
      dataSource: '与「本地待入款」共用同一渲染函数 renderCustomerInfo。',
    },
    {
      anchor: 'dr_col_rechargeCategory',
      name: '充值大类列（全部入款记录 Tab）',
      group: '列',
      interaction: '纯文本展示，不可点。',
      dataSource: '行数据 rechargeCategoryName，为空显示"--"。',
    },
    {
      anchor: 'dr_col_receiveInfo',
      name: '本地收款信息/通道名称列（全部入款记录 Tab）',
      group: '列',
      interaction: '纯展示多行文本，不可点；按 receiveInfo 是否含本地账户信息二选一分支展示。',
      dataSource: '与「本地待入款」共用同一渲染函数 renderReceiveInfoOrChannel。',
    },
    {
      anchor: 'dr_col_amount',
      name: '充值发起金额列（全部入款记录 Tab）',
      group: '列',
      interaction: '纯展示，可按该列排序（点表头）。',
      dataSource: '行数据 amount；USDT 大类订单额外展示兑换比例与 USDT 数量两行。',
    },
    {
      anchor: 'dr_col_actualAmount',
      name: '实际充值金额列（全部入款记录 Tab）',
      group: '列',
      interaction: '纯展示，不可点。',
      dataSource:
        '行数据 actualAmount；未到账/为 0 时展示"0.00"；USDT 大类且未成功时额外展示兑换比例与折算 USDT 数量两行。',
    },
    {
      anchor: 'dr_col_rechargeCount',
      name: '充值次数列（全部入款记录 Tab）',
      group: '列',
      interaction: '纯展示，可按该列排序。',
      dataSource: '行数据 rechargeCount（该会员历史充值总次数）。',
    },
    {
      anchor: 'dr_col_state',
      name: '订单状态列（全部入款记录 Tab）',
      group: '列',
      interaction: '彩色标签展示，不可点。',
      dataSource: '行数据 rechargeState，与搜索下拉同源字典。',
    },
    {
      anchor: 'dr_col_createTime',
      name: '下单时间列（全部入款记录 Tab，复合列）',
      group: '列',
      interaction: '纯展示两行：下单时间 + 完成时间，均按所属商户时区格式化，不可点。',
      dataSource: '行数据 createTime / successTime；未完成时 successTime 显示"--"。',
    },
    {
      anchor: 'dr_col_operator',
      name: '操作人列（全部入款记录 Tab）',
      group: '列',
      interaction: '纯文本展示，不可点。',
      dataSource:
        '行数据 lastUpdateMan（最近一次更新该订单的操作来源，如"异步回调"/"三方充值自动取消"）。',
    },
    {
      anchor: 'dr_col_remark',
      name: '备注列（全部入款记录 Tab）',
      group: '列',
      interaction: '纯文本展示，超长省略并 tooltip 提示，不可点。',
      dataSource: '行数据 remark，为空显示"--"。',
    },

    // ============ Tab③全部入款记录：汇总条 ============
    {
      anchor: 'dr_summaryBar',
      name: '汇总条（全部入款记录 Tab，表格下方）',
      group: '其它',
      interaction: '纯展示两行统计，不可点、不可交互。',
      dataSource:
        '"页面总计"=当前页客户端聚合；"总计"=接口返回的服务端聚合（金额/U额/实付金额/手续费/上分等）。实付金额与上分口径一致，仅统计已支付订单。',
    },

    // 说明：全部入款记录为只读历史视图，对齐开发站已移除行内「确认补单」操作列（补单入口仅在「三方待入款 / 本地待入款」Tab）。

    // ============ Tab④直充短信：搜索 ============
    {
      anchor: 'sms_tenant',
      name: '商户（直充短信 Tab，搜索区）',
      group: '搜索',
      interaction: '下拉单选可清空。',
      dataSource: '全站商户列表。',
      logic: '切换商户会清空"收款卡号"筛选值，并联动重新拉取该商户下的本地银行卡下拉选项。',
      limit: '搜索表单项配了 showRequireMark 红星提示。',
      edge: '2026-07-22 已修复：componentProps 里显式传的 clearable:true 已移除，与其余 3 个 Tab 一致维持不可清空（2026-07-21 曾如实记录：该值会覆盖 ProTenantSelect 内部 :clearable="false" 的默认锁定——v-bind="$attrs" 按 Vue 同名属性后者覆盖前者的规则展开在后，导致本 Tab 商户下拉理论上可被清空、与红星"必选"视觉矛盾，详见 ChangeLogFab v1.9.147）。',
    },
    {
      anchor: 'sms_smsId',
      name: '订单号（直充短信 Tab，搜索区）',
      group: '搜索',
      interaction: '文本输入。',
      dataSource: '用户输入。',
      logic:
        '同时匹配短信自身编号（banKingID）与关联的充值订单号（orderNumber），任一子串命中即算匹配——字段标签是"订单号"，但实际覆盖两个不同来源的编号。',
      limit: '选填；最长 50 字。',
    },
    {
      anchor: 'sms_keyWords',
      name: '短信内容（直充短信 Tab，搜索区）',
      group: '搜索',
      interaction: '文本输入。',
      dataSource: '用户输入。',
      logic: '按短信正文内容子串匹配（不区分大小写）。',
      limit: '选填；最长 50 字。',
    },
    {
      anchor: 'sms_amount',
      name: '充值金额（直充短信 Tab，搜索区）',
      group: '搜索',
      interaction: '数字输入框，可清空。',
      dataSource: '用户输入。',
      logic: '按金额精确相等匹配过滤——不是区间，与本页其余 Tab 的金额搜索多为区间不同。',
      limit: '选填。',
    },
    {
      anchor: 'sms_receiveAccount',
      name: '收款卡号（直充短信 Tab，搜索区）',
      group: '搜索',
      interaction:
        '下拉单选可搜索可清空，下拉每一项三列并排展示：分类标签（Local Bank/Local Upi/Local E-Wallet/Local Usdt）+ 自定义名称 + 收款账号。',
      dataSource: '按当前查询商户加载该商户名下的本地银行卡列表（getRechargeLocalBankCardList）。',
      logic: '按选中账号精确过滤。',
      edge: '商户未选时也会返回全量卡列表（未按商户过滤，与其它 Tab"未选商户下拉为空"的常见模式不同）。',
    },
    {
      anchor: 'sms_matchStatus',
      name: '匹配状态（直充短信 Tab，搜索区）',
      group: '搜索',
      interaction: '下拉单选可清空，固定 4 个选项。',
      dataSource: '固定选项：匹配失败 / 已匹配 / 匹配超时 / 等待匹配，非字典来源。',
      logic: '按选中值精确过滤。',
    },
    {
      anchor: 'sms_sendTimeRange',
      name: '发送时间（直充短信 Tab，搜索区）',
      group: '搜索',
      interaction: '日期时间区间选择，另有独立快捷日期按钮组（quick-date="sendTimeRange"）。',
      limit: '选填，可清空；不允许选未来时间（allowFuture:false）。',
    },

    // ============ Tab④直充短信：列 ============
    {
      anchor: 'sms_col_tenant',
      name: '商户列（直充短信 Tab）',
      group: '列',
      interaction: '标签展示，不可点。',
      dataSource:
        '行数据自带 tenantId（本 Tab 每条短信记录本身就携带真实商户归属，不需要像其它 3 个 Tab 那样用"本次请求提交的商户"回填）。',
    },
    {
      anchor: 'sms_col_banKingID',
      name: '短信ID列（直充短信 Tab）',
      group: '列',
      interaction: '纯文本展示，不可点。',
      dataSource: '行数据 banKingID（短信系统内部流水号）。',
      edge: '2026-08-03 按 PM 需求确认单指令调整：①列位置由"收款账户列之后"挪到"商户列与会员ID列之间"（原第 8 列调至第 2 列）；②列名由"短信编号"改为"短信ID"（i18n key finance.prototype.fields.smsId 中文值同步由"短信编号"改为"短信ID"，英文 SMS ID 本就正确未动）。key/render 逻辑不变。详见 ChangeLogFab。',
    },
    {
      anchor: 'sms_col_userId',
      name: '会员ID列（直充短信 Tab）',
      group: '列',
      interaction: '可点击蓝字链接形式展示（跳转类控件），与其它 3 个 Tab 的会员ID 列行为一致。',
      dataSource: '行数据 userId + tenantId。',
      logic:
        '点击调用 openMemberDetail(userId, tenantId) 打开会员详情弹窗（全站统一的会员ID可点规范）。',
      edge: '2026-07-22 已修复：本列 render 函数已接入 useMemberDetailModal().openMemberDetail 的 onClick，与同页其余 3 个 Tab（三方待入款/本地待入款/全部入款记录）行为对齐（2026-07-21 曾如实记录：样式做成可点蓝字但未绑定 onClick、点击没有任何反应，详见 ChangeLogFab v1.9.147）。',
    },
    {
      anchor: 'sms_col_amount',
      name: '充值金额列（直充短信 Tab）',
      group: '列',
      interaction: '纯展示，可按该列排序（点表头）。',
      dataSource: '行数据 amount。',
    },
    {
      anchor: 'sms_col_orderNumber',
      name: '订单号列（直充短信 Tab）',
      group: '列',
      interaction: '纯文本展示，为空显示"--"，不可点。',
      dataSource:
        '行数据 orderNumber（该条短信自动匹配成功后关联的充值订单号；未匹配成功的短信该字段为空）。',
    },
    {
      anchor: 'sms_col_state',
      name: '匹配状态列（直充短信 Tab）',
      group: '列',
      interaction: '彩色标签展示（已匹配绿/匹配超时橙/等待匹配灰/匹配失败红），不可点。',
      dataSource: '行数据 state（0/1/2/3），与搜索下拉同源。',
    },
    {
      anchor: 'sms_col_bankName',
      name: '收款银行列（直充短信 Tab）',
      group: '列',
      interaction: '纯文本展示，为空显示"--"，不可点。',
      dataSource: '行数据 bankName（短信来源银行）。',
    },
    {
      anchor: 'sms_col_bankAccount',
      name: '收款账户列（直充短信 Tab）',
      group: '列',
      interaction: '纯文本展示，为空显示"--"，不可点。',
      dataSource: '行数据 bankAccount，明文全量展示，未脱敏。',
    },
    {
      anchor: 'sms_col_type',
      name: '短信类型列（直充短信 Tab）',
      group: '列',
      interaction: '纯文本展示"入款短信"/"出款短信"，不可点。',
      dataSource: '行数据 type（0=入款短信 1=出款短信），当前 mock 全部数据均为入款短信。',
    },
    {
      anchor: 'sms_col_sendName',
      name: '发送者列（直充短信 Tab）',
      group: '列',
      interaction: '纯文本展示，为空显示"--"，不可点。',
      dataSource: '行数据 sendName（短信发送方号码/名称，如"HDFCBK"）。',
    },
    {
      anchor: 'sms_col_contents',
      name: '短信内容列（直充短信 Tab）',
      group: '列',
      interaction:
        '复用全站 CopyText 组件展示：最多显示 2 行，超出省略号截断，鼠标悬停截断内容可弹出提示气泡看全文，右侧带复制图标点击可一键复制短信原文。不可点跳转（复制图标除外）。',
      dataSource: '行数据 contents（银行短信原文）。',
      edge: '2026-08-03 按 PM 需求确认单指令调整：原纯文本自然换行居中展示（不截断不提示）改为 CopyText 组件 2 行省略+悬停全文+复制按钮，maxWidth 320px 配合 line-clamp 生效。详见 ChangeLogFab。',
    },
    {
      anchor: 'sms_col_smsTime',
      name: '发送时间列（直充短信 Tab）',
      group: '列',
      interaction: '纯文本展示，不可点。',
      dataSource: '优先取行数据 addTimeStr，取不到则退回 smsTime，都没有显示"--"。',
    },
  ],

  // ============ 字段介绍 tab（按各自 Tab 列表列真实列序；仅列表列 + 定义）============
  fields: [
    // ---- 三方待入款 Tab（9 列，同 thirdPartyPending/useThirdPartyPendingPage.ts columns 顺序）----
    { name: '「三方待入款」商户', def: '该条订单所属商户，标签形式展示。' },
    { name: '「三方待入款」会员ID', def: '发起充值的会员编号，可点击蓝字跳转会员详情弹窗。' },
    { name: '「三方待入款」会员信息', def: '该会员的充值等级 / VIP 等级 / 会员状态三项复合展示。' },
    { name: '「三方待入款」订单号', def: '该笔充值订单的唯一编号。' },
    { name: '「三方待入款」客户入款信息', def: '会员侧填写的持卡人姓名与银行卡号。' },
    {
      name: '「三方待入款」通道名称',
      def: '本笔订单实际使用的三方支付通道，格式为"通道ID → 前台展示名称"。',
    },
    {
      name: '「三方待入款」充值发起金额',
      def: '会员发起充值时提交的金额（USDT 订单另含兑换比例与折算数量）。',
    },
    { name: '「三方待入款」订单状态', def: '待支付 / 已充值 / 支付失败三态之一。' },
    { name: '「三方待入款」下单时间', def: '该笔订单的发起时间，按所属商户时区显示。' },

    // ---- 本地待入款 Tab（11 列，同 bankUpiDeposit/useBankUpiDepositPage.ts columns 顺序）----
    { name: '「本地待入款」商户', def: '该条订单所属商户，标签形式展示。' },
    { name: '「本地待入款」会员ID', def: '发起充值的会员编号，可点击蓝字跳转会员详情弹窗。' },
    { name: '「本地待入款」会员信息', def: '该会员的充值等级 / VIP 等级 / 会员状态三项复合展示。' },
    { name: '「本地待入款」订单号', def: '该笔充值订单的唯一编号。' },
    { name: '「本地待入款」客户入款信息', def: '会员侧填写的持卡人姓名与银行卡号。' },
    {
      name: '「本地待入款」转账凭证',
      def: '会员上传的转账截图，缩略图展示、可点击预览大图，未上传显示占位文字。',
    },
    {
      name: '「本地待入款」本地收款信息/通道名称',
      def: '商户方用于接收本次转账的银行/UPI/EWallet/USDT 账户信息，或三方通道名称（二选一，按订单类型区分）。',
    },
    { name: '「本地待入款」充值大类', def: '该笔订单归属的充值大类展示名称。' },
    {
      name: '「本地待入款」充值发起金额',
      def: '会员发起充值时提交的金额（USDT 订单另含兑换比例与折算数量）。',
    },
    { name: '「本地待入款」订单状态', def: '待支付 / 已充值 / 支付失败（已取消）三态之一。' },
    { name: '「本地待入款」下单时间', def: '该笔订单的发起时间，按所属商户时区显示。' },

    // ---- 全部入款记录 Tab（14 列，同 depositRecords/useDepositRecordsPage.ts columns 顺序）----
    { name: '「全部入款记录」商户', def: '该条订单所属商户，标签形式展示。' },
    { name: '「全部入款记录」会员ID', def: '发起充值的会员编号，可点击蓝字跳转会员详情弹窗。' },
    {
      name: '「全部入款记录」会员信息',
      def: '该会员的充值等级 / VIP 等级 / 会员状态三项复合展示。',
    },
    { name: '「全部入款记录」订单号', def: '该笔充值订单的唯一编号。' },
    { name: '「全部入款记录」客户入款信息', def: '会员侧填写的持卡人姓名与银行卡号。' },
    { name: '「全部入款记录」充值大类', def: '该笔订单归属的充值大类展示名称。' },
    {
      name: '「全部入款记录」本地收款信息/通道名称',
      def: '商户方收款账户信息或三方通道名称（二选一，按订单类型区分）。',
    },
    {
      name: '「全部入款记录」充值发起金额',
      def: '会员发起充值时提交的金额（USDT 订单另含兑换比例与折算数量），可排序。',
    },
    { name: '「全部入款记录」实际充值金额', def: '该笔订单最终实际到账的金额，未到账时为 0。' },
    { name: '「全部入款记录」充值次数', def: '该会员历史累计充值总次数，可排序。' },
    { name: '「全部入款记录」订单状态', def: '待支付 / 已充值 / 支付失败三态之一。' },
    {
      name: '「全部入款记录」下单时间',
      def: '下单时间 + 完成时间两行复合展示，按所属商户时区显示，未完成时完成时间为"--"。',
    },
    {
      name: '「全部入款记录」操作人',
      def: '最近一次更新该订单状态的操作来源（如系统异步回调、三方自动取消等）。',
    },
    { name: '「全部入款记录」备注', def: '该笔订单的补充说明文字。' },

    // ---- 直充短信 Tab（12 列，同 autoSmsRecords/useAutoSmsRecordsPage.ts columns 顺序，2026-08-03 短信ID列挪至第2列）----
    { name: '「直充短信」商户', def: '该条短信记录所属商户，标签形式展示。' },
    {
      name: '「直充短信」短信ID',
      def: '短信系统内部流水号（原名"短信编号"，2026-08-03 改名并从收款账户列后挪到本位）。',
    },
    {
      name: '「直充短信」会员ID',
      def: '若该短信已自动匹配到订单，展示对应会员编号，可点击蓝字跳转会员详情弹窗。',
    },
    { name: '「直充短信」充值金额', def: '短信内容中解析出的到账金额，可排序。' },
    { name: '「直充短信」订单号', def: '该短信自动匹配成功后关联的充值订单号，未匹配成功为空。' },
    {
      name: '「直充短信」匹配状态',
      def: '该短信与充值订单的自动匹配结果：已匹配 / 匹配超时 / 等待匹配 / 匹配失败。',
    },
    { name: '「直充短信」收款银行', def: '发送该短信的银行名称。' },
    { name: '「直充短信」收款账户', def: '短信关联的收款银行账号，明文展示。' },
    { name: '「直充短信」短信类型', def: '入款短信或出款短信。' },
    { name: '「直充短信」发送者', def: '短信发送方（通常为银行官方号码/名称）。' },
    {
      name: '「直充短信」内容',
      def: '银行短信原文全文，最多显示2行超出省略并可悬停查看全文，支持一键复制。',
    },
    { name: '「直充短信」发送时间', def: '该短信到达系统的时间。' },
  ],
};

export default manual;
