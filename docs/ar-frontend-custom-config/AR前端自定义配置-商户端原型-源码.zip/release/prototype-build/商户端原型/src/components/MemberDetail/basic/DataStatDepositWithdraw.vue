<template>
  <!--
    充提明细（样板会员 1100002·合并版）：充值信息 + 提现信息 合并到「一个」带边框版块，
    避免布局把两者拆散（曾出现「提现信息」被跨列腰斩、看着像丢了）。
    每个「最后3次」表默认只展示最后 1 笔、其余可点击展开——数据不删，仅收缩。
  -->
  <div class="detail-section">
    <div class="detail-section__header">
      <h4 class="detail-section__title">{{ t('member.detail.dataStat.depositWithdrawData') }}</h4>
    </div>
    <!-- 合并概览：充值 + 提现 字段合并为一个网格（2026-07-13 用户要求：充值信息 + 提现信息合并）。
         排版（2026-07-16 用户要求）：普通格子横排「标题：数值」；
         带 dateNote 的首充/次充/三充仍保持「标题 / 金额 / 日期」上下三行（2026-07-13 要求，本次明确保留不动），
         故按 dateNote 条件挂共享 .detail-cell--stack——横排会把日期拉到同一行、打散三行结构。 -->
    <div class="detail-grid dsdw__grid--merged">
      <div
        v-for="it in overviewItems"
        :key="it.label"
        class="detail-cell"
        :class="{ 'detail-cell--stack': it.dateNote }"
      >
        <span class="detail-cell__label">{{ it.label }}</span>
        <span
          class="detail-cell__value"
          :class="it.highlight ? `highlight--${it.highlight}` : ''"
          >{{ it.value }}</span
        >
        <!-- 首/次/三充：日期另起一行·小字灰色（2026-07-13 用户要求·标题/金额/日期上下三行） -->
        <span v-if="it.dateNote" class="dsdw__datenote">{{ it.dateNote }}</span>
      </div>
    </div>

    <!-- 最后3次：充值 | 提现 竖版并列（左右两列，各默认 1 笔可展开·2026-07-13 用户要求） -->
    <div class="dsdw__tables">
      <div class="dsdw__tablecol">
        <span class="dsdw__sub">{{ t('member.detail.depositWithdraw.last3Deposits') }}</span>
        <n-data-table :columns="depositCols" :data="depositAll" :bordered="false" size="small" />
      </div>
      <div class="dsdw__tablecol">
        <span class="dsdw__sub">{{ t('member.detail.depositWithdraw.last3Withdraws') }}</span>
        <n-data-table :columns="withdrawCols" :data="withdrawAll" :bordered="false" size="small" />
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
  import { h, computed, type PropType } from 'vue';
  import { NTag } from 'naive-ui';
  import { useI18n } from 'vue-i18n';
  import { useTenantOptions } from '@/hooks';
  import { useMemberContext } from '../useMemberContext';

  const props = defineProps({
    dw: { type: Object as PropType<any>, required: true },
  });

  const { t } = useI18n();
  const { detailData, tenantId } = useMemberContext();
  const { renderTenantDateTimeColumnTitle } = useTenantOptions();

  // 合并概览：充值概览字段 + 提现概览字段 合并为一个网格（充值信息 + 提现信息合并）
  const overviewItems = computed<any[]>(() => [
    ...(props.dw?.rechargeItems || []),
    ...(props.dw?.withdrawItems || []),
  ]);

  // 最后3次：默认全部展开（2026-07-13 用户要求：默认展开、去掉收缩按钮）
  const depositAll = computed<any[]>(() => detailData.value.recentDeposits || []);
  const withdrawAll = computed<any[]>(() => detailData.value.recentWithdraws || []);

  // 通道列：typeId >= 10000 时在通道名前加 tag（与充提信息 Tab 一致）
  function renderChannelCell(typeId: number | null, typeName: string) {
    if (typeId != null && typeId >= 10000) {
      return h('span', { style: 'display: inline-flex; align-items: center; gap: 4px;' }, [
        h(NTag, { size: 'small', bordered: true, type: 'info' }, () => String(typeId)),
        typeName,
      ]);
    }
    return typeName;
  }

  const depositCols = computed(() => [
    {
      title: renderTenantDateTimeColumnTitle(
        t('member.detail.depositWithdraw.depositTime'),
        tenantId.value,
      ),
      key: 'time',
      titleAlign: 'center' as const,
      align: 'center' as const,
    },
    {
      title: t('member.detail.depositWithdraw.amount'),
      key: 'amount',
      titleAlign: 'center' as const,
      align: 'center' as const,
    },
    {
      title: t('member.detail.depositWithdraw.type'),
      key: 'type',
      titleAlign: 'center' as const,
      align: 'center' as const,
      render: (row: any) => renderChannelCell(row.payTypeId, row.type),
    },
  ]);

  const withdrawCols = computed(() => [
    {
      title: renderTenantDateTimeColumnTitle(
        t('member.detail.depositWithdraw.withdrawTime'),
        tenantId.value,
      ),
      key: 'time',
      titleAlign: 'center' as const,
      align: 'center' as const,
    },
    {
      title: t('member.detail.dataStat.codingMultiplier'),
      key: 'multiple',
      titleAlign: 'center' as const,
      align: 'center' as const,
      render: (row: any) => {
        const val = row.multiple;
        if (!val || val === '-') return val;
        return h('span', { style: 'color: #dc2626; font-weight: 600' }, val);
      },
    },
    {
      title: t('member.detail.depositWithdraw.amount'),
      key: 'amount',
      titleAlign: 'center' as const,
      align: 'center' as const,
    },
    {
      title: t('member.detail.depositWithdraw.type'),
      key: 'type',
      titleAlign: 'center' as const,
      align: 'center' as const,
      render: (row: any) => renderChannelCell(row.withdrawTypeId, row.type),
    },
  ]);
</script>

<style lang="less" scoped>
  // 合并版：一个 .detail-section 内含「充值信息 / 提现信息」两子块（子块用小标题分隔）
  .dsdw__subtitle {
    font-size: 13px;
    font-weight: 600;
    color: #262626;
    margin: 2px 0 8px;
  }
  .dsdw__subtitle--gap {
    margin-top: 18px;
  }
  .dsdw__grid--3 {
    grid-template-columns: repeat(3, minmax(0, 1fr));
  }
  .dsdw__grid--2 {
    grid-template-columns: repeat(2, minmax(0, 1fr));
  }
  /* 合并概览网格（充值 + 提现 字段一起）：一行 3 列（2026-07-14 用户要求，原 4 列） */
  .dsdw__grid--merged {
    grid-template-columns: repeat(3, minmax(0, 1fr));
  }
  /* 首/次/三充：日期行·小字灰色（标题/金额/日期上下三行） */
  .dsdw__datenote {
    font-size: 11px;
    color: #9ca3af;
    line-height: 1.4;
  }
  /* 最后3次两表竖版并列：左右两列 */
  .dsdw__tables {
    display: flex;
    gap: 16px;
    align-items: flex-start;
    margin-top: 12px;
  }
  .dsdw__tablecol {
    flex: 1;
    min-width: 0;
  }
  /* 最后3次充值/提现两表：每行（含表头）等高、左右严格对齐——固定 th/td 高度 + 内容不换行，
     消除因列数不同(充值3列 vs 提现4列)/通道名换行导致的行高差异（用户要求 2026-07-13） */
  .dsdw__tables :deep(.n-data-table-th),
  .dsdw__tables :deep(.n-data-table-td) {
    height: 40px;
    box-sizing: border-box;
    white-space: nowrap;
  }
  .dsdw__tablewrap {
    margin-top: 12px;
  }
  .dsdw__sub {
    display: block;
    margin: 0 0 6px;
    font-size: 12px;
    font-weight: 600;
    color: #595959;
  }
  // 「展开其余N笔 / 收起」链接
  .dsdw__toggle {
    display: inline-block;
    margin-top: 8px;
    font-size: 12px;
    color: #2563eb;
    cursor: pointer;
  }
</style>
