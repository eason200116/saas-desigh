// 汇率管理（总控端 admin · lottery_rate）功能说明书。
// 锚定 src/views/lottery/rate/index.vue + data.ts + components/RateFormModal.vue 真实控件（R53 实证、不臆造）。
// 标准 ProCrudTable 列表页：无搜索区 + 4 列 + 顶部 2 操作（新增 / 设为主货币）+ 2 行操作（编辑 / 删除）。

import type { PageManual } from '../types';

const manual: PageManual = {
  route: 'lottery_rate',
  title: '汇率管理',
  overview:
    '总控端维护彩票业务的货币汇率：以一种主货币（mock 默认人民币 CNY）为基准，配置各转换货币与主货币间的换算比例，供投注 / 派奖等场景做跨币种换算。可新增 / 编辑 / 删除汇率记录，可将某货币设为主货币。本页无搜索区，列表展示全部记录、默认居中。页面顶部（操作按钮上方）常驻展示"当前主货币"信息提示条，随"设为主货币"操作实时刷新（不整页刷新）。',
  items: [
    // ============ 操作（顶部 2 + 行操作 2；本页无搜索区、无特殊交互列）============
    {
      anchor: 'act_add',
      name: '新增（顶部）',
      group: '操作',
      interaction:
        '点击顶部「新增」打开新增弹窗（约 520px，RateFormModal）。主货币为只读展示（不可编辑，展示当前全局主货币，如需变更需用顶部「设为主货币」入口）；选转换货币、填汇率后保存。',
      dataSource:
        '转换货币下拉选项来自 api.lottery.rateGetCurrencyOptions（弹窗挂载时拉取，10 种币种共用一套选项）；主货币只读展示同样取自该选项集的当前值。',
      logic: '保存调用 api.lottery.rateSave，成功后刷新列表。',
      limit:
        '转换货币必选；汇率必填、为数字且不可为负（表单 rules：targetCurrency / rate 均 required；RateFormModal 汇率输入框 min:0）。',
      edge: '未选转换货币或未填汇率时点保存被表单校验拦下、不提交。',
    },
    {
      anchor: 'act_setMain',
      name: '设为主货币（顶部）',
      group: '操作',
      interaction: '点击顶部「设为主货币」弹出确认框，框内一个货币下拉（NSelect）供选择。',
      dataSource:
        '下拉选项同样来自 api.lottery.rateGetCurrencyOptions（点击时拉取），默认选中返回结果第一项。',
      logic:
        '点确认调用 api.lottery.rateSetMain({ mainCurrency }) 设置主货币，成功后刷新列表；同时同步刷新顶部"当前主货币"提示条。',
      limit: '必须选中一个货币才能点确认继续。',
      edge: '未选货币点确认 → 弹警告提示且不关闭弹窗（message.warning，不提交）；mock 未联动改写各行 mainCurrency 或重算汇率，真实生效范围（是否级联更新既有记录）待 5190 核实。',
    },
    {
      anchor: 'act_edit',
      name: '行操作 · 编辑',
      group: '操作',
      interaction:
        '点击打开编辑弹窗（约 520px，RateFormModal），回显该行主货币（只读展示，不可编辑）/ 转换货币 / 汇率（可编辑）。',
      logic: '保存调用 api.lottery.rateSave（带 id），成功后刷新列表。',
      limit:
        '同新增：转换货币必选、汇率必填且不可为负（min:0）；主货币不可编辑，本弹窗不支持修改。',
    },
    {
      anchor: 'act_delete',
      name: '行操作 · 删除',
      group: '操作',
      interaction: '点击弹二次确认框（dialog.warning：确认 / 取消）。',
      logic: '确认后调用 api.lottery.rateDelete 删除该条汇率记录，成功后刷新列表。',
      edge: '删除不可撤销；删除前是否检查该货币被其它模块（如投注 / 派奖）引用并拦截，待 5190 核实。',
    },
  ],

  // ============ 字段介绍 tab（仅列表的列 + 定义；顺序同列序 R44）============
  fields: [
    {
      name: '货币名称',
      def: '转换货币（子货币）的中文名称 + 币种代码组合展示，如"墨西哥比索（MXN）"。',
    },
    {
      name: '汇率',
      def: '主货币与该转换货币间的换算比例：主货币→子货币乘以汇率，子货币→主货币除以汇率。',
    },
    { name: '最后修改人', def: '最近一次修改该汇率记录的操作账号。' },
    { name: '最后修改时间', def: '该汇率记录最近一次修改的时间（按商户时区展示）。' },
  ],
};

export default manual;
