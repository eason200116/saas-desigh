<template>
  <n-spin :show="walletLoading">
    <n-empty
      v-if="!walletLoading && !detailData.walletSections?.length"
      :description="t('member.detail.wallet.noData')"
      style="min-height: 200px; display: flex; align-items: center; justify-content: center"
    />
    <div v-else class="wallet-grid">
      <div v-for="section in detailData.walletSections" :key="section.key" class="wallet-section">
        <div class="wallet-section__header">
          <h3 class="wallet-section__title">{{ section.title }}</h3>
          <!-- 「新增」+「操作记录」成组靠右：header 是 space-between，不成组会把按钮挤到中间 -->
          <div style="display: inline-flex; align-items: center; gap: 4px">
            <n-button
              v-permission="sectionModalMap[section.key]?.addAuth"
              type="primary"
              size="tiny"
              @click="handleAdd(section)"
            >
              {{ t('common.add') }}
            </n-button>
            <!-- 操作记录入口（仅样板 1100002·pilot）：版块级，挂「新增」右侧 -->
            <MemberOpLogPopover v-if="isSample" page="会员银行卡管理" :item="section.title" />
          </div>
        </div>
        <n-empty
          v-if="!section.cards?.length"
          :description="t('member.detail.wallet.noData')"
          size="small"
          style="padding: 24px 0"
        />
        <div v-else class="wallet-card-list">
          <div v-for="card in section.cards" :key="card.id" class="wallet-card">
            <div class="wallet-card__header">
              <span class="wallet-card__id"
                >{{ section.idLabel }}：<strong>{{ card.id }}</strong></span
              >
              <!-- 「编辑」+「操作记录」成组靠右：header 是 space-between，不成组会把按钮挤到中间 -->
              <div style="display: inline-flex; align-items: center; gap: 4px">
                <n-button
                  v-permission="sectionModalMap[section.key]?.editAuth"
                  text
                  type="primary"
                  size="tiny"
                  @click="handleEdit(section, card)"
                >
                  {{ t('common.edit') }}
                </n-button>
                <!-- 操作记录入口（仅样板 1100002·pilot）：卡片级，挂「编辑」右侧；item 带卡ID 以区分同版块多张卡 -->
                <MemberOpLogPopover
                  v-if="isSample"
                  page="会员银行卡管理"
                  :item="`${section.title} ${card.id}`"
                />
              </div>
            </div>
            <div class="wallet-card__body">
              <div v-for="field in card.fields" :key="field.label" class="wallet-card__row">
                <span class="wallet-card__label">{{ field.label }}</span>
                <span class="wallet-card__value">{{ field.value }}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </n-spin>
</template>

<script setup lang="ts">
  import { computed, h } from 'vue';
  import { useI18n } from 'vue-i18n';
  import { useModal } from 'naive-ui';
  import { useWallet } from './useWallet';
  import { useMemberContext, MEMBER_DETAIL_CHILD_Z_INDEX } from '../useMemberContext';
  import MemberOpLogPopover from '../shared/MemberOpLogPopover.vue';
  import type { WalletSection, WalletCard } from './buildWalletData';

  // 会员钱包编辑弹窗（跨模块共享）
  import { BankCardEditModal, WalletEditModal, UpiEditModal, UsdtEditModal } from '@/components';

  const { t } = useI18n();
  const modal = useModal();
  const { walletLoading, detailData, reloadWallet } = useWallet();
  // 会员详情上下文：新增钱包时用于默认带入商户 ID 与会员 ID
  const { memberId, tenantId } = useMemberContext();

  // 【已铺开·2026-07-14 用户确认】「操作记录」入口原为样板 1100002 试点，验收后对全部会员生效，故恒为 true。
  // 保留变量以便一行收回（改回 Number(memberId.value) === 1100002）。
  const isSample = computed(() => true);

  /**
   * 各分组对应的弹窗组件、标题和权限码映射。
   * addAuth / editAuth 与 src/views/member/bankCard/{bankCard,wallet,upi,usdt} 列表页的权限码保持一致。
   */
  const sectionModalMap: Record<
    string,
    {
      component: any;
      addTitle: string;
      editTitle: string;
      width: string;
      addAuth: string[];
      editAuth: string[];
    }
  > = {
    bank: {
      component: BankCardEditModal,
      addTitle: t('member.bankCard.addBankCard'),
      editTitle: t('member.bankCard.editBankCard'),
      width: '680px',
      addAuth: ['Member:BankCardManage:UserBankCard:Add'],
      editAuth: ['Member:BankCardManage:UserBankCard:Update'],
    },
    ewallet: {
      component: WalletEditModal,
      addTitle: t('member.bankCard.addWallet'),
      editTitle: t('member.bankCard.editWallet'),
      width: '600px',
      addAuth: ['Member:BankCardManage:UserEWallet:Add'],
      editAuth: ['Member:BankCardManage:UserEWallet:Update'],
    },
    upi: {
      component: UpiEditModal,
      addTitle: t('member.bankCard.addUpi'),
      editTitle: t('member.bankCard.editUpi'),
      width: '560px',
      addAuth: ['Member:BankCardManage:UserUpi:Add'],
      editAuth: ['Member:BankCardManage:UserUpi:Update'],
    },
    usdt: {
      component: UsdtEditModal,
      addTitle: t('member.bankCard.addUsdt'),
      editTitle: t('member.bankCard.editUsdt'),
      width: '560px',
      addAuth: ['Member:BankCardManage:UserUsdt:Add'],
      editAuth: ['Member:BankCardManage:UserUsdt:Update'],
    },
  };

  function handleAdd(section: WalletSection) {
    const config = sectionModalMap[section.key];
    if (!config) return;

    const inst = modal.create({
      zIndex: MEMBER_DETAIL_CHILD_Z_INDEX,
      title: config.addTitle,
      preset: 'dialog',
      showIcon: false,
      style: { width: config.width },
      content: () =>
        h(config.component, {
          mode: 'add',
          // 默认带入当前会员的商户 ID 与会员 ID
          initial: {
            tenantId: tenantId.value ?? undefined,
            userId: memberId.value ?? undefined,
          },
          onCancel: () => inst.destroy(),
          onConfirm: () => {
            inst.destroy();
            reloadWallet();
          },
        }),
    });
  }

  function handleEdit(section: WalletSection, card: WalletCard) {
    const config = sectionModalMap[section.key];
    if (!config) return;

    const inst = modal.create({
      zIndex: MEMBER_DETAIL_CHILD_Z_INDEX,
      title: config.editTitle,
      preset: 'dialog',
      showIcon: false,
      style: { width: config.width },
      content: () =>
        h(config.component, {
          mode: 'edit',
          record: card.payload,
          // 钱包信息接口响应不返回 userId / tenantId，用当前会员详情上下文兜底，避免编辑弹窗会员ID为空
          initial: {
            tenantId: tenantId.value ?? undefined,
            userId: memberId.value ?? undefined,
          },
          onCancel: () => inst.destroy(),
          onConfirm: () => {
            inst.destroy();
            reloadWallet();
          },
        }),
    });
  }
</script>
