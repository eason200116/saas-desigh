import { h, computed, reactive, ref, watch } from 'vue';
import { useI18n } from 'vue-i18n';
import { startOfDay, endOfDay, subDays } from 'date-fns';
import { createActionColumn } from '@/components';
import type { ProCrudTableInstance } from '@/components';
import { useUser } from '@/hooks';
import { currency } from '@/utils';
import { useMemberContext, useQueryReload } from '../useMemberContext';
import { useMemberTableTimezone } from '../useMemberTableTimezone';
import {
  createBettingStatColumns,
  getCategoryTypeMap,
  createBettingSearchColumns,
} from './bettingConfig';

/**
 * 投注统计 Tab 的业务逻辑
 */
export function useBettingStat() {
  const { t } = useI18n();
  const { memberId, tenantId: ctxTenantId, globalTimeRange, lastWithdrawTime } = useMemberContext();
  const { formatDateTimeStr, parseTimeStr, fetchUserBetTotal, openBettingOrderDetailModal } =
    useUser();
  const canViewBetRecord = true;

  const bettingStatTableRef = ref<ProCrudTableInstance | null>(null);
  // 投注时间 picker 按会员所属商户时区展示（而非全局默认商户）
  useMemberTableTimezone(bettingStatTableRef);

  // 用户是否已手动修改时间——一旦修改，不再随 lastWithdrawTime / globalTimeRange 重置
  const userModifiedTime = ref(false);
  const stableLastWithdrawTime = ref(lastWithdrawTime.value);
  const stableDefaultTimeRange = ref<[number, number] | null>(null);

  watch(lastWithdrawTime, (val) => {
    if (!userModifiedTime.value) stableLastWithdrawTime.value = val;
  });

  const markTimeModified = () => {
    userModifiedTime.value = true;
  };

  const bettingStatSummary = reactive({
    pageBetCount: '0',
    pageBetAmount: '0.00',
    pageValidBetAmount: '0.00',
    pagePayoutAmount: '0.00',
    pageWinLoseAmount: '0.00',
    grandTotalBetCount: '0',
    grandTotalBetAmount: '0.00',
    grandTotalValidBetAmount: '0.00',
    grandTotalPayoutAmount: '0.00',
    grandTotalWinLoseAmount: '0.00',
  });

  // 固定的30天范围
  const default30DaysRange = [
    startOfDay(subDays(new Date(), 30)).getTime(),
    endOfDay(new Date()).getTime(),
  ] as [number, number];

  // 默认时间范围：有 lastWithdrawTime 时从上次提现到现在，否则30天
  const defaultBetTimeRange = computed(() => {
    if (lastWithdrawTime.value) {
      const ts = parseTimeStr(lastWithdrawTime.value);
      if (ts) return [ts, endOfDay(new Date()).getTime()] as [number, number];
    }
    if (Array.isArray(globalTimeRange.value) && globalTimeRange.value.length === 2) {
      return [globalTimeRange.value[0], globalTimeRange.value[1]] as [number, number];
    }
    return default30DaysRange;
  });

  // 同步稳定默认时间范围（用户修改后不再跟随 globalTimeRange 变化）
  watch(
    defaultBetTimeRange,
    (val) => {
      if (!userModifiedTime.value) stableDefaultTimeRange.value = val;
    },
    { immediate: true },
  );

  function parseLastWithdrawTime() {
    return parseTimeStr(lastWithdrawTime.value);
  }

  // 搜索列配置（computed 以响应语言切换，稳定时间值不随 lastWithdrawTime 重置）
  const searchColumns = computed(() =>
    createBettingSearchColumns(t, {
      lastWithdrawTime: stableLastWithdrawTime.value,
      parseLastWithdrawTime,
      defaultBetTimeRange: stableDefaultTimeRange.value ?? defaultBetTimeRange.value,
      default30DaysRange,
      onUserModifyTime: markTimeModified,
    }),
  );

  /**
   * 由时间戳范围生成后端要求的字符串格式。入参无效时返回空对象。
   */
  function fmtRange(range: [number, number] | number[] | null | undefined) {
    if (!Array.isArray(range) || range.length !== 2) return {};
    const startTime = formatDateTimeStr(range[0]);
    const endTime = formatDateTimeStr(range[1]);
    if (!startTime || !endTime) return {};
    return { startTime, endTime };
  }

  /**
   * 获取"查看明细"弹窗要传的时间范围。
   * 优先读 form 里展平后的 startTime / endTime（即 picker 展示的值，包含 since_last_withdraw
   * 切换时自动写入的 23:59:59）；都没有时 fallback 到 defaultBetTimeRange。
   */
  function getBettingTimeRange() {
    const searchParams = bettingStatTableRef.value?.getSearchParams?.() || {};

    if (searchParams.startTime && searchParams.endTime) {
      return {
        startTime: searchParams.startTime as string,
        endTime: searchParams.endTime as string,
      };
    }

    return fmtRange(defaultBetTimeRange.value);
  }

  // 操作列
  const actionColumn = createActionColumn(() => ({
    actions: [
      {
        label: t('member.detail.betting.viewDetail'),
        type: 'primary',
        disabled: !canViewBetRecord,
        onClick: (row) => {
          const timeRange = getBettingTimeRange();
          openBettingOrderDetailModal({
            ...row,
            memberId: memberId.value,
            // 透传会员所属商户，避免投注详情弹窗回落到全局商户
            tenantId: ctxTenantId.value ?? undefined,
            ...timeRange,
          });
        },
      },
    ],
    width: 100,
  }));

  // 汇总行（NaiveUI summary，返回数组 = 多行）
  const amountCell = (val: string) => ({
    value: h('span', { style: 'font-weight: 600' }, val),
  });
  const profitCell = (val: string) => ({
    value: h(
      'span',
      { style: `color: ${String(val).startsWith('-') ? '#dc2626' : '#16a34a'}; font-weight: 600` },
      val,
    ),
  });

  const summary = () => [
    {
      gameType: { value: t('common.summary.pageTotal') },
      betCount: amountCell(bettingStatSummary.pageBetCount),
      betAmount: amountCell(bettingStatSummary.pageBetAmount),
      validBetAmount: amountCell(bettingStatSummary.pageValidBetAmount),
      payoutAmount: amountCell(bettingStatSummary.pagePayoutAmount),
      profit: profitCell(bettingStatSummary.pageWinLoseAmount),
    },
    {
      gameType: { value: t('common.summary.total') },
      betCount: amountCell(bettingStatSummary.grandTotalBetCount),
      betAmount: amountCell(bettingStatSummary.grandTotalBetAmount),
      validBetAmount: amountCell(bettingStatSummary.grandTotalValidBetAmount),
      payoutAmount: amountCell(bettingStatSummary.grandTotalPayoutAmount),
      profit: profitCell(bettingStatSummary.grandTotalWinLoseAmount),
    },
  ];

  // 表格列（computed 以响应语言切换）
  const columns = computed(() => createBettingStatColumns(t));

  // 加载数据
  async function loadData(params) {
    const isSinceLastWithdraw = params?.timePreset === 'since_last_withdraw';
    // modelKeys 展平后 form 里直接存 startTime/endTime 字符串；没有时 fallback 到稳定默认范围。
    // 切换"从上次提现 / 所有"由 bettingConfig 的 onUpdateValue 同步写回 startTime/endTime，
    // 这里直接信任 form 的值，避免与 picker 上展示的 endTime（23:59:59）发生不一致。
    let startTime = params?.startTime as string | undefined;
    let endTime = params?.endTime as string | undefined;
    if (!startTime || !endTime) {
      const fallback = stableDefaultTimeRange.value ?? defaultBetTimeRange.value;
      const fmt = fmtRange(fallback);
      startTime = fmt.startTime;
      endTime = fmt.endTime;
    }
    try {
      const userId = Number(memberId.value);

      // 排序参数：profit 列 key 映射到 API 的 winLoseAmount 字段
      const SORT_FIELD_MAP: Record<string, string> = { profit: 'winLoseAmount' };
      const sortField =
        params?.sortField && SORT_FIELD_MAP[params.sortField]
          ? SORT_FIELD_MAP[params.sortField]
          : undefined;
      const orderBy = sortField ? (params.sortOrder === 'ascend' ? 'Asc' : 'Desc') : undefined;

      const result = await fetchUserBetTotal({
        userId,
        // 嵌入弹窗时强制使用订单商户
        tenantId: ctxTenantId.value ?? undefined,
        startTime,
        endTime,
        sinceLastWithdraw: isSinceLastWithdraw,
        pageNo: params?.pageNo ?? 1,
        pageSize: params?.pageSize ?? 10,
        sortField,
        orderBy,
      });
      const categoryMap = getCategoryTypeMap(t);
      const list = (result?.list || []).map((item) => ({
        gameType: categoryMap[item.categoryType] || '--',
        provider: item.vendorDisplayName || item.vendorCode || '--',
        subGameName: item.gameName || '--',
        subGameId: item.gameCode || '--',
        vendorCode: item.vendorCode ?? '',
        gameCategory: item.gameCategory ?? '',
        categoryType: item.categoryType,
        lotteryGameType: item.gameType ?? '',
        betCount: item.betCount ?? 0,
        betAmount: item.betAmount ?? 0,
        validBetAmount: item.validAmount ?? 0,
        payoutAmount: item.winAmount ?? 0,
        winLoseAmount: item.winLoseAmount ?? 0,
      }));

      const s = result?.summary;
      const fmtSigned = (n) => {
        const str = currency(n);
        return String(str).startsWith('-') ? str : `+${str}`;
      };

      bettingStatSummary.pageBetCount = String(s?.pageBetCount ?? 0);
      bettingStatSummary.pageBetAmount = currency(s?.pageBetAmount ?? 0);
      bettingStatSummary.pageValidBetAmount = currency(s?.pageValidAmount ?? 0);
      bettingStatSummary.pagePayoutAmount = currency(s?.pageWinAmount ?? 0);
      bettingStatSummary.pageWinLoseAmount = fmtSigned(s?.pageWinLoseAmount ?? 0);
      bettingStatSummary.grandTotalBetCount = String(s?.totalBetCount ?? 0);
      bettingStatSummary.grandTotalBetAmount = currency(s?.totalBetAmount ?? 0);
      bettingStatSummary.grandTotalValidBetAmount = currency(s?.totalValidAmount ?? 0);
      bettingStatSummary.grandTotalPayoutAmount = currency(s?.totalWinAmount ?? 0);
      bettingStatSummary.grandTotalWinLoseAmount = fmtSigned(s?.totalWinLoseAmount ?? 0);

      return { list, total: result?.totalCount ?? 0 };
    } catch (e) {
      console.error('加载投注统计失败', e);
      return { list: [], total: 0 };
    }
  }

  useQueryReload('bet', bettingStatTableRef);

  return {
    bettingStatTableRef,
    columns,
    searchColumns,
    actionColumn,
    summary,
    loadData,
  };
}
