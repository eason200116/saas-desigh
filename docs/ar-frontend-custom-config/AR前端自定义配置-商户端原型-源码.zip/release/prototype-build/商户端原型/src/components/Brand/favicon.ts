import { createBrandSvgMarkup } from './svg';

const FAVICON_LINK_ID = 'app-favicon';

export function syncDynamicFavicon(themeColor?: string, isDark = false) {
  if (typeof document === 'undefined') {
    return;
  }

  const href = createBrandFaviconDataUrl(themeColor, isDark);
  const faviconLink = ensureFaviconLink();

  faviconLink.type = 'image/svg+xml';
  faviconLink.rel = 'icon';
  faviconLink.sizes = 'any';
  faviconLink.href = href;
}

export function createBrandFaviconDataUrl(themeColor?: string, isDark = false) {
  const svg = createBrandFaviconSvg(themeColor, isDark);
  const encoded = encodeSvgBase64(svg);
  return `data:image/svg+xml;base64,${encoded}`;
}

export function createBrandFaviconSvg(themeColor?: string, isDark = false) {
  return createBrandSvgMarkup({
    decorative: true,
    idPrefix: 'ar-favicon',
    isDark,
    themeColor,
  });
}

function ensureFaviconLink() {
  const existing = document.getElementById(FAVICON_LINK_ID);
  if (existing instanceof HTMLLinkElement) {
    return existing;
  }

  const link = document.createElement('link');
  link.id = FAVICON_LINK_ID;
  document.head.appendChild(link);
  return link;
}

function encodeSvgBase64(svg: string) {
  const encoded = encodeURIComponent(svg).replace(/%([0-9A-F]{2})/g, (_, hex: string) =>
    String.fromCharCode(Number.parseInt(hex, 16)),
  );

  return window.btoa(encoded);
}
