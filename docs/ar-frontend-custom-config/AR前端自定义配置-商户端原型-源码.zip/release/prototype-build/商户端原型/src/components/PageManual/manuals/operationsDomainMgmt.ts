import type { PageManual } from '../types';
import { merchantDomainZh } from './features/arMerchant';

const manual: PageManual = {
  prdManualFeatureId: 'HELP-01',
  route: 'operations_domainMgmt',
  title: '域名管理',
  overview: '维护商户域名与有效主域名的唯一当前版面；已绑定域名必须先解除，才能另行建立新绑定。',
  featurePoints: merchantDomainZh,
  sections: [
    { key: 'purpose', content: '查看及维护主域名、推广域名与防封谷歌页。只有“主域名、已验证、有效”的记录可用于版面；每个主域名同一时间只能绑定一个版面。' },
    { key: 'prerequisites', content: '新增、编辑、解除及建立版面绑定依域名管理与“配置管理”权限。主域名绑定版面前，目标版面必须来自总控下派且仍为商户有效版面。' },
    { key: 'areas', content: '搜索区包含商户、域名类型与域名。列表显示当前绑定版面、状态、建立／修改信息与备注。已绑定记录的版面只读；推广及防封域名不参与版面绑定。' },
    { key: 'workflow', content: '1. 选择商户、域名类型或网址搜索。\n2. 新增主域名时选择一个有效版面。\n3. 输入 https:// 域名、状态与备注并保存。\n4. 已绑定域名不能在编辑表单直接切换版面。\n5. 如需变更，先完成独立解除操作，再另行建立新绑定。\n6. 返回列表核对当前绑定、状态与操作记录。' },
    { key: 'permissions', content: '有页面查看权限可阅读列表与说明。无配置管理时新增、编辑、解除与绑定隐藏或禁用。版面发布由“发布管理”控制。' },
    { key: 'effects', content: '新增或编辑会更新域名数据。解除成功后域名变为未绑定；另行绑定成功后才建立新的唯一关系。停用或审核失败会保留数据但停止对外服务。' },
    { key: 'unavailable', content: '非主域名不能选择版面。主域名必须已验证且有效才可用于新绑定或发布。已绑定域名不能直接选择其他版面；并发操作以第一笔成功为准，后续操作需重新加载。' },
    { key: 'recovery', content: '无可选版面时检查总控下派及商户有效版面；无可选主域名时检查类型、验证及有效状态。重复域名请改用唯一网址。绑定或保存失败时保留当前线上版面与表单内容，按业务提示修正后重试。数据过期或并发冲突时重新加载；加载失败使用重试并保留上次成功数据。' },
  ],
  items: [
    { anchor: 'merchant', name: '商户', group: '搜索', interaction: '按授权范围筛选所属商户；编辑既有域名时商户不可变更。' },
    { anchor: 'domainType', name: '域名类型', group: '搜索', interaction: '筛选主域名、推广域名或防封谷歌页；只有主域名参与版面绑定。' },
    { anchor: 'domainUrl', name: '域名', group: '搜索', interaction: '按完整或部分网址搜索。' },
    { anchor: 'reset', name: '重置', group: '搜索', interaction: '清空搜索条件并重新加载列表。' },
    { anchor: 'act_add', name: '新增', group: '操作', interaction: '新增域名；主域名还需选择商户有效版面。', limit: '网址须以 https:// 开头、最多 50 字且不可重复。' },
    { anchor: 'act_edit', name: '编辑', group: '操作', interaction: '编辑类型、网址、状态与备注；已有版面绑定只读，不能在此直接切换。' },
  ],
  fields: [
    { name: '商户', def: '域名所属且在当前授权范围内的商户。' },
    { name: '域名 ID', def: '域名记录的唯一识别值。' },
    { name: '域名类型', def: '主域名、推广域名或防封谷歌页。' },
    { name: '域名', def: '以 https:// 开头的唯一网址。' },
    { name: '绑定版面', def: '主域名当前唯一绑定的版面；变更前必须先解除。' },
    { name: '状态', def: '域名目前为启用或停用；只有已验证且有效主域名可用于发布。' },
    { name: '创建／修改信息', def: '建立及最近修改的人员与时间。' },
    { name: '备注', def: '域名补充说明，最多 500 字。' },
  ],
};

export default manual;
