// 历史 facade `ProDateRangePicker.vue` 已删；纯转发 wrapper 无价值，外部 export 名直接指向
// `ZonedDateRangePanel`（实际面板实现），调用方与类型签名保持一致。
import ProDateRangePicker from './components/ZonedDateRangePanel.vue';
import ProDateRangeInput from './ProDateRangeInput.vue';
import ProSelectDateRange from './ProSelectDateRange.vue';
import ProQuickDateButtons from './ProQuickDateButtons.vue';

export { ProDateRangePicker, ProDateRangeInput, ProSelectDateRange, ProQuickDateButtons };
export {
  useZonedShortcuts,
  matchShortcutIndexByRange,
  createZonedBaseShortcutItems,
  createZonedDefaultShortcutValue,
  createClearShortcutItem,
  CLEAR_SHORTCUT_KEY,
} from './composables/useZonedShortcuts';
export { useEffectiveDateRangeTimezone } from './useDateRange';
export type { DateRangeValue, ShortcutItem, ProDateRangePickerProps } from '../types';
export default ProDateRangePicker;
