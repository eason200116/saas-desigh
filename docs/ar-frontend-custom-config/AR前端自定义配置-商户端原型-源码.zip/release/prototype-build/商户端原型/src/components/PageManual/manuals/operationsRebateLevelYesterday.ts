// 昨日返佣等级（商户端 tenant · operations_rebateLevelYesterday）功能说明书。
// 锚定 src/views/operations/rebateLevelYesterday/index.vue + RebateLevelReportModal.vue + data.ts 真实控件（R53 实证、不臆造）。
// 报表类只读页（R21：报表类页面允许导出按钮），无新增/编辑/删除。

import type { PageManual } from '../types';

const manual: PageManual = {
  route: 'operations_rebateLevelYesterday',
  title: '昨日返佣等级',
  overview:
    '商户端「运营管理 › 昨日返佣等级」页，统计每位会员昨日在各游戏品类(彩票/电子/真人/体育/棋牌)的投注流水' +
    '与对应返佣金额，报表类只读页，搜索区多达11个筛选项(含团队人数/团队充值/游戏流水的最小-最大区间+排序方式)。' +
    '"返佣等级"列可点击下钻查看该会员当日详细的层级返佣/流水返佣报表。导出按钮走真实的 useTableExport 通用' +
    '导出流程(按当前筛选条件导出)，是真实生效的功能。2026-07-22核实代码未发现真实缺陷。',
  items: [
    {
      anchor: 'merchant',
      name: '商户（必选）',
      group: '搜索',
      interaction: '下拉单选，红星必填；未选点查询红框+红字提示。',
      limit: '单选必填（R63）。',
    },
    {
      anchor: 'memberId',
      name: '会员ID',
      group: '搜索',
      interaction: '文本框，可清空。',
    },
    {
      anchor: 'rebateLevel',
      name: '返佣等级',
      group: '搜索',
      interaction: '下拉单选，可清空；选项Lv1~Lv10。',
    },
    {
      anchor: 'minTeamCount',
      name: '团队人数(最小)',
      group: '搜索',
      interaction: '文本框(数字)。',
    },
    {
      anchor: 'maxTeamCount',
      name: '团队人数(最大)',
      group: '搜索',
      interaction: '文本框(数字)。',
    },
    {
      anchor: 'minTeamRecharge',
      name: '团队充值(最小)',
      group: '搜索',
      interaction: '文本框(数字)。',
    },
    {
      anchor: 'maxTeamRecharge',
      name: '团队充值(最大)',
      group: '搜索',
      interaction: '文本框(数字)。',
    },
    {
      anchor: 'minGameAmount',
      name: '游戏流水(最小)',
      group: '搜索',
      interaction: '文本框(数字)。',
    },
    {
      anchor: 'maxGameAmount',
      name: '游戏流水(最大)',
      group: '搜索',
      interaction: '文本框(数字)。',
    },
    {
      anchor: 'sortBy',
      name: '排序方式',
      group: '搜索',
      interaction: '下拉单选，可清空；10种排序选项，均为降序(按团队人数/团队充值/各品类流水/计算返佣/实发返佣)。',
    },
    {
      anchor: 'reset',
      name: '重置',
      group: '搜索',
      interaction: 'ProCrudTable内置重置按钮。',
    },
    {
      anchor: 'act_export',
      name: '导出',
      group: '操作',
      interaction: '工具栏按钮，点击展开格式选择(Excel/CSV)，选定后按当前筛选条件导出。',
      logic: '走全站通用导出Hook(useTableExport)，真实生效（R21：报表类页面允许导出）。',
    },
    {
      anchor: 'col_rebateLevel',
      name: '返佣等级（可点击，带虚线下划线提示）',
      group: '列',
      interaction: '蓝色Tag，形如"LvN"，带虚线下划线提示可点击。',
      logic: '点击打开该会员当日「会员层级返佣」二级弹窗（1040px宽），展示层级返佣/流水返佣明细报表。',
    },
  ],
  fields: [
    { name: '商户（列）', def: '该记录所属商户，标签展示。' },
    { name: '日期', def: '统计日期（昨日）。' },
    { name: '会员ID', def: '该团队长会员编号，可点击进详情。' },
    { name: '返佣等级', def: '该会员当日所处的返佣等级，见交互条目 col_rebateLevel。' },
    { name: '团队人数', def: '该会员团队下的会员数量。' },
    { name: '团队充值', def: '该会员团队昨日累计充值金额。' },
    { name: '游戏流水', def: '该会员团队昨日全品类累计有效投注流水。' },
    { name: '彩票·流水/返佣（新）', def: '彩票品类的有效投注流水与对应返佣金额，分两个子列。' },
    { name: '电子·流水/返佣（新）', def: '电子品类的有效投注流水与对应返佣金额，分两个子列。' },
    { name: '真人·流水/返佣（新）', def: '真人品类的有效投注流水与对应返佣金额，分两个子列。' },
    { name: '体育·流水/返佣（新）', def: '体育品类的有效投注流水与对应返佣金额，分两个子列。' },
    { name: '棋牌·流水/返佣（新）', def: '棋牌品类的有效投注流水与对应返佣金额，分两个子列。' },
    { name: '计算返佣', def: '按规则计算出的应发返佣总额。' },
    { name: '实发返佣', def: '实际已发放的返佣总额。' },
    { name: '发放时间', def: '返佣实际发放的时间，按商户时区展示。' },
  ],
};

export default manual;
