<template>
  <div class="pro-creator-button" :class="`position-${position}`">
    <n-button
      type="primary"
      dashed
      block
      :disabled="disabled"
      v-bind="buttonProps"
      @click="handleClick"
    >
      <template #icon>
        <n-icon>
          <PlusOutlined />
        </n-icon>
      </template>
      {{ buttonText }}
    </n-button>
  </div>
</template>

<script lang="ts" setup>
  import { computed, type PropType } from 'vue';
  import { NButton, NIcon, type ButtonProps } from 'naive-ui';
  import { useI18n } from 'vue-i18n';
  import { PlusOutlined } from '@vicons/antd';

  defineOptions({
    name: 'ProCreatorButton',
  });

  const props = defineProps({
    /** 按钮位置 */
    position: {
      type: String as PropType<'top' | 'bottom'>,
      default: 'bottom',
    },
    /** 按钮文本 */
    text: {
      type: String,
      default: undefined,
    },
    /** 按钮属性 */
    buttonProps: {
      type: Object as PropType<Partial<ButtonProps>>,
      default: () => ({}),
    },
    /** 禁用 */
    disabled: {
      type: Boolean,
      default: false,
    },
  });

  const { t } = useI18n();
  const buttonText = computed(() => props.text ?? t('components.proEditDataTable.addRow'));

  const emit = defineEmits<{
    (e: 'click'): void;
  }>();

  function handleClick() {
    emit('click');
  }
</script>

<style lang="less" scoped>
  .pro-creator-button {
    padding: 8px 0;

    &.position-top {
      padding-top: 0;
      padding-bottom: 16px;
    }

    &.position-bottom {
      padding-top: 16px;
      padding-bottom: 0;
    }
  }
</style>
