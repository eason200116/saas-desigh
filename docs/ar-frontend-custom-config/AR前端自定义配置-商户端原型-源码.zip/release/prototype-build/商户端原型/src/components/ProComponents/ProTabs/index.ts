/**
 * @description ProTabs 出口：父容器 ProTabs + 子面板 ProTabPane + context 类型。
 * @date 2026-05-22
 * @scope src/components/ProComponents/ProTabs
 */
import ProTabs from './ProTabs.vue';
import ProTabPane from './ProTabPane.vue';

export { ProTabs, ProTabPane };
export type {
  ProTabPaneDisplayDirective,
  ProTabPaneMeta,
  ProTabsContext,
  ProTabsHeightContext,
  ProTabsPaneRect,
} from './context';
export { ProTabsContextKey, ProTabsHeightContextKey } from './context';
export default ProTabs;
