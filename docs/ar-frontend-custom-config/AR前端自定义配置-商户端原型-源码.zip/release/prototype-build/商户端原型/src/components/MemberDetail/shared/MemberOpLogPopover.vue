<!--
  会员详情·操作项「操作记录」浮层：挂在某个可操作字段（开关 / 修改 / 新增 / 编辑）旁的小图标，
  点击弹出该字段最近的变更记录（3 列：操作时间 / 操作人员 / 操作内容）。仅查看、不可编辑。

  视觉 1:1 对齐配置中心「系统消息配置」的 ConfigOpLogPopover（用户 2026-07-14 指定参考）；
  两处有意偏离并有据：
    ① z-index 取 MEMBER_DETAIL_CHILD_Z_INDEX(6100) —— 会员详情主弹窗是 6000，参考里写死的 2200 会被盖住。
    ② 「查看全部记录」切到会员详情内的「系统日志」Tab（不跳 /system/platform-log 全站页），
       因为会员详情自带日志 Tab，跳外部会把用户踢出弹窗、丢掉会员上下文。
  取数复用配置中心已有的确定性 mock getConfigOpLog(page, item)（动词字典「会员列表」「会员银行卡管理」已就绪）。
  i18n 用 member 自有键 member.detail.opLog.*：/member/* 路由只加载 member 命名空间，
  直接用 config.opLog.* 会露原始键（见 spec §7）。
-->
<template>
  <n-popover
    trigger="click"
    placement="bottom-start"
    :show-arrow="true"
    raw
    :z-index="MEMBER_DETAIL_CHILD_Z_INDEX"
    style="border-radius: 10px"
  >
    <template #trigger>
      <span class="mb-oplog__ic" :title="t('member.detail.opLog.title')" @click.stop>
        <!-- 操作记录：日志文档（带横线记录）icon，全站统一（对齐 ConfigOpLogPopover / GroupOpLogPopover） -->
        <svg
          viewBox="0 0 24 24"
          width="13"
          height="13"
          fill="none"
          stroke="currentColor"
          stroke-width="2"
          stroke-linecap="round"
          stroke-linejoin="round"
          aria-hidden="true"
        >
          <path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z" />
          <path d="M14 3v5h5" />
          <path d="M9 12h6" />
          <path d="M9 16h4" />
        </svg>
      </span>
    </template>

    <div class="mb-oplog__pop" @click.stop>
      <div class="mb-oplog__hd">
        <!-- 左上：会员ID（主色加粗）+ · 字段名（灰色小字） -->
        <span class="mb-oplog__subject">
          {{ memberId }}<span class="mb-oplog__itemname"> · {{ item }}</span>
        </span>
        <!-- 右上：操作记录 -->
        <span class="mb-oplog__title">{{ t('member.detail.opLog.title') }}</span>
      </div>

      <table v-if="records.length" class="mb-oplog__tb">
        <thead>
          <tr>
            <th class="col-time">{{ t('member.detail.opLog.time') }}</th>
            <th class="col-user">{{ t('member.detail.opLog.user') }}</th>
            <th class="col-content">{{ t('member.detail.opLog.content') }}</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="(r, i) in records" :key="i">
            <td class="col-time">{{ r.time }}</td>
            <td class="col-user">{{ r.user }}</td>
            <td class="col-content">{{ r.content }}</td>
          </tr>
        </tbody>
      </table>
      <div v-else class="mb-oplog__empty">{{ t('member.detail.opLog.empty') }}</div>

      <div class="mb-oplog__ft">
        <a class="mb-oplog__all" @click="goAll">{{ t('member.detail.opLog.viewAll') }} →</a>
      </div>
    </div>
  </n-popover>
</template>

<script lang="ts" setup>
  defineOptions({ name: 'MemberOpLogPopover' });

  import { computed } from 'vue';
  import { NPopover } from 'naive-ui';
  import { useI18n } from 'vue-i18n';
  // 取数复用配置中心的确定性 mock（纯 TS 数据函数，非组件；跨模块引用 config/shared 是既有做法）
  import { getConfigOpLog } from '@/views/config/shared/configOpLog';
  import { useMemberContext, MEMBER_DETAIL_CHILD_Z_INDEX } from '../useMemberContext';

  const props = defineProps<{
    /** 所在页面口径，决定操作动词字典：'会员列表'（基本信息）/ '会员银行卡管理'（钱包信息） */
    page: string;
    /** 字段/记录标识，如「会员状态」「用户备注」「银行卡 ****1234」 */
    item: string;
    /** 最多展示条数（默认 3，对齐参考） */
    limit?: number;
  }>();

  const { t } = useI18n();
  const { memberId, activeTab } = useMemberContext();

  const records = computed(() =>
    getConfigOpLog(props.page, props.item).slice(0, props.limit ?? 3),
  );

  // 「查看全部记录」→ 切到会员详情内的「系统日志」Tab（用户 2026-07-14 指定：跳会员列表里的系统日志）
  function goAll() {
    activeTab.value = 'log';
  }
</script>

<style lang="less" scoped>
  .mb-oplog__ic {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 18px;
    height: 18px;
    margin-left: 4px;
    border-radius: 5px;
    color: #9aa4b2;
    cursor: pointer;
    border: 1px solid transparent;
    transition: all 0.12s;
    vertical-align: middle;
    flex-shrink: 0;

    &:hover {
      color: var(--ui-accent-solid, #009688);
      background: #f0fdfa;
      border-color: #99f6e4;
    }
  }

  .mb-oplog__pop {
    width: 430px;
    max-width: 92vw;
    background: #fff;
    border-radius: 10px;
    overflow: hidden;
  }

  .mb-oplog__hd {
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 9px 13px;
    border-bottom: 1px solid #eef0f2;
    font-size: 13px;
  }
  /* 左上：会员ID（主色加粗）+ 字段名（灰色小字） */
  .mb-oplog__subject {
    flex: 1;
    min-width: 0;
    font-weight: 700;
    color: var(--ui-accent-solid, #009688);
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }
  .mb-oplog__itemname {
    font-weight: 400;
    color: #9aa4b2;
  }
  /* 右上：操作记录 */
  .mb-oplog__title {
    flex: none;
    margin-left: auto;
    font-size: 12px;
    font-weight: 600;
    color: #6b7280;
  }

  .mb-oplog__tb {
    width: 100%;
    border-collapse: collapse;
    font-size: 12.5px;
  }
  .mb-oplog__tb th {
    background: #f7f9f9;
    color: #6b7280;
    font-size: 11.5px;
    font-weight: 600;
    padding: 7px 12px;
    border-bottom: 1px solid #eef0f2;
  }
  .mb-oplog__tb td {
    padding: 7px 12px;
    color: #374151;
    border-bottom: 1px solid #f3f4f6;
  }
  /* R16 居中：时间 / 人员；R41 换行文案居左：操作内容 */
  .col-time {
    text-align: center;
    white-space: nowrap;
    color: #6b7280;
    font-variant-numeric: tabular-nums;
  }
  .col-user {
    text-align: center;
    white-space: nowrap;
  }
  .col-content {
    text-align: left;
    word-break: break-word;
    line-height: 1.5;
  }

  .mb-oplog__empty {
    padding: 22px 12px;
    text-align: center;
    color: #9aa4b2;
    font-size: 12.5px;
  }
  .mb-oplog__ft {
    padding: 7px 13px;
    text-align: right;
    border-top: 1px solid #eef0f2;
  }
  .mb-oplog__all {
    color: var(--ui-accent-solid, #009688);
    font-size: 12px;
    cursor: pointer;
    text-decoration: none;

    &:hover {
      text-decoration: underline;
    }
  }
</style>
