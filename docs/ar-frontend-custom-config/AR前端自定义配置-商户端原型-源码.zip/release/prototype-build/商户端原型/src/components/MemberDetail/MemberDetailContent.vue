<template>
  <div class="member-detail-content">
    <n-spin :show="loading" style="min-height: 400px">
      <n-tabs v-model:value="activeTab" type="line">
        <!--
          双层懒加载策略（不要简化任何一层）：
          1. tabComponents 用 defineAsyncComponent → 控制 JS chunk 加载时机
             - 弹窗刚打开时只下载默认激活 tab 的 chunk
             - 切到其它 tab 才按需下载对应 chunk
          2. display-directive="show:lazy" → 控制 DOM 实例生命周期
             - 首次激活前：不创建 DOM
             - 首次激活后：切走只 display:none 不销毁，切回保留状态
             - 关键好处：避免在 tab 间来回切时反复销毁重建 + 反复调接口
        -->
        <n-tab-pane
          v-for="tab in tabConfig"
          :key="tab.key"
          :name="tab.key"
          :tab="tab.label"
          display-directive="show:lazy"
        >
          <component :is="tabComponents[tab.key]" />
        </n-tab-pane>
      </n-tabs>
    </n-spin>
  </div>
</template>

<script setup lang="ts">
  import {
    ref,
    watch,
    onMounted,
    toRef,
    computed,
    defineAsyncComponent,
    markRaw,
    type Component,
    type PropType,
  } from 'vue';
  import { useI18n } from 'vue-i18n';
  import { useUser, useTenantOptions } from '@/hooks';
  import { useDictionary } from '@/components/DictSelect';
  import { provideMemberContext, type DetailData } from './useMemberContext';
  import { buildDetailData } from './basic/buildDetailData';

  // Tab 子组件（懒加载，配置驱动）
  // 双层懒加载：
  // 1. defineAsyncComponent 控制 chunk 下载时机（用户切到 tab 才下载该 tab 的 JS）
  // 2. n-tab-pane display-directive="show:lazy" 控制 DOM 创建时机
  type TabKey = 'basic' | 'dataStat' | 'deposit' | 'bet' | 'wallet' | 'fund' | 'log';

  const tabComponents: Record<TabKey, Component> = {
    basic: markRaw(defineAsyncComponent(() => import('./basic/BasicInfoTab.vue'))),
    // 数据统计 Tab：仅样板会员 1100002 展示（试点门控，见 tabConfig）；数据由 buildDetailData.dataStatSections 提供
    dataStat: markRaw(defineAsyncComponent(() => import('./basic/DataStatTab.vue'))),
    deposit: markRaw(defineAsyncComponent(() => import('./basic/DepositWithdrawTab.vue'))),
    bet: markRaw(defineAsyncComponent(() => import('./betting/BettingStatTab.vue'))),
    wallet: markRaw(defineAsyncComponent(() => import('./wallet/WalletTab.vue'))),
    fund: markRaw(defineAsyncComponent(() => import('./fund/FundRecordTab.vue'))),
    log: markRaw(defineAsyncComponent(() => import('./log/OperationLogTab.vue'))),
  };

  const props = defineProps({
    memberId: { type: [String, Number], required: true },
    tenantId: { type: Number, default: null },
    globalTimeRange: { type: Array as PropType<number[] | null>, default: null },
    queryVersion: { type: Number, default: 0 },
  });
  const emit = defineEmits(['update:lastWithdrawTime']);

  const { t } = useI18n();
  const { message, formatDateTimeStr, fetchMemberDetail } = useUser();
  const { formatTenantDateTime, getTenantLabel, getTenantTimeZoneLabel } = useTenantOptions();
  // 会员状态走公共字典 enableStateList（common 源）
  const { findLabel } = useDictionary();

  // Tab 配置（依赖 t，所以放在 useI18n 之后）
  const tabConfig = computed<{ key: TabKey; label: string }[]>(() => [
    { key: 'basic', label: t('member.detail.tabs.basic') },
    // 【已铺开·2026-07-14 用户确认】「数据统计」Tab 取代原「充提信息」Tab（充提明细已并入数据统计），
    // 原为样板 1100002 试点，验收后对全部会员生效。收回方式：改回按 memberId 三元取 deposit。
    { key: 'dataStat', label: t('member.detail.tabs.dataStat') },
    { key: 'bet', label: t('member.detail.tabs.bet') },
    { key: 'wallet', label: t('member.detail.tabs.wallet') },
    // 【已铺开·2026-07-14 用户确认】「账变记录」→「资金账变」（对齐财务·资金账变），原为样板试点，现全部会员生效。
    { key: 'fund', label: t('member.detail.tabs.fundSample') },
    { key: 'log', label: t('member.detail.tabs.log') },
  ]);

  const activeTab = ref<TabKey>('basic');
  const loading = ref(false);
  const lastWithdrawTime = ref<string>('');

  const detailData = ref<DetailData>({
    basicSections: [],
    dataStatSections: [],
    depositInfo: [],
    withdrawInfo: [],
    recentDeposits: [],
    recentWithdraws: [],
    walletSections: [],
  });

  // ============ 注入共享状态给所有 Tab 子组件 ============
  provideMemberContext({
    memberId: toRef(props, 'memberId'),
    tenantId: toRef(props, 'tenantId'),
    globalTimeRange: toRef(props, 'globalTimeRange'),
    activeTab,
    detailData,
    lastWithdrawTime,
    queryVersion: toRef(props, 'queryVersion'),
  });

  // ============ 时间范围解析 ============
  function resolveTimeRange(tabRange) {
    const range =
      Array.isArray(tabRange) && tabRange.length === 2 ? tabRange : props.globalTimeRange;
    if (!Array.isArray(range) || range.length !== 2) return {};
    const startTime = formatDateTimeStr(range[0]);
    const endTime = formatDateTimeStr(range[1]);
    if (!startTime || !endTime) return {};
    return { startTime, endTime };
  }

  // ============ 加载会员详情 ============
  async function loadMemberDetail(userId, startTime?, endTime?) {
    if (!userId) return;
    loading.value = true;
    try {
      // 嵌入弹窗时使用 props.tenantId（订单/会员所属商户）
      const data = await fetchMemberDetail(userId, {
        startTime,
        endTime,
        tenantId: props.tenantId ?? null,
      });
      // 接口异常时拦截器已弹提示，此处不再重复
      if (!data) return;
      const memberTenantId = props.tenantId ?? data.tenantId;
      detailData.value = buildDetailData(data, {
        t,
        formatTenantDateTime,
        getTenantLabel,
        tenantTimeZoneLabel: getTenantTimeZoneLabel(memberTenantId),
        findLabel,
      });
      lastWithdrawTime.value = data.lastWithdrawTime || '';
      emit('update:lastWithdrawTime', lastWithdrawTime.value);
    } catch (e) {
      console.error('加载会员详情失败', e);
      message.error(t('member.detail.loadFailed'));
    } finally {
      loading.value = false;
    }
  }

  // 初始加载
  onMounted(() => {
    const { startTime, endTime } = resolveTimeRange(null);
    loadMemberDetail(props.memberId, startTime, endTime);
  });

  // 父组件触发重新查询（同一会员，新时间范围）
  // 基本信息/充提信息 tab 需要重新加载会员详情；其他 tab 由 useQueryReload 自行刷新表格
  watch(
    () => props.queryVersion,
    () => {
      if (
        activeTab.value === 'basic' ||
        activeTab.value === 'deposit' ||
        activeTab.value === 'dataStat'
      ) {
        const { startTime, endTime } = resolveTimeRange(null);
        loadMemberDetail(props.memberId, startTime, endTime);
      }
    },
  );
</script>

<style lang="less" scoped>
  .member-detail-content {
    // 穿透 Naive UI 与 Pro 组件内部节点
    ::v-deep(.n-tab-pane) {
      height: calc(90vh - 140px);
      overflow-y: auto;
    }
    ::v-deep(.pro-crud-table) {
      padding: 0 12px;
    }
    // 阻止表格滚动冒泡到弹窗容器，防止抖动
    ::v-deep(.n-data-table .n-scrollbar-container) {
      overscroll-behavior: contain;
    }
    ::v-deep(.pro-search-form) {
      padding: 8px 0;
      .n-date-picker {
        min-width: 280px;
      }
    }
    ::v-deep(.pro-search-form-actions) {
      padding-right: 8px;
    }

    // 穿透子 Tab 组件使用的业务类
    ::v-deep(.fund-quick-actions) {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 4px 0;
    }
    ::v-deep(.fund-quick-dates) {
      display: flex;
      gap: 4px;
      margin-right: 12px;
    }

    ::v-deep(.detail-sections) {
      display: flex;
      flex-direction: column;
      gap: 16px;
    }
    ::v-deep(.detail-section) {
      border: 1px solid #f0f0f0;
      border-radius: 8px;
      padding: 12px;
      background: #fff;
    }
    ::v-deep(.detail-section__header) {
      display: flex;
      align-items: center;
      justify-content: space-between;
      margin-bottom: 10px;
    }
    ::v-deep(.detail-section__title) {
      margin: 0;
      font-size: 13px;
      font-weight: 600;
      color: #111827;
    }
    ::v-deep(.detail-section__header + .detail-grid) {
      margin-top: 0;
    }
    ::v-deep(.detail-section__title:not(.detail-section__header .detail-section__title)) {
      margin-bottom: 10px;
    }

    ::v-deep(.detail-grid) {
      display: grid;
      gap: 1px;
      background: #f0f0f0;
      border-radius: 6px;
      overflow: hidden;
    }
    ::v-deep(.detail-grid__subheader) {
      padding: 8px 10px 4px;
      font-size: 12px;
      font-weight: 600;
      color: #374151;
      background: #f0f5ff;
      border-bottom: 1px solid #d6e4ff;
    }

    /* 「一页看完·每版块一列 + masonry」（仅样板 1100002·门控 detail-sections--onepage）：版块用多列 masonry 竖向填满一屏、每块内部字段单列往下排；风控整行。 */
    ::v-deep(.detail-sections.detail-sections--onepage) {
      display: block;
      column-count: 4;
      column-gap: 8px;
    }
    ::v-deep(.detail-sections--onepage .detail-section) {
      break-inside: avoid;
      margin-bottom: 8px;
      padding: 5px 8px;
    }
    /* 风控(特制复合布局)独占整行、不参与 masonry */
    ::v-deep(.detail-sections--onepage .detail-section--wide) {
      column-span: all;
    }
    /* 代理数据不与紧随的打码/洗码拆列（#3 两块同列） */
    ::v-deep(.detail-sections--onepage .detail-section--keep-next) {
      break-after: avoid;
    }
    /* 版块标题·居左（原居中，2026-07-13 用户要求全部版块标题居左展示） */
    ::v-deep(.detail-sections--onepage .detail-section__header) {
      margin-bottom: 3px;
      justify-content: flex-start;
    }
    /* 标题色不再覆盖：回落上方 .detail-section__title 的 #111827，与其它版块/页面同款默认黑
       （2026-07-16 用户要求由红 #dc2626 改回默认黑；红色非归因语义、仅为强调，改后同向 R65） */
    ::v-deep(.detail-sections--onepage .detail-section__title) {
      text-align: left;
      font-weight: 600;
      font-size: 13px;
      white-space: nowrap;
    }
    /* 单元格：「标题:值」成对一行(照目标图) */
    ::v-deep(.detail-sections--onepage .detail-cell) {
      padding: 3px 8px;
      line-height: 1.4;
      font-size: 12px;
    }
    /* 每块内部字段单列往下排(每个版块就一列)；标题列按最长标题取齐、数值统一居左对齐(subgrid #6) */
    ::v-deep(.detail-sections--onepage .detail-section:not(.detail-section--wide) .detail-grid) {
      grid-auto-flow: row !important;
      grid-template-columns: max-content 1fr !important;
      grid-template-rows: none !important;
      column-gap: 0 !important;
    }
    ::v-deep(
        .detail-sections--onepage
          .detail-section:not(.detail-section--wide)
          .detail-cell:not(.detail-cell--compound)
      ) {
      display: grid !important;
      grid-template-columns: subgrid;
      grid-column: 1 / -1 !important;
      align-items: baseline;
    }
    /* 风控复合格(值+同登录数)竖版：占整列宽、保留内部 flex（压过残留 span） */
    ::v-deep(.detail-sections--onepage .detail-section:not(.detail-section--wide) .detail-cell--compound) {
      grid-column: 1 / -1 !important;
    }
    ::v-deep(.detail-sections--onepage .detail-section:not(.detail-section--wide) .detail-cell__value) {
      justify-self: start;
      text-align: left;
    }
    ::v-deep(.detail-sections--onepage .detail-cell__value) {
      word-break: normal;
      overflow-wrap: anywhere;
    }
    /* 用户备注（样板 1100002·onepage）：值撑满 1fr 列——默认 justify-self:start 会让值按内容收缩，
       导致内部 flex 无多余空间：「修改」按钮 margin-left:auto 推不动(不居右)、单行省略 span 无宽度约束(不截断)。
       仅带 ellipsis 的值单元格(.detail-cell__value--fill=用户备注)改回 stretch 撑满，恢复「按钮居右 + 一行省略」；
       不影响其它字段的「数值居左取齐」。 */
    ::v-deep(.detail-sections--onepage .detail-cell__value--fill) {
      justify-self: stretch !important;
      min-width: 0;
    }

    ::v-deep(.detail-cell) {
      display: flex;
      flex-direction: row;
      align-items: baseline;
      gap: 0;
      padding: 7px 10px;
      background: #fafbfc;
    }
    // 「上下结构」修饰：标题在上、值在下（会员风控·最后3次登录明细用，长设备/指纹值不被挤、换行居左 R41）
    ::v-deep(.detail-cell--stack) {
      flex-direction: column;
      align-items: flex-start;
      gap: 2px;
    }
    ::v-deep(.detail-cell--stack .detail-cell__label) {
      &::after {
        content: '';
      }
    }
    // 复合格：左值(上下) + 右侧「同登录X数」计数，非独立列（会员风控最后3次登录）
    ::v-deep(.detail-cell--compound) {
      flex-direction: row;
      align-items: center;
      justify-content: space-between;
      gap: 10px;
    }
    ::v-deep(.detail-cell--compound .detail-cell__main) {
      display: flex;
      flex-direction: column;
      align-items: flex-start;
      gap: 2px;
      min-width: 0;
    }
    ::v-deep(.detail-cell--compound .detail-cell__main .detail-cell__label) {
      &::after {
        content: '';
      }
    }
    ::v-deep(.detail-cell__side) {
      display: flex;
      flex-direction: column;
      align-items: flex-end;
      gap: 2px;
      flex-shrink: 0;
      text-align: right;
    }
    ::v-deep(.detail-cell__side-label) {
      font-size: 12px;
      color: #8c8c8c;
      white-space: nowrap;
    }
    ::v-deep(.detail-cell__side-value) {
      font-size: 13px;
      font-weight: 500;
      color: #262626;
    }
    // 可点计数数字与上方注册计数同色（蓝链 #2563eb）；双类高特异性压过 __side-value 深灰
    ::v-deep(.detail-cell__side-value.detail-cell__link) {
      color: #2563eb;
    }
    ::v-deep(.detail-cell__label) {
      flex: 0 0 auto;
      font-size: 12px;
      color: #8c8c8c;
      white-space: nowrap;
      line-height: 1.5;
      &::after {
        content: '：';
        color: #d9d9d9;
      }
    }
    // 「改」标：标记本轮改过名的字段，与「新」标同款低调风格、改用低饱和蓝以区分
    ::v-deep(.ar-changemark) {
      display: inline-flex;
      align-items: center;
      margin-left: 4px;
      padding: 0 5px;
      font-size: 10px;
      line-height: 15px;
      font-weight: 400;
      letter-spacing: 0.5px;
      color: #4a72c0;
      background: #eef2fb;
      border-radius: 3px;
    }
    ::v-deep(.detail-cell--spacer) {
      background: #fafbfc;
      pointer-events: none;
    }
    ::v-deep(.detail-cell__value) {
      flex: 1;
      min-width: 0;
      font-size: 13px;
      font-weight: 500;
      color: #262626;
      display: flex;
      align-items: center;
      line-height: 1.5;
      word-break: break-all;
    }

    ::v-deep(.deposit-split) {
      display: grid;
      grid-template-columns: repeat(2, 1fr);
      gap: 16px;
    }
    ::v-deep(.deposit-split__card) {
      display: flex;
      flex-direction: column;
    }
    ::v-deep(.deposit-split__card-title) {
      margin-bottom: 10px;
    }
    ::v-deep(.deposit-split__overview) {
      grid-template-columns: repeat(2, minmax(0, 1fr));
    }
    ::v-deep(.deposit-split__recent) {
      margin-top: auto;
    }
    ::v-deep(.deposit-split__divider) {
      height: 1px;
      background: #f0f0f0;
      margin: 12px 0;
    }
    ::v-deep(.deposit-split__sub-title) {
      margin: 0 0 8px;
      font-size: 12px;
      font-weight: 600;
      color: #595959;
    }

    ::v-deep(.highlight--primary) {
      color: #117bea;
    }
    ::v-deep(.highlight--success) {
      color: #16a34a;
    }
    ::v-deep(.highlight--warning) {
      color: #d97706;
    }
    ::v-deep(.highlight--error) {
      color: #dc2626;
    }
    ::v-deep(.highlight--bold) {
      font-weight: 600;
    }
    ::v-deep(.highlight--info) {
      color: #0284c7;
    }

    ::v-deep(.bet-tab-section) {
      border: 1px solid #f0f0f0;
      border-radius: 8px;
      padding: 12px;
      background: #fff;
    }
    ::v-deep(.bet-tab-section__title) {
      margin: 0 0 12px;
      font-size: 13px;
      font-weight: 600;
      color: #111827;
    }

    ::v-deep(.wallet-grid) {
      display: grid;
      grid-template-columns: repeat(2, 1fr);
      gap: 16px;
    }
    ::v-deep(.wallet-section) {
      border: 1px solid #e8e8e8;
      border-radius: 8px;
      padding: 12px;
      background: #fff;
    }
    ::v-deep(.wallet-section__header) {
      display: flex;
      align-items: center;
      justify-content: space-between;
      margin-bottom: 10px;
      padding-bottom: 8px;
      border-bottom: 1px solid #f0f0f0;
    }
    ::v-deep(.wallet-section__title) {
      margin: 0;
      font-size: 13px;
      font-weight: 600;
      color: #111827;
    }
    ::v-deep(.wallet-card-list) {
      display: grid;
      grid-template-columns: repeat(2, 1fr);
      gap: 8px;
    }
    ::v-deep(.wallet-card) {
      border: 1px solid #f0f0f0;
      border-radius: 6px;
      overflow: hidden;
      transition: box-shadow 0.2s;
      &:hover {
        box-shadow: 0 1px 4px rgba(0, 0, 0, 0.06);
      }
    }
    ::v-deep(.wallet-card__header) {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 5px 10px;
      background: #fafafa;
      border-bottom: 1px solid #f0f0f0;
      font-size: 12px;
      color: #595959;
    }
    ::v-deep(.wallet-card__id strong) {
      color: #262626;
    }
    ::v-deep(.wallet-card__body) {
      padding: 2px 0;
    }
    ::v-deep(.wallet-card__row) {
      display: flex;
      padding: 3px 10px;
      font-size: 12px;
      border-bottom: 1px solid #fafafa;
      &:last-child {
        border-bottom: 0;
      }
    }
    ::v-deep(.wallet-card__label) {
      flex: 0 0 90px;
      color: #8c8c8c;
    }
    ::v-deep(.wallet-card__value) {
      flex: 1;
      color: #262626;
      word-break: break-all;
    }

    @media (max-width: 1200px) {
      ::v-deep(.deposit-split),
      ::v-deep(.wallet-grid) {
        grid-template-columns: 1fr;
      }
    }
  }
</style>
