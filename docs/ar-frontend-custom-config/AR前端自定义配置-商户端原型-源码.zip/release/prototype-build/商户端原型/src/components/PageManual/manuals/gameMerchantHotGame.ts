// 热门游戏配置（商户端 tenant · game_merchant_hot_game）功能说明书。
// 锚定 src/views/game/merchant/hotGame/index.vue + data.ts 真实控件（R53 实证、不臆造）。
// R64：本页 roles:['tenant']。标准 ProCrudTable 列表页：2 搜索项 + 6 列（含前台显示开关）+ 1 行操作（编辑）。

import type { PageManual } from '../types';

const manual: PageManual = {
  route: 'game_merchant_hot_game',
  title: '热门游戏配置',
  overview:
    '商户端配置 C 端「热门游戏」展示：按游戏名称、游戏厂商筛选，可切换单个游戏的 C端展示（开关）、查看大类与推荐排序、编辑。控制玩家端热门游戏区的呈现。⚠️ 本页数据为全平台共用一份（ALL_LIST 无 merchantId 维度、不区分商户）。',
  items: [
    // ============ 搜索区 ============
    {
      anchor: 'gameName',
      name: '游戏名称',
      group: '搜索',
      interaction: '文本输入、模糊匹配。',
      dataSource: '用户输入。',
      logic: '按游戏名称筛选。',
      limit: '选填（代码未设长度上限）。',
      edge: '空 = 不按游戏名筛。',
    },
    {
      anchor: 'vendor',
      name: '游戏厂商',
      group: '搜索',
      interaction: '文本输入、模糊匹配。',
      dataSource: '用户输入。',
      logic: '按游戏厂商筛选。',
      limit: '选填。',
      edge: '空 = 不按厂商筛。',
    },

    // ============ 关键列（前台显示开关）============
    {
      anchor: 'col_frontendShow',
      name: 'C端展示列',
      group: '列',
      interaction: '开关（ConfirmSwitch，带二次确认），可直接点切换。',
      dataSource: '行数据 frontendShow（1 显示 / 0 隐藏）。',
      logic: '这是改该游戏前台显示的入口（本列符合 R47 用开关）；切换即调 api.merchantHotGame.updateFrontendShow。',
    },

    // ============ 行操作 ============
    {
      anchor: 'act_edit',
      name: '行操作 · 编辑',
      group: '操作',
      interaction: '点击进入编辑。',
      logic: '当前为骨架占位（handleEdit 仅弹提示回显游戏名），完整编辑功能待补。',
    },
  ],

  // ============ 字段介绍 tab（列序照页面；仅列表列 + 定义）============
  fields: [
    { name: '游戏名称', def: '热门游戏的名称。' },
    { name: '游戏厂商', def: '该游戏所属的厂商。' },
    { name: '游戏大类', def: '该游戏所属的游戏大类（着色 Tag）。' },
    { name: '推荐排序', def: '该游戏在热门区的展示位次（真实列头 i18n = 推荐排序）。' },
    { name: 'C端展示', def: '该游戏是否在 C 端热门区展示：展示 / 隐藏（真实列头 i18n = C端展示）。' },
    { name: '更新时间', def: '配置最近一次更新时间。' },
  ],
};

export default manual;
