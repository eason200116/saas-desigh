// 会员银行卡（商户端 tenant · member_bank_card）功能说明书。
// 锚定 src/views/member/bankCard/index.vue 容器 + 5 个子 Tab（bankCard/usdt/cpf/wallet/upi）各自的
// index.vue/data.ts + 共用编辑弹窗 src/components/MemberWalletModals/*.vue 真实控件（R53 实证、不臆造）。
// 容器页只是 n-tabs 壳（读 route.meta.tabs），5 个子 Tab 各自独立的搜索表单+表格+新增/编辑/删除，
// 靠"银行卡信息/USDT地址/PIX钱包/电子钱包信息/UPI信息"5个标签页组织——区别于「同IP检测」那种单表多维度换皮。

import type { PageManual } from '../types';

const manual: PageManual = {
  route: 'member_bank_card',
  title: '会员银行卡管理',
  overview:
    '商户端「会员管理 › 会员银行卡」页，容器是一个 5 标签页壳（银行卡信息 / USDT地址 / PIX钱包 / 电子钱包信息 / UPI信息），每个标签页是完全独立的搜索表单 + 列表 + 新增/编辑/删除，只是共用同一套新增/编辑弹窗组件（src/components/MemberWalletModals/，该目录同时被「本地支付账号」「会员详情-钱包信息」两处复用）。支持两种嵌入场景：①提现工作台订单详情弹窗直接嵌入整个 5 Tab 容器；②会员详情弹窗内嵌时通过上下文锁定商户不可改、不同步 URL。2026-07-21 已修复：①银行卡/USDT/PIX钱包/电子钱包 4 个 Tab 新增弹窗里"类型"下拉此前恒空导致必填校验无法通过的问题（根因是共用弹窗的 fetchBankList/useTypeOptions 引用了占位 Proxy，现已按各子页真实行数据补齐枚举）；②UPI信息 Tab「UPI类型」下拉此前因 V1_DICTIONARY 缺 upiList key 而为空，现已补齐；③银行卡信息 Tab 搜索区邮箱/手机号/省/市/分行 5 个此前"能填不生效"的字段现已接入过滤逻辑；④5 个 Tab 的新增/编辑/删除此前提交后均假成功、不会真正写回/移除内存数据，现已改造成真正的内存态写入（新增/编辑/删除 reload 后均可见效果，同「分组管理」页模式，硬刷新页面重置为初始 mock）。i18n 里备好但从未被引用的 member.bankCard.noApiTip 提示语，因保存已真实生效，本次未接入（接入会与实际行为矛盾）。',
  items: [
    // ============ 页顶：Tab 切换 ============
    {
      anchor: 'tab_switch',
      name: '5 个子页 Tab 切换（银行卡信息 / USDT地址 / PIX钱包 / 电子钱包信息 / UPI信息）',
      group: '操作',
      interaction:
        '点顶部 Tab 切换，5 个 Tab 各自独立的搜索表单 + 列表 + 新增/编辑/删除，不是同一张表换维度。',
      dataSource: '从当前路由 meta.tabs 读取配置（useRouteTabs），按权限/show 过滤（本页 5 个 Tab 均未设限，恒可见）。',
      logic:
        '默认 keepAlive（各 Tab 切走后状态不丢，含分页/筛选）；独立路由访问时当前 Tab 同步进 URL query，可直接带 query 定位到指定 Tab；嵌入弹窗模式下（embed=true）不同步 URL，只在组件本地记录当前 Tab。',
      note: '容器组件 src/views/member/bankCard/index.vue 本身只是壳，不含独立业务控件；实际控件都在各 Tab 自己的 index.vue 里。',
    },

    // ============ 5 个 Tab 共用的「商户」「会员ID」============
    {
      anchor: 'merchant',
      name: '商户（5 个 Tab 均有，规则一致）',
      group: '搜索',
      interaction: '下拉单选（商户选择器，架构级不可清空，见《交互规范》§3）。',
      dataSource: '全站商户列表。',
      logic:
        '按选中商户过滤当前 Tab 的记录列表；嵌入模式下（来自会员详情/提现工单）强制回显宿主上下文商户并禁用，不可跨商户查询。',
      limit: '必填（红星 showRequireMark + requiredRule）；单选、不可清空——命中 R63。',
      edge:
        '五个 Tab 实现方式不完全一致但对用户表现一致：「银行卡信息」Tab 走 merchantSearchColumn() + MerchantFilterSelect 组件；其余 4 个 Tab 走 valueType: tenantSelect 直接声明，两条代码路径但校验规则/交互效果相同，如实记录这一实现层差异。',
    },
    {
      anchor: 'userId',
      name: '会员ID（5 个 Tab 均有）',
      group: '搜索',
      interaction: '文本输入。',
      dataSource: '用户输入。',
      logic: '按会员ID精确匹配过滤当前 Tab 的记录。',
      limit: '选填；仅允许输入数字字符（allowInput: onlyDigits 过滤非数字按键，不限位数——不是 inputConstraints 的 intNum 预设）。',
      edge: '空 = 不按会员ID筛，只按商户等其它条件。',
    },
    {
      anchor: 'col_userId',
      name: '会员ID列（5 个 Tab 均有，行为一致）',
      group: '列',
      interaction: '数字以可点击蓝字链接形式展示（跳转类控件，非纯展示）。',
      dataSource: '行数据 userId + tenantId。',
      logic: '点击调用 openMemberDetailModal(userId, tenantId) 打开会员详情弹窗（renderMemberIdLink，全站统一的会员ID可点规范）。',
    },

    // ============ Tab①银行卡信息 ============
    {
      anchor: 'bc_beneficiaryName',
      name: '姓名（银行卡信息 Tab，搜索区）',
      group: '搜索',
      interaction: '文本输入。',
      dataSource: '用户输入。',
      logic: '按持卡人姓名模糊匹配（不区分大小写 includes）过滤，mock 已真正接入。',
      limit: '选填；无预设长度限制（普通 clearable 文本框，未接入 inputConstraints 任何预设）。',
    },
    {
      anchor: 'bc_accountNo',
      name: '卡号（银行卡信息 Tab，搜索区）',
      group: '搜索',
      interaction: '文本输入。',
      dataSource: '用户输入。',
      logic: '按卡号子串匹配（includes）过滤，mock 已真正接入。',
      limit: '选填；无预设长度限制。',
    },
    {
      anchor: 'bc_bankName',
      name: '银行名称（银行卡信息 Tab，搜索区）',
      group: '搜索',
      interaction: '下拉单选（AsyncSelect，可搜索可清空）。',
      dataSource: '该 Tab 自己 data.ts 的 getBankTypeList（真实银行枚举：State Bank of India / HDFC Bank / Banco do Brasil 等）。',
      logic: '按选中银行 ID 精确过滤，mock 已真正接入。',
      edge:
        '2026-07-21 已修复：此前弹窗里同名「银行名称」下拉走的是另一套占位 api 引用（组件目录 MemberWalletModals/data.ts）而为空，现已在该占位文件加 override，与本 Tab 搜索区用的银行枚举保持一致（均为 State Bank of India / HDFC Bank / Banco do Brasil 等 6 家），两处下拉仍是两份独立常量（未做成共享导入）但值已对齐。',
    },
    {
      anchor: 'bc_deadFilters',
      name: '邮箱 / 手机号 / 省 / 市 / 分行（银行卡信息 Tab，搜索区）',
      group: '搜索',
      interaction: '均为文本输入框，可正常输入、清空。',
      dataSource: '用户输入。',
      logic:
        '按对应字段过滤列表（email/分行地址不区分大小写子串匹配，手机号/省/市代码精确子串匹配），2026-07-21 已接入。',
      limit: '选填；无预设长度限制。',
      edge:
        '2026-07-21 已修复：此前这 5 个字段的值会组装进查询请求，但 mock 查询函数 getUserBankCardPageList 并未读取，填了点查询不影响结果；现已补上对应过滤逻辑（其余 4 个 Tab 经逐一核对，各自的搜索参数原本就被 mock 真正使用，无此问题，是本 Tab 独有的历史缺口）。',
    },
    {
      anchor: 'bc_add',
      name: '新增银行卡（银行卡信息 Tab）',
      group: '操作',
      interaction:
        '点「新增银行卡」按钮打开弹窗（BankCardEditModal，约 600px），填写商户/会员ID/银行名称/姓名/卡号/手机号/IFSC Code/邮箱/省/市/分行后点确认。',
      dataSource: '弹窗内「银行名称」下拉走 AsyncSelect + fetchBankList 异步请求。',
      logic: '商户/会员ID/银行名称/姓名/卡号为必填；提交调用新增接口，成功后关闭弹窗并刷新列表。',
      limit: '会员ID仅数字（正则校验 + userIdIntegerOnly 提示）；其余必填项为非空校验，无格式/长度限制。',
      edge:
        '2026-07-21 已修复①：弹窗内「银行名称」下拉 fetchBankList 此前引用 MemberWalletModals/data.ts 的占位 Proxy（恒返回 data:null）导致选项为空、必填项无法通过校验；现已在该占位文件加 override 返回真实银行枚举，新增可正常选中银行并提交。②提交时命中的 addUserBankCard 此前是占位 Proxy 方法恒假成功、不会真正写入列表数据，现已改造成真正写入本 Tab 内存列表（BANK_CARDS），新增行 reload 后可见。核实过程中另发现一处不相关的既有问题（未修，如实记录）：列表「IFSC Code」列渲染读取 row.ifscCode，但行数据实际字段名是 bankCode（弹窗表单 ifscCode 值已按此存入），该列因取错字段名恒显示"--"，非本次引入、已提交给用户评估是否单独修复。',
    },

    // ============ Tab②USDT地址 ============
    {
      anchor: 'usdt_protocol',
      name: '网络协议（USDT地址 Tab，搜索区）',
      group: '搜索',
      interaction: '下拉单选（可清空）。',
      dataSource: 'useTypeOptions().usdtOptions，按商户异步加载。',
      logic: '按协议类型（TRC20/ERC20/BEP20）过滤，参数本身被 mock 正确读取。',
      edge:
        '2026-07-21 已修复：该下拉的数据源 useTypeOptions.ts 内部 api 此前引用 MemberWalletModals/data.ts 占位 Proxy 恒返回空数组；现已加 override 返回 TRC20/ERC20/BEP20 三个真实协议，搜索筛选可正常生效。',
    },
    {
      anchor: 'usdt_accountNo',
      name: '钱包地址（USDT地址 Tab，搜索区）',
      group: '搜索',
      interaction: '文本输入。',
      dataSource: '用户输入。',
      logic: '按钱包地址子串匹配过滤，mock 已真正接入。',
      limit: '选填；无预设长度限制。',
    },
    {
      anchor: 'usdt_add',
      name: '新增USDT地址（USDT地址 Tab）',
      group: '操作',
      interaction: '点「新增USDT地址」打开弹窗（UsdtEditModal），填商户/会员ID/网络协议/钱包地址/地址别称后确认。',
      logic: '商户/会员ID/网络协议/钱包地址必填；提交后关闭弹窗刷新列表。',
      limit: '会员ID仅数字；其余必填项仅非空校验。',
      edge:
        '2026-07-21 已修复：「网络协议」下拉选项此前为空（见 usdt_protocol）阻塞必填校验，现已修复，新增可正常选出协议并提交；保存此前命中占位 Proxy 假成功，现已改为真正写入本 Tab 内存列表（USDT_LIST），新增行 reload 后可见。表单「地址别称」(alias) 字段行数据结构中无对应位置存放，如实不落（非本次引入，列表本就没有该展示列）。',
    },

    // ============ Tab③PIX钱包 ============
    {
      anchor: 'cpf_fields',
      name: '钱包类型 / CPF / PIX账号 / 姓名（PIX钱包 Tab，搜索区）',
      group: '搜索',
      interaction: '钱包类型为下拉单选（可清空），其余 3 项为文本输入。',
      dataSource:
        '钱包类型来自 useTypeOptions().cpfOptions（i18n label 为「钱包类型」，实际枚举 PHONE/CPF/EMAIL/CNPJ/Random 五种 PIX key 类型）；其余用户输入。',
      logic: '四项均已被 mock 查询函数真正使用（tenantId/userId 外，cpf/accountNo/beneficiaryName/bankId 全部生效）。',
      limit: '文本类字段选填、无预设长度限制。',
      edge:
        '2026-07-21 已修复：「钱包类型」下拉与 usdt_protocol 同一根因（useTypeOptions 走占位 Proxy），现已加 override 返回 PHONE/CPF/EMAIL/CNPJ/Random 五个真实类型，搜索筛选可正常生效。',
    },
    {
      anchor: 'cpf_add',
      name: '新增PIX钱包（PIX钱包 Tab）',
      group: '操作',
      interaction: '点「新增PIX钱包」打开弹窗（CpfEditModal），填商户/会员ID/钱包类型/PIX账号/CPF/姓名后确认。',
      logic: '商户/会员ID/钱包类型/PIX账号必填；提交后关闭弹窗刷新列表。',
      limit: '会员ID仅数字；其余必填项仅非空校验。',
      edge:
        '2026-07-21 已修复：「钱包类型」下拉此前为空阻塞必填校验，现已修复，新增可正常选类型并提交；保存此前命中占位 Proxy 不真正落库，现已改为真正写入本 Tab 内存列表（CPF_LIST），新增行 reload 后可见。',
    },

    // ============ Tab④电子钱包信息 ============
    {
      anchor: 'wallet_fields',
      name: '钱包类型、账号/手机（电子钱包信息 Tab，搜索区）',
      group: '搜索',
      interaction: '钱包类型下拉单选（可清空），账号/手机为文本输入。',
      dataSource:
        '钱包类型来自 useTypeOptions().walletOptions 并过滤掉标签含"UPI"的选项（UPI 有独立 Tab，本 Tab 枚举为 KBZpay/NAGAD/GCash/PayMaya/GrabPay）；账号/手机用户输入。',
      logic: '两项均被 mock 真正使用过滤。',
      limit: '账号/手机选填、无预设长度限制。',
      edge:
        '2026-07-21 已修复：「钱包类型」下拉此前因 useTypeOptions 占位 Proxy 而选项为空，现已加 override 返回 KBZpay/NAGAD/GCash/PayMaya/GrabPay 五个真实类型，搜索筛选可正常生效。',
    },
    {
      anchor: 'wallet_add',
      name: '新增电子钱包（电子钱包信息 Tab）',
      group: '操作',
      interaction: '点「新增电子钱包」打开弹窗（WalletEditModal），填商户/会员ID/钱包类型/姓名/账号-手机后确认。',
      logic: '商户/会员ID/钱包类型/姓名/账号-手机均必填；提交后关闭弹窗刷新列表。',
      limit: '会员ID仅数字；其余必填项仅非空校验。',
      edge:
        '2026-07-21 已修复：「钱包类型」下拉此前为空阻塞必填校验，现已修复，新增可正常选类型并提交；保存此前命中占位 Proxy 不真正落库，现已改为真正写入本 Tab 内存列表（WALLET_LIST），新增行 reload 后可见。表单字段 accountNo 存入行数据 phoneOrAccount 属性，与既有搜索过滤同一套映射（非本次引入）。',
    },

    // ============ Tab⑤UPI信息 ============
    {
      anchor: 'upi_fields',
      name: 'UPI类型 / UPI ID（UPI信息 Tab，搜索区）',
      group: '搜索',
      interaction: 'UPI类型下拉单选（可清空），UPI ID 为文本输入。',
      dataSource: "UPI类型走 useUser().getOptions('upiList')（v1 字典），非 useTypeOptions；UPI ID 用户输入。",
      logic: '两项均被 mock 真正使用过滤。',
      limit: 'UPI ID 选填、无预设长度限制。',
      edge:
        "2026-07-21 已修复：与其它 3 个 Tab 根因不同——UPI类型走的是 v1 字典 key 'upiList'，此前 V1_DICTIONARY 里未定义该 key 导致选项为空；现已补齐 GooglePay/PhonePe/Paytm/BHIM 四个真实类型（与 upi/data.ts 行数据 withType 对齐），搜索筛选可正常生效。",
    },
    {
      anchor: 'upi_add',
      name: '新增UPI（UPI信息 Tab）',
      group: '操作',
      interaction:
        '点「新增UPI」打开弹窗（UpiEditModal），填商户/会员ID/UPI类型/姓名/UPI ID/手机号/KYC-银行编码后确认。',
      logic:
        '商户/会员ID/姓名/UPI ID 必填；UPI ID 需含"@"符号、限50字内；选中「Fast UPI」类型时手机号与KYC-银行编码动态转为必填（其它类型下二者选填）。',
      limit: 'UPI ID：必填+含@+≤50字；Fast UPI 场景下手机号/KYC编码必填。',
      edge:
        '与其它 4 个 Tab 不同：本 Tab「UPI类型」字段本身不是必填项，此前即使下拉选项为空也不阻塞提交，是 5 个 Tab 里唯一新增流程原本就能在 UI 层走完校验的。2026-07-21 现状更新：upiList 字典已补齐（见 upi_fields）为 GooglePay/PhonePe/Paytm/BHIM 四个真实值，但均不含"Fast"字样，故 Fast UPI 触发的手机号/KYC编码动态必填规则目前仍不会被触发——本次只按需求范围补齐字典缺项，未额外新增"Fast UPI"这个字典值，如实记录待评估。提交此前命中占位 Proxy 恒假成功，现已改为真正写入本 Tab 内存列表（UPI_LIST），新增行 reload 后可见。',
    },

    // ============ 编辑 / 删除（5 个 Tab 共用同一套模式） ============
    {
      anchor: 'edit_shared',
      name: '编辑（5 个 Tab 共用同一套交互模式）',
      group: '操作',
      interaction: '点行内「编辑」打开对应 Tab 的编辑弹窗，预填当前行数据；字段集合与「新增」完全一致，只是 mode=edit。',
      logic:
        '商户/会员ID 编辑态下锁定为只读（disabled，不可改归属）；其余字段可改；校验规则与新增相同；提交调用对应 updateUserXxx 接口。',
      edge:
        '2026-07-21 已修复：①「类型」类下拉此前选项为空，改选其它类型时选不出新值，现已修复，编辑时可正常改选任意类型；②保存此前同样命中 MemberWalletModals 占位 Proxy 假成功、不会真正写回该行数据，现已改为按 bId 定位并真正更新对应 Tab 的内存列表，编辑结果 reload 后可见（商户/会员ID 仍锁定只读，不受影响）。',
    },
    {
      anchor: 'delete_shared',
      name: '删除（5 个 Tab 共用同一套交互模式）',
      group: '操作',
      interaction: "点行内「删除」，弹二次确认框（ActionConfig type: 'delete' 内置行为）。",
      logic: '确认后调用对应 deleteUserXxx / deleteUPI 接口。',
      edge:
        '2026-07-21 已修复：此前 5 个 Tab 各自的 deleteUserXxx mock 实现都只是直接返回成功、并未从本地数组移除该行，点确认后提示"删除成功"但该行仍在；现已改为按 bId 定位并真正从对应 Tab 的内存列表移除，删除后 reload 列表条数同步减少。',
    },
  ],

  // ============ 字段介绍 tab（仅列表列定义；5 个 Tab 通用列写一次，其余按 Tab 前缀区分）============
  fields: [
    { name: '商户（5 个 Tab 通用）', def: '该条记录所属商户，标签形式展示。' },
    { name: '会员ID（5 个 Tab 通用）', def: '记录所属会员，可点击蓝字跳转会员详情弹窗（renderMemberIdLink）。' },
    { name: '创建时间（5 个 Tab 通用）', def: '该条记录的新增时间，按所属商户时区显示。' },
    { name: '最后修改人（5 个 Tab 通用）', def: '最近一次编辑该记录的操作人账号。' },
    { name: '最后修改时间（5 个 Tab 通用）', def: '最近一次编辑该记录的时间，按所属商户时区显示。' },

    { name: '「银行卡信息」姓名', def: '持卡人姓名，明文全量展示，未脱敏。' },
    { name: '「银行卡信息」卡号', def: '银行卡号，明文全量展示，未脱敏。' },
    { name: '「银行卡信息」银行名称', def: '开户银行名称（如 State Bank of India）。' },
    {
      name: '「银行卡信息」手机号',
      def: '预留联系手机号，脱敏展示：保留"+区号"与号码主体前3位，中间打****，保留后4位（如 +86 138****8000）。',
    },
    { name: '「银行卡信息」IFSC Code', def: '印度银行系统的支行识别码，明文展示。' },
    { name: '「银行卡信息」邮箱', def: '预留联系邮箱，脱敏展示：本地名保留前3位 + **** + 完整@域名。' },
    { name: '「银行卡信息」省 / 市 / 分行', def: '开户行所在省份代码 / 城市代码 / 支行地址，均明文展示。' },

    { name: '「USDT地址」网络协议', def: '该地址所属链路类型：TRC20 / ERC20 / BEP20，彩色标签区分。' },
    { name: '「USDT地址」钱包地址', def: 'USDT 收款钱包地址，明文全量展示，未脱敏。' },

    { name: '「PIX钱包」钱包类型', def: 'PIX key 的类型：PHONE / CPF / EMAIL / CNPJ / Random，彩色标签区分。' },
    { name: '「PIX钱包」CPF', def: '巴西个人纳税人识别号，明文展示。' },
    { name: '「PIX钱包」PIX账号', def: 'PIX 收款标识（视类型不同为手机号/邮箱/CPF号/随机key等），明文展示。' },
    { name: '「PIX钱包」姓名', def: '收款人姓名，明文展示。' },

    { name: '「电子钱包信息」钱包类型', def: '电子钱包渠道：KBZpay / NAGAD / GCash / PayMaya / GrabPay，彩色标签区分。' },
    {
      name: '「电子钱包信息」账号/手机',
      def: '钱包绑定的账号或手机号，脱敏展示（规则同手机号：保留前3位 + **** + 后4位）。',
    },
    { name: '「电子钱包信息」姓名', def: '钱包持有人姓名，明文展示。' },
    { name: '「电子钱包信息」地址', def: '钱包持有人所在地址，明文展示。' },

    { name: '「UPI信息」UPI类型', def: 'UPI 支付渠道类型（如 GooglePay/PhonePe/Paytm/BHIM 等），标签展示。' },
    { name: '「UPI信息」UPI ID', def: 'UPI 收款标识（形如 user@bank），明文全量展示，未脱敏。' },
    { name: '「UPI信息」姓名', def: '收款人姓名，明文展示。' },
    { name: '「UPI信息」手机号', def: '绑定手机号，脱敏展示：保留前3位 + **** + 后4位。' },
    { name: '「UPI信息」KYC-银行编码', def: 'KYC 认证对应的银行编码，明文展示。' },
  ],
};

export default manual;
