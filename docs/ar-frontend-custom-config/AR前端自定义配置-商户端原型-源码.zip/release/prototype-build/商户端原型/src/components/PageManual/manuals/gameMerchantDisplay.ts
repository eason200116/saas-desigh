// C端展示配置（商户端 tenant · game_merchant_display）功能说明书。
// ⚠️ 2026-07-18（会话6aafc681）：独立菜单入口已隐藏（game.ts 路由块转注释），本配置台改由「子游戏管理」
//    工具栏「C端展示配置」按钮弹窗访问（subgame/DisplayConfigModal 内嵌本页 index.vue，embedded 模式）。
//    页面/组件/i18n 全部保留、逻辑未变。
// 锚定 src/views/game/merchant/display/index.vue + components/{DisplayColumn,HomePreview}.vue 真实控件（R53 实证、不臆造）。
// R64：本页 roles:['tenant']。非标准页（S5）：非列表——顶部商户+保存，主体三栏级联配置 + 右侧 C 端实时预览；无 fields。

import type { PageManual } from '../types';

const manual: PageManual = {
  route: 'game_merchant_display',
  title: 'C端展示配置',
  overview:
    '商户端「C 端展示配置」工作台（非列表页）：左侧三栏级联配置——大类 → 厂商 → 游戏，每栏可勾选展示 / 拖拽排序 / 下钻到下一层；右侧实时预览玩家端首页（与配置同源，改配置即变）。商户必选，配好后点「保存」下发到该商户。',
  items: [
    // ============ 顶部 ============
    {
      anchor: 'merchant',
      name: '商户',
      group: '顶部',
      interaction: '商户下拉（MerchantFilterSelect）：单选、必填红星。',
      dataSource: '全站商户主数据源。',
      logic: '进页默认选第一家商户；换商户加载该商户的展示配置（有未保存改动会二次确认，防手滑丢配置）。',
      limit: '必填（R63）。',
    },
    {
      anchor: 'act_save',
      name: '保存',
      group: '顶部',
      interaction: '点击「保存」。',
      logic: '把当前三栏配置下发到该商户（api.merchantDisplay.saveConfig），成功后重载。',
      edge: '未选商户时按钮禁用。',
    },

    // ============ 配置区（三栏级联）============
    {
      anchor: 'col_category',
      name: '大类配置栏',
      group: '配置区',
      interaction: '勾选 = 展示该大类 / 取消 = 隐藏；拖拽排序；点击某行下钻到其厂商栏。',
      dataSource: '全量大类池 ⊕ 当前商户 draft 的开关态（buildCategoryRows）。',
      logic: '控制 C 端首页展示哪些游戏大类、按什么顺序。',
      note: '表头两个按钮（2026-07-18 item1 改按钮样式）：「新增」（浅主色实心，点开行内输名 + 保存 → 二次确认后新增自定义策展大类 cust_）、「编辑」（描边，点击后整栏名称变内联输入框 + 整栏浅琥珀底高亮明确进入编辑态、再点「完成」提交改名）。编辑态下每个非失效大类行右侧都有红色「删除」按钮，二次确认后删除（级联移除其下厂商/游戏/直接游戏）：自定义大类（cust_）直接移除；内置大类（老虎机等，大类池全量渲染）与系统策展（推荐/热门/精选，ensureSpecial 补齐）打 removed 墓碑——保留条目但列表/预览都排除、也不被池/ensureSpecial 复活，实现删了不再出现、保存重载也不回来（当前无 UI 恢复已删的内置/策展大类）。栏内若有失效引用（r.invalid）时表头另露「清理失效」按钮。',
    },
    {
      anchor: 'col_vendor',
      name: '厂商配置栏',
      group: '配置区',
      interaction: '勾选 / 拖拽排序 / 下钻到游戏栏，可搜索。',
      dataSource: '当前下钻大类下的厂商池 ⊕ draft 开关态（buildVendorRows）。',
      logic: '控制该大类下展示哪些厂商。需先在大类栏选中一个大类。',
      note: '同大类栏，栏内有失效引用时表头露出「清理失效」按钮。',
    },
    {
      anchor: 'col_game',
      name: '游戏配置栏',
      group: '配置区',
      interaction: '勾选 / 拖拽排序要展示的游戏，可搜索。',
      dataSource: '选了厂商=该厂商的游戏池（buildGameRows）；只选大类没选厂商=该大类的游戏池（buildCategoryGameRows，普通大类=该大类下游戏、策展大类=全平台全部）⊕ draft 开关态。',
      logic: '2026-07-18 统一承接两种流程：①选了厂商→配该厂商下的游戏（vendor 路径，C 端点厂商卡进子游戏页）；②只选大类没选厂商→配该大类的直接游戏（存 categoryGames，C 端在大类里直接铺游戏 icon、无子页，即 item4「不选厂商→游戏 icon」）。',
      note: '栏内有失效引用时表头露出「清理失效」按钮；表头另有「编辑」按钮批量改名（点击后整栏进内联输入、「完成」提交）。策展大类（推荐/热门/精选/自定义）选中时厂商/游戏栏展示全平台全部。（大类栏专属的「新增/删除」见 col_category。）',
    },
    // ============ 预览 ============
    {
      anchor: 'layoutTemplate',
      name: '首页模版',
      group: '预览',
      interaction: '分段单选（预览上方）：左右结构 / 上下多行 / 上下卡片，3 选 1。',
      dataSource: '按商户保存的配置字段 layoutTemplate（默认「左右结构」）。',
      logic: '切换即预览实时重排（只变「分类导航 + 游戏区」排布，其余装饰块不变）；随「保存」写入该商户配置、决定其 C 端首页版型。',
      note: '2026-07-18 用户定「首页预览 3 种常规模版」。左右结构=现状。',
    },
    {
      anchor: 'preview',
      name: 'C端首页预览',
      group: '预览',
      interaction: '右侧实时预览（HomePreview），不可编辑、仅展示。',
      dataSource: '由 draft 配置直接派生（resolveForPreview），与左侧配置同源。',
      logic: '所见即所得：改左侧配置右侧即变；随下钻的大类 / 厂商联动显示对应层级 + 当前「首页模版」的版型。',
      note: '预览里大类 / 厂商 / 游戏每个元素上都有一个 📷「上传图片」按钮（2026-07-18 item4 由 8px 小字改为醒目图标按钮：文字型分类＝描边浅底小方钮、卡片型＝右下角半透明圆形角标），点击弹本地上传弹窗（FileReader 转 dataURL、无 HTTP）设为该项 C 端展示图。',
    },
  ],
};

export default manual;
