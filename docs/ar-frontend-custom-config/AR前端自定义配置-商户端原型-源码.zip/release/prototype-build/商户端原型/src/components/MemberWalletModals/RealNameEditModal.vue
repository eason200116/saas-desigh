<template>
  <n-form ref="formRef" :model="formData" :rules="rules" label-placement="top">
    <n-grid :cols="2" :x-gap="14">
      <n-form-item-gi :label="t('member.bankCard.merchant')">
        <n-input :value="getTenantName(formData.tenantId)" disabled />
      </n-form-item-gi>
      <n-form-item-gi :label="t('member.bankCard.userId')">
        <n-input :value="formData.userId" disabled />
      </n-form-item-gi>
      <n-form-item-gi :label="t('member.bankCard.realName')" path="realName">
        <n-input
          v-model:value="formData.realName"
          :placeholder="t('common.input_placeholder', { label: t('member.bankCard.realName') })"
        />
      </n-form-item-gi>
      <n-form-item-gi :label="t('member.bankCard.cpf')" path="idCard">
        <n-input
          v-model:value="formData.idCard"
          :placeholder="t('common.input_placeholder', { label: t('member.bankCard.cpf') })"
        />
      </n-form-item-gi>
    </n-grid>
  </n-form>
  <n-space justify="end" :style="{ marginTop: '16px' }">
    <n-button @click="emit('cancel')">{{ t('common.cancel') }}</n-button>
    <n-button type="primary" :loading="loading" @click="handleSubmit">
      {{ t('common.confirm') }}
    </n-button>
  </n-space>
</template>

<script setup lang="ts">
  import { reactive, ref } from 'vue';
  import type { FormInst, FormRules } from 'naive-ui';
  import { useI18n } from 'vue-i18n';
  import { useMessage } from 'naive-ui';
  import { useTenantOptions } from '@/hooks';
  import { api } from './data';
  const props = defineProps<{
    record: any;
  }>();

  const emit = defineEmits<{
    (e: 'cancel'): void;
    (e: 'confirm'): void;
  }>();

  const { t } = useI18n();
  const message = useMessage();
  const { getTenantName } = useTenantOptions();

  const formRef = ref<FormInst | null>(null);
  const loading = ref(false);

  const formData = reactive({
    tenantId: props.record.tenantId,
    userId: String(props.record.userId),
    realName: props.record.realName ?? '',
    idCard: props.record.idCard ?? '',
  });

  const rules: FormRules = {
    realName: {
      required: true,
      message: t('common.input_placeholder', { label: t('member.bankCard.realName') }),
      trigger: 'blur',
    },
    idCard: {
      required: true,
      message: t('common.input_placeholder', { label: t('member.bankCard.cpf') }),
      trigger: 'blur',
    },
  };

  async function handleSubmit() {
    try {
      await formRef.value?.validate();
    } catch {
      return;
    }
    loading.value = true;
    try {
      const { result, msg } = await api.v1platform.updateUserRealName({
        realId: props.record.realId,
        userId: Number(formData.userId),
        realName: formData.realName,
        cpf: formData.idCard,
        tenantId: formData.tenantId,
      });
      if (!result) {
        message.error(msg);
        return;
      }
      message.success(t('member.bankCard.saveSuccess'));
      emit('confirm');
    } catch {
      message.error(t('common.requestFailed'));
    } finally {
      loading.value = false;
    }
  }
</script>
