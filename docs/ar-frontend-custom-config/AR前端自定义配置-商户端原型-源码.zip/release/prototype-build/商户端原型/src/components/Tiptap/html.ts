import { getSafeHtml } from '@/utils';

const EMPTY_HTML_SET = new Set(['', '<p></p>', '<p><br></p>']);

export function getInitialEditorHtml(html?: string) {
  if (!html) return '';
  return getSafeHtml(html);
}

export function normalizeEditorHtml(html?: string) {
  const safeHtml = getSafeHtml(html || '').trim();
  const compactHtml = safeHtml.replace(/\s+/g, '');

  if (EMPTY_HTML_SET.has(compactHtml)) {
    return '';
  }

  return safeHtml;
}
