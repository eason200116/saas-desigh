<script setup lang="ts">
  import { nextTick, onActivated, onMounted, onUnmounted, ref, shallowRef, watch } from 'vue';
  import * as echarts from 'echarts';

  const props = withDefaults(
    defineProps<{
      config?: Record<string, any>;
      height?: string | number;
      width?: string | number;
    }>(),
    {
      height: 300,
      width: '100%',
    },
  );

  const chartRef = ref<HTMLDivElement | null>(null);
  const chartInstance = shallowRef<echarts.ECharts | null>(null);
  let resizeObserver: ResizeObserver | null = null;
  let resizeRaf = 0;

  const initChart = () => {
    if (!chartRef.value) return;

    if (chartInstance.value) {
      chartInstance.value.dispose();
    }

    chartInstance.value = echarts.init(chartRef.value);

    if (props.config) {
      chartInstance.value.setOption(props.config);
    }
  };

  // rAF 节流：合并同帧多次触发，并规避 "ResizeObserver loop completed" 警告
  const handleResize = () => {
    if (resizeRaf) cancelAnimationFrame(resizeRaf);
    resizeRaf = requestAnimationFrame(() => {
      resizeRaf = 0;
      const el = chartRef.value;
      if (!el || !chartInstance.value) return;
      // 容器被 display:none 或尺寸归零时跳过 —— 此时 resize 会把画布锁成 0×0，
      // 等容器尺寸恢复后由 ResizeObserver / onActivated 再次驱动
      if (el.clientWidth === 0 || el.clientHeight === 0) return;
      chartInstance.value.resize();
    });
  };

  watch(
    () => props.config,
    (newConfig) => {
      if (chartInstance.value && newConfig) {
        chartInstance.value.setOption(newConfig, true);
      }
    },
    { deep: true },
  );

  onMounted(() => {
    initChart();
    window.addEventListener('resize', handleResize);
    // ResizeObserver 兜底所有 layout 变化（tab 切换、响应式 collapse、抽屉、弹窗等）。
    // ECharts 官方要求容器尺寸变化时必须显式 resize()，否则画布会锁定旧尺寸出现"折叠"
    if (chartRef.value && typeof ResizeObserver !== 'undefined') {
      resizeObserver = new ResizeObserver(handleResize);
      resizeObserver.observe(chartRef.value);
    }
  });

  // KeepAlive 切回时容器从 display:none 恢复，主动 resize 一次兜底 ResizeObserver 异步时序差异
  onActivated(() => {
    nextTick(handleResize);
  });

  onUnmounted(() => {
    if (resizeRaf) cancelAnimationFrame(resizeRaf);
    window.removeEventListener('resize', handleResize);
    resizeObserver?.disconnect();
    resizeObserver = null;
    chartInstance.value?.dispose();
  });

  defineExpose({
    getInstance: () => chartInstance.value,
    resize: handleResize,
  });
</script>

<template>
  <div
    ref="chartRef"
    :style="{
      height: typeof props.height === 'number' ? `${props.height}px` : props.height,
      width: typeof props.width === 'number' ? `${props.width}px` : props.width,
    }"
  />
</template>
