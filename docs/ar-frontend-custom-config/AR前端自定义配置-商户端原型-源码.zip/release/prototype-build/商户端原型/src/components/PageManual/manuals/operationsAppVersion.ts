// APP版本上架（商户端 tenant · operations_appVersion）功能说明书。
// 锚定 src/views/operations/version/index.vue(纯壳，直接渲染 src/views/operations/app/components/VersionTab.vue)
// + VersionFormModal.vue + data.ts 真实控件（R53 实证、不臆造）。
//
// 注：还存在一个 hidden:true 的路由 operations_app（菜单隐藏，router 注释明写"与独立的版本上架/渠道包管理重复"），
// 其内部 Tab 用的正是同一个 VersionTab.vue 组件——本说明书覆盖的就是这份共享内容，不重复为 operations_app 单独建说明书。

import type { PageManual } from '../types';

const manual: PageManual = {
  route: 'operations_appVersion',
  title: 'APP版本上架',
  overview:
    '商户端「运营管理 › APP版本上架」页，维护APP安装包的版本发布信息（版本号/更新类型/最低兼容版本/更新说明等），' +
    '支持发布/下架/编辑/删除。当前仅支持Android平台（下拉选项固定只有Android一项）。' +
    '2026-07-22核实代码发现本页最严重的问题：列表接口 appVersionsList() 在 data.ts 里恒返回 data:null（无任何mock' +
    '数据数组），导致列表**永远空白**，进而新增弹窗里"最低兼容版本"下拉（依赖已有版本列表）也恒为空选项、' +
    '"版本号自动计算"逻辑因取不到历史版本恒回退到默认值"1.0.0"——这是本次全站说明书铺开任务中发现的最严重R32' +
    '(列表必须有数据)违反案例，如实记录，未修复。',
  items: [
    {
      anchor: 'tenantId',
      name: '商户',
      group: '搜索',
      interaction: '下拉单选筛选。',
    },
    {
      anchor: 'platform',
      name: '平台',
      group: '搜索',
      interaction: '下拉单选，可清空；当前选项仅"Android"一项。',
    },
    {
      anchor: 'state',
      name: '状态',
      group: '搜索',
      interaction: '下拉单选，可清空；选项：草稿/已发布/已下架。',
    },
    {
      anchor: 'packageType',
      name: '包类型',
      group: '搜索',
      interaction: '下拉单选，可清空；选项：原生/壳包/主包/衍生包。',
    },
    {
      anchor: 'act_add',
      name: '新增版本',
      group: '操作',
      interaction: '主色按钮，点击打开新增弹窗。',
      logic:
        '弹窗字段：商户(必选)/平台(必选，固定Android)/版本号(必填，格式x.x.x)/包类型/安装包上传' +
        '(必填，按平台限定accept类型)/更新类型(必选：可选/强制/静默)/最低兼容版本(下拉选同商户同平台历史' +
        '低版本号，用于计算)/更新说明(选填)。新增时若已有该商户+平台历史版本，版本号会自动计算成"最高版本+patch位' +
        '递增"，无历史则默认"1.0.0"。',
      edge: '因列表mock恒无数据，"最低兼容版本"下拉与自动版本计算在原型环境下实际总是取不到历史数据，恒为空/恒为1.0.0。',
    },
    {
      anchor: 'col_downloadUrl',
      name: '安装包（下载）',
      group: '列',
      interaction: '有文件则显示"下载"文字按钮，否则显示"-"。',
      logic: '点击通过后端代理下载对应版本安装包文件。',
    },
    {
      anchor: 'act_publish',
      name: '发布（条件显示）',
      group: '操作',
      interaction: '仅状态=草稿的行显示，点击弹二次确认。',
      logic: '确认后调用发布接口，成功后刷新列表（该行状态应变为"已发布"）。',
    },
    {
      anchor: 'act_unpublish',
      name: '下架（条件显示）',
      group: '操作',
      interaction: '仅状态=已发布的行显示，点击弹二次确认（警示色）。',
      logic: '确认后调用下架接口，成功后刷新列表。',
    },
    {
      anchor: 'act_edit',
      name: '编辑',
      group: '操作',
      interaction: '每行常驻，点击打开编辑弹窗（字段同新增，回显当前值）。',
    },
    {
      anchor: 'act_delete',
      name: '删除',
      group: '操作',
      interaction: '每行常驻，危险色，点击弹二次确认。',
      logic: '确认后调用删除接口，成功后刷新列表。',
    },
    {
      anchor: 'reset',
      name: '重置',
      group: '搜索',
      interaction: 'ProCrudTable内置重置按钮，点击清空全部搜索条件并重新查询。',
    },
  ],
  fields: [
    { name: '版本ID', def: '该版本记录的唯一编号。' },
    { name: '商户', def: '该版本所属商户，悬停显示商户ID。' },
    { name: '平台', def: 'Android/iOS，彩色Tag展示（当前仅Android）。' },
    { name: '版本号', def: '形如 x.x.x 的语义化版本号。' },
    { name: '包类型', def: '原生/壳包/主包/衍生包四态。' },
    { name: '更新类型', def: '可选更新/强制更新/静默更新三态。' },
    { name: '状态', def: '草稿/已发布/已下架三态Tag。' },
    { name: '文件大小', def: '安装包文件体积，按KB/MB自动换算展示。' },
    { name: '安装包', def: '下载入口，见交互条目 col_downloadUrl。' },
    { name: '最后修改人', def: '最近一次编辑该版本的操作人（无则显示创建人）。' },
    { name: '最后修改时间', def: '最近一次编辑该版本记录的时间。' },
  ],
};

export default manual;
