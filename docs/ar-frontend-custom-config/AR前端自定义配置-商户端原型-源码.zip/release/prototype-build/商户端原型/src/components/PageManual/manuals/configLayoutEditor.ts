import type { PageManual } from '../types';
import { merchantLayoutEditorZh } from './features/arMerchant';

const manual: PageManual = {
  prdManualFeatureId: 'HELP-01',
  route: 'config_layoutConfig_edit',
  title: '版面编辑／发布',
  overview: '在总控下派保底版面上配置商户覆盖内容。商户发布成功后显示覆盖结果；任何配置加载、校验、发布或渲染失败都会自动切回保底展示。',
  featurePoints: merchantLayoutEditorZh,
  sections: [
    { key: 'purpose', content: '编辑总控已下派版面的商户覆盖层。下派内容包含可直接展示的基本排版与游戏，始终作为保底；模板骨架、组件类型／ID／层级与必备插槽只读，商户只调整允许的语言、素材、显示、排序、数量与游戏。' },
    { key: 'prerequisites', content: '进入和预览需要“版面查看”；编辑及保存需要“配置管理”；立即发布、排程、取消排程与回滚需要“发布管理”。版面必须仍在下派范围内，商户与路由范围一致。没有有效主域名时仍可保存及预览，但不能发布或排程。' },
    { key: 'areas', content: '页首包含名称／ID、主题、备注与状态。内容结构选择导航、分类和区块；区块配置维护已启用语言、素材、显示、排序及游戏；多端预览中，手机端固定以 375×812 检查，PC 端以 1920 为基准宽度并随画面可用宽度自适应，高度随内容延伸且不限制，并可切换已启用语言。发布区提供立即与排程；回滚及记录从列表的操作记录进入。域名绑定统一在版面配置的域名管理处理。' },
    { key: 'workflow', content: '1. 确认总控基准、已启用语言与主域名。\n2. 编辑允许范围内的文案、素材、顺序和游戏。\n3. 保存草稿；未保存内容离开时选择保存、放弃或取消。\n4. 预览设备、语言、域名与文案／素材回退结果。\n5. 修正必填、必备结构及游戏校验。\n6. 选择立即发布，或按商户时区设定至少 5 分钟后的单一待执行排程。\n7. 回列表查看结果，必要时从合资格成功发布执行回滚。' },
    { key: 'permissions', content: '仅查看时可阅读说明、查看配置与预览，编辑控件只读。“查看＋配置”可保存草稿但不能发布。“查看＋发布”可复核当前草稿、发布、排程、取消与回滚，但不能改变配置。权限撤销为只读时保留未保存内容供复制，不允许继续保存。' },
    { key: 'effects', content: '保存草稿与预览不改变线上内容。商户发布成功后，覆盖层原子应用到全部有效已绑定主域名；未覆盖内容继续继承下派保底。系统每次渲染先检查覆盖层健康状态，失败时不显示半成品，直接回到下派保底版面。' },
    { key: 'unavailable', content: '发布需要至少一个有效主域名、默认语言全部必填文案、完整必备导航／分类／区块，以及每个必备游戏区块至少一个 active 子游戏。非默认语言缺文案会警告并回退，但不阻挡。maintenance 可保留但不可新选；disabled／unavailable 不得发布；每区块最多 50 个。每版面只允许一笔待执行排程；直接发布或回滚会先确认并取消既有排程。' },
    { key: 'recovery', content: '配置加载、校验、发布、排程或前台渲染任一阶段失败时，保留草稿与失败原因，但线上立即使用总控下派保底版面；不得渲染失败覆盖或半完成内容。修正后重新预览与发布，成功才恢复商户覆盖。若下派本身已取消或失效，才使用平台默认。' },
  ],
  items: [
    { anchor: 'backToLayouts', name: '返回', group: '操作', interaction: '返回版面列表；有未保存内容时先处理离开提示。' },
    { anchor: 'theme', name: '主题', group: '操作', interaction: '查看或在允许草稿范围内切换主题；不改变组件识别或清除内容。' },
    { anchor: 'applicationDomains', name: '应用主域名', group: '操作', interaction: '查看该版面全部有效且已绑定的主域名。', note: '已有绑定不能直接切换；须先解除成功，再另行绑定其他版面。' },
    { anchor: 'layoutNote', name: '商户版面备注', group: '操作', interaction: '填写当前版面的补充说明。', limit: '最多 200 字。' },
    { anchor: 'saveDraft', name: '保存草稿', group: '操作', interaction: '保存当前编辑内容，不自动发布。' },
    { anchor: 'previewDraft', name: '预览', group: '操作', interaction: '检查当前草稿在设备、语言与域名下的发布效果，不写入线上。' },
    { anchor: 'publishLayout', name: '发布／排程', group: '操作', interaction: '立即发布到全部有效已绑主域名，或建立未来排程。', limit: '排程最早为当前时间后 5 分钟，每版面仅一笔待执行排程。' },
    { anchor: 'contentStructure', name: '内容结构', group: '其它', interaction: '查看模板结构并调整允许的显示状态与同层排序。' },
    { anchor: 'semanticConfig', name: '区块配置', group: '其它', interaction: '编辑已启用语言、允许素材／链接及商户可选游戏。' },
    { anchor: 'h5Preview', name: '多端预览', group: '其它', interaction: '手机端固定以 375×812 预览；PC 端以 1920 为基准宽度并随画面自适应，高度不限制。切换设备或语言不会重置编辑内容。' },
  ],
  fields: [
    { name: '已启用语言', def: '来自商户管理、当前可编辑及发布的语言；停用语言内容保留但不显示。' },
    { name: '文案回退', def: '目标语言 → 商户默认语言 → 总控英文基准。' },
    { name: '应用主域名', def: '该版面全部有效且已绑定的主域名；发布按版面整体生效。' },
    { name: '游戏状态', def: 'active 可选；maintenance 仅保留既有选择；disabled／unavailable 不进入新发布。' },
    { name: '版面状态', def: '尚未配置、草稿、已排程、已发布、发布失败或已回滚。' },
  ],
};

export default manual;
