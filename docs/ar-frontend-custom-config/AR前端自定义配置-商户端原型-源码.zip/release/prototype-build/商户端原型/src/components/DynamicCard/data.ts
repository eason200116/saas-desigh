// 占位 data.ts —— components 层占位，UI 跑得起来不报模块缺失
// 视图调用形态保持源项目一致：const { data, result } = await api.<module>.<method>(req);
export const api: any = new Proxy(
  {},
  {
    get(_t, mod: string) {
      return new Proxy(
        {},
        {
          get(_, method: string) {
            return async (..._args: any[]) => {
              console.warn(
                '[component data placeholder] api.' + mod + '.' + method + ' not implemented',
              );
              return { code: 0, result: true, data: null, msg: 'placeholder' };
            };
          },
        },
      );
    },
  },
);

// 兼容：组件如直接 import http
export const http: any = new Proxy(
  {},
  {
    get(_t, method: string) {
      return async (..._args: any[]) => {
        console.warn('[component http placeholder] http.' + method + ' not implemented');
        return { code: 0, result: true, data: null, msg: 'placeholder' };
      };
    },
  },
);
