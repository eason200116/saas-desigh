import BasicTiptapEditor from './BasicTiptapEditor.vue';

export { BasicTiptapEditor };
export type * from './types';
