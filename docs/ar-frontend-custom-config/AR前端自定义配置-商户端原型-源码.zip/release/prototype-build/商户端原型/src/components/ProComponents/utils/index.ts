// ============== 配置合并 ==============
export {
  mergeConfig,
  mergeObjects,
  mergeProps,
  pickAndMerge,
  omitAndMerge,
  setGlobalConfig,
  getGlobalConfig,
  clearGlobalConfig,
  setupProComponents,
  getProFormConfig,
  getProFieldConfig,
  getProTableConfig,
  getProEditConfig,
  getProSearchFormConfig,
  type ConfigLevel,
  type MergeStrategy,
  type MergeConfig,
  type ProGlobalConfig,
} from './configMerge';

// ============== 占位符 ==============
export {
  createPlaceholder,
  createPlaceholderByValueType,
  getDateFormat,
  getDatePickerType,
  getTimePickerFormat,
  createRequiredMessage,
  createLengthMessage,
  createRangeMessage,
  PATTERNS,
} from './placeholder';

// ============== 值转换 ==============
export {
  getValueByPath,
  setValueByPath,
  deleteValueByPath,
  hasValueByPath,
  omitNil,
  omitEmptyString,
  omitEmpty,
  deepOmitEmpty,
  flattenObject,
  unflattenObject,
  deepClone,
  isEqual,
  getChangedFields,
  mergeDefaults,
  toArray,
  toString,
  safeJsonParse,
  safeJsonStringify,
} from './valueTransform';
