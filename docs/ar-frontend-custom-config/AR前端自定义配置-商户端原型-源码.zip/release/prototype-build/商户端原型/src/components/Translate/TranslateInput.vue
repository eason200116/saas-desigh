<template>
  <div class="translate-input-group w-full">
    <!-- Full Screen Loading Overlay -->
    <Teleport to="body">
      <div v-if="translating" class="translate-loading-overlay">
        <n-spin size="large">
          <template #description>
            <span class="text-white">{{ t('common.translate.translating') }}</span>
          </template>
        </n-spin>
      </div>
    </Teleport>

    <!-- Header: Label + Tooltip + AI Translate Button -->
    <div
      :class="['translate-input-label flex items-center', compact ? 'pb-1' : 'pb-2']"
      v-if="showLabel"
    >
      <span class="label-text">{{ fieldLabel }}</span>
      <n-tooltip trigger="hover">
        <template #trigger>
          <n-icon size="14" class="text-gray-400 cursor-help ml-1">
            <InfoIcon />
          </n-icon>
        </template>
        <span>{{ t('common.translate.sourceHint', { lang: sourceLanguageName }) }}</span>
      </n-tooltip>
      <n-button
        text
        type="info"
        size="tiny"
        :loading="translating"
        @click="handleTranslateAll"
        style="margin-left: 16px"
      >
        <template #icon>
          <n-icon size="14"><SparklesIcon /></n-icon>
        </template>
        {{ t('common.translate.aiTranslate') }}
      </n-button>
    </div>

    <!-- Language Input Rows -->
    <div :class="layoutClass">
      <div v-for="lang in sortedLanguages" :key="lang.code" :class="itemClass">
        <div class="flex items-center gap-2">
          <!-- Language Tag -->
          <n-tag
            :type="lang.code === sourceLang ? 'info' : 'default'"
            :size="size"
            class="justify-center shrink-0"
            :style="{ minWidth: tagWidth }"
          >
            {{ lang.name }}
          </n-tag>
          <!-- Input -->
          <n-input
            :value="formValues[lang.code]"
            :placeholder="placeholder"
            :size="size"
            class="flex-1"
            @update:value="(val: string) => handleInputChange(lang.code, val)"
          />
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
  import { watch, reactive, computed } from 'vue';
  import { useI18n } from 'vue-i18n';
  import { NIcon } from 'naive-ui';
  import {
    Sparkles as SparklesIcon,
    InformationCircleOutline as InfoIcon,
  } from '@vicons/ionicons5';
  import { useUserStore } from '@/store/modules';
  import {
    type TranslateLanguage,
    resolveLanguages,
    resolveSourceLanguage,
    sortLanguages,
  } from './shared';
  import { useTranslate } from './hooks/useTranslate';

  const { t } = useI18n();
  const userStore = useUserStore();

  interface Props {
    /** v-model value - Record of language code to text */
    modelValue?: Record<string, string>;
    /** Field label (e.g., "Activity Title") */
    fieldLabel?: string;
    /** Show label and translate button */
    showLabel?: boolean;
    /** Placeholder text for inputs */
    placeholder?: string;
    /** Display inputs in a single row (horizontal layout) */
    inline?: boolean;
    /** Custom language list - if not provided, uses userStore.info.languageList */
    languageList?: TranslateLanguage[];
    /** Source language code */
    sourceLanguage?: string;
    /** Input and tag size */
    size?: 'small' | 'medium' | 'large';
    /** Language tag width (e.g., '48px', '60px') */
    tagWidth?: string;
    /** Compact mode - reduces vertical spacing */
    compact?: boolean;
  }

  const props = withDefaults(defineProps<Props>(), {
    modelValue: () => ({}),
    fieldLabel: '',
    showLabel: true,
    placeholder: '',
    inline: false,
    languageList: undefined,
    sourceLanguage: 'zh',
    size: 'medium',
    tagWidth: '48px',
    compact: false,
  });

  const emit = defineEmits<{
    'update:modelValue': [value: Record<string, string>];
  }>();

  // Internal form values
  const formValues = reactive<Record<string, string>>({});

  const languages = computed<TranslateLanguage[]>(() =>
    resolveLanguages(
      props.languageList,
      userStore.info.languageList as TranslateLanguage[] | undefined,
    ),
  );

  const sourceLang = computed(() => resolveSourceLanguage(languages.value, props.sourceLanguage));

  const sortedLanguages = computed(() => sortLanguages(languages.value, sourceLang.value));

  const sourceLanguageName = computed(() => {
    const lang = sortedLanguages.value.find((item) => item.code === sourceLang.value);
    return lang?.name || sourceLang.value;
  });

  const languageCodesKey = computed(() => sortedLanguages.value.map((lang) => lang.code).join('|'));
  const modelSnapshotKey = computed(() =>
    sortedLanguages.value
      .map((lang) => `${lang.code}:${props.modelValue?.[lang.code] ?? ''}`)
      .join('\u0001'),
  );

  // Layout classes based on inline prop and language count
  // Single language: full width; Multiple languages with inline: grid 2 columns
  const layoutClass = computed(() => {
    const langCount = sortedLanguages.value.length;
    const gap = props.compact ? 'gap-2' : 'gap-4';
    const spaceY = props.compact ? 'space-y-1' : 'space-y-2';
    if (langCount <= 1) return spaceY;
    return props.inline ? `grid grid-cols-2 ${gap}` : spaceY;
  });

  const itemClass = computed(() => 'translate-input-item');

  const syncFormValuesFromModel = () => {
    const activeCodes = new Set(sortedLanguages.value.map((lang) => lang.code));

    Object.keys(formValues).forEach((code) => {
      if (!activeCodes.has(code)) {
        delete formValues[code];
      }
    });

    sortedLanguages.value.forEach((lang) => {
      const nextValue = props.modelValue?.[lang.code] ?? '';
      if (formValues[lang.code] !== nextValue) {
        formValues[lang.code] = nextValue;
      }
    });
  };

  watch([languageCodesKey, modelSnapshotKey], syncFormValuesFromModel, { immediate: true });

  const handleInputChange = (langCode: string, value: string) => {
    if (formValues[langCode] === value) return;
    formValues[langCode] = value;
    emitUpdate();
  };

  const emitUpdate = () => {
    const values: Record<string, string> = {};
    sortedLanguages.value.forEach((lang) => {
      values[lang.code] = formValues[lang.code] ?? '';
    });
    emit('update:modelValue', values);
  };

  const { translating, handleTranslateAll } = useTranslate({
    sourceLang,
    sortedLanguages,
    getSourceContent: () => formValues[sourceLang.value],
    applyTranslatedMap: (translatedMap) => {
      Object.entries(translatedMap).forEach(([code, content]) => {
        formValues[code] = content;
      });
    },
    afterApply: emitUpdate,
  });
</script>

<style scoped>
  .translate-input-group {
    width: 100%;
  }

  .translate-input-label .label-text {
    font-size: var(--n-label-font-size-top, 14px);
    color: var(--n-label-text-color, #333639);
    font-weight: var(--n-label-font-weight, 400);
    line-height: 1.25;
  }

  .translate-input-item {
    width: 100%;
  }

  .translate-loading-overlay {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background-color: rgba(0, 0, 0, 0.5);
    display: flex;
    justify-content: center;
    align-items: center;
    z-index: 9999;
  }
</style>
