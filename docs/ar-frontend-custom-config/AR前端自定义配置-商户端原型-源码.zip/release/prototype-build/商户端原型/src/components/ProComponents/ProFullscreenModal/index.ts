/**
 * @description ProFullscreenModal 模块 barrel：对外暴露弹窗全屏基座的 4 层 API（业务入口 useProDetailModal、状态层 useFullscreenModalState、渲染层 renderFullscreenTitle、共享常量）。
 * @date 2026-05-08
 * @scope src/components/ProComponents/ProFullscreenModal
 */

export { DEFAULT_NORMAL_MODAL_STYLE, MODAL_FULLSCREEN_STYLE } from './constants';
export {
  useFullscreenModalState,
  type UseFullscreenModalStateReturn,
} from './useFullscreenModalState';
export { renderFullscreenTitle, type RenderFullscreenTitleOptions } from './renderFullscreenTitle';
export {
  useProDetailModal,
  type ProDetailModalContext,
  type ProDetailModalInstance,
  type ProDetailModalOpenOptions,
  type UseProDetailModalReturn,
} from './useProDetailModal';
// 弹窗内容区几何 provider：useProDetailModal 已经默认包了一层。直接走 modal.create
// 而不经 useProDetailModal 的场景，需要内嵌带 ProCrudTable 的独立页面时手动用它包 content。
export { default as ProModalContentRect } from './ProModalContentRect.vue';
