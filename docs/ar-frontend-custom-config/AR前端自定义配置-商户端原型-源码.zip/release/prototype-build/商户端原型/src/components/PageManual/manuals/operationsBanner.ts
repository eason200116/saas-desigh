// Banner管理（商户端 tenant · operations_banner）功能说明书。
// 锚定 src/views/operations/banner/index.vue(纯壳，直接渲染 SystemBannerTab.vue，商城轮播Tab已删除仅剩系统轮播一类)
// + SystemBannerTab.vue + BannerFormModal.vue + data.ts 真实控件（R53 实证、不臆造）。

import type { PageManual } from '../types';

const manual: PageManual = {
  route: 'operations_banner',
  title: 'Banner管理',
  overview:
    '商户端「运营管理 › Banner管理」页，维护平台首页轮播图（系统轮播），每条轮播图按所属商户启用语言集' +
    '逐语言配一张横版图（768×300，复用站内信管理同一套"商户→启用语言"体系），支持3种跳转方式（跳转链接/' +
    '跳转子游戏三级级联/在线客服）。' +
    '2026-07-22核实代码发现：新增/编辑保存(saveBanner)与删除(deleteBanner)均只返回成功、不真正写回底层数组，' +
    '操作提示成功但列表刷新后看不到变化——与站内信管理3个Tab的同类问题同一处历史模板。如实记录，未修复。',
  items: [
    {
      anchor: 'merchant',
      name: '商户',
      group: '搜索',
      interaction: '下拉筛选。',
    },
    {
      anchor: 'state',
      name: '展示状态',
      group: '搜索',
      interaction: '下拉单选（启用/停用），可清空。',
    },
    {
      anchor: 'jumpType',
      name: '跳转方式',
      group: '搜索',
      interaction: '下拉单选，可清空；选项：跳转链接/跳转子游戏/在线客服。',
    },
    {
      anchor: 'reset',
      name: '重置',
      group: '搜索',
      interaction: 'ProCrudTable内置重置按钮。',
    },
    {
      anchor: 'act_add',
      name: '新增',
      group: '操作',
      interaction: '主色按钮，点击打开新增弹窗（760px宽）。',
      logic:
        '弹窗字段：商户(单选，编辑态置灰，切换商户会重载该商户的启用语言集) → 排序(数字) → ' +
        '多语言轮播图(BannerLangImageCards：每种启用语言横向一张图片卡，默认语言必填/未传红框提示，其余语言选填) → ' +
        '跳转方式(下拉：跳转链接/跳转子游戏/在线客服) → 条件字段(跳转链接=文本框填URL；跳转子游戏=' +
        '大类→厂商→子游戏三级级联下拉，下级依赖上级选择结果动态加载选项、上级未选下级禁用；在线客服=无附加字段) → ' +
        '状态(开关，置于弹窗底部)。',
    },
    {
      anchor: 'col_image',
      name: '轮播图（默认语言缩略图+更多）',
      group: '列',
      interaction: '默认语言图缩略展示，hover弹出放大预览；启用语言数>1时额外显示"更多"按钮。',
      logic: '点击"更多"弹出气泡卡片，逐语言列出该语言配的图（未配置显示"—"）。',
    },
    {
      anchor: 'act_edit',
      name: '编辑',
      group: '操作',
      interaction: '每行常驻，点击打开编辑弹窗（字段同新增，回显当前值）。',
    },
    {
      anchor: 'act_delete',
      name: '删除',
      group: '操作',
      interaction: '每行常驻，点击弹二次确认。',
    },
  ],
  fields: [
    { name: '商户（列）', def: '该轮播图所属商户，标签展示。' },
    { name: 'ID', def: '该轮播图记录的唯一编号。' },
    { name: '已配语言', def: '该商户支持的每种语言一个Tag：默认语言标"默认"(蓝)，其余已配图(绿)/未配图(灰)。' },
    { name: '跳转方式', def: '跳转链接(绿)/跳转子游戏(蓝)/在线客服(橙)三态Tag。' },
    { name: '跳转链接', def: '仅跳转方式=跳转链接时有值，展示目标URL，超长省略。' },
    { name: '排序', def: '数值，决定该轮播图在前台的展示顺序。' },
    { name: '最后修改时间', def: '该轮播图最近一次编辑保存的时间。' },
    { name: '最后修改人', def: '最近一次编辑该轮播图的操作人账号。' },
    { name: '状态', def: '启用/停用，只读Tag，恒排最后一个数据列。' },
  ],
};

export default manual;
