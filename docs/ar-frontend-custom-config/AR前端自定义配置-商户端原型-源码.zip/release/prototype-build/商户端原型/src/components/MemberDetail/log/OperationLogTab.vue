<template>
  <ProCrudTable
    ref="logTableRef"
    :columns="columns"
    :search-columns="searchColumns"
    :action-column="actionColumn"
    :request="loadData"
    :search-initial-values="searchInitialValues"
    row-key="logID"
    :search-cols="'1 s:2 m:3 l:4 xl:5 2xl:5'"
    :search-default-collapsed="false"
    :search-auto-span="true"
    :quick-date="{ field: 'timeRange', allowClear: true }"
    :auto-height="false"
  />
</template>

<script setup lang="ts">
  import { ProCrudTable } from '@/components';
  import { useOperationLog } from './useOperationLog';

  const { logTableRef, columns, searchColumns, actionColumn, searchInitialValues, loadData } =
    useOperationLog();

  // 模板 ref 绑定，抑制 TS6133 未读警告
  void logTableRef;
</script>

<!--
  操作路径级联下拉：菜单 teleport 到 body，scoped 样式触达不到，故用非 scoped + 类名
  (.platlog-op-cascader-menu) 命名空间隔离。目的：超长操作项换行完整展示、不截断（R49）。
  列宽/面板高已由 componentProps.themeOverrides 的 columnWidth/menuHeight 控制。
-->
<style>
  .platlog-op-cascader-menu .n-cascader-option__label {
    white-space: normal;
    word-break: break-word;
    line-height: 1.5;
  }
  .platlog-op-cascader-menu .n-cascader-option {
    height: auto;
    min-height: var(--n-option-height, 34px);
    align-items: flex-start;
    padding-top: 5px;
    padding-bottom: 5px;
  }
  .platlog-op-cascader-menu .n-cascader-submenu:first-of-type {
    width: 150px !important;
    min-width: 150px !important;
  }
</style>
