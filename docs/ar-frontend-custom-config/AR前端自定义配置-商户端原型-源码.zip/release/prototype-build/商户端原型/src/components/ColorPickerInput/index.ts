export { default as ColorPickerInput } from './index.vue';
