<template>
  <div class="html-code-editor-panel" :style="panelStyle">
    <div class="html-code-editor-panel__grid">
      <section class="html-code-editor-panel__section">
        <header class="html-code-editor-panel__section-head">
          <div class="html-code-editor-panel__title">
            {{ t('components.htmlCodeEditor.editTitle') }}
          </div>
          <div class="html-code-editor-panel__head-actions">
            <div class="html-code-editor-panel__hint">
              {{ t('components.htmlCodeEditor.completionHint') }}
            </div>
            <n-button
              size="tiny"
              tertiary
              type="primary"
              :loading="isFormatting"
              @click="handleFormatCode"
            >
              {{ t('components.htmlCodeEditor.format') }}
            </n-button>
          </div>
        </header>
        <div ref="editorHostRef" class="html-code-editor-panel__editor" />
      </section>

      <section class="html-code-editor-panel__section">
        <header class="html-code-editor-panel__section-head">
          <div class="html-code-editor-panel__title">
            {{ t('components.htmlCodeEditor.previewTitle') }}
          </div>
          <div class="html-code-editor-panel__hint">
            {{ t('components.htmlCodeEditor.realtimeRender') }}
          </div>
        </header>
        <div class="html-code-editor-panel__preview">
          <RichTextPreview
            :html="codeValue || EMPTY_RICH_TEXT_HTML"
            :theme="previewTheme"
            :language="language"
            :language-name="languageName"
            :height="panelHeight"
            :iframe-path="previewIframePath"
            :use-srcdoc="previewUseSrcdoc"
            @update:theme="handleThemeUpdate"
          />
        </div>
      </section>
    </div>
  </div>
</template>

<script setup lang="ts">
  import { computed, onBeforeUnmount, onMounted, ref, watch } from 'vue';
  import { useMessage } from 'naive-ui';
  import { useI18n } from 'vue-i18n';
  import { EditorState } from '@codemirror/state';
  import { keymap, EditorView, lineNumbers, highlightActiveLineGutter } from '@codemirror/view';
  import { defaultKeymap, history, historyKeymap, indentWithTab } from '@codemirror/commands';
  import {
    autocompletion,
    completionKeymap,
    closeBrackets,
    closeBracketsKeymap,
  } from '@codemirror/autocomplete';
  import { defaultHighlightStyle, syntaxHighlighting } from '@codemirror/language';
  import { html } from '@codemirror/lang-html';
  import RichTextPreview from '../PhonePreview/RichTextPreview.vue';

  const EMPTY_RICH_TEXT_HTML = '<p><br></p>';
  type PreviewTheme = 'light' | 'dark';
  type PrettierHtmlPluginModule = {
    default?: unknown;
  };

  interface Props {
    initialCode?: string;
    language?: string;
    languageName?: string;
    previewHeight?: number;
    previewIframePath?: string;
    previewUseSrcdoc?: boolean;
  }

  const props = withDefaults(defineProps<Props>(), {
    initialCode: '',
    language: '',
    languageName: '',
    previewHeight: 360,
    previewIframePath: '/translate-rich-text-preview.html',
    previewUseSrcdoc: true,
  });

  const emit = defineEmits<{
    change: [value: string];
  }>();

  const { t } = useI18n();
  const message = useMessage();
  const editorHostRef = ref<HTMLDivElement | null>(null);
  const codeValue = ref(props.initialCode ?? '');
  const isFormatting = ref(false);
  const previewTheme = ref<PreviewTheme>('light');
  const panelHeight = computed(() => Math.max(props.previewHeight, 280));
  const panelStyle = computed(() => ({
    '--html-code-editor-panel-height': `${panelHeight.value}px`,
  }));
  let editorView: EditorView | null = null;

  function handleThemeUpdate(theme: PreviewTheme) {
    previewTheme.value = theme;
  }

  function syncCodeValue(nextCode: string) {
    codeValue.value = nextCode;
    emit('change', nextCode);
  }

  function replaceEditorCode(nextCode: string) {
    if (!editorView) return;
    const current = editorView.state.doc.toString();
    if (current === nextCode) return;

    editorView.dispatch({
      changes: { from: 0, to: current.length, insert: nextCode },
    });
  }

  async function formatHtmlCode(rawCode: string) {
    const [{ format }, htmlPluginModule] = await Promise.all([
      import('prettier/standalone'),
      import('prettier/plugins/html'),
    ]);
    const htmlPlugin = (htmlPluginModule as PrettierHtmlPluginModule).default ?? htmlPluginModule;

    return format(rawCode, {
      parser: 'html',
      plugins: [htmlPlugin],
      tabWidth: 2,
      printWidth: 100,
      htmlWhitespaceSensitivity: 'ignore',
    });
  }

  async function handleFormatCode() {
    if (!editorView || isFormatting.value) return;

    const rawCode = editorView.state.doc.toString();
    if (!rawCode.trim()) return;

    isFormatting.value = true;
    try {
      const formatted = await formatHtmlCode(rawCode);
      replaceEditorCode(formatted);
      message.success(t('components.htmlCodeEditor.formatSuccess'));
    } catch (error) {
      console.error('format html failed:', error);
      message.error(t('components.htmlCodeEditor.formatFailed'));
    } finally {
      isFormatting.value = false;
    }
  }

  function createEditorView() {
    if (!editorHostRef.value) return;

    const updateListener = EditorView.updateListener.of((update) => {
      if (!update.docChanged) return;
      syncCodeValue(update.state.doc.toString());
    });

    const state = EditorState.create({
      doc: codeValue.value,
      extensions: [
        lineNumbers(),
        highlightActiveLineGutter(),
        history(),
        keymap.of([
          ...defaultKeymap,
          ...historyKeymap,
          ...completionKeymap,
          ...closeBracketsKeymap,
          indentWithTab,
          {
            key: 'Shift-Alt-f',
            run: () => {
              void handleFormatCode();
              return true;
            },
          },
        ]),
        html({ autoCloseTags: true }),
        syntaxHighlighting(defaultHighlightStyle, { fallback: true }),
        closeBrackets(),
        autocompletion({
          activateOnTyping: true,
          maxRenderedOptions: 16,
        }),
        updateListener,
        EditorView.theme({
          '&': {
            height: '100%',
            fontSize: '13px',
          },
          '.cm-scroller': {
            fontFamily:
              '"SFMono-Regular", Consolas, "Liberation Mono", Menlo, Monaco, "Courier New", monospace',
          },
        }),
      ],
    });

    editorView = new EditorView({
      state,
      parent: editorHostRef.value,
    });
  }

  function destroyEditorView() {
    editorView?.destroy();
    editorView = null;
  }

  watch(
    () => props.initialCode,
    (nextCode) => {
      if (!editorView) return;
      const normalized = nextCode ?? '';
      replaceEditorCode(normalized);
    },
  );

  onMounted(() => {
    createEditorView();
  });

  onBeforeUnmount(() => {
    destroyEditorView();
  });
</script>

<style scoped>
  .html-code-editor-panel {
    width: 100%;
  }

  .html-code-editor-panel__grid {
    display: grid;
    grid-template-columns: minmax(0, 1fr) minmax(0, 1fr);
    gap: 10px;
  }

  .html-code-editor-panel__section {
    display: flex;
    flex-direction: column;
    min-width: 0;
    border: 1px solid #e8e8e8;
    border-radius: 8px;
    overflow: hidden;
    background: #fff;
    min-height: var(--html-code-editor-panel-height);
  }

  .html-code-editor-panel__section-head {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 8px;
    border-bottom: 1px solid #e8e8e8;
    padding: 8px 10px;
  }

  .html-code-editor-panel__title {
    font-size: 12px;
    color: #606266;
    line-height: 1.25;
    font-weight: 600;
  }

  .html-code-editor-panel__hint {
    font-size: 12px;
    color: #909399;
    line-height: 1.25;
    white-space: nowrap;
  }

  .html-code-editor-panel__head-actions {
    display: flex;
    align-items: center;
    gap: 8px;
  }

  .html-code-editor-panel__editor {
    overflow: auto;
    height: var(--html-code-editor-panel-height);
    background: #fff;
  }

  .html-code-editor-panel__preview {
    padding: 8px;
    height: var(--html-code-editor-panel-height);
    overflow: auto;
    background: #fafafa;
  }

  .html-code-editor-panel__preview ::v-deep(.rich-text-preview) {
    min-height: 100%;
  }

  @media (max-width: 960px) {
    .html-code-editor-panel__grid {
      grid-template-columns: 1fr;
    }

    .html-code-editor-panel__editor {
      height: 260px;
    }

    .html-code-editor-panel__preview {
      height: 260px;
    }
  }
</style>
