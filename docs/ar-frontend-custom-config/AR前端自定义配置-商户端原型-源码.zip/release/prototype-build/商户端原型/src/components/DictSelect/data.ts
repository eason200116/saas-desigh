// 动态字典 mock —— 给 AsyncSelect / useDictionary({source:'dynamic'}) 提供数据
// 视图调用：api.common.getDynamicDictionary({ keys: ['roleList', 'tenantList', ...] })
// 返回结构：{ code:0, data: { roleList: [...], tenantList: [...], ... } }
// 字段命名约定见 useDictionary.ts FIELD_MAP（roleList → label:roleName / value:roleId 等）

const ROLE_LIST = [
  { roleId: 1, roleName: '超级管理员', state: true, isSuperAdmin: true, remark: '拥有所有权限' },
  { roleId: 2, roleName: '财务管理员', state: true, isSuperAdmin: false, remark: '财务模块管理' },
  { roleId: 3, roleName: '客服专员', state: true, isSuperAdmin: false, remark: '会员服务' },
  { roleId: 4, roleName: '审核员', state: true, isSuperAdmin: false, remark: '订单审核' },
  { roleId: 5, roleName: '运营专员', state: true, isSuperAdmin: false, remark: '商户运营' },
  { roleId: 6, roleName: '远端-组长', state: true, isSuperAdmin: false, remark: '出款组长' },
  { roleId: 7, roleName: '远端-组员', state: true, isSuperAdmin: false, remark: '出款组员' },
  { roleId: 8, roleName: '只读用户', state: false, isSuperAdmin: false, remark: '已禁用' },
  { roleId: 9, roleName: '商户管理员', state: true, isSuperAdmin: false, remark: '单商户全权限' },
];

const TENANT_LIST = [
  {
    tenantId: 1050,
    tenantName: 'daman',
    tenantNickName: '(1050) daman',
    orgId: 1001,
    orgName: '亚太集团',
    state: true,
    currency: 'INR',
  },
  {
    tenantId: 1048,
    tenantName: '91club',
    tenantNickName: '(1048) 91club',
    orgId: 1001,
    orgName: '亚太集团',
    state: true,
    currency: 'INR',
  },
  {
    tenantId: 1021,
    tenantName: '55club',
    tenantNickName: '(1021) 55club',
    orgId: 1002,
    orgName: '南亚集团',
    state: true,
    currency: 'INR',
  },
  {
    tenantId: 1040,
    tenantName: 'ugame',
    tenantNickName: '(1040) ugame',
    orgId: 1002,
    orgName: '南亚集团',
    state: true,
    currency: 'BRL',
  },
  {
    tenantId: 1070,
    tenantName: 'bdggame',
    tenantNickName: '(1070) bdggame',
    orgId: 1003,
    orgName: '东南亚集团',
    state: true,
    currency: 'VND',
  },
  {
    tenantId: 1090,
    tenantName: 'tirgame',
    tenantNickName: '(1090) tirgame',
    orgId: 1003,
    orgName: '东南亚集团',
    state: false,
    currency: 'VND',
  },
  // ── 新增 10 个商户（与 user store / api 商户主数据保持一致）──
  {
    tenantId: 1052,
    tenantName: 'fun88',
    tenantNickName: '(1052) fun88',
    orgId: 1001,
    orgName: '亚太集团',
    state: true,
    currency: 'INR',
  },
  {
    tenantId: 1054,
    tenantName: 'jeetwin',
    tenantNickName: '(1054) jeetwin',
    orgId: 1001,
    orgName: '亚太集团',
    state: true,
    currency: 'INR',
  },
  {
    tenantId: 1038,
    tenantName: 'pop888',
    tenantNickName: '(1038) pop888',
    orgId: 1002,
    orgName: '南亚集团',
    state: true,
    currency: 'BRL',
  },
  {
    tenantId: 1042,
    tenantName: 'betbra',
    tenantNickName: '(1042) betbra',
    orgId: 1002,
    orgName: '南亚集团',
    state: true,
    currency: 'BRL',
  },
  {
    tenantId: 1030,
    tenantName: 'thaifortune',
    tenantNickName: '(1030) thaifortune',
    orgId: 1003,
    orgName: '东南亚集团',
    state: true,
    currency: 'THB',
  },
  {
    tenantId: 1036,
    tenantName: 'vn168',
    tenantNickName: '(1036) vn168',
    orgId: 1003,
    orgName: '东南亚集团',
    state: true,
    currency: 'VND',
  },
  {
    tenantId: 1072,
    tenantName: 'thaiwin',
    tenantNickName: '(1072) thaiwin',
    orgId: 1003,
    orgName: '东南亚集团',
    state: false,
    currency: 'THB',
  },
  {
    tenantId: 1080,
    tenantName: 'euroking',
    tenantNickName: '(1080) euroking',
    orgId: 1004,
    orgName: '欧美集团',
    state: true,
    currency: 'USD',
  },
  {
    tenantId: 1082,
    tenantName: 'vegas88',
    tenantNickName: '(1082) vegas88',
    orgId: 1004,
    orgName: '欧美集团',
    state: true,
    currency: 'USD',
  },
  {
    tenantId: 1099,
    tenantName: 'globalbet',
    tenantNickName: '(1099) globalbet',
    orgId: 1004,
    orgName: '欧美集团',
    state: true,
    currency: 'USD',
  },
];

const ORGANIZATION_LIST = [
  { orgId: 1001, orgName: '亚太集团', state: true },
  { orgId: 1002, orgName: '南亚集团', state: true },
  { orgId: 1003, orgName: '东南亚集团', state: true },
  { orgId: 1004, orgName: '欧美集团', state: true },
];

const SYS_CURRENCY_LIST = [
  { id: 1, sysCurrency: 'INR', name: '印度卢比', symbol: '₹', state: true },
  { id: 2, sysCurrency: 'USDT', name: 'USDT', symbol: '$', state: true },
  { id: 3, sysCurrency: 'BRL', name: '巴西雷亚尔', symbol: 'R$', state: true },
  { id: 4, sysCurrency: 'VND', name: '越南盾', symbol: '₫', state: true },
  { id: 5, sysCurrency: 'CNY', name: '人民币', symbol: '¥', state: true },
  { id: 6, sysCurrency: 'USD', name: '美元', symbol: '$', state: true },
  { id: 7, sysCurrency: 'THB', name: '泰铢', symbol: '฿', state: true },
];

const PAY_CODE_LIST = [
  { id: 1, payCode: 'UPI_PAY', name: 'UPI 支付', state: true },
  { id: 2, payCode: 'BANK_CARD', name: '银行卡', state: true },
  { id: 3, payCode: 'USDT_TRC20', name: 'USDT-TRC20', state: true },
  { id: 4, payCode: 'USDT_ERC20', name: 'USDT-ERC20', state: true },
  { id: 5, payCode: 'PIX', name: 'PIX', state: true },
  { id: 6, payCode: 'GOPAY', name: 'GoPay', state: true },
];

const THIRD_PAY_MERCHANT_LIST = [
  { merchantId: 5001, customName: 'PayU India 主商户', payCode: 'UPI_PAY', state: true },
  { merchantId: 5002, customName: 'PayU India 备用', payCode: 'UPI_PAY', state: true },
  { merchantId: 5003, customName: 'Razorpay 主商户', payCode: 'BANK_CARD', state: true },
  { merchantId: 5004, customName: 'TronPay USDT', payCode: 'USDT_TRC20', state: true },
  { merchantId: 5005, customName: 'PIX Brazil', payCode: 'PIX', state: true },
  { merchantId: 5006, customName: 'GoPay VND', payCode: 'GOPAY', state: true },
];

const TENANT_PAY_CHANNEL_LIST = [
  {
    tenantChannelId: 7001,
    customName: 'daman-UPI-A',
    tenantId: 1050,
    payCode: 'UPI_PAY',
    state: true,
  },
  {
    tenantChannelId: 7002,
    customName: 'daman-Bank-A',
    tenantId: 1050,
    payCode: 'BANK_CARD',
    state: true,
  },
  {
    tenantChannelId: 7003,
    customName: '91club-UPI-A',
    tenantId: 1048,
    payCode: 'UPI_PAY',
    state: true,
  },
  { tenantChannelId: 7004, customName: 'ugame-PIX', tenantId: 1040, payCode: 'PIX', state: true },
];

const SYS_PAY_CHANNEL_LIST = [
  { sysChannelId: 8001, sysChannelName: 'UPI 通用通道', payCode: 'UPI_PAY', state: true },
  { sysChannelId: 8002, sysChannelName: '银行卡通用通道', payCode: 'BANK_CARD', state: true },
  { sysChannelId: 8003, sysChannelName: 'USDT-TRC20 通道', payCode: 'USDT_TRC20', state: true },
  { sysChannelId: 8004, sysChannelName: 'PIX 通道', payCode: 'PIX', state: true },
];

const RECHARGE_CATEGORY_LIST = [
  { id: 1, name: 'UPI 充值', sysCategoryId: 101, state: true },
  { id: 2, name: '银行卡充值', sysCategoryId: 102, state: true },
  { id: 3, name: 'USDT 充值', sysCategoryId: 103, state: true },
  { id: 4, name: 'PIX 充值', sysCategoryId: 104, state: true },
];

const WITHDRAW_CATEGORY_LIST = [
  { id: 1, name: 'IMPS 提现', sysCategoryId: 201, state: true },
  { id: 2, name: 'HDFC 银行卡提现', sysCategoryId: 202, state: true },
  { id: 3, name: 'USDT-TRC20 提现', sysCategoryId: 203, state: true },
  { id: 4, name: 'UPI 提现', sysCategoryId: 204, state: true },
  { id: 5, name: 'PIX 提现', sysCategoryId: 205, state: true },
];

const MENU_LIST = [
  { menuId: 1, menuName: '会员管理', authCode: 'Member' },
  { menuId: 2, menuName: '财务管理', authCode: 'Finance' },
  { menuId: 3, menuName: '游戏管理', authCode: 'Game' },
  { menuId: 4, menuName: '系统管理', authCode: 'SystemManage' },
  { menuId: 5, menuName: '商户管理', authCode: 'Tenant' },
  { menuId: 6, menuName: '报表管理', authCode: 'Report' },
];

const WITHDRAW_CONFIG_GROUP_LIST = [
  { configGroupId: 11, groupName: 'A组 - 常规出款', state: true },
  { configGroupId: 12, groupName: 'B组 - 大额出款', state: true },
  { configGroupId: 13, groupName: 'C组 - VIP 通道', state: true },
  { configGroupId: 14, groupName: 'D组 - USDT 专组', state: true },
  { configGroupId: 15, groupName: 'E组 - 应急组', state: false },
];

const APPROVAL_AUTHORIZE_LIST = [
  { id: 1, name: '充值权限', code: 'recharge' },
  { id: 2, name: '审核权限', code: 'audit' },
  { id: 3, name: '单笔权限', code: 'single' },
  { id: 4, name: '批量权限', code: 'batch' },
];

// userName 后端用 Dictionary<int,string>；useDictionary 内部会归一化为 [{id,name}]
const USER_NAME_DICT: Record<number, string> = {
  1: 'admin001',
  2: 'finance001',
  3: 'service007',
  4: 'remote_lead05',
  10001: 'finance_lead',
  10002: 'finance_mgr',
  20001: 'tenant_admin_01',
  20002: 'tenant_admin_02',
  20003: 'withdraw_audit_01',
};

// ── 商户字典（总控端-商户管理-配置管理：国家/币种/语言管理三个页签的新增/编辑弹窗下拉框用）──
// value = 该字典的业务代码（时区用 IANA 时区名，国家/币种/语言用通行 ISO 代码）
// label = 中文展示名（时区额外带 UTC 偏移量，格式「国家名(+X)」）

const TIME_ZONE_DICTIONARY_LIST = [
  { value: 'Asia/Kolkata', label: '印度(+5:30)' },
  { value: 'Asia/Dhaka', label: '孟加拉(+6)' },
  { value: 'Asia/Colombo', label: '斯里兰卡(+5:30)' },
  { value: 'Asia/Kathmandu', label: '尼泊尔(+5:45)' },
  { value: 'Asia/Karachi', label: '巴基斯坦(+5)' },
  { value: 'Asia/Bangkok', label: '泰国(+7)' },
  { value: 'Asia/Ho_Chi_Minh', label: '越南(+7)' },
  { value: 'Asia/Kuala_Lumpur', label: '马来西亚(+8)' },
  { value: 'Asia/Yangon', label: '缅甸(+6:30)' },
  { value: 'Asia/Jakarta', label: '印度尼西亚(+7)' },
  { value: 'Asia/Manila', label: '菲律宾(+8)' },
  { value: 'Asia/Singapore', label: '新加坡(+8)' },
  { value: 'Asia/Phnom_Penh', label: '柬埔寨(+7)' },
  { value: 'Asia/Vientiane', label: '老挝(+7)' },
  { value: 'Asia/Shanghai', label: '中国(+8)' },
  { value: 'Asia/Tokyo', label: '日本(+9)' },
  { value: 'Asia/Seoul', label: '韩国(+9)' },
  { value: 'Asia/Dubai', label: '阿联酋(+4)' },
  { value: 'Asia/Riyadh', label: '沙特阿拉伯(+3)' },
  { value: 'Asia/Almaty', label: '哈萨克斯坦(+6)' },
  { value: 'Asia/Tashkent', label: '乌兹别克斯坦(+5)' },
  { value: 'Africa/Cairo', label: '埃及(+3)' },
  { value: 'Africa/Lagos', label: '尼日利亚(+1)' },
  { value: 'Africa/Johannesburg', label: '南非(+2)' },
  { value: 'Africa/Nairobi', label: '肯尼亚(+3)' },
  { value: 'Africa/Casablanca', label: '摩洛哥(+1)' },
  { value: 'Africa/Nouakchott', label: '毛里塔尼亚(+0)' },
  { value: 'Europe/London', label: '英国(+0)' },
  { value: 'Europe/Paris', label: '法国(+1)' },
  { value: 'Europe/Berlin', label: '德国(+1)' },
  { value: 'Europe/Madrid', label: '西班牙(+1)' },
  { value: 'Europe/Moscow', label: '俄罗斯(+3)' },
  { value: 'Europe/Istanbul', label: '土耳其(+3)' },
  { value: 'America/Sao_Paulo', label: '巴西(-3)' },
  { value: 'America/New_York', label: '美国东部(-5)' },
  { value: 'America/Los_Angeles', label: '美国西部(-8)' },
  { value: 'America/Mexico_City', label: '墨西哥(-6)' },
  { value: 'America/Bogota', label: '哥伦比亚(-5)' },
  { value: 'America/Lima', label: '秘鲁(-5)' },
  { value: 'America/Argentina/Buenos_Aires', label: '阿根廷(-3)' },
  { value: 'America/Caracas', label: '委内瑞拉(-4)' },
  { value: 'Pacific/Port_Moresby', label: '巴布亚新几内亚(+10)' },
  { value: 'Pacific/Fiji', label: '斐济(+12)' },
  { value: 'Australia/Sydney', label: '澳大利亚(+10)' },
  { value: 'Pacific/Auckland', label: '新西兰(+12)' },
];

const COUNTRY_DICTIONARY_LIST = [
  { value: 'IND', label: '印度' },
  { value: 'BRA', label: '巴西' },
  { value: 'THA', label: '泰国' },
  { value: 'VNM', label: '越南' },
  { value: 'MYS', label: '马来西亚' },
  { value: 'MMR', label: '缅甸' },
  { value: 'PAK', label: '巴基斯坦' },
  { value: 'BGD', label: '孟加拉国' },
  { value: 'LKA', label: '斯里兰卡' },
  { value: 'NPL', label: '尼泊尔' },
  { value: 'IDN', label: '印度尼西亚' },
  { value: 'PHL', label: '菲律宾' },
  { value: 'SGP', label: '新加坡' },
  { value: 'KHM', label: '柬埔寨' },
  { value: 'LAO', label: '老挝' },
  { value: 'CHN', label: '中国' },
  { value: 'JPN', label: '日本' },
  { value: 'KOR', label: '韩国' },
  { value: 'ARE', label: '阿联酋' },
  { value: 'SAU', label: '沙特阿拉伯' },
  { value: 'EGY', label: '埃及' },
  { value: 'NGA', label: '尼日利亚' },
  { value: 'ZAF', label: '南非' },
  { value: 'KEN', label: '肯尼亚' },
  { value: 'MAR', label: '摩洛哥' },
  { value: 'MRT', label: '毛里塔尼亚' },
  { value: 'GBR', label: '英国' },
  { value: 'FRA', label: '法国' },
  { value: 'DEU', label: '德国' },
  { value: 'ESP', label: '西班牙' },
  { value: 'ITA', label: '意大利' },
  { value: 'RUS', label: '俄罗斯' },
  { value: 'TUR', label: '土耳其' },
  { value: 'USA', label: '美国' },
  { value: 'MEX', label: '墨西哥' },
  { value: 'COL', label: '哥伦比亚' },
  { value: 'ARG', label: '阿根廷' },
  { value: 'PER', label: '秘鲁' },
  { value: 'CHL', label: '智利' },
  { value: 'VEN', label: '委内瑞拉' },
  { value: 'AUS', label: '澳大利亚' },
  { value: 'NZL', label: '新西兰' },
  { value: 'KAZ', label: '哈萨克斯坦' },
  { value: 'UZB', label: '乌兹别克斯坦' },
  { value: 'PNG', label: '巴布亚新几内亚' },
  { value: 'FJI', label: '斐济' },
];

const CURRENCY_DICTIONARY_LIST = [
  { value: 'INR', label: '印度卢比' },
  { value: 'BRL', label: '巴西雷亚尔' },
  { value: 'THB', label: '泰铢' },
  { value: 'VND', label: '越南盾' },
  { value: 'MYR', label: '马来西亚林吉特' },
  { value: 'MMK', label: '缅甸元' },
  { value: 'PKR', label: '巴基斯坦卢比' },
  { value: 'XOF', label: '西非法郎' },
  { value: 'PGK', label: '巴布亚新几内亚基那' },
  { value: 'FJD', label: '斐济元' },
  { value: 'PEN', label: '秘鲁索尔' },
  { value: 'CHF', label: '瑞士法郎' },
  { value: 'VES', label: '委内瑞拉玻利瓦尔' },
  { value: 'MRU', label: '毛里塔尼亚乌吉亚' },
  { value: 'USD', label: '美元' },
  { value: 'EUR', label: '欧元' },
  { value: 'GBP', label: '英镑' },
  { value: 'JPY', label: '日元' },
  { value: 'CNY', label: '人民币' },
  { value: 'KRW', label: '韩元' },
  { value: 'SGD', label: '新加坡元' },
  { value: 'HKD', label: '港元' },
  { value: 'TWD', label: '新台币' },
  { value: 'AUD', label: '澳大利亚元' },
  { value: 'NZD', label: '新西兰元' },
  { value: 'CAD', label: '加拿大元' },
  { value: 'MXN', label: '墨西哥比索' },
  { value: 'ARS', label: '阿根廷比索' },
  { value: 'COP', label: '哥伦比亚比索' },
  { value: 'CLP', label: '智利比索' },
  { value: 'PYG', label: '巴拉圭瓜拉尼' },
  { value: 'BOB', label: '玻利维亚诺' },
  { value: 'UYU', label: '乌拉圭比索' },
  { value: 'ZAR', label: '南非兰特' },
  { value: 'NGN', label: '尼日利亚奈拉' },
  { value: 'KES', label: '肯尼亚先令' },
  { value: 'EGP', label: '埃及镑' },
  { value: 'MAD', label: '摩洛哥迪拉姆' },
  { value: 'AED', label: '阿联酋迪拉姆' },
  { value: 'SAR', label: '沙特里亚尔' },
  { value: 'TRY', label: '土耳其里拉' },
  { value: 'RUB', label: '俄罗斯卢布' },
  { value: 'IDR', label: '印度尼西亚盾' },
  { value: 'PHP', label: '菲律宾比索' },
  { value: 'KHR', label: '柬埔寨瑞尔' },
  { value: 'LAK', label: '老挝基普' },
  { value: 'BDT', label: '孟加拉塔卡' },
  { value: 'LKR', label: '斯里兰卡卢比' },
  { value: 'NPR', label: '尼泊尔卢比' },
  { value: 'KZT', label: '哈萨克斯坦坚戈' },
  { value: 'UZS', label: '乌兹别克斯坦索姆' },
  { value: 'USDT', label: 'USDT(泰达币)' },
];

const LANGUAGE_DICTIONARY_LIST = [
  { value: 'en', label: '英语' },
  { value: 'hi', label: '印地语' },
  { value: 'pt', label: '葡萄牙语' },
  { value: 'vi', label: '越南语' },
  { value: 'th', label: '泰语' },
  { value: 'id', label: '印度尼西亚语' },
  { value: 'zh-TW', label: '中文繁体' },
  { value: 'ms', label: '马来语' },
  { value: 'ur', label: '乌尔都语' },
  { value: 'nb', label: '书面挪威语' },
  { value: 'si', label: '僧伽罗语' },
  { value: 'jv', label: '爪哇语' },
  { value: 'yi', label: '依地语' },
  { value: 'na', label: '瑙鲁语' },
  { value: 'yo', label: '约鲁巴语' },
  { value: 'zh', label: '中文简体' },
  { value: 'ja', label: '日语' },
  { value: 'ko', label: '韩语' },
  { value: 'es', label: '西班牙语' },
  { value: 'fr', label: '法语' },
  { value: 'de', label: '德语' },
  { value: 'ru', label: '俄语' },
  { value: 'ar', label: '阿拉伯语' },
  { value: 'bn', label: '孟加拉语' },
  { value: 'ta', label: '泰米尔语' },
  { value: 'te', label: '泰卢固语' },
  { value: 'mr', label: '马拉地语' },
  { value: 'gu', label: '古吉拉特语' },
  { value: 'pa', label: '旁遮普语' },
  { value: 'km', label: '高棉语' },
  { value: 'lo', label: '老挝语' },
  { value: 'my', label: '缅甸语' },
  { value: 'ne', label: '尼泊尔语' },
  { value: 'sw', label: '斯瓦希里语' },
  { value: 'am', label: '阿姆哈拉语' },
  { value: 'ha', label: '豪萨语' },
  { value: 'zu', label: '祖鲁语' },
  { value: 'tr', label: '土耳其语' },
  { value: 'it', label: '意大利语' },
  { value: 'tl', label: '他加禄语' },
];

const FULL_DICT: Record<string, unknown> = {
  organizationList: ORGANIZATION_LIST,
  tenantList: TENANT_LIST,
  sysCurrencyList: SYS_CURRENCY_LIST,
  payCodeList: PAY_CODE_LIST,
  thirdPayMerchantList: THIRD_PAY_MERCHANT_LIST,
  tenantPayChannelList: TENANT_PAY_CHANNEL_LIST,
  sysPayChannelList: SYS_PAY_CHANNEL_LIST,
  rechargeCategoryList: RECHARGE_CATEGORY_LIST,
  withdrawCategoryList: WITHDRAW_CATEGORY_LIST,
  roleList: ROLE_LIST,
  menuList: MENU_LIST,
  withdrawConfigGroupList: WITHDRAW_CONFIG_GROUP_LIST,
  approvalAuthorizeList: APPROVAL_AUTHORIZE_LIST,
  userName: USER_NAME_DICT,
  timeZoneDictionaryList: TIME_ZONE_DICTIONARY_LIST,
  countryDictionaryList: COUNTRY_DICTIONARY_LIST,
  currencyDictionaryList: CURRENCY_DICTIONARY_LIST,
  languageDictionaryList: LANGUAGE_DICTIONARY_LIST,
};

async function getDynamicDictionary(req?: any) {
  const keys: string[] = Array.isArray(req?.keys) ? req.keys : Object.keys(FULL_DICT);
  const data: Record<string, unknown> = {};
  for (const key of keys) {
    if (key in FULL_DICT) data[key] = FULL_DICT[key];
  }
  return { code: 0, result: true, data, msg: 'success' };
}

export const api: any = {
  common: {
    getDynamicDictionary,
  },
};

export const http: any = new Proxy(
  {},
  {
    get(_t: any, _method: string) {
      return async (..._args: any[]) => ({ code: 0, result: true, data: null, msg: 'success' });
    },
  },
);
