// 渠道包管理（商户端 tenant · operations_appPackage）功能说明书。
// 锚定 src/views/operations/package/index.vue(纯壳，直接渲染 src/views/operations/app/components/PackageTab.vue)
// + PackageFormModal.vue + JobStatsBar.vue + data.ts 真实控件（R53 实证、不臆造）。
//
// 注：还存在一个 hidden:true 的路由 operations_app（菜单隐藏，router 注释明写"与独立的版本上架/渠道包管理重复"），
// 其内部 Tab 用的正是同一个 PackageTab.vue 组件——本说明书覆盖的就是这份共享内容，不重复为 operations_app 单独建说明书。

import type { PageManual } from '../types';

const manual: PageManual = {
  route: 'operations_appPackage',
  title: '渠道包管理',
  overview:
    '商户端「运营管理 › 渠道包管理」页，维护APP的渠道分发包基础信息（渠道标识/应用名/包名/图标/启动图/签名与打包配置），' +
    '每个渠道包可派生多个"打包任务"（构建/上传两种类型），任务列表+日志通过右侧抽屉查看。' +
    '2026-07-22核实代码发现与「APP版本上架」页同类问题：打包任务相关的4个mock方法（jobsList/jobLogsList/' +
    'jobsCreate/cancel/retry）在 data.ts 里全部恒返回 data:null，导致点开"任务列表"抽屉恒显示空状态' +
    '("暂无任务"+"创建第一个任务"引导)、点"创建任务"后也不会真的出现在列表里（因为列表本身是空的）、' +
    '"查看日志"抽屉同样恒空。渠道包列表本身(appPackagesList)有6条真实mock数据，这部分展示正常。如实记录，未修复。',
  items: [
    {
      anchor: 'tenantId',
      name: '商户',
      group: '搜索',
      interaction: '下拉单选筛选。',
    },
    {
      anchor: 'platform',
      name: '平台',
      group: '搜索',
      interaction: '下拉单选，可清空；当前选项仅"Android"一项。',
    },
    {
      anchor: 'act_add',
      name: '新增渠道包',
      group: '操作',
      interaction: '主色按钮，点击打开新增弹窗（860px宽）。',
      logic:
        '弹窗字段：商户/平台(固定Android)/渠道标识/应用名称/包名(前缀只读+可编辑后缀拼成完整包名)/' +
        'App图标(PNG 512×512 ≤1MB)/启动闪屏图(PNG/JPG 1080×2340 ≤2MB)/开屏引导图(PNG/JPG 1080×2340 ≤5MB)' +
        '三个图片上传控件（各自独立尺寸限制，hover问号图标查看）/签名配置+打包配置(两个多行文本域，JSON/配置文本形式)。',
    },
    {
      anchor: 'col_jobCount',
      name: '任务数（可点击）',
      group: '列',
      interaction: '数量>0时显示"N个任务"蓝字可点，=0时显示灰色"-"。',
      logic: '点击打开右侧任务列表抽屉（同 act_detail 行操作，见下）。',
    },
    {
      anchor: 'col_latestJob',
      name: '最新任务状态（可点击）',
      group: '列',
      interaction: '有最新任务则显示"状态点+状态文字"（待处理/执行中/已完成/失败/已取消五态），悬停显示相对时间；无则显示"-"。',
      logic: '点击同样打开任务列表抽屉。',
    },
    {
      anchor: 'act_detail',
      name: '详情（行操作）',
      group: '操作',
      interaction: '每行常驻，点击打开右侧「任务列表」抽屉。',
      logic:
        '抽屉内容：①渠道包基础信息卡片(图标/应用名/平台Tag/渠道标识Tag/包名/商户ID) ②App图标/启动图/开屏图' +
        '预览(仅已配置的图会显示) ③任务统计条(JobStatsBar：总数/待处理/执行中/已完成/失败，纯展示计数，随任务' +
        '列表实时统计) ④任务列表(时间轴卡片式，每条含状态指示灯/任务ID/类型Tag(构建|上传)/状态文字/操作按钮' +
        '"查看日志"常驻+"取消"(待处理|执行中态显示)+"重试"(失败|已取消态显示)，执行中态显示进度条，已完成态显示' +
        '产物下载按钮+文件大小，失败态显示错误信息文字) ⑤顶部"重新创建任务"按钮(执行中态禁用)+刷新按钮。',
    },
    {
      anchor: 'act_createJob',
      name: '创建任务（条件显示，行操作/抽屉内均有）',
      group: '操作',
      interaction: '仅"最新任务状态≠执行中"的行显示；抽屉内顶部"重新创建任务"按钮同逻辑（执行中态禁用）。',
      logic: '点击弹二次确认，确认后调用创建任务接口（jobType固定build，priority固定5），成功后刷新任务列表。',
      edge: '因 jobsCreate/jobsList 均恒返回空数据，创建后任务列表依旧不会出现新任务，无法在原型里实际观察到任务生命周期流转。',
    },
    {
      anchor: 'act_viewLogs',
      name: '查看日志（任务列表抽屉内，每条任务常驻）',
      group: '操作',
      interaction: '圆形图标按钮，hover提示"查看日志"，点击打开右侧「日志」抽屉（时间轴形式展示日志条目，含级别/内容）。',
    },
    {
      anchor: 'act_cancelJob',
      name: '取消任务（条件显示，仅待处理/执行中态）',
      group: '操作',
      interaction: '橙色圆形图标按钮，点击弹二次确认（警示色）。',
    },
    {
      anchor: 'act_retryJob',
      name: '重试任务（条件显示，仅失败/已取消态）',
      group: '操作',
      interaction: '蓝色圆形图标按钮，点击弹二次确认。',
    },
    {
      anchor: 'act_edit',
      name: '编辑',
      group: '操作',
      interaction: '每行常驻，点击打开编辑弹窗（字段同新增，回显当前值）。',
    },
    {
      anchor: 'act_delete',
      name: '删除',
      group: '操作',
      interaction: '每行常驻，危险色，点击弹二次确认。',
    },
    {
      anchor: 'reset',
      name: '重置',
      group: '搜索',
      interaction: 'ProCrudTable内置重置按钮，点击清空全部搜索条件并重新查询。',
    },
  ],
  fields: [
    { name: 'ID', def: '该渠道包记录的唯一编号。' },
    { name: '商户', def: '该渠道包所属商户，悬停显示商户ID。' },
    { name: '平台', def: 'Android/iOS，彩色Tag展示（当前仅Android）。' },
    { name: '渠道标识', def: '该渠道包的推广渠道代码（如GG01/AS01）。' },
    { name: '包名', def: '完整应用包名（如 com.ar.lotto.gg），超长省略+悬停看全。' },
    { name: '应用名称', def: '该渠道包对外展示的App名称。' },
    { name: 'App图标', def: '缩略图预览，无则显示"-"。' },
    { name: '任务数', def: '该渠道包累计发起过的打包任务总数，见交互条目 col_jobCount。' },
    { name: '最新任务', def: '该渠道包最近一次打包任务的状态，见交互条目 col_latestJob。' },
    { name: '创建时间', def: '该渠道包记录的创建时间。' },
  ],
};

export default manual;
