// 银行字典（双端 admin+tenant · finance_merchant_bank_dictionary_page）功能说明书。
// 锚定 src/views/finance/bankDictionary/index.vue + data.ts + components/BankAddModal.vue +
// components/BatchImportModal.vue 真实控件（R53 实证、不臆造）。
//
// 2026-07-24 三轮迭代小结（本文件此前长期停留在第一轮改版之前的旧结构未同步更新，本次借第三轮
// 改动一并整体重写，消除"文档仍描述商户列/多值币种/6项类型"等已不存在的内容，避免新旧描述自相矛盾）：
// 第一轮(87e32176)：彻底移除"商户"概念(筛选/列/新增弹窗均不再出现tenantId)；银行名称+编码合并为
//   单一模糊搜索框(bankNameOrCode)；币种收窄为单值、移至搜索区/列表首位；银行类型下拉收窄为
//   4项固定值(银行卡/电子钱包/KBZ/WAVE)；银行编码"是否独立编码"判断由字符串相似度启发式改为
//   "{币种}{4位流水号}"格式正则校验；新增「新增」按钮+BankAddModal弹窗。
// 第二轮(cabac695)：批量导入模板/预览8条样例数据格式跟上第一轮新体系；新增弹窗补状态开关+
//   4项必填校验。
// 第三轮(a510014c)：币种筛选/列、「新增」按钮改为仅总控端(admin)可见、商户端(tenant)不再出现——与
//   第一轮"两端做成完全一致的全局字典"方向相反，是 Eason 明确要求的角色差异化调整；同时把此前
//   保留的3条空银行编码演示记录(bankId 8/11/13)补全为正规"{币种}{编号}"格式，全部15条种子数据
//   现在都是合规编码。
// 第四轮(本次，Ar V3 agent 直接会话确认，Eason 主动方向调整非 bug 修复)：反转第一轮"彻底移除
//   商户概念"的一半——总控端(admin)维持"全局字典不分商户"不变；商户端(tenant)恢复"商户"筛选项
//   (必选单选、默认当前商户、不可清空，R63)+表格列，均置于首位，与仅总控端可见的"币种"筛选/列
//   互斥（同一角色下二者不会同时出现）。tenantId 字段重新参与商户端查询过滤。新增/批量导入弹窗
//   不受影响（仍仅总控端可见，双端表单本身都不涉及商户字段）。
// 第五轮(本次，Eason 拍板 4 项确认)：①② bankCode/bankType 两个 i18n key（列表列+新增弹窗+搜索
//   筛选项三处共用同一 key，改一处三处同时生效）文案精简："银行字典Code"→"银行编码"、"银行字典
//   类型"→"银行类型"；此举顺带消除了此前 col_bankCode 记录的"同一字段两个 key 文案不一致"问题
//   （finance.prototype.fields.bankCode 本就是"银行编码"，现与本页 key 完全对齐）。③④「银行名称/
//   Code」搜索项由模糊文本框改造为下拉精确选中：选项数据源=data.ts 完整银行列表(getAllBanks())，
//   label="{bankCode} → {bankName}"（无独立编码时只显示银行名称本身，不出现"→ 空白"，口径复用
//   hasIndependentBankCode）；value 优先 bankCode，无独立编码时兜底 bankId（BankRecord 现成唯一
//   id 字段，规避 bankName 潜在重名——当前数据"ICICI Bank"/"Paytm Payments Bank"各有两条同名记录）；
//   data.ts getTabBanksPageList 的匹配逻辑同步由子串模糊匹配改为按选中标识精确匹配。⑤ 该搜索项
//   i18n label 文案顺手精简："银行名称/Code"→"银行名称"（"/Code"后缀不再准确，因搜索方式已从
//   "名称或编码模糊文本"改为下拉精确选中，且下拉每项本身就同时展示编码+名称，无需在 label 里
//   再强调"Code"）。双端同步生效，不加角色判断。
// 第六轮（本次，Eason 通过总PM确认，R83 arv3-executor 执行）：「新增」弹窗删除"银行编码"整个表单项
//   （表单项+输入框均移除），弹窗字段收窄为 3 项：币种/银行名称/银行类型（+状态开关，共 4 项控件，
//   3 项必填）。提交时固定传 bankCode:''，复用既有 hasIndependentBankCode() 灰色兜底展示分支（列表/
//   下拉展示银行名称本身），未新增任何编码生成逻辑。仅改 BankAddModal.vue；列表「银行编码」列、
//   搜索区「银行名称」下拉均不受影响、照常保留。
// 第七轮（本次，总控端专属，R83 arv3-executor 执行）：总控(admin)角色列表末列由「状态」改为「操作」
//   （编辑按钮，createActionColumn + ifShow:isSuperAuthUser，fixed:'right'+lockFixed），状态开关移入
//   编辑弹窗内维护；商户(tenant)角色列表「状态」列（ConfirmSwitch 行内开关）100% 原样不动。BankAddModal
//   改造为新增/编辑共用组件（新增 props.detail，isEdit=!!detail?.bankId）：编辑态下币种/银行类型两个
//   下拉只读(disabled=isEdit)，银行名称/状态保持可编辑；提交按 isEdit 分支调新增 data.ts 方法
//   updateBank({bankId,currency,bankName,bankType,state})（仅落地 bankName/state 两个字段的变更，
//   currency/bankType 只读理论上不会变），成功提示复用 common.updateSuccess（新增态仍是 common.addSuccess）。
//   新增 i18n key finance.setting.bankDictionary.edit.title="编辑银行字典"（En: Edit Bank Dictionary）。
//   搜索区「状态」筛选项、新增弹窗其余行为均未改动。
// 第八轮（本次，总PM转达 Eason 多轮确认口径，R83 arv3-executor 执行）：
//   批量导入弹窗(BatchImportModal) 4 处调整：①模版下载 CSV 去掉"银行编码"列（3列：银行名称/银行
//   类型/币种），预览表格 batchColumns 刻意不变仍保留银行编码列（Eason 已确认模版与预览允许不
//   一致，非疏漏）；②底部主按钮文案由"一键执行"改"确认导入"（此前交互上第一层弹窗没有任何按钮
//   带"确认"字样，只有点击后弹出的二级确认框内才有，本轮在第一层补上；点击行为不变，仍先弹
//   dialog.warning 二次确认框，二级确认框逻辑本身未改动）；③顶部 n-alert 新增一行静态提示（新增
//   data-manual="batch_alert" 锚点），列出当前支持的4个银行类型：银行卡/电子钱包/KBZ/WAVE（不按
//   币种动态过滤——批量导入一次可能涵盖多币种行，没有单一"当前币种"上下文）；④BATCH_SAMPLE_ROWS
//   样例数据由 8 条扩充到 13 条，新增 MYR 银行卡通过样例、VND 币种下 KBZ/WAVE 银行类型通过样例、
//   BRL 电子钱包通过样例，以及 1 条 MYR 编码重复（复用 BANK_LIST 真实记录 MYR0001）失败样例。
//   新增弹窗(BankAddModal) 4 处调整：①币种下拉去掉 USDT（INR/USDT/BRL/VND/MYR → INR/BRL/VND/MYR，
//   仅本弹窗收窄，列表筛选/列的 CURRENCY_OPTIONS 与批量导入历史数据不受影响仍含 USDT）；②币种↔
//   银行类型联动——新增态下 formData.bankType 初始值由固定预填"银行卡"改为空字符串，下拉在
//   `isEdit || !formData.currency` 为真时禁用，未选币种时 placeholder 提示"请先选择币种"
//   （selectCurrencyFirst），选定币种后启用、仍照常显示固定4个选项（不按币种再过滤，Eason 已确认
//   无具体对照表暂不做差异化）；编辑态不受影响，币种/银行类型仍恒只读、值取自 detail 回显；③银行
//   名称与币种调换渲染顺序（银行名称在前、币种在后，银行类型/状态两项位置不变），新增/编辑共用
//   同一模板故两态同步生效；列表 tableColumns 的币种/银行名称列序刻意不联动（R60 特例，Eason 已
//   确认不用同步）；④新增态"确认→预览→发布"三步流程（仅新增态，编辑态维持现状不变）：点击原
//   「确定」按钮校验通过后不再直接调 addBank，改为先弹预览确认框 openAddPreview()（参照
//   BatchImportModal.vue executeBatch() 的 useDialog()+dialog.warning 写法，全站风格一致）——展示
//   本次要新增的数据摘要(币种/银行名称/银行类型/状态，纯文字) + 该币种关联商户名单+总数（数据来源
//   新增的 tenant/merchantManage/data.ts 导出函数 getMerchantsByCurrency()，按 currency 过滤，0 家
//   时展示"该币种暂无关联商户"，不算错误）；预览框「取消」（negativeText，复用 common.cancel）
//   关闭预览回到表单、不提交；「发布」（positiveText，复用已有 common.publish）才真正调用
//   submitAdd()→addBank()，成功后关闭弹窗+触发 emit('confirm') 刷新列表，同原有新增成功收尾逻辑。
// 第九轮（本次，Eason 对第八轮验收反馈的 2 处修正，R83 arv3-executor 执行）：批量导入弹窗
//   (BatchImportModal) 2 处调整：①"确认导入"按钮从预校验表格 ProCrudTable 的 #footer-right slot
//   移到弹窗自己的 .bank-batch-import-modal__footer 底部按钮行，排在"关闭"按钮右侧、同行右对齐
//   （此前分属两行，与关闭按钮不在一起）；v-if="batchRows.length"/loading态/点击行为/按钮类型均未变，
//   只挪了渲染位置。②第八轮新增的"当前支持的银行类型"静态提示行已删除（连同 i18n key
//   supportedBankTypesHint，zh/en 同步删除）——Eason 澄清当初把原文"山谷好可"误解成"银行类型"，
//   实际应为"商户"；改为在预校验表格下方、底部按钮行上方新增"当前预览表格各币种关联哪些商户"展示
//   （新增 anchor batch_currencyMerchants），复用第八轮已在 tenant/merchantManage/data.ts 新增的
//   getMerchantsByCurrency()（该文件本轮零改动），口径与新增弹窗预览一致（商户名称+总数）；两个
//   computed（previewCurrencies/currencyMerchantSummaryText）派生自 batchRows，上传新文件/清空表格
//   自动联动刷新，为空时显示占位提示「上传文件后展示关联商户」。
// 第十轮（本次，Eason 拍板 3 项确认，R83 arv3-executor 执行）：搜索筛选区「币种→银行类型→银行
//   名称」做成三级级联（仅改 index.vue，不改 data.ts/BankAddModal.vue/i18n）。总控(admin)角色：
//   银行类型可选项按当前选中币种动态收窄（从 getAllBanks() 按 currency 过滤取 bankType 去重集合，
//   仍按银行卡/电子钱包/KBZ/WAVE 标准顺序展示），默认选中收窄后第一项；切换币种后若原选中银行
//   类型不在新集合里，自动重置为新集合第一项（不悬空）。商户(tenant)角色没有币种筛选，银行类型
//   固定展示全部 4 项，默认选中第一项"银行卡"（不收窄，因无币种上下文）。双端一致：银行名称可
//   选项按当前选中银行类型动态收窄（buildBankNameOrCodeOptions 新增可选 bankType 过滤参数，
//   label/value 构造规则不变）；切换银行类型后若原选中银行名称不在新集合里，直接清空（不禁用、
//   不报错）。三级均不做禁用逻辑——Eason 拍板"给每级设默认值即可避免完全未选的空状态"。搜索区
//   「重置」按钮联动补一层：级联运行态（selectedCurrency/selectedBankType）会在点击重置时同步
//   复位，避免"表单已重置但下拉选项还停留在重置前的收窄状态"。

import type { PageManual } from '../types';

const manual: PageManual = {
  route: 'finance_merchant_bank_dictionary_page',
  title: '银行字典',
  overview:
    "「财务管理 › 银行字典」页（双端可见，路由 meta.roles:['admin','tenant']），维护银行/电子钱包字典（名称+编码+类型+币种/商户+启停状态），供商户端收付款配置选择银行时使用。单表 ProCrudTable，搜索区/列表/顶部操作/行操作四处均按角色差异化：总控(admin)角色维持「全局字典不分商户」（第一轮方向不变）——搜索区 4 项[币种(首位必选)/银行名称或Code/银行类型/状态]、列表 5 列[币种/银行名称/银行编码/银行类型/操作]（2026-07-25 第七轮：末列由「状态」改为「操作」，仅一个「编辑」按钮，fixed:'right'+lockFixed）、顶部「批量导入」+「新增」两个按钮均可见；商户(tenant)角色（2026-07-24 第四轮恢复「商户」维度）——搜索区同为 4 项但首位换成[商户(必选单选、默认当前商户、不可清空)/银行名称或Code/银行类型/状态]（无币种）、列表同为 5 列但首位换成[商户/银行名称/银行编码/银行类型/状态]（无币种列，末列仍是「状态」ConfirmSwitch 行内开关，第七轮未改动）、顶部两个按钮均不可见——该角色下本页仅可查看列表数据，无任何写入入口。两角色的首位筛选/列互斥（要么币种要么商户，不会同时出现）。第七轮后：admin 角色状态改动走「编辑」弹窗内的状态开关，tenant 角色状态改动仍走列内 ConfirmSwitch 开关（两角色路径不同，互不影响）。",
  items: [
    // ============ 搜索区（顺序照代码 searchColumns：商户(仅tenant)/币种(仅admin，二者互斥同处首位)→银行名称→银行类型→状态）============
    {
      anchor: 'tenantId',
      name: '商户',
      group: '搜索',
      interaction:
        '下拉单选，不可清空（clearable:false）。仅商户(tenant)角色显示；总控(admin)角色下本搜索项整体隐藏（不渲染，非禁用）——2026-07-24 第四轮恢复的角色差异化，与仅总控可见的「币种」项互斥同处首位。',
      dataSource:
        'useTenantOptions().tenantOptions（当前登录用户可访问的商户下拉选项，标签格式 `(商户号)商户名`）。',
      logic: '按银行字典记录的 tenantId 精确匹配过滤。',
      limit:
        '商户角色下必填（formItemProps.showRequireMark 红星，R63 商户单选必填标杆用法），默认预填 useTenantOptions().defaultTenantId（当前登录用户的默认/激活商户）；总控角色下该字段连初始值都不设置。',
      edge: '2026-07-24 第一轮曾彻底移除该筛选项（"全局字典不分商户"方向）；第四轮 Eason 反转，仅商户端恢复，总控端不受影响仍不出现。',
    },
    {
      anchor: 'currency',
      name: '币种',
      group: '搜索',
      interaction:
        '下拉单选，不可清空（clearable:false）。仅总控(admin)角色显示；商户(tenant)角色下本搜索项整体隐藏（不渲染，非禁用）——2026-07-24 第三轮反馈新增的角色差异化。',
      dataSource:
        '本地枚举 5 项：INR/USDT/BRL/VND/MYR（CURRENCY_OPTIONS，与 data.ts BANK_LIST.currency 实际取值一致）；币种码本身即通用标识，不做 i18n 翻译（同 rechargeChannelDictionary 页 sysCurrency 展示口径）。',
      logic:
        '按银行字典记录的 currency 精确匹配过滤。2026-07-25 第十轮起同时是三级级联的第一级：切换币种会驱动下方「银行类型」可选项动态收窄（见 bankType），若原选中银行类型不在新集合里自动重置为新集合第一项。',
      limit:
        '总控角色下必填（formItemProps.showRequireMark 红星），默认预填第一项 INR；商户角色下该字段连初始值都不设置（searchInitialValues 角色感知返回空对象，避免对不存在的字段设初始值）。',
      edge: '2026-07-24 第一轮由多值数组收窄为单值、移至搜索区首位；第三轮进一步收窄为仅总控端可见。第十轮新增级联下游联动（selectedCurrency ref 通过 onUpdateValue 同步）。',
    },
    {
      anchor: 'bankNameOrCode',
      name: '银行名称',
      group: '搜索',
      interaction:
        '下拉单选，可清空，filterable（n-select 默认按渲染出的 label 文案做子串匹配），双端均显示。2026-07-24 第五轮由模糊文本框改造为下拉精确选中。',
      dataSource:
        '选项 = data.ts 完整银行列表 getAllBanks()（非分页快照，新增银行后下拉能反映最新数据），2026-07-25 第十轮起按当前选中的「银行类型」过滤（bankType 匹配）后再构建；每项 label="{bankCode} → {bankName}"（构造规则不变），若该记录 hasIndependentBankCode() 判定为「无独立编码」则只显示银行名称本身（不出现"→ 空白"，口径与列表 col_bankCode 兜底展示一致）。',
      logic:
        '选中某一项后按其唯一标识精确匹配对应记录，不再做子串模糊匹配。标识优先取该记录 bankCode（有独立编码时）；无独立编码时兜底取 bankId（BankRecord 现成唯一 id 字段，规避 bankName 潜在重名——当前数据"ICICI Bank"/"Paytm Payments Bank"各有两条同名记录）。filterable 按 label 文案子串匹配，故仍可同时按编码或名称片段找到目标项。第十轮起同时是三级级联的第三级：切换上方「银行类型」后若本项原选中值不在新集合里，直接清空（不禁用、不报错）。',
      limit: '选填；须先从下拉选中具体一项才会生效过滤，不再支持不选中项、仅凭自由文本模糊查询。',
      edge: '未选 = 不按名称/编码筛，仅按其它已选条件过滤。2026-07-24 第一轮曾由原「银行名称」单字段搜索框合并升级为模糊文本框（当时 label 为「银行名称/Code」），第五轮进一步改造为下拉精确选中（语义从"文本模糊搜索"变为"精确选中一项"），label 同步精简为「银行名称」（"/Code"后缀不再准确）。第十轮：银行类型清空为空值时本项不筛（显示全量，回退到未级联前的行为），不锁死交互。',
    },
    {
      anchor: 'bankType',
      name: '银行类型',
      group: '搜索',
      interaction:
        '下拉单选，可清空，双端均显示。不做禁用逻辑——无论当前值是什么（含被清空为空），本项及下方「银行名称」都保持可操作。',
      dataSource:
        '本地固定 4 项标准顺序：银行卡/电子钱包/KBZ/WAVE（BANK_TYPE_DROPDOWN_VALUES，2026-07-24 第一轮由原 6 项收窄，去掉"储蓄账户"/"USDT"两项）。2026-07-25 第十轮角色分流：总控(admin)角色按当前选中「币种」动态收窄——从 getAllBanks() 过滤出该币种下实际出现过的 bankType 去重集合，仍按上述标准顺序展示（如 INR→[银行卡,电子钱包]、VND→[银行卡,KBZ,WAVE]）；商户(tenant)角色没有币种上下文，固定展示全部 4 项、不收窄。',
      logic:
        '按银行字典记录的 bankType 精确匹配过滤；不选 = 不筛。第十轮起默认选中当前可选项第一项（双端均需要，避免"完全未选"空状态）；切换上方币种（仅总控角色会变）后若本项原选中值不在新集合里，自动重置为新集合第一项。切换本项会驱动下方「银行名称」可选项动态收窄（见 bankNameOrCode）。',
      limit: '选填（可清空）；但首次渲染与角色默认状态下恒有默认值，正常操作不会出现完全未选。',
      edge: '同时也是表格列（col_bankType），并非只搜索区可筛；映射表 BANK_TYPE_I18N_KEY 仍保留全部 6 个历史 key 兼容老数据展示，但下拉可选项只出 4 项（商户角色）或收窄后的子集（总控角色）。第十轮前双端固定同一份 4 项选项；第十轮起总控角色改为按币种动态收窄，商户角色维持固定 4 项不变。',
    },
    {
      anchor: 'state',
      name: '状态',
      group: '搜索',
      interaction: '下拉单选：启用 / 禁用，可清空，双端均显示。',
      dataSource: '本地枚举（启用=1 / 禁用=0）。',
      logic: '按银行字典记录的启停状态过滤。',
      limit: '选填。',
      edge: '不选 = 全部状态。',
    },

    // ============ 列（顺序照代码 tableColumns：商户(仅tenant)/币种(仅admin，二者互斥同处首位)→银行名称→银行编码→银行类型→状态）============
    {
      anchor: 'col_tenantId',
      name: '商户列',
      group: '列',
      interaction:
        '只读 Tag（NTag info 蓝框），不可点。仅商户(tenant)角色显示；总控(admin)角色下本列整体不出现——2026-07-24 第四轮恢复的角色差异化，位置固定在列表最前（角色可见时），与仅总控可见的「币种列」互斥同处首位。',
      dataSource:
        '行数据 tenantId，经 useTenantOptions().getTenantLabel() 解析为 `(商户号)商户名` 展示标签。',
      logic: '展示该行归属的商户。',
      edge: '2026-07-24 第一轮曾彻底移除该列（"全局字典不分商户"方向，tenantId 字段仅作内部标记保留、UI 不引用）；第四轮 Eason 反转，仅商户端恢复引用，总控端不受影响仍不展示。',
    },
    {
      anchor: 'col_currency',
      name: '币种列',
      group: '列',
      interaction:
        '只读 Tag（NTag info 蓝框），不可点。仅总控(admin)角色显示；商户(tenant)角色下本列整体不出现——2026-07-24 第三轮反馈新增的角色差异化，位置固定在列表最前（角色可见时）。',
      dataSource: '行数据 currency（单值字符串）；为空显示"-"。',
      logic: '展示该行的币种代码。',
      edge: '2026-07-24 第一轮由多 Tag 并列（多值数组）收窄为单一 Tag（单值），第三轮进一步收窄为仅总控端可见。',
    },
    {
      anchor: 'col_bankName',
      name: '银行名称列',
      group: '列',
      interaction: '纯文本展示，不可点，双端均显示。',
      dataSource: '行数据 bankName；空值兜底显示"-"（normalizeText）。',
    },
    {
      anchor: 'col_bankCode',
      name: '银行编码列',
      group: '列',
      interaction: '纯文本展示，不可点，双端均显示。',
      dataSource:
        '行数据 bankCode；空值兜底显示"-"（normalizeText，但 2026-07-24 第三轮反馈补全后当前 15 条种子数据已无空值）。',
      logic:
        '按 hasIndependentBankCode(bankCode) 判定：值符合「{币种大写}{4位流水号}」格式（正则校验，如 VND0001）→ 视为「有独立编码」→ 红色(#d03050)加粗展示编码本身；不符合格式（含空值）→ 视为「无独立编码」→ 灰色(#6b7280)展示银行名称本身兜底。2026-07-24 第一轮把该判断逻辑由「字符串相似度启发式」改为「格式正则校验」，更严谨可预期。',
      limit:
        '2026-07-24 第六轮起「新增」弹窗已不再采集该字段（表单项移除），新建记录固定传空值，' +
        '必然落进灰色兜底展示分支（展示银行名称本身），属预期行为、非报错；种子数据里已有的正规编码' +
        '（INR0001 等）不受影响，仍按格式正则判定展示红色加粗编码。',
      edge: '2026-07-24 第五轮前：本列标题用 i18n key finance.setting.bankDictionary.columns.bankCode="银行字典Code"，而批量导入弹窗预览表格的同名字段标题用的是另一个 key finance.prototype.fields.bankCode="银行编码"——同一页面内、同一个字段概念显示两种不同中文文案；第五轮已将前者改为"银行编码"，两个 key 现已文案对齐，该历史差异不再存在。2026-07-24 第三轮反馈前，主列表 15 条种子数据里有 3 条（bankId 8/11/13）故意留空演示灰色兜底分支；第三轮反馈要求全部记录统一为正规格式，这 3 条已补全为 INR0005/INR0006/USDT0003，当前灰色兜底分支在种子数据里已无触发实例（函数与渲染逻辑仍保留，未来手动新增不规范编码时仍会触发）。',
    },
    {
      anchor: 'col_bankType',
      name: '银行类型列',
      group: '列',
      interaction: '纯文本展示，不可点，双端均显示。',
      dataSource: '行数据 bankType，经 bankTypeLabel() 转 i18n 文案；空值显示"-"。',
    },
    {
      anchor: 'col_state',
      name: '状态列',
      group: '列',
      interaction:
        'ConfirmSwitch 开关（R47），点击先弹二次确认对话框，确认后才提交。2026-07-25 第七轮起仅商户(tenant)角色显示；总控(admin)角色下本列已移除（不渲染），状态改动改走「编辑」弹窗内的状态开关（见 add_state，弹窗新增/编辑共用）。',
      dataSource: '行数据 state（1=启用/0=禁用）。',
      logic:
        '确认后调用 api.v1platform.updateStateTabBanks({bankId, state}) 更新该行状态，成功后 Toast 提示 + 整表刷新。仅 tenant 角色路径；admin 角色状态变更走编辑弹窗提交 updateBank()，不经此方法。',
      note: '全站开关类控件约 92% 点击即生效、仅约 8% 弹二次确认（《交互规范》§6），本列属于弹二次确认的少数派。',
      edge: '2026-07-25 第七轮前双端均显示；第七轮起总控(admin)角色改为「操作」列(act_editBank)，商户(tenant)角色本列 100% 原样不动。',
    },

    // ============ 操作（顶部，主页；均仅总控(admin)角色可见）============
    {
      anchor: 'act_batchImport',
      name: '批量导入（顶部）',
      group: '操作',
      interaction:
        '点击打开「批量导入」弹窗（BatchImportModal，宽 860px）。仅总控(admin)角色显示；商户(tenant)角色下本按钮不渲染。',
      logic:
        '弹窗关闭时触发主表 reload。2026-07-24 第一轮移除商户概念后，弹窗不再携带 tenantId 上下文。',
      note: '与「新增」并列为本页仅有的两个顶部操作入口，商户角色两者皆不可见——该角色下本页纯查看，无任何写入操作。',
    },
    {
      anchor: 'act_addBank',
      name: '新增（顶部）',
      group: '操作',
      interaction:
        '点击打开「新增银行字典」弹窗（BankAddModal，宽 480px）。仅总控(admin)角色显示；商户(tenant)角色下本按钮不渲染——2026-07-24 第三轮反馈新增的角色差异化（此前第一轮上线时双端均可见）。',
      logic: '提交成功后弹窗关闭 + 触发主表 reload。',
    },
    {
      anchor: 'act_editBank',
      name: '编辑（行操作，2026-07-25 第七轮新建）',
      group: '操作',
      interaction:
        "列表末列「操作」列的「编辑」按钮（NButton primary，经 createActionColumn 渲染，fixed:'right'+lockFixed:true）。仅总控(admin)角色显示（actionColumn ifShow:()=>isSuperAuthUser.value）；商户(tenant)角色下本列整体不渲染（createActionColumn 内部对 ifShow 为假时返回 undefined，ProCrudTable 不出该列，非禁用/置灰）。",
      dataSource: '点击行 = 该行完整 BankRecord 数据，作为 detail 传给 BankAddModal。',
      logic:
        '打开「编辑银行字典」弹窗（复用 BankAddModal，传 detail=row，标题 i18n key finance.setting.bankDictionary.edit.title），弹窗内 isEdit=!!detail?.bankId 为真，币种/银行类型只读、仅银行名称/状态可编辑；保存成功后弹窗关闭 + 触发主表 reload（与「新增」共用同一关闭/刷新逻辑）。',
      edge: '本页此前无任何行操作列（无编辑入口），2026-07-25 第七轮新增；对应 tenant 角色的原「状态列」内联开关不受影响、仍是该角色唯一的状态改动入口。',
    },

    // ============ 弹窗：BankAddModal（新增，2026-07-24 第一轮新建；2026-07-25 第七轮改为新增/编辑共用） ============
    {
      anchor: 'add_bankName',
      name: '弹窗(新增/编辑共用) · 银行名称',
      group: '操作',
      interaction:
        '文本输入。2026-07-25 第七轮起本弹窗新增/编辑共用：新增态/编辑态均可编辑（编辑态非只读，是本次任务明确要求可改的两个字段之一）；编辑态初始值取自 props.detail.bankName 回显。第八轮：渲染顺序调整为表单第 1 项（此前是第 2 项，与「币种」调换），新增/编辑共用同一模板两态同步生效。',
      dataSource: '用户输入。',
      limit: "必填（rules.bankName required）；inputProps('name') 约束控制字符。",
    },
    {
      anchor: 'add_currency',
      name: '弹窗(新增/编辑共用) · 币种',
      group: '操作',
      interaction:
        '下拉单选，不可清空。2026-07-25 第七轮起本弹窗新增/编辑共用：新增态可正常选择；编辑态(isEdit=!!props.detail?.bankId)只读(disabled=isEdit)，值取自 props.detail.currency 回显，不可修改。第八轮：渲染顺序调整为表单第 2 项（此前是第 1 项，与「银行名称」调换）；同轮选中该字段还会联动下方「银行类型」的可用状态（见 add_bankType）。',
      dataSource:
        '本地枚举 4 项：INR/BRL/VND/MYR（弹窗内独立声明一份 currencyOptions，2026-07-25 第八轮去掉 USDT，取值不再与主列表 CURRENCY_OPTIONS(仍含USDT，仅列表筛选/批量导入历史数据保留) 完全一致，是 Eason 明确要求仅收窄本弹窗）。',
      logic: '随其它字段一起提交；新增态提交给 addBank()，编辑态提交给 updateBank()（值未变化）。',
      limit: '必填（rules.currency required，未选中提交会拦截）；编辑态因只读恒有值，校验必过。',
    },
    {
      anchor: 'add_bankType',
      name: '弹窗(新增/编辑共用) · 银行类型',
      group: '操作',
      interaction:
        '下拉单选，不可清空。2026-07-25 第七轮起本弹窗新增/编辑共用：编辑态(isEdit)恒只读(disabled 含 isEdit)，值取自 props.detail.bankType 回显，不可修改。第八轮起新增态新增"币种↔银行类型联动"：`:disabled="isEdit || !formData.currency"`——未选币种时本控件禁用，placeholder 提示"请先选择币种"（selectCurrencyFirst）；选定币种后启用，可从固定4项中正常选择。',
      dataSource:
        '本地固定 4 项：银行卡/电子钱包/KBZ/WAVE（与主列表 bankTypeOptions 同口径），不按币种再做差异化过滤（Eason 确认：暂无具体"某币种对应哪几种银行类型"的限制对照表，以后给了再细化）。',
      limit:
        '必填（rules.bankType required）；第八轮起新增态初始值改为空字符串（此前固定预填"银行卡"），须先选币种、控件启用后才能选择；编辑态仍默认取 detail 现有值。',
      edge: '第八轮前：新增态默认预填"银行卡"、无需先选币种即可修改。第八轮后：新增态改为强制"先选币种、才能选类型"的联动顺序，编辑态完全不受影响（恒只读，不存在联动问题）。',
    },
    {
      anchor: 'add_state',
      name: '弹窗(新增/编辑共用) · 状态',
      group: '操作',
      interaction:
        'n-switch 开关（非 ConfirmSwitch——表单场景是"和其它字段一起提交"，不适合单独弹二次确认）。2026-07-25 第七轮起本弹窗新增/编辑共用：新增态/编辑态均可编辑（编辑态非只读，是本次任务明确要求可改的两个字段之一——总控(admin)角色状态改动的唯一入口，因列表侧「操作」列已无内联开关）；编辑态初始值取自 props.detail.state 回显。',
      dataSource: '新增态默认开启（state=1）；编辑态取 props.detail.state。',
      logic:
        '随其它字段一起提交，data.ts addBank()/updateBank() 均用 ===0 显式判断避免把合法的 0(禁用) 误当假值兜底成 1。',
      limit: '开关无"未填"状态，不加必填规则。',
      edge: '2026-07-24 第二轮反馈修复新增此字段（第一轮上线时新增弹窗曾无状态字段，硬编码 state:1）；2026-07-25 第七轮起编辑态复用同一开关，成为总控(admin)角色状态改动的唯一入口。',
    },
    {
      anchor: 'add_cancel',
      name: '弹窗(新增/编辑共用) · 取消',
      group: '操作',
      interaction:
        '点击按钮，不提交、直接关闭弹窗（不刷新主表）。新增/编辑两态共用同一按钮与行为。',
    },
    {
      anchor: 'add_confirm',
      name: '弹窗(新增/编辑共用) · 确定',
      group: '操作',
      interaction: '点击按钮，先校验表单（3 项必填规则：币种/银行名称/银行类型），通过后提交。',
      logic:
        '编辑态(isEdit=true，2026-07-25 第七轮新增，仅总控(admin)角色经 act_editBank 触发)：行为不变，校验通过直接调用 ' +
        'api.v1platform.updateBank({bankId:props.detail.bankId,currency,bankName,bankType,state})，按 bankId 定位原记录原地更新，' +
        '成功后 Toast「更新成功」(common.updateSuccess) + 关闭弹窗 + 触发主表 reload，无预览环节。' +
        '新增态(isEdit=false)：2026-07-25 第八轮改为"确认→预览→发布"三步——校验通过后不再直接提交，先调用 openAddPreview() 弹出 ' +
        '预览确认框（dialog.warning，参照 BatchImportModal.vue executeBatch() 写法）：展示本次要新增的数据摘要(币种/银行名称/' +
        '银行类型/状态，纯文字，previewSummary) + 该币种关联商户名单+总数(previewMerchantList，数据来源新增的 ' +
        'tenant/merchantManage/data.ts getMerchantsByCurrency()，0 家时展示 previewNoMerchant"该币种暂无关联商户")；' +
        '预览框「取消」(negativeText=common.cancel) 关闭预览、回到表单、不提交；「发布」(positiveText=common.publish) 才真正调用 ' +
        "submitAdd()→api.v1platform.addBank({currency,bankName,bankCode:'',bankType,state})（bankCode 固定传空字符串，" +
        '2026-07-24 第六轮起弹窗不再采集该字段），成功后 Toast「新增成功」(common.addSuccess) + 关闭弹窗 + 触发主表 reload；' +
        '插入本地 mock 数组顶部（unshift）。',
      limit:
        '任一必填项未填会被表单校验拦截，不发起提交；编辑态币种/银行类型只读恒有值不受此限制。新增态预览框是校验通过后的' +
        '强制中间步骤，不能跳过直接发布。',
      edge:
        '第八轮前：新增态点击「确定」校验通过即直接提交，无中间步骤。第八轮后：新增态多一层预览确认，用户可在预览框点' +
        '「取消」反悔退回表单修改后重新点「确定」；编辑态从未有过预览环节，本轮也未新增。',
    },

    // ============ 弹窗：BatchImportModal（批量导入） ============
    {
      anchor: 'batch_alert',
      name: '弹窗(批量导入) · 顶部提示',
      group: '操作',
      interaction: '纯展示 n-alert（info 蓝色，不可关闭），弹窗顶部，一行文案。',
      dataSource: '上传限制说明(uploadLimit)+支持格式说明(uploadSupportTypes) 拼接展示。',
      logic: '纯提示，不联动任何数据请求。',
      edge:
        '2026-07-25 第九轮：第八轮曾新增的第二行"当前支持的银行类型"静态提示(supportedBankTypesHint)已删除——' +
        'Eason 反馈当初把原文"山谷好可"误解成"银行类型"，实际应为"商户"，改到下方新增的关联商户展示块' +
        '（见 batch_currencyMerchants），本提示恢复为单行、i18n key 已一并删除。',
    },
    {
      anchor: 'batch_downloadTemplate',
      name: '弹窗(批量导入) · 模板下载',
      group: '操作',
      interaction: '点击按钮。',
      logic:
        '纯前端本地生成一份含表头+示例行的 CSV 文件并触发浏览器下载（bank-dictionary-template.csv），不发任何请求。2026-07-25 第八轮：表头/示例行由 4 列收窄为 3 列——银行名称/银行类型/币种（去掉"银行编码"列）。',
      note: '下载的是 .csv 模板，但上传入口 accept 限定 .xlsx/.xls——模板容器格式与上传要求的格式不同（如实记录，非本次引入；原型环境不生成真实 xlsx）。第八轮起模板列（3列，无编码）与下方预校验结果表格 batch_table（7列，含编码）刻意不一致——Eason 已确认允许，非疏漏：模板是给用户准备待导入数据用，预览表格是给用户核对系统解析结果用，两者用途不同。',
    },
    {
      anchor: 'batch_uploadExcel',
      name: '弹窗(批量导入) · 上传Excel',
      group: '操作',
      interaction:
        '点击按钮触发隐藏的 <input type="file" accept=".xlsx,.xls">，选择文件后立即上传。',
      dataSource: '用户选择的本地文件。',
      logic:
        '调用 api.v1platform.initBatchBankFile(file, {}) 做预校验，返回结果填充下方预览表格；若含失败行会弹 warning Toast 提示失败条数。',
      limit: '仅接受 .xlsx/.xls 扩展名（浏览器文件选择器层面限制）。',
      edge: '⚠️ mock initBatchBankFile 不真正解析所选文件内容，无论上传什么文件，恒返回同一份写死的样例数据（BATCH_SAMPLE_ROWS，2026-07-25 第八轮由 8 行扩充到 13 行，覆盖正常通过/编码重复/名称为空/币种非法/类型非法 5 类校验场景 + INR/BRL/VND/MYR 多币种、银行卡/电子钱包/KBZ/WAVE 多银行类型样例）——data.ts 注释已自述这是有意设计的 mock 行为，非隐藏缺陷。',
    },
    {
      anchor: 'batch_table',
      name: '弹窗(批量导入) · 预校验结果表格',
      group: '操作',
      interaction:
        '只读表格，7 列：#/银行名称/银行编码/银行类型/币种/校验信息/状态；校验信息列失败原因红字展示、通过显示绿色✓；状态列 Tag（成功/通过=绿，失败=红）。',
      dataSource:
        '上传后 initBatchBankFile 的返回结果；执行后 importBatchBankData 的返回结果覆盖同一份数据。',
      logic: '数据为空时表格区域隐藏（modal 样式 --empty 修饰类隐藏空态 footer）。',
    },
    {
      anchor: 'batch_clearBatch',
      name: '弹窗(批量导入) · 清空表格数据',
      group: '操作',
      interaction: '点击按钮，仅当预览表格有数据时显示。',
      logic: '前端直接清空 batchRows，表格恢复空态，不调用任何接口。',
    },
    {
      anchor: 'batch_currencyMerchants',
      name: '弹窗(批量导入) · 关联商户展示',
      group: '操作',
      interaction:
        '纯展示文字块，不可点击；位置在预校验表格下方、底部「关闭/确认导入」按钮行上方。',
      dataSource:
        '从 batchRows 提取去重后的币种列表（Array.from(new Set(...currency)).filter(Boolean)），逐个调用 ' +
        'tenant/merchantManage/data.ts 的 getMerchantsByCurrency(currency) 查该币种关联的商户，取 .name 拼接展示' +
        '（与 BankAddModal.vue 新增预览 previewMerchantList 同一数据源、同一口径：商户名称+总数，不展示其它字段）。',
      logic:
        '两个 computed（previewCurrencies/currencyMerchantSummaryText）派生自 batchRows，上传新文件/清空表格会自动重新计算，无需额外 watch。' +
        '格式："关联商户：{币种1}({N}家：{商户名1}、{商户名2}...)　{币种2}(暂无关联商户)　..."，币种间用全角空格分隔；' +
        '该币种查无商户时显示"(暂无关联商户)"而非报错或留空。',
      edge:
        'batchRows 为空（未上传文件/已清空）时本块不展示上述文字，改显示占位提示「上传文件后展示关联商户」，不留空白怪样式。' +
        '2026-07-25 第九轮新增，替换本轮删除的原「当前支持的银行类型」静态提示行（原提示是固定文案与实际数据无关；' +
        '本轮改为动态反映当前预览表格真实数据）。',
    },
    {
      anchor: 'batch_executeBatch',
      name: '弹窗(批量导入) · 确认导入',
      group: '操作',
      interaction:
        '点击按钮（仅预览表格有数据时显示），先弹二次确认对话框（dialog.warning，含通过/失败条数汇总 + 完整表格只读预览），确认后才真正提交。' +
        '2026-07-25 第八轮：按钮文案由"一键执行"改"确认导入"——Eason 反馈此前第一层弹窗缺少带"确认"字样的按钮（"确认"此前只出现在点击后' +
        '弹出的二级对话框内），本轮补上；点击行为（先弹二级确认框）未变。2026-07-25 第九轮：渲染位置由预校验表格(ProCrudTable)的 ' +
        'footer-right slot 挪到本弹窗自己的底部按钮行，排在「关闭」按钮右侧、同处一行右对齐（此前与关闭按钮分属两行，Eason 反馈修正）；' +
        'v-if 显示条件/loading态/点击行为/按钮类型均未变，只挪了 DOM 位置。',
      logic:
        '确认后调用 api.v1platform.importBatchBankData({items})，返回结果按行更新为「导入成功」/「导入失败」状态；含失败行用 warning Toast、全部成功用 success Toast。',
      limit:
        '预览表格为空时点击（理论上按钮已隐藏，属双重防御）会 warning 提示「暂无可执行数据」并短路。',
    },
    {
      anchor: 'batch_close',
      name: '弹窗(批量导入) · 关闭',
      group: '操作',
      interaction:
        '点击按钮，弹窗底部按钮行最左侧（2026-07-25 第九轮：右侧新增「确认导入」按钮同处一行、右对齐，此前本按钮独占一行）。',
      logic: "触发 emit('close')，父层销毁弹窗实例并刷新主表格（无论批量导入是否执行过）。",
    },
  ],

  // ============ 字段介绍 tab（列序照页面；仅列表列 + 定义）============
  fields: [
    {
      name: '商户',
      def: '该银行字典记录归属的商户，展示为 `(商户号)商户名`；仅商户(tenant)角色列表展示该列，总控(admin)角色不展示（2026-07-24 第四轮角色差异化，与「币种」列互斥同处首位）。',
    },
    {
      name: '币种',
      def: '该银行/电子钱包渠道的结算币种（单值），枚举 5 项：INR/USDT/BRL/VND/MYR；仅总控(admin)角色列表展示该列，商户(tenant)角色不展示（2026-07-24 第三轮反馈角色差异化）。',
    },
    {
      name: '银行名称',
      def: '该银行/电子钱包渠道的名称，如 State Bank of India、TronPay。双端均展示。',
    },
    {
      name: '银行编码',
      def: '该银行/电子钱包渠道的编码标识，规律为「{币种大写}{4位流水号}」（如 VND0001）；符合该格式显示红色加粗，不符合（含空值）显示灰色兜底为银行名称本身。当前 15 条种子数据均已是合规格式（2026-07-24 第三轮反馈补全最后 3 条空值）。双端均展示。',
    },
    {
      name: '银行类型',
      def: '该银行/电子钱包渠道的类型分类，下拉可选 4 项：银行卡/电子钱包/KBZ/WAVE。双端均展示。',
    },
    {
      name: '状态',
      def: '该银行字典记录的启用/禁用状态；禁用后该银行渠道不可在商户端收付款配置中选用。2026-07-25 第七轮起：商户(tenant)角色仍是列表列（ConfirmSwitch 行内开关，切换需二次确认）；总控(admin)角色列表不再展示该列，改为点「编辑」按钮在弹窗内用开关调整（提交后即时生效，弹窗内无需二次确认）。',
    },
  ],
};

export default manual;
