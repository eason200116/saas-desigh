<template>
  <n-form ref="formRef" :model="formData" :rules="rules" label-placement="top">
    <n-grid :cols="2" :x-gap="14">
      <n-form-item-gi :label="t('member.bankCard.merchant')" path="tenantId">
        <n-select
          v-if="!lockTenantId"
          v-model:value="formData.tenantId"
          :options="tenantOptions"
          filterable
          clearable
          :placeholder="t('common.select_placeholder', { label: t('member.bankCard.merchant') })"
          @update:value="handleTenantChange"
        />
        <n-input v-else :value="getTenantName(formData.tenantId)" disabled />
      </n-form-item-gi>
      <n-form-item-gi :label="t('member.bankCard.userId')" path="userId">
        <n-input
          v-model:value="formData.userId"
          :disabled="lockUserId"
          :allow-input="onlyDigits"
          :placeholder="t('common.input_placeholder', { label: t('member.bankCard.userId') })"
        />
      </n-form-item-gi>
      <n-form-item-gi :label="t('member.bankCard.networkProtocol')" path="bankId">
        <n-select
          v-model:value="formData.bankId"
          :options="selectOptions"
          clearable
          :placeholder="
            t('common.select_placeholder', { label: t('member.bankCard.networkProtocol') })
          "
        />
      </n-form-item-gi>
      <n-form-item-gi :label="t('member.bankCard.walletAddress')" path="accountNo">
        <n-input
          v-model:value="formData.accountNo"
          :placeholder="
            t('common.input_placeholder', { label: t('member.bankCard.walletAddress') })
          "
        />
      </n-form-item-gi>
      <n-form-item-gi :label="t('member.bankCard.alias')" :span="2">
        <n-input
          v-model:value="formData.alias"
          :placeholder="t('common.input_placeholder', { label: t('member.bankCard.alias') })"
        />
      </n-form-item-gi>
    </n-grid>
  </n-form>
  <n-space justify="end" :style="{ marginTop: '16px' }">
    <n-button @click="emit('cancel')">{{ t('common.cancel') }}</n-button>
    <n-button type="primary" :loading="loading" @click="handleSubmit">
      {{ t('common.confirm') }}
    </n-button>
  </n-space>
</template>

<script setup lang="ts">
  import { reactive, ref, computed, onMounted } from 'vue';
  import type { FormInst, FormRules } from 'naive-ui';
  import { useI18n } from 'vue-i18n';
  import { useMessage } from 'naive-ui';
  import { useTenantOptions } from '@/hooks';
  import { onlyDigits } from '@/utils';
  import { api } from './data';
  import { useTypeOptions } from './useTypeOptions';

  const props = defineProps<{
    mode: 'add' | 'edit';
    record?: any | null;
    // 新增模式下可由调用方预填商户/会员，例如会员详情 - 钱包信息 tab
    initial?: { tenantId?: number | null; userId?: string | number | null } | null;
  }>();

  const emit = defineEmits<{
    (e: 'cancel'): void;
    (e: 'confirm'): void;
  }>();

  const { t } = useI18n();
  const message = useMessage();
  const { tenantOptions, getTenantName, defaultTenantId } = useTenantOptions();
  const { usdtOptions, loadUsdtOptions, ensureOption } = useTypeOptions();

  const isEdit = computed(() => props.mode === 'edit');
  // 新增模式下如果调用方通过 initial 预填了商户/会员，则锁死不可编辑
  const lockTenantId = computed(() => isEdit.value || props.initial?.tenantId != null);
  const lockUserId = computed(() => isEdit.value || props.initial?.userId != null);
  const formRef = ref<FormInst | null>(null);
  const loading = ref(false);

  const selectOptions = computed(() =>
    ensureOption(usdtOptions.value, formData.bankId, props.record?.bankNameStr),
  );

  onMounted(() => loadUsdtOptions(formData.tenantId));

  function handleTenantChange(tenantId: number) {
    formData.bankId = null;
    loadUsdtOptions(tenantId);
  }

  const formData = reactive({
    tenantId:
      props.record?.tenantId ?? props.initial?.tenantId ?? defaultTenantId.value ?? undefined,
    userId:
      props.record?.userId != null
        ? String(props.record.userId)
        : props.initial?.userId != null
          ? String(props.initial.userId)
          : '',
    bankId: props.record?.bankId ?? (null as number | null),
    accountNo: props.record?.accountNo ?? '',
    alias: props.record?.beneficiaryName ?? '',
  });

  const rules: FormRules = {
    tenantId: {
      required: true,
      type: 'number',
      message: t('common.select_placeholder', { label: t('member.bankCard.merchant') }),
      trigger: 'change',
    },
    userId: [
      {
        required: true,
        message: t('common.input_placeholder', { label: t('member.bankCard.userId') }),
        trigger: 'blur',
      },
      {
        pattern: /^\d+$/,
        message: t('member.bankCard.userIdIntegerOnly'),
        trigger: ['blur', 'input'],
      },
    ],
    bankId: {
      required: true,
      type: 'number',
      message: t('common.select_placeholder', { label: t('member.bankCard.networkProtocol') }),
      trigger: 'change',
    },
    accountNo: {
      required: true,
      message: t('common.input_placeholder', { label: t('member.bankCard.walletAddress') }),
      trigger: 'blur',
    },
  };

  async function handleSubmit() {
    try {
      await formRef.value?.validate();
    } catch {
      return;
    }
    loading.value = true;
    try {
      const basePayload = {
        userId: Number(formData.userId),
        bankId: formData.bankId ?? undefined,
        accountNo: formData.accountNo,
        beneficiaryName: formData.alias || undefined,
        tenantId: formData.tenantId,
      };
      const { result, msg } = isEdit.value
        ? await api.v1platform.updateUserUsdt({ bId: props.record!.bId, ...basePayload })
        : await api.v1platform.addUserUsdt(basePayload);
      if (!result) {
        message.error(msg);
        return;
      }
      message.success(t('member.bankCard.saveSuccess'));
      emit('confirm');
    } catch {
      message.error(t('common.requestFailed'));
    } finally {
      loading.value = false;
    }
  }
</script>
