export { default as PageManual } from './index.vue';
