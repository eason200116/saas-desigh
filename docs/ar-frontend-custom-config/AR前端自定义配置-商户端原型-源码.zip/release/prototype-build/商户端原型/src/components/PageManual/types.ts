// 页面功能说明书面板（PageManual）—— 类型定义。
// 给开发人员看的「随点随看」功能说明书：右侧可收缩面板，点页面控件→高亮对应说明。
// 设计文档：docs/superpowers/specs/2026-07-17-page-manual-panel-design.md
// 与 DevLocator（dev-only 悬停探针）是两套、互不干扰：本套正式面板、原型环境也显示、点控件联动。

/** 一条控件/功能的说明（五维：交互/数据来源/逻辑/输入限制/边界 + 名称/锚点/补充）。 */
export interface ManualItem {
  /** 联动锚点：与页面控件的 data-manual 值一致、页内唯一。点该控件→面板滚动高亮本条。 */
  anchor: string;
  /** 控件名（如「游戏大类」）。 */
  name: string;
  /** 面板内分区归类。 */
  group?: '搜索' | '列' | '操作' | '其它';
  /** 交互介绍：这个控件怎么用。 */
  interaction: string;
  /** 数据来源：值 / 选项从哪来。 */
  dataSource?: string;
  /** 逻辑介绍：点了 / 选了会怎样。 */
  logic?: string;
  /** 输入限制：必填 / 格式 / 长度等。 */
  limit?: string;
  /** 边界情况：空 / 异常 / 校验失败怎样。 */
  edge?: string;
  /** 补充（可选）。 */
  note?: string;
}

/** 「字段介绍」tab 一条：仅列表中的字段 + 其定义（不含交互/逻辑/来源/限制）。 */
export interface FieldDef {
  /** 字段名（＝列表的列名，如「厂商编码」）。 */
  name: string;
  /** 定义：这个字段是什么、一句话说清。 */
  def: string;
}

/** 功能说明书固定章节。 */
export type ManualSectionKey =
  | 'purpose'
  | 'prerequisites'
  | 'areas'
  | 'workflow'
  | 'permissions'
  | 'effects'
  | 'unavailable'
  | 'recovery';

/**
 * PRD 功能点在说明书中的一对一内容映射。
 * prdFeatureId 只供内容稽核与验收使用，PageManual 画面不得显示工程编号。
 */
export interface ManualFeaturePoint {
  /** PRD 中的业务章节／功能名称，用于内容层逐项对照；前台不显示。 */
  prdSection: string;
  /** PRD 已提供唯一功能点编号时填写；来源未编号时不得自行编造。 */
  prdFeatureId?: string;
  /** 面向操作人员的功能名称。 */
  title: string;
  /** 同一功能点在固定八个说明章节中的独立说明。 */
  details: Partial<Record<ManualSectionKey, string>>;
}

export interface ManualSection {
  key: ManualSectionKey;
  content: string;
}

export interface PageManualContent {
  /** PRD 功能說明書規範對應；僅供內容資料追溯，前台不顯示。 */
  prdManualFeatureId?: string;
  title: string;
  overview: string;
  items: ManualItem[];
  fields?: FieldDef[];
  /** 新版内容来源：每个功能点只定义一次，再按固定章节呈现。 */
  featurePoints?: ManualFeaturePoint[];
  /** 旧页面兼容；新增 AR 说明优先使用 featurePoints。 */
  sections?: ManualSection[];
}

/** 一个页面的说明书（按路由名归属）。 */
export interface PageManual extends PageManualContent {
  /** 路由 name，如 'game_platform'。 */
  route: string;
  /** 同一页面在页签式路由中的上下文别名，如 tenant_styleManage:templateLibrary。 */
  routeAliases?: string[];
  /** 跟随后台语言；未提供或不支持的语言使用根层简体中文内容。 */
  locales?: Partial<Record<string, Partial<PageManualContent>>>;
}
