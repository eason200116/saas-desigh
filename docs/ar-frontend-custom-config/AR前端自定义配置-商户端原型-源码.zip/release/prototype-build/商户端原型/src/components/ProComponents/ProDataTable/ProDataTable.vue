<template>
  <div
    ref="tableContainerRef"
    class="pro-data-table"
    :class="{
      'pro-data-table--tr-dragging': isDragging,
      'pro-data-table--flex-height': flexHeight,
    }"
  >
    <slot name="extra" />
    <n-data-table
      ref="tableRef"
      :columns="processedColumns"
      :data="data"
      :loading="loading"
      :row-key="rowKeyFn"
      :scroll-x="scrollX"
      :max-height="maxHeight"
      :min-height="minHeight"
      :flex-height="flexHeight"
      :virtual-scroll="virtualScroll"
      bordered
      striped
      :single-line="false"
      v-bind="$attrs"
    />
    <slot name="table" />
  </div>
</template>

<script lang="ts" setup generic="T extends Recordable = Recordable">
  import {
    ref,
    computed,
    provide,
    h,
    useAttrs,
    type VNode,
    type VNodeChild,
    onMounted,
    onBeforeUnmount,
    nextTick,
  } from 'vue';
  import {
    NCheckbox,
    NDataTable,
    NIcon,
    NRadio,
    NTooltip,
    type DataTableColumn,
    type DataTableRowKey,
  } from 'naive-ui';
  import { QuestionCircleOutlined } from '@vicons/antd';
  import { useTenantOptions } from '@/hooks';
  import { useDragSort } from '../composables/useDragSort';
  import { useColumnRenderer } from '../composables/useColumnRenderer';
  import { ProTableContextKey } from '../context';
  import { useProCrudTableContextSafe } from '../context/crudTableContext';
  import type {
    Recordable,
    ProColumn,
    ProTableDragSortOptions,
    ProTenantTimeZoneDisplayOptions,
  } from '../types';

  defineOptions({
    name: 'ProDataTable',
    inheritAttrs: false,
  });

  interface ProDataTableComponentProps<TData extends Recordable = Recordable> {
    /** 列定义 */
    columns?: ProColumn<TData>[];
    /** 数据源 */
    data?: TData[];
    /** 加载状态 */
    loading?: boolean;
    /** 弹性高度 */
    flexHeight?: boolean;
    /** 行键 */
    rowKey?: string | ((row: TData) => DataTableRowKey);
    /** 横向滚动宽度 */
    scrollX?: number | string;
    /** 最大高度 */
    maxHeight?: number | string;
    /**
     * 最小高度。当与 maxHeight 设为同一个值时，n-data-table body 强制固定到该高度，
     * 实现"无数据/数据少时仍撑满"的语义（占位居中、行在顶、超出滚动），且不破坏 virtual-scroll。
     * naive-ui 内部已经实现，但 d.ts 未公开；这里显式透传。
     */
    minHeight?: number | string;
    /** 虚拟滚动（大数据量时开启，需配合 maxHeight 使用） */
    virtualScroll?: boolean;
    /** 拖拽排序配置 */
    dragSortOptions?: ProTableDragSortOptions<TData>;
    /** 当前搜索参数，供列渲染按搜索态联动 */
    searchParams?: Recordable;
  }

  const props = withDefaults(defineProps<ProDataTableComponentProps<T>>(), {
    columns: () => [],
    data: () => [],
    loading: false,
    flexHeight: false,
    rowKey: 'id',
    virtualScroll: false,
  });

  const attrs = useAttrs();

  // Refs
  const tableRef = ref<InstanceType<typeof NDataTable> | null>(null);
  const tableContainerRef = ref<HTMLElement | null>(null);

  function findHorizontalScrollableElement(root: HTMLElement): HTMLElement | null {
    const candidates = Array.from(root.querySelectorAll<HTMLElement>('*'));
    for (const el of candidates) {
      if (el.scrollWidth <= el.clientWidth + 1) continue;
      const style = window.getComputedStyle(el);
      const overflowX = style.overflowX;
      if (overflowX !== 'auto' && overflowX !== 'scroll' && overflowX !== 'overlay') continue;
      return el;
    }
    if (root.scrollWidth > root.clientWidth + 1) return root;
    return null;
  }

  const handleWheel = (event: WheelEvent) => {
    if (!event.shiftKey) return;
    const container = tableContainerRef.value;
    if (!container) return;
    const target = event.target as Node | null;
    if (!target || !container.contains(target)) return;
    const dataTableRoot = container.querySelector<HTMLElement>('.n-data-table');
    if (dataTableRoot && target instanceof Node && !dataTableRoot.contains(target)) return;

    const scrollEl = dataTableRoot ? findHorizontalScrollableElement(dataTableRoot) : null;
    if (!scrollEl) return;

    const canScroll = scrollEl.scrollWidth > scrollEl.clientWidth + 1;
    if (!canScroll) return;

    const delta = Math.abs(event.deltaX) > Math.abs(event.deltaY) ? event.deltaX : event.deltaY;
    if (!delta) return;

    event.preventDefault();
    scrollEl.scrollLeft += delta;
  };

  onMounted(async () => {
    await nextTick();
    tableContainerRef.value?.addEventListener('wheel', handleWheel, { passive: false });
  });

  onBeforeUnmount(() => {
    tableContainerRef.value?.removeEventListener('wheel', handleWheel as EventListener);
  });

  // 列渲染器
  const { renderColumnWithEllipsis } = useColumnRenderer();
  const {
    activeTenantId,
    defaultTenantId,
    renderTenantDateTimeColumnTitle,
    formatTenantDateTime,
    getTenantTimeZone,
  } = useTenantOptions();

  // 与 picker (ProDateRangeInput / ProSelectDateRange) 的 useEffectiveDateRangeTimezone
  // 完全同链：ProCrudTable.context.timezoneId（业务页面通过 setTimezoneId / tenant-timezone
  // 写入）→ defaultTenantId 兜底。保证 render 注入的时区与触发器/面板时区一致。
  const crudCtx = useProCrudTableContextSafe();
  const columnRenderTimezone = computed<string | undefined>(() => {
    const fromCtx = crudCtx?.timezoneId.value;
    if (fromCtx) return fromCtx;
    const tid = defaultTenantId.value;
    return tid != null ? (getTenantTimeZone(tid) ?? undefined) : undefined;
  });

  type TenantTimeZoneResolvedOptions = Required<
    Pick<ProTenantTimeZoneDisplayOptions, 'searchTenantIdKey' | 'rowTenantIdKey'>
  > &
    ProTenantTimeZoneDisplayOptions;

  // 拖拽排序
  const dragSortResult = props.dragSortOptions
    ? useDragSort({
        dataSource: computed(() => props.data),
        options: props.dragSortOptions,
        containerRef: tableContainerRef,
      })
    : { isDragging: ref(false), dragHandleId: '' };

  const { isDragging } = dragSortResult;

  // 行键函数
  const rowKeyFn = computed(() => {
    if (typeof props.rowKey === 'function') {
      return props.rowKey;
    }
    return (row: T) => (row as Recordable)[props.rowKey as string];
  });

  type SelectionUpdateHandler =
    | ((keys: DataTableRowKey[]) => void)
    | Array<(keys: DataTableRowKey[]) => void>;

  type SelectionFixed = boolean | 'left' | 'right';

  type ProDataTableSelectionColumn<TData extends Recordable = Recordable> =
    DataTableColumn<TData> & {
      type: 'selection';
      multiple?: boolean;
      fixed?: SelectionFixed;
      disabled?: (row: TData) => boolean;
      className?: string;
    };

  function getCheckedRowKeys(): DataTableRowKey[] {
    const keys = attrs.checkedRowKeys ?? attrs['checked-row-keys'];
    return Array.isArray(keys) ? (keys as DataTableRowKey[]) : [];
  }

  function getCheckedRowKeysUpdateHandler(): SelectionUpdateHandler | undefined {
    return (
      (attrs['onUpdate:checkedRowKeys'] as SelectionUpdateHandler | undefined) ??
      (attrs.onUpdateCheckedRowKeys as SelectionUpdateHandler | undefined) ??
      (attrs['onUpdate:checked-row-keys'] as SelectionUpdateHandler | undefined)
    );
  }

  function emitCheckedRowKeys(keys: DataTableRowKey[]) {
    const handler = getCheckedRowKeysUpdateHandler();
    if (!handler) return;
    if (Array.isArray(handler)) {
      handler.forEach((fn) => fn(keys));
      return;
    }
    handler(keys);
  }

  function isSameRowKey(left: DataTableRowKey, right: DataTableRowKey) {
    return left === right;
  }

  function uniqRowKeys(keys: DataTableRowKey[]) {
    return Array.from(new Set(keys));
  }

  function isSelectionRadio(column: ProDataTableSelectionColumn<T>) {
    return column.multiple === false;
  }

  function isSelectionRowDisabled(rowData: T, column: ProDataTableSelectionColumn<T>) {
    return column.disabled?.(rowData) === true;
  }

  function getSelectionRowKey(rowData: T) {
    return rowKeyFn.value(rowData);
  }

  function isSelectionRowChecked(rowData: T) {
    const key = getSelectionRowKey(rowData);
    return getCheckedRowKeys().some((checkedKey) => isSameRowKey(checkedKey, key));
  }

  function getSelectableRowKeys(column: ProDataTableSelectionColumn<T>) {
    return props.data
      .filter((row) => !isSelectionRowDisabled(row, column))
      .map((row) => getSelectionRowKey(row));
  }

  function getHeaderSelectionState(column: ProDataTableSelectionColumn<T>) {
    const selectableKeys = getSelectableRowKeys(column);
    const checkedKeys = getCheckedRowKeys();
    const checkedSelectableCount = selectableKeys.filter((key) =>
      checkedKeys.some((checkedKey) => isSameRowKey(checkedKey, key)),
    ).length;

    return {
      selectableKeys,
      checked: selectableKeys.length > 0 && checkedSelectableCount === selectableKeys.length,
      indeterminate: checkedSelectableCount > 0 && checkedSelectableCount < selectableKeys.length,
      disabled: selectableKeys.length === 0,
    };
  }

  function handleHeaderSelectionChange(column: ProDataTableSelectionColumn<T>, checked: boolean) {
    const selectableKeys = getSelectableRowKeys(column);
    if (!selectableKeys.length) return;

    if (checked) {
      emitCheckedRowKeys(uniqRowKeys([...getCheckedRowKeys(), ...selectableKeys]));
      return;
    }

    const selectableKeySet = new Set(selectableKeys);
    emitCheckedRowKeys(getCheckedRowKeys().filter((key) => !selectableKeySet.has(key)));
  }

  function handleRowSelectionChange(
    rowData: T,
    column: ProDataTableSelectionColumn<T>,
    checked: boolean,
  ) {
    if (isSelectionRowDisabled(rowData, column)) return;

    const key = getSelectionRowKey(rowData);

    if (isSelectionRadio(column)) {
      if (checked) emitCheckedRowKeys([key]);
      return;
    }

    const checkedKeys = getCheckedRowKeys();
    const nextKeys = checked
      ? uniqRowKeys([...checkedKeys, key])
      : checkedKeys.filter((checkedKey) => !isSameRowKey(checkedKey, key));
    emitCheckedRowKeys(nextKeys);
  }

  function normalizeSelectionFixed(fixed: SelectionFixed | undefined) {
    if (fixed === true) return 'left';
    if (fixed === false) return undefined;
    return fixed;
  }

  function mergeSelectionClassName(className: string | undefined) {
    const baseClassName = 'n-data-table-td--selection pro-data-table__selection-td';
    return className ? `${className} ${baseClassName}` : baseClassName;
  }

  function renderSelectionHeader(column: ProDataTableSelectionColumn<T>) {
    const state = getHeaderSelectionState(column);
    return h(NCheckbox, {
      checked: state.checked,
      indeterminate: state.indeterminate,
      disabled: state.disabled,
      class: 'pro-data-table__selection-checkbox',
      'onUpdate:checked': (checked: boolean) => handleHeaderSelectionChange(column, checked),
    });
  }

  function renderSelectionCell(rowData: T, column: ProDataTableSelectionColumn<T>) {
    const disabled = isSelectionRowDisabled(rowData, column);
    const checked = isSelectionRowChecked(rowData);
    const isRadio = isSelectionRadio(column);
    const disabledCheckboxClass = [
      'pro-data-table__selection-checkbox--disabled',
      'relative',
      'cursor-not-allowed',
      "after:content-['X']",
      'after:pointer-events-none',
      'after:absolute',
      'after:left-1/2',
      'after:top-1/2',
      'after:z-[1]',
      'after:-translate-x-1/2',
      'after:-translate-y-1/2',
      'after:text-[10px]',
      'after:font-semibold',
      'after:leading-none',
      'after:text-[var(--n-text-color-disabled)]',
      '[&_*]:cursor-not-allowed',
    ].join(' ');

    const control = isRadio
      ? h(NRadio, {
          checked,
          disabled,
          class: 'pro-data-table__selection-radio',
          'onUpdate:checked': (nextChecked: boolean) =>
            handleRowSelectionChange(rowData, column, nextChecked),
        })
      : h(NCheckbox, {
          checked,
          disabled,
          class: ['pro-data-table__selection-checkbox', disabled ? disabledCheckboxClass : ''],
          'onUpdate:checked': (nextChecked: boolean) =>
            handleRowSelectionChange(rowData, column, nextChecked),
        });

    return h(
      'span',
      {
        class: [
          'pro-data-table__selection-cell inline-flex w-full min-h-[22px] items-center justify-center leading-none',
          disabled ? 'pro-data-table__selection-cell--disabled' : '',
        ],
        onClick: (event: MouseEvent) => event.stopPropagation(),
      },
      [control],
    );
  }

  function createCustomSelectionColumn(column: ProDataTableSelectionColumn<T>): DataTableColumn<T> {
    const radio = isSelectionRadio(column);
    return {
      key: '__selection__',
      title: radio ? undefined : ((() => renderSelectionHeader(column)) as () => VNodeChild),
      width: column.width ?? 50,
      fixed: normalizeSelectionFixed(column.fixed),
      align: 'center',
      titleAlign: 'center',
      className: mergeSelectionClassName(column.className),
      resizable: false,
      render: (rowData: T) => renderSelectionCell(rowData, column),
    };
  }

  function normalizeTenantId(value: unknown) {
    const tenantId = Number(value);
    return Number.isFinite(tenantId) && tenantId > 0 ? tenantId : undefined;
  }

  function normalizeDateFormat(format?: string) {
    if (!format) return undefined;
    return format.replace(/YYYY/g, 'yyyy').replace(/DD/g, 'dd');
  }

  function normalizeTimestampValue(value: number) {
    return Math.abs(value) < 1e12 ? value * 1000 : value;
  }

  function createTextDisplayColumn(column: ProColumn<T>): ProColumn {
    return {
      key: String(column.key),
      title: typeof column.title === 'string' ? column.title : undefined,
      copyable: column.copyable,
      ellipsis: column.ellipsis,
      valueType: 'text',
    };
  }

  function resolveTenantTimeZoneOptions(
    column: ProColumn<T>,
  ): TenantTimeZoneResolvedOptions | null {
    if (!column.showTenantTimeZone) return null;

    if (column.showTenantTimeZone === true) {
      return {
        searchTenantIdKey: 'tenantId',
        rowTenantIdKey: 'tenantId',
      };
    }

    return {
      searchTenantIdKey: 'tenantId',
      rowTenantIdKey: 'tenantId',
      ...column.showTenantTimeZone,
    };
  }

  function resolveSearchTenantId(options: { searchTenantIdKey?: string; rowTenantIdKey?: string }) {
    return (
      normalizeTenantId(props.searchParams?.[options.searchTenantIdKey ?? 'tenantId']) ??
      normalizeTenantId(activeTenantId.value)
    );
  }

  function resolveRowTenantId(
    rowData: T,
    options: {
      searchTenantIdKey?: string;
      rowTenantIdKey?: string;
    },
  ) {
    return normalizeTenantId((rowData as Recordable)[options.rowTenantIdKey ?? 'tenantId']);
  }

  function renderTenantTimeZoneValue(
    value: unknown,
    rowData: T,
    rowIndex: number,
    column: ProColumn<T>,
    options: TenantTimeZoneResolvedOptions,
  ) {
    const textDisplayColumn = createTextDisplayColumn(column);

    if (value === null || value === undefined || value === '') {
      return renderColumnWithEllipsis('-', rowData as Recordable, rowIndex, textDisplayColumn);
    }

    if (typeof value === 'string') {
      return renderColumnWithEllipsis(value, rowData as Recordable, rowIndex, textDisplayColumn);
    }

    const tenantId = resolveSearchTenantId(options) ?? resolveRowTenantId(rowData, options);

    if (typeof value === 'number' || value instanceof Date) {
      const normalizedValue = typeof value === 'number' ? normalizeTimestampValue(value) : value;
      const formattedText = formatTenantDateTime(
        normalizedValue,
        tenantId,
        options.format ?? normalizeDateFormat(column.dateFormat),
        '-',
      );

      return renderColumnWithEllipsis(
        formattedText,
        rowData as Recordable,
        rowIndex,
        textDisplayColumn,
      );
    }

    return renderColumnWithEllipsis(value, rowData as Recordable, rowIndex, textDisplayColumn);
  }

  // 处理后的列配置
  const processedColumns = computed<DataTableColumn<T>[]>(() => {
    const columns: DataTableColumn<T>[] = [];

    // 是否展示（hideInTable / ifShow）——顶层列与分组子列统一判断
    const isColumnVisible = (col: ProColumn<T>): boolean => {
      if (col.hideInTable) return false;
      if (col.ifShow !== undefined) {
        return typeof col.ifShow === 'function' ? col.ifShow(col) : col.ifShow;
      }
      return true;
    };

    // 叶子列规范化：单个 ProColumn → Naive 叶子列（原逻辑原样抽出，供分组子列复用）
    const buildLeafColumn = (col: ProColumn<T>): DataTableColumn<T> => {
      const dataKey = (col.dataIndex || col.key) as string;
      const tenantTimeZoneOptions = resolveTenantTimeZoneOptions(col);
      const columnTitle =
        tenantTimeZoneOptions !== null
          ? renderTenantDateTimeColumnTitle(
              col.title ?? String(col.key),
              resolveSearchTenantId(tenantTimeZoneOptions),
            )
          : col.title;

      const column: DataTableColumn<T> = {
        key: col.key as string,
        title: columnTitle,
        width: col.width,
        minWidth: col.minWidth,
        maxWidth: col.maxWidth,
        fixed: col.fixed,
        align: col.align || 'center',
        titleAlign: col.titleAlign,
        ellipsis: col.ellipsis
          ? typeof col.ellipsis === 'object'
            ? col.ellipsis
            : { tooltip: true }
          : undefined,
        resizable: col.resizable,
        sorter: col.sortable ? true : undefined,
        defaultSortOrder: col.defaultSortOrder,
        filter: col.filterable ? true : undefined,
        filterOptions: col.filterOptions,
        defaultFilterOptionValue: col.defaultFilterValue,
        className: col.className,
        cellProps: col.cellProps,
        render: col.render
          ? (rowData: T, rowIndex: number) => {
              // showTenantTimeZone 启用时把已解析的商户时区注入 render 第 4 参。
              // 解析链与 picker (useEffectiveDateRangeTimezone) 同源：
              //   ProCrudTable.context.timezoneId → defaultTenantId 兜底
              const timezone = tenantTimeZoneOptions ? columnRenderTimezone.value : undefined;
              return col.render!(rowData, rowIndex, col, timezone);
            }
          : (rowData: T, rowIndex: number) => {
              const value = !dataKey
                ? undefined
                : dataKey.includes('.')
                  ? dataKey
                      .split('.')
                      .reduce((obj: Recordable | undefined, key) => obj?.[key], rowData)
                  : (rowData as Recordable)[dataKey];

              if (tenantTimeZoneOptions !== null) {
                return renderTenantTimeZoneValue(
                  value,
                  rowData,
                  rowIndex,
                  col,
                  tenantTimeZoneOptions,
                ) as VNode;
              }

              return renderColumnWithEllipsis(
                value,
                rowData as Recordable,
                rowIndex,
                col as ProColumn<Recordable>,
              ) as VNode;
            },
      };

      // 标题 tooltip
      if (col.titleTooltip) {
        const typedColumn = column as DataTableColumn<T> & { title?: typeof columnTitle };
        const titleContent = typedColumn.title;
        typedColumn.title = () =>
          h('span', { style: { display: 'inline-flex', alignItems: 'center', gap: '4px' } }, [
            typeof titleContent === 'function'
              ? (titleContent as (column: DataTableColumn<T>) => VNode)(typedColumn)
              : (titleContent ?? ''),
            h(
              NTooltip,
              { trigger: 'hover' },
              {
                trigger: () =>
                  h(NIcon, { size: 14, style: { cursor: 'help', color: '#999' } }, () =>
                    h(QuestionCircleOutlined),
                  ),
                default: () => col.titleTooltip,
              },
            ),
          ]);
      }

      return column;
    };

    // 分组列递归：含 children（嵌套子列）时保留分组表头并递归规范化子列；否则当叶子列。
    // 修复：原先逐列拍平丢弃 children，导致分组表头（如昨日返佣等级 5 游戏「投注流水/返佣金额」）退化成空叶子列。
    const normalizeNode = (col: ProColumn<T>): DataTableColumn<T> => {
      const childCols = (col as { children?: ProColumn<T>[] }).children;
      if (Array.isArray(childCols) && childCols.length) {
        return {
          key: col.key as string,
          title: col.title,
          align: col.align || 'center',
          titleAlign: col.titleAlign,
          fixed: col.fixed,
          children: childCols.filter(isColumnVisible).map(normalizeNode),
        } as unknown as DataTableColumn<T>;
      }
      return buildLeafColumn(col);
    };

    for (const col of props.columns) {
      // 特殊列：selection 拦截替换为自定义列，expand 仍交给 Naive 处理。
      const colType = 'type' in col ? (col as { type?: string }).type : undefined;
      if (colType === 'selection') {
        columns.push(createCustomSelectionColumn(col as unknown as ProDataTableSelectionColumn<T>));
        continue;
      }
      if (colType === 'expand') {
        columns.push(col as DataTableColumn<T>);
        continue;
      }

      // 隐藏列 / 条件显示
      if (!isColumnVisible(col)) continue;

      // 分组列（含 children）或叶子列
      columns.push(normalizeNode(col));
    }

    return columns;
  });

  // 暴露 NDataTable 方法
  const exposedMethods = {
    sort: (columnKey: string | null, order: 'ascend' | 'descend' | false) => {
      tableRef.value?.sort(columnKey as any, order);
    },
    page: (page: number) => {
      tableRef.value?.page(page);
    },
    filter: (filters: Recordable | null) => {
      tableRef.value?.filter(filters);
    },
    clearSorter: () => {
      tableRef.value?.clearSorter();
    },
    clearFilters: () => {
      tableRef.value?.clearFilters();
    },
    scrollTo: (options: { top?: number; left?: number; row?: number }) => {
      tableRef.value?.scrollTo(options);
    },
  };

  defineExpose(exposedMethods);

  // 提供上下文
  provide(ProTableContextKey, {
    tableRef,
    columns: computed(() => props.columns as ProColumn<Recordable>[]),
    dataSource: computed(() => props.data as Recordable[]),
    loading: computed(() => props.loading),
  });
</script>

<style lang="less" scoped>
  .pro-data-table {
    &--tr-dragging {
      ::v-deep(.n-data-table-tr--dragging) {
        opacity: 0.5;
        background-color: var(--n-color-hover);
      }
    }

    &--flex-height {
      display: flex;
      flex-direction: column;
      // 用 flex 链而非 height:100%：放在 flex column 父（如 .pro-crud-table__table-wrapper）
      // 内时，flex:1 让自己在 main-axis 上吃满剩余空间；min-height:0 允许内部收缩。
      // 历史 height:100% 在与 summary/footer 同级的 flex 父中会争抢空间，导致 n-data-table
      // 内部 virtual-scroll 算高度异常（v3.6+ 已验证）。
      flex: 1;
      min-height: 0;
    }

    // 行底边线：naive single-line=false 默认行为偏弱，业务页面（如 finance/rechargeOrder
    // 历史 ::v-deep 写法）一直靠显式 td border-bottom 强化分隔。所有行（含最后一行）都加。
    // body 撑满模式下最后一行 border + body 底边会显双线，这是接受的取舍——保住每行清晰
    // 的视觉边界，比"无缝过渡到留白"更重要。
    ::v-deep(.n-data-table-tbody .n-data-table-tr .n-data-table-td) {
      border-bottom: 1px solid var(--n-merged-border-color);
    }

    // 列拖拽调整宽度：改为边框线样式
    ::v-deep(.n-data-table-resize-button) {
      width: 8px !important;
      right: -4px !important;

      &::after {
        width: 1px !important;
        height: 100% !important;
        top: 0 !important;
        transform: none !important;
        left: 50% !important;
        background-color: transparent !important;
        transition: background-color 0.2s ease !important;
      }

      &:hover::after {
        background-color: var(--n-th-icon-color-active) !important;
      }

      &--active::after {
        background-color: var(--n-th-icon-color-active) !important;
      }
    }
  }
</style>
