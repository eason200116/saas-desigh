<template>
  <n-cascader
    v-if="isSuperAuthUser"
    :value="adminValue"
    :options="adminTenantOptions"
    :loading="loading"
    :multiple="multiple"
    :clearable="false"
    check-strategy="child"
    v-bind="$attrs"
    @update:value="handleAdminUpdate"
  />
  <n-select
    v-else
    v-model:value="modelValue"
    :options="tenantOptions"
    :multiple="multiple"
    :clearable="false"
    v-bind="$attrs"
  />
</template>

<script setup lang="ts">
  import { computed, onMounted, watch } from 'vue';
  import type { CascaderOption, SelectOption } from 'naive-ui';
  import { useTenantOptions } from '@/hooks';
  import { useUserStore } from '@/store/modules/user';
  import { useProCrudTableContextSafe } from '../../context/crudTableContext';

  defineOptions({
    name: 'ProTenantSelect',
    inheritAttrs: false,
  });

  const props = withDefaults(
    defineProps<{
      immediate?: boolean;
      multiple?: boolean;
      /**
       * 是否在 modelValue 为空时自动回填激活商户（HeaderTenant 选中的商户）。
       * 默认 true：商户端用户打开搜索/编辑表单时省去手动选自己商户的步骤（项目级统一行为）。
       * 设为 false：让用户必须手动选择商户（适用于跨商户审核明细等需要主动筛选的场景）。
       */
      autoFill?: boolean;
      /**
       * 数据源范围。
       * - 'all'（默认）：全部商户。super-auth-user 走 cascader、普通用户走扁平 select。
       * - 'approval'：仅 approvalTenantList（当前用户可审批的商户子集），所有用户统一走扁平 select；
       *   默认填充走 defaultApprovalTenantId。用于人工充值、审核等限定在审批范围的页面。
       */
      scope?: 'all' | 'approval';
    }>(),
    {
      immediate: true,
      multiple: false,
      autoFill: true,
      scope: 'all',
    },
  );

  type TenantSelectValue = number | number[] | null | undefined;
  type RawTenantSelectValue = number | string | Array<number | string> | null | undefined;

  const modelValue = defineModel<TenantSelectValue>();
  const userStore = useUserStore();
  // approval 模式所有用户统一走扁平 select（审批列表本身无层级），与 bankCard 等"商户"下拉视觉对齐。
  const isSuperAuthUser = computed(() => props.scope === 'all' && userStore.isSuperAuthUser);
  const {
    defaultTenantId,
    tenantOptions: scopedTenantOptions,
    tenantCascaderOptions,
    approvalTenantOptions,
    defaultApprovalTenantId,
    loading,
    load,
    getTenantTimeZone,
  } = useTenantOptions();
  const crudCtx = useProCrudTableContextSafe();

  const tenantOptions = computed<SelectOption[]>(() => {
    const source =
      props.scope === 'approval' ? approvalTenantOptions.value : scopedTenantOptions.value;
    return source as unknown as SelectOption[];
  });
  const adminTenantOptions = computed<CascaderOption[]>(
    () => tenantCascaderOptions.value as unknown as CascaderOption[],
  );
  // approval 模式默认回填值走 defaultApprovalTenantId；'all' 模式保持原有 defaultTenantId 行为。
  const effectiveDefaultTenantId = computed<number | null>(() =>
    props.scope === 'approval' ? defaultApprovalTenantId.value || null : defaultTenantId.value,
  );
  const adminValue = computed<TenantSelectValue>(() => {
    if (props.multiple) return normalizeTenantIds(modelValue.value);
    return typeof modelValue.value === 'number' ? modelValue.value : null;
  });

  function toTenantId(value: number | string | null | undefined) {
    if (value == null) return null;
    const tenantId = Number(value);
    return Number.isFinite(tenantId) ? tenantId : null;
  }

  function normalizeTenantIds(value: RawTenantSelectValue) {
    if (!Array.isArray(value)) {
      const tenantId = toTenantId(value);
      return tenantId == null ? [] : [tenantId];
    }
    return value.map((item) => toTenantId(item)).filter((item): item is number => item !== null);
  }

  function hasTenantValue(value: TenantSelectValue) {
    return Array.isArray(value) ? value.length > 0 : value !== undefined && value !== null;
  }

  function handleAdminUpdate(value: RawTenantSelectValue) {
    if (props.multiple) {
      modelValue.value = normalizeTenantIds(value);
      return;
    }
    modelValue.value = toTenantId(Array.isArray(value) ? value[0] : value);
  }

  onMounted(() => {
    if (props.immediate && isSuperAuthUser.value) {
      void load();
    }
  });

  watch(
    () =>
      [
        modelValue.value,
        effectiveDefaultTenantId.value,
        isSuperAuthUser.value,
        props.multiple,
      ] as const,
    ([value, tenantId, currentIsSuperAuthUser, multiple]) => {
      if (!props.autoFill) return; // opt-out：让用户必须手动选商户
      if (currentIsSuperAuthUser) return;
      if (hasTenantValue(value)) return;
      if (tenantId === null) return;
      modelValue.value = multiple ? [tenantId] : tenantId;
    },
    { immediate: true },
  );

  // 单选商户才写入 ProCrudTableContext。多选商户的时区口径由页面层决定，
  // 避免组件用任一选中商户或 null 覆盖页面设置的默认商户时区。
  watch(
    () => [modelValue.value, props.multiple] as const,
    ([val, multiple]) => {
      if (!crudCtx) return;
      if (multiple) return;
      const id = Array.isArray(val) ? val[0] : val;
      const tz = id != null ? getTenantTimeZone(id) || null : null;
      crudCtx.setTimezoneId(tz);
    },
    { immediate: true },
  );
</script>
