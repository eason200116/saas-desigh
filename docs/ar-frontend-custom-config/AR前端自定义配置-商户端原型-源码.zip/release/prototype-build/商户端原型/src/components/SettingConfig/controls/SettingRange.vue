<template>
  <n-popover trigger="manual" placement="bottom" :show="showEdit" @clickoutside="showEdit = false">
    <template #trigger>
      <n-button :disabled="disabled" size="small" quaternary type="info" @click="openEdit">
        {{ value1 }}{{ suffix }} ~ {{ value2 }}{{ suffix }}
      </n-button>
    </template>
    <div class="range-edit">
      <n-space align="center" size="small">
        <n-input-number
          ref="input1Ref"
          v-model:value="editValue1"
          :min="computedMin"
          :max="editValue2 ?? computedMax"
          :precision="computedPrecision"
          :show-button="false"
          size="small"
          class="range-input"
        >
          <template v-if="suffix" #suffix>{{ suffix }}</template>
        </n-input-number>
        <span>~</span>
        <n-input-number
          v-model:value="editValue2"
          :min="editValue1 ?? computedMin"
          :max="computedMax"
          :precision="computedPrecision"
          :show-button="false"
          size="small"
          class="range-input"
        >
          <template v-if="suffix" #suffix>{{ suffix }}</template>
        </n-input-number>
      </n-space>
      <n-space justify="end" size="small" class="mt-2">
        <n-button size="tiny" @click="showEdit = false">
          {{ t('common.cancel') }}
        </n-button>
        <n-button size="tiny" type="primary" @click="handleConfirm">
          {{ t('common.confirm') }}
        </n-button>
      </n-space>
    </div>
  </n-popover>
</template>

<script setup lang="ts">
  import { ref, computed, nextTick } from 'vue';
  import { useI18n } from 'vue-i18n';
  import { useMessage } from 'naive-ui';
  import type { SettingRule } from '../types';

  const props = defineProps<{
    value1?: number | null;
    value2?: number | null;
    disabled?: boolean;
    suffix?: string;
    rules?: SettingRule[];
  }>();

  const emit = defineEmits<{
    (e: 'confirm', v1: number, v2: number): void;
  }>();

  const { t } = useI18n();
  const message = useMessage();

  const showEdit = ref(false);
  const editValue1 = ref<number | null>(null);
  const editValue2 = ref<number | null>(null);
  const input1Ref = ref();

  const computedMin = computed(() => props.rules?.[0]?.min ?? 0);
  const computedMax = computed(() => props.rules?.[0]?.max ?? undefined);
  const computedPrecision = computed(() => (props.rules?.[0]?.integer ? 0 : 2));

  const openEdit = () => {
    if (props.disabled) return;
    editValue1.value = props.value1 ?? 0;
    editValue2.value = props.value2 ?? 0;
    showEdit.value = true;
    nextTick(() => {
      input1Ref.value?.focus();
    });
  };

  const handleConfirm = () => {
    const v1 = editValue1.value ?? 0;
    const v2 = editValue2.value ?? 0;

    if (v1 > v2) {
      message.warning(t('common.rangeError'));
      return;
    }

    emit('confirm', v1, v2);
    showEdit.value = false;
  };
</script>

<style scoped>
  .range-edit {
    width: 280px;
  }

  .range-input {
    width: 100px;
  }
</style>
