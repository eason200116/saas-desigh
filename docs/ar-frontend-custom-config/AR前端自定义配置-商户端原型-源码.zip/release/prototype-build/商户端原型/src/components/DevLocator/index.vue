<!--
  DevLocator · 开发专用「定位探针」浮层（仅 import.meta.env.DEV 挂载，不进生产打包）。
  用途：精确告知 Claude "要改页面哪个位置"。
  用法：悬停坐标默认关闭（底部「规范版」徽标常驻可见）；按 Cmd+Shift+X(Mac)/Alt+Shift+X(Win) 开启后，移动鼠标看 十字线 + 坐标 + 光标下元素 + 交互规范；右键=复制定位信息到剪贴板（左键正常点击页面不受影响）。
  复制内容示例：
    [定位] 坐标(1200,650)
    元素: a.cfg-oplog__all "查看全部记录 →"
    路径: div.cfg-oplog__pop > div.cfg-oplog__ft > a.cfg-oplog__all
  纯前端调试工具，无业务逻辑、不依赖第三方插件。
-->
<template>
  <teleport to="body">
    <div class="devloc" aria-hidden="true">
      <!-- 悬停坐标层：默认关闭，⌘/Alt+Shift+X 开启（十字线 + 跟随光标的坐标/规范面板） -->
      <template v-if="active">
        <!-- 十字线 -->
        <div class="devloc__vline" :style="{ left: x + 'px' }"></div>
        <div class="devloc__hline" :style="{ top: y + 'px' }"></div>

      <!-- 信息面板（跟随光标，靠边翻转） -->
      <div class="devloc__panel" :style="panelStyle">
        <div class="devloc__coord">坐标 {{ x }} , {{ y }}</div>
        <div class="devloc__el">{{ elDesc || '—' }}</div>
        <div v-if="elText" class="devloc__text">“{{ elText }}”</div>
        <!-- 交互规范（命中控件 key 时显示；路径仅右键复制才带） -->
        <div v-if="specHit" class="devloc__spec">
          <div v-if="sAuthored" class="devloc__spec-row" style="color: #c08a4a">
            <b style="color: #c08a4a">补写</b>两文档缺/过简，据V1+业务补写
          </div>
          <!-- 控件名称：普通控件(A)/按钮(C) 显示 -->
          <div v-if="sType !== 'static' && sName" class="devloc__spec-row">
            <b>控件名称</b>{{ sName }}
          </div>
          <div class="devloc__spec-row">
            <b>{{ sType === 'static' ? '字段' : '控件字段' }}</b
            >{{ sField }}
          </div>
          <div v-if="sDef" class="devloc__spec-row">
            <b>{{ sType === 'static' ? '字段定义' : '控件定义' }}</b
            >{{ sDef }}
          </div>
          <div v-if="sIntro" class="devloc__spec-row"><b>介绍</b>{{ sIntro }}</div>
          <!-- 普通控件：控件规范(含限制)。静态名词不显 -->
          <div v-if="sType === 'input' && sSpec" class="devloc__spec-row">
            <b>控件规范</b>{{ sSpec }}
          </div>
          <!-- 控件逻辑（普通控件 + 确认控件 + 跳转 都显示，文档有则显示） -->
          <div v-if="sLogic" class="devloc__spec-row"><b>控件逻辑</b>{{ sLogic }}</div>
          <!-- 边界情况 -->
          <div v-if="sBoundary" class="devloc__spec-row"><b>边界</b>{{ sBoundary }}</div>
          <!-- Toast 文案 -->
          <div v-if="sToast" class="devloc__spec-row"><b>Toast</b>{{ sToast }}</div>
          <!-- 校验枚举：仅确认控件(确认/保存/应用等最终操作)额外多这一项 -->
          <div v-if="sCheckEnum" class="devloc__spec-row" style="color: #c08a4a">
            <b style="color: #c08a4a">校验枚举</b>{{ sCheckEnum }}
          </div>
        </div>
        <!-- 文档未收录（docMode 页面：命中控件但两文档无对应条目） -->
        <div v-else-if="specMiss" class="devloc__spec">
          <div class="devloc__spec-row" style="color: #c0392b">
            <b style="color: #c0392b">⚠ 文档未收录</b>{{ sMissKey }}
          </div>
          <div class="devloc__spec-row" style="color: #8a8a8a">
            交互规则 / 字段词典暂无此控件；去文档补后重跑 gen-doc-spec 即显示
          </div>
        </div>
        <div class="devloc__tip">
          {{ specHit ? '右键=复制全文(含路径) · ' : '右键=复制 · ' }}左键正常点 · ⌘/Alt+Shift+X 关闭
        </div>
      </div>

        <!-- 复制成功闪现 -->
        <div v-if="flash" class="devloc__flash">✅ 已复制定位信息</div>
      </template>

      <!-- 底部「规范版」徽标已隐藏（2026-07-18 用户定：界面不显示常驻徽标）。
           开关仍靠快捷键 ⌘/Alt+Shift+X（见 onKey，挂载即注册、独立于本徽标），按下即可调起悬停坐标。
           原 badge 的拖动/定位代码（badgeStyle/badgePos/onBadgeDown 等）无渲染引用即不显示，暂留无害。 -->
    </div>
  </teleport>
</template>

<script lang="ts" setup>
  import { computed, onBeforeUnmount, onMounted, ref } from 'vue';
  import { useRoute } from 'vue-router';
  import vipConfigSpec from './spec-data/vipConfig.json';
  import rebateConfigSpec from './spec-data/rebateConfig.json';
  import messageTemplateSpec from './spec-data/messageTemplate.json';
  import memberUserSpec from './spec-data/memberUser.json';
  import memberDetailSpecRaw from './spec-data/memberDetail.json';
  import authored from './spec-data/_authored.json';
  import registry from './spec-data/_registry.json';

  // 会员详情表：生成数据 + 人工补写覆盖（补写按中文名 key，优先生效并带 authored 标记）
  const memberDetailSpec: Record<string, any> = {
    ...memberDetailSpecRaw,
    ...(authored as any).detail,
  };
  // 会员弹窗控件表（人工补写，按中文名匹配）
  const memberModalsSpec: Record<string, any> = (authored as any).modals;

  // 通用页面规范：spec-data/pages/*.json 自动加载 + _registry.json 映射 route→{spec,mode,alias}
  // 由工作流按页产出（每条含 provenance/isNew，R53 证据锚定）
  const pageModules = import.meta.glob('./spec-data/pages/*.json', { eager: true }) as Record<
    string,
    any
  >;
  const pageTables: Record<string, any> = {};
  for (const p in pageModules) {
    const nm = p.split('/').pop()!.replace('.json', '');
    pageTables[nm] = pageModules[p].default || pageModules[p];
  }
  // _registry: [{ match:'/member/groupManage', spec:'memberGroupManage', mode:'key'|'name', alias?:{} }]
  const pageRegistry: Array<{
    match: string;
    spec: string;
    mode?: string;
    alias?: Record<string, string>;
  }> = (registry as any) || [];

  const route = useRoute();

  // 会员列表：页面列 key → 字段词典 key 的别名（命名不一致的老字段；新字段直接同名/大小写兼容）
  const MEMBER_ALIAS: Record<string, string> = {
    site: 'tenantId',
    memberId: 'userId',
    account: 'userName',
    balance: 'amount',
    thirdPartyBalance: 'thirdBlance',
    safeBalance: 'safeAmount',
    redPacketBalance: 'redAmount',
    inviteCode: 'inviterCode',
    channelNo: 'channelCode',
    group: 'userGroupName',
    registerDevice: 'phoneType',
    registerTime: 'addTime',
    status: 'userState',
    type: 'userType',
    blacklist: 'isBlock',
    firstRechargeTime: 'rechargeTimeFirst',
    lastRechargeTime: 'rechargeTimeLast',
    rechargeAmount: 'rechargeAmounts',
    rechargeCount: 'rechargeTimes',
    lastOnline: 'userActivityDate',
    firstLoginTime: 'userLoginDate',
    frontGoogle: 'isvalidator',
    betAmount: 'amountofCode',
  };

  // docMode(doc-index) 页的「页面 data-col-key → 文档 key」桥接：页面列 key 与文档/词典 key 不一致时用。
  // 登录记录/验证码查询 两边 key 一致，无需 alias；会员列表沿用 MEMBER_ALIAS（仅用于表格单元格）。
  // 各页「页面列 key → 字段词典 key」桥接（列命名与词典不一致时）
  const OPS_EMAIL_ALIAS: Record<string, string> = { name: 'emailName', logo: 'emailLogo' };
  const OPS_BANNER_ALIAS: Record<string, string> = { image: 'imageByLang' };
  const OPS_SMS_ALIAS: Record<string, string> = { name: 'smsName', template: 'smsContent' };
  // 异常会员：复合列(金额+笔数)取金额定义 + 状态/时间列名不一致
  const RISK_ABNORMAL_ALIAS: Record<string, string> = {
    memberState: 'userState',
    blacklistState: 'isBlock',
    bet: 'betAmount',
    recharge: 'rechargeAmount',
    withdraw: 'withdrawAmount',
    registerTime: 'userRegisterTime',
  };
  const DOC_ALIAS_BY_ROUTE: Record<string, Record<string, string>> = {
    '/member/user': MEMBER_ALIAS,
    '/operations/emailConfig': OPS_EMAIL_ALIAS,
    '/operations/banner': OPS_BANNER_ALIAS,
    '/operations/smsConfig': OPS_SMS_ALIAS,
    '/risk-control/abnormalMember': RISK_ABNORMAL_ALIAS,
    // 站内消息：列表「标题/消息内容」列 key=title/content → 字段词典逐语言字段(同一概念,
    // contentByLang 定义即写明「列表显默认语言」)。
    '/operations/inboxMessage': { title: 'titleByLang', content: 'contentByLang' },
  };

  // 搜索控件专用别名：搜索项 data-spec(=搜索 path) → 交互规则 controls key。
  // 与 MEMBER_ALIAS（列/单元格别名）分开——列别名是「页面列 key → 字段词典 key」，
  // 若误套到搜索分支会把 memberId 改写成 userId 等、反而查不到 controls（根因2）。
  // 只登记 path 与 controls 键名真不一致者：会员列表商户搜索 path=tenantId、文档控件键为 merchant。
  const MEMBER_SEARCH_ALIAS: Record<string, string> = {
    tenantId: 'merchant',
  };
  const SEARCH_ALIAS_BY_ROUTE: Record<string, Record<string, string>> = {
    '/member/user': MEMBER_SEARCH_ALIAS,
  };

  // 单元格「可点跳转」专用别名：页面列 key → 交互规则 actions key。
  // 用于「同一列两态」的可点列——如前台/后台谷歌绑定码列(已绑定→蓝链「点击查看谷歌码」)，
  // 列 key(frontGoogle/backGoogle) 与文档 action key(处理函数名 handleViewGoogleAuth)不一致时桥接。
  // 仅「交互态(可点)」生效；未绑定的静态态仍走 fields(字段词典·绑定状态定义)，见 resolveCell。
  const MEMBER_ACTION_ALIAS: Record<string, string> = {
    frontGoogle: 'handleViewGoogleAuth',
    backGoogle: 'handleViewGoogleAuth',
  };
  const ACTION_ALIAS_BY_ROUTE: Record<string, Record<string, string>> = {
    '/member/user': MEMBER_ACTION_ALIAS,
    // VIP记录·VIP升降级记录(vipOpLog)：操作列「查看详情」按钮列 key=actions → 交互规则 openDetail
    '/operations/vipRecord': { actions: 'openDetail', action: 'openDetail' },
  };
  // 按路由查别名表：hitRoute 来自 docIndexByRoute(已全小写)，而别名表键可能含大写(如 emailConfig)，
  // 故大小写不敏感匹配——否则含大写字母的路由永远取不到别名（emailConfig name/logo bug 根因）。
  const aliasByRoute = (
    tbl: Record<string, Record<string, string>>,
    r: string,
  ): Record<string, string> | null => {
    if (tbl[r]) return tbl[r];
    const rl = r.toLowerCase();
    for (const k in tbl) if (k.toLowerCase() === rl) return tbl[k];
    return null;
  };

  // 搜索项标签 → 词典 key 的别名（标签名与控件名不完全一致的少数字段）
  // 2026-07-09「在线时间」改名「最后登录时间」；保留旧名别名做向后兼容
  const SEARCH_LABEL_ALIAS: Record<string, string> = {
    最后登录时间: 'userActivityDate',
    在线时间: 'userActivityDate',
    渠道: 'channelCode',
  };

  // 框架级通用控件（搜索栏/工具栏，非业务文档控件，据实标注通用行为，不臆造业务规则）
  const GENERIC_CONTROLS: Record<string, any> = {
    取消: {
      field: '(通用)',
      name: '取消',
      type: 'button',
      logic: '关闭当前弹窗/放弃本次操作，不保存改动。',
    },
    关闭: {
      field: '(通用)',
      name: '关闭',
      type: 'button',
      logic: '关闭当前弹窗/面板，不保存改动。',
    },
    查询: {
      field: '(通用)',
      name: '查询',
      type: 'button',
      logic: '按当前筛选条件查询列表，重置分页到第 1 页。',
    },
    搜索: {
      field: '(通用)',
      name: '搜索',
      type: 'button',
      logic: '按当前筛选条件查询列表，重置分页到第 1 页。',
    },
    重置: {
      field: '(通用)',
      name: '重置',
      type: 'button',
      logic: '清空所有筛选条件、恢复默认值（含默认商户），并重新查询。',
    },
    展开: { field: '(通用)', name: '展开', type: 'button', logic: '展开更多筛选项（高级搜索）。' },
    收起: { field: '(通用)', name: '收起', type: 'button', logic: '收起高级筛选项，仅留常用项。' },
    刷新: {
      field: '(通用)',
      name: '刷新',
      type: 'button',
      logic: '按当前条件重新拉取当前页数据。',
    },
  };

  // 站点级通用：可点「会员ID」链接（全站统一规范——真实会员ID列渲染蓝链→点开会员详情弹窗）。
  // 仅当单元格「可点(交互态)」且列 key 为 memberId/userId、且页面文档未单列该 action 时兜底；
  // 已在文档单列的(如登录记录 actions.userId)优先用文档。据实锚定 renderMemberIdLink→openMemberDetailModal。
  const GENERIC_MEMBER_ID_LINK: any = {
    field: 'memberId',
    name: '会员ID链接',
    type: 'input',
    fieldDef: '会员（可下钻至会员详情）',
    spec: '列表内真实会员ID渲染为蓝色可点击链接，非输入控件、无输入校验。',
    logic: '点击调用 openMemberDetailModal(会员ID, 商户) 打开该会员的详情弹窗（只读详情）。',
    toast: '加载失败 Toast「加载失败：{原因}」',
    boundary: '会员ID为空/未注册显灰标或「--」、不可点；员工ID/汇总行/未注册等非真实会员不可点。',
    intro: '谁的记录（点开看会员详情）',
  };
  const MEMBER_ID_LINK_KEYS = new Set(['memberid', 'userid']);

  // 框架通用容器兜底：快捷时间/翻页/列设置 这类每页都有、不在业务文档里的区域，
  // 按「容器」给通用卡片——覆盖区域内所有子控件(图标/数字/文字)，避免悬停空白。
  const GENERIC_CONTAINERS: Array<{ sel: string; entry: any }> = [
    {
      sel: '.pro-crud-table__quick-date, .pro-quick-date-buttons',
      entry: {
        field: '(通用·快捷时间)',
        name: '快捷时间',
        type: 'button',
        logic:
          '点击把时间区间一键设为该快捷值（今天/本周/本月…）并按当前条件查询；「所有」= 清空时间筛选、查全部数据。',
      },
    },
    {
      sel: '.n-pagination',
      entry: {
        field: '(通用·分页)',
        name: '翻页',
        type: 'button',
        logic: '切换页码 / 改每页条数 / 跳至指定页；切换后按当前筛选重新拉取该页数据。',
      },
    },
    {
      sel: '.pro-crud-table__toolbar-settings, .pro-column-setting, .pro-column-setting-panel',
      entry: {
        field: '(通用·工具栏)',
        name: '列设置',
        type: 'button',
        logic: '显隐 / 拖拽排序 / 冻结列；配置本地持久化，仅影响列展示、不改数据。',
      },
    },
  ];
  function genericContainer(el: Element | null): any {
    if (!el) return null;
    for (const g of GENERIC_CONTAINERS) if (el.closest?.(g.sel)) return g.entry;
    return null;
  }

  // 大小写不敏感查表（页面 registerIp vs 词典 registerIP、nickname vs nickName）
  const ciCache = new WeakMap<object, Record<string, any>>();
  function ciLookup(table: Record<string, any>, key: string): any {
    if (table[key]) return table[key];
    let idx = ciCache.get(table);
    if (!idx) {
      idx = {};
      for (const k in table) idx[k.toLowerCase()] = table[k];
      ciCache.set(table, idx);
    }
    return idx[key.toLowerCase()] || null;
  }

  const active = ref(false); // 悬停坐标默认关闭；底部「规范版」徽标常驻，⌘/Alt+Shift+X 开启
  const x = ref(0);
  const y = ref(0);
  const elDesc = ref('');
  const elText = ref('');
  const elPath = ref('');
  const flash = ref(false);
  let flashTimer: any = null;

  // ===== 顶部 badge 可拖动 =====
  // badgePos=null 时用 CSS 默认（底部居中）；拖动后切成显式 left/top
  const badgePos = ref<{ left: number; top: number } | null>(null);
  const badgeDragging = ref(false);
  let badgeDrag = { offX: 0, offY: 0, w: 0, h: 0 };
  const badgeStyle = computed(() =>
    badgePos.value
      ? {
          left: badgePos.value.left + 'px',
          top: badgePos.value.top + 'px',
          right: 'auto',
          bottom: 'auto',
          transform: 'none',
        }
      : {},
  );
  function onBadgeDown(e: MouseEvent) {
    e.preventDefault();
    e.stopPropagation();
    const rect = (e.currentTarget as HTMLElement).getBoundingClientRect();
    badgeDrag = {
      offX: e.clientX - rect.left,
      offY: e.clientY - rect.top,
      w: rect.width,
      h: rect.height,
    };
    badgeDragging.value = true;
    window.addEventListener('mousemove', onBadgeMove, true);
    window.addEventListener('mouseup', onBadgeUp, true);
  }
  function onBadgeMove(e: MouseEvent) {
    if (!badgeDragging.value) return;
    e.preventDefault();
    e.stopPropagation();
    const left = Math.max(0, Math.min(window.innerWidth - badgeDrag.w, e.clientX - badgeDrag.offX));
    const top = Math.max(0, Math.min(window.innerHeight - badgeDrag.h, e.clientY - badgeDrag.offY));
    badgePos.value = { left, top };
  }
  function onBadgeUp() {
    badgeDragging.value = false;
    window.removeEventListener('mousemove', onBadgeMove, true);
    window.removeEventListener('mouseup', onBadgeUp, true);
  }

  // 规范（命中控件 key 时填充）
  const specHit = ref(false);
  const sField = ref('');
  const sName = ref(''); // 控件名称
  const sType = ref('input'); // static(静态列) / input(普通控件) / button(确认按钮)
  const sDef = ref('');
  const sIntro = ref(''); // 控件介绍(大白话，会员列表用)
  const sSpec = ref('');
  const sLogic = ref('');
  const sBoundary = ref('');
  const sToast = ref('');
  const sCheckEnum = ref(''); // 校验枚举：仅确认控件(确认/保存/应用等)额外多这一项
  const sAuthored = ref(false); // 是否人工补写（两文档缺/过简，经授权自定义）
  const specMiss = ref(false); // docMode: 命中页面控件但两文档未收录该 key
  const sMissKey = ref('');
  // 文档抽取(docMode)：自动加载 spec-data/doc-index/*.json（scripts/gen-doc-spec.mjs 生成，勿手改），
  // 按各文件 __meta.route 建「路由 → 三层(controls搜索/actions列交互·按钮/fields静态列)」映射。
  // 以后加页只改生成器 PAGES + 重跑，无需改本引擎。
  const docIndexModules = import.meta.glob('./spec-data/doc-index/*.json', {
    eager: true,
  }) as Record<string, any>;
  const docIndexByRoute: Record<string, { controls: any; actions: any; fields: any }> = {};
  for (const path in docIndexModules) {
    const mod = docIndexModules[path]?.default || docIndexModules[path];
    const route = mod?.__meta?.route;
    if (route)
      docIndexByRoute[String(route).toLowerCase()] = {
        controls: mod.controls || {},
        actions: mod.actions || {},
        fields: mod.fields || {},
      };
  }

  // 各页规范表；后续拓展页在此登记 {table, alias, byName}
  // byName=true 时按中文标签匹配（表键即中文名，如会员详情）；否则按 key(data-col-key/data-spec) 匹配
  function currentSpecCtx(
    el?: Element | null,
  ): { table: Record<string, any>; alias: Record<string, string> | null; byName?: boolean } | null {
    // 会员详情·基本信息（页面或弹窗）：DOM 命中 .detail-sections 即用详情表，与路由无关
    if (el && el.closest?.('.detail-sections, .detail-cell'))
      return { table: memberDetailSpec, alias: null, byName: true };
    // 会员操作弹窗（修改密码/三方/红包/谷歌/批量等）：在 .n-modal/.n-drawer 内且当前是会员页 → 弹窗控件表
    const rp = (route.path || '').toLowerCase();
    if (
      el &&
      el.closest?.('.n-modal, .n-drawer') &&
      (rp.includes('member/user') || rp.includes('memberdetail'))
    )
      return { table: memberModalsSpec, alias: null, byName: true };
    const p = rp;
    // 文档抽取页(docMode)：路由命中 doc-index/*.json 的 __meta.route → 三层，最长匹配优先。
    // 优先级高于下方手抄分支；详情弹窗/操作弹窗(上面 DOM 分支)仍走手抄表，不受影响。
    {
      let hit: { controls: any; actions: any; fields: any } | null = null;
      let hitRoute = '';
      let hitLen = 0;
      for (const r in docIndexByRoute) {
        if (p.includes(r) && r.length > hitLen) {
          hit = docIndexByRoute[r];
          hitRoute = r;
          hitLen = r.length;
        }
      }
      if (hit)
        return {
          ...hit,
          alias: aliasByRoute(DOC_ALIAS_BY_ROUTE, hitRoute),
          searchAlias: aliasByRoute(SEARCH_ALIAS_BY_ROUTE, hitRoute),
          actionAlias: aliasByRoute(ACTION_ALIAS_BY_ROUTE, hitRoute),
          docMode: true,
        } as any;
    }
    if (p.includes('vipconfig'))
      return { table: vipConfigSpec as Record<string, any>, alias: null };
    if (p.includes('rebateconfig'))
      return { table: rebateConfigSpec as Record<string, any>, alias: null };
    if (p.includes('messagetemplate'))
      return { table: messageTemplateSpec as Record<string, any>, alias: null };
    if (p.includes('memberdetail'))
      return { table: memberDetailSpec as Record<string, any>, alias: null, byName: true };
    // 注：会员列表/分组管理/验证码查询/登录记录 已走上方 docMode(doc-index) 分支；
    // memberUserSpec 仅作 doc-index 缺失时的兜底（正常不会到这）。
    if (p.includes('member/user'))
      return { table: memberUserSpec as Record<string, any>, alias: MEMBER_ALIAS };
    // 通用注册表（工作流产出的新页面）：路由子串匹配，取最长匹配避免父/子路由撞车
    let best: (typeof pageRegistry)[number] | null = null;
    for (const r of pageRegistry) {
      if (p.includes(r.match.toLowerCase()) && (!best || r.match.length > best.match.length))
        best = r;
    }
    if (best && pageTables[best.spec])
      return {
        table: pageTables[best.spec],
        alias: best.alias || null,
        byName: best.mode === 'name',
      };
    return null;
  }

  // 归一化标签：去空白/尾冒号/括号备注/请选择请输入前缀，便于模糊匹配
  function normLabel(s: string): string {
    return (s || '')
      .replace(/[\s*＊]+$/, '') // 去必填星号/尾空白（"商户 *" → "商户"）
      .replace(/\s+/g, '')
      .replace(/^请(选择|输入)/, '')
      .replace(/[（(][^）)]*[）)]/g, '')
      .replace(/[:：]$/, '')
      .trim();
  }

  // 按控件中文名兜底查表（搜索项/按钮/详情展示项等无 key 控件）
  // preferStatic=true 时同名优先取静态展示项（详情页字段以展示为主）；否则优先交互控件(非 static)
  // 匹配顺序：搜索标签别名 → 通用控件 → 精确名 → 归一化名 → 双向包含
  const nameCache = new WeakMap<
    object,
    { normal: Record<string, any>; stat: Record<string, any> }
  >();
  function nameLookup(table: Record<string, any>, label: string, preferStatic = false): any {
    if (!label) return null;
    if (SEARCH_LABEL_ALIAS[label]) {
      const hit = ciLookup(table, SEARCH_LABEL_ALIAS[label]);
      if (hit) return hit;
    }
    if (GENERIC_CONTROLS[label]) return GENERIC_CONTROLS[label];
    let pair = nameCache.get(table);
    if (!pair) {
      const normal: Record<string, any> = {};
      const stat: Record<string, any> = {};
      for (const k in table) {
        const e = table[k];
        if (!e || !e.name) continue;
        // 同时登记原名与「小写归一名」——英文 token 大小写常漂(FireBase vs Firebase)，按小写兜底匹配
        for (const nk of [e.name, normLabel(e.name), normLabel(e.name).toLowerCase()]) {
          if (!nk) continue;
          // normal：同键优先非 static；stat：同键优先 static
          if (!normal[nk] || (normal[nk].type === 'static' && e.type !== 'static')) normal[nk] = e;
          if (!stat[nk] || (stat[nk].type !== 'static' && e.type === 'static')) stat[nk] = e;
        }
      }
      pair = { normal, stat };
      nameCache.set(table, pair);
    }
    const idx = preferStatic ? pair.stat : pair.normal;
    if (idx[label]) return idx[label];
    const nl = normLabel(label);
    if (idx[nl]) return idx[nl];
    if (idx[nl.toLowerCase()]) return idx[nl.toLowerCase()];
    // 仅允许「标签包含控件名」这一安全方向（如"在线时间范围"含"在线时间")，取最长匹配；
    // 反方向(控件名包含短标签,如"批量取消拉黑"含"取消")会误报，已弃用。控件名须≥3字。
    let best: any = null;
    let bestLen = 0;
    for (const nk in idx) {
      if (nk.length < 3) continue;
      if (nl.includes(nk) && nk.length > bestLen) {
        best = idx[nk];
        bestLen = nk.length;
      }
    }
    return best;
  }

  // 取光标控件的"标签文字"：详情展示项 .detail-cell 优先读 .detail-cell__label（避免带上值）；
  // 其次表单项标签 / placeholder / aria-label；再退按钮/开关自身短文本
  function findLabel(el: Element | null): string {
    if (!el) return '';
    const cell = (el.closest?.('.detail-cell') as HTMLElement | null) || null;
    if (cell) {
      const lbl = cell.querySelector('.detail-cell__label');
      // 去掉「新」标与空白
      const t = ((lbl?.childNodes?.[0]?.textContent ?? lbl?.textContent) || '')
        .replace(/新\s*$/, '')
        .replace(/\s+/g, ' ')
        .trim();
      if (t) return t;
    }
    // 分区头开关标签（领取返佣/对上级返佣）
    const sw = (el.closest?.('.detail-section__switch') as HTMLElement | null) || null;
    if (sw) {
      const t = (sw.querySelector('.detail-section__switch-label')?.textContent || '')
        .replace(/\s+/g, ' ')
        .trim();
      if (t) return t;
    }
    const fi = (el.closest?.('.n-form-item, .n-form-item-gi') as HTMLElement | null) || null;
    if (fi) {
      const lbl = fi.querySelector('.n-form-item-label__text, .n-form-item-label');
      const t = (lbl?.textContent || '').replace(/\s+/g, ' ').trim();
      if (t) return t;
    }
    // placeholder / aria-label（自身或内嵌 input/select）——搜索项常见
    const inp =
      ((el as HTMLElement).getAttribute?.('placeholder') ? el : null) ||
      el.querySelector?.('[placeholder]') ||
      fi?.querySelector('[placeholder]');
    const ph = (inp as HTMLElement | null)?.getAttribute?.('placeholder') || '';
    if (ph) return ph;
    const aria = (el as HTMLElement).getAttribute?.('aria-label') || '';
    if (aria) return aria;
    const own = (el.textContent || '').replace(/\s+/g, ' ').trim();
    if (own && own.length <= 12) return own;
    return '';
  }

  // 从光标元素向上找带 key 的宿主(表格 data-col-key / 手动 data-spec)，经别名+大小写兼容查规范；
  // 查不到再按中文标签兜底匹配控件名。
  // 非控件：弹窗/抽屉遮罩背景、分区标题等（不含高级搜索面板内字段——那些要匹配）
  const NO_MATCH_SEL =
    '.n-modal-mask,.n-drawer-mask,' +
    '.detail-section__title,.detail-grid__subheader,.pro-advanced-search__section-title';

  function resolveSpec(el: Element | null) {
    specMiss.value = false;
    const ctx = currentSpecCtx(el);
    if (!ctx || !el) {
      specHit.value = false;
      return;
    }
    // 高级搜索遮罩「背景暗色区」非控件；但面板内(.pro-advanced-search__panel)的筛选项要匹配
    const advBackdrop =
      !!el.closest?.('.pro-advanced-search__mask') && !el.closest?.('.pro-advanced-search__panel');
    // 遮罩/浮层/分区标题等非控件 → 不匹配
    if (el.closest?.(NO_MATCH_SEL) || advBackdrop) {
      specHit.value = false;
      return;
    }
    let key = '';
    let entry: any = null;
    // 文档抽取试验（docMode）：分两层匹配——
    //   表格列(data-col-key) = 静态字段 → 查 fields(字段词典)
    //   搜索框/按钮(data-spec 或 按中文名) = 交互控件 → 查 controls(交互规则)
    if ((ctx as any).docMode) {
      const controls = (ctx as any).controls || {}; // 搜索项（交互规则）
      const actions = (ctx as any).actions || {}; // 列交互/按钮（交互规则）
      const fields = (ctx as any).fields || {}; // 静态展示列（字段词典）
      const colAlias = (ctx as any).alias || null; // 列/单元格：页面列 key → 词典/文档 key
      const searchAlias = (ctx as any).searchAlias || null; // 搜索：搜索 path → controls key
      const actionAlias = (ctx as any).actionAlias || null; // 单元格跳转：列 key → actions key
      const toCol = (k: string) => (colAlias && colAlias[k]) || k;
      const toSearch = (k: string) => (searchAlias && searchAlias[k]) || k;

      const INTERACTIVE = 'a,button,.n-button,.n-switch,[role="button"]';
      // 交互性以「锚点宿主自身子树」为准（横版=整列 td；竖版=该展示子行），不看整格——
      // 竖版一个大格里含多个子行(会员ID链接/昵称/账号…)，若按整格判定会把静态子行误判成交互。
      const isInteractive = (host: HTMLElement | null) =>
        !!el.closest?.(INTERACTIVE) || !!host?.querySelector?.(INTERACTIVE);
      const inHeader = !!el.closest?.('.n-data-table-th, th');

      // 单元格解析（四类框架③④）：按「本单元格是否可点」分流——
      //   可点(交互态)=③跳转 → 交互规则 actions 优先（列 key/别名/action别名三路查），
      //     无 action 但列是会员ID/userId → 站点级会员ID链接兜底；再退 controls/fields。
      //   纯展示(静态态)=④静态 → 字段词典 fields 优先，再退 controls/actions。
      // 传入 rawKey(未别名的页面列 key)，内部再按用途选 fields 别名(toCol)/action 别名。
      // 用于 data-col-key(横版) 与 竖版 data-spec 子行——同一列两态(如谷歌绑定/未绑定)各归各层。
      const resolveCell = (rawKey: string, host: HTMLElement | null) => {
        const ak = toCol(rawKey); // 别名后 key（对齐字段词典/交互规则搜索项）
        const aak = (actionAlias && actionAlias[rawKey]) || null; // 单元格跳转专用 action 别名
        const asAction =
          ciLookup(actions, rawKey) ||
          ciLookup(actions, ak) ||
          (aak ? ciLookup(actions, aak) : null);
        if (isInteractive(host)) {
          if (asAction) return asAction;
          if (
            MEMBER_ID_LINK_KEYS.has(rawKey.toLowerCase()) ||
            MEMBER_ID_LINK_KEYS.has(ak.toLowerCase())
          )
            return GENERIC_MEMBER_ID_LINK;
          return (
            ciLookup(controls, ak) ||
            ciLookup(controls, rawKey) ||
            ciLookup(fields, ak) ||
            ciLookup(fields, rawKey)
          );
        }
        // 纯展示单元格=④静态：只查字段词典 fields；查不到即「未收录」，绝不回落 controls/actions
        //（静态展示列不该显示搜索控件规范或动作逻辑）。
        return ciLookup(fields, ak) || ciLookup(fields, rawKey);
      };

      // 是否「带 key 的表格单元格」(data-col-key 或 td 内 data-spec 子行)——
      // 这类单元格若按 key 查不到规范，直接判「未收录」，不再按中文名兜底
      //（避免静态展示列误命中同名搜索控件 controls）。
      let cellKeyed = false;

      // ① 表格单元格：data-col-key（横版扁平列，经 withColKeys 注入）
      const colHost = el.closest?.('[data-col-key]') as HTMLElement | null;
      const colKey = colHost ? colHost.getAttribute('data-col-key') || '' : '';
      if (colKey) {
        key = colKey;
        cellKeyed = true;
        entry = resolveCell(colKey, colHost);
      }

      // ② data-spec 宿主：在表格单元格内(竖版展示子行)→当「单元格」解析(列别名+交互性)；
      //    否则是搜索框/工具栏控件→当「搜索控件」解析(搜索别名，controls 优先)。
      if (!entry) {
        const dsHost = el.closest?.('[data-spec]') as HTMLElement | null;
        const dsKey = dsHost ? dsHost.getAttribute('data-spec') || '' : '';
        if (dsKey) {
          key = dsKey;
          const inCell = !!dsHost?.closest?.('td, .n-data-table-td');
          if (inCell) cellKeyed = true;
          entry = inCell
            ? resolveCell(dsKey, dsHost)
            : ciLookup(controls, toSearch(dsKey)) ||
              ciLookup(actions, toSearch(dsKey)) ||
              ciLookup(fields, toSearch(dsKey));
        }
      }

      // ③ 无 key：按中文名兜底。表头(静态名词)→字段词典(fields)优先；
      //    搜索框/工具栏按钮→交互规则(controls/actions)优先。
      //    带 key 的表格单元格(cellKeyed)不走名兜底——查不到即未收录，防静态列误命中同名控件。
      if (!entry && !cellKeyed) {
        const label = findLabel(el);
        if (label)
          entry = inHeader
            ? nameLookup(fields, label) || nameLookup(actions, label) || nameLookup(controls, label)
            : nameLookup(controls, label) ||
              nameLookup(actions, label) ||
              nameLookup(fields, label);
      }
      if (!entry) {
        const gc = genericContainer(el); // 框架通用区域(快捷时间/翻页/列设置)兜底
        if (gc) {
          fillEntry(gc, '');
          return;
        }
        specHit.value = false;
        if (key) {
          specMiss.value = true;
          sMissKey.value = key;
        }
        return;
      }
      fillEntry(entry, key);
      return;
    }
    // 先按 key 匹配：表格 data-col-key / 手动 data-spec。
    // 列表/详情表按英文字段名(经 alias)命中；弹窗表按中文控件名命中——两者都是「按表键 ciLookup」，故统一处理。
    const host = el.closest?.('[data-col-key],[data-spec]') as HTMLElement | null;
    key = host ? host.getAttribute('data-col-key') || host.getAttribute('data-spec') || '' : '';
    if (key && ctx.alias && ctx.alias[key]) key = ctx.alias[key];
    entry = key ? ciLookup(ctx.table, key) : null;
    if (!entry) {
      // 兜底/详情：按标签中文名匹配；详情展示项(.detail-cell)优先取静态字段
      const inDetail = !!el.closest?.('.detail-cell, .detail-sections');
      const label = findLabel(el);
      if (label) entry = nameLookup(ctx.table, label, inDetail);
    }
    if (!entry) {
      const gc = genericContainer(el); // 框架通用区域(快捷时间/翻页/列设置)兜底
      if (gc) {
        fillEntry(gc, '');
        return;
      }
      specHit.value = false;
      // docMode 页面：命中了控件宿主 key 但两文档没这条 → 提示「文档未收录」
      if ((ctx as any).docMode && key) {
        specMiss.value = true;
        sMissKey.value = key;
      }
      return;
    }
    fillEntry(entry, key);
  }

  // 把命中的规范条目填进面板字段（docMode 与常规共用）
  function fillEntry(entry: any, key: string) {
    key = key || entry.field || '';
    specHit.value = true;
    sField.value = entry.field || key;
    sName.value = entry.name || '';
    sType.value = entry.type || 'input';
    sDef.value = entry.fieldDef || '';
    sIntro.value = entry.intro || '';
    sSpec.value = entry.spec || '';
    sLogic.value = entry.logic || '';
    sBoundary.value = entry.boundary || '';
    sToast.value = entry.toast || '';
    sCheckEnum.value = entry.checkEnum || '';
    sAuthored.value = !!entry.authored;
  }

  // 面板跟随光标 + 靠边翻转，避免超出视口
  const panelStyle = computed(() => {
    const offset = 18;
    const pw = 380;
    const ph = specHit.value ? 420 : specMiss.value ? 160 : 120;
    const vw = window.innerWidth;
    const vh = window.innerHeight;
    let left = x.value + offset;
    let top = y.value + offset;
    if (left + pw > vw) left = x.value - pw - offset;
    if (top + ph > vh) top = y.value - ph - offset;
    return { left: Math.max(4, left) + 'px', top: Math.max(4, top) + 'px' };
  });

  function describe(el: Element | null): string {
    if (!el || !(el as HTMLElement).tagName) return '';
    const tag = el.tagName.toLowerCase();
    const id = (el as HTMLElement).id ? `#${(el as HTMLElement).id}` : '';
    let cls = '';
    const cn = el.getAttribute('class');
    if (cn && cn.trim()) {
      cls = '.' + cn.trim().split(/\s+/).slice(0, 3).join('.');
    }
    return `${tag}${id}${cls}`;
  }

  function textOf(el: Element | null): string {
    if (!el) return '';
    const t = (el.textContent || '').replace(/\s+/g, ' ').trim();
    if (!t) return '';
    return t.length > 40 ? t.slice(0, 40) + '…' : t;
  }

  function pathOf(el: Element | null): string {
    const parts: string[] = [];
    let cur: Element | null = el;
    for (let i = 0; i < 4 && cur && cur.tagName && cur.tagName !== 'BODY'; i++) {
      parts.unshift(describe(cur));
      cur = cur.parentElement;
    }
    return parts.join(' > ');
  }

  function elementAt(px: number, py: number): Element | null {
    // 浮层自身 pointer-events:none，elementFromPoint 直接命中页面真实元素
    return document.elementFromPoint(px, py);
  }

  function onMove(e: MouseEvent) {
    if (!active.value || badgeDragging.value) return; // 拖 badge 时不跟随光标
    x.value = e.clientX;
    y.value = e.clientY;
    const el = elementAt(e.clientX, e.clientY);
    elDesc.value = describe(el);
    elText.value = textOf(el);
    elPath.value = pathOf(el);
    resolveSpec(el);
  }

  async function copyText(txt: string) {
    try {
      await navigator.clipboard.writeText(txt);
    } catch {
      // 兜底：execCommand
      const ta = document.createElement('textarea');
      ta.value = txt;
      ta.style.position = 'fixed';
      ta.style.opacity = '0';
      document.body.appendChild(ta);
      ta.select();
      try {
        document.execCommand('copy');
      } catch {
        /* ignore */
      }
      document.body.removeChild(ta);
    }
  }

  function onContextMenu(e: MouseEvent) {
    if (!active.value) return;
    // 右键=复制定位信息，并屏蔽浏览器右键菜单；左键不拦截，页面正常点击
    e.preventDefault();
    e.stopPropagation();
    const el = elementAt(e.clientX, e.clientY);
    resolveSpec(el); // 以点击处为准刷新规范
    const desc = describe(el);
    const text = textOf(el);
    let str =
      `[定位] 坐标(${e.clientX},${e.clientY})\n` +
      `元素: ${desc}${text ? ` "${text}"` : ''}\n` +
      `路径: ${pathOf(el)}`;
    if (specHit.value) {
      str += `\n—— 规范 ——`;
      if (sName.value) str += `\n控件名称: ${sName.value}`;
      str += `\n字段: ${sField.value}`;
      if (sDef.value) str += `\n定义: ${sDef.value}`;
      // 控件介绍已从面板移除（静态列表字段只保留字段/定义），复制内容与面板保持一致，不再带介绍
      if (sSpec.value) str += `\n控件规范: ${sSpec.value}`;
      if (sLogic.value) str += `\n控件逻辑: ${sLogic.value}`;
      if (sBoundary.value) str += `\n边界情况: ${sBoundary.value}`;
    }
    copyText(str);
    flash.value = true;
    if (flashTimer) clearTimeout(flashTimer);
    flashTimer = setTimeout(() => (flash.value = false), 1200);
  }

  function setActive(v: boolean) {
    active.value = v;
    document.body.style.cursor = v ? 'crosshair' : '';
    if (v) {
      window.addEventListener('mousemove', onMove, true);
      window.addEventListener('contextmenu', onContextMenu, true);
    } else {
      window.removeEventListener('mousemove', onMove, true);
      window.removeEventListener('contextmenu', onContextMenu, true);
    }
  }

  function onKey(e: KeyboardEvent) {
    // 开/关：Mac = Cmd+Shift+X；Windows = Alt+Shift+X
    if ((e.metaKey || e.altKey) && e.shiftKey && e.code === 'KeyX') {
      e.preventDefault();
      setActive(!active.value);
    }
  }

  onMounted(() => {
    window.addEventListener('keydown', onKey, true);
    setActive(false); // 悬停坐标默认关闭：仅注册开关快捷键；⌘/Alt+Shift+X 开启后才挂监听 + 十字光标
  });

  onBeforeUnmount(() => {
    window.removeEventListener('keydown', onKey, true);
    window.removeEventListener('mousemove', onBadgeMove, true);
    window.removeEventListener('mouseup', onBadgeUp, true);
    setActive(false);
    if (flashTimer) clearTimeout(flashTimer);
  });
</script>

<style scoped>
  .devloc {
    position: fixed;
    inset: 0;
    z-index: 2147483000;
    pointer-events: none; /* 关键：不拦截，elementFromPoint 命中页面元素 */
  }
  .devloc__vline,
  .devloc__hline {
    position: fixed;
    background: rgba(255, 45, 85, 0.8);
    pointer-events: none;
  }
  .devloc__vline {
    top: 0;
    bottom: 0;
    width: 1px;
  }
  .devloc__hline {
    left: 0;
    right: 0;
    height: 1px;
  }
  .devloc__panel {
    position: fixed;
    min-width: 180px;
    max-width: 380px;
    max-height: 66vh;
    overflow: hidden;
    padding: 8px 10px;
    background: rgba(17, 24, 39, 0.94);
    color: #f9fafb;
    border: 1px solid rgba(255, 45, 85, 0.6);
    border-radius: 8px;
    font-size: 12px;
    line-height: 1.5;
    font-family: 'SF Mono', Menlo, Consolas, monospace;
    box-shadow: 0 6px 20px rgba(0, 0, 0, 0.35);
    pointer-events: none;
  }
  .devloc__coord {
    color: #ff9fb1;
    font-weight: 700;
  }
  .devloc__el {
    color: #7ee787;
    word-break: break-all;
    margin-top: 2px;
  }
  .devloc__text {
    color: #ffd479;
    word-break: break-all;
  }
  .devloc__path {
    color: #9aa4b2;
    word-break: break-all;
    margin-top: 2px;
    font-size: 11px;
  }
  .devloc__spec {
    margin-top: 6px;
    padding-top: 6px;
    border-top: 1px dashed rgba(255, 255, 255, 0.18);
  }
  .devloc__spec-row {
    color: #cdd6e2;
    margin-top: 3px;
    line-height: 1.45;
    word-break: break-word;
    display: -webkit-box;
    -webkit-line-clamp: 4;
    -webkit-box-orient: vertical;
    overflow: hidden;
  }
  .devloc__spec-row b {
    display: inline-block;
    min-width: 52px;
    margin-right: 6px;
    color: #ff9fb1;
    font-weight: 700;
  }
  .devloc__tip {
    color: #6b7280;
    margin-top: 4px;
    font-size: 10.5px;
  }
  .devloc__badge {
    position: fixed;
    /* 默认底部居中；可拖动到任意位置（拖动后由内联 style 覆盖为 left/top）*/
    bottom: 10px;
    left: 50%;
    transform: translateX(-50%);
    padding: 4px 12px;
    background: rgba(255, 45, 85, 0.82);
    color: #fff;
    font-size: 11.5px;
    font-weight: 600;
    border-radius: 999px;
    /* 可拖动：需接收鼠标事件 */
    pointer-events: auto;
    cursor: move;
    user-select: none;
    opacity: 0.9;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
  }
  .devloc__flash {
    position: fixed;
    bottom: 24px;
    left: 50%;
    transform: translateX(-50%);
    padding: 8px 18px;
    background: rgba(16, 160, 88, 0.95);
    color: #fff;
    font-size: 13px;
    font-weight: 600;
    border-radius: 8px;
    pointer-events: none;
    box-shadow: 0 6px 18px rgba(0, 0, 0, 0.35);
  }
</style>
