<template>
  <div class="file-upload">
    <!-- 已上传文件展示 -->
    <div v-if="fileUrl" class="file-upload__file">
      <n-tag type="success" closable @close="handleRemove">
        <template #icon>
          <n-icon><FileOutlined /></n-icon>
        </template>
        <a :href="fileUrl" target="_blank" class="file-upload__link">
          {{ fileName }}
        </a>
      </n-tag>
      <span v-if="fileSizeText" class="file-upload__size">{{ fileSizeText }}</span>
    </div>

    <!-- 上传按钮 -->
    <n-spin v-else :show="uploading" size="small">
      <n-upload
        :accept="acceptTypes"
        :max="1"
        :custom-request="handleUpload"
        :disabled="disabled || uploading"
        :show-file-list="false"
      >
        <slot>
          <n-button :loading="uploading" :disabled="disabled || uploading">
            <template #icon>
              <n-icon><UploadOutlined /></n-icon>
            </template>
            {{ buttonText || t('common.upload.upload') }}
          </n-button>
        </slot>
      </n-upload>
    </n-spin>

    <!-- 提示文本 -->
    <div v-if="helpText && !fileUrl" class="file-upload__help">
      {{ helpText }}
    </div>
  </div>
</template>

<script lang="ts" setup>
  import { ref, computed, watch } from 'vue';
  import { useMessage, type UploadCustomRequestOptions } from 'naive-ui';
  import { FileOutlined, UploadOutlined } from '@vicons/antd';
  import { useI18n } from 'vue-i18n';
  import SparkMD5 from 'spark-md5';
  defineOptions({
    name: 'FileUpload',
  });

  const props = withDefaults(
    defineProps<{
      /** 文件 URL */
      value?: string;
      /** 接受的文件类型，如 'apk,ipa' */
      accept?: string;
      /** 最大文件大小 (KB) */
      maxSize?: number;
      /** 目录类型: 1=common, 2=apk, 3=skin, 4=icon, 5=appPackage, 6=banner */
      fileType?: number;
      /** 是否禁用 */
      disabled?: boolean;
      /** 按钮文字 */
      buttonText?: string;
      /** 帮助文本 */
      helpText?: string;
    }>(),
    {
      value: '',
      accept: '',
      maxSize: 204800, // 200MB
      fileType: 1,
      disabled: false,
      buttonText: '',
      helpText: '',
    },
  );

  const emit = defineEmits<{
    (e: 'update:value', value: string): void;
    (e: 'change', info: { url: string; fileSize: number; md5: string }): void;
  }>();

  const { t } = useI18n();
  const message = useMessage();

  const uploading = ref(false);
  const fileUrl = ref('');
  const fileSize = ref<number>(0);
  const fileMd5 = ref('');

  // Computed
  const acceptTypes = computed(() => {
    if (!props.accept) return undefined;
    return props.accept
      .split(',')
      .map((ext) => `.${ext.trim()}`)
      .join(',');
  });

  const fileName = computed(() => {
    if (!fileUrl.value) return '';
    return fileUrl.value.split('/').pop() || '';
  });

  const fileSizeText = computed(() => {
    if (!fileSize.value) return '';
    const kb = fileSize.value / 1024;
    if (kb >= 1024) {
      return `${(kb / 1024).toFixed(2)} MB`;
    }
    return `${kb.toFixed(2)} KB`;
  });

  // Calculate MD5 hash of file (32-char hex)
  async function calculateMD5(file: File): Promise<string> {
    const buffer = await file.arrayBuffer();
    return SparkMD5.ArrayBuffer.hash(buffer);
  }

  // 原型阶段：本地 blob URL 模拟上传，无真实接口
  async function uploadToHubOSS(
    file: File,
    _folder: number,
  ): Promise<{ url: string; filename?: string; size?: number; mimeType?: string }> {
    const url = URL.createObjectURL(file);
    return { url, filename: file.name, size: file.size, mimeType: file.type };
  }

  // Methods
  async function handleUpload({ file, onFinish, onError }: UploadCustomRequestOptions) {
    const uploadFile = file.file as File;

    // Validate file size
    if (props.maxSize && uploadFile.size / 1024 > props.maxSize) {
      const maxSizeMB = (props.maxSize / 1024).toFixed(0);
      message.error(t('common.upload.fileMaxSizeError', { size: `${maxSizeMB} MB` }));
      onError();
      return;
    }

    uploading.value = true;
    try {
      // Calculate MD5 and upload in parallel
      const folder = props.fileType || 1;
      const [md5Hash, result] = await Promise.all([
        calculateMD5(uploadFile),
        uploadToHubOSS(uploadFile, folder),
      ]);

      fileUrl.value = result.url;
      fileSize.value = result.size || uploadFile.size;
      fileMd5.value = md5Hash;
      emit('update:value', result.url);
      emit('change', { url: result.url, fileSize: result.size || uploadFile.size, md5: md5Hash });
      message.success(t('common.upload.uploadSuccess'));
      onFinish();
    } catch (error) {
      console.error('Upload error:', error);
      message.error(t('common.upload.uploadError'));
      onError();
    } finally {
      uploading.value = false;
    }
  }

  function handleRemove() {
    fileUrl.value = '';
    fileSize.value = 0;
    fileMd5.value = '';
    emit('update:value', '');
    emit('change', { url: '', fileSize: 0, md5: '' });
  }

  // Watch props.value
  watch(
    () => props.value,
    (newVal) => {
      fileUrl.value = newVal || '';
    },
    { immediate: true },
  );

  // Expose
  defineExpose({
    clear: handleRemove,
  });
</script>

<style lang="less" scoped>
  .file-upload {
    &__file {
      display: flex;
      align-items: center;
      gap: 8px;
    }

    &__link {
      color: inherit;
      text-decoration: none;
      max-width: 300px;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
      display: inline-block;

      &:hover {
        text-decoration: underline;
      }
    }

    &__size {
      color: #999;
      font-size: 12px;
    }

    &__help {
      margin-top: 4px;
      color: #999;
      font-size: 12px;
    }
  }
</style>
