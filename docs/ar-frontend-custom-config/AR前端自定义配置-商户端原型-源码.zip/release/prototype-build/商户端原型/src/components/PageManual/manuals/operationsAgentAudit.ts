// 代理审核机制（商户端 tenant · operations_agentAudit）功能说明书。
// 锚定 src/views/operations/agentAudit/index.vue + AgentRebateFormModal.vue + data.ts 真实控件（R53 实证、不臆造）。

import type { PageManual } from '../types';

const manual: PageManual = {
  route: 'operations_agentAudit',
  title: '代理审核机制',
  overview:
    '商户端「运营管理 › 代理审核机制」页，管理代理的返佣配置与返佣状态（启用/关闭配置）。' +
    '"启用配置/关闭配置"这个原本独立的操作已合并进"修改返佣"弹窗内的开关，不再单独出按钮。' +
    '2026-07-22核实代码发现：新增/编辑保存(saveAgentRebate)与状态切换(toggleAgentRebateState)均只返回成功、' +
    '不真正写回底层数组，操作提示成功但列表刷新后费率/状态看不到变化。如实记录，未修复。',
  items: [
    {
      anchor: 'merchant',
      name: '商户',
      group: '搜索',
      interaction: '下拉单选，红星必填；未选点查询红框+红字提示。',
      limit: '单选必填（R63）。',
    },
    {
      anchor: 'agentId',
      name: '代理ID',
      group: '搜索',
      interaction: '文本框，仅允许数字输入，可清空。',
    },
    {
      anchor: 'agentType',
      name: '代理类型',
      group: '搜索',
      interaction: '下拉单选，不可清空（恒有值，默认"全部"）；选项：全部/外部代理/内部代理。',
    },
    {
      anchor: 'rebateState',
      name: '返佣状态',
      group: '搜索',
      interaction: '下拉单选，不可清空（恒有值，默认"全部"）；选项：全部/已启用/已关闭。',
    },
    {
      anchor: 'minDays',
      name: '下级0首充天数(最小)',
      group: '搜索',
      interaction: '数字输入框，最小值0，可清空。',
    },
    {
      anchor: 'maxDays',
      name: '下级0首充天数(最大)',
      group: '搜索',
      interaction: '数字输入框，最小值0，可清空。',
    },
    {
      anchor: 'reset',
      name: '重置',
      group: '搜索',
      interaction: 'ProCrudTable内置重置按钮。',
    },
    {
      anchor: 'col_agentId',
      name: '代理ID（列，可点击）',
      group: '列',
      interaction: '蓝字可点。',
      logic: '点击打开全站共用「会员详情」弹窗。',
    },
    {
      anchor: 'act_editRebate',
      name: '修改返佣',
      group: '操作',
      interaction: '每行常驻，主色按钮，点击打开修改返佣弹窗（440px宽）。',
      logic:
        '弹窗字段：配置状态(开关，即原"启用/关闭配置"，已合并至此) → 彩票/电子/真人/体育/棋牌 五类返佣率' +
        '(各自数字输入，百分比，最小0，步进0.01) → 备注(多行文本)。保存时若配置状态有变更，会额外调用' +
        '状态切换接口同步。',
    },
  ],
  fields: [
    { name: '商户（列）', def: '该代理所属商户，标签展示。' },
    { name: '代理ID', def: '代理唯一编号，可点击进详情，见交互条目 col_agentId。' },
    { name: '上级ID', def: '该代理的上级代理编号。' },
    { name: '直属下级', def: '该代理直接下级会员数量。' },
    { name: '代理类型', def: '外部代理(蓝)/内部代理(橙)。' },
    { name: '下级0首充天数', def: '该代理下级会员从注册到首次充值的天数（0=当天首充）。' },
    { name: '返佣状态', def: '已启用(绿)/已关闭(灰)。' },
    { name: '昨日佣金', def: '该代理昨日产生的佣金金额。' },
    { name: '下级总投注', def: '该代理全部下级会员的累计投注金额。' },
    { name: '返佣最后操作人', def: '最近一次修改该代理返佣费率的操作人账号。' },
    { name: '返佣操作时间', def: '最近一次修改返佣费率的时间。' },
    { name: '状态最后操作人', def: '最近一次修改该代理返佣状态(启用/关闭)的操作人账号。' },
    { name: '状态操作时间', def: '最近一次修改返佣状态的时间。' },
  ],
};

export default manual;
