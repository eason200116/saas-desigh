export { default as BasicUpload } from './src/BasicUpload.vue';
export { default as FileUpload } from './src/FileUpload.vue';
export { default as UploadLotto } from './src/UploadLotto.vue';
export type {
  BasicUploadProps,
  BasicUploadInstance,
  ImageDimensions,
  ImageInfo,
  UploadResult,
} from './src/types';
export { DEFAULT_ACCEPT, DEFAULT_MAX_SIZE, DEFAULT_SIZE, ACCEPT_PRESETS } from './src/types';
