<template>
  <button
    v-if="visible && !open"
    class="pm-handle"
    type="button"
    :aria-label="tr('common.manual.title', '功能说明书')"
    :title="tr('common.manual.tooltip', '查看本页功能说明')"
    @click="open = true"
  >
    <n-icon :component="BookOutline" :size="16" />
  </button>

  <n-drawer
    class="page-manual-drawer"
    :show="open && visible"
    resizable
    :default-width="560"
    :min-width="400"
    :max-width="760"
    placement="right"
    :trap-focus="false"
    :show-mask="false"
    :mask-closable="false"
    to="body"
    @update:show="handleDrawerShow"
  >
    <n-drawer-content
      closable
      :native-scrollbar="false"
      :title="tr('common.manual.title', '功能说明书')"
      body-content-style="padding: 0;"
    >
      <div ref="bodyEl" class="pm-body">
        <template v-if="manual">
          <section class="pm-summary">
            <h2>{{ manual.title }}</h2>
            <p>{{ manual.overview }}</p>
          </section>

          <n-tabs
            v-model:value="tab"
            class="pm-tabs"
            type="line"
            :animated="false"
            :tabs-padding="16"
            pane-class="pm-tab-pane"
          >
            <n-tab-pane
              v-if="featureCards.length"
              name="guide"
              :tab="tr('common.manual.tab.guide', '操作说明')"
              display-directive="show:lazy"
            >
              <p class="pm-tab-intro">
                {{
                  tr('common.manual.guideHint', '按功能点展开查看操作步骤、完成结果与异常处理。')
                }}
              </p>
              <n-collapse v-model:expanded-names="expandedFeatures" arrow-placement="right">
                <n-collapse-item
                  v-for="feature in featureCards"
                  :key="feature.id"
                  :name="feature.id"
                  :title="feature.title"
                >
                  <div class="pm-guide-details">
                    <section
                      v-for="detail in feature.details"
                      :key="detail.key"
                      class="pm-guide-detail"
                    >
                      <h3>{{ sectionLabel(detail.key) }}</h3>
                      <p>{{ detail.content }}</p>
                    </section>
                  </div>
                </n-collapse-item>
              </n-collapse>
            </n-tab-pane>

            <n-tab-pane
              name="interaction"
              :tab="tr('common.manual.tab.interaction', '交互说明')"
              display-directive="show:lazy"
            >
              <template v-for="group in groups" :key="group.name">
                <section v-if="group.items.length" class="pm-group">
                  <h3 class="pm-group-title">{{ group.label }}</h3>
                  <article
                    v-for="item in group.items"
                    :key="item.anchor"
                    class="pm-item"
                    :class="{ 'is-active': activeAnchor === item.anchor }"
                    :data-anchor="item.anchor"
                  >
                    <h4>{{ item.name }}</h4>
                    <dl>
                      <template v-if="item.interaction">
                        <dt>{{ tr('common.manual.dim.interaction', '交互') }}</dt>
                        <dd>{{ item.interaction }}</dd>
                      </template>
                      <template v-if="item.dataSource">
                        <dt>{{ tr('common.manual.dim.dataSource', '数据来源') }}</dt>
                        <dd>{{ item.dataSource }}</dd>
                      </template>
                      <template v-if="item.logic">
                        <dt>{{ tr('common.manual.dim.logic', '处理逻辑') }}</dt>
                        <dd>{{ item.logic }}</dd>
                      </template>
                      <template v-if="item.limit">
                        <dt>{{ tr('common.manual.dim.limit', '输入限制') }}</dt>
                        <dd>{{ item.limit }}</dd>
                      </template>
                      <template v-if="item.edge">
                        <dt>{{ tr('common.manual.dim.edge', '异常与边界') }}</dt>
                        <dd>{{ item.edge }}</dd>
                      </template>
                      <template v-if="item.note">
                        <dt>{{ tr('common.manual.dim.note', '补充') }}</dt>
                        <dd>{{ item.note }}</dd>
                      </template>
                    </dl>
                  </article>
                </section>
              </template>
              <n-empty
                v-if="!manual.items.length"
                size="small"
                :description="tr('common.manual.itemsEmpty', '本页暂无交互说明')"
              />
            </n-tab-pane>

            <n-tab-pane
              name="fields"
              :tab="tr('common.manual.tab.fields', '字段说明')"
              display-directive="show:lazy"
            >
              <div v-if="fields.length" class="pm-fields">
                <article v-for="field in fields" :key="field.name" class="pm-field">
                  <h4>{{ field.name }}</h4>
                  <p>{{ field.def }}</p>
                </article>
              </div>
              <n-empty
                v-else
                size="small"
                :description="tr('common.manual.fieldsEmpty', '暂无字段说明')"
              />
            </n-tab-pane>
          </n-tabs>
        </template>

        <n-empty
          v-else
          class="pm-page-empty"
          :description="tr('common.manual.pageEmpty', '本页说明书待补充')"
        />
      </div>

      <template #footer>
        <span class="pm-footer">
          {{ tr('common.manual.hint', '点击页面控件，可自动定位到对应交互说明。') }}
        </span>
      </template>
    </n-drawer-content>
  </n-drawer>
</template>

<script lang="ts" setup>
  import { computed, nextTick, onBeforeUnmount, onMounted, ref, watch } from 'vue';
  import {
    NCollapse,
    NCollapseItem,
    NDrawer,
    NDrawerContent,
    NEmpty,
    NIcon,
    NTabPane,
    NTabs,
  } from 'naive-ui';
  import { BookOutline } from '@vicons/ionicons5';
  import { useRoute } from 'vue-router';
  import { useI18n } from 'vue-i18n';
  import { getManual } from './manuals/_registry';
  import type { ManualItem, ManualSectionKey } from './types';

  defineOptions({ name: 'PageManual' });

  const { t, te, locale } = useI18n();
  const route = useRoute();

  const HIDE_ON_PATHS = ['/login', '/redirect'];
  const visible = computed(
    () => !HIDE_ON_PATHS.some((path) => (route.path || '').startsWith(path)),
  );
  const open = ref(false);

  function tr(key: string, fallback: string) {
    if (!te(key)) return fallback;
    const value = String(t(key) || '');
    return !value || value === key || value.includes('common.manual.') ? fallback : value;
  }

  function handleDrawerShow(show: boolean) {
    open.value = show;
    if (!show) activeAnchor.value = null;
  }

  const routeContext = computed(() => {
    const raw = route.query.tab;
    return Array.isArray(raw) ? raw[0] : raw;
  });
  const manual = computed(() =>
    getManual(route.name as string | undefined, locale.value, routeContext.value),
  );

  const GROUP_ORDER: NonNullable<ManualItem['group']>[] = ['搜索', '列', '操作', '其它'];
  const GROUP_KEY: Record<NonNullable<ManualItem['group']>, string> = {
    搜索: 'search',
    列: 'columns',
    操作: 'actions',
    其它: 'other',
  };
  const GROUP_FALLBACK: Record<NonNullable<ManualItem['group']>, string> = {
    搜索: '搜索',
    列: '列表字段',
    操作: '操作',
    其它: '页面区块',
  };
  const groups = computed(() =>
    GROUP_ORDER.map((name) => ({
      name,
      label: tr('common.manual.group.' + GROUP_KEY[name], GROUP_FALLBACK[name]),
      items: (manual.value?.items ?? []).filter((item) => (item.group ?? '其它') === name),
    })),
  );

  const SECTION_ORDER: ManualSectionKey[] = [
    'purpose',
    'prerequisites',
    'areas',
    'workflow',
    'permissions',
    'effects',
    'unavailable',
    'recovery',
  ];
  const SECTION_FALLBACK: Record<ManualSectionKey, string> = {
    purpose: '功能用途',
    prerequisites: '使用前提',
    areas: '页面位置与状态',
    workflow: '操作步骤',
    permissions: '权限要求',
    effects: '完成结果',
    unavailable: '不可操作条件',
    recovery: '异常处理',
  };
  function sectionLabel(key: ManualSectionKey) {
    return tr('common.manual.section.' + key, SECTION_FALLBACK[key]);
  }

  const featureCards = computed(() => {
    const featurePoints = manual.value?.featurePoints ?? [];
    if (featurePoints.length) {
      return featurePoints
        .map((feature, index) => ({
          id: 'feature-' + index,
          title: feature.title,
          details: SECTION_ORDER.flatMap((key) => {
            const content = feature.details[key]?.trim();
            return content ? [{ key, content }] : [];
          }),
        }))
        .filter((feature) => feature.details.length);
    }
    return (manual.value?.sections ?? [])
      .filter((section) => section.content.trim())
      .map((section, index) => ({
        id: 'legacy-section-' + index,
        title: sectionLabel(section.key),
        details: [{ key: section.key, content: section.content }],
      }));
  });

  const tab = ref<'guide' | 'interaction' | 'fields'>('interaction');
  const expandedFeatures = ref<Array<string | number>>([]);
  const fields = computed(() => manual.value?.fields ?? []);
  const bodyEl = ref<HTMLElement | null>(null);
  const activeAnchor = ref<string | null>(null);
  const targetBindings = new Map<HTMLElement, EventListener>();

  watch(
    () => String(route.name ?? '') + ':' + String(routeContext.value ?? ''),
    () => {
      tab.value = featureCards.value.length ? 'guide' : 'interaction';
      expandedFeatures.value = featureCards.value.length ? [featureCards.value[0].id] : [];
      activeAnchor.value = null;
    },
    { immediate: true },
  );

  function activate(key: string) {
    if (!visible.value) return;
    const hit = (manual.value?.items ?? []).some((item) => item.anchor === key);
    if (!hit) return;
    tab.value = 'interaction';
    activeAnchor.value = key;
    nextTick(() => {
      const selector = '[data-anchor="' + CSS.escape(key) + '"]';
      bodyEl.value?.querySelector<HTMLElement>(selector)?.scrollIntoView({
        block: 'center',
        behavior: 'smooth',
      });
    });
  }

  function onDocInteract(event: Event) {
    const pathElement = event
      .composedPath()
      .find((node): node is HTMLElement => node instanceof HTMLElement);
    const element = pathElement ?? (event.target as HTMLElement | null);
    if (element?.closest?.('.page-manual-drawer, .pm-handle')) return;
    const key = element?.closest?.('[data-manual]')?.getAttribute('data-manual');
    if (key) activate(key);
    else if (activeAnchor.value) activeAnchor.value = null;
  }

  function onFocusEvent(event: Event) {
    const key = (event as CustomEvent<string>).detail;
    if (typeof key === 'string') activate(key);
  }

  function bindManualTargets() {
    document.querySelectorAll<HTMLElement>('[data-manual]').forEach((element) => {
      if (element.closest('.page-manual-drawer') || targetBindings.has(element)) return;
      const handler: EventListener = () => {
        const key = element.getAttribute('data-manual');
        if (key) activate(key);
      };
      element.addEventListener('pointerdown', handler, true);
      element.addEventListener('focusin', handler, true);
      element.addEventListener('click', handler, true);
      targetBindings.set(element, handler);
    });
  }

  watch(open, (show) => {
    if (show) nextTick(bindManualTargets);
  });

  function onKeydown(event: KeyboardEvent) {
    if (event.key === 'Escape' && open.value && visible.value) open.value = false;
  }

  onMounted(() => {
    window.addEventListener('pointerdown', onDocInteract, true);
    window.addEventListener('focusin', onDocInteract, true);
    window.addEventListener('click', onDocInteract, true);
    document.addEventListener('keydown', onKeydown);
    window.addEventListener('page-manual:focus', onFocusEvent);
  });
  onBeforeUnmount(() => {
    window.removeEventListener('pointerdown', onDocInteract, true);
    window.removeEventListener('focusin', onDocInteract, true);
    window.removeEventListener('click', onDocInteract, true);
    document.removeEventListener('keydown', onKeydown);
    window.removeEventListener('page-manual:focus', onFocusEvent);
    targetBindings.forEach((handler, element) => {
      element.removeEventListener('pointerdown', handler, true);
      element.removeEventListener('focusin', handler, true);
      element.removeEventListener('click', handler, true);
    });
    targetBindings.clear();
  });
</script>

<style scoped>
  .pm-handle {
    position: fixed;
    top: 50%;
    right: 0;
    z-index: 8000;
    display: flex;
    width: 24px;
    height: 52px;
    align-items: center;
    justify-content: center;
    padding: 0;
    border: 0;
    border-radius: 10px 0 0 10px;
    color: #fff;
    background: #009688;
    box-shadow: -2px 0 10px rgb(0 0 0 / 18%);
    cursor: pointer;
    transform: translateY(-50%);
    transition:
      width 0.15s,
      background 0.15s;
  }
  .pm-handle:hover {
    width: 28px;
    background: #00796b;
  }
  .pm-body {
    min-height: 100%;
    padding-bottom: 8px;
    background: #f6f8fa;
  }
  .pm-summary {
    padding: 20px 20px 16px;
    border-bottom: 1px solid var(--n-border-color, #eef2f7);
    background: var(--n-color, #fff);
  }
  .pm-summary h2 {
    margin: 0;
    color: var(--n-title-text-color, #1f2328);
    font-size: 18px;
    line-height: 26px;
  }
  .pm-summary p,
  .pm-tab-intro,
  .pm-guide-detail p,
  .pm-field p {
    margin: 6px 0 0;
    color: var(--n-text-color, #4b5563);
    font-size: 13px;
    line-height: 1.7;
    white-space: pre-line;
    overflow-wrap: anywhere;
  }
  .pm-tabs :deep(.n-tabs-nav) {
    position: sticky;
    top: 0;
    z-index: 2;
    padding: 0 4px;
    border-bottom: 1px solid var(--n-border-color, #eef2f7);
    background: rgb(255 255 255 / 96%);
  }
  .pm-tabs :deep(.n-tabs-pane-wrapper) {
    padding: 16px 18px 24px;
  }
  .pm-tab-intro {
    margin: 0 0 12px;
    color: var(--n-tab-text-color, #64748b);
  }
  .pm-tabs :deep(.n-collapse) {
    display: grid;
    gap: 10px;
  }
  .pm-tabs :deep(.n-collapse-item) {
    overflow: hidden;
    margin: 0;
    border: 1px solid var(--n-border-color, #e5e7eb);
    border-radius: 8px;
    background: var(--n-color, #fff);
  }
  .pm-tabs :deep(.n-collapse-item__header) {
    min-height: 46px;
    padding: 0 14px;
  }
  .pm-tabs :deep(.n-collapse-item__content-inner) {
    padding: 0 14px 14px;
  }
  .pm-tabs :deep(.n-collapse-item__header-main) {
    color: var(--n-title-text-color, #1f2328);
    font-size: 14px;
    font-weight: 600;
  }
  .pm-guide-details {
    display: grid;
    gap: 10px;
    padding: 2px 0 0;
  }
  .pm-guide-detail {
    padding: 10px 12px;
    border-left: 3px solid var(--primary-color, #009688);
    border-radius: 0 6px 6px 0;
    background: #f8fafc;
  }
  .pm-guide-detail h3,
  .pm-group-title,
  .pm-item h4,
  .pm-field h4 {
    margin: 0;
    color: var(--n-title-text-color, #1f2328);
    font-size: 13px;
    font-weight: 600;
    line-height: 20px;
  }
  .pm-guide-detail h3 {
    color: var(--primary-color, #00796b);
  }
  .pm-group + .pm-group {
    margin-top: 16px;
  }
  .pm-group-title {
    margin-bottom: 10px;
    color: var(--n-tab-text-color, #64748b);
    font-size: 12px;
    letter-spacing: 0.04em;
  }
  .pm-item,
  .pm-field {
    position: relative;
    padding: 10px 12px;
    border: 1px solid var(--n-border-color, #e5e7eb);
    border-radius: 8px;
    background: var(--n-color, #fff);
    transition:
      border-color 0.2s,
      box-shadow 0.2s,
      background 0.2s;
  }
  .pm-item + .pm-item {
    margin-top: 8px;
  }
  .pm-item.is-active {
    border-color: var(--primary-color, #009688);
    background: rgb(0 150 136 / 8%);
    box-shadow: 0 0 0 2px rgb(0 150 136 / 18%);
  }
  .pm-item.is-active::before {
    position: absolute;
    top: 50%;
    left: -8px;
    color: var(--primary-color, #009688);
    content: '▶';
    font-size: 16px;
    line-height: 1;
    transform: translateY(-50%);
  }
  .pm-item dl {
    display: grid;
    grid-template-columns: max-content minmax(0, 1fr);
    gap: 4px 10px;
    margin: 6px 0 0;
    font-size: 12px;
    line-height: 1.65;
  }
  .pm-fields {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(210px, 1fr));
    gap: 10px;
  }
  .pm-field + .pm-field {
    margin-top: 0;
  }
  .pm-item dt {
    color: var(--primary-color, #00796b);
    font-weight: 500;
  }
  .pm-item dd {
    min-width: 0;
    margin: 0;
    color: var(--n-text-color, #4b5563);
    white-space: pre-line;
    overflow-wrap: anywhere;
  }
  .pm-fields {
    display: grid;
    gap: 8px;
  }
  .pm-field + .pm-field {
    margin-top: 0;
  }
  .pm-field p {
    margin-top: 4px;
    font-size: 12px;
  }
  .pm-page-empty {
    min-height: 320px;
    align-items: center;
    justify-content: center;
  }
  .pm-footer {
    color: var(--n-footer-text-color, #8c8c8c);
    font-size: 12px;
  }
  @media (max-width: 640px) {
    .pm-tabs :deep(.n-tabs-pane-wrapper) {
      padding-right: 12px;
      padding-left: 12px;
    }
  }
</style>
