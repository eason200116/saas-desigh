<template>
  <!-- TabBar 子项 - 可拖拽标签栏 -->
  <div v-if="items.length > 0" class="draggable-tabs">
    <div class="tabs-header">
      <VueDraggable
        :model-value="items"
        animation="300"
        item-key="_key"
        handle=".drag-handle"
        class="tabs-list"
        @update:model-value="handleItemsChange"
      >
        <div
          v-for="element in items"
          :key="element._key"
          class="tab-item-drag"
          :class="{ active: element._key === activeTab }"
          @click="activeTab = element._key"
        >
          <n-icon class="drag-handle" size="14"><MenuOutlined /></n-icon>
          <span class="tab-label">{{
            element.name?.zh || element.key || t('tenant.styleManage.newItem')
          }}</span>
          <n-icon
            v-if="items.length > 1"
            class="tab-close"
            size="14"
            @click.stop="handleCloseTab(element._key)"
          >
            <CloseOutlined />
          </n-icon>
        </div>
      </VueDraggable>
      <n-button v-if="items.length < maxItems" size="small" quaternary @click="handleAddItem">
        <template #icon>
          <n-icon><PlusCircleOutlined /></n-icon>
        </template>
      </n-button>
      <n-tooltip v-else>
        <template #trigger>
          <n-button size="small" quaternary disabled>
            <template #icon>
              <n-icon><PlusCircleOutlined /></n-icon>
            </template>
          </n-button>
        </template>
        {{ t('tenant.styleManage.itemsMaxError') }}
      </n-tooltip>
    </div>

    <!-- Tab 内容区域 -->
    <div
      v-for="item in items"
      v-show="item._key === activeTab"
      :key="item._key"
      class="tab-content"
    >
      <n-form :model="item" label-placement="top" :label-width="100" size="small">
        <n-grid :cols="24" :x-gap="24">
          <n-form-item-gi
            :span="12"
            :label="t('tenant.styleManage.itemKey')"
            path="key"
            :rule="{
              required: true,
              message: t('tenant.styleManage.itemKeyRequired'),
              trigger: ['blur', 'input'],
            }"
          >
            <n-input
              v-model:value="item.key"
              :placeholder="t('tenant.styleManage.itemKeyPlaceholder')"
            />
          </n-form-item-gi>
          <n-form-item-gi :span="12" :label="t('tenant.styleManage.itemVisible')">
            <n-switch v-model:value="item.visible" />
          </n-form-item-gi>
          <!-- 前台多语言名称 -->
          <n-form-item-gi :span="24" :show-label="false">
            <TranslateInput
              v-model="item.name"
              :field-label="t('tenant.styleManage.itemDisplayName')"
              :placeholder="t('tenant.styleManage.itemNameValuePlaceholder')"
              size="small"
              tag-width="56px"
              inline
              compact
            />
          </n-form-item-gi>

          <n-form-item-gi
            :span="8"
            :label="t('tenant.styleManage.itemType')"
            path="targetType"
            :rule="{
              required: true,
              message: t('tenant.styleManage.itemTypeRequired'),
              trigger: 'change',
            }"
          >
            <n-select
              v-model:value="item.targetType"
              :options="typeOptions"
              :placeholder="t('tenant.styleManage.itemTypePlaceholder')"
            />
          </n-form-item-gi>
          <n-form-item-gi
            :span="8"
            :label="t('tenant.styleManage.itemTarget')"
            path="target"
            :rule="{
              required: item.targetType === 'route',
              validator: (_rule: unknown, value: string) => {
                if (item.targetType !== 'route') return true;
                return value && value.trim()
                  ? true
                  : new Error(t('tenant.styleManage.itemTargetRequired'));
              },
              trigger: ['change', 'blur'],
            }"
          >
            <!-- 前端路由时显示下拉选择 -->
            <n-select
              v-if="item.targetType === 'route'"
              v-model:value="item.target"
              :options="routeTargetOptions"
              :placeholder="t('tenant.styleManage.itemTargetPlaceholder')"
            />
            <!-- 其他类型显示文本输入 -->
            <n-input
              v-else
              v-model:value="item.target"
              :placeholder="t('tenant.styleManage.itemTargetPlaceholder')"
            />
          </n-form-item-gi>
          <n-form-item-gi :span="8" :label="t('tenant.styleManage.itemSpecial')">
            <n-select
              v-model:value="item.special"
              :options="specialOptions"
              :placeholder="t('tenant.styleManage.itemSpecialPlaceholder')"
            />
          </n-form-item-gi>
        </n-grid>
        <n-grid :cols="24" :x-gap="24">
          <n-form-item-gi :span="12" :label="t('tenant.styleManage.itemIcon')">
            <BasicUpload
              :key="`${item._key}-icon`"
              :value="item.iconKey ? [item.iconKey] : []"
              :width="40"
              :height="40"
              :max-number="1"
              :custom-path="4"
              full-path
              compact
              @update:value="(val: string[]) => (item.iconKey = val[0] || '')"
            />
          </n-form-item-gi>
          <n-form-item-gi :span="12" :label="t('tenant.styleManage.itemIconActive')">
            <BasicUpload
              :key="`${item._key}-iconActive`"
              :value="item.iconActiveKey ? [item.iconActiveKey] : []"
              :width="40"
              :height="40"
              :max-number="1"
              :custom-path="4"
              full-path
              compact
              @update:value="(val: string[]) => (item.iconActiveKey = val[0] || '')"
            />
          </n-form-item-gi>
        </n-grid>
      </n-form>
    </div>
  </div>

  <!-- 无子项时的添加按钮 -->
  <div v-else class="py-8 text-center">
    <n-empty size="small" :description="t('tenant.styleManage.noItems')">
      <template #extra>
        <n-button size="small" type="primary" @click="handleAddItem">
          <template #icon>
            <n-icon><PlusCircleOutlined /></n-icon>
          </template>
          {{ t('tenant.styleManage.addTabbarItem') }}
        </n-button>
      </template>
    </n-empty>
  </div>
</template>

<script lang="ts" setup>
  import { ref, computed, watch, nextTick } from 'vue';
  import { useMessage } from 'naive-ui';
  import { PlusCircleOutlined, MenuOutlined, CloseOutlined } from '@vicons/antd';
  import { VueDraggableNext as VueDraggable } from 'vue-draggable-next';
  import { useI18n } from 'vue-i18n';
  import { TranslateInput, BasicUpload } from '@/components';

  /** 对齐 `CreateTabBarItemInputDto` 的字段名（`targetType`/`sortOrder`），避免提交前再做一次重命名 */
  export interface TabBarItem {
    _key: string;
    id?: number;
    name: Record<string, string>;
    key: string;
    targetType: 'route' | 'url' | 'game' | null;
    target: string;
    iconKey: string;
    iconActiveKey: string;
    special: number;
    sortOrder: number;
    visible: boolean;
  }

  // FrontStyle format (for designer)
  export interface FrontStyleTabBarItem {
    key: string;
    name: Record<string, string>;
    enabled: boolean;
    sort: number;
    iconKey: string;
    iconActiveKey: string;
    type: string;
    target: string;
    special: number;
  }

  const props = withDefaults(
    defineProps<{
      modelValue: TabBarItem[] | FrontStyleTabBarItem[];
      activeKey?: string;
      maxItems?: number;
      /** Use FrontStyle data format (key as _key, backendName as itemName, enabled as visible) */
      frontStyleMode?: boolean;
    }>(),
    {
      activeKey: undefined,
      maxItems: 6,
      frontStyleMode: false,
    },
  );

  const emit = defineEmits<{
    (e: 'update:modelValue', value: TabBarItem[] | FrontStyleTabBarItem[]): void;
    (e: 'update:activeKey', value: string): void;
    (e: 'update:activeIndex', value: number): void;
  }>();

  const { t } = useI18n();
  const message = useMessage();

  const activeTab = ref<string>('');
  const internalItems = ref<TabBarItem[]>([]);

  // Sync activeTab with external activeKey prop
  watch(
    () => props.activeKey,
    (val) => {
      if (val !== undefined && val !== activeTab.value) {
        activeTab.value = val;
      }
    },
    { immediate: true },
  );

  // Emit activeKey and activeIndex changes (skip empty initial value)
  watch(activeTab, (val) => {
    if (val) {
      emit('update:activeKey', val);
      const idx = internalItems.value.findIndex((i) => i._key === val);
      if (idx >= 0) emit('update:activeIndex', idx);
    }
  });

  // Convert from external format to internal format
  // Note: _key is derived from item.key (not preserved from old items).
  // The selfTriggered flag prevents sync-back during user edits, so _key
  // won't change when the user modifies the key field.
  function fromExternalFormat(externalItems: TabBarItem[] | FrontStyleTabBarItem[]): TabBarItem[] {
    if (props.frontStyleMode) {
      // FrontStyle 用的是 bottom-nav 那套接口（`type`/`sort`/`enabled`），在此单向映射进内部
      return (externalItems as FrontStyleTabBarItem[]).map((item) => ({
        _key: item.key || generateKey(),
        name: item.name,
        key: item.key,
        targetType: (item.type as TabBarItem['targetType']) || null,
        target: item.target,
        iconKey: item.iconKey,
        iconActiveKey: item.iconActiveKey,
        special: item.special,
        sortOrder: item.sort,
        visible: item.enabled,
      }));
    }
    return externalItems as TabBarItem[];
  }

  // Convert internal format back to external format
  function toExternalFormat(items: TabBarItem[]): TabBarItem[] | FrontStyleTabBarItem[] {
    if (props.frontStyleMode) {
      return items.map((item) => ({
        key: item.key || item._key,
        name: item.name,
        enabled: item.visible,
        sort: item.sortOrder,
        iconKey: item.iconKey,
        iconActiveKey: item.iconActiveKey,
        type: item.targetType || 'route',
        target: item.target,
        special: item.special,
      })) as FrontStyleTabBarItem[];
    }
    return items;
  }

  // Emit changes when internal items change
  let selfTriggered = false;
  function emitUpdate() {
    selfTriggered = true;
    emit('update:modelValue', toExternalFormat(internalItems.value));
  }

  // Alias for template
  const items = computed(() => internalItems.value);

  const typeOptions = computed(() => [
    { label: t('tenant.styleManage.typeRoute'), value: 'route' },
    { label: t('tenant.styleManage.typeUrl'), value: 'url' },
    { label: t('tenant.styleManage.typeGame'), value: 'game' },
  ]);

  const specialOptions = computed(() => [
    { label: t('tenant.styleManage.specialNormal'), value: 0 },
    { label: t('tenant.styleManage.specialRaised'), value: 1 },
  ]);

  // Route target options for TabBar
  const routeTargetOptions = computed(() => [
    { label: t('tenant.styleManage.routeHome'), value: '/home' },
    { label: t('tenant.styleManage.routeWheel'), value: '/wheel' },
    { label: t('tenant.styleManage.routeEarn'), value: '/earn' },
    { label: t('tenant.styleManage.routeMenu'), value: '/menu' },
    { label: t('tenant.styleManage.routeProfile'), value: '/profile' },
  ]);

  function generateKey() {
    return `item_${Date.now()}_${Math.random().toString(36).slice(2, 11)}`;
  }

  function createEmptyItem(): TabBarItem {
    return {
      _key: generateKey(),
      name: {},
      key: '',
      targetType: null,
      target: '',
      iconKey: '',
      iconActiveKey: '',
      special: 0,
      sortOrder: internalItems.value.length,
      visible: true,
    };
  }

  // Sync from external to internal and initialize activeTab
  let isUpdating = false;
  watch(
    () => props.modelValue,
    (val) => {
      // Skip sync-back when the change was triggered by our own emitUpdate
      if (selfTriggered) {
        selfTriggered = false;
        return;
      }

      isUpdating = true;
      internalItems.value = fromExternalFormat(val);
      // Initialize activeTab or fix if it doesn't match any item
      if (internalItems.value.length > 0) {
        const match = internalItems.value.some((i) => i._key === activeTab.value);
        if (!match) {
          activeTab.value = internalItems.value[0]._key;
        }
      }
      nextTick(() => {
        isUpdating = false;
      });
    },
    { immediate: true, deep: true },
  );

  // Watch for deep changes in internal items and emit
  watch(
    internalItems,
    () => {
      if (!isUpdating) {
        emitUpdate();
      }
    },
    { deep: true },
  );

  function handleAddItem() {
    if (internalItems.value.length >= props.maxItems) {
      message.warning(t('tenant.styleManage.itemsMaxError'));
      return;
    }
    const newItem = createEmptyItem();
    internalItems.value.push(newItem);
    // Deep watcher will call emitUpdate() automatically
    activeTab.value = newItem._key;
  }

  function handleCloseTab(key: string) {
    const index = internalItems.value.findIndex((item) => item._key === key);
    if (index === -1) return;

    internalItems.value.splice(index, 1);

    if (internalItems.value.length > 0) {
      const newIndex = Math.min(index, internalItems.value.length - 1);
      activeTab.value = internalItems.value[newIndex]._key;
    } else {
      activeTab.value = '';
    }
  }

  function handleItemsChange(newItems: TabBarItem[]) {
    // Update sortOrder based on new order
    internalItems.value = newItems.map((item, index) => ({
      ...item,
      sortOrder: index,
    }));
  }
</script>

<style lang="less" scoped>
  /* 可拖拽标签栏样式 */
  .draggable-tabs {
    border: 1px solid #e8e8e8;
    border-radius: 4px;
    background: #fafafa;
  }

  .tabs-header {
    display: flex;
    align-items: center;
    padding: 8px 8px 0;
    border-bottom: 1px solid #e8e8e8;
    background: #fff;
  }

  .tabs-list {
    display: flex;
    flex-wrap: wrap;
    gap: 4px;
    flex: 1;
  }

  .tab-item-drag {
    display: flex;
    align-items: center;
    gap: 6px;
    padding: 6px 10px;
    background: #f0f0f0;
    border: 1px solid #d9d9d9;
    border-bottom: none;
    border-radius: 4px 4px 0 0;
    cursor: pointer;
    transition: all 0.2s;
    user-select: none;
    margin-bottom: -1px;
    color: #666;
  }

  .tab-item-drag:hover {
    background: #fff;
    color: #1890ff;
  }

  .tab-item-drag.active {
    background: #fff;
    border-color: #1890ff;
    border-bottom: 1px solid #fff;
    color: #1890ff;
  }

  .drag-handle {
    cursor: grab;
    color: #999;
    flex-shrink: 0;
  }

  .drag-handle:active {
    cursor: grabbing;
  }

  .tab-label {
    font-size: 13px;
    max-width: 80px;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }

  .tab-close {
    color: #999;
    cursor: pointer;
    flex-shrink: 0;
    transition: color 0.2s;
  }

  .tab-close:hover {
    color: #f5222d;
  }

  .tab-content {
    padding: 12px;
    background: #fff;
  }
</style>
