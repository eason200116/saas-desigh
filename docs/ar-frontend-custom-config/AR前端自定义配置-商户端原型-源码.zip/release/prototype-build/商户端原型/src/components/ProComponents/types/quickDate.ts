export interface QuickDateItem {
  key: string;
  label: string;
  value: [number, number];
  /**
   * 标记为"清空/不限"项：点击时不写入 value 而是清空对应 form 字段；
   * 反向高亮匹配在 range 为空时命中此项（仅生效首个）。
   * value 在 clear=true 时仅占位（建议 [0, 0]），不会被读取。
   */
  clear?: boolean;
}
