import { computed, type Component, type Ref } from 'vue';
import type { Editor } from '@tiptap/core';
import type {
  DropdownDividerOption,
  DropdownGroupOption,
  DropdownOption,
  DropdownRenderOption,
} from 'naive-ui';
import { useI18n } from 'vue-i18n';
import {
  AlignCenterOutlined,
  AlignLeftOutlined,
  AlignRightOutlined,
  BlockOutlined,
  BoldOutlined,
  CodeOutlined,
  CompressOutlined,
  ExpandOutlined,
  FontSizeOutlined,
  ItalicOutlined,
  OrderedListOutlined,
  StrikethroughOutlined,
  UnderlineOutlined,
  UnorderedListOutlined,
} from '@vicons/antd';

export interface TiptapToolbarProps {
  editor: Editor | null;
  refreshKey?: number;
  disabled?: boolean;
  readonly?: boolean;
  showImage?: boolean;
  showTable?: boolean;
  showPreview?: boolean;
  isFullscreen?: boolean;
}

interface ToolbarButtonItem {
  key: string;
  title: string;
  icon: Component;
  canRun: (editor: Editor) => boolean;
  isActive: () => boolean;
  run: () => void;
}

type ToolbarDropdownOption =
  | DropdownOption
  | DropdownGroupOption
  | DropdownDividerOption
  | DropdownRenderOption;

interface UseTiptapToolbarOptions {
  editor: Ref<Editor | null>;
  refreshKey: Ref<number>;
  disabled: Ref<boolean>;
  readonly: Ref<boolean>;
  showImage: Ref<boolean>;
  showTable: Ref<boolean>;
  isFullscreen: Ref<boolean>;
  onLink: () => void;
  onImage: () => void;
}

export function useTiptapToolbar(options: UseTiptapToolbarOptions) {
  const { t } = useI18n();

  const toolbarDisabled = computed(
    () => !options.editor.value || options.disabled.value || options.readonly.value,
  );

  function canRun(checker: (editor: Editor) => boolean) {
    void options.refreshKey.value;
    if (!options.editor.value || options.disabled.value || options.readonly.value) return false;
    return checker(options.editor.value);
  }

  function isMarkActive(name: string, attrs?: Record<string, unknown>) {
    void options.refreshKey.value;
    return options.editor.value?.isActive(name, attrs) ?? false;
  }

  function isNodeActive(attrs: Record<string, unknown>) {
    void options.refreshKey.value;
    return options.editor.value?.isActive(attrs) ?? false;
  }

  const isTableActive = computed(() => {
    void options.refreshKey.value;
    return options.editor.value?.isActive('table') ?? false;
  });

  function getTextStyleAttribute(key: 'color' | 'backgroundColor') {
    void options.refreshKey.value;

    const value = options.editor.value?.getAttributes('textStyle')?.[key];
    return typeof value === 'string' && value.trim() ? value : null;
  }

  const currentStyleKey = computed(() => {
    void options.refreshKey.value;
    if (!options.editor.value) return 'paragraph';
    if (options.editor.value.isActive('heading', { level: 1 })) return 'heading1';
    if (options.editor.value.isActive('heading', { level: 2 })) return 'heading2';
    if (options.editor.value.isActive('heading', { level: 3 })) return 'heading3';
    return 'paragraph';
  });

  const currentStyleLabel = computed(() => {
    const labelMap: Record<string, string> = {
      paragraph: t('common.tiptap.paragraph'),
      heading1: t('common.tiptap.heading1'),
      heading2: t('common.tiptap.heading2'),
      heading3: t('common.tiptap.heading3'),
    };

    return labelMap[currentStyleKey.value] || t('common.tiptap.paragraph');
  });

  const fullscreenIcon = computed(() =>
    options.isFullscreen.value ? CompressOutlined : ExpandOutlined,
  );
  const textColorValue = computed(() => getTextStyleAttribute('color'));
  const backgroundColorValue = computed(() => getTextStyleAttribute('backgroundColor'));

  const canUndo = (editor: Editor) => editor.can().chain().focus().undo().run();
  const canRedo = (editor: Editor) => editor.can().chain().focus().redo().run();
  const canClearFormatting = (editor: Editor) =>
    editor.can().chain().focus().unsetAllMarks().unsetTextAlign().clearNodes().run();
  const canSetTextColor = (editor: Editor) =>
    editor.can().chain().focus().setColor('#0f172a').run();
  const canSetBackgroundColor = (editor: Editor) =>
    editor.can().chain().focus().setBackgroundColor('#fef08a').run();
  const canInsertTable = (editor: Editor) =>
    editor.can().chain().focus().insertTable({ rows: 3, cols: 3, withHeaderRow: true }).run();

  const textItems = computed<ToolbarButtonItem[]>(() => [
    {
      key: 'bold',
      title: t('common.tiptap.bold'),
      icon: BoldOutlined,
      canRun: (editor: Editor) => editor.can().chain().focus().toggleBold().run(),
      isActive: () => isMarkActive('bold'),
      run: () => options.editor.value?.chain().focus().toggleBold().run(),
    },
    {
      key: 'italic',
      title: t('common.tiptap.italic'),
      icon: ItalicOutlined,
      canRun: (editor: Editor) => editor.can().chain().focus().toggleItalic().run(),
      isActive: () => isMarkActive('italic'),
      run: () => options.editor.value?.chain().focus().toggleItalic().run(),
    },
    {
      key: 'underline',
      title: t('common.tiptap.underline'),
      icon: UnderlineOutlined,
      canRun: (editor: Editor) => editor.can().chain().focus().toggleUnderline().run(),
      isActive: () => isMarkActive('underline'),
      run: () => options.editor.value?.chain().focus().toggleUnderline().run(),
    },
    {
      key: 'strike',
      title: t('common.tiptap.strike'),
      icon: StrikethroughOutlined,
      canRun: (editor: Editor) => editor.can().chain().focus().toggleStrike().run(),
      isActive: () => isMarkActive('strike'),
      run: () => options.editor.value?.chain().focus().toggleStrike().run(),
    },
    {
      key: 'code',
      title: t('common.tiptap.code'),
      icon: CodeOutlined,
      canRun: (editor: Editor) => editor.can().chain().focus().toggleCode().run(),
      isActive: () => isMarkActive('code'),
      run: () => options.editor.value?.chain().focus().toggleCode().run(),
    },
  ]);

  const alignItems = computed<ToolbarButtonItem[]>(() => [
    {
      key: 'alignLeft',
      title: t('common.tiptap.alignLeft'),
      icon: AlignLeftOutlined,
      canRun: (editor: Editor) => editor.can().chain().focus().setTextAlign('left').run(),
      isActive: () =>
        isNodeActive({ textAlign: 'left' }) ||
        (!isNodeActive({ textAlign: 'center' }) && !isNodeActive({ textAlign: 'right' })),
      run: () => options.editor.value?.chain().focus().setTextAlign('left').run(),
    },
    {
      key: 'alignCenter',
      title: t('common.tiptap.alignCenter'),
      icon: AlignCenterOutlined,
      canRun: (editor: Editor) => editor.can().chain().focus().setTextAlign('center').run(),
      isActive: () => isNodeActive({ textAlign: 'center' }),
      run: () => options.editor.value?.chain().focus().setTextAlign('center').run(),
    },
    {
      key: 'alignRight',
      title: t('common.tiptap.alignRight'),
      icon: AlignRightOutlined,
      canRun: (editor: Editor) => editor.can().chain().focus().setTextAlign('right').run(),
      isActive: () => isNodeActive({ textAlign: 'right' }),
      run: () => options.editor.value?.chain().focus().setTextAlign('right').run(),
    },
  ]);

  const structureItems = computed<ToolbarButtonItem[]>(() => [
    {
      key: 'bulletList',
      title: t('common.tiptap.bulletList'),
      icon: UnorderedListOutlined,
      canRun: (editor: Editor) => editor.can().chain().focus().toggleBulletList().run(),
      isActive: () => isMarkActive('bulletList'),
      run: () => options.editor.value?.chain().focus().toggleBulletList().run(),
    },
    {
      key: 'orderedList',
      title: t('common.tiptap.orderedList'),
      icon: OrderedListOutlined,
      canRun: (editor: Editor) => editor.can().chain().focus().toggleOrderedList().run(),
      isActive: () => isMarkActive('orderedList'),
      run: () => options.editor.value?.chain().focus().toggleOrderedList().run(),
    },
    {
      key: 'blockquote',
      title: t('common.tiptap.blockquote'),
      icon: BlockOutlined,
      canRun: (editor: Editor) => editor.can().chain().focus().toggleBlockquote().run(),
      isActive: () => isMarkActive('blockquote'),
      run: () => options.editor.value?.chain().focus().toggleBlockquote().run(),
    },
  ]);

  const styleOptions = computed<ToolbarDropdownOption[]>(() => [
    { label: t('common.tiptap.paragraph'), key: 'paragraph' },
    { label: t('common.tiptap.heading1'), key: 'heading1' },
    { label: t('common.tiptap.heading2'), key: 'heading2' },
    { label: t('common.tiptap.heading3'), key: 'heading3' },
  ]);

  const tableMenuOptions = computed<ToolbarDropdownOption[]>(() => [
    {
      label: t('common.tiptap.insertTable'),
      key: 'insertTable',
      disabled: !canRun(canInsertTable),
    },
    { type: 'divider', key: 'table-divider-1' },
    {
      label: t('common.tiptap.addRowAbove'),
      key: 'addRowBefore',
      disabled: !canRun((editor: Editor) => editor.can().chain().focus().addRowBefore().run()),
    },
    {
      label: t('common.tiptap.addRowBelow'),
      key: 'addRowAfter',
      disabled: !canRun((editor: Editor) => editor.can().chain().focus().addRowAfter().run()),
    },
    {
      label: t('common.tiptap.addColumnBefore'),
      key: 'addColumnBefore',
      disabled: !canRun((editor: Editor) => editor.can().chain().focus().addColumnBefore().run()),
    },
    {
      label: t('common.tiptap.addColumnAfter'),
      key: 'addColumnAfter',
      disabled: !canRun((editor: Editor) => editor.can().chain().focus().addColumnAfter().run()),
    },
    { type: 'divider', key: 'table-divider-2' },
    {
      label: t('common.tiptap.toggleHeaderRow'),
      key: 'toggleHeaderRow',
      disabled: !canRun((editor: Editor) => editor.can().chain().focus().toggleHeaderRow().run()),
    },
    {
      label: t('common.tiptap.toggleHeaderColumn'),
      key: 'toggleHeaderColumn',
      disabled: !canRun((editor: Editor) =>
        editor.can().chain().focus().toggleHeaderColumn().run(),
      ),
    },
    {
      label: t('common.tiptap.mergeCells'),
      key: 'mergeCells',
      disabled: !canRun((editor: Editor) => editor.can().chain().focus().mergeCells().run()),
    },
    {
      label: t('common.tiptap.splitCell'),
      key: 'splitCell',
      disabled: !canRun((editor: Editor) => editor.can().chain().focus().splitCell().run()),
    },
    { type: 'divider', key: 'table-divider-3' },
    {
      label: t('common.tiptap.deleteRow'),
      key: 'deleteRow',
      disabled: !canRun((editor: Editor) => editor.can().chain().focus().deleteRow().run()),
    },
    {
      label: t('common.tiptap.deleteColumn'),
      key: 'deleteColumn',
      disabled: !canRun((editor: Editor) => editor.can().chain().focus().deleteColumn().run()),
    },
    {
      label: t('common.tiptap.deleteTable'),
      key: 'deleteTable',
      disabled: !canRun((editor: Editor) => editor.can().chain().focus().deleteTable().run()),
    },
  ]);

  function handleStyleSelect(key: string | number) {
    if (!options.editor.value) return;

    const editor = options.editor.value.chain().focus();
    switch (key) {
      case 'heading1':
        editor.toggleHeading({ level: 1 }).run();
        break;
      case 'heading2':
        editor.toggleHeading({ level: 2 }).run();
        break;
      case 'heading3':
        editor.toggleHeading({ level: 3 }).run();
        break;
      default:
        editor.setParagraph().run();
        break;
    }
  }

  function handleTableSelect(key: string | number) {
    if (!options.editor.value) return;

    const editor = options.editor.value.chain().focus();
    switch (key) {
      case 'insertTable':
        editor.insertTable({ rows: 3, cols: 3, withHeaderRow: true }).run();
        break;
      case 'addRowBefore':
        editor.addRowBefore().run();
        break;
      case 'addRowAfter':
        editor.addRowAfter().run();
        break;
      case 'addColumnBefore':
        editor.addColumnBefore().run();
        break;
      case 'addColumnAfter':
        editor.addColumnAfter().run();
        break;
      case 'toggleHeaderRow':
        editor.toggleHeaderRow().run();
        break;
      case 'toggleHeaderColumn':
        editor.toggleHeaderColumn().run();
        break;
      case 'mergeCells':
        editor.mergeCells().run();
        break;
      case 'splitCell':
        editor.splitCell().run();
        break;
      case 'deleteRow':
        editor.deleteRow().run();
        break;
      case 'deleteColumn':
        editor.deleteColumn().run();
        break;
      case 'deleteTable':
        editor.deleteTable().run();
        break;
    }
  }

  function undo() {
    options.editor.value?.chain().focus().undo().run();
  }

  function redo() {
    options.editor.value?.chain().focus().redo().run();
  }

  function clearFormatting() {
    options.editor.value?.chain().focus().unsetAllMarks().unsetTextAlign().clearNodes().run();
  }

  function setTextColor(color: string | null) {
    if (!options.editor.value) return;
    const chain = options.editor.value.chain().focus();
    if (color) {
      chain.setColor(color).run();
      return;
    }

    chain.unsetColor().run();
  }

  function setBackgroundColor(color: string | null) {
    if (!options.editor.value) return;
    const chain = options.editor.value.chain().focus();
    if (color) {
      chain.setBackgroundColor(color).run();
      return;
    }

    chain.unsetBackgroundColor().run();
  }

  return {
    t,
    toolbarDisabled,
    isTableActive,
    currentStyleLabel,
    fullscreenIcon,
    textColorValue,
    backgroundColorValue,
    textItems,
    alignItems,
    structureItems,
    styleOptions,
    tableMenuOptions,
    canRun,
    canUndo,
    canRedo,
    canClearFormatting,
    canSetTextColor,
    canSetBackgroundColor,
    handleStyleSelect,
    handleTableSelect,
    undo,
    redo,
    clearFormatting,
    setTextColor,
    setBackgroundColor,
    FontSizeOutlined,
  };
}
