// 注单补采（总控端 admin · game_fetchBet）功能说明书。
// 锚定 src/views/game/balance/index.vue + data.ts 真实控件（R53 实证、不臆造）。
// 非标准页（S5）：上方为「提交表单」（厂商 / 币种 / 时间范围或版本号 + 确认），下方为只读「补采记录」列表（无搜索、无行操作）。
// 目录名 balance/ 与 i18n 命名空间 game.thirdBalance.* 为历史遗留叫法，勿改。
// 2026-07-22 更新：第三个参数字段改为按厂商类型二选一（时间范围/补采版本号），见下方 form_timeRange、form_version 两条。

import type { PageManual } from '../types';

const manual: PageManual = {
  route: 'game_fetchBet',
  title: '注单补采',
  overview:
    '总控端发起三方注单补采任务。上方提交区选「游戏厂商 + 币种」后，第三个参数按厂商类型二选一（2026-07-22 新增，Eason 截图确认真实交互）：时间范围模式显示开始/结束时间选择器，版本号模式显示补采版本号文本框，两者互斥展示；点确认（先校验、再二次确认回显参数）提交一次补采任务；下方只读展示补采记录。V3 精简版：源站原为「三方余额回收 + 注单补采」双 Tab，V3 只保留注单补采（对源站的有意偏离）。补采粒度取厂商。',
  items: [
    // ============ 提交表单（非 ProSearchForm，是 NForm 提交区）============
    {
      anchor: 'form_vendor',
      name: '游戏厂商（提交表单）',
      group: '提交表单',
      interaction:
        '下拉单选、可搜索、可清空；选后驱动「币种」联动，并决定下方第三个参数字段是时间范围还是版本号。',
      dataSource:
        '选项来自 gameVendorPool，仅列真有子游戏的厂商（过滤掉 HOT/FEA/REC 展示分类占位）。',
      logic: '指定补采哪个厂商的注单。',
      limit: '必填（表单 rule required）。',
    },
    {
      anchor: 'form_currency',
      name: '币种（提交表单）',
      group: '提交表单',
      interaction: '下拉单选、可清空；未选厂商时禁用。',
      dataSource: '随所选厂商联动，只列该厂商实际支持的币种（gameVendorMap.currencyList）。',
      logic: '指定补采的结算币种。',
      limit: '必填；换厂商会清空币种重选（避免选出厂商不支持的非法组合）。',
    },
    {
      anchor: 'form_timeRange',
      name: '时间范围（提交表单·时间范围模式）',
      group: '提交表单',
      interaction:
        '日期时间范围选择（n-date-picker datetimerange，可清空）。仅当所选厂商属于「时间范围模式」时展示，与 form_version 互斥。',
      dataSource: '用户选择。',
      logic: '指定补采的时间段。',
      limit: '必填（该模式下）。',
      note: '2026-07-22 起改为按厂商类型二选一（原为恒定展示的唯一字段）；源站无此字段，V3 有意补上（不给时段说不清补采哪一段）。厂商类型→模式的完整对应关系尚未全部核实，目前仅棋牌类确认为本模式（见 data.ts 的 getFetchMode 注释）。',
    },
    {
      anchor: 'form_version',
      name: '补采版本号（提交表单·版本号模式）',
      group: '提交表单',
      interaction:
        '文本输入框，可清空。仅当所选厂商属于「版本号模式」时展示，与 form_timeRange 互斥。',
      dataSource: '用户输入。',
      logic: '指定补采的版本号（部分厂商按版本号而非时间段补采）。',
      limit: '必填（该模式下）。',
      note: '2026-07-22 新增。目前仅真人视讯类厂商（如 MG视讯）确认为本模式，其余厂商类型待核实（见 data.ts 的 getFetchMode 注释）。',
    },

    // ============ 操作 ============
    {
      anchor: 'act_confirm',
      name: '确认（提交补采任务）',
      group: '操作',
      interaction:
        '点「确认」先做表单校验，通过后弹二次确认框（回显厂商 / 币种 / 时间范围或版本号供核对，按所选厂商的模式二选一）。',
      logic:
        '二次确认后调用 api.game.gameBalanceFetchBet 提交补采任务；提交为异步任务（仅提示已受理），成功后刷新下方补采记录。',
      edge: '补采粒度取厂商而非具体子游戏（用户拍板，与 .NET 源码一致）；真实补采范围 / 耗时 / 是否可重复提交待 5190 核实。',
    },
  ],

  // ============ 字段介绍 tab（下方「补采记录」列表的列 + 定义；列序照页面）============
  fields: [
    { name: '游戏厂商', def: '本条补采任务针对的游戏厂商。' },
    { name: '币种', def: '补采任务的结算币种。' },
    {
      name: '补采参数',
      def: '本条补采任务的第三个参数，按记录的模式二选一展示：时间范围模式显示「开始时间 ~ 结束时间」（按商户时区），版本号模式显示补采版本号。2026-07-22 由原「开始时间」「结束时间」两列合并而来，列位置不变。',
    },
    { name: '创建人', def: '提交该补采任务的操作账号（本页无编辑，实为提交人）。' },
    { name: '创建时间', def: '该补采记录的创建（提交）时间。' },
  ],
};

export default manual;
