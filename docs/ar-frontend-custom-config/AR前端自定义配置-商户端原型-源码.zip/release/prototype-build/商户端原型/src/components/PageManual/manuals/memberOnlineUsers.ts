// 在线人数（商户端 tenant · member_online_users）功能说明书。
// 锚定 src/views/member/onlineUsers/index.vue + data.ts + useOnlineUsersPage.ts + form.ts 真实控件（R53 实证、不臆造）。
// 单表 ProCrudTable 纯查看型列表：无新增/编辑/删除/操作列/批量操作/导出按钮，仅供浏览当前商户下会员的基础信息 + 资产/投注/登录快照。仅商户端(tenant)可访问(路由 roles:['tenant'])，总控端无此入口。
// 页面当前未挂 data-manual 锚点，本说明书条目暂不联动面板点击高亮，仅供阅读（对齐同模块既有先例 riskControlSameIp.ts / memberGroupManage.ts 现状）。
// 页名取实际渲染值：左侧菜单/页面Tab显示「在线人数」(i18n menu.json 的 member_online_users key)；member.json 内另有 onlineUsers.title="在线用户明细" 键，站内代码未见任何引用，属未使用的孤立 i18n key，如实记录、不采用为页名。
// 另：data.ts 的 getOnlineUserPageList 保留了 ip 字段过滤分支（filtered.filter(r => r.ip.includes(ip))），但本页搜索区未提供对应输入控件、useOnlineUsersPage.loadData 组装 requestParams 时也未透传 ip 参数，这段 mock 过滤逻辑当前不可达；如实记录，非本次引入。

import type { PageManual } from '../types';

const manual: PageManual = {
  route: 'member_online_users',
  title: '在线人数',
  overview:
    '商户端专属（仅 tenant 角色可见，总控端无此路由）「会员管理 › 在线人数」页，单表（ProCrudTable）展示当前商户下会员的基础信息 + 资产/投注/登录快照，纯查看型列表——无新增/编辑/删除/操作列/批量操作/导出按钮。除左侧菜单进入外，还可从顶部导航「在线人数」角标浮层（OnlineBadge）点击具体商户直接跳入并自动定位（URL 携带 siteId 参数；页面借 keepAlive + tabIgnoreQueryKeys 复用同一个 tab，监听 siteId 变化自动重查，不新开 tab）。商户搜索项单选必填（R63）。',
  items: [
    // ============ 搜索区 ============
    {
      anchor: 'merchant',
      name: '商户',
      group: '搜索',
      interaction:
        '下拉单选（MerchantFilterSelect，multiple:false → 架构级不可清空，见《交互规范》§3 商户选择器）。',
      dataSource:
        '全站商户列表；默认预填有两路——① 从顶部导航「在线人数」角标浮层（OnlineBadge）点击具体商户跳入时，URL 带 siteId，回填该商户；② 直接从左侧菜单进入时，预填左上角当前选中商户（defaultTenantId；本页仅商户端可访问，恒有值）。',
      logic:
        "按选中商户过滤会员列表（matchMerchantFilter，兼容单值/数组写法）；本页已在同一 tab 打开时，再从 OnlineBadge 点击另一个商户会更新 URL 的 siteId 但不新开 tab（keepAlive + tabIgnoreQueryKeys=['siteId']），页面监听该变化自动切换搜索商户并重新查询。",
      limit:
        '必填（红星 showRequireMark + requiredRule）；单选、不可清空——命中 R63（本页商户与会员ID同屏出现，商户必单选+必填）。',
      edge: '不可清空，恒有值，不存在「未选商户」态。',
    },
    {
      anchor: 'v1UserId',
      name: '会员ID',
      group: '搜索',
      interaction: '数字输入框（不带步进箭头 showButton:false，可清空）。',
      dataSource: '用户输入。',
      logic: '按会员ID精确匹配过滤（严格等值，非模糊）。',
      limit: '选填；最小值 0、整数（precision 0）。',
      edge:
        '填 0 或负数等同未填——loadData 会把非正整数转换成 undefined 不参与查询，与「留空」效果一致。',
    },

    // ============ 列 ============
    {
      anchor: 'col_v1UserId',
      name: '会员ID列',
      group: '列',
      interaction:
        '数字以可点击蓝字链接形式展示（跳转类控件，非纯展示；全站会员ID可点标准写法 renderMemberIdLink）。',
      dataSource: '行数据 v1UserId + tenantId。',
      logic:
        '点击调用 openMemberDetailModal(会员ID, 商户ID) 打开「会员详情」弹窗（命令式全局弹窗，本页无需挂载额外组件）。',
    },
  ],

  // ============ 字段介绍 tab（列序照页面；仅列表列 + 定义）============
  fields: [
    { name: '商户', def: '该会员当前所属商户，以商户标签展示（renderTenantTag：商户号+商户名）。' },
    {
      name: '会员ID',
      def: '会员的唯一数字ID（V1 平台用户ID）；数字为可点击蓝字链接，点击打开会员详情弹窗。',
    },
    { name: '会员账号', def: '会员的登录账号。' },
    { name: 'VIP等级', def: '会员当前的 VIP 等级，以「VIPx」标签展示（如 VIP3）。' },
    { name: '会员分组', def: '会员所属的分组名称（如"VIP专属组"/"普通会员组"/"活跃组"等）。' },
    { name: '余额', def: '该会员钱包当前余额（货币格式化展示）。' },
    {
      name: '今日/历史有效投注',
      def: '上下两行：今日有效投注（原始字段）在上，历史累计有效投注灰字在下——历史值由 mock 按公式从今日值 + 累计充值派生，用于原型多样化展示（R32），并非独立后端字段。',
    },
    {
      name: '今日/历史充值金额',
      def: '上下两行：今日充值（mock 按累计充值 × 系数派生，用于原型多样化展示 R32，并非独立后端字段）在上，累计充值（原始字段）灰字在下——与「今日/历史有效投注」列方向相反（该列是原始字段在上、派生值在下），如实记录两列生成方式不对称，非本次引入。',
    },
    {
      name: '最后登录地区/IP',
      def: '上下两行：登录IP在上，登录地区（国家/省州组合，经 enumLabel 统一转译的有限枚举）灰字在下；缺省时显示"--"。',
    },
    { name: '最后登录时间', def: '会员最近一次登录的时间，按当前操作商户所在时区显示。' },
    { name: '注册时间', def: '会员的注册时间，按当前操作商户所在时区显示。' },
  ],
};

export default manual;
