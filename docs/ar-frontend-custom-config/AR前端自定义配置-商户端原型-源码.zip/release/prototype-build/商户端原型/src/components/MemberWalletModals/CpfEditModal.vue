<template>
  <n-form ref="formRef" :model="formData" :rules="rules" label-placement="top">
    <n-grid :cols="2" :x-gap="14">
      <n-form-item-gi :label="t('member.bankCard.merchant')" path="tenantId">
        <n-select
          v-if="!isEdit"
          v-model:value="formData.tenantId"
          :options="tenantOptions"
          filterable
          clearable
          :placeholder="t('common.select_placeholder', { label: t('member.bankCard.merchant') })"
          @update:value="handleTenantChange"
        />
        <n-input v-else :value="getTenantName(formData.tenantId)" disabled />
      </n-form-item-gi>
      <n-form-item-gi :label="t('member.bankCard.userId')" path="userId">
        <n-input
          v-model:value="formData.userId"
          :disabled="isEdit"
          :allow-input="onlyDigits"
          :placeholder="t('common.input_placeholder', { label: t('member.bankCard.userId') })"
        />
      </n-form-item-gi>
      <n-form-item-gi :label="t('member.bankCard.walletType')" path="bankId">
        <n-select
          v-model:value="formData.bankId"
          :options="selectOptions"
          clearable
          :placeholder="t('common.select_placeholder', { label: t('member.bankCard.walletType') })"
        />
      </n-form-item-gi>
      <n-form-item-gi :label="t('member.bankCard.pix')" path="accountNo">
        <n-input
          v-model:value="formData.accountNo"
          :placeholder="t('common.input_placeholder', { label: t('member.bankCard.pix') })"
        />
      </n-form-item-gi>
      <n-form-item-gi :label="t('member.bankCard.cpf')">
        <n-input
          v-model:value="formData.cpf"
          :placeholder="t('common.input_placeholder', { label: t('member.bankCard.cpf') })"
        />
      </n-form-item-gi>
      <n-form-item-gi :label="t('member.bankCard.beneficiaryName')">
        <n-input
          v-model:value="formData.beneficiaryName"
          :placeholder="
            t('common.input_placeholder', { label: t('member.bankCard.beneficiaryName') })
          "
        />
      </n-form-item-gi>
    </n-grid>
  </n-form>
  <n-space justify="end" :style="{ marginTop: '16px' }">
    <n-button @click="emit('cancel')">{{ t('common.cancel') }}</n-button>
    <n-button type="primary" :loading="loading" @click="handleSubmit">
      {{ t('common.confirm') }}
    </n-button>
  </n-space>
</template>

<script setup lang="ts">
  import { reactive, ref, computed, onMounted } from 'vue';
  import type { FormInst, FormRules } from 'naive-ui';
  import { useI18n } from 'vue-i18n';
  import { useMessage } from 'naive-ui';
  import { useTenantOptions } from '@/hooks';
  import { onlyDigits } from '@/utils';
  import { api } from './data';
  import { useTypeOptions } from './useTypeOptions';

  const props = defineProps<{
    mode: 'add' | 'edit';
    record?: any | null;
  }>();

  const emit = defineEmits<{
    (e: 'cancel'): void;
    (e: 'confirm'): void;
  }>();

  const { t } = useI18n();
  const message = useMessage();
  const { tenantOptions, getTenantName, defaultTenantId } = useTenantOptions();
  const { cpfOptions, loadCpfOptions, ensureOption } = useTypeOptions();

  const isEdit = computed(() => props.mode === 'edit');
  const formRef = ref<FormInst | null>(null);
  const loading = ref(false);

  const selectOptions = computed(() =>
    ensureOption(cpfOptions.value, formData.bankId, props.record?.bankNameStr),
  );

  onMounted(() => loadCpfOptions(formData.tenantId));

  function handleTenantChange(tenantId: number) {
    formData.bankId = null;
    loadCpfOptions(tenantId);
  }

  const formData = reactive({
    tenantId: props.record?.tenantId ?? defaultTenantId.value ?? undefined,
    userId: props.record?.userId != null ? String(props.record.userId) : '',
    bankId: props.record?.bankId ?? (null as number | null),
    accountNo: props.record?.accountNo ?? '',
    cpf: props.record?.cpf ?? '',
    beneficiaryName: props.record?.beneficiaryName ?? '',
  });

  const rules: FormRules = {
    tenantId: {
      required: true,
      type: 'number',
      message: t('common.select_placeholder', { label: t('member.bankCard.merchant') }),
      trigger: 'change',
    },
    userId: [
      {
        required: true,
        message: t('common.input_placeholder', { label: t('member.bankCard.userId') }),
        trigger: 'blur',
      },
      {
        pattern: /^\d+$/,
        message: t('member.bankCard.userIdIntegerOnly'),
        trigger: ['blur', 'input'],
      },
    ],
    bankId: {
      required: true,
      type: 'number',
      message: t('common.select_placeholder', { label: t('member.bankCard.walletType') }),
      trigger: 'change',
    },
    accountNo: {
      required: true,
      message: t('common.input_placeholder', { label: t('member.bankCard.pix') }),
      trigger: 'blur',
    },
  };

  async function handleSubmit() {
    try {
      await formRef.value?.validate();
    } catch {
      return;
    }
    loading.value = true;
    try {
      const basePayload = {
        userId: Number(formData.userId),
        bankId: formData.bankId ?? undefined,
        accountNo: formData.accountNo,
        beneficiaryName: formData.beneficiaryName || undefined,
        cpf: formData.cpf || undefined,
        tenantId: formData.tenantId,
      };
      const { result, msg } = isEdit.value
        ? await api.v1platform.updateUserCpf({ bId: props.record!.bId, ...basePayload })
        : await api.v1platform.addUserCpf(basePayload);
      if (!result) {
        message.error(msg);
        return;
      }
      message.success(t('member.bankCard.saveSuccess'));
      emit('confirm');
    } catch {
      message.error(t('common.requestFailed'));
    } finally {
      loading.value = false;
    }
  }
</script>
