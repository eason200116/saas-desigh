<template>
  <div class="product-nav-content">
    <!-- Search Box -->
    <div class="product-nav-content__search">
      <n-input
        v-model:value="searchKeyword"
        :placeholder="t('productNav.searchPlaceholder')"
        clearable
        size="large"
      >
        <template #prefix>
          <n-icon :size="18">
            <SearchOutline />
          </n-icon>
        </template>
      </n-input>
    </div>

    <!-- Search Results -->
    <div v-if="searchKeyword && searchResults.length > 0" class="product-nav-content__results">
      <div class="product-nav-content__results-header">
        {{ t('productNav.searchResults') }} ({{ searchResults.length }})
      </div>
      <div class="product-nav-content__results-list">
        <div
          v-for="result in searchResults"
          :key="`${result.key}-${result.tabKey || ''}`"
          class="product-nav-content__result-item"
          @click="handleResultClick(result)"
        >
          <span class="product-nav-content__result-category">{{ result.categoryTitle }}</span>
          <span class="product-nav-content__result-title">{{ result.title }}</span>
        </div>
      </div>
    </div>

    <!-- No Results -->
    <div v-else-if="searchKeyword && searchResults.length === 0" class="product-nav-content__empty">
      <n-empty :description="t('productNav.noResults')" />
    </div>

    <!-- Categories -->
    <div v-else class="product-nav-content__body">
      <div class="product-nav-content__categories">
        <CategorySection
          v-for="category in categories"
          :key="category.key"
          :category="category"
          @navigate="handleNavigate"
          @navigate-tab="handleNavigateTab"
        />
      </div>

      <!-- Anchor Navigation -->
      <div class="product-nav-content__anchor">
        <div class="product-nav-content__anchor-title">{{ t('productNav.quickNav') }}</div>
        <div
          v-for="category in categories"
          :key="category.key"
          class="product-nav-content__anchor-item"
          :class="{ 'product-nav-content__anchor-item--active': activeAnchor === category.key }"
          @click="scrollToCategory(category.key)"
        >
          {{ t(category.title) }}
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
  import { ref, onMounted, onUnmounted } from 'vue';
  import { useI18n } from 'vue-i18n';
  import { SearchOutline } from '@vicons/ionicons5';
  import { useProductNav } from './useProductNav';
  import CategorySection from './CategorySection.vue';
  import type { SearchResultItem } from './types';

  const emit = defineEmits<{
    close: [];
  }>();

  const { t } = useI18n();
  const { categories, searchKeyword, searchResults, navigateTo, navigateToTab } = useProductNav();

  const activeAnchor = ref('');

  // Handle navigation to a page
  const handleNavigate = (routeName: string) => {
    navigateTo(routeName);
    emit('close');
  };

  // Handle navigation to a tab
  const handleNavigateTab = (routeName: string, tabKey: string) => {
    navigateToTab(routeName, tabKey);
    emit('close');
  };

  // Handle search result click
  const handleResultClick = (result: SearchResultItem) => {
    if (result.tabKey) {
      navigateToTab(result.key, result.tabKey);
    } else {
      navigateTo(result.key);
    }
    emit('close');
  };

  // Scroll to category section
  const scrollToCategory = (categoryKey: string) => {
    const element = document.getElementById(`category-${categoryKey}`);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth', block: 'start' });
      activeAnchor.value = categoryKey;
    }
  };

  // Track scroll position to update active anchor
  let scrollContainer: HTMLElement | null = null;
  let observer: IntersectionObserver | null = null;

  onMounted(() => {
    // Set initial active anchor
    if (categories.value.length > 0) {
      activeAnchor.value = categories.value[0].key;
    }

    // Setup intersection observer for anchor highlighting
    scrollContainer = document.querySelector('.product-nav-content__categories');
    if (scrollContainer) {
      observer = new IntersectionObserver(
        (entries) => {
          entries.forEach((entry) => {
            if (entry.isIntersecting) {
              const id = entry.target.id;
              if (id.startsWith('category-')) {
                activeAnchor.value = id.replace('category-', '');
              }
            }
          });
        },
        {
          root: scrollContainer,
          threshold: 0.3,
        },
      );

      categories.value.forEach((category) => {
        const element = document.getElementById(`category-${category.key}`);
        if (element) {
          observer?.observe(element);
        }
      });
    }
  });

  onUnmounted(() => {
    if (observer) {
      observer.disconnect();
    }
  });
</script>

<style lang="less" scoped>
  .product-nav-content {
    display: flex;
    flex-direction: column;
    height: 100%;
    background-color: #fff;

    &__search {
      padding: 20px 24px;
      border-bottom: 1px solid #f0f0f0;
    }

    &__body {
      display: flex;
      flex: 1;
      overflow: hidden;
    }

    &__categories {
      flex: 1;
      overflow-y: auto;
      padding: 20px 24px;
    }

    &__anchor {
      width: 160px;
      border-left: 1px solid #f0f0f0;
      padding: 20px 16px;
      overflow-y: auto;

      &-title {
        font-size: 14px;
        font-weight: 600;
        color: #333;
        margin-bottom: 12px;
        padding-left: 8px;
      }

      &-item {
        padding: 8px 12px;
        font-size: 13px;
        color: #666;
        cursor: pointer;
        border-radius: 4px;
        transition: all 0.2s;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;

        &:hover {
          color: var(--ui-accent-text);
          background-color: var(--ui-accent-soft);
        }

        &--active {
          color: var(--ui-accent-solid);
          background-color: var(--ui-accent-soft-hover);
          font-weight: 500;
        }
      }
    }

    &__results {
      flex: 1;
      overflow-y: auto;
      padding: 20px 24px;

      &-header {
        font-size: 14px;
        font-weight: 600;
        color: #333;
        margin-bottom: 12px;
      }

      &-list {
        display: flex;
        flex-direction: column;
        gap: 4px;
      }
    }

    &__result-item {
      display: flex;
      align-items: center;
      padding: 10px 12px;
      border-radius: 4px;
      cursor: pointer;
      transition: background-color 0.2s;

      &:hover {
        background-color: rgba(24, 160, 88, 0.08);
      }
    }

    &__result-category {
      font-size: 12px;
      color: #999;
      background-color: #f5f5f5;
      padding: 2px 8px;
      border-radius: 4px;
      margin-right: 12px;
      flex-shrink: 0;
    }

    &__result-title {
      font-size: 14px;
      color: #333;
    }

    &__empty {
      flex: 1;
      display: flex;
      align-items: center;
      justify-content: center;
    }
  }
</style>
