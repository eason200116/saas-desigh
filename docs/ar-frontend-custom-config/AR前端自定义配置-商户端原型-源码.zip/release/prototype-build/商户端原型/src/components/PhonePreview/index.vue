<template>
  <div class="relative flex h-full w-full min-h-0 flex-col">
    <button
      v-if="collapsible"
      type="button"
      class="absolute top-1/2 left-0 z-[5] flex h-14 w-[18px] -translate-x-1/2 -translate-y-1/2 cursor-pointer items-center justify-center rounded-[9px] border border-gray-200 bg-white p-0 text-gray-500 shadow-[0_2px_6px_rgba(15,23,42,0.08)] transition-colors duration-200 hover:border-[#91caff] hover:bg-[#f0f7ff] hover:text-[#1890ff]"
      :title="
        collapsed ? t('components.phonePreview.expand') : t('components.phonePreview.collapse')
      "
      data-manual="previewToggle"
      @click="collapsed = !collapsed"
    >
      <n-icon size="14">
        <ChevronForwardOutline v-if="!collapsed" />
        <ChevronBackOutline v-else />
      </n-icon>
    </button>

    <n-card v-show="!collapsed" size="small" class="preview-card" :title="preview.title">
      <template #header-extra>
        <n-space align="center" size="small">
          <n-radio-group
            v-if="availableTerminalOptions.length > 1"
            v-model:value="terminal"
            size="small"
          >
            <n-radio-button
              v-for="item in availableTerminalOptions"
              :key="item.value"
              :value="item.value"
            >
              {{ item.label }}
            </n-radio-button>
          </n-radio-group>

          <n-tag v-if="preview.tagLabel" size="small" :type="preview.tagType || 'info'">
            {{ preview.tagLabel }}
          </n-tag>

          <n-button
            v-if="preview.openButtonText"
            text
            size="small"
            :disabled="!preview.canRender || !activeIframeSrc"
            @click="openInNewTab"
          >
            {{ preview.openButtonText }}
          </n-button>
        </n-space>
      </template>

      <n-empty
        v-if="!preview.canRender || !activeIframeSrc"
        :description="preview.emptyDescription"
      />

      <div v-else class="preview-shell" :class="previewShellClass">
        <div v-if="isPhoneTerminal" class="preview-shell__camera" />

        <div v-if="isPhoneTerminal" class="preview-shell__viewport">
          <iframe
            :key="activeIframeSrc"
            :src="activeIframeSrc"
            class="preview-shell__frame"
            frameborder="0"
            loading="lazy"
          />
        </div>

        <iframe
          v-else
          :key="activeIframeSrc"
          :src="activeIframeSrc"
          class="preview-shell__frame preview-shell__frame--browser"
          frameborder="0"
          loading="lazy"
        />
      </div>
    </n-card>
  </div>
</template>

<script setup lang="ts">
  import { computed, ref, watch } from 'vue';
  import { ChevronBackOutline, ChevronForwardOutline } from '@vicons/ionicons5';
  import { useI18n } from 'vue-i18n';
  import type {
    PhonePreviewModel,
    PhonePreviewTerminal,
    PhonePreviewTerminalOption,
  } from './types';

  const DEFAULT_TERMINAL_OPTIONS: PhonePreviewTerminalOption[] = [
    { label: 'PC', value: 'pc' },
    { label: 'H5', value: 'h5' },
    { label: 'APP', value: 'app' },
  ];

  const props = withDefaults(
    defineProps<{
      preview: PhonePreviewModel;
      /** 是否允许折叠（显示左侧把手）。默认 true，不需要折叠的场景传 false 即可隐藏把手 */
      collapsible?: boolean;
      /**
       * 折叠状态（可选 v-model）。不绑定时组件内部自管；绑定时父组件用来同步调整容器尺寸。
       */
      collapsed?: boolean;
    }>(),
    {
      collapsible: true,
      collapsed: undefined,
    },
  );

  const emit = defineEmits<{
    (e: 'update:collapsed', value: boolean): void;
  }>();

  const { t } = useI18n();

  // 父组件没绑 v-model 时走内部 ref；绑了就用 props.collapsed 并在 set 时 emit。
  const internalCollapsed = ref(false);
  const collapsed = computed<boolean>({
    get: () => props.collapsed ?? internalCollapsed.value,
    set: (value) => {
      internalCollapsed.value = value;
      emit('update:collapsed', value);
    },
  });

  const terminal = ref<PhonePreviewTerminal>('pc');

  const availableTerminalOptions = computed(() => {
    const options = props.preview.terminalOptions?.length
      ? props.preview.terminalOptions
      : DEFAULT_TERMINAL_OPTIONS;
    return options.filter((item) => Boolean(props.preview.iframeSrcMap[item.value]));
  });

  const activeIframeSrc = computed(() => {
    const currentSrc = props.preview.iframeSrcMap[terminal.value];
    if (currentSrc) return currentSrc;
    const fallback = availableTerminalOptions.value[0]?.value;
    return fallback ? props.preview.iframeSrcMap[fallback] || '' : '';
  });

  const isPhoneTerminal = computed(() => terminal.value === 'h5' || terminal.value === 'app');

  const previewShellClass = computed(() => ({
    'preview-shell--browser': terminal.value === 'pc',
    'preview-shell--phone': isPhoneTerminal.value,
    'preview-shell--app': terminal.value === 'app',
  }));

  watch(
    [() => props.preview.defaultTerminal, availableTerminalOptions],
    () => {
      const defaultTerminal = props.preview.defaultTerminal;
      if (
        defaultTerminal &&
        availableTerminalOptions.value.some((item) => item.value === defaultTerminal)
      ) {
        terminal.value = defaultTerminal;
        return;
      }

      terminal.value = availableTerminalOptions.value[0]?.value || 'pc';
    },
    { immediate: true },
  );

  function openInNewTab() {
    if (!props.preview.canRender || !activeIframeSrc.value) return;
    window.open(activeIframeSrc.value, '_blank', 'noopener,noreferrer');
  }
</script>

<style scoped>
  .preview-card {
    width: 100%;
    height: 100%;
  }

  .preview-card :deep(.n-card__content) {
    display: flex;
    flex-direction: column;
    gap: 12px;
    height: 100%;
    min-height: 0;
  }

  .preview-shell {
    display: flex;
    align-items: center;
    justify-content: center;
    flex: 1;
    min-height: 0;
  }

  .preview-shell--browser {
    width: 100%;
    height: 100%;
    min-height: 560px;
    border: 1px solid #e5e7eb;
    border-radius: 16px;
    overflow: hidden;
    background: #fff;
    display: flex;
    flex-direction: column;
    box-shadow: 0 20px 40px rgba(15, 23, 42, 0.08);
  }

  .preview-shell--phone {
    width: 340px;
    height: 100%;
    max-height: 760px;
    padding: 16px 12px 18px;
    border-radius: 32px;
    border: 1px solid #dbe3ef;
    background: linear-gradient(180deg, #111827 0%, #1f2937 100%);
    flex-direction: column;
    gap: 12px;
    box-shadow: 0 20px 40px rgba(15, 23, 42, 0.16);
  }

  .preview-shell--app {
    background: linear-gradient(180deg, #0f172a 0%, #111827 100%);
  }

  .preview-shell__camera {
    width: 108px;
    height: 22px;
    margin: 0 auto;
    border-radius: 999px;
    background: rgba(255, 255, 255, 0.08);
  }

  .preview-shell__viewport {
    flex: 1;
    min-height: 0;
    width: 100%;
    border-radius: 24px;
    overflow: hidden;
    background: #fff;
  }

  .preview-shell__frame {
    width: 100%;
    height: 100%;
    border: none;
    background: #fff;
  }

  .preview-shell__frame--browser {
    flex: 1;
    min-height: 0;
  }
</style>
