<template>
  <n-el tag="div" class="tiptap-ai-modal" :style="themeStyleVars">
    <div ref="chatAreaRef" class="tiptap-ai-modal__chat">
      <div v-if="selectionText" class="tiptap-ai-modal__bubble tiptap-ai-modal__bubble--context">
        <div class="tiptap-ai-modal__bubble-label">{{ t('common.tiptap.aiSelection') }}</div>
        <div class="tiptap-ai-modal__bubble-text">{{ selectionText }}</div>
      </div>

      <div v-if="!messages.length" class="tiptap-ai-modal__empty">
        <div class="tiptap-ai-modal__empty-title">{{ props.action.label }}</div>
        <p class="tiptap-ai-modal__empty-description">
          {{ props.action.description }}
        </p>
      </div>

      <template v-for="(msg, idx) in messages" :key="idx">
        <div class="tiptap-ai-modal__bubble tiptap-ai-modal__bubble--user">
          <div class="tiptap-ai-modal__bubble-text">{{ msg.instruction }}</div>
        </div>

        <div class="tiptap-ai-modal__bubble tiptap-ai-modal__bubble--ai">
          <div v-if="msg.error" class="tiptap-ai-modal__error">
            {{ msg.error }}
          </div>
          <div v-else-if="msg.content" class="tiptap-ai-modal__result">
            <div v-html="cleanContent(msg.content)" />
          </div>
          <div
            v-else-if="isStreaming && idx === messages.length - 1"
            class="tiptap-ai-modal__typing"
          >
            {{ t('common.tiptap.aiGenerating') }}
          </div>
        </div>
      </template>
    </div>

    <div class="tiptap-ai-modal__input">
      <div class="tiptap-ai-modal__input-main">
        <div class="tiptap-ai-modal__input-head">
          <div class="tiptap-ai-modal__input-badge">
            <n-icon size="14"><RobotOutlined /></n-icon>
            <span>{{ props.action.label }}</span>
          </div>
          <span class="tiptap-ai-modal__input-caption">
            {{ inputDescription }}
          </span>
        </div>

        <div class="tiptap-ai-modal__input-surface">
          <n-input
            v-model:value="instruction"
            type="textarea"
            size="small"
            :autosize="{ minRows: 2, maxRows: 5 }"
            :disabled="isStreaming"
            :placeholder="t('common.tiptap.aiInstructionPlaceholder')"
            class="tiptap-ai-modal__textarea"
            @keydown.enter.exact.prevent="handleSend"
          />
        </div>
      </div>

      <div class="tiptap-ai-modal__input-actions">
        <n-button v-if="isStreaming" size="small" type="warning" secondary @click="handleStop">
          {{ t('common.tiptap.aiStopGenerate') }}
        </n-button>
        <n-button
          v-else
          size="small"
          type="primary"
          :disabled="!instruction.trim()"
          @click="handleSend"
        >
          <template #icon>
            <n-icon><RobotOutlined /></n-icon>
          </template>
          {{ t('common.tiptap.aiGenerateResult') }}
        </n-button>
      </div>
    </div>

    <div class="tiptap-ai-modal__footer">
      <span v-if="lastResult" class="tiptap-ai-modal__hint">
        {{ t('common.tiptap.aiApplyHint') }}
      </span>
      <span v-else />
      <div class="tiptap-ai-modal__footer-actions">
        <n-button size="small" @click="handleClose">
          {{ t('common.translate.cancel') }}
        </n-button>
        <n-button
          size="small"
          type="primary"
          :disabled="!lastResult || isStreaming"
          @click="handleApply"
        >
          {{ t('common.tiptap.aiApply') }}
        </n-button>
      </div>
    </div>
  </n-el>
</template>

<script setup lang="ts">
  import { computed, nextTick, onBeforeUnmount, reactive, ref } from 'vue';
  import { RobotOutlined } from '@vicons/antd';
  import { useThemeVars } from 'naive-ui';
  import { useI18n } from 'vue-i18n';
  import { useSSEStream } from '@/hooks';
  import type { TiptapAiActionDefinition, TiptapAiApplyPayload } from './types';

  interface ContentGenSSEEvent {
    type: 'chunk' | 'done' | 'error';
    content?: string;
    message?: string;
    code?: string;
    retryable?: boolean;
  }

  interface ChatMessage {
    instruction: string;
    content: string;
    error: string;
  }

  interface Props {
    action: TiptapAiActionDefinition;
    selection?: string;
    initialInstruction?: string;
    documentHtml?: string;
  }

  const props = withDefaults(defineProps<Props>(), {
    selection: '',
    initialInstruction: '',
    documentHtml: '',
  });

  const emit = defineEmits<{
    apply: [payload: TiptapAiApplyPayload];
    close: [];
  }>();

  const { t } = useI18n();
  const themeVars = useThemeVars();
  const { isStreaming, start, stop } = useSSEStream();
  const instruction = ref(props.initialInstruction || '');
  const messages = reactive<ChatMessage[]>([]);
  const chatAreaRef = ref<HTMLElement | null>(null);

  const selectionText = computed(() => props.selection.trim());
  const inputDescription = computed(
    () => props.action.description || t('common.tiptap.aiInstruction'),
  );
  const lastResult = computed(() => {
    for (let i = messages.length - 1; i >= 0; i--) {
      if (messages[i].content) return cleanContent(messages[i].content);
    }
    return '';
  });

  const themeStyleVars = computed(() => ({
    '--tiptap-ai-primary': themeVars.value.primaryColor,
    '--tiptap-ai-primary-hover': themeVars.value.primaryColorHover,
    '--tiptap-ai-border': themeVars.value.borderColor,
    '--tiptap-ai-surface': themeVars.value.cardColor,
    '--tiptap-ai-surface-muted': themeVars.value.actionColor,
    '--tiptap-ai-text': themeVars.value.textColor2,
    '--tiptap-ai-text-muted': themeVars.value.textColor3,
    '--tiptap-ai-danger': themeVars.value.errorColor,
  }));

  /**
   * 清洗 AI 返回内容：剥离 markdown code fence 并 trim
   * 例如 ```html\n<p>...</p>\n``` → <p>...</p>
   * 在展示和应用时统一调用，确保流式过程中也能正确渲染
   */
  function cleanContent(raw: string): string {
    return raw
      .replace(/^```[\w]*\n?/gm, '')
      .replace(/\n?```$/gm, '')
      .trim();
  }

  function scrollToBottom() {
    nextTick(() => {
      const el = chatAreaRef.value;
      if (el) el.scrollTop = el.scrollHeight;
    });
  }

  function buildRequestDto(userInstruction: string): any {
    return {
      action: props.action.key,
      content: selectionText.value || undefined,
      documentContext: props.documentHtml || undefined,
      instruction: userInstruction.trim() || undefined,
    };
  }

  async function handleSend() {
    const text = instruction.value.trim();
    if (!text || isStreaming.value) return;

    const msg: ChatMessage = reactive({ instruction: text, content: '', error: '' });
    messages.push(msg);
    instruction.value = '';
    scrollToBottom();

    await start<ContentGenSSEEvent>(
      {
        url: '/api/ai/content-gen/text',
        body: buildRequestDto(text),
      },
      {
        onEvent: (event) => {
          if (event.type === 'chunk' && event.content) {
            msg.content += event.content;
            scrollToBottom();
          } else if (event.type === 'error') {
            msg.error = event.message || t('common.tiptap.aiRequestFailed');
          }
        },
        onDone: () => {
          if (msg.content) {
            msg.content = cleanContent(msg.content);
          } else if (!msg.error) {
            msg.error = t('common.tiptap.aiEmptyResult');
          }
          scrollToBottom();
        },
        onError: (error) => {
          msg.error = error.message || t('common.tiptap.aiRequestFailed');
          scrollToBottom();
        },
      },
    );
  }

  function handleStop() {
    stop();
  }

  function handleApply() {
    const content = lastResult.value;
    if (!content) return;

    emit('apply', {
      action: props.action.key,
      result: content,
      hasSelection: !!selectionText.value,
    });
  }

  function handleClose() {
    emit('close');
  }

  onBeforeUnmount(() => {
    stop();
  });
</script>

<style scoped lang="less">
  .tiptap-ai-modal {
    height: min(60vh, 560px);
    display: flex;
    flex-direction: column;
    gap: 12px;
    padding: 4px;
  }

  .tiptap-ai-modal__chat {
    flex: 1;
    min-height: 0;
    display: flex;
    flex-direction: column;
    gap: 12px;
    padding: 6px 4px 0 0;
    overflow-y: auto;
  }

  .tiptap-ai-modal__bubble {
    max-width: 88%;
    border-radius: 18px;
    padding: 12px 14px;
    word-break: break-word;
    box-shadow: 0 10px 24px rgba(15, 23, 42, 0.06);
  }

  .tiptap-ai-modal__bubble-text {
    margin-top: 4px;
    font-size: 13px;
    line-height: 1.7;
  }

  .tiptap-ai-modal__bubble--context {
    align-self: center;
    max-width: 100%;
    border: 1px dashed color-mix(in srgb, var(--tiptap-ai-primary) 32%, #dbe3ef);
    background: color-mix(in srgb, var(--tiptap-ai-primary) 8%, #ffffff);
    color: var(--tiptap-ai-text-muted);
  }

  .tiptap-ai-modal__bubble-label {
    font-size: 11px;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.04em;
    color: var(--tiptap-ai-text-muted);
  }

  .tiptap-ai-modal__bubble--user {
    margin-left: auto;
    background: linear-gradient(135deg, var(--tiptap-ai-primary), var(--tiptap-ai-primary-hover));
    color: #fff;
    border-bottom-right-radius: 6px;
  }

  .tiptap-ai-modal__bubble--ai {
    margin-right: auto;
    border: 1px solid var(--tiptap-ai-border);
    background: var(--tiptap-ai-surface);
    color: var(--tiptap-ai-text);
    border-bottom-left-radius: 6px;
  }

  .tiptap-ai-modal__error {
    font-size: 13px;
    line-height: 1.6;
    color: var(--tiptap-ai-danger);
  }

  .tiptap-ai-modal__typing {
    font-size: 13px;
    color: var(--tiptap-ai-text-muted);
  }

  .tiptap-ai-modal__empty {
    display: grid;
    gap: 6px;
    padding: 18px;
    border: 1px dashed var(--tiptap-ai-border);
    border-radius: 18px;
    background: var(--tiptap-ai-surface-muted);
    color: var(--tiptap-ai-text-muted);
  }

  .tiptap-ai-modal__empty-title {
    font-size: 13px;
    font-weight: 700;
    color: var(--tiptap-ai-text);
  }

  .tiptap-ai-modal__empty-description {
    margin: 0;
    font-size: 12px;
    line-height: 1.6;
  }

  .tiptap-ai-modal__input {
    display: flex;
    gap: 10px;
    align-items: stretch;
    padding: 14px;
    border: 1px solid var(--tiptap-ai-border);
    border-radius: 20px;
    background: var(--tiptap-ai-surface);
    box-shadow: 0 12px 30px rgba(15, 23, 42, 0.05);
  }

  .tiptap-ai-modal__input-main {
    min-width: 0;
    flex: 1;
    display: grid;
    gap: 10px;
  }

  .tiptap-ai-modal__input-head {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 12px;
    min-width: 0;
  }

  .tiptap-ai-modal__input-badge {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    min-width: 0;
    padding: 6px 10px;
    border-radius: 999px;
    background: color-mix(in srgb, var(--tiptap-ai-primary) 10%, #ffffff);
    color: var(--tiptap-ai-primary);
    font-size: 12px;
    font-weight: 700;
  }

  .tiptap-ai-modal__input-caption {
    min-width: 0;
    font-size: 12px;
    line-height: 1.5;
    color: var(--tiptap-ai-text-muted);
    text-align: right;
  }

  .tiptap-ai-modal__input-surface {
    min-width: 0;
    padding: 2px;
    border-radius: 16px;
    background: linear-gradient(
      180deg,
      color-mix(in srgb, var(--tiptap-ai-primary) 6%, #ffffff),
      var(--tiptap-ai-surface-muted)
    );
  }

  .tiptap-ai-modal__input-actions {
    display: flex;
    flex-shrink: 0;
    flex-direction: column;
    justify-content: space-between;
    gap: 6px;
  }

  .tiptap-ai-modal__textarea {
    flex: 1;
  }

  .tiptap-ai-modal__textarea :deep(.n-input) {
    border-radius: 14px;
    background: rgba(255, 255, 255, 0.92);
  }

  .tiptap-ai-modal__textarea :deep(.n-input-wrapper) {
    padding-top: 10px;
    padding-bottom: 10px;
  }

  .tiptap-ai-modal__textarea :deep(.n-input__textarea-el) {
    line-height: 1.7;
  }

  .tiptap-ai-modal__footer {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 12px;
    padding: 0 4px 2px;
  }

  .tiptap-ai-modal__footer-actions {
    display: flex;
    gap: 10px;
  }

  .tiptap-ai-modal__result :deep(p) {
    margin: 0.4em 0;
  }

  .tiptap-ai-modal__result :deep(ul),
  .tiptap-ai-modal__result :deep(ol) {
    padding-left: 1.2em;
    margin: 0.4em 0;
  }

  .tiptap-ai-modal__hint {
    font-size: 12px;
    color: var(--tiptap-ai-text-muted);
  }
</style>
