import { h } from 'vue';
import { NEllipsis, NTag } from 'naive-ui';
import { currency } from '@/utils';

type CascaderOption = {
  label: string;
  value: string | number;
  children?: Array<{ label: string; value: string | number }>;
};

// ProDataTable 的默认 cell 渲染路径会同时透传 column.ellipsis 给 naive-ui + 内部又包一层 NEllipsis，
// 两套省略互相干扰，导致 td 被裁但不显示 "..."。这里改用自定义 render 直接产出 NEllipsis VNode。
function renderEllipsisCell(value: unknown) {
  const text = value == null || value === '' ? '--' : String(value);
  return h(NEllipsis, { tooltip: true }, () => text);
}

/**
 * 账变信息搜索列配置
 */
export function createFundSearchColumns(
  t: (key: string) => string,
  typeCascaderOptions: CascaderOption[],
  isSample = false,
) {
  // 账变类型控件（pilot 收窄·2026-07-13·仅会员 1100002）：
  //   样板 → 对齐财务·资金账变的「可勾选树 treeSelect」（checkStrategy='child'·可同时展开多分支/含厂商游戏层，
  //          值经 useFundRecord 的 parseFinancialTypeMatchers → typeMatchers，与财务同源 mock）。
  //   其它会员 → 保持原「级联 cascader（checkStrategy='parent'）」（值经 expandFinancialTypeValue → type）。二者不混。
  const changeTypeColumn = isSample
    ? {
        path: 'changeType',
        label: t('member.detail.fund.changeType'),
        valueType: 'treeSelect' as const,
        options: typeCascaderOptions,
        componentProps: {
          clearable: true,
          multiple: true,
          checkable: true,
          cascade: true,
          checkStrategy: 'child',
          keyField: 'value',
          maxTagCount: 'responsive',
          filterable: true,
          placeholder: t('member.detail.fund.changeType'),
          virtualScroll: false,
          consistentMenuWidth: false,
          menuProps: { class: 'fundchange-type-tree-menu' },
        },
      }
    : {
        path: 'changeType',
        label: t('member.detail.fund.changeType'),
        valueType: 'cascader' as const,
        options: typeCascaderOptions,
        componentProps: {
          clearable: true,
          multiple: true,
          cascade: true,
          checkStrategy: 'parent',
          maxTagCount: 'responsive',
          filterable: true,
          placeholder: t('member.detail.fund.changeType'),
        },
      };
  return [
    {
      path: 'orderNo',
      label: t('member.detail.fund.orderNo'),
      valueType: 'text' as const,
      componentProps: { clearable: true },
    },
    changeTypeColumn,
    {
      path: 'operator',
      label: t('common.operator'),
      valueType: 'text' as const,
      componentProps: { clearable: true },
    },
    {
      path: 'timeRange',
      label: t('member.detail.fund.timeRange'),
      valueType: 'proDateRange' as const,
      placeholder: t('member.detail.fund.selectTimeRange'),
      order: 99,
      span: 2,
      componentProps: {
        valueFormat: 'string',
        displayFormat: 'yyyy-MM-dd HH:mm:ss',
        maxDays: 180,
        allowFuture: false,
        shortcuts: false,
        // 首屏默认 today；picker 的 fillback 已限定为只在 mount 触发，
        // quick-date "所有" 按钮清空时不会被重新 fillback（见 ProSelectDateRange.vue）
        defaultShortcut: 'today',
        // 展平写回：起 → form.startTime，止 → form.endTime
        modelKeys: ['startTime', 'endTime'],
      },
    },
  ];
}

/**
 * 账变信息表格列配置
 */
export function createFundColumns(
  t: (key: string) => string,
  getCurrency?: (tenantId?: string | number | null) => string,
  typeLabelMap: Map<string | number, string> = new Map(),
  isSample = false,
) {
  // 注：列 key 是 useFundRecord.loadData 重映射后的别名，导出 export 需映回 FinanceRecordRsp 真实字段名
  const cols = [
    {
      key: 'orderNo',
      title: t('member.detail.fund.orderNo'),
      width: 160,
      export: 'orderNum',
      render: (row) => renderEllipsisCell(row.orderNo),
    },
    {
      key: 'type',
      title: t('member.detail.fund.changeType'),
      width: 120,
      // 导出真实字段为后端账变类型展示文本 typeName
      export: 'typeName',
      render: (row) => typeLabelMap.get(row.type) ?? typeLabelMap.get(String(row.type)) ?? '--',
    },
    {
      key: 'currency',
      title: t('member.detail.fund.currency'),
      width: 80,
      export: 'sysCurrency',
      render: (row) => {
        const val = getCurrency?.(row.tenantId);
        return val ? h(NTag, { size: 'small', type: 'success' }, () => val) : '--';
      },
    },
    {
      key: 'beforeBalance',
      title: t('member.detail.fund.beforeBalance'),
      width: 110,
      export: 'beforeAmount',
      render: (row) => currency(row.beforeBalance),
    },
    {
      key: 'amount',
      title: t('member.detail.fund.changeAmount'),
      width: 130,
      render(row) {
        const n = row.amount ?? 0;
        const str = currency(n);
        const isNegative = String(str).startsWith('-');
        const display = isNegative ? str : `+${str}`;
        const color = isNegative ? '#dc2626' : '#16a34a';
        return h('span', { style: `color: ${color}; font-weight: 600;` }, display);
      },
    },
    {
      key: 'afterBalance',
      title: t('member.detail.fund.afterBalance'),
      width: 110,
      export: 'backAmount',
      render: (row) => currency(row.afterBalance),
    },
    {
      key: 'remarkDisplay',
      title: t('member.detail.fund.remarkDesc'),
      width: 120,
      render: (row) => renderEllipsisCell(row.remarkDisplay),
    },
    { key: 'operator', title: t('common.operator'), width: 80, export: 'reserved' },
  ];
  // 账变时间列序（pilot 收窄·2026-07-13·仅会员 1100002）：
  //   样板 → 对齐财务·资金账变：置于「变更后余额」之后、「备注说明」之前（R44）。
  //   其它会员 → 保持原样：账变时间在最末列。
  const timeCol = {
    key: 'time',
    title: t('member.detail.fund.changeTime'),
    width: 160,
    export: 'addTimeStr',
    // useFundRecord 会把本列 title 改写为带时区后缀的 VNode；导出取不到字符串标题，
    // 这里用 columnSettingTitle 提供纯文本表头兜底
    columnSettingTitle: t('member.detail.fund.changeTime'),
  };
  if (isSample) cols.splice(6, 0, timeCol);
  else cols.push(timeCol);
  return cols;
}
