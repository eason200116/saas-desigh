import { addDays, format } from 'date-fns';
import {
  AppstoreAddOutlined,
  BlockOutlined,
  CalendarOutlined,
  CodeOutlined,
  ColumnWidthOutlined,
  InsertRowAboveOutlined,
  LinkOutlined,
  NotificationOutlined,
  PicCenterOutlined,
  RobotOutlined,
  TableOutlined,
} from '@vicons/antd';
import { buildOpsTemplateHtml } from '@/components/Translate/opsTemplateConfig';
import { getEditorProfileConfig } from './profiles';
import type {
  TiptapAiActionType,
  TiptapEditorProfile,
  TiptapQuickActionGroup,
  TiptapQuickActionGroupSection,
  TiptapQuickActionItem,
} from './types';

interface CreateQuickActionOptions {
  t: (key: string) => string;
  profile: TiptapEditorProfile;
  onLink: () => void;
  onImage: () => void;
  onAiAction: (action: TiptapAiActionType) => void;
}

interface GroupQuickActionOptions {
  query?: string;
  activeGroup?: TiptapQuickActionGroup | 'all';
  groupLabelMap: Record<TiptapQuickActionGroup, string>;
}

export const TIPTAP_QUICK_ACTION_GROUP_ORDER: TiptapQuickActionGroup[] = [
  'format',
  'blocks',
  'templates',
  'ai',
];

export function createQuickActionGroupLabelMap(t: (key: string) => string) {
  return {
    format: t('common.tiptap.insertGroupFormat'),
    blocks: t('common.tiptap.insertGroupBlocks'),
    templates: t('common.tiptap.insertGroupTemplates'),
    ai: t('common.tiptap.insertGroupAi'),
  } satisfies Record<TiptapQuickActionGroup, string>;
}

export function createQuickActionItems(options: CreateQuickActionOptions): TiptapQuickActionItem[] {
  const { t } = options;
  const profileConfig = getEditorProfileConfig(options.profile);

  return [
    {
      key: 'link',
      label: t('common.tiptap.link'),
      description: t('common.tiptap.quickLinkDescription'),
      group: 'format',
      keywords: ['link', 'url', 'href'],
      icon: LinkOutlined,
      run: ({ onLink }) => onLink(),
    },
    {
      key: 'image',
      label: t('common.tiptap.image'),
      description: t('common.tiptap.quickImageDescription'),
      group: 'format',
      keywords: ['image', 'photo', 'picture'],
      icon: PicCenterOutlined,
      isVisible: () => profileConfig.allowImages,
      run: ({ onImage }) => onImage(),
    },
    {
      key: 'divider',
      label: t('common.tiptap.divider'),
      description: t('common.tiptap.quickDividerDescription'),
      group: 'format',
      keywords: ['divider', 'hr', 'line'],
      icon: InsertRowAboveOutlined,
      canRun: (editor) => editor.can().chain().focus().setHorizontalRule().run(),
      run: ({ editor }) => {
        editor.chain().focus().setHorizontalRule().run();
      },
    },
    {
      key: 'codeBlock',
      label: t('common.tiptap.codeBlock'),
      description: t('common.tiptap.quickCodeBlockDescription'),
      group: 'format',
      keywords: ['code', 'snippet'],
      icon: CodeOutlined,
      canRun: (editor) => editor.can().chain().focus().toggleCodeBlock().run(),
      run: ({ editor }) => {
        editor.chain().focus().toggleCodeBlock().run();
      },
    },
    {
      key: 'insertTable',
      label: t('common.tiptap.table'),
      description: t('common.tiptap.quickTableDescription'),
      group: 'format',
      keywords: ['table', 'grid'],
      icon: TableOutlined,
      isVisible: () => profileConfig.allowTables,
      canRun: (editor) =>
        editor.can().chain().focus().insertTable({ rows: 3, cols: 3, withHeaderRow: true }).run(),
      run: ({ editor }) => {
        editor.chain().focus().insertTable({ rows: 3, cols: 3, withHeaderRow: true }).run();
      },
    },
    {
      key: 'callout',
      label: t('common.tiptap.calloutBlock'),
      description: t('common.tiptap.quickCalloutDescription'),
      group: 'blocks',
      keywords: ['callout', 'highlight', 'notice'],
      icon: NotificationOutlined,
      isVisible: () => profileConfig.allowAdvancedBlocks,
      canRun: (editor) => editor.can().chain().focus().insertCalloutBlock().run(),
      run: ({ editor }) => {
        editor.chain().focus().insertCalloutBlock({ tone: 'info' }).run();
      },
    },
    {
      key: 'status',
      label: t('common.tiptap.statusBlock'),
      description: t('common.tiptap.quickStatusDescription'),
      group: 'blocks',
      keywords: ['status', 'badge', 'tag'],
      icon: AppstoreAddOutlined,
      isVisible: () => profileConfig.allowAdvancedBlocks,
      canRun: (editor) => editor.can().chain().focus().insertStatusBlock().run(),
      run: ({ editor }) => {
        editor.chain().focus().insertStatusBlock({ tone: 'success' }).run();
      },
    },
    {
      key: 'date',
      label: t('common.tiptap.dateBlock'),
      description: t('common.tiptap.quickDateDescription'),
      group: 'blocks',
      keywords: ['date', 'time', 'schedule'],
      icon: CalendarOutlined,
      isVisible: () => profileConfig.allowAdvancedBlocks,
      canRun: (editor) => editor.can().chain().focus().insertDateBlock().run(),
      run: ({ editor }) => {
        editor
          .chain()
          .focus()
          .insertDateBlock({
            label: t('common.tiptap.dateBlockDefaultLabel'),
            date: format(new Date(), 'yyyy-MM-dd'),
          })
          .run();
      },
    },
    {
      key: 'columns',
      label: t('common.tiptap.columnsBlock'),
      description: t('common.tiptap.quickColumnsDescription'),
      group: 'blocks',
      keywords: ['columns', 'layout', '2col'],
      icon: ColumnWidthOutlined,
      isVisible: () => profileConfig.allowAdvancedBlocks,
      canRun: (editor) => editor.can().chain().focus().insertOpsColumns().run(),
      run: ({ editor }) => {
        editor.chain().focus().insertOpsColumns().run();
      },
    },
    {
      key: 'templateAnnouncement',
      label: t('common.tiptap.templateAnnouncement'),
      description: t('common.tiptap.quickAnnouncementTemplateDescription'),
      group: 'templates',
      keywords: ['template', 'announcement'],
      icon: NotificationOutlined,
      isVisible: () => profileConfig.allowTemplates,
      run: ({ editor }) => {
        const currentDate = format(new Date(), 'yyyy-MM-dd');
        const nextDate = format(addDays(new Date(), 1), 'yyyy-MM-dd');
        editor
          .chain()
          .focus()
          .insertContent(buildOpsTemplateHtml('announcement', { currentDate, nextDate }))
          .run();
      },
    },
    {
      key: 'templateActivity',
      label: t('common.tiptap.templateActivity'),
      description: t('common.tiptap.quickActivityTemplateDescription'),
      group: 'templates',
      keywords: ['template', 'activity', 'campaign'],
      icon: BlockOutlined,
      isVisible: () => profileConfig.allowTemplates,
      run: ({ editor }) => {
        const currentDate = format(new Date(), 'yyyy-MM-dd');
        const nextDate = format(addDays(new Date(), 7), 'yyyy-MM-dd');
        editor
          .chain()
          .focus()
          .insertContent(buildOpsTemplateHtml('activity', { currentDate, nextDate }))
          .run();
      },
    },
    {
      key: 'templateRule',
      label: t('common.tiptap.templateRule'),
      description: t('common.tiptap.quickRuleTemplateDescription'),
      group: 'templates',
      keywords: ['template', 'rule'],
      icon: BlockOutlined,
      isVisible: () => profileConfig.allowTemplates,
      run: ({ editor }) => {
        const currentDate = format(new Date(), 'yyyy-MM-dd');
        const nextDate = format(addDays(new Date(), 1), 'yyyy-MM-dd');
        editor
          .chain()
          .focus()
          .insertContent(buildOpsTemplateHtml('rule', { currentDate, nextDate }))
          .run();
      },
    },
    {
      key: 'aiContinue',
      label: t('common.tiptap.aiContinue'),
      description: t('common.tiptap.aiContinueDescription'),
      group: 'ai',
      keywords: ['ai', 'continue', 'extend'],
      icon: RobotOutlined,
      isVisible: () => profileConfig.allowAi,
      run: ({ onAiAction }) => onAiAction('continue'),
    },
    {
      key: 'aiGenerate',
      label: t('common.tiptap.aiGenerate'),
      description: t('common.tiptap.aiGenerateDescription'),
      group: 'ai',
      keywords: ['ai', 'generate', 'activity'],
      icon: RobotOutlined,
      isVisible: () => profileConfig.allowAi,
      run: ({ onAiAction }) => onAiAction('generate'),
    },
    {
      key: 'aiPolish',
      label: t('common.tiptap.aiPolish'),
      description: t('common.tiptap.aiPolishDescription'),
      group: 'ai',
      keywords: ['ai', 'polish', 'tone'],
      icon: RobotOutlined,
      isVisible: () => profileConfig.allowAi,
      run: ({ onAiAction }) => onAiAction('polish'),
    },
  ];
}

export function filterQuickActionItems(items: TiptapQuickActionItem[], query: string) {
  const normalizedQuery = query.trim().toLowerCase();
  if (!normalizedQuery) return items;

  return items.filter((item) => {
    const haystack = [item.label, item.description, ...item.keywords].join(' ').toLowerCase();
    return haystack.includes(normalizedQuery);
  });
}

export function groupQuickActionItems(
  items: TiptapQuickActionItem[],
  options: GroupQuickActionOptions,
): TiptapQuickActionGroupSection[] {
  const filteredItems = filterQuickActionItems(items, options.query || '');

  return TIPTAP_QUICK_ACTION_GROUP_ORDER.filter(
    (groupKey) => options.activeGroup === 'all' || options.activeGroup === groupKey,
  )
    .map((groupKey) => ({
      key: groupKey,
      label: options.groupLabelMap[groupKey],
      items: filteredItems.filter((item) => item.group === groupKey),
    }))
    .filter((group) => group.items.length);
}
