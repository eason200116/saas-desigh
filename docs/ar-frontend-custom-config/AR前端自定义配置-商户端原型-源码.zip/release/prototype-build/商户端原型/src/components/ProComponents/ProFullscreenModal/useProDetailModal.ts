/**
 * @description 弹窗业务入口层 composable：组合 useModal + useFullscreenModalState + renderFullscreenTitle 三层，向业务暴露 open(options) 一行 API，自带全屏切换与状态机。是 ProFullscreenModal 基座的最高层。
 * @date 2026-05-08
 * @scope src/components/ProComponents/ProFullscreenModal
 */

import { useModal } from 'naive-ui';
import { h, type CSSProperties, type Ref, type VNodeChild } from 'vue';
import { DEFAULT_NORMAL_MODAL_STYLE, MODAL_FULLSCREEN_STYLE } from './constants';
import ProModalContentRect from './ProModalContentRect.vue';
import { renderFullscreenTitle } from './renderFullscreenTitle';
import { useFullscreenModalState } from './useFullscreenModalState';

/** 业务回调获取的运行时上下文：当前全屏状态 + 切换函数 + 主动关闭 */
export interface ProDetailModalContext {
  isFullscreen: Ref<boolean>;
  toggleFullscreen: () => void;
  /** 主动关闭弹窗（与外部 instance.close() / X 按钮等价；触发 onClose 一次） */
  close: () => void;
}

/** open() 选项 */
export interface ProDetailModalOpenOptions {
  /**
   * 标题。
   * - string：用默认渲染器渲染「标题文字 + 全屏按钮」。
   * - function：业务自渲染，可注入审单耗时 / Reviewing tag 等复杂结构；从 ctx 接收 isFullscreen 与 toggleFullscreen。
   */
  title: string | ((ctx: ProDetailModalContext) => VNodeChild);
  /** 弹窗内容渲染器；同样从 ctx 接收 isFullscreen，内部组件可据此调整布局密度 */
  content: (ctx: ProDetailModalContext) => VNodeChild;
  /** 常态弹窗样式；默认 DEFAULT_NORMAL_MODAL_STYLE */
  normalStyle?: CSSProperties;
  /** 全屏弹窗样式；默认 MODAL_FULLSCREEN_STYLE */
  fullscreenStyle?: CSSProperties;
  /**
   * 透传给 modal.create 的其他参数（preset / bordered / maskClosable / closeOnEsc 等）。
   * 注意 title / content / style / onClose 由基座托管，传了也会被覆盖。
   */
  modalProps?: Record<string, unknown>;
  /** 弹窗关闭后清理回调（X 按钮关闭或主动 close() 都触发，且只触发一次） */
  onClose?: () => void;
}

/** open() 返回的弹窗实例 */
export interface ProDetailModalInstance {
  /** 主动关闭（与 X 按钮关闭等价；都会触发 onClose 一次） */
  close: () => void;
  /** 当前是否全屏（响应式） */
  isFullscreen: Ref<boolean>;
  /** 主动切换全屏 */
  toggleFullscreen: () => void;
}

export interface UseProDetailModalReturn {
  open: (options: ProDetailModalOpenOptions) => ProDetailModalInstance;
}

/**
 * 业务层一行接入弹窗 + 全屏的 composable。
 *
 * 必须在 setup 上下文调用（依赖 Naive UI useModal）。
 *
 * @example
 * ```ts
 * const detailModal = useProDetailModal();
 *
 * function openOrderDetail(row) {
 *   detailModal.open({
 *     title: t('finance.detail.title'),
 *     normalStyle: { width: 'min(1600px, 98vw)' },
 *     content: () => h(SomeDetailModal, { row, ... }),
 *   });
 * }
 * ```
 */
export function useProDetailModal(): UseProDetailModalReturn {
  const modal = useModal();

  return {
    open(options) {
      const state = useFullscreenModalState(
        options.normalStyle ?? DEFAULT_NORMAL_MODAL_STYLE,
        options.fullscreenStyle ?? MODAL_FULLSCREEN_STYLE,
      );

      let modalInstance: ReturnType<typeof modal.create> | null = null;
      let isClosed = false;

      const fireOnClose = () => {
        if (isClosed) return;
        isClosed = true;
        options.onClose?.();
      };

      const close = () => {
        if (!modalInstance) return;
        fireOnClose();
        modalInstance.destroy();
        modalInstance = null;
      };

      const ctx: ProDetailModalContext = {
        isFullscreen: state.isFullscreen,
        toggleFullscreen: () => {
          state.toggleFullscreen();
          // 命令式更新 modal.style 让宽高立即生效（Naive UI modal 内部对 style 的响应不如直接赋值稳）
          if (modalInstance) {
            modalInstance.style = state.currentStyle.value;
          }
        },
        close,
      };

      const renderTitle = () => {
        const titleOpt = options.title;
        if (typeof titleOpt === 'string') {
          return renderFullscreenTitle({
            title: titleOpt,
            isFullscreen: state.isFullscreen,
            onToggle: ctx.toggleFullscreen,
          });
        }
        return titleOpt(ctx);
      };

      modalInstance = modal.create({
        preset: 'card',
        bordered: false,
        maskClosable: false,
        closeOnEsc: false,
        ...options.modalProps,
        title: renderTitle,
        // 用 ProModalContentRect 包一层：在弹窗内 provide LayoutContentRectKey，
        // 让被嵌组件（如 LotteryTab / 会员银行卡管理 等独立页面）内部的 ProCrudTable
        // useAutoHeight inject 到弹窗真实可视底，避免回退 viewport 兜底导致 max-height
        // 算大、出现底部留白 / 表格被裁的问题。
        content: () => h(ProModalContentRect, null, { default: () => options.content(ctx) }),
        style: state.currentStyle.value,
        onClose: fireOnClose,
      });

      return {
        close,
        isFullscreen: state.isFullscreen,
        toggleFullscreen: ctx.toggleFullscreen,
      };
    },
  };
}
