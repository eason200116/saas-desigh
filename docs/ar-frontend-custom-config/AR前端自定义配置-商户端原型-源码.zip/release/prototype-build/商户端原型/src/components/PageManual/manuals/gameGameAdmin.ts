// 商户游戏管理（总控端 admin · game_game）功能说明书。
// 锚定 src/views/game/game/index.vue + data.ts + components/MerchantBindModal.vue、MerchantGameStateModal.vue 真实控件（R53 实证、不臆造）。
// 标准 ProCrudTable 列表页：7 搜索项 + 11 列 + 顶部「绑定商户」+ 2 行操作。
// 本页容易混淆点：同一行有两个「状态」——merchantState（本商户能否用该厂商，本页可改）与
// vendorState（厂商自身是否启用，只读，真正入口在「游戏厂商管理」页）；本说明书按 R53 分开讲清楚，不混为一谈。

import type { PageManual } from '../types';

const manual: PageManual = {
  route: 'game_game',
  title: '商户游戏管理',
  overview:
    '总控端全局查看/管理「所有商户 × 厂商」的游戏开通状态：按商户、游戏大类、厂商编码/名称、支持币种/语言、商户游戏状态搜索列表；「商户游戏状态」（本商户能否用该厂商游戏）在行操作「状态」弹窗内用开关切换，「厂商游戏状态」列只读展示（真正入口在「游戏厂商管理」页）；顶部「绑定商户」新增「商户 × 厂商」记录（单选商户、多选厂商，每选一个厂商生成一条独立记录）；行操作「查看子游戏」跳转子游戏管理页并按本行厂商编码预筛。列表按搜索条件过滤、默认居中展示。',
  items: [
    // ============ 搜索区（点了联动）============
    {
      anchor: 'merchantId',
      name: '商户名称',
      group: '搜索',
      interaction: '下拉单选、可清空。',
      dataSource: '商户选项，来自共享商户池 GAME_MERCHANT_LIST（MERCHANT_LIST），覆盖平台各商户。',
      logic: '筛选该商户名下的「商户 × 厂商」记录。',
      limit: '选填。',
      edge: '不选 = 不按商户筛，显示全部商户的记录。',
    },
    {
      anchor: 'categoryType',
      name: '游戏大类',
      group: '搜索',
      interaction: '下拉单选、可清空。',
      dataSource:
        '来自共享「游戏主类型配置」主数据（mainTypeOptions，与总控「游戏厂商管理」页同一套主类型，按 sort 排序）。',
      logic: '筛出该大类厂商的记录（按大类精确匹配）。',
      limit: '选填。',
      edge: '不选 = 不按大类筛，显示全部大类。',
    },
    {
      anchor: 'vendorCode',
      name: '厂商编码',
      group: '搜索',
      interaction: '文本输入、模糊匹配。',
      dataSource: '用户输入。',
      logic: '按厂商编码模糊筛选（不区分大小写）。',
      limit: '选填；最多 50 字，禁止输入控制字符（inputProps searchKw 预设）。',
      edge: '空 = 不按编码筛；查询时前后空格自动去除（data.ts 内 trim 处理）。',
    },
    {
      anchor: 'vendorName',
      name: '厂商名称',
      group: '搜索',
      interaction: '文本输入、模糊匹配。',
      dataSource: '用户输入。',
      logic: '按厂商中文名或英文名模糊筛选（不区分大小写）。',
      limit: '选填；最多 50 字，禁止输入控制字符（inputProps searchKw 预设）。',
      edge: '空 = 不按名称筛；查询时前后空格自动去除。',
    },
    {
      anchor: 'currency',
      name: '支持币种',
      group: '搜索',
      interaction: '下拉单选、可清空。',
      dataSource: '币种选项（CURRENCY_OPTIONS：INR / BRL / VND / PKR）。',
      logic: '筛出「支持币种」列包含所选币种的记录。',
      limit: '选填。',
      edge: '不选 = 不按币种筛。',
    },
    {
      anchor: 'language',
      name: '支持语言',
      group: '搜索',
      interaction: '下拉单选、可清空。',
      dataSource:
        '语言选项（LANGUAGE_OPTIONS：English / Chinese / Thai / Vietnamese / Indonesian / Portuguese）。',
      logic: '筛出「支持语言」列包含所选语言的记录。',
      limit: '选填。',
      edge: '不选 = 不按语言筛。',
    },
    {
      anchor: 'search_state',
      name: '商户游戏状态（搜索）',
      group: '搜索',
      interaction: '下拉单选：启用 / 禁用，可清空。',
      dataSource: '本地固定枚举（启用 = 1 / 禁用 = 0）。',
      logic: '按该行「商户游戏状态」（本商户能否使用该厂商游戏）筛选列表。',
      limit: '选填。',
      edge: '不选 = 全部状态都显示。',
    },

    // ============ 关键列（状态列点了联动）============
    {
      anchor: 'col_state',
      name: '商户游戏状态列',
      group: '列',
      interaction: '只读 Tag：启用绿 / 禁用红，不可点。',
      dataSource: '行数据 merchantState（1 = 启用 / 0 = 禁用）。',
      logic: '仅展示「该商户能否用该厂商游戏」的当前状态；要改状态走右侧行操作「状态」弹窗里的开关。',
      note:
        '本页有意破例 R47：列用只读 Tag、开关移到弹窗。同行「厂商游戏状态」列（vendorState）是另一独立只读字段——展示厂商自身是否启用，真正入口在「游戏厂商管理」页，本页不提供编辑，仅在字段介绍 tab 里说明定义，别与本列混为一谈。',
    },

    // ============ 操作（顶部绑定商户 + 2 行操作）============
    {
      anchor: 'act_add',
      name: '绑定商户（顶部）',
      group: '操作',
      interaction:
        '点击顶部「绑定商户」开新增弹窗（约 700px）：先单选商户，再从「该商户还未绑定」的厂商里多选（可全选 / 清空），确认后每选中一个厂商生成一条独立记录。',
      dataSource:
        '商户选项 getMerchantOptions；换商户后按 getBindableVendors(merchantId) 取该商户「还能绑哪些」厂商——已绑过的厂商直接不出现在勾选项里。',
      logic:
        '保存后刷新列表；新记录 merchantState 默认启用(1)，vendorState 取该厂商在「游戏厂商管理」页的真实启停态（只读、不在本弹窗另设）。',
      limit: '商户必选；厂商至少勾选一个，否则报错提示。',
      edge: '该商户已绑完全部厂商 = 勾选区显示「该商户已绑定全部厂商」空态、无厂商可选；未选商户时勾选区提示「请先选择商户」。',
      note:
        'V3 新增入口（用户 2026-07-15 定）：源站绑定入口在「商户管理·游戏自定义通道」、不在游戏组，V3 无此页故在本页加此入口，是有意偏离源站。',
    },
    {
      anchor: 'act_state',
      name: '行操作 · 状态',
      group: '操作',
      interaction:
        '点击开窄弹窗（约 460px）：信息行展示商户名 / 厂商名，用开关改该「商户 × 厂商」的商户游戏状态。',
      dataSource: '弹窗初值取该行 merchantState，无需再拉详情接口。',
      logic:
        '保存后刷新列表；这是本页真正改「商户游戏状态」的入口（R47 开关在弹窗）。弹窗内小字提示会影响该厂商在本商户下的全部游戏。',
      note: '与「厂商游戏状态」（vendorState 列）不是一回事：本操作只改「本商户能否用该厂商」，厂商自身是否启用要去「游戏厂商管理」页改。',
    },
    {
      anchor: 'act_viewSubGame',
      name: '行操作 · 查看子游戏',
      group: '操作',
      interaction: '点击跳转子游戏管理页，并按本行厂商编码（vendorCode）预筛。',
      dataSource: '取本行 row.vendorCode 作为跳转查询参数。',
      logic: '跳转子游戏管理页；商户维度到此为止——跳转后只按厂商预筛，子游戏管理页本身没有商户这一层。',
      note:
        '这是跳转类操作、非弹窗，对源站有意偏离：早期版本此处是「查看子游戏」弹窗，2026-07-15 改为跳整页；原弹窗组件 SubGameViewModal / SubGameStateModal 仍保留在磁盘、只是没了入口，不是死代码。',
    },
  ],

  // ============ 字段介绍 tab（仅列表的列 + 定义；顺序同列表列序 R44）============
  fields: [
    { name: '商户名称', def: '该记录所属的商户。' },
    { name: '厂商名称', def: '第三方游戏厂商的名称。' },
    { name: '厂商编码', def: '厂商的唯一标识编码（如 CQ9 / PP / EVO_Video）。' },
    { name: '游戏大类', def: '厂商所属的游戏主类型（电子 / 真人 / 彩票等）。' },
    { name: '支持语言', def: '该厂商游戏可展示的语言清单。' },
    { name: '支持币种', def: '该厂商可结算的币种清单。' },
    { name: '商户游戏状态', def: '该商户能否使用该厂商游戏：启用 / 禁用。' },
    { name: '厂商游戏状态', def: '该厂商自身当前的启用 / 禁用状态（只读，入口在「游戏厂商管理」页）。' },
    { name: '创建时间', def: '该记录创建时间（按商户时区展示）。' },
    { name: '更新时间', def: '该记录最近一次修改的时间（按商户时区展示）。' },
    { name: '操作人', def: '最近一次创建 / 修改该记录的操作账号。' },
  ],
};

export default manual;
