export { default as MemberDetailContent } from './MemberDetailContent.vue';
export { default as MemberDetailShell } from './MemberDetailShell.vue';
// BettingOrderDetailModal 已迁至 @/views/game/betRecord/components/BettingOrderDetailModal.vue
// （属于 betRecord 模块对外暴露的详情入口，消费方走 useUser().openBettingOrderDetailModal）
