<script setup lang="ts">
  import { computed } from 'vue';
  import DynamicCard from './DynamicCard.vue';
  import type { any } from './types';

  interface Props {
    /** 卡片列表 */
    cards: any[];
    /** 加载中的卡片 ID 集合 */
    loadingCardIds?: Set<string>;
    /** 列数 */
    cols?: number;
    /** 间距 */
    gap?: number;
    /** 是否显示操作按钮 */
    showActions?: boolean;
  }

  const props = withDefaults(defineProps<Props>(), {
    loadingCardIds: () => new Set(),
    cols: 24,
    gap: 12,
    showActions: true,
  });

  const emit = defineEmits<{
    edit: [cardId: string];
    delete: [cardId: string];
    move: [cardId: string];
  }>();

  // 按 sort 排序
  const sortedCards = computed(() => {
    return [...props.cards].sort((a, b) => a.sort - b.sort);
  });

  // 根据卡片类型确定列宽
  const getCardSpan = (cardType: string): number => {
    switch (cardType) {
      case 'number':
        return 6;
      case 'table':
        return 24;
      case 'funnel':
      case 'path':
        return 12;
      default:
        return 8;
    }
  };

  // 根据卡片类型确定高度
  const getCardHeight = (cardType: string): number => {
    switch (cardType) {
      case 'number':
        return 140;
      case 'retention':
        return 280;
      default:
        return 220;
    }
  };
</script>

<template>
  <n-grid :x-gap="gap" :y-gap="gap" :cols="cols">
    <n-gi v-for="card in sortedCards" :key="card.cardId" :span="getCardSpan(card.type)">
      <DynamicCard
        :card="card"
        :loading="loadingCardIds.has(card.cardId)"
        :height="getCardHeight(card.type)"
        :show-actions="showActions"
        @edit="emit('edit', $event)"
        @delete="emit('delete', $event)"
        @move="emit('move', $event)"
      />
    </n-gi>
  </n-grid>
</template>

<script lang="ts">
  export default { name: 'DynamicCardGrid' };
</script>
