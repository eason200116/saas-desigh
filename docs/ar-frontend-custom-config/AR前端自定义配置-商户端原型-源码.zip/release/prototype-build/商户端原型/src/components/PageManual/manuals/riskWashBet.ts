// 对刷管理（商户端 tenant · riskControl_washBet）功能说明书。
// 2026-07-20（总-4）由总控端「彩票管理·对刷管理」跨端迁入商户端「风控管理·异常检测」，文件随迁、i18n 改挂 risk.*。
// 锚定 src/views/riskControl/washBet/index.vue + data.ts + components/*.vue 真实控件（R53 实证、不臆造）。
// 混合页：ProCrudTable 列表 + 页内「统计分析 / 对刷分析」双 Tab + 列表头工具栏（阈值 / 对刷查询）。
// 页内标题「对刷管理」，菜单名「对刷查询」（源站如此）。

import type { PageManual } from '../types';

const manual: PageManual = {
  route: 'riskControl_washBet',
  title: '对刷管理',
  overview:
    '商户端「风控管理 · 异常·检测」下的对刷（互刷 / 对打）风控分析页，2026-07-20 由总控端「彩票管理」跨端迁入（总-4），总控端已下线。页内「统计分析 / 对刷分析」双 Tab 切换：统计分析看仪表盘汇总、对刷分析看疑似对刷的关联账号明细列表。按用户ID + 时间查询，可调重合率阈值，逐对账号看对刷指标并查看详情。列表与详情里的会员ID一律脱敏展示（保留前 3 位 + 后 3 位、中间打星、总位数不变，如 123456789 → 123***789）。',
  items: [
    // ============ 搜索区 ============
    {
      anchor: 'userId',
      name: '用户ID',
      group: '搜索',
      interaction: '文本输入。',
      dataSource: '用户输入。',
      logic: '按用户ID查询该账号的对刷分析；仪表盘随查询联动（一个账号只属一种币种）。',
      limit: '选填；最多 50 字（inputProps searchKw）。',
      edge: '空 = mock 兜底取首条账号，进页面即有数据可看；此处按**完整ID**查询，脱敏只作用于列表/详情的展示、不影响搜索。',
    },
    {
      anchor: 'time',
      name: '时间',
      group: '搜索',
      interaction: '日期范围选择（proDateRange，纯日期、无时分秒，对齐源站）。',
      dataSource: '用户选择。',
      logic: '按时间范围筛选对刷数据。',
      limit: '最多跨 90 天、不可选未来（maxDays 90 / allowFuture false）。',
      edge: '空 = 不按时间筛。',
    },

    // ============ 页内控件（Tab 切换 + 工具栏）============
    {
      anchor: 'tab_mode',
      name: '页内 Tab · 统计分析 / 对刷分析',
      group: '操作',
      interaction: '点 Tab 切换视图模式（切换式、互不挤占，各占一屏）。',
      logic:
        '「统计分析」只显示仪表盘、隐藏工具栏与列表；「对刷分析」只显示工具栏与列表。默认停在「统计分析」。',
      note: '用 CSS 在页面侧控 ProCrudTable 外层容器显隐，不改 ProComponents 内部（红线 3）。',
    },
    {
      anchor: 'threshold',
      name: '重合率阈值（列表头）',
      group: '操作',
      interaction: '列表头下拉，选 30% ~ 100%（步进 10）。',
      dataSource: '本地枚举（30/40/…/100）。',
      logic: '设定判定「对刷」的重合率门槛，默认 30%；调整后点「对刷查询」按新阈值重查。',
    },
    {
      anchor: 'act_query',
      name: '对刷查询（列表头）',
      group: '操作',
      interaction: '点击按当前阈值 + 搜索条件重新查询。',
      logic: '刷新列表与仪表盘（同源刷新，一次带出）。',
    },

    // ============ 行操作 ============
    {
      anchor: 'act_detail',
      name: '行操作 · 详情',
      group: '操作',
      interaction: '点击打开对刷详情弹窗（约 720px，WashBetDetailModal）。',
      logic: '查看该对关联账号的对刷明细。只读展示。',
    },
  ],

  // ============ 字段介绍 tab（列序照页面；仅列表列 + 定义）============
  fields: [
    {
      name: '关联用户ID',
      def: '疑似互刷的一对账号（列内以「用户ID ↔ 关联用户ID」形式展示）。两个ID均脱敏展示：保留前 3 位 + 后 3 位、中间逐位打星、总位数与原值一致（如 88012345 → 880**345），底层数据仍为完整值，详情弹窗同规则（总-4）。',
    },
    { name: '商户', def: '该对账号所属的商户。' },
    { name: '重合率', def: '两账号投注重合程度的百分比（越高越可疑）。' },
    { name: '同期投注期数', def: '两账号在同一期一起投注的期数。' },
    { name: '同期投注金额', def: '两账号同期投注的金额合计。' },
    { name: '对刷期数', def: '判定为对刷（对打）的期数。' },
    { name: '对刷投注金额', def: '判定为对刷的投注金额合计。' },
    { name: '对刷比例(期)', def: '对刷期数占同期投注期数的百分比。' },
    { name: '对刷比例(金额)', def: '对刷金额占同期投注金额的百分比。' },
    { name: '币种', def: '该对账号投注 / 结算的币种。' },
    { name: '投注金额', def: '该对账号的投注总额。' },
    { name: '输赢金额', def: '该对账号的净输赢（正绿负红）。' },
  ],
};

export default manual;
