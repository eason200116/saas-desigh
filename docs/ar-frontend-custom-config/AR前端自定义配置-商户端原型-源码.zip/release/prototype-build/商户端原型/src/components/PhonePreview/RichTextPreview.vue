<template>
  <div class="rich-text-preview">
    <div class="rich-text-preview__toolbar">
      <span class="rich-text-preview__lang">{{ languageLabel }}</span>
      <n-radio-group v-if="showThemeToggle" v-model:value="themeValue" size="small">
        <n-radio-button value="light">{{ t('common.translate.opsPreviewLight') }}</n-radio-button>
        <n-radio-button value="dark">{{ t('common.translate.opsPreviewDark') }}</n-radio-button>
      </n-radio-group>
    </div>

    <iframe
      ref="frameRef"
      class="rich-text-preview-frame"
      :src="previewSrc || undefined"
      :srcdoc="frameSrcdoc"
      :style="frameStyle"
      @load="handleFrameLoad"
    />
  </div>
</template>

<script setup lang="ts">
  import { computed, ref, watch } from 'vue';
  import { useI18n } from 'vue-i18n';
  import frameTemplateHtml from './richTextPreviewFrame.html?raw';

  type PreviewTheme = 'light' | 'dark';
  const PREVIEW_MESSAGE_TYPE = 'translate-rich-text-preview:update';
  const EMPTY_RICH_TEXT_HTML = '<p><br></p>';

  interface Props {
    html?: string;
    language?: string;
    languageName?: string;
    theme?: PreviewTheme;
    height?: number;
    iframePath?: string;
    useSrcdoc?: boolean;
    /** 是否展示浅色/深色切换（默认展示；协议管理等纯净档可关闭） */
    showThemeToggle?: boolean;
  }

  const emit = defineEmits<{
    'update:theme': [value: PreviewTheme];
  }>();

  const props = withDefaults(defineProps<Props>(), {
    html: '',
    language: '',
    languageName: '',
    theme: 'light',
    height: 340,
    iframePath: '/translate-rich-text-preview.html',
    useSrcdoc: true,
    showThemeToggle: true,
  });

  const { t } = useI18n();
  const frameRef = ref<HTMLIFrameElement | null>(null);
  const themeValue = computed<PreviewTheme>({
    get() {
      return props.theme;
    },
    set(value) {
      emit('update:theme', value);
    },
  });
  const languageLabel = computed(() => {
    if (props.languageName) return props.languageName;
    return props.language || '-';
  });

  const previewSrc = computed(() => {
    if (props.useSrcdoc) return '';
    const rawPath = (props.iframePath || '').trim();
    if (/^https?:\/\//i.test(rawPath)) {
      return rawPath;
    }

    const base = import.meta.env.BASE_URL || '/';
    const normalizedPath = rawPath.startsWith('/') ? rawPath.slice(1) : rawPath;
    if (typeof window === 'undefined') {
      return `${base}${normalizedPath}`;
    }
    const baseUrl = new URL(base, window.location.origin);
    return new URL(normalizedPath, baseUrl).toString();
  });

  const frameStyle = computed(() => ({
    height: `${Math.max(props.height, 220)}px`,
  }));

  const frameSrcdoc = computed(() => (props.useSrcdoc ? frameTemplateHtml : undefined));

  function postPreviewMessage() {
    const previewWindow = frameRef.value?.contentWindow;
    if (!previewWindow) return;

    previewWindow.postMessage(
      {
        type: PREVIEW_MESSAGE_TYPE,
        payload: {
          theme: props.theme,
          html: props.html || EMPTY_RICH_TEXT_HTML,
          language: props.language,
          languageName: props.languageName,
        },
      },
      window.location.origin,
    );
  }

  function handleFrameLoad() {
    postPreviewMessage();
  }

  watch(
    () => [props.html, props.theme, props.language, props.languageName],
    () => {
      postPreviewMessage();
    },
    { immediate: true },
  );
</script>

<style scoped>
  .rich-text-preview {
    display: flex;
    flex-direction: column;
    gap: 8px;
  }

  .rich-text-preview__toolbar {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 8px;
  }

  .rich-text-preview__lang {
    font-size: 12px;
    color: #606266;
    white-space: nowrap;
  }

  .rich-text-preview-frame {
    width: 100%;
    border: 0;
    display: block;
    background: #fff;
    border-radius: 8px;
  }
</style>
