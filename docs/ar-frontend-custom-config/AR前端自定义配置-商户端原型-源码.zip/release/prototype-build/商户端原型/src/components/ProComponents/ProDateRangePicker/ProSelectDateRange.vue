<template>
  <div class="pro-select-date-range" :class="{ 'is-active': showPopover }">
    <n-select
      :value="currentSelectValue"
      :options="options"
      :size="size"
      :theme-overrides="selectThemeOverrides"
      class="pro-select-date-range__select"
      :style="{ flex: `0 0 ${selectWidth}px` }"
      @update:value="handleSelectUpdate"
    />
    <n-popover
      trigger="click"
      placement="bottom-start"
      :show="showPopover"
      :width="showTime ? undefined : 650"
      :style="showTime ? 'max-width: none;' : ''"
      @update:show="showPopover = $event"
    >
      <template #trigger>
        <div class="pro-select-date-range__date-trigger" @click="showPopover = true">
          <span class="pro-select-date-range__value" :class="{ 'is-placeholder': !startDisplay }">
            {{ startDisplay || placeholder || t('common.dateRange.placeholder') }}
          </span>
          <span class="pro-select-date-range__separator">→</span>
          <span class="pro-select-date-range__value" :class="{ 'is-placeholder': !endDisplay }">
            {{ endDisplay || placeholder || t('common.dateRange.placeholder') }}
          </span>
          <span class="pro-select-date-range__icons">
            <n-icon v-if="clearable && modelValue" class="clear-icon" @click.stop="handleClear">
              <CloseCircleFilled />
            </n-icon>
            <n-icon v-else><CalendarOutlined /></n-icon>
          </span>
        </div>
      </template>
      <ZonedDateRangePanel
        :value="modelValue"
        :value-format="valueFormat"
        :value-string-pattern="valueStringPattern"
        :timezone="pickerTimezone"
        :show-time="showTime"
        :shortcut-preset="shortcutPreset"
        :shortcuts="shortcuts"
        :max-days="maxDays"
        :allow-future="allowFuture"
        @confirm="handleConfirm"
        @reset="handleReset"
      />
    </n-popover>
  </div>
</template>

<script lang="ts" setup>
  import { computed, ref, toRef, watch } from 'vue';
  import { format } from 'date-fns';
  import { useI18n } from 'vue-i18n';
  import { NSelect, NIcon, NPopover } from 'naive-ui';
  import { CalendarOutlined, CloseCircleFilled } from '@vicons/antd';
  import ZonedDateRangePanel from './components/ZonedDateRangePanel.vue';
  import { createZonedDefaultShortcutValue } from './composables/useZonedShortcuts';
  import { useDateRangeTrigger, type RangeValue } from './useDateRange';
  import { resolveTimezoneId } from './utils/zonedDateMath';
  import type {
    DateRangeDefaultShortcut,
    DateRangeShortcutPreset,
    DateRangeShortcuts,
    DateRangeTimezone,
  } from '../types';
  import { useProFormContextSafe } from '../context';

  defineOptions({ name: 'ProSelectDateRange' });

  const props = withDefaults(
    defineProps<{
      /** 下拉选项 */
      options: { label: string; value: number }[];
      /** 下拉选中值 */
      selectValue?: number;
      /** ProField 标准 v-model:value 入口；普通模式下等价于 dateValue */
      value?: [number, number] | [string, string] | null;
      /** 日期区间值 [start, end]。number 元组用于 timestamp 模式；string 元组仅 valueFormat='string' 时生效 */
      dateValue?: [number, number] | [string, string] | null;
      /** ProForm 中写入时间类型的字段名 */
      selectField?: string;
      /** ProForm 中写入时间范围起止字段名 */
      modelKeys?: string[];
      /** 时间类型默认值 */
      defaultSelectValue?: number;
      /** 出站格式：'timestamp'（默认）emit 毫秒时间戳；'string' emit 格式化字符串（不做任何 tz 处理） */
      valueFormat?: 'timestamp' | 'string';
      /** valueFormat='string' 时的字符串格式，默认 'yyyy-MM-dd HH:mm:ss' */
      valueStringPattern?: string;
      /** 商户时区。string=自定义；false=强制 UTC；未传=CrudTable 上下文或默认商户 */
      timezone?: DateRangeTimezone;
      /** 日期区间占位符 */
      placeholder?: string;
      /** 尺寸 */
      size?: 'small' | 'medium' | 'large';
      /** Select 宽度（px） */
      selectWidth?: number;
      /** 是否可清除日期 */
      clearable?: boolean;
      /** 日期显示格式 */
      displayFormat?: string;
      /** 快捷选项预设 */
      shortcutPreset?: DateRangeShortcutPreset;
      /** 快捷选项：false 隐藏，true/不传显示默认，数组使用外部自定义 */
      shortcuts?: DateRangeShortcuts;
      /** 初始为空时按快捷项 key 写入默认区间 */
      defaultShortcut?: DateRangeDefaultShortcut;
      /** 最大可选天数 */
      maxDays?: number;
      /** 是否允许选择未来日期 */
      allowFuture?: boolean;
      /** 是否显示时分秒 */
      showTime?: boolean;
    }>(),
    {
      selectValue: undefined,
      value: undefined,
      dateValue: undefined,
      selectField: undefined,
      modelKeys: undefined,
      defaultSelectValue: 1,
      valueFormat: 'timestamp',
      valueStringPattern: 'yyyy-MM-dd HH:mm:ss',
      timezone: null,
      placeholder: '',
      size: 'small',
      selectWidth: 80,
      clearable: true,
      displayFormat: 'yyyy-MM-dd',
      shortcutPreset: 'default',
      shortcuts: undefined,
      defaultShortcut: undefined,
      maxDays: 31,
      allowFuture: false,
      showTime: true,
    },
  );

  const emit = defineEmits<{
    'update:selectValue': [value: number];
    'update:dateValue': [value: [number, number] | [string, string] | null];
    'update:value': [value: [number, number] | [string, string] | null];
    change: [value: [number, number] | [string, string] | null];
    clear: [];
  }>();

  const { t } = useI18n();
  const showPopover = ref(false);
  const modelValue = ref<RangeValue>(props.dateValue ?? props.value ?? null);
  const formContext = useProFormContextSafe();

  // Select 去掉右侧圆角
  const selectThemeOverrides = {
    peers: { InternalSelection: { borderRadius: '6px 0 0 6px' } },
  };

  const useModelKeys = computed(
    () => Array.isArray(props.modelKeys) && props.modelKeys.length >= 2 && !!formContext,
  );
  const useSelectField = computed(() => !!props.selectField && !!formContext);

  const currentSelectValue = computed(() => {
    if (useSelectField.value) {
      const value = formContext!.getFieldValue(props.selectField!);
      return value == null || value === '' ? props.defaultSelectValue : Number(value);
    }
    return props.selectValue ?? props.defaultSelectValue;
  });

  function readFromModelKeys(): RangeValue {
    if (!useModelKeys.value) return null;
    const [startKey, endKey] = props.modelKeys!;
    const startVal = formContext!.getFieldValue(startKey);
    const endVal = formContext!.getFieldValue(endKey);
    if (
      (startVal === undefined || startVal === null || startVal === '') &&
      (endVal === undefined || endVal === null || endVal === '')
    ) {
      return null;
    }
    return [startVal, endVal] as RangeValue;
  }

  function writeToModelKeys(value: RangeValue) {
    if (!useModelKeys.value) return;
    const [startKey, endKey] = props.modelKeys!;
    if (Array.isArray(value) && value.length === 2) {
      formContext!.setFieldValue(startKey, value[0]);
      formContext!.setFieldValue(endKey, value[1]);
      return;
    }
    formContext!.setFieldValue(startKey, null);
    formContext!.setFieldValue(endKey, null);
  }

  function commitDateValue(value: RangeValue) {
    modelValue.value = value;
    if (useModelKeys.value) {
      writeToModelKeys(value);
    } else {
      emit('update:dateValue', value);
      emit('update:value', value);
    }
  }

  // 共用触发器状态机：面板时区 / 显示 / string 规范化 / tz 切换都在 composable 里
  const { pickerTimezone, startDisplay, endDisplay } = useDateRangeTrigger({
    value: modelValue,
    externalValue: modelValue,
    valueFormat: toRef(props, 'valueFormat'),
    valueStringPattern: toRef(props, 'valueStringPattern'),
    displayFormat: toRef(props, 'displayFormat'),
    propTimezone: toRef(props, 'timezone'),
    onStringNormalize: (normalized) => {
      commitDateValue(normalized);
      emit('change', normalized);
    },
  });

  function handleSelectUpdate(val: number) {
    if (useSelectField.value) {
      formContext!.setFieldValue(props.selectField!, val);
    }
    emit('update:selectValue', val);
  }

  function handleConfirm(val: [number, number] | [string, string]) {
    showPopover.value = false;
    commitDateValue(val);
    emit('change', val);
  }

  function handleReset() {
    suppressDefaultShortcut.value = true;
    commitDateValue(null);
    emit('change', null);
  }

  function handleClear() {
    suppressDefaultShortcut.value = true;
    commitDateValue(null);
    emit('change', null);
    emit('clear');
  }

  const defaultShortcutValue = computed(() => {
    const timezone = pickerTimezone.value;
    if (timezone === null && props.timezone !== false) return null;
    return createZonedDefaultShortcutValue({
      defaultShortcut: props.defaultShortcut,
      timezoneId: resolveTimezoneId(timezone === false ? null : timezone),
      valueFormat: props.valueFormat,
      valueStringPattern: props.valueStringPattern,
      preset: props.shortcutPreset,
      t,
    });
  });
  const suppressDefaultShortcut = ref(false);

  function isEmptyRange(value: RangeValue) {
    if (!Array.isArray(value) || value.length !== 2) return true;
    const startEmpty = value[0] === undefined || value[0] === null || value[0] === '';
    const endEmpty = value[1] === undefined || value[1] === null || value[1] === '';
    return startEmpty && endEmpty;
  }

  function getCurrentRange() {
    return useModelKeys.value ? readFromModelKeys() : modelValue.value;
  }

  function getTimezoneIdentity(value: DateRangeTimezone | undefined) {
    if (value === false || value === null || value === undefined) return 'UTC';
    return resolveTimezoneId(value);
  }

  function resetDefaultShortcut() {
    const next = defaultShortcutValue.value;
    if (!next) return false;
    suppressDefaultShortcut.value = false;
    commitDateValue(next);
    return true;
  }

  function applyDefaultShortcutIfEmpty() {
    const next = defaultShortcutValue.value;
    if (!next) return false;
    if (!isEmptyRange(getCurrentRange())) return false;
    if (suppressDefaultShortcut.value) {
      suppressDefaultShortcut.value = false;
      return false;
    }
    commitDateValue(next);
    return true;
  }

  watch(
    () => [props.dateValue, props.value] as const,
    ([dateValue, value]) => {
      if (useModelKeys.value) {
        modelValue.value = readFromModelKeys();
        applyDefaultShortcutIfEmpty();
        return;
      }
      modelValue.value = dateValue !== undefined ? dateValue : (value ?? null);
      applyDefaultShortcutIfEmpty();
    },
    { immediate: true, flush: 'sync' },
  );

  const modelKeysSnapshot = computed<RangeValue>(() =>
    useModelKeys.value ? readFromModelKeys() : null,
  );

  watch(
    modelKeysSnapshot,
    (next) => {
      if (!useModelKeys.value) return;
      if (
        props.valueFormat === 'string' &&
        Array.isArray(next) &&
        next.length === 2 &&
        typeof next[0] === 'number' &&
        typeof next[1] === 'number'
      ) {
        const pattern = props.valueStringPattern;
        commitDateValue([format(next[0], pattern), format(next[1], pattern)]);
        return;
      }
      const current = modelValue.value;
      if (
        (next?.[0] ?? null) === (current?.[0] ?? null) &&
        (next?.[1] ?? null) === (current?.[1] ?? null)
      ) {
        return;
      }
      modelValue.value = next;
      // 不在此处 applyDefaultShortcutIfEmpty：外部（如 ProCrudTable quick-date "所有" 按钮）
      // 把 modelKeys 字段写为 null 时，会触发本 watch，此前会 fillback 回 today 导致清空失效。
      // 首屏 mount 的 fillback 由上面的 [dateValue, value] watch (immediate) 保证。
    },
    { flush: 'sync' },
  );

  watch(
    () => [props.selectField, props.defaultSelectValue] as const,
    () => {
      if (!useSelectField.value) return;
      const current = formContext!.getFieldValue(props.selectField!);
      if (current === undefined || current === null || current === '') {
        formContext!.setFieldValue(props.selectField!, props.defaultSelectValue);
      }
    },
    { immediate: true, flush: 'sync' },
  );

  watch(
    pickerTimezone,
    (nextTimezone, previousTimezone) => {
      if (!props.defaultShortcut) return;
      if (getTimezoneIdentity(nextTimezone) === getTimezoneIdentity(previousTimezone)) return;
      resetDefaultShortcut();
    },
    { flush: 'sync' },
  );

  watch(defaultShortcutValue, () => applyDefaultShortcutIfEmpty(), {
    immediate: true,
    flush: 'sync',
  });
</script>

<style lang="less" scoped>
  // 模拟 NInput readonly small 的外观，不依赖 Naive UI 的 --n-* CSS 变量
  @border-color: #e0e0e6;
  @border-color-hover: #36ad6a;
  @text-color: #333639;
  @placeholder-color: #c2c2c2;
  @icon-color: #c2c2c2;
  @icon-color-hover: #999;

  .pro-select-date-range {
    display: flex;
    align-items: center;
    width: 100%;
    min-width: 0;

    &__date-trigger {
      flex: 1;
      min-width: 0;
      display: flex;
      align-items: center;
      height: 26px;
      padding: 0 8px;
      margin-left: -1px;
      border: 1px solid @border-color;
      border-radius: 0 3px 3px 0;
      background: #fff;
      cursor: pointer;
      font-size: 13px;
      box-sizing: border-box;
      transition: border-color 0.3s;

      &:hover {
        border-color: @border-color-hover;
      }
    }

    &__value {
      flex: 1;
      min-width: 0;
      text-align: center;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
      color: @text-color;

      &.is-placeholder {
        color: @placeholder-color;
      }
    }

    &__separator {
      flex-shrink: 0;
      color: #999;
      font-size: 12px;
      margin: 0 4px;
    }

    &__icons {
      flex-shrink: 0;
      display: flex;
      align-items: center;
      margin-left: 4px;
      color: @icon-color;
    }

    .clear-icon {
      cursor: pointer;
      transition: color 0.3s;

      &:hover {
        color: @icon-color-hover;
      }
    }
  }
</style>
