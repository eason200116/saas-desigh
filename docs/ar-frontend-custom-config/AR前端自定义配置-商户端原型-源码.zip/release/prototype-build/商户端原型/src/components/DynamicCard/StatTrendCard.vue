<script setup lang="ts">
  import { ref, computed } from 'vue';
  import { useI18n } from 'vue-i18n';
  import Chart1 from '@/components/Chart/chart1.vue';
  import { ArrowUpOutline, ArrowDownOutline, InformationCircleOutline } from '@vicons/ionicons5';
  interface DataItem {
    date: string;
    value: number;
    value2?: number;
  }

  interface TableColumn {
    title: string;
    key: string;
    render?: (row: DataItem) => string | number;
  }

  interface Props {
    title: string;
    // 方式1: 直接传入统计数据（兼容 StatCard）
    statisticList?: any[];
    // 方式2: 分别传入各项数据
    currentValue?: number | string;
    compareValue?: number;
    compareLabel?: string;
    weekCompare?: number | 'same';
    total?: number | string;
    average?: number | string;
    // Chart data
    data?: DataItem[];
    chartType?: 'line' | 'bar';
    seriesName?: string;
    seriesColor?: string;
    // 双系列支持（从 TrendCard 合并）
    showSecondSeries?: boolean;
    seriesName2?: string;
    seriesColor2?: string;
    // 值格式化（从 TrendCard 合并）
    valueFormatter?: (val: number) => string;
    // 自定义表格列（从 TrendCard 合并）
    tableColumns?: TableColumn[];
    // Layout
    showChart?: boolean;
    // 显示图表/表格切换按钮
    showToggle?: boolean;
    // Tooltip
    tooltip?: string;
  }

  const props = withDefaults(defineProps<Props>(), {
    chartType: 'bar',
    seriesColor: '#2080f0',
    seriesColor2: '#18a058',
    showSecondSeries: false,
    showChart: true,
    showToggle: false,
  });

  // 视图模式：图表或表格
  const viewMode = ref<'chart' | 'table'>('chart');

  const { t } = useI18n();

  // 格式化日期为 YYYY-MM-DD
  const formatDateStr = (date: Date): string => {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  };

  // 从 statisticList 提取数据（兼容 StatCard）
  const statFromList = computed(() => {
    if (!props.statisticList || props.statisticList.length === 0) {
      return null;
    }
    const first = props.statisticList[0];
    const calcData = first.calcData || [];

    const total = first.calcTotail || 0;
    const average = calcData.length > 0 ? Math.round((total / calcData.length) * 100) / 100 : 0;

    // 按日期排序（升序）
    const sortedData = [...calcData].sort((a, b) =>
      (a.happenDate || '').localeCompare(b.happenDate || ''),
    );

    // 获取今天和昨天的日期字符串
    const now = new Date();
    const todayStr = formatDateStr(now);
    const yesterdayDate = new Date(now);
    yesterdayDate.setDate(now.getDate() - 1);
    const yesterdayStr = formatDateStr(yesterdayDate);
    const lastWeekDate = new Date(now);
    lastWeekDate.setDate(now.getDate() - 7);
    const lastWeekStr = formatDateStr(lastWeekDate);

    // 查找今天、昨天、上周同期的数据
    const todayData = sortedData.find((d) => d.happenDate === todayStr);
    const yesterdayData = sortedData.find((d) => d.happenDate === yesterdayStr);
    const lastWeekData = sortedData.find((d) => d.happenDate === lastWeekStr);

    const todayValue = todayData ? Number(todayData.count) || 0 : 0;
    const yesterdayValue = yesterdayData ? Number(yesterdayData.count) || 0 : 0;
    const lastWeekValue = lastWeekData ? Number(lastWeekData.count) || 0 : 0;

    // 计算较昨日（环比）
    let chainRatio: number | undefined;
    if (yesterdayValue > 0) {
      chainRatio = Math.round(((todayValue - yesterdayValue) / yesterdayValue) * 10000) / 100;
    }

    // 计算同比上周
    let weekRatio: number | undefined;
    if (lastWeekValue > 0) {
      weekRatio = Math.round(((todayValue - lastWeekValue) / lastWeekValue) * 10000) / 100;
    }

    // 构建趋势数据
    const trendData: DataItem[] = sortedData.map((d) => ({
      date: d.happenDate || '',
      value: Number(d.count) || 0,
    }));

    return {
      value: todayValue,
      total,
      average,
      chainRatio,
      weekRatio,
      trendData,
    };
  });

  // 统一获取数据（优先使用 statisticList，否则使用直接传入的 props）
  const effectiveValue = computed(() => {
    if (statFromList.value) return statFromList.value.value;
    return props.currentValue;
  });

  const effectiveCompareValue = computed(() => {
    if (statFromList.value) return statFromList.value.chainRatio;
    return props.compareValue;
  });

  const effectiveWeekCompare = computed(() => {
    if (statFromList.value) return statFromList.value.weekRatio;
    return props.weekCompare;
  });

  const effectiveTotal = computed(() => {
    if (statFromList.value) return statFromList.value.total;
    return props.total;
  });

  const effectiveAverage = computed(() => {
    if (statFromList.value) return statFromList.value.average;
    return props.average;
  });

  const effectiveData = computed(() => {
    if (statFromList.value && statFromList.value.trendData.length > 0) {
      return statFromList.value.trendData;
    }
    return props.data;
  });

  // Get current day of week
  const todayLabel = computed(() => {
    const days = ['日', '一', '二', '三', '四', '五', '六'];
    const today = new Date();
    return `${t('analytics.common.today')}（${days[today.getDay()]}）`;
  });

  // Format value（支持自定义 formatter）
  const formatValue = (val: number | string | undefined) => {
    if (val === undefined) return '';
    if (typeof val === 'string') return val;
    if (props.valueFormatter) return props.valueFormatter(val);
    if (val >= 10000) return (val / 10000).toFixed(2) + ' 万';
    if (val >= 1000) return (val / 1000).toFixed(2) + ' 千';
    return val.toFixed(2);
  };

  const formattedValue = computed(() => {
    const val = effectiveValue.value;
    if (val === undefined) return '';
    if (typeof val === 'string') return val;
    const num = val;
    if (num >= 10000) return Math.floor(num).toString();
    return num.toString();
  });

  // Format stat values
  const formatStatValue = (val: number | string | undefined) => {
    if (val === undefined) return '';
    if (typeof val === 'string') return val;
    return val.toFixed(2);
  };

  // 默认表格列
  const defaultTableColumns = computed<TableColumn[]>(() => [
    { title: t('analytics.common.date'), key: 'date' },
    {
      title: props.seriesName || t('analytics.common.value'),
      key: 'value',
      render: (row: DataItem) => formatValue(row.value),
    },
    ...(props.showSecondSeries
      ? [
          {
            title: props.seriesName2 || t('analytics.common.value2'),
            key: 'value2',
            render: (row: DataItem) => formatValue(row.value2 || 0),
          },
        ]
      : []),
  ]);

  const tableColumns = computed(() => props.tableColumns || defaultTableColumns.value);

  // 表格数据
  const tableData = computed(() => effectiveData.value || []);

  // Comparison classes
  const isPositive = computed(() => {
    const val = effectiveCompareValue.value;
    if (val === undefined) return null;
    return val >= 0;
  });

  const weekCompareText = computed(() => {
    const val = effectiveWeekCompare.value;
    if (val === undefined) return '';
    if (val === 'same' || val === 0) {
      return t('analytics.common.weekSame');
    }
    const prefix = val > 0 ? '+' : '';
    return `${prefix}${val}%`;
  });

  const weekCompareClass = computed(() => {
    const val = effectiveWeekCompare.value;
    if (val === undefined || val === 'same' || val === 0) {
      return 'neutral';
    }
    return val > 0 ? 'positive' : 'negative';
  });

  // 是否显示图表
  const hasChartData = computed(() => {
    return props.showChart && effectiveData.value && effectiveData.value.length > 0;
  });

  // Chart config（支持双系列）
  const chartConfig = computed(() => {
    const data = effectiveData.value;
    if (!data || data.length === 0) return null;

    const isLine = props.chartType === 'line';
    const hasSecondSeries = props.showSecondSeries && data.some((d) => d.value2 !== undefined);
    const seriesName1 = props.seriesName || t('analytics.common.value');
    const seriesName2 = props.seriesName2 || t('analytics.common.value2');

    const series: any[] = [
      {
        name: seriesName1,
        type: isLine ? 'line' : 'bar',
        data: data.map((d) => d.value),
        itemStyle: { color: props.seriesColor },
        barMaxWidth: 40,
        smooth: isLine,
        label: {
          show: !hasSecondSeries,
          position: 'top',
          fontSize: 10,
          color: '#8c8c8c',
          formatter: '{c}',
        },
      },
    ];

    if (hasSecondSeries) {
      series.push({
        name: seriesName2,
        type: isLine ? 'line' : 'bar',
        data: data.map((d) => d.value2 || 0),
        itemStyle: { color: props.seriesColor2 },
        barMaxWidth: 40,
        smooth: isLine,
      });
    }

    return {
      tooltip: {
        trigger: 'axis',
        axisPointer: { type: isLine ? 'line' : 'shadow' },
      },
      legend: hasSecondSeries
        ? {
            data: [seriesName1, seriesName2],
            bottom: 0,
          }
        : undefined,
      grid: {
        left: hasSecondSeries ? '3%' : 5,
        right: hasSecondSeries ? '4%' : 5,
        top: hasSecondSeries ? '10%' : 25,
        bottom: hasSecondSeries ? '15%' : 25,
        containLabel: hasSecondSeries,
      },
      xAxis: {
        type: 'category',
        data: data.map((d) => d.date.slice(5)),
        axisLabel: { fontSize: 10, color: '#8c8c8c', rotate: hasSecondSeries ? 45 : 0 },
        axisLine: { lineStyle: { color: '#e8e8e8' } },
        axisTick: { show: false },
      },
      yAxis: {
        type: 'value',
        show: hasSecondSeries,
      },
      series,
    };
  });
</script>

<template>
  <div class="stat-trend-card">
    <div class="stat-trend-card__header">
      <span class="stat-trend-card__title">{{ title }}</span>
      <n-tooltip v-if="tooltip" trigger="hover">
        <template #trigger>
          <n-icon size="14" class="stat-trend-card__info">
            <InformationCircleOutline />
          </n-icon>
        </template>
        {{ tooltip }}
      </n-tooltip>
      <!-- 图表/表格切换 -->
      <div v-if="showToggle && hasChartData" class="stat-trend-card__toggle">
        <n-button-group size="tiny">
          <n-button
            :type="viewMode === 'chart' ? 'primary' : 'default'"
            @click="viewMode = 'chart'"
          >
            {{ t('analytics.common.chart') }}
          </n-button>
          <n-button
            :type="viewMode === 'table' ? 'primary' : 'default'"
            @click="viewMode = 'table'"
          >
            {{ t('analytics.common.table') }}
          </n-button>
        </n-button-group>
      </div>
    </div>

    <div
      class="stat-trend-card__content"
      :class="{ 'stat-trend-card__content--with-chart': hasChartData && viewMode === 'chart' }"
    >
      <!-- Left: Stats -->
      <div class="stat-trend-card__stats">
        <div class="stat-trend-card__today">{{ todayLabel }}</div>
        <div class="stat-trend-card__value">{{ formattedValue }}</div>
        <div class="stat-trend-card__metrics">
          <span v-if="effectiveCompareValue !== undefined" class="stat-trend-card__metric">
            <span class="stat-trend-card__metric-label">{{
              compareLabel || t('analytics.common.vsYesterday')
            }}</span>
            <span
              class="stat-trend-card__metric-value"
              :class="{ positive: isPositive, negative: !isPositive }"
            >
              <n-icon size="12">
                <ArrowUpOutline v-if="isPositive" />
                <ArrowDownOutline v-else />
              </n-icon>
              {{ Math.abs(effectiveCompareValue) }}%
            </span>
          </span>
          <span v-if="effectiveWeekCompare !== undefined" class="stat-trend-card__metric">
            <span class="stat-trend-card__metric-label">{{
              t('analytics.common.vsLastWeek')
            }}</span>
            <span class="stat-trend-card__metric-value" :class="weekCompareClass">{{
              weekCompareText
            }}</span>
          </span>
          <span v-if="effectiveTotal !== undefined" class="stat-trend-card__metric">
            <span class="stat-trend-card__metric-label">{{ t('analytics.common.total') }}</span>
            <span class="stat-trend-card__metric-value">{{ formatStatValue(effectiveTotal) }}</span>
          </span>
          <span v-if="effectiveAverage !== undefined" class="stat-trend-card__metric">
            <span class="stat-trend-card__metric-label">{{ t('analytics.common.average') }}</span>
            <span class="stat-trend-card__metric-value">{{
              formatStatValue(effectiveAverage)
            }}</span>
          </span>
        </div>
      </div>

      <!-- Right: Chart or Table -->
      <div v-if="hasChartData" class="stat-trend-card__chart">
        <template v-if="viewMode === 'chart'">
          <Chart1 :config="chartConfig!" height="120px" />
        </template>
        <template v-else>
          <n-data-table
            :columns="tableColumns"
            :data="tableData"
            :bordered="false"
            size="small"
            :max-height="120"
          />
        </template>
      </div>
    </div>
  </div>
</template>

<script lang="ts">
  export default {
    name: 'StatTrendCard',
  };
</script>

<style lang="less" scoped>
  .stat-trend-card {
    background: #fff;
    border: 1px solid #f0f0f0;
    border-radius: 8px;
    height: 100%;
    display: flex;
    flex-direction: column;

    &__header {
      display: flex;
      align-items: center;
      gap: 6px;
      padding: 12px 16px;
      border-bottom: 1px solid #f0f0f0;
    }

    &__title {
      font-size: 14px;
      font-weight: 500;
      color: #262626;
      flex: 1;
    }

    &__info {
      color: #bfbfbf;
      cursor: help;
    }

    &__toggle {
      margin-left: auto;
      margin-right: 28px; // 给 dynamic-card-action 留出空间
      ::v-deep(.n-button) {
        font-size: 12px;
        padding: 0 8px;
      }
    }

    &__content {
      flex: 1;
      padding: 12px;
      display: flex;
      gap: 12px;

      &--with-chart {
        .stat-trend-card__stats {
          flex: 0 0 auto;
          min-width: 100px;
        }
        .stat-trend-card__chart {
          flex: 1;
          min-width: 0;
        }
      }
    }

    &__stats {
      display: flex;
      flex-direction: column;
    }

    &__today {
      font-size: 12px;
      color: #8c8c8c;
      margin-bottom: 4px;
    }

    &__value {
      font-size: 36px;
      font-weight: 600;
      color: #262626;
      line-height: 1.2;
      font-family:
        'DIN Alternate',
        -apple-system,
        BlinkMacSystemFont,
        sans-serif;
      margin-bottom: 12px;
    }

    &__metrics {
      display: flex;
      flex-direction: column;
      gap: 4px;
    }

    &__metric {
      display: inline-flex;
      align-items: center;
      font-size: 12px;
    }

    &__metric-label {
      color: #8c8c8c;
      margin-right: 4px;
    }

    &__metric-value {
      display: inline-flex;
      align-items: center;
      gap: 2px;
      color: #262626;
      font-weight: 500;

      &.positive {
        color: #f5222d;
      }
      &.negative {
        color: #52c41a;
      }
      &.neutral {
        color: #8c8c8c;
      }
    }

    &__chart {
      display: flex;
      align-items: center;
    }
  }

  // Dark theme
  .dark .stat-trend-card {
    background: #242b3d;
    border-color: #3a4459;

    &__header {
      border-color: #3a4459;
    }

    &__title {
      color: #e5e7eb;
    }

    &__value {
      color: #e5e7eb;
    }

    &__metric-label {
      color: #9ca3af;
    }

    &__metric-value {
      color: #e5e7eb;
    }
  }
</style>
