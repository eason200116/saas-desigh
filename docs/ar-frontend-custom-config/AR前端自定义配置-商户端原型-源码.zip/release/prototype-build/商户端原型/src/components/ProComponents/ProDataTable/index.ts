import ProDataTable from './ProDataTable.vue';
import ProTableToolbar from './ProTableToolbar.vue';

export { ProDataTable, ProTableToolbar };
export default ProDataTable;
