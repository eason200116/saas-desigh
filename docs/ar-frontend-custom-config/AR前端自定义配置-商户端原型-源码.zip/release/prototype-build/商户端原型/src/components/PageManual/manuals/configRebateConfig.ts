// 返佣配置（商户端 tenant · configCenter_rebateConfig）功能说明书。
// 锚定 src/views/config/rebateConfig/index.vue + shared/ConfigWorkspaceBar.vue + ConfigSideNav.vue +
// MerchantConfigLog.vue + data.ts 真实控件（R53 实证、不臆造）。
// 页面结构与「VIP配置」(configVipConfig.ts) 同源：商户配置/模版配置2个tab + 共用ConfigWorkspaceBar
// (template-only+versioning+group-by-currency)；ws_ 前缀条目锚点同VIP配置、已在shared组件内联动，
// 此处不重复注释来源。区别：本页返佣等级可动态增删(非固定11级)，且多一块"返佣费率"配置区。

import type { PageManual } from '../types';

const manual: PageManual = {
  route: 'configCenter_rebateConfig',
  title: '返佣配置',
  overview:
    '商户端「配置中心 › 返佣配置」页，结构与VIP配置同源（商户配置/模版配置2个tab + 共用模版画廊组件）。' +
    '与VIP配置的关键差异：①返佣等级(L1..Ln)可动态新增/删除，非固定档位；②每个等级除"团队/直属"6项达标' +
    '条件外，还有独立的"返佣费率"配置区——10档层级×5类游戏(彩票/电子/真人/体育/棋牌)矩阵，每格可编辑，' +
    '同一游戏纵向求和超5%标红拦截保存；③"满足人数"列为灰色占位(配置态恒为0，标注运行时统计，非模版态' +
    '才显示)。2026-07-22核实代码未发现真实缺陷(等级/费率均真实落库，超限校验/删除确认均真实生效)。',
  items: [
    // ===== 商户配置 tab（与VIP配置同构，锚点同名） =====
    { anchor: 'tab_merchant', name: '商户配置（tab）', group: '搜索', interaction: '默认选中的tab。' },
    {
      anchor: 'tab_template',
      name: '模版配置（tab）',
      group: '搜索',
      interaction: '点击切换；离开该tab自动退出新建/编辑模版态。',
    },
    {
      anchor: 'mchCur',
      name: '货币（商户配置tab）',
      group: '搜索',
      interaction: '横向滚动chip单选，支持鼠标拖动+两端箭头；切换货币清空已选商户。',
    },
    { anchor: 'mchFilter', name: '搜索商户', group: '搜索', interaction: '文本框，按商户名模糊过滤下方chip列表。' },
    {
      anchor: 'selectAllMch',
      name: '全选',
      group: '搜索',
      interaction: '按钮，勾选当前货币下所有商户chip。',
    },
    { anchor: 'clearMch', name: '清空', group: '搜索', interaction: '按钮，取消所有已选商户chip。' },
    {
      anchor: 'toggleMch',
      name: '商户chip（勾选）',
      group: '搜索',
      interaction: '点击勾选/取消；单选一个商户→立即载入该商户配置。',
    },
    {
      anchor: 'mchSrc',
      name: '配置来源（单选）',
      group: '搜索',
      interaction: '单选：应用模版配置 / 自定义；多选商户时"自定义"选项禁用。',
    },
    {
      anchor: 'pickTpl',
      name: '选择模版',
      group: '搜索',
      interaction: '下拉，仅列当前货币下的模版；默认自动选中第一个。',
    },
    {
      anchor: 'ws_curChip',
      name: '货币（模版配置tab画廊）',
      group: '搜索',
      interaction: '横向滚动chip单选，仅展示该货币下的模版卡片。',
    },
    // ===== 操作 =====
    {
      anchor: 'applySource',
      name: '应用',
      group: '操作',
      interaction: '按钮，仅"应用模版配置"来源时出现；点击弹二次确认→确认后生效落库。',
    },
    {
      anchor: 'applyFromMch',
      name: '应用其他商户配置',
      group: '操作',
      interaction: '按钮，打开弹窗：选同货币源商户→只读预览其等级表+费率矩阵→确认覆盖当前商户。',
    },
    {
      anchor: 'updateToLatest',
      name: '立即更新',
      group: '操作',
      interaction: '按钮，仅当前商户应用的模版有更新版本时出现；点击把模版最新版应用到该商户并生效。',
    },
    {
      anchor: 'addLevel',
      name: '新增等级',
      group: '操作',
      interaction: '按钮，在表格顶部插入一行待填的新等级(行内编辑态)，等级号自动取当前最大值+1。',
    },
    {
      anchor: 'levelIntroToggle',
      name: '返佣等级说明',
      group: '操作',
      interaction: '按钮，点击展开/收起等级配置的图文说明提示条(5条要点)。',
    },
    {
      anchor: 'rateIntroToggle',
      name: '返佣费率说明',
      group: '操作',
      interaction: '按钮，点击展开/收起费率配置的图文说明提示条(5条要点+一份配置举例表格)。',
    },
    {
      anchor: 'editLevel_row',
      name: '返佣等级·行内编辑',
      group: '操作',
      interaction:
        '每行"编辑"按钮进入行内编辑(团队/直属6项数值+备注)，编辑态出现保存/取消/清空/恢复4个按钮；保存弹二次确认预览→确认后即生效落库。L0基础层不可编辑/删除(灰字"基础层级"占位)。',
    },
    {
      anchor: 'deleteLevel_row',
      name: '返佣等级·删除',
      group: '操作',
      interaction: '每行"删除"按钮，二次确认弹窗(dialog.warning)确认后删除该等级及其对应费率配置。',
    },
    {
      anchor: 'editRate_card',
      name: '返佣费率卡·行内编辑',
      group: '操作',
      interaction:
        '每个等级费率卡右上角"编辑"按钮进入矩阵编辑态，出现保存/取消/清空/恢复4个按钮；保存前校验同一游戏大类纵向求和≤5%，超限该列标红+hover错因+阻止保存。',
      limit: '每类游戏(彩票/电子/真人/体育/棋牌)跨全部层级(tier1~10)求和上限5%。',
    },
    {
      anchor: 'ws_addTemplate',
      name: '＋新增模板',
      group: '操作',
      interaction: '按钮，最多10个模板(满额隐藏)；点击进入新建草稿态。',
    },
    {
      anchor: 'ws_saveTemplateDraft',
      name: '保存（新建模板草稿）',
      group: '操作',
      interaction: '按钮，草稿名称+等级表+费率一并提交为新模版；同行"取消"放弃草稿。',
    },
    {
      anchor: 'ws_selectTemplate',
      name: '模板卡片（点击进入编辑）',
      group: '操作',
      interaction: '点击卡片名称或右上角"编辑"按钮，载入该模版内容进入编辑态。',
    },
    { anchor: 'ws_deleteTemplate', name: '删除模板', group: '操作', interaction: '卡片右上角红色按钮，删除该模版。' },
    {
      anchor: 'ws_viewAllMerchant',
      name: '查看更多（商户）',
      group: '操作',
      interaction: '模板卡片已应用商户超过展示上限时出现，点击打开"查看全部"弹窗(带搜索)。',
    },
    {
      anchor: 'ws_editMeta',
      name: '编辑（模板名称/币种）',
      group: '操作',
      interaction: '编辑模板态下的按钮，点击后名称变可输入框；币种编辑态锁定不可改。',
    },
    { anchor: 'ws_saveMeta', name: '保存（模板名称）', group: '操作', interaction: '按钮，确认修改模版名称。' },
    {
      anchor: 'ws_applyMchToTpl',
      name: '应用其他商户配置（到模板）',
      group: '操作',
      interaction: '编辑模板态按钮，选一个同币种商户，用其等级+费率配置整体覆盖当前正在编辑的模版。',
    },
    {
      anchor: 'openMerchantCfgLog',
      name: '商户配置记录',
      group: '操作',
      interaction: '按钮，打开只读弹窗展示该页全局商户配置变更流水(跨商户)，仅展示最新10条。',
    },
    // ===== 其它（展示态） =====
    {
      anchor: 'previewArea',
      name: '来源预览区（只读）',
      group: '其它',
      interaction: '选中"应用模版配置"或"应用其他商户配置"后，应用前先只读预览将套用的等级表+费率卡片组。',
    },
    {
      anchor: 'sourceInfo',
      name: '正在配置·来源/版本/状态',
      group: '其它',
      interaction: '"正在配置"栏展示当前商户名+配置来源+配置版本号+状态标签。',
    },
    {
      anchor: 'chipSrc',
      name: 'chip·配置来源与版本标识',
      group: '其它',
      interaction: '商户chip第2排的来源标签(自定义/模版名/复制自XX)+"🔔有新版"或"已最新"徽标。',
    },
    { anchor: 'batchTip', name: '批量提示', group: '其它', interaction: '多选商户时出现的提示文案，告知将批量应用到N个商户。' },
    {
      anchor: 'configExample',
      name: '配置举例（静态示意表）',
      group: '其它',
      interaction: '费率说明展开后附的一份示例矩阵，纯静态展示配置思路，不可编辑。',
    },
    {
      anchor: 'ws_boundMerchants',
      name: '模板·已绑定商户/版本',
      group: '其它',
      interaction: '编辑模板栏展示该模版当前版本号+已应用的商户列表(超3个可"查看全部")。',
    },
    {
      anchor: 'navToggle',
      name: '左侧配置导航',
      group: '其它',
      interaction: '可展开/收起；展开态含搜索框+页面入口卡片，收起态显示竖排短标签。',
    },
  ],
  fields: [
    { name: '等级（列）', def: '返佣层级编号L1..Ln，可动态增删；L0固定为基础层级，不可编辑/删除。' },
    { name: '团队充值人数/金额/游戏流水', def: '升级到该等级所需的团队(下级总和)达标条件，3项数值。' },
    { name: '直属充值人数/金额/游戏流水', def: '升级到该等级所需的直属下级达标条件，3项数值。' },
    { name: '满足人数', def: '灰色占位列，非模版态才显示；配置态恒为0，实际数值由运行时统计生成。' },
    { name: '备注', def: '该等级的说明文字，可换行，居左展示(R41)。' },
    { name: '返佣费率矩阵', def: '10档层级(tier1~10) × 5类游戏(彩票/电子/真人/体育/棋牌)的百分比矩阵，逐格独立配置。' },
    { name: '合计行', def: '费率卡片底部只读行，纵向求和展示每类游戏当前已配置的总百分比，超5%标红。' },
  ],
};

export default manual;
