// 资金账变（商户端 tenant · finance_fund_change_page）功能说明书。
// 锚定 src/views/finance/fundChange/{index.vue,data.ts,fundChangeConfig.ts,useFundChangePage.ts}
// 真实控件（R53 实证、不臆造）。CLAUDE.md 点名的 finance 模块标杆页面（结构范本）。
// 单表 ProCrudTable：搜索区 6 项 + 表格 11 列 + 操作列「修改备注」+ 工具栏「导出」，无新增/编辑/删除/批量。
// 全站唯一把「账变类型」treeSelect 做满 4 层（主类型→子类型→厂商→游戏）的范例页
// （docs/published/interaction-spec-draft.html §5 直接点名本页）。
// 核实结论：本页搜索区 6 项 mock 全部真实读取生效（含账变类型的第 3/4 层厂商/游戏级过滤），
// 未发现「UI 有但逻辑未接入」的情况——与同批部分参照页（如下级会员）大量此类缺陷的情况不同。

import type { PageManual } from '../types';

const manual: PageManual = {
  route: 'finance_fund_change_page',
  title: '资金账变',
  overview:
    '商户端「财务管理 › 资金账变」页，按会员/订单/账变类型/操作人/时间等条件查询会员账户的每一笔余额变动流水（充值、提现、投注、中奖、返佣、活动奖励等），支持「修改备注」和导出。页面 auto-load 关闭，首次进入表格为空，必须先满足「会员ID/订单号/账变类型/操作人」四选一（至少填一项）才能查询到数据，商户与时间区间不计入此四选一判定（商户是独立必填项，时间区间选填）。底部有「本页合计」「总计」两行金额汇总。「账变类型」是全站唯一做满 4 层（主类型→子类型→厂商→游戏）的分类树筛选控件，是站内 treeSelect 控件规范的参考范例页。',
  items: [
    // ============ 搜索区（按 createFundChangeSearchColumns 真实顺序）============
    {
      anchor: 'merchant',
      name: '商户',
      group: '搜索',
      interaction:
        '下拉单选（商户选择器 MerchantFilterSelect，multiple:false → 架构级不可清空，无"全部"选项，见《交互规范》§3）。',
      dataSource: '全站商户列表（当前商户端可见商户）。',
      logic:
        '按选中商户过滤账变记录（mock matchMerchantFilter）；不选时组件会自动写回默认商户（左上角激活商户）。',
      limit:
        '必填（红星 showRequireMark + requiredRule）；单选、不可清空——命中 R63（本页商户与会员ID同屏出现）。',
      edge: '与「会员ID/订单号/账变类型/操作人」四选一规则彼此独立：即使商户已选好，四选一四项一个都没填，点查询/导出依然会被拦下弹提示、查不到数据（详见"其它"分组「四选一提示」条）。',
    },
    {
      anchor: 'userID',
      name: '会员ID',
      group: '搜索',
      interaction: '文本输入。',
      dataSource: '用户输入。',
      logic: '按会员ID精确匹配过滤（mock `r.userID === userID`）。',
      limit:
        '选填，但属于四选一之一；仅数字（allowInput onlyDigits），最多9位（INPUT_PRESETS.intNum）。',
      edge: '四选一规则：会员ID/订单号/账变类型/操作人四项至少填一项，否则点「查询」或点「导出」都会被前端短路拦截（hasAtLeastOneSearchKey），弹提示「会员ID/订单号/类型/操作人必须填写一项」、不发请求——不含商户和时间区间。',
    },
    {
      anchor: 'orderNum',
      name: '订单号',
      group: '搜索',
      interaction: '文本输入。',
      dataSource: '用户输入。',
      logic: '按订单号子串匹配过滤（mock includes）。',
      limit: "选填，但属于四选一之一；inputProps('searchKw')预设，最多50字，只拦控制字符。",
      edge: '同「会员ID」条：属四选一其中一项，规则见该条 edge。',
    },
    {
      anchor: 'type',
      name: '账变类型',
      group: '搜索',
      interaction:
        "下拉可勾选树（treeSelect，checkable+cascade+checkStrategy:'child'，多选、可搜索、不做虚拟滚动、菜单宽度随内容自适应）——全站「分类树选择」控件规范的范例页（《交互规范》§5 直接点名本页）。",
      dataSource:
        '主类型→子类型两级取自 src/constants/financialType.ts 的 FINANCIAL_TYPE_GROUPS（充值/提现/游戏/返佣返水/活动奖励 5 个主类型）；仅"游戏"主类型下投注/中奖/电子投注/电子中奖/电子大奖/游戏存入/游戏取回/游戏退还 8 个子类型会再展开第 3 层「厂商」（投注/中奖=自研，其余=8 个三方厂商），厂商有具体游戏时再展开第 4 层「游戏名称」；跟单冻结扣款/跟单解冻加钱两个子类型因共享 subGroup 会被收进一个「跟单」归组节点（仅影响树形展示分组，不影响取值，各自 code 137/138 独立）。',
      logic:
        "勾选任意层级会级联自动全选其下（checkStrategy:'child'），取值恒为最底层叶子（子类型 code / 厂商叶子 v:code:vendorId / 游戏叶子 gm:code:vendorId:gameId），parseFinancialTypeMatchers 解析为匹配项数组，每项内 code/vendorId/gameId 逐维 AND、多个已勾选项之间 OR；mock 已真实按此逻辑过滤（示例数据 90013~90023 号记录专门带 vendorId/gameId 供第 3/4 层过滤验证）。",
      limit: '选填，但属于四选一之一；可清空、可搜索（filterable 命中任意层级标签）、多选到叶子。',
      edge: '同「会员ID」条：属四选一其中一项。⚠️ 是全站唯一真正用满 4 层（主类型/子类型/厂商/游戏）的 treeSelect 范例，其它点名同类控件的页面（如会员游戏账变）未做到第 4 层。',
    },
    {
      anchor: 'reserved',
      name: '操作人',
      group: '搜索',
      interaction: '文本输入。',
      dataSource: '用户输入。',
      logic: '按操作人账号子串匹配过滤（mock 不分大小写 includes）。',
      limit: "选填，但属于四选一之一；inputProps('name')预设。",
      edge: '同「会员ID」条：属四选一其中一项。列表「操作人」列常见值为"系统"（系统自动产生的账变，如投注/中奖/充值）或人工操作员账号（如"admin01"，人工调账场景）。',
    },
    {
      anchor: 'timeRange',
      name: '时间区间',
      group: '搜索',
      interaction:
        '日期时间区间选择（proDateRange，精确到秒），配合工具栏快捷按钮（quick-date="timeRange"）。',
      dataSource: '用户选择，或点工具栏快捷按钮；首屏默认 today（defaultShortcut）。',
      logic:
        '按账变时间（addTimeStr）过滤（mock 区间比较）；展平写回 form.startTime / form.endTime。',
      limit:
        '最多跨 180 天——命中 2026-07-21 当天新定的"业务特批放宽档"（《交互规范》§0 明确点名「资金账变」为该档位参考页，财务对账场景特批，非任意页可抄）。',
      edge: '与四选一规则彼此独立：不填时间区间不影响四选一判定，也不属于四选一四项之一。',
    },

    // ============ 列 ============
    {
      anchor: 'col_userID',
      name: '会员ID列',
      group: '列',
      interaction: '数字以可点击蓝字链接形式展示（跳转类控件，非纯展示，renderMemberIdLink）。',
      dataSource: '行数据 userID + tenantId。',
      logic: '点击调用 openMemberDetailModal 打开会员详情弹窗（全站统一会员ID可点规范）。',
    },

    // ============ 操作 ============
    {
      anchor: 'export',
      name: '导出',
      group: '操作',
      interaction: '点击展开格式下拉（Excel/CSV），选定格式后触发导出（ExportButton 标准组件）。',
      dataSource: 'N/A。',
      logic:
        '导出前会先执行与查询相同的"四选一"校验（hasAtLeastOneSearchKey），不满足则弹提示、不会真正发起导出；满足则按当前搜索条件（不分页，一次性 pageSize 10000）请求导出接口。',
      limit:
        "需 v-permission=['Member:FinanceRecord:GetPageList:Export'] 权限才显示该按钮；同样受四选一约束。",
      edge: '本地 mock 原型无真实后端，点击最终只会弹"导出成功"提示（getFinanceRecordPageListExport 恒返回 data:null），不会真的生成/下载文件——《交互规范》§9 已注明这是全站导出按钮的统一预期行为，非本页独有缺陷。',
    },
    {
      anchor: 'act_editRemark',
      name: '修改备注',
      group: '操作',
      interaction: '点行内「修改备注」按钮打开弹窗（约600px），文本域（4行，带字数统计）编辑备注。',
      dataSource: '弹窗预填当前行 remarkDisplay（值为"--"时预填空）。',
      logic:
        '点「保存」调用 updateFinanceRemark(finanID, 备注内容)，成功后关闭弹窗并刷新列表（tableRef.reload()）；失败提示错误。',
      limit: "备注文本走 inputProps('remark')预设，最多200字。",
      edge: '操作列来自 createActionColumn，代码注释注明"无 UpdateRemark 权限时返回 undefined，整列隐藏"。另外 actionColumn 包了一层 withOpLogCorner(...)，但站内操作记录悬浮徽标当前全局停用（OPLOG_CORNER_ENABLED=false，2026-07-01收窄仅配置中心生效），本页当前不会因此产生任何可见的额外徽标，非本页独有现象。',
    },

    // ============ 其它 ============
    {
      anchor: 'hint_4choose1',
      name: '「会员ID/订单号/类型/操作人必须填写一项」提示',
      group: '其它',
      interaction: '静态文案（红字 + 提示图标），紧挨导出按钮同一行常驻显示，非可点击控件。',
      dataSource: '固定 i18n 文案 member.fundChange.searchAnyOneRequired。',
      logic:
        '提示背后是真实生效的前端强校验（hasAtLeastOneSearchKey）：会员ID/订单号/账变类型/操作人四项一个都不填时，点「查询」或点「导出」都会被短路拦截并弹同一句错误提示，不会真正发请求；商户与时间区间不计入这四项判定。',
      edge: '因 auto-load="false"，首次进页面表格默认空白；即使左上角商户已默认选中，只要四选一四项都空，点查询仍会一直查不到数据——这是本页"必须先按条件查"的核心交互提示，不是可有可无的装饰文案。',
    },
  ],

  // ============ 字段介绍 tab（列序照页面 createFundChangeColumns；仅列表列 + 定义）============
  fields: [
    { name: '商户', def: '该条账变记录所属商户，标签形式展示（renderTenantTag）。' },
    {
      name: '会员ID',
      def: '发生该笔账变的会员ID；数字为可点击链接，点击跳转会员详情弹窗查看该会员完整信息。',
    },
    { name: '订单号', def: '该笔账变关联的业务订单号（如充值单号/提现单号/投注单号）。' },
    {
      name: '账变类型',
      def: '展示为"主类型-子类型"，游戏类记录（投注/中奖/电子投注等）带厂商/游戏时再拼接"·厂商·游戏名"，如"游戏-投注·自研·WinGo"；取自全站单一数据源 constants/financialType.ts。',
    },
    { name: '币种', def: '按该条记录所属商户解析出的结算币种，标签展示；解析不到时显示"--"。' },
    { name: '变动前余额', def: '该笔账变发生前，会员账户的余额。' },
    {
      name: '账变金额',
      def: '该笔账变的金额；正数（充值/中奖等增加）绿色+号展示，负数（投注/提现等扣减）红色-号展示。',
    },
    { name: '变动后余额', def: '该笔账变发生后，会员账户的余额（= 变动前余额 + 账变金额）。' },
    { name: '账变时间', def: '该笔账变发生的时间，按所属商户时区显示。' },
    {
      name: '备注说明',
      def: '该笔账变的备注文字，无备注时显示"--"；可通过操作列「修改备注」编辑。',
    },
    {
      name: '操作人',
      def: '产生该笔账变的操作来源；系统自动产生的账变（充值/投注/中奖等）显示"系统"，人工调账则显示对应操作员账号。',
    },
  ],
};

export default manual;
