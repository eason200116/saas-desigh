import type { Editor, JSONContent } from '@tiptap/core';
import type { Component } from 'vue';

// 'plain'：无 AI 的纯净富文本档（用于协议管理等公开正文，去掉 AI 改写/续写等 AI 能力）
export type TiptapEditorProfile = 'basic' | 'activity' | 'public' | 'email' | 'plain';
export type TiptapAiActionType =
  | 'continue'
  | 'generate'
  | 'rewrite'
  | 'expand'
  | 'shorten'
  | 'translate'
  | 'polish';

export interface TiptapAiActionDefinition {
  key: TiptapAiActionType;
  label: string;
  description: string;
  requiresSelection?: boolean;
  defaultInstruction?: string;
}

export interface TiptapAiActionRequest {
  action: TiptapAiActionType;
  profile: TiptapEditorProfile;
  document: string;
  title?: string;
  selection?: string;
  instruction?: string;
}

export interface TiptapAiApplyPayload {
  action: TiptapAiActionType;
  result: string;
  hasSelection: boolean;
}

export interface TiptapQuickActionContext {
  editor: Editor;
  profile: TiptapEditorProfile;
  onLink: () => void;
  onImage: () => void;
  onAiAction: (action: TiptapAiActionType) => void;
}

export type TiptapQuickActionGroup = 'format' | 'blocks' | 'templates' | 'ai';

export interface TiptapQuickActionItem {
  key: string;
  label: string;
  description: string;
  group: TiptapQuickActionGroup;
  keywords: string[];
  icon?: Component;
  canRun?: (editor: Editor) => boolean;
  isVisible?: (context: TiptapQuickActionContext) => boolean;
  run: (context: TiptapQuickActionContext) => void;
}

export interface TiptapQuickActionGroupSection {
  key: TiptapQuickActionGroup;
  label: string;
  items: TiptapQuickActionItem[];
}

export interface TiptapImageUploadResult {
  url: string;
  alt?: string;
}

export type TiptapImageUploadHandler = (
  file: File,
) => Promise<TiptapImageUploadResult> | TiptapImageUploadResult;

export interface BasicTiptapEditorExpose {
  focus: () => void;
  getHTML: () => string;
  getJSON: () => JSONContent | null;
  setHTML: (html: string) => void;
  insertContent: (content: string) => void;
  replaceSelection: (content: string) => void;
  getSelectionText: () => string;
}
