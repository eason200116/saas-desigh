<template>
  <div class="member-detail-shell" :class="`member-detail-shell--${mode}`">
    <div v-if="historyTabs.length > 1" class="query-history-bar">
      <div
        v-for="tab in historyTabs"
        :key="tab.id"
        class="query-history-bar__item"
        :class="{ 'is-active': String(tab.id) === String(currentMemberId) }"
        @click="switchToMember(tab.id)"
      >
        <span class="query-history-bar__label">ID: {{ tab.id }}</span>
        <span class="query-history-bar__close" @click.stop="removeHistoryTab(tab.id)">×</span>
      </div>
    </div>

    <div class="modal-toolbar">
      <span class="modal-toolbar__label">
        {{ t('member.detail.basic.memberId') }}<span class="modal-toolbar__required">*</span>
      </span>
      <n-input
        v-model:value="searchForm.userId"
        :placeholder="t('member.detail.userIdPlaceholder')"
        size="small"
        style="width: 120px"
        :allow-input="onlyDigits"
        @keyup.enter="handleQuery"
      />
      <!-- 「日期」时间查询：样板 1100002 已下放到「数据统计」Tab 内渲染（2026-07-14 用户要求），此处隐藏；
           其它会员没有数据统计 Tab，顶部日期原样保留、不受影响（其他不改） -->
      <template v-if="!isSampleMember">
        <span class="modal-toolbar__label">{{ t('member.detail.basic.date') }}</span>
        <div style="width: 280px; flex-shrink: 0">
          <ProDateRangeInput
            v-model:value="searchForm.timeRange"
            :timezone="datePickerTimezone"
            :placeholder="t('member.detail.dateRangePlaceholder')"
            display-format="yyyy-MM-dd"
            value-format="string"
            :show-time="false"
            :max-days="3650"
            :allow-future="false"
            shortcut-preset="default"
            clearable
            size="small"
          />
        </div>
      </template>
      <n-button type="primary" size="small" @click="handleQuery">
        {{ t('member.detail.query') }}
      </n-button>
    </div>

    <keep-alive :max="10">
      <MemberDetailContent
        :key="currentMemberId"
        :member-id="currentMemberId"
        :tenant-id="props.tenantId"
        :global-time-range="searchForm.timeRange"
        :query-version="queryVersion"
        @update:lastWithdrawTime="handleLastWithdrawTimeUpdate"
      />
    </keep-alive>
  </div>
</template>

<script setup lang="ts">
  import { computed, provide, reactive, ref, toRef, watch } from 'vue';
  import { useI18n } from 'vue-i18n';
  import { ProDateRangeInput } from '@/components';
  import { useUser, useTenantOptions } from '@/hooks';
  import { provideTenantOverride } from '@/hooks/useUser';
  import { onlyDigits } from '@/utils';
  import MemberDetailContent from './MemberDetailContent.vue';
  import { MEMBER_DETAIL_HAS_HISTORY_BAR, MEMBER_DETAIL_TIME_QUERY } from './useMemberContext';

  interface MemberDetailShellProps {
    memberId: string | number;
    tenantId?: number | null;
    mode?: 'modal' | 'page';
  }

  const props = withDefaults(defineProps<MemberDetailShellProps>(), {
    tenantId: null,
    mode: 'modal',
  });
  const emit = defineEmits<{
    'change:member-id': [id: string];
  }>();

  provideTenantOverride(toRef(props, 'tenantId'));

  const { t } = useI18n();
  const { message, parseTimeStr } = useUser();
  const { getTenantTimeZone } = useTenantOptions();

  // 顶部「日期」picker 按会员所属商户时区展示（独立组件，不在 ProCrudTable 内，
  // 需显式传 timezone；为空则回退默认商户，与改动前一致）
  const datePickerTimezone = computed(() =>
    props.tenantId != null ? getTenantTimeZone(props.tenantId) || null : null,
  );

  const searchForm = reactive<{ userId: string; timeRange: [number, number] | null }>({
    userId: '',
    timeRange: null,
  });
  const queryVersion = ref(0);
  const MAX_HISTORY_TABS = 10;
  const currentMemberId = ref('');
  const historyTabs = ref<{ id: string }[]>([]);
  const timeRangeCache = new Map<string, [number, number] | null>();

  // 提供给内部 Tab：是否存在顶部历史标签栏（多会员切换条），用于子表格按需调整 max-height
  const hasHistoryBar = computed(() => historyTabs.value.length > 1);
  provide(MEMBER_DETAIL_HAS_HISTORY_BAR, hasHistoryBar);

  // 【已铺开·2026-07-14 用户确认】顶部「日期」时间查询已下放到「数据统计」Tab 内渲染（该 Tab 现已对全部会员开放），
  // 故此处对所有会员一律隐藏、恒为 true。保留变量以便一行收回（改回 Number(currentMemberId.value) === 1100002）。
  const isSampleMember = computed(() => true);

  // 下放「时间查询」能力给 Tab 内控件：时间**状态仍在本 Shell**（searchForm.timeRange），
  // 故其值照旧作为 globalTimeRange 流向 投注 / 系统日志 / 资金账变 的兜底时间、行为不变；
  // apply() 复用原顶部「查询」的机制（queryVersion++ → 当前 Tab 按新时间重载）。
  provide(MEMBER_DETAIL_TIME_QUERY, {
    timeRange: toRef(searchForm, 'timeRange'),
    timezone: datePickerTimezone,
    apply: () => {
      queryVersion.value++;
    },
  });

  /**
   * 添加会员查询历史标签。
   * 规则：最多保留 10 个，超出时提示，不强制淘汰旧标签。
   */
  function addHistoryTab(id: string | number) {
    const sid = String(id);
    if (!sid) return true;
    if (historyTabs.value.find((tab) => String(tab.id) === sid)) return true;
    if (historyTabs.value.length >= MAX_HISTORY_TABS) {
      message.warning(t('member.detail.maxTabsWarning', { max: MAX_HISTORY_TABS }));
      return false;
    }
    historyTabs.value.push({ id: sid });
    return true;
  }

  /**
   * 切换当前查看的会员，并恢复该会员上次查询时使用的时间范围。
   */
  function switchToMember(id: string | number) {
    const sid = String(id);
    if (currentMemberId.value) {
      timeRangeCache.set(currentMemberId.value, searchForm.timeRange);
    }
    currentMemberId.value = sid;
    searchForm.userId = sid;
    searchForm.timeRange = timeRangeCache.has(sid)
      ? timeRangeCache.get(sid)!
      : searchForm.timeRange;
    emit('change:member-id', sid);
  }

  /**
   * 删除历史标签；如果删除的是当前标签，则切换到最近的一个标签。
   */
  function removeHistoryTab(id: string | number) {
    const sid = String(id);
    const idx = historyTabs.value.findIndex((tab) => String(tab.id) === sid);
    if (idx === -1) return;

    historyTabs.value.splice(idx, 1);
    timeRangeCache.delete(sid);

    if (sid === String(currentMemberId.value) && historyTabs.value.length > 0) {
      const nextTab = historyTabs.value[Math.min(idx, historyTabs.value.length - 1)];
      switchToMember(nextTab.id);
    }
  }

  watch(
    () => props.memberId,
    (val) => {
      const sid = String(val ?? '');
      if (addHistoryTab(sid)) switchToMember(sid);
    },
    { immediate: true },
  );

  /**
   * 查询行为：
   * - 同一会员：递增 queryVersion，触发当前详情刷新
   * - 新会员：加入标签并切换详情上下文
   */
  function handleQuery() {
    const id = searchForm.userId.trim();
    if (!id) {
      message.warning(t('member.detail.inputUserId'));
      return;
    }

    if (id === String(currentMemberId.value)) {
      queryVersion.value++;
      return;
    }

    if (!addHistoryTab(id)) return;
    switchToMember(id);
  }

  /**
   * 会员详情返回上次提现时间后，自动为首次访问的会员补齐默认日期范围。
   * 规则：仅在当前会员尚未缓存时间范围，且用户未手动设置时间时生效。
   */
  function handleLastWithdrawTimeUpdate(lastWithdrawTime: string) {
    const sid = String(currentMemberId.value || '');
    if (!sid || timeRangeCache.has(sid) || searchForm.timeRange) return;

    const startTime = parseTimeStr(lastWithdrawTime);
    if (!startTime) return;

    const defaultRange: [number, number] = [startTime, Date.now()];
    searchForm.timeRange = defaultRange;
    timeRangeCache.set(sid, defaultRange);
  }
</script>

<style lang="less" scoped>
  .member-detail-shell {
    display: flex;
    flex-direction: column;
    height: 100%;
    min-height: 0;
  }

  .member-detail-shell--page {
    padding: 12px;
    background: #fff;
    border-radius: 8px;
    border: 1px solid #f0f0f0;
  }

  .query-history-bar {
    display: flex;
    flex-wrap: wrap;
    gap: 4px;
    padding: 6px 10px;
    background: #f0f5ff;
    border: 1px solid #d6e4ff;
    border-radius: 6px;
    margin-bottom: 8px;
  }

  .query-history-bar__item {
    display: inline-flex;
    align-items: center;
    gap: 4px;
    padding: 2px 8px 2px 10px;
    border-radius: 4px;
    border: 1px solid #d9d9d9;
    background: #fff;
    font-size: 12px;
    color: #595959;
    cursor: pointer;
    user-select: none;
    transition: all 0.2s;
  }

  .query-history-bar__item:hover {
    border-color: #4096ff;
    color: #1677ff;
  }

  .query-history-bar__item.is-active {
    border-color: #1677ff;
    background: #e6f4ff;
    color: #1677ff;
    font-weight: 500;
  }

  .query-history-bar__label {
    white-space: nowrap;
  }

  .query-history-bar__close {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 14px;
    height: 14px;
    border-radius: 50%;
    font-size: 13px;
    line-height: 1;
    color: #8c8c8c;
    transition: all 0.15s;
  }

  .query-history-bar__close:hover {
    background: #ff4d4f;
    color: #fff;
  }

  .modal-toolbar {
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 6px 10px;
    background: #f8fafc;
    border-radius: 6px;
    border: 1px solid #f0f0f0;
    margin-bottom: 8px;
  }

  .modal-toolbar__label {
    font-size: 13px;
    color: #595959;
    white-space: nowrap;
  }

  .modal-toolbar__required {
    color: #d03050;
  }
</style>
