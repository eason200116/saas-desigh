export type OpsTemplateKey = 'announcement' | 'activity' | 'rule';

export interface OpsTemplateBuildContext {
  currentDate: string;
  nextDate: string;
}

type OpsTemplateBuilder = (context: OpsTemplateBuildContext) => string;

export const OPS_TEMPLATE_KEYS: OpsTemplateKey[] = ['announcement', 'activity', 'rule'];

const OPS_TEMPLATE_BUILDERS: Record<OpsTemplateKey, OpsTemplateBuilder> = {
  announcement: ({ currentDate }) => `
    <h2>【系统维护通知】</h2>
    <p>发布时间：${currentDate}</p>
    <p>为保障平台稳定，系统将进行例行维护升级，请您提前做好安排。</p>
    <p>影响范围：Web/H5/App 登录、充值、提款、转账、活动报名。</p>
    <p>维护时段：${currentDate} 02:00 - 03:00（UTC+8）</p>
    <h3>维护期间说明</h3>
    <ul>
      <li>维护期间页面可能短时不可访问，已提交订单将延后处理。</li>
      <li>维护完成后请刷新页面并重新登录，如仍异常请联系在线客服。</li>
    </ul>
    <h3>用户操作建议</h3>
    <ol>
      <li>请在维护前完成资金操作并保留订单截图。</li>
      <li>遇到异常提示时，请勿重复提交，等待系统恢复后再操作。</li>
    </ol>
    <blockquote>
      <p>温馨提示：最终活动/维护时间以平台实时公告为准。</p>
    </blockquote>
  `,
  activity: ({ currentDate, nextDate }) => `
    <h2>【首存加赠活动】</h2>
    <p>活动时间：${currentDate} 00:00 至 ${nextDate} 23:59（UTC+8）</p>
    <h3>活动对象与内容</h3>
    <p>活动期间首笔存款满足条件可领取对应加赠奖励，每位用户限参与一次。</p>
    <h3>参与步骤</h3>
    <ol>
      <li>完成登录后进入【活动中心】点击“立即参与”。</li>
      <li>在活动页完成首笔充值，系统将按档位发放奖励。</li>
      <li>奖励发放后可在【钱包记录】查看到账明细。</li>
    </ol>
    <h3>稽核与风控规则</h3>
    <ul>
      <li>活动彩金需满足指定流水倍数后方可提款，具体以活动页说明为准。</li>
      <li>同设备/同IP/异常套利行为将取消资格并回收奖励。</li>
    </ul>
  `,
  rule: () => `
    <h2>平台通用规则</h2>
    <p>以下规则适用于平台常规活动与公告场景，请按实际业务补充参数。</p>
    <ol>
      <li>活动仅限已完成账号实名认证的用户参与。</li>
      <li>奖励发放后将进入钱包，可在账变记录中查询。</li>
      <li>若发现违规套利或批量注册，平台有权取消资格。</li>
      <li>平台保留在法律范围内对活动规则的最终解释权。</li>
    </ol>
    <blockquote>
      <p>温馨提示：如遇争议，以平台最新公告与用户协议为准。</p>
    </blockquote>
  `,
};

export function isOpsTemplateKey(value: string): value is OpsTemplateKey {
  return OPS_TEMPLATE_KEYS.includes(value as OpsTemplateKey);
}

export function buildOpsTemplateHtml(
  templateKey: OpsTemplateKey,
  context: OpsTemplateBuildContext,
) {
  return OPS_TEMPLATE_BUILDERS[templateKey](context);
}
