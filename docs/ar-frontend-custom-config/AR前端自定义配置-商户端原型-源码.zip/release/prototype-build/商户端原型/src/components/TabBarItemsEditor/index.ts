export { default as TabBarItemsEditor } from './TabBarItemsEditor.vue';
export type { TabBarItem, FrontStyleTabBarItem } from './TabBarItemsEditor.vue';
export { default as BackgroundInput } from './BackgroundInput.vue';
