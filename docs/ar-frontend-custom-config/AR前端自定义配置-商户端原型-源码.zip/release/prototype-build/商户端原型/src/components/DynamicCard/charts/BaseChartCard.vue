<script setup lang="ts">
  import { ref } from 'vue';
  import { useI18n } from 'vue-i18n';

  interface Props {
    title: string;
    height?: string | number;
    loading?: boolean;
    showToggle?: boolean;
    hasData?: boolean;
  }

  const props = withDefaults(defineProps<Props>(), {
    height: 220,
    loading: false,
    showToggle: true,
    hasData: false,
  });

  const emit = defineEmits<{
    'view-change': [mode: 'chart' | 'table'];
  }>();

  const { t } = useI18n();

  // 视图模式
  const viewMode = ref<'chart' | 'table'>('chart');

  const handleViewChange = (mode: 'chart' | 'table') => {
    viewMode.value = mode;
    emit('view-change', mode);
  };

  // 卡片整体高度直接套到 wrapper；chart slot 内部用 100% 跟随 body 流，不再传绝对高度
  const wrapperHeight = typeof props.height === 'number' ? `${props.height}px` : props.height;
  // 表格视图最大高度：扣掉 header + body padding，避免溢出
  const HEADER_HEIGHT = 46;
  const BODY_PADDING = 24;
  const heightNumber =
    typeof props.height === 'number' ? props.height : parseInt(props.height as string);
  const tableMaxHeight = Math.max(120, heightNumber - HEADER_HEIGHT - BODY_PADDING);

  defineExpose({
    viewMode,
  });
</script>

<template>
  <div class="base-chart-card" :style="{ height: wrapperHeight }">
    <!-- 卡片头部 -->
    <div class="base-chart-card__header">
      <span class="base-chart-card__title">{{ title }}</span>
      <div class="base-chart-card__actions">
        <!-- 图表/表格切换 -->
        <n-button-group v-if="showToggle" size="tiny">
          <n-button
            :type="viewMode === 'chart' ? 'primary' : 'default'"
            @click="handleViewChange('chart')"
          >
            {{ t('analytics.common.chart') }}
          </n-button>
          <n-button
            :type="viewMode === 'table' ? 'primary' : 'default'"
            @click="handleViewChange('table')"
          >
            {{ t('analytics.common.table') }}
          </n-button>
        </n-button-group>
        <!-- 额外操作插槽 -->
        <slot name="actions" />
      </div>
    </div>

    <!-- 卡片内容 -->
    <div class="base-chart-card__body">
      <n-spin :show="loading">
        <template v-if="hasData">
          <!-- 图表视图：slot 拿到 100%，让 chart 跟随 body flex 撑高 -->
          <div v-show="viewMode === 'chart'" class="base-chart-card__chart">
            <slot name="chart" height="100%" />
          </div>
          <!-- 表格视图 -->
          <div v-show="viewMode === 'table'" class="base-chart-card__table">
            <slot name="table" :max-height="tableMaxHeight" />
          </div>
        </template>
        <n-empty v-else :description="t('analytics.common.noData')" />
      </n-spin>
    </div>
  </div>
</template>

<script lang="ts">
  export default {
    name: 'BaseChartCard',
  };
</script>

<style lang="less" scoped>
  .base-chart-card {
    background: #fff;
    border: 1px solid #f0f0f0;
    border-radius: 8px;
    height: 100%;
    display: flex;
    flex-direction: column;

    &__header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 12px 16px;
      border-bottom: 1px solid #f0f0f0;
    }

    &__title {
      font-size: 14px;
      font-weight: 500;
      color: #262626;
      flex: 1;
    }

    &__actions {
      display: flex;
      align-items: center;
      gap: 8px;
      margin-right: 28px; // 给 dynamic-card-action 留出空间

      ::v-deep(.n-button) {
        font-size: 12px;
        padding: 0 8px;
      }
    }

    &__body {
      flex: 1;
      min-height: 0;
      padding: 12px;
      overflow: hidden;

      // n-spin 包裹层撑满 body，避免 chart slot 高度退化
      ::v-deep(.n-spin-container),
      ::v-deep(.n-spin-content) {
        height: 100%;
      }
    }

    &__chart,
    &__table {
      height: 100%;
    }
  }

  // Dark theme
  .dark .base-chart-card {
    background: #242b3d;
    border-color: #3a4459;

    &__title {
      color: #e5e7eb;
    }
  }
</style>
