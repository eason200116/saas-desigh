<script setup lang="ts">
  /**
   * 漏斗趋势卡片
   * 数据格式：FunnelDataPoint[]
   */
  import { ref, computed } from 'vue';
  import { useI18n } from 'vue-i18n';
  import Chart1 from '@/components/Chart/chart1.vue';
  import { InformationCircleOutline } from '@vicons/ionicons5';
  import type { CardConfig, FunnelDataPoint } from '../types';

  const { t } = useI18n();

  interface TrendItem {
    date: string;
    value: number;
  }

  interface Props {
    title: string;
    data?: FunnelDataPoint[];
    config?: CardConfig;
    trendData?: TrendItem[];
    conversionPeriod?: string;
    tooltip?: string;
    showFunnelToggle?: boolean;
    height?: string | number;
    loading?: boolean;
  }

  const props = withDefaults(defineProps<Props>(), {
    data: () => [],
    conversionPeriod: '',
    showFunnelToggle: true,
    height: 220,
    loading: false,
  });

  // 默认转化周期文案：父组件未传 conversionPeriod 时，按 i18n 渲染「{count}天」。
  const resolvedConversionPeriod = computed(
    () =>
      props.conversionPeriod || t('analytics.trafficDashboard.funnel.daysWithCount', { count: 1 }),
  );

  // 有效数据
  const effectiveData = computed(() => props.data || []);

  // 趋势数据
  const effectiveTrendData = computed(() => props.trendData || []);

  // 视图模式
  const viewMode = ref<'funnel' | 'trend' | 'table'>('funnel');

  // 计算总转化率（最后一步的 percentage）
  const totalRate = computed(() => {
    if (effectiveData.value.length === 0) return 0;
    return effectiveData.value[effectiveData.value.length - 1]?.percentage || 0;
  });

  // 表格列配置
  const tableColumns = computed(() => [
    {
      title: t('analytics.trafficDashboard.funnel.tableStep'),
      key: 'step',
      render: (_row: FunnelDataPoint, index: number) => index + 1,
    },
    { title: t('analytics.trafficDashboard.funnel.tableName'), key: 'name' },
    { title: t('analytics.trafficDashboard.funnel.tableCount'), key: 'count' },
    {
      title: t('analytics.trafficDashboard.funnel.conversionRate'),
      key: 'percentage',
      render: (row: FunnelDataPoint) => `${row.percentage}%`,
    },
  ]);

  // 趋势图配置
  const trendChartConfig = computed(() => ({
    tooltip: {
      trigger: 'axis',
      formatter: (params: any) => {
        const item = params[0];
        const rateLabel = t('analytics.trafficDashboard.funnel.conversionRate');
        return `${item.axisValue}<br/>${item.marker} ${rateLabel}: ${item.value}%`;
      },
    },
    grid: { left: 40, right: 20, top: 30, bottom: 30 },
    xAxis: {
      type: 'category',
      data: effectiveTrendData.value.map((d) => d.date.slice(5)),
      axisLabel: { fontSize: 10, color: '#8c8c8c' },
      axisLine: { lineStyle: { color: '#e8e8e8' } },
      axisTick: { show: false },
    },
    yAxis: {
      type: 'value',
      axisLabel: { fontSize: 10, color: '#8c8c8c', formatter: '{value}%' },
      splitLine: { lineStyle: { color: '#f0f0f0', type: 'dashed' } },
    },
    series: [
      {
        name: t('analytics.trafficDashboard.funnel.conversionRate'),
        type: 'line',
        data: effectiveTrendData.value.map((d) => d.value),
        smooth: true,
        itemStyle: { color: '#2080f0' },
        areaStyle: {
          color: {
            type: 'linear',
            x: 0,
            y: 0,
            x2: 0,
            y2: 1,
            colorStops: [
              { offset: 0, color: 'rgba(32, 128, 240, 0.2)' },
              { offset: 1, color: 'rgba(32, 128, 240, 0.02)' },
            ],
          },
        },
        label: { show: true, position: 'top', fontSize: 10, color: '#8c8c8c', formatter: '{c}%' },
      },
    ],
  }));
</script>

<template>
  <div class="funnel-trend-card">
    <div class="funnel-trend-card__header">
      <span class="funnel-trend-card__title">{{ title }}</span>
      <n-tooltip v-if="tooltip" trigger="hover">
        <template #trigger>
          <n-icon size="14" class="funnel-trend-card__info"><InformationCircleOutline /></n-icon>
        </template>
        {{ tooltip }}
      </n-tooltip>
      <div class="funnel-trend-card__toggle">
        <n-button-group size="tiny">
          <n-button
            :type="viewMode === 'funnel' ? 'primary' : 'default'"
            @click="viewMode = 'funnel'"
          >
            {{ t('analytics.trafficDashboard.funnel.modeFunnel') }}
          </n-button>
          <n-button
            :type="viewMode === 'trend' ? 'primary' : 'default'"
            @click="viewMode = 'trend'"
          >
            {{ t('analytics.trafficDashboard.funnel.modeTrend') }}
          </n-button>
          <n-button
            :type="viewMode === 'table' ? 'primary' : 'default'"
            @click="viewMode = 'table'"
          >
            {{ t('analytics.trafficDashboard.funnel.modeTable') }}
          </n-button>
        </n-button-group>
      </div>
    </div>

    <div class="funnel-trend-card__period">
      {{ t('analytics.trafficDashboard.funnel.conversionPeriod') }}: {{ resolvedConversionPeriod }}
    </div>

    <div class="funnel-trend-card__content">
      <n-spin :show="loading">
        <!-- 漏斗/趋势视图 -->
        <div
          v-if="viewMode === 'funnel' || viewMode === 'trend'"
          class="funnel-trend-card__main-view"
        >
          <div class="funnel-trend-card__left">
            <div class="funnel-trend-card__total-rate">
              <div class="funnel-trend-card__total-label">
                {{ t('analytics.trafficDashboard.funnel.conversionRate') }}
              </div>
              <div class="funnel-trend-card__total-value">{{ totalRate }}%</div>
            </div>
            <div class="funnel-trend-card__steps">
              <div
                v-for="(item, index) in effectiveData"
                :key="index"
                class="funnel-trend-card__step"
              >
                <div class="funnel-trend-card__step-badge" :class="`step-${(index % 3) + 1}`">{{
                  index + 1
                }}</div>
                <div class="funnel-trend-card__step-info">
                  <span class="funnel-trend-card__step-name">{{ item.name }}</span>
                  <span class="funnel-trend-card__step-value">{{ item.count }}</span>
                </div>
                <div v-if="index > 0" class="funnel-trend-card__step-rate">
                  <span class="funnel-trend-card__rate-text">{{ item.percentage }}%</span>
                </div>
              </div>
            </div>
          </div>
          <div class="funnel-trend-card__chart">
            <Chart1 :config="trendChartConfig" height="220px" />
          </div>
        </div>

        <!-- 表格视图 -->
        <div v-else>
          <n-data-table
            :columns="tableColumns"
            :data="effectiveData"
            :bordered="false"
            size="small"
          />
        </div>
      </n-spin>
    </div>
  </div>
</template>

<script lang="ts">
  export default { name: 'FunnelTrendCard' };
</script>

<style lang="less" scoped>
  .funnel-trend-card {
    background: #fff;
    border: 1px solid #f0f0f0;
    border-radius: 8px;
    height: 100%;
    display: flex;
    flex-direction: column;

    &__header {
      display: flex;
      align-items: center;
      gap: 6px;
      padding: 12px 16px;
      border-bottom: 1px solid #f0f0f0;
    }

    &__title {
      font-size: 14px;
      font-weight: 500;
      color: #262626;
    }
    &__info {
      color: #bfbfbf;
      cursor: help;
    }
    &__toggle {
      margin-left: auto;
      margin-right: 28px; // 给 dynamic-card-action 留出空间
      ::v-deep(.n-button) {
        font-size: 12px;
        padding: 0 10px;
      }
    }

    &__period {
      padding: 8px 16px;
      font-size: 12px;
      color: #8c8c8c;
      border-bottom: 1px solid #f5f5f5;
    }

    &__content {
      flex: 1;
      padding: 12px;
      overflow: hidden;
    }

    &__main-view {
      display: flex;
      gap: 12px;
      height: 100%;
    }
    &__left {
      flex: 0 0 200px;
      display: flex;
      flex-direction: column;
      gap: 12px;
    }
    &__chart {
      flex: 1;
      min-width: 0;
    }

    &__total-rate {
      background: linear-gradient(135deg, #f0a020 0%, #ff6b35 100%);
      border-radius: 8px;
      padding: 10px 12px;
      color: #fff;
    }

    &__total-label {
      font-size: 12px;
      opacity: 0.9;
    }
    &__total-value {
      font-size: 20px;
      font-weight: 600;
      font-family: 'DIN Alternate', sans-serif;
    }

    &__steps {
      display: flex;
      flex-direction: column;
      gap: 8px;
    }

    &__step {
      display: flex;
      align-items: center;
      gap: 8px;
    }

    &__step-badge {
      width: 20px;
      height: 20px;
      border-radius: 4px;
      font-size: 12px;
      font-weight: 500;
      color: #fff;
      display: flex;
      align-items: center;
      justify-content: center;
      flex-shrink: 0;
      &.step-1 {
        background: #2080f0;
      }
      &.step-2 {
        background: #f0a020;
      }
      &.step-3 {
        background: #18a058;
      }
    }

    &__step-info {
      display: flex;
      flex-direction: column;
      flex: 1;
      min-width: 0;
    }
    &__step-name {
      font-size: 12px;
      color: #595959;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }
    &__step-value {
      font-size: 12px;
      color: #262626;
      font-weight: 500;
    }

    &__step-rate {
      margin-left: auto;
    }
    &__rate-text {
      font-size: 12px;
      color: #f0a020;
      font-weight: 500;
    }
  }

  .dark .funnel-trend-card {
    background: #242b3d;
    border-color: #3a4459;
    &__header,
    &__period {
      border-color: #3a4459;
    }
    &__title {
      color: #e5e7eb;
    }
    &__step-name {
      color: #9ca3af;
    }
    &__step-value {
      color: #e5e7eb;
    }
  }
</style>
