import { h, ref } from 'vue';
import { useRouter } from 'vue-router';
import {
  NDataTable,
  NInput,
  NInputNumber,
  NRadio,
  NRadioGroup,
  useDialog,
  useModal,
} from 'naive-ui';
import { useI18n } from 'vue-i18n';
import { useUser } from '@/hooks';
import { useMemberDetailModal } from '@/hooks/useMemberDetailModal';
import { currency } from '@/utils';
import { setCodeNeed, getCodeDone } from '@/utils/memberCodeProgress';
import { useMemberContext, MEMBER_DETAIL_CHILD_Z_INDEX } from '../useMemberContext';
import { commissionModeLabel } from './buildDetailData';
import { attrLabel } from './attributionLabel';

/**
 * 基本信息 Tab 的编辑操作逻辑
 */
export function useBasicInfo() {
  const { memberId, tenantId: ctxTenantId, detailData } = useMemberContext();
  const {
    message,
    getOptions: getMemberOptions,
    updateMemberRemark,
    updateMemberState,
    updateMemberIntegral,
  } = useUser();
  const modal = useModal();
  const dialog = useDialog();
  const { t } = useI18n();
  // 命令式会员详情弹窗（单例）——下钻跳转前用于关闭本弹窗
  const { closeMemberDetail } = useMemberDetailModal();

  function handleItemAction(sectionKey, item) {
    if (item.actionKey === 'remark') handleEditRemark(item);
    else if (item.actionKey === 'requiredBetAmount') handleEditRequiredAmount(sectionKey, item);
    else if (item.actionKey === 'state') handleEditState(item);
    else if (item.actionKey === 'integral') handleEditIntegral(item);
  }

  /** 会员状态直接开关（R47）：点击切换 → 二次确认 → mock 提交 → 回写状态 + 高亮 + Toast */
  function handleToggleState(item: any, val: boolean) {
    const target = val ? 1 : 0;
    const rawOptions = getMemberOptions('userStateList');
    const label =
      rawOptions.find((o: any, idx: number) => (o.value ?? idx) === target)?.label ?? item.value;
    const action = val
      ? t('member.user.switchToggle.on')
      : t('member.user.switchToggle.off');
    dialog.warning({
      zIndex: MEMBER_DETAIL_CHILD_Z_INDEX,
      title: t('member.user.switchToggle.confirmTitle'),
      content: t('member.user.switchToggle.confirmContent', {
        action,
        label: t('member.detail.basic.userStatus'),
      }),
      positiveText: t('common.confirm'),
      negativeText: t('common.cancel'),
      onPositiveClick: async () => {
        try {
          const { code, msg } = await updateMemberState(
            memberId.value,
            target,
            ctxTenantId.value ?? null,
          );
          if (code !== 0) {
            message.error(msg || t('member.detail.basic.editStatusFailed'));
            return false;
          }
          message.success(t('member.detail.basic.editStatusSuccess'));
          item._userState = target;
          item.value = label;
          item.highlight = target === 1 ? 'success' : 'error';
        } catch (e) {
          message.error(t('member.detail.basic.editStatusFailed'));
          return false;
        }
      },
    });
  }

  /** 头部开关（是否领取返佣 / 是否对上级返佣）：点击切换需二次确认，确认后 mock 提交 + 回写开关值 */
  function handleToggleSwitch(sw: { label: string; value: boolean }, val: boolean) {
    const action = val ? t('member.user.switchToggle.on') : t('member.user.switchToggle.off');
    dialog.warning({
      zIndex: MEMBER_DETAIL_CHILD_Z_INDEX,
      title: t('member.user.switchToggle.confirmTitle'),
      content: t('member.user.switchToggle.confirmContent', { action, label: sw.label }),
      positiveText: t('common.confirm'),
      negativeText: t('common.cancel'),
      onPositiveClick: () => {
        sw.value = val;
        message.success(t('member.user.switchToggle.success', { label: sw.label }));
      },
    });
  }

  function handleEditRemark(item) {
    const remarkRef = ref(item.value === '--' ? '' : item.value);
    const inst = modal.create({
      zIndex: MEMBER_DETAIL_CHILD_Z_INDEX,
      title: t('member.detail.basic.editRemark'),
      preset: 'dialog',
      class: 'w-[500px]',
      showIcon: false,
      content: () =>
        h(NInput, {
          type: 'textarea',
          rows: 4,
          placeholder: t('member.detail.basic.remarkPlaceholder'),
          value: remarkRef.value,
          onUpdateValue: (val) => {
            remarkRef.value = val;
          },
        }),
      positiveText: t('common.save'),
      negativeText: t('common.cancel'),
      onPositiveClick: async () => {
        inst.loading = true;
        try {
          // 嵌入弹窗时按订单商户更新备注
          const { code, msg } = await updateMemberRemark(
            memberId.value,
            remarkRef.value,
            ctxTenantId.value ?? null,
          );
          if (code !== 0) {
            message.error(msg || t('member.detail.basic.editRemarkFailed'));
            return false;
          }
          message.success(t('member.detail.basic.editRemarkSuccess'));
          item.value = remarkRef.value || '--';
        } catch (e) {
          message.error(t('member.detail.basic.editRemarkFailed'));
          return false;
        } finally {
          inst.loading = false;
        }
      },
    });
  }

  // 修改「需要打码量」（打码进度行的编辑按钮）：只改需要打码量、写共享 store → 列表 + 详情进度条一并联动；
  // 已完成打码量按会员列表标准不动，重算进度 = 已完成 ÷ 需要。纯前端 mock、直接改内存 store。
  function handleEditRequiredAmount(sectionKey, item) {
    const amountRef = ref(parseFloat(String(item.value).replace(/,/g, '')) || 0);
    modal.create({
      zIndex: MEMBER_DETAIL_CHILD_Z_INDEX,
      title: t('member.detail.basic.editRequiredAmount'),
      preset: 'dialog',
      class: 'w-[400px]',
      showIcon: false,
      content: () =>
        h(NInputNumber, {
          value: amountRef.value,
          placeholder: t('member.detail.basic.requiredAmountPlaceholder'),
          style: 'width: 100%',
          min: 0,
          onUpdateValue: (val) => {
            amountRef.value = val ?? 0;
          },
        }),
      positiveText: t('common.save'),
      negativeText: t('common.cancel'),
      onPositiveClick: () => {
        const needVal = amountRef.value;
        // 只改「需要打码量」→ 写共享 store；已完成不动，进度 = 已完成 ÷ 需要
        setCodeNeed(memberId.value, needVal);
        const doneVal = getCodeDone(memberId.value, 0);
        const sec = detailData.value?.basicSections?.find((s: any) => s.key === sectionKey);
        if (sec?.progress) {
          sec.progress.need = currency(needVal);
          sec.progress.pct =
            needVal > 0 ? Math.max(0, Math.min(100, Math.round((doneVal / needVal) * 100))) : 100;
          sec.progress.reached = doneVal >= needVal;
        }
        message.success(t('member.detail.basic.editRequiredAmountSuccess'));
      },
    });
  }

  function handleEditIntegral(item) {
    const integralRef = ref(parseFloat(String(item.value).replace(/,/g, '')) || 0);
    const inst = modal.create({
      zIndex: MEMBER_DETAIL_CHILD_Z_INDEX,
      title: t('member.detail.basic.editIntegral'),
      preset: 'dialog',
      class: 'w-[400px]',
      showIcon: false,
      content: () =>
        h(NInputNumber, {
          value: integralRef.value,
          placeholder: t('member.detail.basic.integralPlaceholder'),
          style: 'width: 100%',
          min: 0,
          precision: 0,
          onUpdateValue: (val) => {
            integralRef.value = val ?? 0;
          },
        }),
      positiveText: t('common.save'),
      negativeText: t('common.cancel'),
      onPositiveClick: async () => {
        inst.loading = true;
        try {
          // 嵌入弹窗时按订单商户更新积分
          const { code, msg } = await updateMemberIntegral(
            memberId.value,
            integralRef.value,
            ctxTenantId.value ?? null,
          );
          if (code !== 0) {
            message.error(msg || t('member.detail.basic.editIntegralFailed'));
            return false;
          }
          message.success(t('member.detail.basic.editIntegralSuccess'));
          item.value = String(integralRef.value);
        } catch (e) {
          message.error(t('member.detail.basic.editIntegralFailed'));
          return false;
        } finally {
          inst.loading = false;
        }
      },
    });
  }

  function handleEditState(item) {
    const rawOptions = getMemberOptions('userStateList');
    const stateOptions = rawOptions.map((opt, idx) => ({
      label: opt.label ?? opt.name ?? String(idx),
      value: idx,
    }));
    const stateRef = ref(item._userState ?? null);
    const inst = modal.create({
      zIndex: MEMBER_DETAIL_CHILD_Z_INDEX,
      title: t('member.detail.basic.editUserStatus'),
      preset: 'dialog',
      class: 'w-[400px]',
      showIcon: false,
      content: () =>
        h(
          NRadioGroup,
          {
            value: stateRef.value,
            onUpdateValue: (val) => {
              stateRef.value = val;
            },
          },
          () =>
            stateOptions.map((opt) =>
              h(
                NRadio,
                { value: opt.value, key: opt.value, style: 'margin-right: 16px;' },
                () => opt.label,
              ),
            ),
        ),
      positiveText: t('common.save'),
      negativeText: t('common.cancel'),
      onPositiveClick: async () => {
        if (stateRef.value == null) {
          message.warning(t('member.detail.basic.selectStatus'));
          return false;
        }
        inst.loading = true;
        try {
          // 嵌入弹窗时按订单商户更新会员状态
          const { code, msg } = await updateMemberState(
            memberId.value,
            stateRef.value,
            ctxTenantId.value ?? null,
          );
          if (code !== 0) {
            message.error(msg || t('member.detail.basic.editStatusFailed'));
            return false;
          }
          message.success(t('member.detail.basic.editStatusSuccess'));
          const selected = stateOptions.find((o) => o.value === stateRef.value);
          item.value = selected?.label || item.value;
          item._userState = stateRef.value;
          item.highlight = stateRef.value === 1 ? 'success' : 'error';
        } catch (e) {
          message.error(t('member.detail.basic.editStatusFailed'));
          return false;
        } finally {
          inst.loading = false;
        }
      },
    });
  }

  /** 点击代理关系链 → 弹出「代理线全链路」逐级详情表格 */
  function handleViewAgentLine(section: any) {
    const rows = section?.agentLine || [];
    if (!rows.length) return;
    const al = 'member.detail.basic.agentLine';
    // 层级数据如「1级·总代」：中文环境原样；英文映射为「Level 1 · Super Agent」（不改 mock）
    const levelLabel = (raw: any) => {
      const m = String(raw ?? '').match(/^(\d+)级(?:·(.+))?$/);
      if (!m) return String(raw ?? '');
      const base = t(`${al}.levelN`, { n: m[1] });
      const suf =
        m[2] === '总代'
          ? t(`${al}.roleSuper`)
          : m[2] === '直属上级'
            ? t(`${al}.roleUpline`)
            : m[2] === '本会员'
              ? t(`${al}.roleSelf`)
              : '';
      return `${base}${suf}`;
    };
    // 是/否 → Yes/No（中文环境原样）
    const yn = (v: any) =>
      v === '是' ? t('member.user.yes') : v === '否' ? t('member.user.no') : String(v ?? '');
    const columns = [
      {
        title: t(`${al}.level`),
        key: 'level',
        width: 120,
        render: (row: any) => levelLabel(row.level),
      },
      { title: t(`${al}.agentId`), key: 'agentId', width: 100 },
      {
        title: t(`${al}.nickname`),
        key: 'nickname',
        width: 100,
        // nickname 形如 'Raj（总代）'：翻译括号内「总代」标注，人名原样
        render: (row: any) => attrLabel(t, row.nickname),
      },
      { title: t(`${al}.subCount`), key: 'subCount', width: 80 },
      {
        title: t(`${al}.commissionMode`),
        key: 'commissionMode',
        width: 140,
        render: (row: any) => commissionModeLabel(t, row.commissionMode),
      },
      { title: t(`${al}.rebateLevel`), key: 'rebateLevel', width: 120 },
      {
        title: t(`${al}.toParent`),
        key: 'toParent',
        width: 120,
        render: (row: any) => yn(row.toParent),
      },
      {
        title: t(`${al}.toChild`),
        key: 'toChild',
        width: 120,
        render: (row: any) => yn(row.toChild),
      },
    ];
    modal.create({
      zIndex: MEMBER_DETAIL_CHILD_Z_INDEX,
      title: t(`${al}.title`),
      preset: 'card',
      showIcon: false,
      style: { width: 'min(900px, 94vw)' },
      content: () =>
        h('div', [
          h(NDataTable, { columns, data: rows, size: 'small', bordered: true } as any),
          h('div', { style: 'padding:10px 2px;color:#94a3b8;font-size:12px' }, t(`${al}.note`)),
        ]),
    });
  }

  /** 点击邀请人 → 弹出邀请人详情（label/value 列表） */
  function handleViewInviter(item: any) {
    const rows = item?.detailRows || [];
    if (!rows.length) return;
    modal.create({
      zIndex: MEMBER_DETAIL_CHILD_Z_INDEX,
      title: item.detailTitle || t('member.detail.basic.inviterDetailTitle'),
      preset: 'card',
      showIcon: false,
      style: { width: 'min(520px, 92vw)' },
      content: () =>
        h(
          'div',
          rows.map((r: any) =>
            h('div', { style: 'display:flex;padding:7px 0;border-bottom:1px solid #f1f5f9' }, [
              h('span', { style: 'width:110px;color:#64748b;flex-shrink:0' }, r.label),
              h('span', { style: 'flex:1;color:#1e293b;font-weight:500' }, String(r.value ?? '--')),
            ]),
          ),
        ),
    });
  }

  // 同IP/同设备人数点击下钻：
  // - 默认跳会员列表（列表支持 loginIp/loginDevice 等 key 预填筛选）——最后3次登录等沿用；
  // - 带 jumpPath 时跳该路径（会员风控 6 项 → /risk-control/sameIp，query 带 tab 预选维度 + keyword 预填）。
  const router = useRouter();
  function handleJumpMemberList(item: any) {
    const query = item?.jumpQuery;
    if (!query || !Object.keys(query).length) return;
    // 仅会员风控项（带 jumpPath·目前只样板会员 1100002 有）下钻前关会员详情弹窗，避免二级弹窗挡住风控页；
    // 其他会员的同IP/最后3次登录跳会员列表沿用原行为、不关弹窗
    if (item?.jumpPath) closeMemberDetail();
    router.push({ path: item?.jumpPath || '/member/user', query });
  }

  return {
    handleItemAction,
    handleToggleState,
    handleToggleSwitch,
    handleViewAgentLine,
    handleViewInviter,
    handleJumpMemberList,
  };
}
