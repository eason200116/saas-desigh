<script setup lang="ts">
  /**
   * 路径图卡片（桑基图）
   */
  import { computed } from 'vue';
  import { useI18n } from 'vue-i18n';
  import Chart1 from '@/components/Chart/chart1.vue';
  import BaseChartCard from './BaseChartCard.vue';
  import { generatePathConfig } from '../chartConfigs';
  import type { CardConfig } from '../types';

  interface PathDataPoint {
    source: string;
    target: string;
    value: number;
  }

  interface Props {
    title: string;
    data: PathDataPoint[];
    config: CardConfig;
    height?: string | number;
    loading?: boolean;
    showToggle?: boolean;
  }

  const props = withDefaults(defineProps<Props>(), {
    height: 220,
    loading: false,
    showToggle: true,
  });

  const { t } = useI18n();

  // 是否有数据
  const hasData = computed(() => props.data && props.data.length > 0);

  // 生成图表配置
  const chartConfig = computed(() => {
    if (!hasData.value) return null;
    return generatePathConfig(props.data, props.config, t);
  });

  // 表格列配置
  const tableColumns = computed(() => [
    { title: t('analytics.common.source'), key: 'source' },
    { title: t('analytics.common.target'), key: 'target' },
    { title: t('analytics.common.value'), key: 'value' },
  ]);
</script>

<template>
  <BaseChartCard
    :title="title"
    :height="height"
    :loading="loading"
    :show-toggle="showToggle"
    :has-data="hasData"
  >
    <template #chart="{ height: h }">
      <Chart1 v-if="chartConfig" :config="chartConfig" :height="h" />
    </template>
    <template #table="{ maxHeight }">
      <n-data-table
        :columns="tableColumns"
        :data="data"
        :bordered="false"
        size="small"
        :max-height="maxHeight"
      />
    </template>
  </BaseChartCard>
</template>

<script lang="ts">
  export default {
    name: 'PathChartCard',
  };
</script>
