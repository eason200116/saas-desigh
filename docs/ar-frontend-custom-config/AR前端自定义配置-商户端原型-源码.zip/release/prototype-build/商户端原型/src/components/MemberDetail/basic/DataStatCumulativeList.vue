<template>
  <!--
    数据统计·今日/累计数据（样板会员 1100002 专用）：6 指标合并为 6 格、占满一行——
    每格 = 一个指标，格内「指标名 / 今日X / 累计X」三行上下叠。
    2026-07-16 由 12 格平铺（今日一行 + 累计一行）改回合并格（用户要求：今日与累计合并成一行、保留上下结构）。
    上下结构走共享 .detail-cell--stack 修饰（不再靠 DataStatTab 的全局 !important 覆盖，
    因该覆盖已随「充提/奖励改横排」一并移除）。金额·流水汇总值随 .detail-cell 默认居左（R61）。
  -->
  <div class="detail-section">
    <div class="detail-section__header">
      <h4 class="detail-section__title">{{ title }}</h4>
    </div>
    <div class="detail-grid" :style="{ gridTemplateColumns: 'repeat(6, minmax(0, 1fr))' }">
      <div v-for="row in cumulative.rows" :key="row.item" class="detail-cell detail-cell--stack">
        <span class="detail-cell__label">{{ row.item }}</span>
        <span class="detail-cell__value dsc__line">
          <span class="dsc__tag">{{ cumulative.todayName }}</span>{{ row.today }}
        </span>
        <span class="detail-cell__value dsc__line">
          <span class="dsc__tag">{{ cumulative.totalName }}</span>{{ row.total }}
        </span>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
  import { type PropType } from 'vue';

  defineProps({
    cumulative: { type: Object as PropType<any>, required: true },
    title: { type: String, default: '' },
  });
</script>

<style lang="less" scoped>
  /* 合并格：一格一个指标，格内 指标名 / 今日X / 累计X 三行。
     共享 .detail-cell__value 带 flex:1 + align-items:center + gap:0（父组件 ::v-deep 注入），
     列向排布下 flex:1 会把两行拉伸。这里双类选择器提高特异性压过它（同为 (0,2,0) 时只靠源码顺序决胜、不可靠）。 */
  .detail-cell__value.dsc__line {
    flex: 0 0 auto;
    align-items: baseline;
    gap: 4px;
  }
  /* 「今日 / 累计」前缀：弱化成与 .detail-cell__label 同款次要色，数值仍走 __value 的 13px/500 */
  .dsc__tag {
    flex-shrink: 0;
    font-size: 12px;
    font-weight: 400;
    color: #8c8c8c;
  }
</style>
