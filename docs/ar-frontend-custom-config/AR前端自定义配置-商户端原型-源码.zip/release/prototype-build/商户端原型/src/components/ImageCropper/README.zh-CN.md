# ImageCropper Hook 中文说明

## 目的

`useImageCropper.ts` 用于沉淀 `ImageCropper` 组件与业务页面（如 `src/views/operations/imageCrop`）的通用逻辑，避免重复实现导致的参数不一致。

## 导出内容

- 类型： `DragMode`、`ExportFormat`、`CropOutputMode`、`SupportedExportMimeType`、`CropRequestOptions`
- 常量： `SUPPORTED_IMAGE_MIME_TYPES`、`SUPPORTED_IMAGE_EXTENSIONS`、`MIN_OUTPUT_DIMENSION`、`MAX_OUTPUT_DIMENSION`
- 工具方法： `normalizeMimeType`、`resolveExportMimeType`、`isQualityAdjustableMimeType`、`normalizeDimension`、`normalizeExportQuality`、`normalizeRotateFineStep`、`normalizeDragMode`
- 参数生成： `getCropOutputSize`、`createCropRequestOptions`

## 推荐用法

1. 页面层只维护业务表单值（宽高、格式、质量、模式）。
2. 通过 `createCropRequestOptions` 生成传给 `cropper.crop` 的参数。
3. 通过 `getCropOutputSize` 统一预览与下载模式下的尺寸计算。

## 参考接入

- 组件内部复用： `src/components/ImageCropper/index.vue`
- 页面复用： `src/views/operations/imageCrop/index.vue`
