// 游戏映射管理（总控端 admin · game_mapping）功能说明书。
// 锚定 src/views/game/mapping/index.vue + components/{SiteSelectPanel,MappingArea,GameMappingCard}.vue
// + mappingConfigData.ts 真实控件（R53 实证、不臆造）。
//
// 【非标准列表】本页是双栏映射配置页，不是 ProCrudTable 列表：
//   左栏 SiteSelectPanel 多选「商户站点」，右栏 MappingArea 选一个「三方厂商」后
//   按自营厂商分组展示自营游戏卡片（GameMappingCard），勾选要建立映射的游戏、点保存写回。
//   故本文件不提供 fields（无 tableColumns 可对应）。
// 注意：本页数据源是 ./mappingConfigData.ts，与同目录 ./data.ts（另一窗口维护的旧版 CRUD 列表 mock）
//   完全独立、互不复用——若未来 data.ts 被清理不影响本说明书。
//
// 联动锚点说明：本页控件均为页面自有模板元素（非 createActionColumn 渲染），data-manual 直接挂在
//   真实 DOM/组件根节点上即可被 PageManual 的全局 document 点击监听捕获，故未使用 focusManual()
//   事件派发（那是 channel/platform 页为绕过 createActionColumn 不透传 attr 才用的兜底手法，本页不需要）。

import type { PageManual } from '../types';

const manual: PageManual = {
  route: 'game_mapping',
  title: '游戏映射管理',
  overview:
    '总控端游戏映射配置页——双栏形态（非标准列表）：左栏多选「商户站点」，右栏选一个「三方厂商」后按自营厂商分组展示自营游戏卡片，勾选要建立映射的游戏、点「保存」写回。语义：商户站点 × 三方厂商 → 自营游戏 的映射关系配置。仅总控端可见（meta.roles: admin）。',
  items: [
    // ============ 左栏：商户站点（圈定范围）============
    {
      anchor: 'siteIds',
      name: '选择站点',
      group: '搜索',
      interaction:
        '下拉单选、可搜索(filterable)、可清空；每选一次就加入下方「已选站点」列表，重复操作实现多选。下拉第一位固定「所有商户」功能性选项（2026-07-24 Eason 确认新增）：选中它＝把当前所有尚未选中的商户一次性批量加入「已选站点」列表，不会把「所有商户」本身当作一条商户加入已选列表。',
      dataSource:
        '站点选项，来自 api.game.mappingConfigGetSites()（页面加载时拉取，当前 mock 8 个站点，如 Dev-1001/BrasilBet-1003…）；候选已自动排除已选中的站点。「所有商户」为本地固定选项（哨兵值 __all_sites__，非接口返回），不参与「已选则从下拉消失」的排除逻辑，始终固定在下拉第一位，方便后续移出某些商户后可再次点选批量加回。',
      logic:
        '已选站点集合与右栏「三方厂商」共同决定右栏加载哪组映射数据——两者任一变化都会触发重新加载（watch [selectedSiteIds, selectedVendor]）。',
      limit: '可多选；右栏加载要求至少选 1 个站点。',
      edge: '未选任何站点、或未选三方厂商时，右栏显示「请先选择商户站点和三方厂商」空态、不发请求。',
    },
    {
      anchor: 'sourceVendor',
      name: '三方厂商选择',
      group: '搜索',
      interaction:
        '下拉单选、可搜索、可清空；选项格式「徽标 · 厂商名」，选中后左侧显示该厂商 2 字母徽标。',
      dataSource:
        '三方厂商选项，来自 api.game.mappingConfigGetVendors()（页面加载时拉取，当前 mock 14 个厂商，如 JILI电子/AG电子/PP电子…）。',
      logic:
        '与左栏站点选择共同决定右栏数据加载；切换厂商会重新拉取「当前站点组合 × 该厂商」下的自营游戏映射态。',
      limit: '单选，必选（不选则 hasSelection=false、右栏不加载）。',
      edge: '清空后右栏立即回到空态，已加载分组一并清空。',
    },
    {
      anchor: 'searchKw',
      name: '搜索游戏',
      group: '搜索',
      interaction: '文本输入、可清空、带搜索图标前缀。',
      dataSource: '用户输入，纯前端过滤，不重新请求接口。',
      logic:
        '按游戏 ID（数字转字符串包含）、目标游戏名称（不区分大小写子串）、目标游戏编码（不区分大小写子串）过滤已加载的分组卡片；某分组过滤后卡片数为 0 则整组隐藏。',
      limit: '选填；最多 50 字（inputProps searchKw 预设）。',
      edge: '过滤后全部分组都空 → 显示「暂无匹配结果」。',
    },
    {
      anchor: 'filterMode',
      name: '全部 / 仅手动',
      group: '搜索',
      interaction: '两态单选按钮组（radio-button）：「全部」/「仅手动」。',
      dataSource: '本地态，默认「全部」。',
      logic:
        '「仅手动」只显示 card.manual === true 的卡片（该站点组合下人工配置过的映射，来自 mock 内存态 manualTargetIds）；可与「搜索游戏」叠加使用。',
      limit: '二选一。',
      edge: '「仅手动」下若某分组没有手动项，该分组不显示。',
    },

    // ============ 只读展示 ============
    {
      anchor: 'col_groupStat',
      name: '分组统计',
      group: '列',
      interaction: '只读文字，数字本身不可点（但落在分组表头范围内点击仍会触发该分组收起/展开）。',
      dataSource:
        '「共 N」= 该自营厂商在当前三方厂商目录下的游戏总数；「手动 N」（仅 manualCount>0 时显示，橙色）= 其中人工配置过的数量；「已选 N/M」= 当前本地勾选态里属于该分组的数量 / 总数（selectionStats 实时计算）。',
      logic: '三个数字随勾选/筛选/站点厂商切换实时更新，均为派生展示，不接受直接编辑。',
      note: '「手动」不是审批/风控状态，纯粹表示这条映射历史上是否被人工设置过。',
    },
    {
      anchor: 'col_manualTag',
      name: '卡片「手动」标记',
      group: '列',
      interaction: '只读 Tag（橙色，卡片右上角），仅 card.manual === true 时显示，不可点。',
      dataSource:
        '该卡片对应目标游戏 ID 是否在当前「站点组合 + 三方厂商」组合的 manualTargetIds 内。',
      logic:
        '仅展示，无直接切换入口——手动标记会在下次保存时按「该游戏是否还在选中集合中」自动重新计算（取消勾选则手动标记一并失效）。',
    },

    // ============ 操作 ============
    {
      anchor: 'act_siteClear',
      name: '清空已选站点',
      group: '操作',
      interaction: '点击「清空」按钮，一次性清空左栏全部已选站点。',
      logic: '清空后右栏回到「请先选择商户站点和三方厂商」空态。',
      limit: '无已选站点时按钮禁用。',
    },
    {
      anchor: 'act_siteRemove',
      name: '已选站点 · 删除',
      group: '操作',
      interaction: '每条已选站点行右侧「删除」按钮，点击移除该单条站点。',
      logic: '移除后若仍有其它已选站点，右栏按剩余站点重新加载；全部移除则回到空态。',
    },
    {
      anchor: 'act_groupSelectAll',
      name: '分组 · 全选',
      group: '操作',
      interaction: '每个自营厂商分组表头右侧「全选」按钮，点击把该组全部卡片加入本地勾选集合。',
      logic:
        '仅改本地勾选态（checkedSet），不立即持久化——需再点「保存」才写回；点击已 .stop，不会连带触发该分组收起/展开。',
    },
    {
      anchor: 'act_groupCollapse',
      name: '分组 · 收起 / 展开',
      group: '操作',
      interaction:
        '点击分组表头（「全选」按钮范围外）切换该分组卡片区域的收起/展开，图标随之旋转。',
      logic:
        '纯前端 UI 态（collapsedGroups，组件级 reactive）；分组 key 是固定的自营厂商名（如 KB电子/UP电子），切换站点/三方厂商不会重置收起状态——已折叠的分组保持折叠（本页还带 keepAlive），需再点表头展开。不影响已勾选数据、不持久化。',
    },
    {
      anchor: 'act_toggleCard',
      name: '映射游戏卡片 · 勾选切换',
      group: '操作',
      interaction:
        '点击卡片任意处（或卡片内勾选框）切换该自营游戏是否勾选；卡片展示「三方徽标+源ID → 自营徽标+目标ID」、（部分厂商如 UP电子）目标游戏编码、目标游戏名称；勾选态描边高亮为主色。',
      dataSource:
        '源 ID（sourceId）由「三方厂商 + 目标游戏 ID」派生的稳定展示用编号（deriveSourceId，非真实业务 ID）；目标游戏来自自营游戏池（当前 KB电子、UP电子两组，各 20 款）。',
      logic: '切换仅改本地勾选集合，不立即持久化；需点「保存」才调用 mappingConfigSave 写回。',
      note: '橙色描边 = 该卡片同时是「手动」态（见 col_manualTag），二者可同时出现在同一张卡片上。',
    },
    {
      anchor: 'act_save',
      name: '保存',
      group: '操作',
      interaction: '点击「保存」提交当前本地勾选集合。',
      logic:
        '调用 api.game.mappingConfigSave({ siteIds, sourceVendor, selectedTargetIds })：把当前勾选写回「已选站点 × 当前三方厂商」组合的内存态（多选站点时，对每个站点各写一份相同的 selectedTargetIds）；成功提示「保存成功」并重新加载，失败提示「保存失败」。已取消勾选的游戏会一并清掉其「手动」标记。',
      limit: '未同时选中站点与厂商时按钮禁用（hasSelection=false）。',
      edge: '纯前端 mock、无真实持久化，刷新页面后内存态重置为 mock 初始值。',
    },
  ],
  // 非标准列表页，无 tableColumns 可对应，故不提供 fields（面板「字段介绍」tab 会显示"暂无字段说明"）。
};

export default manual;
