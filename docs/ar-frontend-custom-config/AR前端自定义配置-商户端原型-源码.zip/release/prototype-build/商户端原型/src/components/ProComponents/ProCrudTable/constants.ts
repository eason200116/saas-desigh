export const AUTO_LABEL_WIDTH = 'auto' as const;
