<template>
  <div class="background-input">
    <!-- Type Switch -->
    <n-radio-group v-model:value="bgType" size="small" class="mb-2">
      <n-radio-button value="color">{{ t('common.backgroundColor') }}</n-radio-button>
      <n-radio-button value="image">{{ t('common.backgroundImage') }}</n-radio-button>
    </n-radio-group>

    <!-- Color Input -->
    <div v-if="bgType === 'color'" class="color-input-wrapper">
      <div class="flex items-center gap-2 w-full">
        <!-- n-color-picker 渲染为 fragment，class 无法自动透传到根节点，外层 wrapper 承接样式 -->
        <div class="color-picker-no-text">
          <n-color-picker
            v-model:value="pickerColor"
            :show-alpha="true"
            :modes="['hex']"
            :swatches="swatches"
            size="small"
            @update:value="handlePickerChange"
            @complete="handleColorComplete"
          />
        </div>
        <n-input
          v-model:value="colorValue"
          :placeholder="placeholder || colorPlaceholder"
          :status="colorStatus"
          @blur="validateColor"
        />
      </div>
      <div v-if="colorStatus === 'error'" class="color-error-message">
        {{ t('common.invalidColorFormat') }}
      </div>
    </div>

    <!-- Image Upload -->
    <BasicUpload
      v-else
      :value="imageValue ? [imageValue] : []"
      :max-number="1"
      :width="width"
      :height="height"
      :custom-path="4"
      full-path
      compact
      @update:value="handleImageChange"
    />
  </div>
</template>

<script setup lang="ts">
  import { ref, watch } from 'vue';
  import { useI18n } from 'vue-i18n';
  import { BasicUpload } from '@/components';

  const props = withDefaults(
    defineProps<{
      modelValue?: string;
      placeholder?: string;
      width?: number;
      height?: number;
    }>(),
    {
      modelValue: '',
      placeholder: '',
      width: 100,
      height: 40,
    },
  );

  const emit = defineEmits<{
    (e: 'update:modelValue', value: string): void;
  }>();

  const { t } = useI18n();

  // Default placeholder for color input
  const colorPlaceholder = t('common.backgroundColorPlaceholder');

  // Preset colors
  const swatches = [
    '#1a2744',
    '#0f1419',
    '#1890ff',
    '#52c41a',
    '#faad14',
    '#f5222d',
    '#722ed1',
    '#13c2c2',
    '#eb2f96',
    '#2f54eb',
  ];

  // Color validation regex (hex with optional alpha)
  const colorRegex = /^#([0-9A-Fa-f]{3}|[0-9A-Fa-f]{4}|[0-9A-Fa-f]{6}|[0-9A-Fa-f]{8})$/;

  // Check if value is an image URL
  function isImageValue(value: string): boolean {
    if (!value) return false;
    // Check common image extensions or URL patterns
    return /\.(png|jpg|jpeg|gif|webp|svg)$/i.test(value) || value.startsWith('http');
  }

  // State
  const bgType = ref<'color' | 'image'>('color');
  const colorValue = ref('');
  const imageValue = ref('');
  const pickerColor = ref('');
  const colorStatus = ref<'error' | undefined>(undefined);
  const isUserSwitching = ref(false); // Flag to prevent watch loop

  // Initialize from modelValue (only updates values, not bgType unless value indicates type)
  function initFromValue(value: string, forceUpdateType = false) {
    if (!value) {
      // Don't change bgType if user is switching
      if (forceUpdateType) {
        bgType.value = 'color';
      }
      colorValue.value = '';
      imageValue.value = '';
      pickerColor.value = '';
      return;
    }

    if (isImageValue(value)) {
      bgType.value = 'image';
      imageValue.value = value;
      colorValue.value = '';
      pickerColor.value = '';
    } else {
      bgType.value = 'color';
      colorValue.value = value;
      imageValue.value = '';
      // Sync to picker if valid color
      if (colorRegex.test(value)) {
        pickerColor.value = value;
      }
    }
  }

  // Watch modelValue changes
  watch(
    () => props.modelValue,
    (newVal) => {
      // Skip if user is manually switching type
      if (isUserSwitching.value) {
        isUserSwitching.value = false;
        return;
      }
      initFromValue(newVal || '', true);
    },
    { immediate: true },
  );

  // Watch bgType changes - clear the other type's value and emit
  watch(bgType, (newType) => {
    isUserSwitching.value = true;
    if (newType === 'color') {
      // Clear image value when switching to color
      imageValue.value = '';
      emit('update:modelValue', colorValue.value);
    } else {
      // Clear color value when switching to image
      colorValue.value = '';
      pickerColor.value = '';
      colorStatus.value = undefined;
      emit('update:modelValue', imageValue.value);
    }
  });

  // Validate color format on blur
  function validateColor() {
    if (!colorValue.value) {
      colorStatus.value = undefined;
      pickerColor.value = '';
      return;
    }

    const isValid = colorRegex.test(colorValue.value);
    colorStatus.value = isValid ? undefined : 'error';

    if (isValid) {
      // Sync to picker when valid
      pickerColor.value = colorValue.value;
    }
  }

  // Handle color picker value change (including swatches click)
  function handlePickerChange(color: string) {
    colorValue.value = color;
    colorStatus.value = undefined;
    emit('update:modelValue', color);
  }

  // Handle color picker complete
  function handleColorComplete(color: string) {
    colorValue.value = color;
    pickerColor.value = color;
    colorStatus.value = undefined;
    emit('update:modelValue', color);
  }

  // Watch color input changes - sync to picker if valid
  watch(colorValue, (newVal) => {
    if (bgType.value === 'color') {
      emit('update:modelValue', newVal);
      // Only sync to picker if valid format (for real-time preview)
      if (newVal && colorRegex.test(newVal)) {
        pickerColor.value = newVal;
      }
    }
  });

  // Handle image upload change
  function handleImageChange(values: string[]) {
    imageValue.value = values[0] || '';
    if (bgType.value === 'image') {
      emit('update:modelValue', imageValue.value);
    }
  }
</script>

<style scoped>
  .background-input {
    width: 100%;
  }

  .color-input-wrapper {
    width: 100%;
  }

  .color-picker-no-text {
    width: 34px;
    flex-shrink: 0;
  }

  .color-picker-no-text ::v-deep(.n-color-picker-trigger__value) {
    display: none;
  }

  .color-error-message {
    font-size: 12px;
    color: #d03050;
    margin-top: 4px;
    line-height: 1.25;
  }
</style>
