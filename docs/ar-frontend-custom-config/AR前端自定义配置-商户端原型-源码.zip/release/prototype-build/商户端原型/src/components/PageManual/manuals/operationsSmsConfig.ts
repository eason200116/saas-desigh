// 短信商配置（商户端 tenant · operations_smsConfig）功能说明书。
// 锚定 src/views/operations/smsConfig/index.vue(纯壳，渲染 components/SmsProviderTab.vue) + data.ts 真实控件（R53 实证、不臆造）。
// 结构与「邮件商配置」页高度一致（同批次姊妹页，设计上刻意对齐）。

import type { PageManual } from '../types';

const manual: PageManual = {
  route: 'operations_smsConfig',
  title: '短信商配置',
  overview:
    '商户端「运营管理 › 短信商配置」页，维护平台对外发送验证码短信用的服务商账号配置，每条配置归属单一商户。' +
    '短信类型目前固定为"验证码"（表单不展示该字段，仅列表"短信类型"列固定显示"验证码"）。列表仅展示商户/' +
    '自定义名称/供应商/短信类型/模板内容，其余字段(API地址/账号/密钥等)收在编辑弹窗内。API KEY与API密钥编辑' +
    '回显时脱敏(前4后4中间***)，重新输入即覆盖明文。' +
    '2026-07-22核实代码发现：保存(saveSmsProvider)只返回成功、不真正写回底层数组，操作提示成功但列表刷新' +
    '看不到变化；另外 data.ts 里定义的 updateSmsProviderState(单独状态切换)、deleteSmsProvider(删除) 两个' +
    'mock方法在页面里完全没有被调用——本页没有独立的启用/禁用开关或删除按钮，状态只能通过编辑弹窗内的开关' +
    '连同其它字段一起保存，与「邮件商配置」同一处历史模板问题。如实记录，未修复。',
  items: [
    {
      anchor: 'merchant',
      name: '商户',
      group: '搜索',
      interaction: '下拉筛选。',
    },
    {
      anchor: 'name',
      name: '自定义名称',
      group: '搜索',
      interaction: '文本框，可清空，模糊匹配。',
    },
    {
      anchor: 'provider',
      name: '短信供应商',
      group: '搜索',
      interaction: '下拉单选，可清空。',
    },
    {
      anchor: 'reset',
      name: '重置',
      group: '搜索',
      interaction: 'ProCrudTable内置重置按钮。',
    },
    {
      anchor: 'act_add',
      name: '新增',
      group: '操作',
      interaction: '主色按钮，点击打开新增弹窗（920px宽）。',
      logic:
        '字段顺序固定：商户(必选，新增可选/编辑置灰) → 短信供应商(必选下拉，新增可选/编辑禁用，选择后' +
        '联动短信商名称默认取供应商名) → 短信商名称(必填，可改) → API地址(必填) → API商户号(选填) → ' +
        'API KEY(选填，编辑回显脱敏) → API密钥(选填，编辑回显脱敏) → 模板内容(必填，多行文本) → 状态(开关)。',
    },
    {
      anchor: 'col_template',
      name: '模板内容（列，悬停看全文）',
      group: '列',
      interaction: '截断40字展示，hover弹出完整内容气泡；为空显示"-"。',
    },
    {
      anchor: 'act_edit',
      name: '编辑',
      group: '操作',
      interaction: '每行常驻，点击打开编辑弹窗（字段同新增，回显当前值，账号/密钥脱敏显示）。',
    },
  ],
  fields: [
    { name: '商户（列）', def: '该短信配置所属商户，标签展示。' },
    { name: '自定义名称', def: '商户对该短信商的自定义命名（可与供应商品牌名不同），为空展示"-"。' },
    { name: '短信供应商', def: '所选短信服务商品牌名，为空展示"-"。' },
    { name: '短信类型', def: '目前固定显示"验证码"。' },
    { name: '模板内容', def: '短信文案模板，见交互条目 col_template。' },
  ],
};

export default manual;
