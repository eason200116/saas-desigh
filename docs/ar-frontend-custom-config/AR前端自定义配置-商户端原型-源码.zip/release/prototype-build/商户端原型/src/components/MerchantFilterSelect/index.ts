import { h } from 'vue';
import type { SelectOption } from 'naive-ui';
import type { ProSearchFormColumn } from '@/components/ProComponents/types/searchForm';
import MerchantFilterSelect from './MerchantFilterSelect.vue';

export { MerchantFilterSelect };
export { MERCHANT_ALL_VALUE, MERCHANT_ALL_LABEL, matchMerchantFilter } from './constants';

/** disabled / options 既可传静态值，也可传基于 formModel 的函数（响应式联动场景）。 */
type FormModel = Record<string, any>;
type MaybeFn<T> = T | ((formModel: FormModel) => T);

function resolve<T>(v: MaybeFn<T> | undefined, formModel: FormModel): T | undefined {
  return typeof v === 'function' ? (v as (m: FormModel) => T)(formModel) : v;
}

/**
 * 生成「商户」搜索列（多选 + 「全部」互斥）。
 * 用法：把原来 `valueType: 'tenantSelect'` 的商户筛选列替换为 `merchantSearchColumn({ label })`。
 *
 * 进阶能力（带级联/禁用/自定义选项的筛选页用）：
 * - `disabled`：静态布尔或 `(formModel) => boolean`，透传给下拉禁用态。
 * - `options`：静态数组或 `(formModel) => SelectOption[]`，覆盖默认全量商户（如按集团过滤后的子集）。
 * - `onChange`：值变更回调（在 setValue 之后触发），用于清空下游联动字段、重载字典等。
 * - `formItemProps`：透传给列（与同表单其它列对齐 label 宽度/样式、showRequireMark 等）。
 */
export function merchantSearchColumn(opts?: {
  path?: string;
  label?: string;
  pin?: boolean;
  order?: number;
  placeholder?: string;
  // 多选(默认) / 单选。单选用于「仅单选+必填」筛选（如会员列表）。
  multiple?: boolean;
  // 是否可搜索过滤，默认 true；个别页可传 false 关闭下拉搜索
  filterable?: boolean;
  disabled?: MaybeFn<boolean>;
  options?: MaybeFn<SelectOption[]>;
  formItemProps?: Record<string, any>;
  onChange?: (
    value: number | number[],
    ctx: { formModel: FormModel; setValue: (v: number | number[]) => void; field: string },
  ) => void;
}): ProSearchFormColumn {
  const path = opts?.path ?? 'tenantId';
  return {
    path,
    label: opts?.label ?? '商户',
    ...(opts?.pin === undefined ? {} : { pin: opts.pin }),
    ...(opts?.order === undefined ? {} : { order: opts.order }),
    ...(opts?.formItemProps === undefined ? {} : { formItemProps: opts.formItemProps }),
    render: ({ formModel, setValue, field }) =>
      h(MerchantFilterSelect, {
        value: formModel[field] as number | number[] | null | undefined,
        ...(opts?.multiple === undefined ? {} : { multiple: opts.multiple }),
        ...(opts?.filterable === undefined ? {} : { filterable: opts.filterable }),
        disabled: resolve(opts?.disabled, formModel),
        options: resolve(opts?.options, formModel),
        ...(opts?.placeholder === undefined ? {} : { placeholder: opts.placeholder }),
        'onUpdate:value': (value: number | number[]) => {
          setValue(value);
          opts?.onChange?.(value, { formModel, setValue, field });
        },
      }),
  };
}
