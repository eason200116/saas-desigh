<template>
  <n-popover
    v-model:show="visible"
    trigger="hover"
    placement="bottom-start"
    :show-arrow="false"
    :width="680"
    :delay="100"
    :duration="150"
    class="product-nav-popover"
    content-class="product-nav-popover__content"
    @update:show="handleVisibleChange"
  >
    <template #trigger>
      <div class="product-nav-trigger">
        <n-icon size="18">
          <GridOutline />
        </n-icon>
        <span class="product-nav-trigger__text">{{ t('productNav.title') }}</span>
        <n-icon size="14" class="product-nav-trigger__arrow">
          <ChevronDownOutline />
        </n-icon>
      </div>
    </template>
    <div class="product-nav-panel">
      <!-- 头部：标题和搜索框 -->
      <div class="product-nav-panel__header">
        <span class="product-nav-panel__title">{{ t('productNav.title') }}</span>
        <div class="product-nav-panel__search">
          <n-input
            v-model:value="searchKeyword"
            :placeholder="t('productNav.searchPlaceholder')"
            clearable
            size="small"
          >
            <template #prefix>
              <n-icon :size="16">
                <SearchOutline />
              </n-icon>
            </template>
          </n-input>
        </div>
      </div>
      <!-- 内容区 -->
      <div class="product-nav-panel__body">
        <!-- 产品文档 PRD 入口（线上 PRD 全量，新标签打开）-->
        <div class="product-nav-panel__doc-entry" @click="openPrdDoc">
          <n-icon :size="16" class="product-nav-panel__doc-icon">
            <DocumentTextOutline />
          </n-icon>
          <span class="product-nav-panel__doc-text">{{ t('productNav.prdDoc') }}</span>
          <!-- 迁移期「新」标，收尾统一删除 -->
          <span class="product-nav-panel__doc-new">新</span>
          <n-icon :size="13" class="product-nav-panel__doc-arrow">
            <OpenOutline />
          </n-icon>
        </div>
        <!-- 搜索结果 -->
        <template v-if="searchKeyword && searchResults.length > 0">
          <div class="product-nav-panel__results">
            <div class="product-nav-panel__results-header">
              {{ t('productNav.searchResults') }} ({{ searchResults.length }})
            </div>
            <div class="product-nav-panel__results-list">
              <div
                v-for="result in searchResults"
                :key="`${result.key}-${result.tabKey || ''}`"
                class="product-nav-panel__result-item"
                @click="handleResultClick(result)"
              >
                <span class="product-nav-panel__result-category">{{ result.categoryTitle }}</span>
                <span class="product-nav-panel__result-title">{{ result.title }}</span>
              </div>
            </div>
          </div>
        </template>
        <!-- 无搜索结果 -->
        <template v-else-if="searchKeyword && searchResults.length === 0">
          <div class="product-nav-panel__empty">
            <n-empty :description="t('productNav.noResults')" size="small" />
          </div>
        </template>
        <!-- 所有分类的服务列表 - 紧凑标签式 -->
        <template v-else>
          <div
            v-for="category in categories"
            :key="category.key"
            class="product-nav-panel__section"
          >
            <!-- 分类标题 -->
            <div class="product-nav-panel__section-header">
              <n-icon v-if="category.icon" :size="14" class="product-nav-panel__section-icon">
                <component :is="category.icon" />
              </n-icon>
              <span class="product-nav-panel__section-title">{{ t(category.title) }}</span>
            </div>
            <!-- 服务项标签 -->
            <div class="product-nav-panel__tags">
              <template v-for="item in category.items" :key="item.key">
                <!-- 无子项的服务 -->
                <span
                  v-if="!(item.tabs && item.tabs.length > 0)"
                  class="product-nav-panel__tag"
                  @click="handleNavigate(item.key)"
                >
                  {{ t(item.title) }}
                </span>
                <!-- 有子项的服务 - 主标签 + 子标签 -->
                <template v-else>
                  <span
                    class="product-nav-panel__tag product-nav-panel__tag--parent"
                    @click="handleNavigate(item.key)"
                  >
                    {{ t(item.title) }}
                  </span>
                  <span
                    v-for="tab in item.tabs"
                    :key="tab.key"
                    class="product-nav-panel__tag product-nav-panel__tag--child"
                    @click="handleNavigateTab(item.key, tab.key)"
                  >
                    {{ t(tab.title) }}
                  </span>
                </template>
              </template>
            </div>
          </div>
        </template>
      </div>
    </div>
  </n-popover>
</template>

<script setup lang="ts">
  import { ref } from 'vue';
  import { useI18n } from 'vue-i18n';
  import {
    GridOutline,
    ChevronDownOutline,
    SearchOutline,
    DocumentTextOutline,
    OpenOutline,
  } from '@vicons/ionicons5';
  import { useProductNav } from './useProductNav';
  import type { SearchResultItem } from './types';

  const { t } = useI18n();
  const { categories, searchKeyword, searchResults, navigateTo, navigateToTab } = useProductNav();

  // PRD 全量文档地址：按站点语境取本地/线上（R40 链接环境一致）
  const PRD_DOC_URL =
    (window.location.hostname.endsWith('github.io')
      ? 'https://eason200116.github.io/saas-desigh/docs'
      : 'http://localhost:8090/docs') + '/saas-phase2-prd-full.html';

  const visible = ref(false);

  // Clear search when popover closes
  const handleVisibleChange = (show: boolean) => {
    if (!show) {
      searchKeyword.value = '';
    }
  };

  // Close popover
  const closePopover = () => {
    visible.value = false;
    searchKeyword.value = '';
  };

  // 打开线上 PRD 全量文档（新标签）
  const openPrdDoc = () => {
    window.open(PRD_DOC_URL, '_blank', 'noopener,noreferrer');
    closePopover();
  };

  // Navigate to page
  const handleNavigate = (routeName: string) => {
    navigateTo(routeName);
    closePopover();
  };

  // Navigate to tab
  const handleNavigateTab = (routeName: string, tabKey: string) => {
    navigateToTab(routeName, tabKey);
    closePopover();
  };

  // Handle search result click
  const handleResultClick = (result: SearchResultItem) => {
    if (result.tabKey) {
      navigateToTab(result.key, result.tabKey);
    } else {
      navigateTo(result.key);
    }
    closePopover();
  };
</script>

<style lang="less">
  .product-nav-popover {
    .n-popover__content {
      padding: 0 !important;
    }
  }
</style>

<style lang="less" scoped>
  .product-nav-trigger {
    display: flex;
    align-items: center;
    gap: 6px;
    padding: 0 12px;
    height: 100%;
    cursor: pointer;
    transition: background-color 0.2s;
    color: #fff;

    &:hover {
      background: hsla(0, 0%, 100%, 0.08);
    }

    &__text {
      font-size: 14px;
      white-space: nowrap;
    }

    &__arrow {
      transition: transform 0.2s;
    }
  }

  .product-nav-panel {
    display: flex;
    flex-direction: column;
    max-height: 480px;
    background: #fff;

    &__header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 16px 20px;
      border-bottom: 1px solid #f0f0f0;
      flex-shrink: 0;
    }

    &__title {
      font-size: 16px;
      font-weight: 600;
      color: #333;
    }

    &__search {
      width: 200px;
    }

    &__body {
      flex: 1;
      overflow-y: auto;
      padding: 16px 20px;
    }

    &__doc-entry {
      display: flex;
      align-items: center;
      gap: 8px;
      padding: 10px 14px;
      margin-bottom: 16px;
      border: 1px solid var(--ui-accent-soft);
      border-radius: 6px;
      background-color: var(--ui-accent-soft);
      color: var(--ui-accent-text);
      font-size: 14px;
      font-weight: 600;
      cursor: pointer;
      transition: all 0.2s;

      &:hover {
        background-color: var(--ui-accent-soft-hover);
      }
    }

    &__doc-icon {
      flex-shrink: 0;
    }

    &__doc-text {
      flex: 1;
    }

    &__doc-new {
      display: inline-flex;
      align-items: center;
      font-size: 10px;
      line-height: 15px;
      padding: 0 5px;
      border-radius: 3px;
      color: #c08a4a;
      background: #faf4ec;
      font-weight: 400;
      letter-spacing: 0.5px;
    }

    &__doc-arrow {
      flex-shrink: 0;
      opacity: 0.7;
    }

    &__section {
      margin-bottom: 20px;

      &:last-child {
        margin-bottom: 0;
      }
    }

    &__section-header {
      display: flex;
      align-items: center;
      margin-bottom: 12px;
      padding-left: 2px;
    }

    &__section-icon {
      margin-right: 8px;
      color: var(--ui-accent-text);
    }

    &__section-title {
      font-size: 14px;
      font-weight: 600;
      color: #333;
    }

    &__tags {
      display: flex;
      flex-wrap: wrap;
      gap: 0;
    }

    &__tag {
      display: inline-flex;
      align-items: center;
      padding: 8px 16px;
      font-size: 14px;
      color: #333;
      background-color: transparent;
      border-radius: 4px;
      cursor: pointer;
      transition: all 0.2s;
      white-space: nowrap;

      &:hover {
        color: var(--ui-accent-text);
        background-color: var(--ui-accent-soft);
      }

      // Parent tag with children - same style as normal
      &--parent {
        color: #333;
        background-color: transparent;

        &:hover {
          color: var(--ui-accent-text);
          background-color: var(--ui-accent-soft);
        }
      }

      // Child tag - same style as normal
      &--child {
        color: #333;
        background-color: transparent;

        &:hover {
          color: var(--ui-accent-text);
          background-color: var(--ui-accent-soft);
        }
      }
    }

    &__results {
      &-header {
        font-size: 14px;
        font-weight: 500;
        color: #333;
        margin-bottom: 12px;
        padding-bottom: 8px;
        border-bottom: 1px solid #f0f0f0;
      }

      &-list {
        display: flex;
        flex-direction: column;
        gap: 4px;
      }
    }

    &__result-item {
      display: flex;
      align-items: center;
      padding: 8px 12px;
      border-radius: 4px;
      cursor: pointer;
      transition: background-color 0.2s;

      &:hover {
        background-color: var(--ui-accent-soft);
      }
    }

    &__result-category {
      font-size: 12px;
      color: #999;
      background-color: #f5f5f5;
      padding: 2px 8px;
      border-radius: 4px;
      margin-right: 12px;
      flex-shrink: 0;
    }

    &__result-title {
      font-size: 14px;
      color: #333;
    }

    &__empty {
      display: flex;
      align-items: center;
      justify-content: center;
      height: 200px;
    }
  }
</style>

<!-- Dark theme styles -->
<style lang="less">
  .dark .product-nav-panel {
    background: #242b3d !important;

    .product-nav-panel__header {
      border-bottom-color: #3a4459;
    }

    .product-nav-panel__title {
      color: #e5e7eb;
    }

    .product-nav-panel__section-title {
      color: #e5e7eb;
    }

    .product-nav-panel__doc-entry {
      border-color: var(--ui-accent-soft-hover);

      &:hover {
        background-color: var(--ui-accent-soft-hover);
      }
    }

    .product-nav-panel__tag {
      color: #9ca3af;

      &:hover {
        color: var(--ui-accent-text);
        background-color: var(--ui-accent-soft-hover);
      }

      &--parent,
      &--child {
        color: #9ca3af;

        &:hover {
          color: var(--ui-accent-text);
          background-color: var(--ui-accent-soft-hover);
        }
      }
    }

    .product-nav-panel__results-header {
      color: #e5e7eb;
      border-bottom-color: #3a4459;
    }

    .product-nav-panel__result-category {
      color: #9ca3af;
      background-color: rgba(255, 255, 255, 0.08);
    }

    .product-nav-panel__result-title {
      color: #e5e7eb;
    }

    .product-nav-panel__result-item:hover {
      background-color: var(--ui-accent-soft-hover);
    }
  }
</style>
