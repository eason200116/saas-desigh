/**
 * 表格列 render 工具函数
 * 内置 h()，在列定义中直接调用即可，无需手动 import { h }
 *
 * @example
 * // IP 地址链接
 * { key: 'ip', title: 'IP', render: (row) => renderIPLink(row.ip) }
 *
 * // 在线/离线
 * { key: 'isOnLine', title: '登录状态', render: (row) => renderBoolTag(row.isOnLine, '在线', '离线') }
 *
 * // 多标签（固定颜色）
 * { key: 'langs', title: '语言', render: (row) => renderTagList(row.langs?.split(','), 'info') }
 *
 * // 单标签
 * { key: 'payCode', title: '三方映射码', render: (row) => renderTag(row.payCode, { type: 'info' }) }
 *
 * // 多标签（按索引轮换颜色）
 * { key: 'roles', title: '角色', render: (row) => renderTagList(names, 'auto') }
 *
 * // 日期时间
 * { key: 'createTime', title: '创建时间', render: (row) => renderDateTime(row.createTime) }
 * { key: 'date', title: '日期', render: (row) => renderDateTime(row.date, { format: 'yyyy-MM-dd', inline: true }) }
 */
import { h, type VNode } from 'vue';
import { NEllipsis, NSpace, NTag, NTooltip, type TagProps } from 'naive-ui';
import { useTenantOptions } from '@/hooks';
import { isIPv4Address, getSafeHtml } from '@/utils';
import DateTime from '../DateTime/index.vue';

type NativeTagType = NonNullable<TagProps['type']>;

export type TagType = NativeTagType | 'sky';
export type TagSize = NonNullable<TagProps['size']>;
const TAG_TYPE_CYCLE: NativeTagType[] = ['error', 'warning', 'info', 'success', 'default'];
const DEFAULT_TAG_MAX_WIDTH = 180;

// Sky tag 配色（参考 Ant Design / Element Plus 蓝色系）：'sky' 走 NTag 的 color prop，
// 而非 Naive UI 原生 type，因此通过 resolveTagProps 在内部做映射，调用侧仍按 TagType 写。
const SKY_TAG_COLOR = {
  color: '#E6F7FF',
  textColor: '#1890FF',
  borderColor: '#91D5FF',
} satisfies NonNullable<TagProps['color']>;

function resolveTagProps(type: TagType): Pick<TagProps, 'type' | 'color'> {
  if (type === 'sky') return { color: SKY_TAG_COLOR };
  return { type };
}

function normalizeTagLabel(value: string | number | null | undefined) {
  if (value === null || value === undefined) return '';
  return String(value).trim();
}

function toCssLength(value: number | string) {
  return typeof value === 'number' ? `${value}px` : value;
}

function resolveTagMetrics(size: TagSize) {
  if (size === 'large') {
    return { height: '28px', fontSize: '13px', lineHeight: '22px' };
  }

  if (size === 'medium') {
    return { height: '24px', fontSize: '13px', lineHeight: '20px' };
  }

  return { height: '22px', fontSize: '12px', lineHeight: '18px' };
}

function renderTagNode(
  label: string | number,
  options: Pick<RenderTagOptions, 'type' | 'size' | 'bordered' | 'maxWidth'> = {},
) {
  const { type = 'default', size = 'small', bordered = true } = options;
  const maxWidth = toCssLength(options.maxWidth ?? DEFAULT_TAG_MAX_WIDTH);
  const metrics = resolveTagMetrics(size);
  const text = String(label);

  return h(
    NTag,
    {
      size,
      bordered,
      style: `max-width:100%;height:${metrics.height};vertical-align:middle;`,
      ...resolveTagProps(type),
    },
    {
      default: () =>
        h(
          NEllipsis,
          {
            style: `max-width:${maxWidth};font-size:${metrics.fontSize};font-weight:500;line-height:${metrics.lineHeight};`,
            tooltip: text.length > 10,
          },
          { default: () => text },
        ),
    },
  );
}

// ---------------------------------------------------------------------------
// renderIPLink — IP 地址可点击链接
// ---------------------------------------------------------------------------
export function renderIPLink(ip: string | null | undefined, fallback = '--'): VNode | string {
  if (!ip) return fallback;
  const link = h(
    'a',
    {
      class: 'text-blue-600 hover:underline',
      href: `https://www.ip2location.com/demo/${ip}`,
      target: '_blank',
    },
    ip,
  );

  if (isIPv4Address(ip)) return link;

  return h(
    NEllipsis,
    {
      class: 'block max-w-full leading-snug',
      tooltip: true,
    },
    { default: () => link },
  );
}

// ---------------------------------------------------------------------------
// renderStatusTag — 枚举值 → 彩色标签
// ---------------------------------------------------------------------------
export interface StatusOption {
  type: TagType;
  label: string;
}

export function renderStatusTag(
  value: string | number | boolean | null | undefined,
  options: Record<string, StatusOption>,
  size: TagSize = 'small',
): VNode | string {
  const key = String(value ?? '');
  const opt = options[key];
  return renderTagNode(opt?.label || '--', { type: opt?.type || 'default', size, maxWidth: 160 });
}

// ---------------------------------------------------------------------------
// renderBoolTag — 布尔值快捷标签
// ---------------------------------------------------------------------------
export function renderBoolTag(
  value: boolean | number | null | undefined,
  trueLabel = '是',
  falseLabel = '否',
  trueType: TagType = 'success',
  falseType: TagType = 'default',
): VNode | string {
  const active = value === true || value === 1;
  return renderTagNode(active ? trueLabel : falseLabel, {
    type: active ? trueType : falseType,
    maxWidth: 140,
  });
}

// ---------------------------------------------------------------------------
// renderTag — 单个文本标签
// ---------------------------------------------------------------------------
export interface RenderTagOptions {
  type?: TagType;
  size?: TagSize;
  bordered?: boolean;
  fallback?: string;
  maxWidth?: number | string;
}

export function renderTag(
  value: string | number | null | undefined,
  options: RenderTagOptions = {},
): VNode | string {
  const { type = 'default', size = 'small', bordered = true, fallback = '--', maxWidth } = options;
  const label = normalizeTagLabel(value);
  if (!label) return fallback;

  return renderTagNode(label, { type, size, bordered, maxWidth });
}

// ---------------------------------------------------------------------------
// renderTagList — 数组 → 多标签
// 支持字符串数组 或 { label, type? } 对象数组
// ---------------------------------------------------------------------------
export interface TagItem {
  label: string;
  type?: TagType;
}

export interface TagListOptions {
  /** 全局颜色：固定值 | 'auto' 按索引轮换（对象自带 type 时优先用对象的） */
  type?: TagType | 'auto';
  size?: TagSize;
  bordered?: boolean;
  maxWidth?: number | string;
  center?: boolean;
  fallback?: string;
}

export function renderTagList(
  items: (string | TagItem | undefined | null)[] | null | undefined,
  options: TagListOptions | TagType | 'auto' = 'default',
): VNode | string {
  const opts: TagListOptions = typeof options === 'string' ? { type: options } : options;
  const {
    type = 'default',
    size = 'small',
    bordered = true,
    maxWidth = 150,
    center = true,
    fallback = '--',
  } = opts;

  const list = (items ?? []).flatMap((item) => {
    if (!item) return [];
    const isObj = typeof item === 'object';
    const label = normalizeTagLabel(isObj ? item.label : item);
    if (!label) return [];
    return [
      {
        label,
        type: isObj ? item.type : undefined,
      },
    ];
  });
  if (!list.length) return fallback;

  return h(
    NSpace,
    {
      size: [6, 6],
      wrap: true,
      justify: center ? 'center' : 'start',
      align: 'center',
      style: 'max-width:100%;',
    },
    {
      default: () =>
        list.map((item, index) => {
          const tagType =
            item.type || (type === 'auto' ? TAG_TYPE_CYCLE[index % TAG_TYPE_CYCLE.length] : type);
          return renderTagNode(item.label, { type: tagType, size, bordered, maxWidth });
        }),
    },
  );
}

// ---------------------------------------------------------------------------
// renderTenantTag — 商户/集团名称标签
// 内部自动通过 useTenantOptions().getTenantLabel 解析商户名称
// 用法: renderTenantTag(tenantId)
//       renderTenantTag(tenantId, tenantName)
//       renderTenantTag('直接传名称')
// ---------------------------------------------------------------------------

export function renderTenantTag(
  nameOrId?: string | number | null,
  tenantName?: string | null,
  fallback = '--',
): VNode | string {
  const { getTenantLabel, defaultTenantId } = useTenantOptions();
  const resolvedId = typeof nameOrId === 'number' ? nameOrId : undefined;
  let label: string | undefined;

  if (resolvedId) {
    label = getTenantLabel(resolvedId, tenantName) || undefined;
  } else if (typeof nameOrId === 'string' && nameOrId.trim()) {
    label = nameOrId.trim();
  } else if (defaultTenantId.value) {
    label = getTenantLabel(defaultTenantId.value) || undefined;
  }

  if (!label || label === '-' || label === '--') return fallback;

  return renderTagNode(label, { type: 'info', maxWidth: 170 });
}

// ---------------------------------------------------------------------------
// renderTenantTags — 多商户标签（一格内渲染多个 info 标签，居中换行）
// 用法: render: (row) => renderTenantTags(row.tenantIds)
// 内部对每个 id 复用 renderTenantTag 解析商户名称；空数组返回 fallback
// ---------------------------------------------------------------------------

export function renderTenantTags(
  ids?: Array<string | number> | null,
  fallback = '--',
): VNode | string {
  const list = Array.isArray(ids) ? ids.filter((v) => v != null && v !== '') : [];
  if (!list.length) return fallback;
  return h(
    'div',
    {
      style:
        'display:flex;flex-wrap:wrap;gap:4px;justify-content:center;align-items:center',
    },
    list.map((id) => renderTenantTag(id)),
  );
}

// ---------------------------------------------------------------------------
// renderMemberIdLink — 会员 ID 可点击链接（蓝色字体）
// 统一替代各处手写的 h('a', { style: 'color: #1890ff;...', onClick }, ...)
// 用法: render: (row) => renderMemberIdLink(row.userId, row.tenantId, openMemberDetailModal)
//       render: (row) => renderMemberIdLink(row.userId, row.tenantId, onClick, { bold: false })
//       render: (row) => renderMemberIdLink(row.userId, row.tenantId, onClick, { tenantLabel: row.site })
// ---------------------------------------------------------------------------

export function renderMemberIdLink(
  memberId: string | number | null | undefined,
  tenantId: string | number | null | undefined,
  onClick: (
    memberId: string | number,
    tenantId: string | number,
    tenantLabel?: string | null,
  ) => void,
  options?: { bold?: boolean; fallback?: string; tenantLabel?: string | null },
): VNode | string {
  const fallback = options?.fallback ?? '--';
  if (memberId == null || memberId === '') return fallback;
  const bold = options?.bold !== false;
  const style = bold
    ? 'color: #1890ff; font-weight: 600; cursor: pointer;'
    : 'color: #1890ff; cursor: pointer;';
  return h(
    'a',
    {
      style,
      onClick: () => onClick(memberId, tenantId ?? '', options?.tenantLabel),
    },
    String(memberId),
  );
}

// ---------------------------------------------------------------------------
// renderSummaryAmount — 汇总行：加粗金额（无颜色/符号处理）
// 用法: summary 行 { balance: { value: renderSummaryAmount(summaryData.xxx) } }
// ---------------------------------------------------------------------------

export function renderSummaryAmount(
  value: string | number | null | undefined,
  fallback = '--',
): VNode | string {
  if (value == null || value === '') return fallback;
  return h('span', { style: 'font-weight: 600' }, String(value));
}

// ---------------------------------------------------------------------------
// renderSignedAmount — 汇总行：正负号 + 颜色（正绿负红 + 加粗）
// 输入值可以是已带 "+"/"-" 前缀的字符串，也可以是原始数值
// 用法: { value: renderSignedAmount(fundStatSummary.pageAmount) }
// ---------------------------------------------------------------------------

export function renderSignedAmount(
  value: string | number | null | undefined,
  fallback = '--',
): VNode | string {
  if (value == null || value === '') return fallback;
  const str = String(value);
  const negative = str.startsWith('-');
  return h('span', { style: `color: ${negative ? '#dc2626' : '#16a34a'}; font-weight: 600;` }, str);
}

// ---------------------------------------------------------------------------
// renderOrgTag — 集团名称标签
// ---------------------------------------------------------------------------

export function renderOrgTag(orgId?: string | number | null, fallback = '--'): VNode | string {
  const { getOrgName } = useTenantOptions();
  const label = getOrgName(orgId, '');
  if (!label) return fallback;

  return renderTagNode(label, { type: 'warning', maxWidth: 170 });
}

// ---------------------------------------------------------------------------
// renderRichText — 富文本/可能含 HTML 编码的文本单元格：省略 + hover tooltip 全文
//
// 适用「后端做了 HTML 编码」的自由文本（备注 remark、操作日志 logInfo 等）：
// 这类内容含 &#40;&#41; 实体或颜色/换行标签，纯文本插值会原样显示编码串。
// 传 html: true 时走 getSafeHtml（解码实体 + DOMPurify 消毒）后按 HTML 渲染。
//
// ⚠️ 仅对「后端确实 HTML 编码」的字段开 html: true；纯文本字段（可能含字面 < / &）
//    保持 html: false，否则 getSafeHtml 会把 < 之后当标签误删。
//
// 用 span + NTooltip 手写（不用 NEllipsis）：ProCrudTable 嵌套 flex/overflow 下
// NEllipsis 的省略常失效，手写更稳。
//
// 用法:
//   render: (row) => renderRichText(row.remark, { html: true, lineClamp: 3, bold: true, color: '#ff4d4f' })
//   render: (row) => renderRichText(row.logInfo, { html: true })  // 单行省略
// ---------------------------------------------------------------------------
export interface RenderRichTextOptions {
  /** 内容是否为后端 HTML 编码文本：true 则解码+消毒后按 HTML 渲染 */
  html?: boolean;
  /** 多行省略行数；省略则单行省略 */
  lineClamp?: number;
  /** 加粗 */
  bold?: boolean;
  /** 文本颜色 */
  color?: string;
  /** tooltip 最大宽度（px） */
  tooltipMaxWidth?: number;
  /** 空值占位 */
  fallback?: string;
}

export function renderRichText(
  value: string | number | null | undefined,
  options: RenderRichTextOptions = {},
): VNode {
  const {
    html = false,
    lineClamp,
    bold = false,
    color,
    tooltipMaxWidth = 480,
    fallback = '--',
  } = options;

  const content = String(value ?? '').trim() || fallback;
  // 仅对 HTML 编码文本解码+消毒；占位符不处理，避免无谓 DOM 解析
  const innerHtml = html && content !== fallback ? getSafeHtml(content) : undefined;
  const isClamp = !!(lineClamp && lineClamp > 0);

  const triggerStyle: Record<string, string> = {
    display: isClamp ? '-webkit-box' : 'block',
    width: '100%',
    maxWidth: '100%',
    minWidth: '0',
    overflow: 'hidden',
    textOverflow: 'ellipsis',
    lineHeight: '1.5',
    textAlign: 'left',
    boxSizing: 'border-box',
  };
  if (isClamp) {
    triggerStyle['-webkit-line-clamp'] = String(lineClamp);
    triggerStyle['-webkit-box-orient'] = 'vertical';
    triggerStyle.whiteSpace = 'normal';
  } else {
    triggerStyle.whiteSpace = 'nowrap';
  }
  if (bold) triggerStyle.fontWeight = '600';
  if (color) triggerStyle.color = color;

  const triggerSpan = h(
    'span',
    {
      style: triggerStyle,
      ...(innerHtml != null ? { innerHTML: innerHtml } : {}),
    },
    innerHtml != null ? undefined : content,
  );

  return h(
    NTooltip,
    {
      trigger: 'hover',
      placement: 'top-start',
      disabled: content === fallback,
      style: `max-width: ${tooltipMaxWidth}px;`,
    },
    {
      trigger: () => triggerSpan,
      default: () =>
        h(
          'div',
          {
            style: {
              maxWidth: `${tooltipMaxWidth}px`,
              wordBreak: 'break-all',
              whiteSpace: 'pre-wrap',
              fontSize: '12px',
              lineHeight: '1.6',
              textAlign: 'left',
            },
            ...(innerHtml != null ? { innerHTML: innerHtml } : {}),
          },
          innerHtml != null ? undefined : content,
        ),
    },
  );
}

// ---------------------------------------------------------------------------
// renderDateTime — 日期时间
// ---------------------------------------------------------------------------
export function renderDateTime(
  value: any,
  options?: { format?: string; inline?: boolean },
): VNode | string {
  return h(DateTime, {
    value,
    format: options?.format,
    inline: options?.inline,
  });
}
