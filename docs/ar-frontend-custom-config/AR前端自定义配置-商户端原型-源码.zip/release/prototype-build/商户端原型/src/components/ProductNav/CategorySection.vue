<template>
  <div :id="`category-${category.key}`" class="category-section">
    <div class="category-section__header">
      <n-icon v-if="category.icon" class="category-section__icon" :size="18">
        <component :is="category.icon" />
      </n-icon>
      <span class="category-section__title">{{ t(category.title) }}</span>
      <span class="category-section__count">{{ category.items.length }}</span>
    </div>
    <div class="category-section__items">
      <ServiceItem
        v-for="item in category.items"
        :key="item.key"
        :item="item"
        @navigate="emit('navigate', $event)"
        @navigate-tab="(routeName, tabKey) => emit('navigateTab', routeName, tabKey)"
      />
    </div>
  </div>
</template>

<script setup lang="ts">
  import { useI18n } from 'vue-i18n';
  import ServiceItem from './ServiceItem.vue';
  import type { Category } from './types';

  defineProps<{
    category: Category;
  }>();

  const emit = defineEmits<{
    navigate: [routeName: string];
    navigateTab: [routeName: string, tabKey: string];
  }>();

  const { t } = useI18n();
</script>

<style lang="less" scoped>
  .category-section {
    margin-bottom: 24px;

    &__header {
      display: flex;
      align-items: center;
      padding: 0 12px 12px;
      border-bottom: 1px solid #f0f0f0;
      margin-bottom: 8px;
    }

    &__icon {
      margin-right: 8px;
      color: var(--ui-accent-text);
    }

    &__title {
      font-size: 16px;
      font-weight: 600;
      color: #333;
    }

    &__count {
      margin-left: 8px;
      font-size: 12px;
      color: #999;
      background-color: #f5f5f5;
      padding: 2px 8px;
      border-radius: 10px;
    }

    &__items {
      display: flex;
      flex-direction: column;
      gap: 2px;
    }
  }
</style>
