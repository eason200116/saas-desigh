import { computed, h, reactive, ref, watch } from 'vue';
import { useEventListener, useFileDialog, useScrollLock } from '@vueuse/core';
import { useI18n } from 'vue-i18n';
import { useMessage, useModal } from 'naive-ui';
import { useUserStore } from '@/store/modules';
import { useTranslate } from '@/components/Translate/hooks/useTranslate';
import {
  type TranslateLanguage,
  resolveLanguages,
  resolveSourceLanguage,
  sortLanguages,
} from '@/components/Translate/shared';
import { createQuickActionItems, filterQuickActionItems } from '../actions';
import { getTiptapAiActions, shouldReplaceWholeDocument } from '../ai';
import { useTiptapEditor } from '../editor';
import { normalizeEditorHtml } from '../html';
import { getEditorProfileConfig } from '../profiles';
import TiptapAiModal from '../TiptapAiModal.vue';
import type {
  BasicTiptapEditorExpose,
  TiptapAiApplyPayload,
  TiptapAiActionType,
  TiptapEditorProfile,
  TiptapImageUploadHandler,
} from '../types';

export interface BasicTiptapEditorProps {
  modelValue?: string;
  placeholder?: string;
  disabled?: boolean;
  readonly?: boolean;
  height?: string | number;
  profile?: TiptapEditorProfile;
  showToolbar?: boolean;
  showPreview?: boolean;
  uploadImage?: TiptapImageUploadHandler;
  /** 提供此 prop 后启用多语言模式 */
  translateModelValue?: Record<string, string>;
  fieldLabel?: string;
  showLabel?: boolean;
  languageList?: TranslateLanguage[];
  sourceLanguage?: string;
  showTranslateAction?: boolean;
}

export type BasicTiptapEditorEmitFn = {
  (e: 'update:modelValue', value: string): void;
  (e: 'change', value: string): void;
  (e: 'ready'): void;
  (e: 'update:translateModelValue', value: Record<string, string>): void;
  (e: 'translateChange', value: Record<string, string>): void;
};

export function useBasicTiptapEditor(props: BasicTiptapEditorProps, emit: BasicTiptapEditorEmitFn) {
  const { t } = useI18n();
  const message = useMessage();
  const modal = useModal();
  const userStore = useUserStore();

  // ─── Translate mode ─────────────────────────────────────
  const isTranslateMode = computed(() => props.translateModelValue !== undefined);
  const currentLang = ref('');
  const contentMap = reactive<Record<string, string>>({});

  const languages = computed<TranslateLanguage[]>(() =>
    resolveLanguages(
      props.languageList,
      userStore.info.languageList as TranslateLanguage[] | undefined,
    ),
  );
  const sourceLang = computed(() => resolveSourceLanguage(languages.value, props.sourceLanguage));
  const sortedLanguages = computed(() => sortLanguages(languages.value, sourceLang.value));

  function emitTranslateContentMap() {
    const nextValue: Record<string, string> = {};
    sortedLanguages.value.forEach((lang) => {
      nextValue[lang.code] = contentMap[lang.code] || '';
    });
    emit('update:translateModelValue', nextValue);
    emit('translateChange', nextValue);
  }

  function syncContentMap() {
    const activeCodes = new Set(sortedLanguages.value.map((lang) => lang.code));
    Object.keys(contentMap).forEach((code) => {
      if (!activeCodes.has(code)) delete contentMap[code];
    });
    sortedLanguages.value.forEach((lang) => {
      contentMap[lang.code] = props.translateModelValue?.[lang.code] || '';
    });
    if (!currentLang.value || !activeCodes.has(currentLang.value)) {
      currentLang.value = sourceLang.value;
    }
  }

  const { translating, handleTranslateAll } = useTranslate({
    sourceLang,
    sortedLanguages,
    getSourceContent: () => contentMap[sourceLang.value],
    applyTranslatedMap: (translatedMap) => {
      Object.entries(translatedMap).forEach(([code, value]) => {
        contentMap[code] = value;
      });
      emitTranslateContentMap();
    },
  });

  // ─── Core editor state ──────────────────────────────────
  const surfaceRef = ref<HTMLElement | null>(null);
  const isFullscreen = ref(false);
  const showPreviewModal = ref(false);
  const showSourceModal = ref(false);
  const sourceCodeDraft = ref('');
  const isAiModalOpen = ref(false);
  const slashActiveIndex = ref(0);
  const isBodyScrollLocked = useScrollLock(typeof document !== 'undefined' ? document.body : null);
  let aiModalInst: ReturnType<typeof modal.create> | null = null;

  const profileConfig = computed(() => getEditorProfileConfig(props.profile ?? 'basic'));
  const resolvedHeight = computed(() =>
    typeof props.height === 'number'
      ? props.height
      : Number.parseInt(props.height as string, 10) || 320,
  );
  const editorStyle = computed(() => ({
    '--tiptap-editor-height': isFullscreen.value
      ? 'calc(100vh - 360px)'
      : typeof props.height === 'number'
        ? `${props.height}px`
        : props.height || '320px',
  }));
  const editable = computed(() => !props.disabled && !props.readonly);
  const placeholder = computed(() => props.placeholder || t('common.tiptap.editorPlaceholder'));
  const content = computed(() => {
    if (isTranslateMode.value && currentLang.value) {
      return contentMap[currentLang.value] || '';
    }
    return props.modelValue || '';
  });
  const sourcePreviewHeight = computed(() => Math.max(resolvedHeight.value, 360));

  const {
    open: openImageDialog,
    reset: resetImageDialog,
    onChange: onImageDialogChange,
  } = useFileDialog({ accept: 'image/*', multiple: false });

  const profileRef = computed(() => (props.profile ?? 'basic') as TiptapEditorProfile);

  const {
    hostRef,
    editor,
    editorTick,
    focus,
    getHTML,
    getJSON,
    setHTML,
    insertContent,
    replaceSelection,
    getSelectionText,
  } = useTiptapEditor({
    content,
    editable,
    placeholder,
    profile: profileRef,
    onUpdate: (value) => {
      if (isTranslateMode.value && currentLang.value) {
        contentMap[currentLang.value] = value;
        emitTranslateContentMap();
      } else {
        emit('update:modelValue', value);
        emit('change', value);
      }
    },
    onReady: () => emit('ready'),
  });

  // ─── Derived state ──────────────────────────────────────
  const previewHtml = computed(() =>
    normalizeEditorHtml(editor.value?.getHTML() || props.modelValue || ''),
  );
  const plainText = computed(() => {
    void editorTick.value;
    return editor.value?.getText({ blockSeparator: '\n' }) || '';
  });
  const currentSelectionText = computed(() => {
    void editorTick.value;
    return getSelectionText().trim();
  });
  const charCount = computed(() => plainText.value.replace(/\s+/g, '').length);
  const wordCount = computed(() => {
    const normalized = plainText.value.trim();
    return normalized ? normalized.split(/\s+/).length : 0;
  });

  // ─── Quick actions ──────────────────────────────────────
  const quickActionContext = computed(() => {
    if (!editor.value) return null;
    return {
      editor: editor.value,
      profile: props.profile ?? ('basic' as TiptapEditorProfile),
      onLink: handleLinkRequest,
      onImage: handleImageRequest,
      onAiAction: openAiAction,
    };
  });
  const quickActions = computed(() => {
    const context = quickActionContext.value;
    if (!context) return [];
    return createQuickActionItems({
      t,
      profile: (props.profile ?? 'basic') as TiptapEditorProfile,
      onLink: context.onLink,
      onImage: context.onImage,
      onAiAction: context.onAiAction,
    }).filter((item) => !item.isVisible || item.isVisible(context));
  });
  const quickActionMap = computed(
    () => new Map(quickActions.value.map((item) => [item.key, item])),
  );

  // ─── AI actions ─────────────────────────────────────────
  const aiActions = computed(() => getTiptapAiActions(t));
  const aiActionMap = computed(() => new Map(aiActions.value.map((item) => [item.key, item])));
  // profile.allowAi=false（如 'plain'）时不暴露划词 AI 气泡，彻底移除 AI 能力
  const selectionAiActions = computed(() =>
    profileConfig.value.allowAi ? aiActions.value.filter((item) => item.requiresSelection) : [],
  );

  // ─── Slash panel ────────────────────────────────────────
  const slashPanel = computed(() => {
    void editorTick.value;
    const currentEditor = editor.value;
    const surface = surfaceRef.value;
    if (!currentEditor || !surface || props.disabled || props.readonly || isAiModalOpen.value)
      return null;

    const { from, empty, $from } = currentEditor.state.selection;
    if (!empty) return null;

    const textBeforeCursor = $from.parent.textBetween(0, $from.parentOffset, '\0', '\0');
    const match = textBeforeCursor.match(/^\/([^\s]*)$/);
    if (!match) return null;

    const items = filterQuickActionItems(quickActions.value, match[1]).slice(0, 8);
    if (!items.length) return null;

    const surfaceRect = surface.getBoundingClientRect();
    const coords = currentEditor.view.coordsAtPos(from);

    return {
      items,
      from: from - textBeforeCursor.length,
      to: from,
      top: coords.bottom - surfaceRect.top + 10,
      left: coords.left - surfaceRect.left,
    };
  });
  const slashPanelStyle = computed(() => {
    if (!slashPanel.value) return undefined;
    return {
      top: `${Math.max(8, slashPanel.value.top)}px`,
      left: `${Math.max(8, slashPanel.value.left)}px`,
    };
  });

  // ─── Selection bubble ───────────────────────────────────
  const selectionBubbleStyle = computed(() => {
    void editorTick.value;
    const currentEditor = editor.value;
    const surface = surfaceRef.value;
    if (
      !currentEditor ||
      !surface ||
      props.disabled ||
      props.readonly ||
      !currentSelectionText.value ||
      isAiModalOpen.value
    ) {
      return undefined;
    }

    const { from, to } = currentEditor.state.selection;
    if (from === to) return undefined;

    const start = currentEditor.view.coordsAtPos(from);
    const end = currentEditor.view.coordsAtPos(to);
    const surfaceRect = surface.getBoundingClientRect();
    const centerX = (start.left + end.right) / 2 - surfaceRect.left;
    const top = Math.max(12, Math.min(start.top - surfaceRect.top - 10, surfaceRect.height - 24));

    return {
      top: `${top}px`,
      left: `${centerX}px`,
      transform: 'translate(-50%, -100%)',
    };
  });

  // ─── Methods ────────────────────────────────────────────
  function handleLinkRequest() {
    const currentEditor = editor.value;
    if (!currentEditor || props.disabled || props.readonly) return;

    const currentHref = (currentEditor.getAttributes('link').href as string | undefined) || '';
    const nextHref = window.prompt(t('common.tiptap.linkPrompt'), currentHref);
    if (nextHref === null) return;

    const normalizedHref = nextHref.trim();
    if (!normalizedHref) {
      currentEditor.chain().focus().extendMarkRange('link').unsetLink().run();
      return;
    }

    currentEditor.chain().focus().extendMarkRange('link').setLink({ href: normalizedHref }).run();
  }

  async function handleImageFileChange(file: File | null | undefined) {
    const currentEditor = editor.value;
    if (!currentEditor || !file || !props.uploadImage) {
      resetImageDialog();
      return;
    }

    try {
      const result = await props.uploadImage(file);
      currentEditor
        .chain()
        .focus()
        .setImage({ src: result.url, alt: result.alt || file.name })
        .run();
      message.success(t('common.tiptap.imageUploadSuccess'));
    } catch (error) {
      console.error('upload image failed:', error);
      message.error(t('common.tiptap.imageUploadFailed'));
    } finally {
      resetImageDialog();
    }
  }

  function handleImageRequest() {
    const currentEditor = editor.value;
    if (!currentEditor || props.disabled || props.readonly) return;

    if (props.uploadImage) {
      openImageDialog();
      return;
    }

    const nextSrc = window.prompt(t('common.tiptap.imagePrompt'), '');
    if (nextSrc === null) return;

    const normalizedSrc = nextSrc.trim();
    if (!normalizedSrc) return;

    currentEditor.chain().focus().setImage({ src: normalizedSrc }).run();
  }

  function syncExternalValue(value: string) {
    const normalized = normalizeEditorHtml(value);
    if (isTranslateMode.value && currentLang.value) {
      contentMap[currentLang.value] = normalized;
      emitTranslateContentMap();
    } else {
      emit('update:modelValue', normalized);
      emit('change', normalized);
    }
  }

  function openSourceModal() {
    sourceCodeDraft.value = getHTML();
    showSourceModal.value = true;
  }

  function applySourceCode() {
    setHTML(sourceCodeDraft.value);
    syncExternalValue(sourceCodeDraft.value);
    showSourceModal.value = false;
  }

  function openPreviewModal() {
    showPreviewModal.value = true;
  }

  function toggleFullscreen() {
    isFullscreen.value = !isFullscreen.value;
  }

  function handleQuickAction(key: string) {
    const item = quickActionMap.value.get(key);
    const context = quickActionContext.value;
    if (!item || !context) return;
    item.run(context);
  }

  function openAiAction(action: TiptapAiActionType) {
    const actionConfig = aiActionMap.value.get(action);
    if (!actionConfig) return;

    if (actionConfig.requiresSelection && !currentSelectionText.value) {
      message.warning(t('common.tiptap.aiSelectionRequired'));
      return;
    }

    destroyAiModal();
    isAiModalOpen.value = true;

    aiModalInst = modal.create({
      preset: 'card',
      title: actionConfig.label || t('common.tiptap.aiTitle'),
      closable: true,
      maskClosable: true,
      style: { width: 'min(860px, 92vw)' },
      onClose: destroyAiModal,
      onMaskClick: destroyAiModal,
      content: () =>
        h(TiptapAiModal, {
          action: actionConfig,
          selection: currentSelectionText.value,
          initialInstruction: actionConfig.defaultInstruction || '',
          documentHtml: getHTML(),
          onClose: destroyAiModal,
          onApply: (payload: TiptapAiApplyPayload) => {
            applyAiResult(payload);
            destroyAiModal();
          },
        }),
    });
  }

  function destroyAiModal() {
    const currentInst = aiModalInst;
    aiModalInst = null;
    isAiModalOpen.value = false;
    currentInst?.destroy();
  }

  function applyAiResult(payload: TiptapAiApplyPayload) {
    if (!payload.result.trim()) return;

    const normalizedResult = normalizeEditorHtml(payload.result);
    const hasSelection = payload.hasSelection;

    if (hasSelection) {
      replaceSelection(normalizedResult);
    } else if (
      shouldReplaceWholeDocument(payload.action, hasSelection) ||
      !normalizeEditorHtml(getHTML())
    ) {
      setHTML(normalizedResult);
      syncExternalValue(normalizedResult);
    } else {
      insertContent(normalizedResult);
    }

    focus();
    message.success(t('common.tiptap.aiApplySuccess'));
  }

  function runSlashItem(key: string) {
    if (!slashPanel.value) return;

    const currentEditor = editor.value;
    if (!currentEditor) return;

    currentEditor
      .chain()
      .focus()
      .deleteRange({ from: slashPanel.value.from, to: slashPanel.value.to })
      .run();

    handleQuickAction(key);
  }

  function handleWindowKeydown(event: KeyboardEvent) {
    if (slashPanel.value) {
      if (event.key === 'ArrowDown') {
        event.preventDefault();
        slashActiveIndex.value = (slashActiveIndex.value + 1) % slashPanel.value.items.length;
        return;
      }
      if (event.key === 'ArrowUp') {
        event.preventDefault();
        slashActiveIndex.value =
          (slashActiveIndex.value - 1 + slashPanel.value.items.length) %
          slashPanel.value.items.length;
        return;
      }
      if (event.key === 'Enter') {
        event.preventDefault();
        runSlashItem(slashPanel.value.items[slashActiveIndex.value]?.key || '');
        return;
      }
      if (event.key === 'Escape') {
        event.preventDefault();
        editor.value
          ?.chain()
          .focus()
          .deleteRange({ from: slashPanel.value.from, to: slashPanel.value.to })
          .run();
        return;
      }
    }

    if (event.key === 'Escape' && (showSourceModal.value || showPreviewModal.value)) {
      return;
    }

    if (event.key === 'Escape' && isFullscreen.value) {
      isFullscreen.value = false;
    }
  }

  // ─── Side effects ───────────────────────────────────────
  onImageDialogChange((files) => {
    void handleImageFileChange(files?.[0]);
  });

  watch(isFullscreen, (nextValue) => {
    isBodyScrollLocked.value = nextValue;
  });

  watch(
    () => slashPanel.value?.from,
    () => {
      slashActiveIndex.value = 0;
    },
  );

  useEventListener('keydown', (event: KeyboardEvent) => {
    handleWindowKeydown(event);
  });

  // Translate mode watchers
  watch(
    () => props.translateModelValue,
    () => {
      if (isTranslateMode.value) syncContentMap();
    },
    { immediate: true, deep: true },
  );

  watch(
    sortedLanguages,
    () => {
      if (isTranslateMode.value) syncContentMap();
    },
    { immediate: true },
  );

  // ─── Return ─────────────────────────────────────────────
  const expose: BasicTiptapEditorExpose = {
    focus,
    getHTML,
    getJSON,
    setHTML,
    insertContent,
    replaceSelection,
    getSelectionText,
  };

  return {
    t,
    // Translate mode
    isTranslateMode,
    currentLang,
    sortedLanguages,
    translating,
    handleTranslateAll,
    // Core refs
    surfaceRef,
    hostRef,
    editor,
    editorTick,
    // UI state
    isFullscreen,
    showPreviewModal,
    showSourceModal,
    sourceCodeDraft,
    slashActiveIndex,
    profileConfig,
    resolvedHeight,
    editorStyle,
    sourcePreviewHeight,
    // Derived data
    previewHtml,
    charCount,
    wordCount,
    quickActions,
    selectionAiActions,
    slashPanel,
    slashPanelStyle,
    selectionBubbleStyle,
    // Methods
    handleLinkRequest,
    handleImageRequest,
    openSourceModal,
    applySourceCode,
    openPreviewModal,
    toggleFullscreen,
    handleQuickAction,
    openAiAction,
    runSlashItem,
    // Expose
    expose,
  };
}
