import type { TiptapEditorProfile } from './types';

export interface TiptapEditorProfileConfig {
  allowImages: boolean;
  allowTables: boolean;
  allowAi: boolean;
  allowTemplates: boolean;
  allowAdvancedBlocks: boolean;
}

const DEFAULT_PROFILE_CONFIG: TiptapEditorProfileConfig = {
  allowImages: true,
  allowTables: true,
  allowAi: true,
  allowTemplates: true,
  allowAdvancedBlocks: true,
};

// 'plain'：关闭 AI（改写/续写/翻译等），其余能力保留；用于协议管理等公开正文。
const PLAIN_PROFILE_CONFIG: TiptapEditorProfileConfig = {
  ...DEFAULT_PROFILE_CONFIG,
  allowAi: false,
};

export function getEditorProfileConfig(profile: TiptapEditorProfile): TiptapEditorProfileConfig {
  return profile === 'plain' ? PLAIN_PROFILE_CONFIG : DEFAULT_PROFILE_CONFIG;
}
