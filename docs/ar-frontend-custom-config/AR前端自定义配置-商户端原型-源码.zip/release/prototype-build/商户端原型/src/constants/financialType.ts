/**
 * 资金账变类型 —— 主类型 / 子类型 分级（全站单一数据源）
 *
 * 来源：迁移源站 V1 `FinancialLogTypeEnum`
 *   - 编码源头：ar_v1_lotteryapi/WaterCloud.Code/Common/CommonEnum.cs（FinancialLogTypeEnum）
 *   - 中文显示名：Ar_V1_Admin/PC.dianzan/Areas/Admin/Models/ModelData.cs（FinanceTypes 后台实际渲染名）
 *   - 英文：取 enum [Description]（个别 admin 专有码按语义补）
 *
 * 说明：
 *   - code 一律沿用 V1 真实编码（0/1/2…134），迁移对接不错位。
 *   - 主类型仅用于两级筛选与归类，不占用 code；子类型 code 即后端 type 值。
 *   - 消费方：finance/fundChange（资金账变页）、MemberDetail/fund（会员详情·资金记录 Tab）、
 *     src/api/index.ts（生成扁平字典 financialTypeList + mock 账变记录）。
 */

/** 游戏组第 4 层「游戏名称」（仅资金账变单选级联展开）。自研=V1 LotteryCategoryEnum 真品类；三方=mock 示意 */
export interface FinancialGame {
  id: number;
  zh: string;
  en: string;
}

/** 游戏组第 3 层「厂商」（仅资金账变单选级联展开；自研=ARGame(100)、三方取 V1 ThirdGameVendorEnum） */
export interface FinancialVendor {
  /** V1 ThirdGameVendorEnum id（自研=100） */
  id: number;
  zh: string;
  en: string;
  /** 第 4 层游戏名称（该厂商下的游戏）；自研=真彩票品类、三方=mock */
  games?: FinancialGame[];
}

export interface FinancialSubType {
  /** V1 真实 type 编码 */
  code: number;
  zh: string;
  en: string;
  /** 可选第 3 层「厂商」——仅游戏组子类型有；只在资金账变单选级联里展开（会员详情等仍 2 层不受影响） */
  vendors?: FinancialVendor[];
  /**
   * 可选「同级归组」标签——多个独立 code 的子类型共享同一展示父节点（如策略钱包-转入/转出收进「策略钱包」下），
   * 不影响 code/zh/en 本身（表格仍显示各自完整名称），只影响资金账变单选级联的树形展示（withVendor=true 时）；
   * 会员详情等 2 层模式不受影响（该模式本就不区分厂商/归组，始终扁平）。
   */
  subGroup?: { zh: string; en: string };
}

export interface FinancialTypeGroup {
  /** 主类型 key（筛选节点值，形如 g_recharge，不与 code 冲突） */
  key: string;
  zh: string;
  en: string;
  children: FinancialSubType[];
}

/** 主类型节点值前缀（级联选择器父节点 value，用于与数字 code 区分） */
export const FINANCIAL_GROUP_PREFIX = 'g_';

/**
 * 自研厂商（平台自研彩票 投注/中奖 用）——对应 V1 ThirdGameVendorEnum.ARGame(100)。
 * 第 4 层游戏名 = V1 LotteryCategoryEnum 真品类（WinGo/TrxWin/K3/5D）。
 */
const SELF_DEV_VENDOR: FinancialVendor[] = [
  {
    id: 100,
    zh: '自研',
    en: 'In-house',
    games: [
      { id: 1, zh: 'WinGo', en: 'WinGo' },
      { id: 2, zh: 'TrxWin', en: 'TrxWin' },
      { id: 3, zh: 'K3', en: 'K3' },
      { id: 4, zh: '5D', en: '5D' },
    ],
  },
];
/**
 * 三方厂商（精简 8 个，id/名取自 V1 ThirdGameVendorEnum）——电子/游戏转账类用。
 * 第 4 层游戏名：V1 账变不记录具体游戏、库无种子数据，故为 mock 示意（每厂商 3 款代表）。
 */
const THIRD_PARTY_VENDORS: FinancialVendor[] = [
  {
    id: 5,
    zh: 'PG电子',
    en: 'PG',
    games: [
      { id: 1, zh: '麻将胡了', en: 'Mahjong Ways' },
      { id: 2, zh: '寻宝黄金城', en: 'Gem Saviour' },
      { id: 3, zh: '赏金女王', en: 'Bounty Queen' },
    ],
  },
  {
    id: 2,
    zh: 'CQ9电子',
    en: 'CQ9',
    games: [
      { id: 1, zh: '跳高高', en: 'Jump High' },
      { id: 2, zh: '宝石侠', en: 'Gem Hero' },
      { id: 3, zh: '福运象财神', en: 'Fortune Elephant' },
    ],
  },
  {
    id: 16,
    zh: 'EVO视讯',
    en: 'EVO',
    games: [
      { id: 1, zh: '百家乐', en: 'Baccarat' },
      { id: 2, zh: '轮盘', en: 'Roulette' },
      { id: 3, zh: '骰宝', en: 'Sic Bo' },
    ],
  },
  {
    id: 10,
    zh: 'AG视讯',
    en: 'AG',
    games: [
      { id: 1, zh: 'AG百家乐', en: 'AG Baccarat' },
      { id: 2, zh: 'AG龙虎斗', en: 'AG Dragon Tiger' },
      { id: 3, zh: 'AG牛牛', en: 'AG Niu Niu' },
    ],
  },
  {
    id: 18,
    zh: 'JILI电子',
    en: 'JILI',
    games: [
      { id: 1, zh: '幸运财神', en: 'Lucky God' },
      { id: 2, zh: '超级王牌', en: 'Super Ace' },
      { id: 3, zh: '大力神', en: 'Hercules' },
    ],
  },
  {
    id: 7,
    zh: 'DG视讯',
    en: 'DG',
    games: [
      { id: 1, zh: 'DG百家乐', en: 'DG Baccarat' },
      { id: 2, zh: 'DG轮盘', en: 'DG Roulette' },
      { id: 3, zh: 'DG骰宝', en: 'DG Sic Bo' },
    ],
  },
  {
    id: 14,
    zh: '沙巴体育',
    en: 'SaBa',
    games: [
      { id: 1, zh: '足球', en: 'Football' },
      { id: 2, zh: '篮球', en: 'Basketball' },
      { id: 3, zh: '网球', en: 'Tennis' },
    ],
  },
  {
    id: 6,
    zh: 'JDB电子',
    en: 'JDB',
    games: [
      { id: 1, zh: '财神发发发', en: 'Fortune God' },
      { id: 2, zh: '五福临门', en: 'Five Blessings' },
      { id: 3, zh: '累计彩金', en: 'Jackpot' },
    ],
  },
];

export const FINANCIAL_TYPE_GROUPS: FinancialTypeGroup[] = [
  {
    key: 'recharge',
    zh: '充值',
    en: 'Recharge',
    children: [
      { code: 4, zh: '充值', en: 'Recharge increase' },
      { code: 10, zh: '充值赠送', en: 'Recharge gift' },
      { code: 11, zh: '人工充值', en: 'Manual recharge' },
      { code: 13, zh: '彩金充值', en: 'Bonus recharge' },
      { code: 27, zh: 'USDT充值', en: 'USDT recharge' },
      { code: 8, zh: '代理红包充值', en: 'Agent red envelope recharge' },
      { code: 125, zh: '充值补单', en: 'Recharge replenishment' },
      { code: 131, zh: '下载APP充值奖励', en: 'Download APP recharge reward' },
      { code: 132, zh: '充值等级奖励', en: 'Recharge level rewards' },
      { code: 134, zh: '回归新充值奖励', en: 'Old user return new recharge rewards' },
      // 系统/调整组拆分移入：ARPay钱包退回
      { code: 123, zh: 'ARPay钱包退回', en: 'ARPay cash back' },
    ],
  },
  {
    key: 'withdraw',
    zh: '提现',
    en: 'Withdraw',
    children: [
      { code: 5, zh: '提现', en: 'Withdrawal reduction' },
      { code: 6, zh: '提现退回', en: 'Withdrawal cash back' },
      { code: 9, zh: '出款拒绝', en: 'Withdrawal rejected' },
      { code: 101, zh: '人工提款', en: 'Manual withdrawal' },
      { code: 126, zh: '提现活动奖励', en: 'Withdraw awards' },
    ],
  },
  {
    key: 'game',
    zh: '游戏',
    en: 'Game',
    children: [
      // 投注/中奖=平台自研彩票 → 厂商「自研」；电子/游戏转账=三方 → 8 个三方厂商
      { code: 0, zh: '投注', en: 'Bet', vendors: SELF_DEV_VENDOR },
      { code: 2, zh: '中奖', en: 'Jackpot', vendors: SELF_DEV_VENDOR },
      { code: 23, zh: '电子投注', en: 'Electronic bet', vendors: THIRD_PARTY_VENDORS },
      { code: 24, zh: '电子中奖', en: 'Electronic jackpot', vendors: THIRD_PARTY_VENDORS },
      { code: 103, zh: '电子大奖', en: 'Electronic awards', vendors: THIRD_PARTY_VENDORS },
      { code: 21, zh: '游戏存入', en: 'Game transfer in', vendors: THIRD_PARTY_VENDORS },
      { code: 22, zh: '游戏取回', en: 'Game transfer out', vendors: THIRD_PARTY_VENDORS },
      { code: 26, zh: '游戏退还', en: 'Game money refund', vendors: THIRD_PARTY_VENDORS },
      // 系统/调整组拆分移入（无厂商层，普通叶子）：彩金扣除 / XOSO期号取消
      { code: 100, zh: '彩金扣除', en: 'Bonus deduction' },
      { code: 105, zh: 'XOSO期号取消', en: 'XOSO issue canceled' },
      // 跟单冻结扣款/解冻加钱（V3 新增·无 V1 码·普通叶子不挂厂商，收进「跟单」归组节点，替代原策略钱包转账）
      {
        code: 137,
        zh: '跟单冻结扣款',
        en: 'Follow-order Freeze Deduction',
        subGroup: { zh: '跟单', en: 'Follow Order' },
      },
      {
        code: 138,
        zh: '跟单解冻加钱',
        en: 'Follow-order Unfreeze Credit',
        subGroup: { zh: '跟单', en: 'Follow Order' },
      },
    ],
  },
  {
    key: 'rebate',
    zh: '返佣返水',
    en: 'Commission & Rebate',
    children: [
      { code: 1, zh: '投注返佣', en: 'Agency commission' },
      { code: 28, zh: '投注返水', en: 'Betting rebate' },
      { code: 102, zh: '一键洗码反水', en: 'One-key wash code rebate' },
      { code: 122, zh: '合伙人奖励', en: 'Partner rewards' },
    ],
  },
  {
    key: 'activity',
    zh: '活动奖励',
    en: 'Activity Bonus',
    children: [
      { code: 3, zh: '红包', en: 'Red envelope' },
      { code: 7, zh: '每日签到', en: 'Daily check-in' },
      { code: 12, zh: '注册送金', en: 'Sign-up bonus' },
      { code: 14, zh: '首充满赠送', en: 'First full gift' },
      { code: 15, zh: '首充返佣', en: 'First charge rebate' },
      { code: 20, zh: '邀请奖励', en: 'Invite bonus' },
      { code: 25, zh: '绑卡赠送', en: 'Card binding gift' },
      { code: 104, zh: '绑定手机奖励', en: 'Bind mobile awards' },
      { code: 106, zh: '绑定邮箱奖励', en: 'Bind email awards' },
      { code: 107, zh: '每周奖励', en: 'Weekly awards' },
      { code: 113, zh: '新手礼包', en: 'Newbie gift pack' },
      { code: 114, zh: '锦标赛奖励', en: 'Tournament rewards' },
      { code: 115, zh: '回归奖励', en: 'Return awards' },
      { code: 116, zh: '新会员负盈利送彩金', en: 'New member negative-profit bonus' },
      { code: 117, zh: '新会员玩游戏送彩金', en: 'New member play-game bonus' },
      { code: 118, zh: '每日奖励', en: 'Daily awards' },
      { code: 119, zh: '转盘奖励', en: 'Turntable awards' },
      { code: 124, zh: '加入频道奖励', en: 'Join channel awards' },
      { code: 130, zh: '邀请转盘奖励', en: 'Invitation wheel rewards' },
      // VIP 组并入活动奖励（原独立 VIP 组已删）
      { code: 29, zh: 'VIP会员升级礼包', en: 'VIP member upgrade package' },
      { code: 30, zh: 'VIP会员每月奖励', en: 'VIP monthly rewards' },
      { code: 31, zh: 'VIP会员充值奖励', en: 'VIP recharge rewards' },
      { code: 133, zh: 'VIP充值等级奖励', en: 'VIP recharge level rewards' },
    ],
  },
  // 说明：①理财/保险箱组(17/18/19)整删；②系统/调整组拆分——彩金扣除(100)/XOSO期号取消(105)→游戏组、
  //       ARPay钱包退回(123)→充值组、VIP 4 码→活动奖励组（均见上）。以 V1 真码为准，仅重新归组。
];

type Lang = 'zh' | 'en';

const normLang = (lang?: string): Lang => (lang && lang.startsWith('en') ? 'en' : 'zh');

/** 扁平子类型（按主类型顺序展开） */
export const FINANCIAL_SUBTYPES: FinancialSubType[] = FINANCIAL_TYPE_GROUPS.flatMap(
  (g) => g.children,
);

/** 扁平字典（value=code, label=中文）—— 兼容 useDictionary('financialTypeList') 老消费方 */
export const FINANCIAL_TYPE_FLAT_DICT: { value: number; label: string }[] = FINANCIAL_SUBTYPES.map(
  (s) => ({ value: s.code, label: s.zh }),
);

/** 主类型 key → 子类型 code 列表 */
const GROUP_CODE_MAP = new Map<string, number[]>(
  FINANCIAL_TYPE_GROUPS.map((g) => [
    `${FINANCIAL_GROUP_PREFIX}${g.key}`,
    g.children.map((c) => c.code),
  ]),
);

/** code → 子类型标签（按语言） */
export function buildFinancialTypeLabelMap(lang?: string): Map<string | number, string> {
  const l = normLang(lang);
  const map = new Map<string | number, string>();
  FINANCIAL_SUBTYPES.forEach((s) => {
    const label = l === 'en' ? s.en : s.zh;
    map.set(s.code, label);
    map.set(String(s.code), label);
  });
  return map;
}

/** code → “主类型-子类型”标签（按语言）—— 列表展示用 */
export function buildFinancialTypeFullLabelMap(lang?: string): Map<string | number, string> {
  const l = normLang(lang);
  const map = new Map<string | number, string>();
  FINANCIAL_TYPE_GROUPS.forEach((g) => {
    const gl = l === 'en' ? g.en : g.zh;
    g.children.forEach((c) => {
      const full = `${gl}-${l === 'en' ? c.en : c.zh}`;
      map.set(c.code, full);
      map.set(String(c.code), full);
    });
  });
  return map;
}

/** 全部账变类型速查清单（主类型 + 其子类型名，按语言）—— 问号气泡内容用 */
export function buildFinancialTypeLegend(lang?: string): Array<{ label: string; items: string[] }> {
  const l = normLang(lang);
  return FINANCIAL_TYPE_GROUPS.map((g) => ({
    label: l === 'en' ? g.en : g.zh,
    items: g.children.map((c) => (l === 'en' ? c.en : c.zh)),
  }));
}

/**
 * 级联选择器选项（主类型 → 子类型 [→ 厂商]，按语言）。
 * - 不传 allLabel（默认）：主类型 value=主类型 key，作父节点整组选（供多选 checkStrategy='parent' 用，如会员详情·资金记录）；始终 2 层。
 * - 传 allLabel（单选，参照系统日志「操作路径」，如资金账变）：主类型为非叶子包装节点(grp: 前缀、不可直接选中)，
 *   其下首个「（全部）」叶子代表整组筛（值=主类型 key，expandFinancialTypeValue 会展开为全部子类型 code）。
 * - withVendor=true（仅资金账变）：游戏组子类型再展开第 3 层「厂商」、第 4 层「游戏名称」：
 *   子类型非叶子(sub:code) → 厂商(有游戏则非叶子 vw:code:vid) → 游戏叶子(gm:code:vid:gid)。
 *   每层首个「（全部）」叶子代表按该层整体筛（子类型全部=code、厂商全部=v:code:vid）。
 *   同一层内，共享 subGroup 的多个独立子类型（如策略钱包-转入/转出）会先收进一个不可单独选中的
 *   归组节点(grp2:mainKey:codes)，其下才是各自叶子；checkStrategy='child' 下勾选归组节点会
 *   原生级联勾选到底层各 code，取值仍是各自 code，不受影响。
 */
export function buildFinancialTypeCascaderOptions(
  lang?: string,
  allLabel?: string,
  withVendor = false,
  multiSelect = false,
) {
  const l = normLang(lang);
  const gl = (o: { zh: string; en: string }) => (l === 'en' ? o.en : o.zh);
  // 多选模式（仅资金账变）：去掉各层「（全部）」叶子，改用原生父级复选框「全选其下」；
  // 主类型(一级)不作独立选中项（checkStrategy='child' 下取值恒为子类型/厂商/游戏叶子）。
  const allLeaf = (value: string | number) =>
    multiSelect || allLabel == null ? [] : [{ label: allLabel, value }];
  return FINANCIAL_TYPE_GROUPS.map((g) => {
    const mainKey = `${FINANCIAL_GROUP_PREFIX}${g.key}`;
    // 单选/多选级联（传入 allLabel）
    if (allLabel != null) {
      // 单个子类型 → 叶子，或（有厂商时）非叶子(sub:) + 厂商/游戏子树
      const buildSubTypeNode = (c: FinancialSubType) => {
        // 需要第 3 层 + 该子类型有厂商 → 子类型变非叶子(sub:)，其下「（全部）」+ 各厂商
        if (withVendor && c.vendors?.length) {
          const vendorNodes = c.vendors.map((v) => {
            // 厂商有游戏 → 厂商非叶子(vw:)，其下「（全部）」+ 各游戏名(第 4 层)
            if (v.games?.length) {
              return {
                label: gl(v),
                value: `vw:${c.code}:${v.id}`,
                children: [
                  ...allLeaf(`v:${c.code}:${v.id}`),
                  ...v.games.map((gm) => ({
                    label: gl(gm),
                    value: `gm:${c.code}:${v.id}:${gm.id}`,
                  })),
                ],
              };
            }
            // 厂商无游戏 → 厂商叶子
            return { label: gl(v), value: `v:${c.code}:${v.id}` };
          });
          return {
            label: gl(c),
            value: `sub:${c.code}`,
            children: [...allLeaf(c.code), ...vendorNodes],
          };
        }
        return { label: gl(c), value: c.code };
      };
      // 归组节点下叶子标签去掉与父节点重复的组名前缀（中文"策略钱包-"连字符式 / 英文"Strategy Wallet "空格式），
      // 树内只显示「转入/转出」「Transfer in/out」；zh/en 字段本身不变，表格整名展示（走 buildFinancialType*LabelMap）不受影响。
      const stripGroupPrefix = (label: string, group: string) => {
        if (label.startsWith(`${group}-`)) return label.slice(group.length + 1);
        if (label.startsWith(`${group} `)) {
          const rest = label.slice(group.length + 1);
          return rest.charAt(0).toUpperCase() + rest.slice(1);
        }
        return label;
      };
      // 共享 subGroup 的多个子类型（如策略钱包-转入/转出）收进一个归组节点；
      // 首次遇到该 subGroup 时一并取出全部同组成员建节点，后续成员跳过（已并入）。
      const groupedKeys = new Set<string>();
      const subNodes = g.children.flatMap((c) => {
        if (withVendor && c.subGroup) {
          if (groupedKeys.has(c.subGroup.zh)) return [];
          groupedKeys.add(c.subGroup.zh);
          const groupLabel = gl(c.subGroup);
          const members = g.children.filter((x) => x.subGroup?.zh === c.subGroup!.zh);
          return [
            {
              label: groupLabel,
              value: `grp2:${mainKey}:${members.map((m) => m.code).join('_')}`,
              children: members.map((m) => {
                const node = buildSubTypeNode(m);
                if (typeof node.label === 'string') {
                  return { ...node, label: stripGroupPrefix(node.label, groupLabel) };
                }
                return node;
              }),
            },
          ];
        }
        return [buildSubTypeNode(c)];
      });
      return {
        label: gl(g),
        // value 加 grp: 前缀，避免与其下「（全部）」叶子(mainKey)撞值；一级不可被直接选中
        value: `grp:${mainKey}`,
        children: [...allLeaf(mainKey), ...subNodes],
      };
    }
    // 默认（多选 checkStrategy='parent'，会员详情）：2 层扁平，不含厂商
    return {
      label: gl(g),
      value: mainKey,
      children: g.children.map((c) => ({ label: gl(c), value: c.code })),
    };
  });
}

/**
 * 把级联选择器的选中值（可能混有主类型 key 与子类型 code）展开为纯子类型 code 数组，
 * 供后端 type 过滤使用。主类型 key → 展开为其全部子类型 code；数字 code 原样保留。
 */
export function expandFinancialTypeValue(
  value: Array<string | number> | string | number | null | undefined,
): number[] {
  if (value == null || value === '') return [];
  const arr = Array.isArray(value) ? value : [value];
  const codes = new Set<number>();
  arr.forEach((v) => {
    const groupCodes = GROUP_CODE_MAP.get(String(v));
    if (groupCodes) {
      groupCodes.forEach((c) => codes.add(c));
    } else {
      const n = Number(v);
      if (!Number.isNaN(n)) codes.add(n);
    }
  });
  return Array.from(codes);
}

/** 账变类型多选级联的一个匹配项：子类型 code [+ 厂商 id] [+ 游戏 id]，逐维 AND，多个匹配项之间 OR。 */
export interface FinancialTypeMatcher {
  code: number;
  vendorId?: number;
  gameId?: number;
}

/**
 * 解析资金账变「账变类型」多选级联的选中值（数组，支持第 3/4 层厂商/游戏）→ 匹配项数组：
 *  - 子类型 code（数字/数字串）→ { code }
 *  - 厂商叶子 v:{code}:{vendorId} → { code, vendorId }
 *  - 游戏叶子 gm:{code}:{vendorId}:{gameId} → { code, vendorId, gameId }
 *  - 主类型 key（g_xxx，多选下已不产生；容错）→ 展开为该组全部子类型 { code }
 * 非叶子包装值(grp:/sub:/vw:)在 checkStrategy='child' 下不会进入取值。
 */
export function parseFinancialTypeMatchers(
  value: Array<string | number> | string | number | null | undefined,
): FinancialTypeMatcher[] {
  if (value == null || value === '') return [];
  const arr = Array.isArray(value) ? value : [value];
  const out: FinancialTypeMatcher[] = [];
  for (const v of arr) {
    const s = String(v);
    if (s.startsWith('gm:')) {
      const [, code, vid, gid] = s.split(':');
      out.push({ code: Number(code), vendorId: Number(vid), gameId: Number(gid) });
    } else if (s.startsWith('v:')) {
      const [, code, vid] = s.split(':');
      out.push({ code: Number(code), vendorId: Number(vid) });
    } else {
      const groupCodes = GROUP_CODE_MAP.get(s);
      if (groupCodes) groupCodes.forEach((c) => out.push({ code: c }));
      else {
        const n = Number(s);
        if (!Number.isNaN(n)) out.push({ code: n });
      }
    }
  }
  return out;
}

/** 在游戏子类型下按 code 找厂商对象（内部用） */
function findVendor(code: number, vendorId: number): FinancialVendor | undefined {
  for (const g of FINANCIAL_TYPE_GROUPS) {
    const sub = g.children.find((c) => c.code === code);
    const v = sub?.vendors?.find((x) => x.id === vendorId);
    if (v) return v;
  }
  return undefined;
}

/** code + 厂商 id → 厂商标签（列表展示第 3 层用）；找不到返回 ''。 */
export function resolveFinancialVendorLabel(
  code: number,
  vendorId: number | null | undefined,
  lang?: string,
): string {
  if (vendorId == null) return '';
  const v = findVendor(code, vendorId);
  return v ? (normLang(lang) === 'en' ? v.en : v.zh) : '';
}

/** code + 厂商 id + 游戏 id → 游戏名标签（列表展示第 4 层用）；找不到返回 ''。 */
export function resolveFinancialGameLabel(
  code: number,
  vendorId: number | null | undefined,
  gameId: number | null | undefined,
  lang?: string,
): string {
  if (vendorId == null || gameId == null) return '';
  const gm = findVendor(code, vendorId)?.games?.find((x) => x.id === gameId);
  return gm ? (normLang(lang) === 'en' ? gm.en : gm.zh) : '';
}
