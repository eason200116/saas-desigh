// 游戏子游戏池 —— 唯一真源，补上配置链「第三方厂商 → 总控接入 → 商户配置 → C 端展示」里的子游戏一环。
// 与 gameVendorPool（厂商身份）/ gameMainTypePool（主类型）配套：厂商池定"哪家厂商"，本池定"该厂商下有哪些游戏"。
//
// 为什么要有：此前子游戏 mock 散在 5 处、各造各的（总控 game/subgame、商户 game/merchant/subgame、
// 主类型挂靠弹窗 merchant/mainType/components、两端「查看子游戏」弹窗），同一款游戏在不同页
// 编码/名称/大类对不上，商户端挑的子游戏在总控端找不到。收敛到本池后，各页只取身份、不再各自造。
//
// 口径（与 gameVendorPool 一致）：**本池只存"身份"，不存状态**。
// 启停 / 排序 / 映射 / 商户是否开通等都是「某商户 × 某游戏」的配置态，归各消费页自己的 data.ts，不进池。
//
// 接线状态（2026-07-15）：已接 **2 处**，均属总控端游戏管理——
//   ① game/maintain 弹窗「子游戏维护」态（搜索+分页复选网格）＝首个消费者
//   ② game/game（商户游戏管理）弹窗「查看子游戏」＝第二个消费者
// ②接线前自带一份 8 家厂商的私有小表（VENDOR_INFO/GAME_NAME_POOL），码是老的全大写且做了 toUpperCase()，
// 池子改用源站码（EVO_Video/Card365/MG_Fish…混合大小写）后 **43 家里 39 家匹配不上、掉进「游戏一/游戏二」兜底**。
// 这正是「各页各造各的」必然分叉的活样本，接池后消灭。其余 4 处消费方分属其它窗口、仍未接线（避让 R15 并发）。
// 各页接线时：import { subgamesByVendor } from '@/config/gameSubgamePool' 取身份，自己叠加状态字段。

export interface GameSubgameDef {
  /** 子游戏编码（全局唯一，各端一致） */
  code: string;
  /**
   * 厂商侧游戏编码 —— 源站列表「游戏编码」列显示的就是它（如 CQ9 的 1 / 10 / 1010 / 102）。
   * 与 code 不是一回事：code 是 V3 自定的全局唯一键，本字段是厂商自家的短码、**跨厂商不唯一**
   * （两家厂商都可能有编码 1），故不能拿来当 key。仅有实采证据的厂商才填，其余留空由消费页回落 code。
   */
  vendorGameCode?: string;
  /** 游戏ID（数字，列表展示/搜索用） */
  gameId: number;
  /** 游戏名称(中文) */
  zh: string;
  /** 游戏名称(英文) */
  en: string;
  /** 所属厂商编码 —— 必须是 gameVendorPool 里的 code */
  vendorCode: string;
  /** 游戏大类：code，对齐 gameMainTypePool（slots/lottery/sports/casino/pvc/fishing/mini/chess/live） */
  categoryType: string;
  /** 游戏子类（厂商侧细分，如 Slot / Baccarat / WinGo） */
  subType: string;
  /** RTP 返奖率 */
  rtp: string;
}

// 229 款 / 各家款数有意不均（大厂 8~10 款、中小厂 5 款、单品厂 1~3 款），数据多样化 R32。
// categoryType 与所属厂商在 gameVendorPool 里的 categoryType 保持一致。
// 覆盖全部 12 个主类型；hot / featured / recommend 三类 2026-07-17 各补 5 款
//   （「选择游戏」级联补全·用户需求 B：让这三类的 HOT/FEA/REC 厂商下不再是空叶子）。
// 只有 CQ9 这 9 款是源站实采（用户截图），其余各家仍是编的 —— 拿不到实采就不假装有（R45）。
export const GAME_SUBGAME_POOL: GameSubgameDef[] = [
  // ── CQ9电子（slots）· 9 款**全部按源站实采**（用户 2026-07-15 截图，见 R45 口径）
  // 原 10 款（跳高高/鸿福齐天/雷神之锤/发财神…）系编造，与源站零重合，已整段替换。
  // gameId 随之由 100001~100010 变为 **100000~100008**（源站真值，起点是 0 不是 1）。
  // 源站第 10 行被截图截断、看不清 → **不编**，CQ9 就收在 9 款（池子 100→99，仍是 2 页、不影响 maintain 分页）。
  { code: 'CQ9_001', gameId: 100000, zh: '钻石水果王', en: 'FruitKing', vendorGameCode: '1', vendorCode: 'CQ9', categoryType: 'slots', subType: 'Slot', rtp: '96.50%' },
  { code: 'CQ9_002', gameId: 100001, zh: '五福临门', en: 'LuckyBats', vendorGameCode: '10', vendorCode: 'CQ9', categoryType: 'slots', subType: 'Slot', rtp: '95.80%' },
  { code: 'CQ9_003', gameId: 100002, zh: '五福临门JP', en: 'LuckyBatsJP', vendorGameCode: '1010', vendorCode: 'CQ9', categoryType: 'slots', subType: 'Slot', rtp: '97.20%' },
  { code: 'CQ9_004', gameId: 100003, zh: '水果派对', en: 'Fruity Carnival', vendorGameCode: '102', vendorCode: 'CQ9', categoryType: 'slots', subType: 'Slot', rtp: '94.60%' },
  { code: 'CQ9_005', gameId: 100004, zh: '宝石配对', en: 'Jewel Luxury', vendorGameCode: '103', vendorCode: 'CQ9', categoryType: 'slots', subType: 'Slot', rtp: '96.10%' },
  { code: 'CQ9_006', gameId: 100005, zh: '海滨消消乐', en: 'Chicky Parm Parm', vendorGameCode: '104', vendorCode: 'CQ9', categoryType: 'slots', subType: 'Slot', rtp: '95.40%' },
  { code: 'CQ9_007', gameId: 100006, zh: '单手跳高高', en: 'Jumping Mobile', vendorGameCode: '105', vendorCode: 'CQ9', categoryType: 'slots', subType: 'Slot', rtp: '96.80%' },
  { code: 'CQ9_008', gameId: 100007, zh: '赚金蛋JP', en: 'GoldenEggsJP', vendorGameCode: '1067', vendorCode: 'CQ9', categoryType: 'slots', subType: 'Slot', rtp: '97.00%' },
  { code: 'CQ9_009', gameId: 100008, zh: '聚宝盆JP', en: 'TreasureBowlJP', vendorGameCode: '1074', vendorCode: 'CQ9', categoryType: 'slots', subType: 'Slot', rtp: '94.90%' },
  // ── PP电子（slots）
  { code: 'PP_001', gameId: 100011, zh: '甜蜜之旅', en: 'Sweet Bonanza', vendorCode: 'PP', categoryType: 'slots', subType: 'Slot', rtp: '96.50%' },
  { code: 'PP_002', gameId: 100012, zh: '狂野西部', en: 'Wild West Gold', vendorCode: 'PP', categoryType: 'slots', subType: 'Slot', rtp: '96.50%' },
  { code: 'PP_003', gameId: 100013, zh: '黄金列车', en: 'Gold Train', vendorCode: 'PP', categoryType: 'slots', subType: 'Slot', rtp: '95.90%' },
  { code: 'PP_004', gameId: 100014, zh: '宙斯闪电', en: 'Gates of Olympus', vendorCode: 'PP', categoryType: 'slots', subType: 'Slot', rtp: '96.50%' },
  // ── JILI电子（slots）
  { code: 'JILI_001', gameId: 100021, zh: '超级王牌', en: 'Super Ace', vendorCode: 'JILI', categoryType: 'slots', subType: 'Slot', rtp: '97.00%' },
  { code: 'JILI_002', gameId: 100022, zh: '幸运女神', en: 'Lucky Goddess', vendorCode: 'JILI', categoryType: 'slots', subType: 'Slot', rtp: '96.20%' },
  { code: 'JILI_003', gameId: 100023, zh: '金色帝国', en: 'Golden Empire', vendorCode: 'JILI', categoryType: 'slots', subType: 'Slot', rtp: '95.50%' },
  { code: 'JILI_004', gameId: 100024, zh: '龙之传奇', en: 'Dragon Legend', vendorCode: 'JILI', categoryType: 'slots', subType: 'Slot', rtp: '96.80%' },
  // ── PG电子（slots）
  { code: 'PG_001', gameId: 100031, zh: '麻将胡了', en: 'Mahjong Ways', vendorCode: 'PG', categoryType: 'slots', subType: 'Slot', rtp: '96.90%' },
  { code: 'PG_002', gameId: 100032, zh: '赏金船长', en: 'Captain Bounty', vendorCode: 'PG', categoryType: 'slots', subType: 'Slot', rtp: '96.70%' },
  { code: 'PG_003', gameId: 100033, zh: '寻龙记', en: 'Dragon Hatch', vendorCode: 'PG', categoryType: 'slots', subType: 'Slot', rtp: '96.70%' },
  { code: 'PG_004', gameId: 100034, zh: '冰雪女王', en: 'Ice Queen', vendorCode: 'PG', categoryType: 'slots', subType: 'Slot', rtp: '96.50%' },
  // ── EVO视讯（casino）· 码 EVO→EVO_Video 对齐源站
  { code: 'EVO_Video_001', gameId: 100041, zh: '经典百家乐', en: 'Classic Baccarat', vendorCode: 'EVO_Video', categoryType: 'casino', subType: 'Baccarat', rtp: '98.90%' },
  { code: 'EVO_Video_002', gameId: 100042, zh: '极速轮盘', en: 'Speed Roulette', vendorCode: 'EVO_Video', categoryType: 'casino', subType: 'Roulette', rtp: '97.30%' },
  { code: 'EVO_Video_003', gameId: 100043, zh: '疯狂时间', en: 'Crazy Time', vendorCode: 'EVO_Video', categoryType: 'casino', subType: 'GameShow', rtp: '96.10%' },
  { code: 'EVO_Video_004', gameId: 100044, zh: '龙虎斗', en: 'Dragon Tiger', vendorCode: 'EVO_Video', categoryType: 'casino', subType: 'DragonTiger', rtp: '96.30%' },
  // ── AG视讯（casino）· 码 AG→AG_Video 对齐源站
  { code: 'AG_Video_001', gameId: 100051, zh: 'VIP百家乐', en: 'VIP Baccarat', vendorCode: 'AG_Video', categoryType: 'casino', subType: 'Baccarat', rtp: '98.80%' },
  { code: 'AG_Video_002', gameId: 100052, zh: '经典轮盘', en: 'Classic Roulette', vendorCode: 'AG_Video', categoryType: 'casino', subType: 'Roulette', rtp: '97.30%' },
  { code: 'AG_Video_003', gameId: 100053, zh: '牛牛', en: 'Niu Niu', vendorCode: 'AG_Video', categoryType: 'casino', subType: 'NiuNiu', rtp: '96.50%' },
  { code: 'AG_Video_004', gameId: 100054, zh: '骰宝', en: 'Sic Bo', vendorCode: 'AG_Video', categoryType: 'casino', subType: 'SicBo', rtp: '97.20%' },
  // ── 棋牌（chess）· 原挂 KM棋牌(源站无此厂商)，2026-07-15 改挂 365棋牌 / V8棋牌 / KoolBet棋牌
  { code: 'Card365_001', gameId: 100061, zh: '德州扑克', en: 'Texas Holdem', vendorCode: 'Card365', categoryType: 'chess', subType: 'Poker', rtp: '97.50%' },
  { code: 'Card365_002', gameId: 100062, zh: '斗地主', en: 'Landlord', vendorCode: 'Card365', categoryType: 'chess', subType: 'Poker', rtp: '96.80%' },
  { code: 'V8Card_003', gameId: 100063, zh: '十三水', en: 'Thirteen', vendorCode: 'V8Card', categoryType: 'chess', subType: 'Poker', rtp: '96.40%' },
  { code: 'V8Card_004', gameId: 100064, zh: '炸金花', en: 'Golden Flower', vendorCode: 'V8Card', categoryType: 'chess', subType: 'Poker', rtp: '96.90%' },
  // ── 体育（sports）· 原挂 IBC体育(源站无此厂商)，2026-07-15 改挂 CMD / IM / SaBa / 9Wickets / ARBET
  { code: 'CMD_001', gameId: 100071, zh: '足球滚球', en: 'Football Live', vendorCode: 'CMD', categoryType: 'sports', subType: 'Football', rtp: '94.50%' },
  { code: 'IM_002', gameId: 100072, zh: '篮球早盘', en: 'Basketball Early', vendorCode: 'IM', categoryType: 'sports', subType: 'Basketball', rtp: '94.80%' },
  { code: 'SaBa_003', gameId: 100073, zh: '网球赛事', en: 'Tennis Match', vendorCode: 'SaBa', categoryType: 'sports', subType: 'Tennis', rtp: '94.20%' },
  { code: 'Wickets9_004', gameId: 100074, zh: '串关投注', en: 'Parlay', vendorCode: 'Wickets9', categoryType: 'sports', subType: 'Parlay', rtp: '93.50%' },
  // ── 彩票（lottery）· 原挂 GPI彩票(源站无此厂商)，2026-07-15 改挂 AR彩票(源站唯一彩票厂商)
  { code: 'ARLottery_001', gameId: 100081, zh: 'WinGo 1分钟', en: 'WinGo 1min', vendorCode: 'ARLottery', categoryType: 'lottery', subType: 'WinGo', rtp: '98.00%' },
  { code: 'ARLottery_002', gameId: 100082, zh: 'K3 3分钟', en: 'K3 3min', vendorCode: 'ARLottery', categoryType: 'lottery', subType: 'K3', rtp: '97.80%' },
  { code: 'ARLottery_003', gameId: 100083, zh: '5D 5分钟', en: '5D 5min', vendorCode: 'ARLottery', categoryType: 'lottery', subType: '5D', rtp: '97.50%' },
  { code: 'ARLottery_004', gameId: 100084, zh: 'TrxWinGo 1分钟', en: 'TrxWinGo 1min', vendorCode: 'ARLottery', categoryType: 'lottery', subType: 'WinGo', rtp: '98.20%' },
  // ── TF电竞（pvc）· **唯一保留的非源站厂商**：源站无电竞厂商，删了 pvc 大类会空（用户选方案 B）
  { code: 'TF_001', gameId: 100091, zh: '英雄联盟', en: 'League of Legends', vendorCode: 'TF', categoryType: 'pvc', subType: 'ESports', rtp: '95.00%' },
  { code: 'TF_002', gameId: 100092, zh: 'CS2赛事', en: 'CS2 Match', vendorCode: 'TF', categoryType: 'pvc', subType: 'ESports', rtp: '94.70%' },
  { code: 'TF_003', gameId: 100093, zh: 'DOTA2赛事', en: 'DOTA2 Match', vendorCode: 'TF', categoryType: 'pvc', subType: 'ESports', rtp: '94.90%' },
  { code: 'TF_004', gameId: 100094, zh: '王者荣耀', en: 'Honor of Kings', vendorCode: 'TF', categoryType: 'pvc', subType: 'ESports', rtp: '95.20%' },
  // ── 捕鱼（fishing）· 原挂 BG捕鱼(源站无此厂商)，2026-07-15 改挂 MG捕鱼(源站唯一捕鱼厂商)
  { code: 'MG_Fish_001', gameId: 100101, zh: '金蟾捕鱼', en: 'Golden Toad Fishing', vendorCode: 'MG_Fish', categoryType: 'fishing', subType: 'Fishing', rtp: '96.00%' },
  { code: 'MG_Fish_002', gameId: 100102, zh: '深海狩猎', en: 'Deep Sea Hunt', vendorCode: 'MG_Fish', categoryType: 'fishing', subType: 'Fishing', rtp: '96.30%' },
  { code: 'MG_Fish_003', gameId: 100103, zh: '龙王捕鱼', en: 'Dragon King Fishing', vendorCode: 'MG_Fish', categoryType: 'fishing', subType: 'Fishing', rtp: '95.80%' },
  { code: 'MG_Fish_004', gameId: 100104, zh: '雷霆战警', en: 'Thunder Fishing', vendorCode: 'MG_Fish', categoryType: 'fishing', subType: 'Fishing', rtp: '96.10%' },
  // ── 小游戏（mini）· 原挂 SPB小游戏(源站无此厂商)，2026-07-15 改挂 SPRIBE电子 / TB电子
  { code: 'SPRIBE_001', gameId: 100111, zh: '飞行家', en: 'Aviator', vendorCode: 'SPRIBE', categoryType: 'mini', subType: 'Crash', rtp: '97.00%' },
  { code: 'SPRIBE_002', gameId: 100112, zh: '扫雷', en: 'Mines', vendorCode: 'SPRIBE', categoryType: 'mini', subType: 'Mines', rtp: '97.00%' },
  { code: 'SPRIBE_003', gameId: 100113, zh: '骰子', en: 'Dice', vendorCode: 'SPRIBE', categoryType: 'mini', subType: 'Dice', rtp: '97.30%' },
  { code: 'SPRIBE_004', gameId: 100114, zh: '迷你轮盘', en: 'Mini Roulette', vendorCode: 'SPRIBE', categoryType: 'mini', subType: 'MiniRoulette', rtp: '97.30%' },
  // ── SEXY视讯（live）· 码 SEXY→SEXY_Video 对齐源站
  { code: 'SEXY_Video_001', gameId: 100121, zh: '真人百家乐', en: 'Live Baccarat', vendorCode: 'SEXY_Video', categoryType: 'live', subType: 'Baccarat', rtp: '98.80%' },
  { code: 'SEXY_Video_002', gameId: 100122, zh: '真人轮盘', en: 'Live Roulette', vendorCode: 'SEXY_Video', categoryType: 'live', subType: 'Roulette', rtp: '97.30%' },
  { code: 'SEXY_Video_003', gameId: 100123, zh: '真人骰宝', en: 'Live Sic Bo', vendorCode: 'SEXY_Video', categoryType: 'live', subType: 'SicBo', rtp: '97.20%' },
  { code: 'SEXY_Video_004', gameId: 100124, zh: '真人龙虎', en: 'Live Dragon Tiger', vendorCode: 'SEXY_Video', categoryType: 'live', subType: 'DragonTiger', rtp: '96.30%' },

  // ══════ 2026-07-15 扩容 52 → 100 款 ══════
  // 起因：游戏维护管理弹窗「子游戏维护」态照源站截图做成「搜索 + 分页复选网格」，每页 50；
  // 源站真实总数 5576（112 页），V3 原 52 款不足 2 页、分页形同虚设。用户定「不用全部补，补 2 页即可」
  // → 补到 100 款正好 2 页。各家款数**有意不均**（大厂 10 款 / 小厂 5 款），贴近真实且满足 R32 数据多样化。
  // gameId 沿用原规则：每家占一个 10 号段（PP=100011~100020、JILI=100021~100030…），未越段。
  // CQ9 的 6 款编造扩容已于 2026-07-15 随实采替换一并删除（见上方 CQ9 段）——
  // 那 6 款与源站零重合，留着就是把编的数据混进实采里。CQ9 现为 9 款实采、占 100000~100008。
  // ── PP电子（slots）+6 → 共 10
  { code: 'PP_005', gameId: 100015, zh: '狗屋巨额', en: 'The Dog House Megaways', vendorCode: 'PP', categoryType: 'slots', subType: 'Slot', rtp: '96.60%' },
  { code: 'PP_006', gameId: 100016, zh: '星光公主', en: 'Starlight Princess', vendorCode: 'PP', categoryType: 'slots', subType: 'Slot', rtp: '96.50%' },
  { code: 'PP_007', gameId: 100017, zh: '糖果派对', en: 'Sugar Rush', vendorCode: 'PP', categoryType: 'slots', subType: 'Slot', rtp: '96.50%' },
  { code: 'PP_008', gameId: 100018, zh: '寻宝黄金城', en: 'John Hunter', vendorCode: 'PP', categoryType: 'slots', subType: 'Slot', rtp: '96.20%' },
  { code: 'PP_009', gameId: 100019, zh: '火焰之链', en: 'Fire Strike', vendorCode: 'PP', categoryType: 'slots', subType: 'Slot', rtp: '96.50%' },
  { code: 'PP_010', gameId: 100020, zh: '大力神之力', en: 'Power of Thor', vendorCode: 'PP', categoryType: 'slots', subType: 'Slot', rtp: '96.50%' },
  // ── JILI电子（slots）+6 → 共 10
  { code: 'JILI_005', gameId: 100025, zh: '好运来', en: 'Fortune Coming', vendorCode: 'JILI', categoryType: 'slots', subType: 'Slot', rtp: '96.40%' },
  { code: 'JILI_006', gameId: 100026, zh: '疯狂777', en: 'Crazy 777', vendorCode: 'JILI', categoryType: 'slots', subType: 'Slot', rtp: '95.70%' },
  { code: 'JILI_007', gameId: 100027, zh: '爆财神', en: 'Boom Fortune', vendorCode: 'JILI', categoryType: 'slots', subType: 'Slot', rtp: '96.90%' },
  { code: 'JILI_008', gameId: 100028, zh: '魔法灯', en: 'Magic Lamp', vendorCode: 'JILI', categoryType: 'slots', subType: 'Slot', rtp: '96.10%' },
  { code: 'JILI_009', gameId: 100029, zh: '招财童子', en: 'Lucky Boy', vendorCode: 'JILI', categoryType: 'slots', subType: 'Slot', rtp: '95.80%' },
  { code: 'JILI_010', gameId: 100030, zh: '水果狂欢', en: 'Fruit Carnival', vendorCode: 'JILI', categoryType: 'slots', subType: 'Slot', rtp: '96.60%' },
  // ── PG电子（slots）+6 → 共 10
  { code: 'PG_005', gameId: 100035, zh: '麻将胡了2', en: 'Mahjong Ways 2', vendorCode: 'PG', categoryType: 'slots', subType: 'Slot', rtp: '96.95%' },
  { code: 'PG_006', gameId: 100036, zh: '福运象财神', en: 'Ganesha Fortune', vendorCode: 'PG', categoryType: 'slots', subType: 'Slot', rtp: '96.70%' },
  { code: 'PG_007', gameId: 100037, zh: '开心农场', en: 'Jungle Delight', vendorCode: 'PG', categoryType: 'slots', subType: 'Slot', rtp: '96.60%' },
  { code: 'PG_008', gameId: 100038, zh: '糖果大爆炸', en: 'Candy Burst', vendorCode: 'PG', categoryType: 'slots', subType: 'Slot', rtp: '96.71%' },
  { code: 'PG_009', gameId: 100039, zh: '双囍临门', en: 'Double Fortune', vendorCode: 'PG', categoryType: 'slots', subType: 'Slot', rtp: '96.72%' },
  { code: 'PG_010', gameId: 100040, zh: '爵士俱乐部', en: 'Jazz Club', vendorCode: 'PG', categoryType: 'slots', subType: 'Slot', rtp: '96.50%' },
  // ── EVO视讯（casino）· 码 EVO→EVO_Video 对齐源站+4 → 共 8
  { code: 'EVO_Video_005', gameId: 100045, zh: '无限21点', en: 'Infinite Blackjack', vendorCode: 'EVO_Video', categoryType: 'casino', subType: 'Blackjack', rtp: '99.50%' },
  { code: 'EVO_Video_006', gameId: 100046, zh: '梦幻轮盘', en: 'Dream Catcher', vendorCode: 'EVO_Video', categoryType: 'casino', subType: 'GameShow', rtp: '96.60%' },
  { code: 'EVO_Video_007', gameId: 100047, zh: '闪电骰宝', en: 'Lightning Dice', vendorCode: 'EVO_Video', categoryType: 'casino', subType: 'SicBo', rtp: '96.20%' },
  { code: 'EVO_Video_008', gameId: 100048, zh: '免佣百家乐', en: 'No Commission Baccarat', vendorCode: 'EVO_Video', categoryType: 'casino', subType: 'Baccarat', rtp: '98.76%' },
  // ── AG视讯（casino）· 码 AG→AG_Video 对齐源站+4 → 共 8
  { code: 'AG_Video_005', gameId: 100055, zh: '竞咪百家乐', en: 'Competitive Baccarat', vendorCode: 'AG_Video', categoryType: 'casino', subType: 'Baccarat', rtp: '98.70%' },
  { code: 'AG_Video_006', gameId: 100056, zh: 'AG极速轮盘', en: 'AG Speed Roulette', vendorCode: 'AG_Video', categoryType: 'casino', subType: 'Roulette', rtp: '97.30%' },
  { code: 'AG_Video_007', gameId: 100057, zh: '21点', en: 'Blackjack', vendorCode: 'AG_Video', categoryType: 'casino', subType: 'Blackjack', rtp: '99.40%' },
  { code: 'AG_Video_008', gameId: 100058, zh: '红黑大战', en: 'Red Black War', vendorCode: 'AG_Video', categoryType: 'casino', subType: 'DragonTiger', rtp: '96.40%' },
  // ── 棋牌（chess）· 原挂 KM棋牌(源站无此厂商)，2026-07-15 改挂 365棋牌 / V8棋牌 / KoolBet棋牌+2 → 共 6
  { code: 'KoolBet_005', gameId: 100065, zh: '二八杠', en: 'Er Ba Gang', vendorCode: 'KoolBet', categoryType: 'chess', subType: 'Poker', rtp: '96.60%' },
  { code: 'KoolBet_006', gameId: 100066, zh: '麻将', en: 'Mahjong', vendorCode: 'KoolBet', categoryType: 'chess', subType: 'Mahjong', rtp: '97.10%' },
  // ── 体育（sports）· 原挂 IBC体育(源站无此厂商)，2026-07-15 改挂 CMD / IM / SaBa / 9Wickets / ARBET+2 → 共 6
  { code: 'Wickets9_005', gameId: 100075, zh: '板球赛事', en: 'Cricket Match', vendorCode: 'Wickets9', categoryType: 'sports', subType: 'Cricket', rtp: '94.60%' },
  { code: 'ARBET_006', gameId: 100076, zh: '羽毛球赛事', en: 'Badminton Match', vendorCode: 'ARBET', categoryType: 'sports', subType: 'Badminton', rtp: '94.30%' },
  // ── 彩票（lottery）· 原挂 GPI彩票(源站无此厂商)，2026-07-15 改挂 AR彩票(源站唯一彩票厂商)+4 → 共 8
  { code: 'ARLottery_005', gameId: 100085, zh: 'WinGo 3分钟', en: 'WinGo 3min', vendorCode: 'ARLottery', categoryType: 'lottery', subType: 'WinGo', rtp: '98.00%' },
  { code: 'ARLottery_006', gameId: 100086, zh: 'K3 1分钟', en: 'K3 1min', vendorCode: 'ARLottery', categoryType: 'lottery', subType: 'K3', rtp: '97.80%' },
  { code: 'ARLottery_007', gameId: 100087, zh: '5D 1分钟', en: '5D 1min', vendorCode: 'ARLottery', categoryType: 'lottery', subType: '5D', rtp: '97.50%' },
  { code: 'ARLottery_008', gameId: 100088, zh: 'TrxWinGo 5分钟', en: 'TrxWinGo 5min', vendorCode: 'ARLottery', categoryType: 'lottery', subType: 'WinGo', rtp: '98.20%' },
  // ── TF电竞（pvc）· **唯一保留的非源站厂商**：源站无电竞厂商，删了 pvc 大类会空（用户选方案 B）+1 → 共 5
  { code: 'TF_005', gameId: 100095, zh: '守望先锋', en: 'Overwatch', vendorCode: 'TF', categoryType: 'pvc', subType: 'ESports', rtp: '94.80%' },
  // ── 捕鱼（fishing）· 原挂 BG捕鱼(源站无此厂商)，2026-07-15 改挂 MG捕鱼(源站唯一捕鱼厂商)+2 → 共 6
  { code: 'MG_Fish_005', gameId: 100105, zh: '街机捕鱼', en: 'Arcade Fishing', vendorCode: 'MG_Fish', categoryType: 'fishing', subType: 'Fishing', rtp: '96.20%' },
  { code: 'MG_Fish_006', gameId: 100106, zh: '海王捕鱼', en: 'Ocean King', vendorCode: 'MG_Fish', categoryType: 'fishing', subType: 'Fishing', rtp: '95.90%' },
  // ── 小游戏（mini）· 原挂 SPB小游戏(源站无此厂商)，2026-07-15 改挂 SPRIBE电子 / TB电子+3 → 共 7
  { code: 'TB_Chess_005', gameId: 100115, zh: '掷骰塔', en: 'Dice Tower', vendorCode: 'TB_Chess', categoryType: 'mini', subType: 'Dice', rtp: '97.10%' },
  { code: 'TB_Chess_006', gameId: 100116, zh: '足球爆破', en: 'Goal Blast', vendorCode: 'TB_Chess', categoryType: 'mini', subType: 'Crash', rtp: '97.00%' },
  { code: 'TB_Chess_007', gameId: 100117, zh: '石头剪刀布', en: 'Rock Paper Scissors', vendorCode: 'TB_Chess', categoryType: 'mini', subType: 'Mini', rtp: '96.80%' },
  // ── SEXY视讯（live）· 码 SEXY→SEXY_Video 对齐源站+2 → 共 6
  { code: 'SEXY_Video_005', gameId: 100125, zh: '真人牛牛', en: 'Live Niu Niu', vendorCode: 'SEXY_Video', categoryType: 'live', subType: 'NiuNiu', rtp: '96.50%' },
  { code: 'SEXY_Video_006', gameId: 100126, zh: '真人炸金花', en: 'Live Golden Flower', vendorCode: 'SEXY_Video', categoryType: 'live', subType: 'Poker', rtp: '96.70%' },

  // ══════════════════════════════════════════════════════════════════════════════
  // 2026-07-15 · 补齐「有厂商、无子游戏」的 23 家（用户拍板）
  //
  // 起因：厂商池 v1.7.0 由 13 家扩到源站真实 42 家时，子游戏池没跟上——这 23 家一款游戏都没有。
  // 此前看不出来，是因为总控端「查看子游戏」弹窗的旧 mock 匹配不上就吐「游戏一~游戏六」假数据兜着；
  // 该弹窗本次接池后兜底消失，23 家立刻现形为空表，而 v1.7.6 的「绑定商户」恰好能绑全部厂商。
  //
  // 每家 5 款（少于原有大厂的 8~10 款，因这批多是中小/代理接入厂商），大类严格随其在
  // gameVendorPool 里的 categoryType；gameId 沿用「每家一个 10 号段」规则，本批占 100131~100355。
  // 游戏名按各家真实调性取（SPRIBE 系＝Crash/Mines 类小游戏、视讯厂商＝真人桌台、JDB 系＝捕鱼+电子），
  // 不复用别家名字，避免搜索时一个关键词跨厂商命中一片（R32 数据多样化）。
  //
  // ⚠️ 仍空的 3 个大类：hot / featured / recommend —— 别的窗口 2026-07-15 14:44 往厂商池加了
  // HOT/FEA/REC 三个「破例厂商」（源站无对应厂商，为免大类筛选空列表），但没补子游戏。
  // 本窗口**有意不补**：「热门/精选/推荐」不是真厂商，其下该挂的是**从各厂商挑出来的游戏引用**，
  // 而非 5 款独家新游戏——造「热门游戏一~五」是错的建模。归属加它们的窗口，需先定建模再补。
  // ══════════════════════════════════════════════════════════════════════════════

  // ── AG电子（slots）
  { code: 'AG_Electronic_001', gameId: 100131, zh: '黄金之路', en: 'Golden Road', vendorCode: 'AG_Electronic', categoryType: 'slots', subType: 'Slot', rtp: '96.20%' },
  { code: 'AG_Electronic_002', gameId: 100132, zh: '五虎将', en: 'Five Tigers', vendorCode: 'AG_Electronic', categoryType: 'slots', subType: 'Slot', rtp: '95.60%' },
  { code: 'AG_Electronic_003', gameId: 100133, zh: '连环夺宝', en: 'Treasure Chain', vendorCode: 'AG_Electronic', categoryType: 'slots', subType: 'Slot', rtp: '97.10%' },
  { code: 'AG_Electronic_004', gameId: 100134, zh: '孙悟空', en: 'Monkey King', vendorCode: 'AG_Electronic', categoryType: 'slots', subType: 'Slot', rtp: '94.80%' },
  { code: 'AG_Electronic_005', gameId: 100135, zh: '幸运锦鲤', en: 'Lucky Koi', vendorCode: 'AG_Electronic', categoryType: 'slots', subType: 'Slot', rtp: '96.40%' },
  // ── ART电子（slots）· 自营厂商
  { code: 'ART_001', gameId: 100141, zh: '极速快车', en: 'Turbo Racer', vendorCode: 'ART', categoryType: 'slots', subType: 'Slot', rtp: '96.00%' },
  { code: 'ART_002', gameId: 100142, zh: '霓虹之夜', en: 'Neon Nights', vendorCode: 'ART', categoryType: 'slots', subType: 'Slot', rtp: '95.30%' },
  { code: 'ART_003', gameId: 100143, zh: '沙漠寻宝', en: 'Desert Treasure', vendorCode: 'ART', categoryType: 'slots', subType: 'Slot', rtp: '97.40%' },
  { code: 'ART_004', gameId: 100144, zh: '狂欢节', en: 'Carnival Fever', vendorCode: 'ART', categoryType: 'slots', subType: 'Slot', rtp: '96.60%' },
  { code: 'ART_005', gameId: 100145, zh: '海底王国', en: 'Ocean Kingdom', vendorCode: 'ART', categoryType: 'slots', subType: 'Slot', rtp: '94.50%' },
  // ── BGAMING电子（slots）
  { code: 'BGAMING_001', gameId: 100151, zh: '猫王青蛙', en: 'Elvis Frog', vendorCode: 'BGAMING', categoryType: 'slots', subType: 'Slot', rtp: '96.00%' },
  { code: 'BGAMING_002', gameId: 100152, zh: '疯狂矿工', en: 'Crazy Miner', vendorCode: 'BGAMING', categoryType: 'slots', subType: 'Slot', rtp: '96.80%' },
  { code: 'BGAMING_003', gameId: 100153, zh: '甜蜜炸弹', en: 'Candy Bomb', vendorCode: 'BGAMING', categoryType: 'slots', subType: 'Slot', rtp: '95.10%' },
  { code: 'BGAMING_004', gameId: 100154, zh: '阿罗哈国王', en: 'Aloha King', vendorCode: 'BGAMING', categoryType: 'slots', subType: 'Slot', rtp: '97.30%' },
  { code: 'BGAMING_005', gameId: 100155, zh: '太空巨鲸', en: 'Space Whale', vendorCode: 'BGAMING', categoryType: 'slots', subType: 'Slot', rtp: '94.90%' },
  // ── BOAN-INOUT电子（slots）
  { code: 'BOAN_INOUT_001', gameId: 100161, zh: '雷霆万钧', en: 'Thunder Strike', vendorCode: 'BOAN_INOUT', categoryType: 'slots', subType: 'Slot', rtp: '96.30%' },
  { code: 'BOAN_INOUT_002', gameId: 100162, zh: '青龙出海', en: 'Azure Dragon', vendorCode: 'BOAN_INOUT', categoryType: 'slots', subType: 'Slot', rtp: '95.70%' },
  { code: 'BOAN_INOUT_003', gameId: 100163, zh: '摩天大楼', en: 'Skyscraper', vendorCode: 'BOAN_INOUT', categoryType: 'slots', subType: 'Slot', rtp: '97.00%' },
  { code: 'BOAN_INOUT_004', gameId: 100164, zh: '玛雅金字塔', en: 'Maya Pyramid', vendorCode: 'BOAN_INOUT', categoryType: 'slots', subType: 'Slot', rtp: '94.70%' },
  { code: 'BOAN_INOUT_005', gameId: 100165, zh: '烈焰凤凰', en: 'Blazing Phoenix', vendorCode: 'BOAN_INOUT', categoryType: 'slots', subType: 'Slot', rtp: '96.90%' },
  // ── BOAN-SPRIBE电子（mini）· SPRIBE 系＝Crash/Mines 类小游戏
  { code: 'BOAN_SPRIBE_001', gameId: 100171, zh: '飞行棋', en: 'Aviator Boan', vendorCode: 'BOAN_SPRIBE', categoryType: 'mini', subType: 'Crash', rtp: '97.00%' },
  { code: 'BOAN_SPRIBE_002', gameId: 100172, zh: '扫雷高手', en: 'Mines Master', vendorCode: 'BOAN_SPRIBE', categoryType: 'mini', subType: 'Mines', rtp: '96.50%' },
  { code: 'BOAN_SPRIBE_003', gameId: 100173, zh: '骰子快打', en: 'Dice Rush', vendorCode: 'BOAN_SPRIBE', categoryType: 'mini', subType: 'Dice', rtp: '98.00%' },
  { code: 'BOAN_SPRIBE_004', gameId: 100174, zh: '弹珠台', en: 'Plinko Drop', vendorCode: 'BOAN_SPRIBE', categoryType: 'mini', subType: 'Plinko', rtp: '97.50%' },
  { code: 'BOAN_SPRIBE_005', gameId: 100175, zh: '极限攀升', en: 'Limbo Climb', vendorCode: 'BOAN_SPRIBE', categoryType: 'mini', subType: 'Limbo', rtp: '96.20%' },
  // ── DG视讯（live）· 真人桌台
  { code: 'DG_Video_001', gameId: 100181, zh: 'DG经典百家乐', en: 'DG Classic Baccarat', vendorCode: 'DG_Video', categoryType: 'live', subType: 'Baccarat', rtp: '98.80%' },
  { code: 'DG_Video_002', gameId: 100182, zh: 'DG免佣百家乐', en: 'DG No Commission Baccarat', vendorCode: 'DG_Video', categoryType: 'live', subType: 'Baccarat', rtp: '98.90%' },
  { code: 'DG_Video_003', gameId: 100183, zh: 'DG欧式轮盘', en: 'DG European Roulette', vendorCode: 'DG_Video', categoryType: 'live', subType: 'Roulette', rtp: '97.30%' },
  { code: 'DG_Video_004', gameId: 100184, zh: 'DG龙虎斗', en: 'DG Dragon Tiger', vendorCode: 'DG_Video', categoryType: 'live', subType: 'DragonTiger', rtp: '96.30%' },
  { code: 'DG_Video_005', gameId: 100185, zh: 'DG幸运骰宝', en: 'DG Lucky Sic Bo', vendorCode: 'DG_Video', categoryType: 'live', subType: 'SicBo', rtp: '97.20%' },
  // ── EVO电子（slots）· 与 EVO视讯(EVO_Video) 是两家，勿混
  { code: 'EVO_Electronic_001', gameId: 100191, zh: '雷神传说', en: 'Thunder Legend', vendorCode: 'EVO_Electronic', categoryType: 'slots', subType: 'Slot', rtp: '96.10%' },
  { code: 'EVO_Electronic_002', gameId: 100192, zh: '海盗宝藏', en: 'Pirate Treasure', vendorCode: 'EVO_Electronic', categoryType: 'slots', subType: 'Slot', rtp: '95.40%' },
  { code: 'EVO_Electronic_003', gameId: 100193, zh: '丛林狂舞', en: 'Jungle Dance', vendorCode: 'EVO_Electronic', categoryType: 'slots', subType: 'Slot', rtp: '97.20%' },
  { code: 'EVO_Electronic_004', gameId: 100194, zh: '冰川时代', en: 'Ice Age Rush', vendorCode: 'EVO_Electronic', categoryType: 'slots', subType: 'Slot', rtp: '94.60%' },
  { code: 'EVO_Electronic_005', gameId: 100195, zh: '黄金矿工', en: 'Gold Digger', vendorCode: 'EVO_Electronic', categoryType: 'slots', subType: 'Slot', rtp: '96.70%' },
  // ── 9G电子（slots）
  { code: '9G_001', gameId: 100201, zh: '九龙至尊', en: 'Nine Dragons', vendorCode: '9G', categoryType: 'slots', subType: 'Slot', rtp: '96.50%' },
  { code: '9G_002', gameId: 100202, zh: '财神驾到', en: 'God of Wealth', vendorCode: '9G', categoryType: 'slots', subType: 'Slot', rtp: '95.90%' },
  { code: '9G_003', gameId: 100203, zh: '福星高照', en: 'Lucky Star Shine', vendorCode: '9G', categoryType: 'slots', subType: 'Slot', rtp: '97.10%' },
  { code: '9G_004', gameId: 100204, zh: '爆金水果', en: 'Fruit Blast', vendorCode: '9G', categoryType: 'slots', subType: 'Slot', rtp: '94.40%' },
  { code: '9G_005', gameId: 100205, zh: '金猪送福', en: 'Fortune Pig', vendorCode: '9G', categoryType: 'slots', subType: 'Slot', rtp: '96.80%' },
  // ── GameBox电子（slots）
  { code: 'GameBox_001', gameId: 100211, zh: '像素冒险', en: 'Pixel Quest', vendorCode: 'GameBox', categoryType: 'slots', subType: 'Slot', rtp: '96.00%' },
  { code: 'GameBox_002', gameId: 100212, zh: '街机之王', en: 'Arcade King', vendorCode: 'GameBox', categoryType: 'slots', subType: 'Slot', rtp: '95.50%' },
  { code: 'GameBox_003', gameId: 100213, zh: '糖果盒子', en: 'Candy Box', vendorCode: 'GameBox', categoryType: 'slots', subType: 'Slot', rtp: '97.30%' },
  { code: 'GameBox_004', gameId: 100214, zh: '机甲战士', en: 'Mecha Fighter', vendorCode: 'GameBox', categoryType: 'slots', subType: 'Slot', rtp: '94.90%' },
  { code: 'GameBox_005', gameId: 100215, zh: '魔法书', en: 'Book of Magic', vendorCode: 'GameBox', categoryType: 'slots', subType: 'Slot', rtp: '96.60%' },
  // ── 黑豹-JDB电子（slots）· 黑豹系＝经黑豹代理接入的同名厂商，游戏与直连版不完全相同
  { code: 'HeiBao_JDB_001', gameId: 100221, zh: '黑豹百鬼夜行', en: 'HB Ghost Night', vendorCode: 'HeiBao_JDB', categoryType: 'slots', subType: 'Slot', rtp: '96.20%' },
  { code: 'HeiBao_JDB_002', gameId: 100222, zh: '黑豹龙王传说', en: 'HB Dragon King Legend', vendorCode: 'HeiBao_JDB', categoryType: 'slots', subType: 'Slot', rtp: '95.80%' },
  { code: 'HeiBao_JDB_003', gameId: 100223, zh: '黑豹财神到', en: 'HB Caishen Arrives', vendorCode: 'HeiBao_JDB', categoryType: 'slots', subType: 'Slot', rtp: '97.00%' },
  { code: 'HeiBao_JDB_004', gameId: 100224, zh: '黑豹三倍金刚', en: 'HB Triple Kong', vendorCode: 'HeiBao_JDB', categoryType: 'slots', subType: 'Slot', rtp: '94.70%' },
  { code: 'HeiBao_JDB_005', gameId: 100225, zh: '黑豹芝麻开门', en: 'HB Open Sesame', vendorCode: 'HeiBao_JDB', categoryType: 'slots', subType: 'Slot', rtp: '96.90%' },
  // ── 黑豹-JILI电子（slots）
  { code: 'HeiBao_JILI_001', gameId: 100231, zh: '黑豹超级王牌', en: 'HB Super Ace', vendorCode: 'HeiBao_JILI', categoryType: 'slots', subType: 'Slot', rtp: '96.40%' },
  { code: 'HeiBao_JILI_002', gameId: 100232, zh: '黑豹金色帝国', en: 'HB Golden Empire', vendorCode: 'HeiBao_JILI', categoryType: 'slots', subType: 'Slot', rtp: '95.20%' },
  { code: 'HeiBao_JILI_003', gameId: 100233, zh: '黑豹幸运女神', en: 'HB Lucky Goddess', vendorCode: 'HeiBao_JILI', categoryType: 'slots', subType: 'Slot', rtp: '97.40%' },
  { code: 'HeiBao_JILI_004', gameId: 100234, zh: '黑豹狂野公牛', en: 'HB Wild Bull', vendorCode: 'HeiBao_JILI', categoryType: 'slots', subType: 'Slot', rtp: '94.30%' },
  { code: 'HeiBao_JILI_005', gameId: 100235, zh: '黑豹钱来也', en: 'HB Money Coming', vendorCode: 'HeiBao_JILI', categoryType: 'slots', subType: 'Slot', rtp: '96.10%' },
  // ── 黑豹-PG电子（slots）
  { code: 'HeiBao_PG_001', gameId: 100241, zh: '黑豹麻将胡了', en: 'HB Mahjong Ways', vendorCode: 'HeiBao_PG', categoryType: 'slots', subType: 'Slot', rtp: '96.70%' },
  { code: 'HeiBao_PG_002', gameId: 100242, zh: '黑豹赏金船长', en: 'HB Captain Bounty', vendorCode: 'HeiBao_PG', categoryType: 'slots', subType: 'Slot', rtp: '95.60%' },
  { code: 'HeiBao_PG_003', gameId: 100243, zh: '黑豹寻龙记', en: 'HB Dragon Hatch', vendorCode: 'HeiBao_PG', categoryType: 'slots', subType: 'Slot', rtp: '97.20%' },
  { code: 'HeiBao_PG_004', gameId: 100244, zh: '黑豹开心农场', en: 'HB Jolly Farm', vendorCode: 'HeiBao_PG', categoryType: 'slots', subType: 'Slot', rtp: '94.80%' },
  { code: 'HeiBao_PG_005', gameId: 100245, zh: '黑豹双龙戏珠', en: 'HB Double Dragons', vendorCode: 'HeiBao_PG', categoryType: 'slots', subType: 'Slot', rtp: '96.30%' },
  // ── 黑豹-PP电子（slots）
  { code: 'HeiBao_PP_001', gameId: 100251, zh: '黑豹甜蜜之旅', en: 'HB Sweet Bonanza', vendorCode: 'HeiBao_PP', categoryType: 'slots', subType: 'Slot', rtp: '96.50%' },
  { code: 'HeiBao_PP_002', gameId: 100252, zh: '黑豹宙斯闪电', en: 'HB Gates of Olympus', vendorCode: 'HeiBao_PP', categoryType: 'slots', subType: 'Slot', rtp: '95.90%' },
  { code: 'HeiBao_PP_003', gameId: 100253, zh: '黑豹狂野西部', en: 'HB Wild West Gold', vendorCode: 'HeiBao_PP', categoryType: 'slots', subType: 'Slot', rtp: '97.10%' },
  { code: 'HeiBao_PP_004', gameId: 100254, zh: '黑豹星光公主', en: 'HB Starlight Princess', vendorCode: 'HeiBao_PP', categoryType: 'slots', subType: 'Slot', rtp: '94.60%' },
  { code: 'HeiBao_PP_005', gameId: 100255, zh: '黑豹糖果派对', en: 'HB Sugar Rush', vendorCode: 'HeiBao_PP', categoryType: 'slots', subType: 'Slot', rtp: '96.80%' },
  // ── 黑豹-SPRIBE电子（mini）
  { code: 'HeiBao_SPRIBE_001', gameId: 100261, zh: '黑豹飞行棋', en: 'HB Aviator', vendorCode: 'HeiBao_SPRIBE', categoryType: 'mini', subType: 'Crash', rtp: '97.00%' },
  { code: 'HeiBao_SPRIBE_002', gameId: 100262, zh: '黑豹扫雷', en: 'HB Mines', vendorCode: 'HeiBao_SPRIBE', categoryType: 'mini', subType: 'Mines', rtp: '96.60%' },
  { code: 'HeiBao_SPRIBE_003', gameId: 100263, zh: '黑豹骰子', en: 'HB Dice', vendorCode: 'HeiBao_SPRIBE', categoryType: 'mini', subType: 'Dice', rtp: '98.00%' },
  { code: 'HeiBao_SPRIBE_004', gameId: 100264, zh: '黑豹足球射门', en: 'HB Goal', vendorCode: 'HeiBao_SPRIBE', categoryType: 'mini', subType: 'Goal', rtp: '96.90%' },
  { code: 'HeiBao_SPRIBE_005', gameId: 100265, zh: '黑豹轮盘赌', en: 'HB Mini Roulette', vendorCode: 'HeiBao_SPRIBE', categoryType: 'mini', subType: 'Mini', rtp: '97.30%' },
  // ── INOUT电子（slots）
  { code: 'INOUT_001', gameId: 100271, zh: '金库大盗', en: 'Vault Heist', vendorCode: 'INOUT', categoryType: 'slots', subType: 'Slot', rtp: '96.10%' },
  { code: 'INOUT_002', gameId: 100272, zh: '午夜马戏团', en: 'Midnight Circus', vendorCode: 'INOUT', categoryType: 'slots', subType: 'Slot', rtp: '95.30%' },
  { code: 'INOUT_003', gameId: 100273, zh: '狂野牛仔', en: 'Wild Cowboy', vendorCode: 'INOUT', categoryType: 'slots', subType: 'Slot', rtp: '97.50%' },
  { code: 'INOUT_004', gameId: 100274, zh: '深海探险', en: 'Deep Sea Quest', vendorCode: 'INOUT', categoryType: 'slots', subType: 'Slot', rtp: '94.20%' },
  { code: 'INOUT_005', gameId: 100275, zh: '罗马角斗士', en: 'Roman Gladiator', vendorCode: 'INOUT', categoryType: 'slots', subType: 'Slot', rtp: '96.40%' },
  // ── JDB电子（slots）· 直连版，与黑豹-JDB 是两家
  { code: 'JDB_001', gameId: 100281, zh: '龙王争霸', en: 'Dragon King Battle', vendorCode: 'JDB', categoryType: 'slots', subType: 'Slot', rtp: '96.30%' },
  { code: 'JDB_002', gameId: 100282, zh: '爆金777', en: 'Blast 777', vendorCode: 'JDB', categoryType: 'slots', subType: 'Slot', rtp: '95.70%' },
  { code: 'JDB_003', gameId: 100283, zh: '幸运熊猫', en: 'Lucky Panda', vendorCode: 'JDB', categoryType: 'slots', subType: 'Slot', rtp: '97.20%' },
  { code: 'JDB_004', gameId: 100284, zh: '拉斯维加斯', en: 'Las Vegas Night', vendorCode: 'JDB', categoryType: 'slots', subType: 'Slot', rtp: '94.50%' },
  { code: 'JDB_005', gameId: 100285, zh: '黄金屋', en: 'Golden House', vendorCode: 'JDB', categoryType: 'slots', subType: 'Slot', rtp: '96.90%' },
  // ── KB电子（slots）
  { code: 'KB_001', gameId: 100291, zh: '皇家宝石', en: 'Royal Gems', vendorCode: 'KB', categoryType: 'slots', subType: 'Slot', rtp: '96.00%' },
  { code: 'KB_002', gameId: 100292, zh: '疯狂七', en: 'Crazy Seven', vendorCode: 'KB', categoryType: 'slots', subType: 'Slot', rtp: '95.80%' },
  { code: 'KB_003', gameId: 100293, zh: '印加古城', en: 'Inca City', vendorCode: 'KB', categoryType: 'slots', subType: 'Slot', rtp: '97.40%' },
  { code: 'KB_004', gameId: 100294, zh: '甜心教主', en: 'Sweet Idol', vendorCode: 'KB', categoryType: 'slots', subType: 'Slot', rtp: '94.60%' },
  { code: 'KB_005', gameId: 100295, zh: '雷电风暴', en: 'Lightning Storm', vendorCode: 'KB', categoryType: 'slots', subType: 'Slot', rtp: '96.70%' },
  // ── MG电子（slots）· 与 MG捕鱼(MG_Fish) / MG视讯(MG_Video) 是三家
  { code: 'MG_001', gameId: 100301, zh: '超级月亮', en: 'Mega Moon', vendorCode: 'MG', categoryType: 'slots', subType: 'Slot', rtp: '96.60%' },
  { code: 'MG_002', gameId: 100302, zh: '不朽情缘', en: 'Immortal Love', vendorCode: 'MG', categoryType: 'slots', subType: 'Slot', rtp: '96.90%' },
  { code: 'MG_003', gameId: 100303, zh: '非洲之心', en: 'Heart of Africa', vendorCode: 'MG', categoryType: 'slots', subType: 'Slot', rtp: '95.10%' },
  { code: 'MG_004', gameId: 100304, zh: '雷神之光', en: 'Thunder Light', vendorCode: 'MG', categoryType: 'slots', subType: 'Slot', rtp: '97.30%' },
  { code: 'MG_005', gameId: 100305, zh: '宝石之星', en: 'Star Gems', vendorCode: 'MG', categoryType: 'slots', subType: 'Slot', rtp: '94.40%' },
  // ── MG视讯（casino）
  { code: 'MG_Video_001', gameId: 100311, zh: 'MG百家乐', en: 'MG Baccarat', vendorCode: 'MG_Video', categoryType: 'casino', subType: 'Baccarat', rtp: '98.90%' },
  { code: 'MG_Video_002', gameId: 100312, zh: 'MG轮盘', en: 'MG Roulette', vendorCode: 'MG_Video', categoryType: 'casino', subType: 'Roulette', rtp: '97.30%' },
  { code: 'MG_Video_003', gameId: 100313, zh: 'MG二十一点', en: 'MG Blackjack', vendorCode: 'MG_Video', categoryType: 'casino', subType: 'Blackjack', rtp: '99.50%' },
  { code: 'MG_Video_004', gameId: 100314, zh: 'MG骰宝', en: 'MG Sic Bo', vendorCode: 'MG_Video', categoryType: 'casino', subType: 'SicBo', rtp: '97.20%' },
  { code: 'MG_Video_005', gameId: 100315, zh: 'MG龙虎', en: 'MG Dragon Tiger', vendorCode: 'MG_Video', categoryType: 'casino', subType: 'DragonTiger', rtp: '96.30%' },
  // ── NG电子（slots）
  { code: 'NG_001', gameId: 100321, zh: '霓虹赛车', en: 'Neon Racer', vendorCode: 'NG', categoryType: 'slots', subType: 'Slot', rtp: '96.20%' },
  { code: 'NG_002', gameId: 100322, zh: '北欧诸神', en: 'Nordic Gods', vendorCode: 'NG', categoryType: 'slots', subType: 'Slot', rtp: '95.50%' },
  { code: 'NG_003', gameId: 100323, zh: '幻想森林', en: 'Fantasy Forest', vendorCode: 'NG', categoryType: 'slots', subType: 'Slot', rtp: '97.10%' },
  { code: 'NG_004', gameId: 100324, zh: '钻石矿脉', en: 'Diamond Vein', vendorCode: 'NG', categoryType: 'slots', subType: 'Slot', rtp: '94.70%' },
  { code: 'NG_005', gameId: 100325, zh: '狂欢派对', en: 'Party Mania', vendorCode: 'NG', categoryType: 'slots', subType: 'Slot', rtp: '96.50%' },
  // ── TURBO电子（slots）
  { code: 'TURBO_001', gameId: 100331, zh: '涡轮增压', en: 'Turbo Boost', vendorCode: 'TURBO', categoryType: 'slots', subType: 'Slot', rtp: '96.80%' },
  { code: 'TURBO_002', gameId: 100332, zh: '飙速漂移', en: 'Drift Rush', vendorCode: 'TURBO', categoryType: 'slots', subType: 'Slot', rtp: '95.20%' },
  { code: 'TURBO_003', gameId: 100333, zh: '闪电狂飙', en: 'Lightning Dash', vendorCode: 'TURBO', categoryType: 'slots', subType: 'Slot', rtp: '97.60%' },
  { code: 'TURBO_004', gameId: 100334, zh: '极速赢家', en: 'Speed Winner', vendorCode: 'TURBO', categoryType: 'slots', subType: 'Slot', rtp: '94.30%' },
  { code: 'TURBO_005', gameId: 100335, zh: '引擎轰鸣', en: 'Engine Roar', vendorCode: 'TURBO', categoryType: 'slots', subType: 'Slot', rtp: '96.10%' },
  // ── UP电子（slots）
  { code: 'UP_001', gameId: 100341, zh: '步步高升', en: 'Step Up', vendorCode: 'UP', categoryType: 'slots', subType: 'Slot', rtp: '96.40%' },
  { code: 'UP_002', gameId: 100342, zh: '云端城堡', en: 'Cloud Castle', vendorCode: 'UP', categoryType: 'slots', subType: 'Slot', rtp: '95.60%' },
  { code: 'UP_003', gameId: 100343, zh: '热气球之旅', en: 'Balloon Journey', vendorCode: 'UP', categoryType: 'slots', subType: 'Slot', rtp: '97.00%' },
  { code: 'UP_004', gameId: 100344, zh: '登月计划', en: 'Moon Mission', vendorCode: 'UP', categoryType: 'slots', subType: 'Slot', rtp: '94.80%' },
  { code: 'UP_005', gameId: 100345, zh: '巅峰对决', en: 'Peak Showdown', vendorCode: 'UP', categoryType: 'slots', subType: 'Slot', rtp: '96.30%' },
  // ── WM视讯（live）
  { code: 'WM_Video_001', gameId: 100351, zh: 'WM百家乐', en: 'WM Baccarat', vendorCode: 'WM_Video', categoryType: 'live', subType: 'Baccarat', rtp: '98.80%' },
  { code: 'WM_Video_002', gameId: 100352, zh: 'WM竞咪百家乐', en: 'WM Squeeze Baccarat', vendorCode: 'WM_Video', categoryType: 'live', subType: 'Baccarat', rtp: '98.90%' },
  { code: 'WM_Video_003', gameId: 100353, zh: 'WM轮盘', en: 'WM Roulette', vendorCode: 'WM_Video', categoryType: 'live', subType: 'Roulette', rtp: '97.30%' },
  { code: 'WM_Video_004', gameId: 100354, zh: 'WM骰宝', en: 'WM Sic Bo', vendorCode: 'WM_Video', categoryType: 'live', subType: 'SicBo', rtp: '97.20%' },
  { code: 'WM_Video_005', gameId: 100355, zh: 'WM牛牛', en: 'WM Niu Niu', vendorCode: 'WM_Video', categoryType: 'live', subType: 'NiuNiu', rtp: '96.50%' },
  // ── HOT热门（hot）· 2026-07-17 补（选择游戏级联补全 B）：热门聚合类，收录各厂人气游戏
  { code: 'HOT_001', gameId: 100401, zh: '火爆777', en: 'Blazing 777', vendorCode: 'HOT', categoryType: 'hot', subType: 'Slot', rtp: '96.50%' },
  { code: 'HOT_002', gameId: 100402, zh: '疯狂麻将', en: 'Crazy Mahjong', vendorCode: 'HOT', categoryType: 'hot', subType: 'Slot', rtp: '96.20%' },
  { code: 'HOT_003', gameId: 100403, zh: '招财喵', en: 'Lucky Neko', vendorCode: 'HOT', categoryType: 'hot', subType: 'Slot', rtp: '96.80%' },
  { code: 'HOT_004', gameId: 100404, zh: '金龙报喜', en: 'Golden Dragon', vendorCode: 'HOT', categoryType: 'hot', subType: 'Slot', rtp: '95.90%' },
  { code: 'HOT_005', gameId: 100405, zh: '爆金水果', en: 'Fruit Blast', vendorCode: 'HOT', categoryType: 'hot', subType: 'Slot', rtp: '96.10%' },
  // ── FEA精选（featured）· 2026-07-17 补：精选聚合类
  { code: 'FEA_001', gameId: 100411, zh: '甜蜜风暴', en: 'Sweet Storm', vendorCode: 'FEA', categoryType: 'featured', subType: 'Slot', rtp: '96.40%' },
  { code: 'FEA_002', gameId: 100412, zh: '奥林匹斯之门', en: 'Gates of Olympus', vendorCode: 'FEA', categoryType: 'featured', subType: 'Slot', rtp: '96.50%' },
  { code: 'FEA_003', gameId: 100413, zh: '寻宝黄金城', en: 'Treasure City', vendorCode: 'FEA', categoryType: 'featured', subType: 'Slot', rtp: '96.00%' },
  { code: 'FEA_004', gameId: 100414, zh: '精选百家乐', en: 'Featured Baccarat', vendorCode: 'FEA', categoryType: 'featured', subType: 'Baccarat', rtp: '98.80%' },
  { code: 'FEA_005', gameId: 100415, zh: '幸运转轮', en: 'Lucky Wheel', vendorCode: 'FEA', categoryType: 'featured', subType: 'GameShow', rtp: '95.70%' },
  // ── REC推荐（recommend）· 2026-07-17 补：推荐聚合类
  { code: 'REC_001', gameId: 100421, zh: '荒野赏金', en: 'Wild Bounty', vendorCode: 'REC', categoryType: 'recommend', subType: 'Slot', rtp: '96.30%' },
  { code: 'REC_002', gameId: 100422, zh: '财神传奇', en: 'Fortune Tiger', vendorCode: 'REC', categoryType: 'recommend', subType: 'Slot', rtp: '96.70%' },
  { code: 'REC_003', gameId: 100423, zh: '五行八卦', en: 'Five Elements', vendorCode: 'REC', categoryType: 'recommend', subType: 'Slot', rtp: '96.20%' },
  { code: 'REC_004', gameId: 100424, zh: '极速飞车', en: 'Turbo Racer', vendorCode: 'REC', categoryType: 'recommend', subType: 'Arcade', rtp: '96.90%' },
  { code: 'REC_005', gameId: 100425, zh: '推荐足球', en: 'Recommended Football', vendorCode: 'REC', categoryType: 'recommend', subType: 'Sports', rtp: '95.50%' },
];

/** 编码 → 子游戏定义，供各端 O(1) 取身份 */
export const GAME_SUBGAME_MAP: Record<string, GameSubgameDef> = Object.fromEntries(
  GAME_SUBGAME_POOL.map((g) => [g.code, g]),
);

/** 游戏ID → 子游戏定义（列表/搜索按 ID 命中用） */
export const GAME_SUBGAME_BY_ID: Record<number, GameSubgameDef> = Object.fromEntries(
  GAME_SUBGAME_POOL.map((g) => [g.gameId, g]),
);

/** 取某厂商下的全部子游戏（厂商编码对齐 gameVendorPool） */
export function subgamesByVendor(vendorCode: string): GameSubgameDef[] {
  const code = String(vendorCode ?? '').trim();
  if (!code) return [];
  return GAME_SUBGAME_POOL.filter((g) => g.vendorCode === code);
}

/** 取某主类型下的全部子游戏（主类型 code 对齐 gameMainTypePool） */
export function subgamesByMainType(categoryType: string): GameSubgameDef[] {
  const code = String(categoryType ?? '').trim();
  if (!code) return [];
  return GAME_SUBGAME_POOL.filter((g) => g.categoryType === code);
}

/** 显示：code/gameId → 「中文（英文）」；查不到回退原值 */
export function subgameLabel(input: string | number): string {
  const def = GAME_SUBGAME_MAP[String(input)] ?? GAME_SUBGAME_BY_ID[Number(input)];
  return def ? `${def.zh}（${def.en}）` : String(input ?? '');
}

/** 选项：label=中文（英文），value=code；传 vendorCode 则只取该厂商下的（挂靠/筛选用） */
export function subgameOptions(vendorCode?: string): { label: string; value: string }[] {
  const list = vendorCode ? subgamesByVendor(vendorCode) : GAME_SUBGAME_POOL;
  return list.map((g) => ({ label: `${g.zh}（${g.en}）`, value: g.code }));
}
