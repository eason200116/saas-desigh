// 全站商户名单（集团 › 商户两层）—— 唯一真源。
//
// 【为什么建这个文件】原先这份数据是 src/api/index.ts 里 createApiProxy() 内的局部常量
// TENANT_ORG_SELECT_LIST，**函数作用域、导不出来** → 想用同一批商户的页面只能各自另抄一份，
// 于是出现了 config/gameMerchantList.ts 那份自造的 4 家（阿尔法娱乐/贝塔平台/伽马体育/德尔塔电竞，
// id 1001~1004），与全站真实商户（daman/91club… id 1050/1048…）**ID 与名称双双对不上** ——
// 同一个「商户」概念在游戏版块和其余版块是两套人马。
// 现把数据提到本 config 当真源，api/index.ts 反过来 import 它对外服务（organizationGetSelectList），
// 需要商户名单的页面一律从这里取，**不再各造一份**（造第二份必分叉）。
//
// 数据从 src/api/index.ts 原样搬来（2026-07-15），未增删改任何一条：4 个集团 / 16 家商户。
// 消费方：
//   · src/api/index.ts → tenantOverride.organizationGetSelectList（useTenantOptions / 全站商户下拉的数据来源）
//   · src/config/gameMerchantList.ts → 游戏版块各页的商户名单

export interface MerchantDef {
  /** 商户ID（全站唯一，与全站商户下拉、各页 mock 的 merchantId / tenantId 同源） */
  id: number;
  /** 商户名 */
  name: string;
}

export interface MerchantOrgDef {
  /** 集团ID */
  id: number;
  /** 集团名 */
  name: string;
  /** 该集团下的商户 */
  tenantList: MerchantDef[];
}

/** 集团 › 商户 两层名单（api/index.ts 的 organizationGetSelectList 直接返回本结构） */
export const MERCHANT_ORG_LIST: MerchantOrgDef[] = [
  {
    id: 1001,
    name: '亚太集团',
    tenantList: [
      { id: 1050, name: 'daman' },
      { id: 1048, name: '91club' },
      { id: 1052, name: 'fun88' },
      { id: 1054, name: 'jeetwin' },
    ],
  },
  {
    id: 1002,
    name: '南亚集团',
    tenantList: [
      { id: 1021, name: '55club' },
      { id: 1040, name: 'ugame' },
      { id: 1038, name: 'pop888' },
      { id: 1042, name: 'betbra' },
    ],
  },
  {
    id: 1003,
    name: '东南亚集团',
    tenantList: [
      { id: 1070, name: 'bdggame' },
      { id: 1090, name: 'tirgame' },
      { id: 1030, name: 'thaifortune' },
      { id: 1036, name: 'vn168' },
      { id: 1072, name: 'thaiwin' },
    ],
  },
  {
    id: 1004,
    name: '欧美集团',
    tenantList: [
      { id: 1080, name: 'euroking' },
      { id: 1082, name: 'vegas88' },
      { id: 1099, name: 'globalbet' },
    ],
  },
];

/** 拍平的全量商户名单（16 家，跨集团） */
export const MERCHANT_LIST: MerchantDef[] = MERCHANT_ORG_LIST.flatMap((o) => o.tenantList);

/** id → 商户 映射 */
export const MERCHANT_MAP: Record<number, MerchantDef> = Object.fromEntries(
  MERCHANT_LIST.map((m) => [m.id, m]),
);

/** 商户ID → 商户名（查不到回落原ID字符串，不吞值） */
export function merchantName(id: number): string {
  return MERCHANT_MAP[id]?.name ?? String(id ?? '');
}

/** 该集团下的商户选项（select 下拉用，集团→商户级联联动）；查无该集团则回退全量商户（不落空表 R32）。 */
export function merchantOptionsForGroup(
  orgId?: number | string | null,
): Array<{ label: string; value: number }> {
  const org = MERCHANT_ORG_LIST.find((o) => o.id === Number(orgId));
  const list = org?.tenantList ?? MERCHANT_LIST;
  return list.map((m) => ({ label: m.name, value: m.id }));
}
