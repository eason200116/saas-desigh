// 游戏语言 / 币种池 —— 唯一真源，供「厂商支持语言 / 支持币种」展示与筛选使用。
//
// 【数据来源 · 实证】1:1 取自 SIT 源站镜像
//   sit-admin-mirror/game-platform-vendor-mgmt.html
//     · L410 const LANG_NAME={en:'en-English(英语)', ...}  → 14 种语言
//     · L409 const CUR_NAME ={BDT:'BDT(塔卡)', ...}        → 14 种币种
//   中文名一律照抄源站叫法，未自行翻译（R45 不臆造 / R53 锚定实证）。
//   注意源站用词：id=「印度尼西亚语」（非"印尼语"）、zh=「中文简体」、zhw=「中文繁体」。
//
// 【为什么要有这个池】原先各页 data.ts 各自硬编 LANGUAGE_OPTIONS(6种) / CURRENCY_OPTIONS(4种)，
//   而 gameVendorPool 里实际用到 14 种语言 + 14 种币种 → 列表看得到 BDT/zhw、搜索下拉却筛不了。
//   本池覆盖全 14+14，选项由 vendorLanguageOptions()/vendorCurrencyOptions() 从厂商池实际值聚合生成。

import { GAME_VENDOR_POOL } from './gameVendorPool';

export interface GameLocaleDef {
  /** 编码（与 gameVendorPool 的 languageList / currencyList 元素一致） */
  code: string;
  /** 中文名（源站叫法） */
  zh: string;
  /** 源站完整标签（如 en-English(英语) / INR(印度卢比)），用于 tooltip / 映射配置类弹窗 */
  full: string;
}

/** 语言池（源站 LANG_NAME 原样） */
export const GAME_LANGUAGE_POOL: GameLocaleDef[] = [
  { code: 'en', zh: '英语', full: 'en-English(英语)' },
  { code: 'id', zh: '印度尼西亚语', full: 'id-Indonesian(印度尼西亚语)' },
  { code: 'pt', zh: '葡萄牙语', full: 'pt-Portuguese(葡萄牙语)' },
  { code: 'th', zh: '泰语', full: 'th-Thai(泰语)' },
  { code: 'vi', zh: '越南语', full: 'vi-Vietnamese(越南语)' },
  { code: 'zh', zh: '中文简体', full: 'zh-Chinese(中文简体)' },
  { code: 'zhw', zh: '中文繁体', full: 'zh-ChineseTW(中文繁体)' },
  { code: 'ar', zh: '阿拉伯语', full: 'ar-Arabic(阿拉伯语)' },
  { code: 'bn', zh: '孟加拉语', full: 'bn-Bengali(孟加拉语)' },
  { code: 'es', zh: '西班牙语', full: 'es-Spanish(西班牙语)' },
  { code: 'hi', zh: '印地语', full: 'hi-Hindi(印地语)' },
  { code: 'ms', zh: '马来语', full: 'ms-Malay(马来语)' },
  { code: 'my', zh: '缅甸语', full: 'my-Burmese(缅甸语)' },
  { code: 'ur', zh: '乌尔都语', full: 'ur-Urdu(乌尔都语)' },
];

/** 币种池（源站 CUR_NAME 原样；币种 zh 保留 ISO 码前缀，因 ISO 码本身即通用标识） */
export const GAME_CURRENCY_POOL: GameLocaleDef[] = [
  { code: 'BDT', zh: 'BDT(塔卡)', full: 'BDT(塔卡)' },
  { code: 'INR', zh: 'INR(印度卢比)', full: 'INR(印度卢比)' },
  { code: 'PKR', zh: 'PKR(巴基斯坦卢比)', full: 'PKR(巴基斯坦卢比)' },
  { code: 'VND', zh: 'VND(越南盾)', full: 'VND(越南盾)' },
  { code: 'BRL', zh: 'BRL(巴西雷亚尔)', full: 'BRL(巴西雷亚尔)' },
  { code: 'IDR', zh: 'IDR(印尼盾)', full: 'IDR(印尼盾)' },
  { code: 'MMK', zh: 'MMK(缅甸元)', full: 'MMK(缅甸元)' },
  { code: 'MXN', zh: 'MXN(墨西哥比索)', full: 'MXN(墨西哥比索)' },
  { code: 'THB', zh: 'THB(泰铢)', full: 'THB(泰铢)' },
  { code: 'CNY', zh: 'CNY(人民币)', full: 'CNY(人民币)' },
  { code: 'USD', zh: 'USD(美元)', full: 'USD(美元)' },
  { code: 'EGP', zh: 'EGP(埃及镑)', full: 'EGP(埃及镑)' },
  { code: 'MYR', zh: 'MYR(马来西亚林吉特)', full: 'MYR(马来西亚林吉特)' },
  { code: 'NGN', zh: 'NGN(尼日利亚奈拉)', full: 'NGN(尼日利亚奈拉)' },
];

const LANGUAGE_MAP = new Map(GAME_LANGUAGE_POOL.map((l) => [l.code, l]));
const CURRENCY_MAP = new Map(GAME_CURRENCY_POOL.map((c) => [c.code, c]));

/** 语言码 → 中文名（查不到回退原码，不吞值） */
export function languageLabel(code: string): string {
  return LANGUAGE_MAP.get(code)?.zh ?? code;
}

/** 语言码 → 源站完整标签（tooltip 用） */
export function languageFullLabel(code: string): string {
  return LANGUAGE_MAP.get(code)?.full ?? code;
}

/** 币种码 → 带中文注解标签（查不到回退原码） */
export function currencyLabel(code: string): string {
  return CURRENCY_MAP.get(code)?.zh ?? code;
}

/** 按池内既定次序排序（未收录的排最后、保持原相对序） */
function sortByPool(codes: string[], pool: GameLocaleDef[]): string[] {
  const order = new Map(pool.map((d, i) => [d.code, i]));
  return [...codes].sort(
    (a, b) => (order.get(a) ?? Number.MAX_SAFE_INTEGER) - (order.get(b) ?? Number.MAX_SAFE_INTEGER),
  );
}

/** 厂商池里实际出现过的语言 → 下拉项（label=中文名, value=码） */
export function vendorLanguageOptions(): { label: string; value: string }[] {
  const used = new Set<string>();
  GAME_VENDOR_POOL.forEach((v) => v.languageList.forEach((l) => used.add(l)));
  return sortByPool([...used], GAME_LANGUAGE_POOL).map((code) => ({
    label: languageLabel(code),
    value: code,
  }));
}

/** 厂商池里实际出现过的币种 → 下拉项（label=带中文注解, value=码） */
export function vendorCurrencyOptions(): { label: string; value: string }[] {
  const used = new Set<string>();
  GAME_VENDOR_POOL.forEach((v) => v.currencyList.forEach((c) => used.add(c)));
  return sortByPool([...used], GAME_CURRENCY_POOL).map((code) => ({
    label: currencyLabel(code),
    value: code,
  }));
}
