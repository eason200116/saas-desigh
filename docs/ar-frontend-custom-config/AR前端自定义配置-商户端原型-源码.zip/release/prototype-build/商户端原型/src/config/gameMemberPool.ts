// 游戏会员样例池 —— 总控端「游戏会员管理」版块（6 页）的共享会员/枚举真源。
//
// 为什么要有：该版块 6 页（会员管理 / 会员游戏账变 / 会员投注记录 / 会员上下分记录 /
// 三方上下分记录 / 策略明细）说的都是「同一批会员」的不同维度。若各页各造会员，
// 就会出现「会员管理里有 88012345、但他的投注记录里查无此人」的分叉。收敛到本池后，
// 各页的 mock 都从这批会员派生，跨页点同一个会员 ID 能对上（数据一致性 + R32 多样化）。
//
// 迁移自 SIT 总控端会员管理版块（sit-admin.wmgametransit.com）。真实会员 PII 不入库，
// 本池为自造脱敏样例（会员ID/商户会员ID/IP 均为编造），仅结构 1:1。
// 厂商/币种引用共享池（gameVendorPool / gameLocalePool），不另造。

import { GAME_VENDOR_POOL } from './gameVendorPool';
import { GAME_CURRENCY_POOL } from './gameLocalePool';

export interface GameMemberDef {
  /** 会员ID（平台唯一，长数字） */
  memberId: string;
  /** 商户会员ID（商户侧短号） */
  merchantMemberId: string;
  /** 所属商户名称 */
  merchantName: string;
  /** 商户编码（列表「商户名称」Tag 显示 merchantName，此为内部键） */
  merchantCode: string;
  /** 代理编码 */
  agentCode: string;
  /** 币种 code（对齐 gameLocalePool） */
  currency: string;
  /** 用户类型：0 正式会员 / 1 试玩会员 / 2 测试会员 */
  userType: 0 | 1 | 2;
  /** 注册 IP */
  registerIp: string;
  /** 注册时间 */
  registerTime: string;
  /** 最后登录时间 */
  lastLoginTime: string;
  /** 最后登录 IP */
  lastLoginIp: string;
}

// 12 条样例：币种覆盖 INR/BRL/VND/PKR/BDT；正式 7 / 试玩 3 / 测试 2（R32 多样）；
// 注册时间跨 2024~2026；余额/输赢由各消费页按 memberId 派生（不在池里存状态）。
// merchantMemberId 用**纯数字短号**（2026-07-17 用户拍板，1:1 照源站 /account/user 详情弹窗——
// 原为字母短号 vip888/lucky01…系迁移时臆造，源站实为 101254 这类数字）。6 页共用、同步生效。
export const GAME_MEMBER_POOL: GameMemberDef[] = [
  {
    memberId: '88012345',
    merchantMemberId: '101254',
    merchantName: 'sitINR',
    merchantCode: 'sitINR-2001',
    agentCode: 'AG-01',
    currency: 'INR',
    userType: 0,
    registerIp: '103.22.11.8',
    registerTime: '2024-07-27 11:29:50',
    lastLoginTime: '2026-07-10 10:15:22',
    lastLoginIp: '103.22.11.8',
  },
  {
    memberId: '88033456',
    merchantMemberId: '100377',
    merchantName: 'sitBRL',
    merchantCode: 'sitBRL-2003',
    agentCode: 'AG-03',
    currency: 'BRL',
    userType: 0,
    registerIp: '45.120.9.33',
    registerTime: '2026-03-05 16:38:40',
    lastLoginTime: '2026-07-09 18:40:10',
    lastLoginIp: '45.120.9.33',
  },
  {
    memberId: '88055012',
    merchantMemberId: '100892',
    merchantName: 'sitVND',
    merchantCode: 'sitVND-2007',
    agentCode: 'AG-02',
    currency: 'VND',
    userType: 1,
    registerIp: '88.201.4.7',
    registerTime: '2025-11-15 16:40:00',
    lastLoginTime: '2026-07-08 20:11:05',
    lastLoginIp: '88.201.4.7',
  },
  {
    memberId: '88077234',
    merchantMemberId: '101503',
    merchantName: 'sitPKR',
    merchantCode: 'sitPKR-2004',
    agentCode: 'AG-05',
    currency: 'PKR',
    userType: 0,
    registerIp: '172.16.0.9',
    registerTime: '2026-01-10 11:20:00',
    lastLoginTime: '2026-07-06 09:10:00',
    lastLoginIp: '172.16.0.9',
  },
  {
    memberId: '88090011',
    merchantMemberId: '100641',
    merchantName: 'sitBDT',
    merchantCode: 'sitBDT-2011',
    agentCode: 'AG-01',
    currency: 'BDT',
    userType: 0,
    registerIp: '58.97.156.20',
    registerTime: '2025-08-22 14:05:33',
    lastLoginTime: '2026-07-05 22:30:41',
    lastLoginIp: '58.97.156.20',
  },
  {
    memberId: '88102288',
    merchantMemberId: '102288',
    merchantName: 'sitINR',
    merchantCode: 'sitINR-2001',
    agentCode: 'AG-01',
    currency: 'INR',
    userType: 0,
    registerIp: '103.30.248.19',
    registerTime: '2026-06-30 17:31:03',
    lastLoginTime: '2026-07-15 10:56:51',
    lastLoginIp: '103.30.248.19',
  },
  {
    memberId: '88113399',
    merchantMemberId: '103399',
    merchantName: 'sitBRL',
    merchantCode: 'sitBRL-2003',
    agentCode: 'AG-03',
    currency: 'BRL',
    userType: 1,
    registerIp: '191.53.240.11',
    registerTime: '2026-05-18 09:12:47',
    lastLoginTime: '2026-07-02 13:22:08',
    lastLoginIp: '191.53.240.11',
  },
  {
    memberId: '88124400',
    merchantMemberId: '100244',
    merchantName: 'sitVND',
    merchantCode: 'sitVND-2007',
    agentCode: 'AG-04',
    currency: 'VND',
    userType: 0,
    registerIp: '113.161.7.220',
    registerTime: '2024-12-03 20:44:15',
    lastLoginTime: '2026-07-14 08:05:50',
    lastLoginIp: '113.161.7.220',
  },
  {
    memberId: '88135511',
    merchantMemberId: '101877',
    merchantName: 'sitPKR',
    merchantCode: 'sitPKR-2004',
    agentCode: 'AG-05',
    currency: 'PKR',
    userType: 2,
    registerIp: '39.60.10.44',
    registerTime: '2026-02-27 15:33:29',
    lastLoginTime: '2026-07-11 19:40:02',
    lastLoginIp: '39.60.10.44',
  },
  {
    memberId: '88146622',
    merchantMemberId: '100915',
    merchantName: 'sitINR',
    merchantCode: 'sitINR-2001',
    agentCode: 'AG-02',
    currency: 'INR',
    userType: 2,
    registerIp: '8.211.42.128',
    registerTime: '2026-06-24 13:53:18',
    lastLoginTime: '2026-07-01 16:35:30',
    lastLoginIp: '8.211.42.128',
  },
  {
    memberId: '88157733',
    merchantMemberId: '102733',
    merchantName: 'sitBRL',
    merchantCode: 'sitBRL-2003',
    agentCode: 'AG-03',
    currency: 'BRL',
    userType: 0,
    registerIp: '177.92.16.5',
    registerTime: '2025-09-30 11:08:52',
    lastLoginTime: '2026-07-13 21:15:33',
    lastLoginIp: '177.92.16.5',
  },
  {
    memberId: '88168844',
    merchantMemberId: '100468',
    merchantName: 'sitBDT',
    merchantCode: 'sitBDT-2011',
    agentCode: 'AG-01',
    currency: 'BDT',
    userType: 1,
    registerIp: '103.230.107.8',
    registerTime: '2026-04-11 10:20:19',
    lastLoginTime: '2026-07-04 07:50:12',
    lastLoginIp: '103.230.107.8',
  },
];

/** 商户下拉（单选，1:1 照源站；label 用商户名称、value 用商户编码） */
export const MEMBER_MERCHANT_OPTIONS = Array.from(
  new Map(
    GAME_MEMBER_POOL.map((m) => [m.merchantCode, { label: m.merchantName, value: m.merchantCode }]),
  ).values(),
);

/** 所属代理下拉（单选，1:1 照源站；源站商户名称右侧那格的第二个下拉，value=代理编码）。 */
export const MEMBER_AGENT_OPTIONS = Array.from(new Set(GAME_MEMBER_POOL.map((m) => m.agentCode)))
  .sort()
  .map((code) => ({ label: code, value: code }));

/**
 * 按商户编码派生「所属代理」下拉（商户→代理级联用）：只列该商户名下的代理；
 * 未传/传空则回退全部代理（与 MEMBER_AGENT_OPTIONS 同构）。会员账变页选商户后代理下拉据此过滤。
 * 2026-07-20 总-5：Eason 确认「所属代理」搜索筛选保留，仅删「代理编码」列/字段展示——
 * 存活 3 页 user/record/bet 已不显示 agentCode 列/详情，但搜索仍用本函数按代理筛选。
 */
export function agentOptionsForMerchant(merchantCode?: string | null) {
  const pool = merchantCode
    ? GAME_MEMBER_POOL.filter((m) => m.merchantCode === merchantCode)
    : GAME_MEMBER_POOL;
  return Array.from(new Set(pool.map((m) => m.agentCode)))
    .sort()
    .map((code) => ({ label: code, value: code }));
}

/** 通道下拉（三方上下分记录·源站游戏厂商右侧第二个下拉，厂商联动；mock 用扁平通道号）。 */
export const MEMBER_CHANNEL_OPTIONS = ['10001', '10002', '10003', '10004', '10005', '10006'].map(
  (c) => ({
    label: `通道${c}`,
    value: c,
  }),
);

/** 用户类型：0 正式 / 1 试玩 */
export const USER_TYPE_OPTIONS = [
  { label: '正式会员', value: 0 },
  { label: '试玩会员', value: 1 },
  { label: '测试会员', value: 2 },
];
export function userTypeLabel(v: number) {
  return v === 2 ? '测试会员' : v === 1 ? '试玩会员' : '正式会员';
}

/** 钱包类型（会员游戏账变）—— 1:1 照源站实采（2026-07-17 遍4 复核修正） */
export const WALLET_TYPE_OPTIONS = [
  { label: '主钱包', value: 'main' },
  { label: '策略钱包', value: 'strategy' },
];

/** 账变类型（会员游戏账变）—— 10 值 1:1 照源站下拉实采（2026-07-17 遍4 复核，原 4 值全错） */
export const RECORD_TYPE_OPTIONS = [
  { label: '商户转入(上分)', value: 'merchantIn' },
  { label: '商户转出(下分)', value: 'merchantOut' },
  { label: '商户转账退回', value: 'merchantRefund' },
  { label: '下注', value: 'bet' },
  { label: '结算', value: 'settle' },
  { label: '游戏上分', value: 'gameIn' },
  { label: '游戏下分', value: 'gameOut' },
  { label: '游戏扣款', value: 'gameDeduct' },
  { label: '游戏补款', value: 'gameCompensate' },
  { label: '游戏活动奖励', value: 'gameReward' },
];

/** 上下分·转账类型（transfer/thirdTransfer 共用）—— 1:1 照源站「转入(上分)/转出(下分)」（2026-07-17 遍4 修正措辞） */
export const TRANSFER_TYPE_OPTIONS = [
  { label: '转入(上分)', value: 'in' },
  { label: '转出(下分)', value: 'out' },
];

/**
 * 交易状态（transfer + thirdTransfer 共用）—— 1:1 照源站实采：成功 / 处理中 / 失败。
 * 2026-07-17 遍4 复核修正：两页下拉均为此三值，此前误把第三值当「回调超时」（不存在）、
 * 又一度把 transfer 砍成两值——均错。现统一三值。
 */
export const TRANSFER_STATE_OPTIONS = [
  { label: '成功', value: 'success' },
  { label: '处理中', value: 'processing' },
  { label: '失败', value: 'fail' },
];

/** 注单状态（会员投注记录）—— 7 值 1:1 照源站下拉实采（2026-07-17 遍4 复核，原 2 值不全） */
export const BET_STATE_OPTIONS = [
  { label: '未结算', value: 'unsettled' },
  { label: '已结算', value: 'settled' },
  { label: '已取消', value: 'cancelled' },
  { label: '已退款', value: 'refunded' },
  { label: '已作废', value: 'voided' },
  { label: '提前结算', value: 'earlySettled' },
  { label: '重新结算', value: 'resettled' },
];
/** 完成状态（会员投注记录）—— 3 值 1:1 照源站（2026-07-17 遍4 复核，原「已完成/进行中」错） */
export const BET_FINISH_OPTIONS = [
  { label: '未完成', value: 'incomplete' },
  { label: '已结算未完成', value: 'settledIncomplete' },
  { label: '已完成', value: 'completed' },
];

/** 供应商（会员投注记录·由厂商 provider 推导，此处列常见值） */
export const PROVIDER_OPTIONS = ['ZhiFeng', 'DengFeng', 'Official'];

/** 策略类型（策略明细） */
export const STRATEGY_OPTIONS = [
  { label: '对刷策略', value: 'brush' },
  { label: '跟投策略', value: 'follow' },
  { label: '对冲策略', value: 'hedge' },
];

/** 策略明细·子游戏（源站策略挂在彩票类子游戏上） */
export const STRATEGY_SUBGAME_OPTIONS = ['TRX Win', 'K3 快三', '5D 彩', 'Bingo18', 'WinGo 30s'];

/** 结束原因（策略明细） */
export const STRATEGY_END_REASON_OPTIONS = ['达到止盈', '手动结束', '进行中'];

/** 彩票限红分组（会员管理·设置用户彩票限红）：0 不限 + 限红组-1..8 */
export const LOTTERY_LIMIT_OPTIONS = [
  { label: '0', value: 0 },
  ...Array.from({ length: 8 }, (_, i) => ({ label: `限红组-${i + 1}`, value: i + 1 })),
];

/** 币种下拉（取共享币种池，只列本版块用到的） */
// 币种筛选下拉：列**全部 14 种**（2026-07-17 用户「币种补全」）。
// 原只放会员数据实际用到的 5 种(INR/BRL/VND/PKR/BDT)，导致列表见得到某币种、下拉却筛不了；
// 现直接取共享币种池全量，选项 ⊇ 数据（不是每种币都有会员，属正常）。
export const MEMBER_CURRENCY_OPTIONS = GAME_CURRENCY_POOL.map((c) => ({
  label: c.zh,
  value: c.code,
}));

/** 游戏厂商下拉（取共享厂商池，只列真有子游戏的） */
export const MEMBER_VENDOR_OPTIONS = GAME_VENDOR_POOL.map((v) => ({ label: v.zh, value: v.code }));
