// 商户展示配置池 —— 唯一真源，存「某商户的 C 端首页展示配置」。
//
// 【口径 · 与 gameMainTypePool/gameVendorPool/gameSubgamePool 一致】
//   三个池子只存"身份"（名称/编码/大类/RTP），本池只存"该商户挑了什么、怎么排、露不露"。
//   **绝不复制身份进来** —— 造第二份必分叉，本项目已因此踩坑两次（弹窗厂商码全兜底、商户名单两份）。
//
// 【分层】生效配置 = 总控层(三池 = 可用范围) ⊕ 商户层(本池 = 挑选/排序/显隐)
//   模型照搬 /Users/eason/v1/站点预览/index.html 已验证的 resolveConfig(商户) 架构。
//
// 【三层】大类(侧栏) → 厂商(宫格卡，挂在某大类下) → 游戏(二级页里该厂商露出的款)
//   层级实证自站点预览：games[分类] = 厂商卡数组；点厂商卡 → 二级页列该厂商的游戏。

import { BUILTIN_MAIN_TYPE_CODES } from './gameMainTypePool';
import { GAME_VENDOR_POOL } from './gameVendorPool';
import { subgamesByVendor } from './gameSubgamePool';
import { GAME_MERCHANT_LIST } from './gameMerchantList';

/** 第 1 层 · 侧栏大类（只存挑选，名称/图标现取 gameMainTypePool） */
export interface DisplayCategory {
  code: string; // → gameMainTypePool.code（策展大类为 sp_*/cust_* 自定义 code）
  visible: boolean;
  sort: number;
  aliasZh?: string; // 商户自定义展示名（不填 = 用池里的 zh）
  icon?: string; // 商户自定义图标（不填 = 用池里的）
  curation?: boolean; // 策展大类（推荐/热门/精选/自定义·2026-07-18）：不在游戏大类池，厂商/游戏取全平台全部
  removed?: boolean; // 墓碑（2026-07-18 item3 改「内置大类也要能删」）：内置/系统策展大类删除后保留条目但打此标记——
  //            buildCategoryRows/resolve 都排除、ensureSpecial 因条目仍在不再补 → 实现「删了不再出现」。自定义 cust_ 删除=直接移除、不用墓碑。
}

/** 第 2 层 · 某大类下的宫格厂商卡（只存挑选，名称现取 gameVendorPool） */
export interface DisplayVendor {
  categoryCode: string;
  vendorCode: string; // → gameVendorPool.code
  visible: boolean;
  sort: number;
  aliasZh?: string;
  icon?: string; // 按 spec §8「甲」案默认不填，卡面用统一底色
}

/** 第 3 层 · 某厂商下露出的游戏（只存挑选，名称现取 gameSubgamePool） */
export interface DisplayGame {
  vendorCode: string;
  gameId: number; // → gameSubgamePool.gameId
  visible: boolean;
  sort: number;
  alias?: string; // 商户自定义展示名（2026-07-18「编辑名称」；不填 = 用池里的 zh）
  icon?: string; // 商户自定义图标（2026-07-18「上传图片」dataURL；不填 = 用池图/兜底）
}

/** 「大类下直接游戏」（2026-07-18 用户定「跳过厂商、直接在大类配游戏」）：与厂商卡并存，
 *  游戏来自「该大类下所有厂商的游戏」拍平池；C 端在该大类里直接铺游戏卡（无厂商层）。 */
export interface DisplayCategoryGame {
  categoryCode: string; // → gameMainTypePool.code（挂在哪个大类下）
  gameId: number; // → gameSubgamePool.gameId
  visible: boolean;
  sort: number;
  alias?: string; // 商户自定义展示名（2026-07-18「编辑名称」）
  icon?: string; // 商户自定义图标（2026-07-18「上传图片」dataURL）
}

/** 首页版型模版（2026-07-18 用户定「首页预览 3 种常规模版选择」）：
 *  sidebar=左右结构（左分类 rail + 右宫格）/ rowGrid=上下多行（顶部圆形图标 + 下方厂商大卡）/
 *  cards=上下卡片（顶部矩形分类卡 + 下方宫格）。默认 sidebar=现状。 */
export type DisplayLayoutTemplate = 'sidebar' | 'rowGrid' | 'cards';

export interface MerchantDisplayConfig {
  merchantId: number;
  /** 首页版型模版（默认 sidebar=左右结构） */
  layoutTemplate: DisplayLayoutTemplate;
  categories: DisplayCategory[];
  vendors: DisplayVendor[];
  games: DisplayGame[];
  /** 大类下直接游戏（跳过厂商、与厂商卡并存）。缺省 [] */
  categoryGames: DisplayCategoryGame[];
}

/** 新商户默认配置：用池子内置的 7 个大类（builtin=true），厂商/游戏留空由商户自己挑 */
function defaultConfig(merchantId: number): MerchantDisplayConfig {
  return {
    merchantId,
    layoutTemplate: 'sidebar',
    categories: BUILTIN_MAIN_TYPE_CODES.map((code, i) => ({
      code,
      visible: true,
      sort: (i + 1) * 10,
    })),
    vendors: [],
    games: [],
    categoryGames: [],
  };
}

// 各商户的展示配置（原型态：内存存储，切页保留、刷新重置）
const STORE: Record<number, MerchantDisplayConfig> = {};

// 样板数据（R32 数据多样化）：给前两家商户预置不同的配置，第三家只有大类、第四家走默认
function seed() {
  const [m1, m2] = GAME_MERCHANT_LIST;
  if (!m1) return;

  // 商户 1：4 个大类，slots/casino 下各挂厂商与游戏
  const slotsVendors = GAME_VENDOR_POOL.filter((v) => v.categoryType === 'slots').slice(0, 4);
  const casinoVendors = GAME_VENDOR_POOL.filter((v) => v.categoryType === 'casino').slice(0, 3);
  const c1: MerchantDisplayConfig = {
    merchantId: m1.id,
    layoutTemplate: 'sidebar',
    categories: [
      { code: 'slots', visible: true, sort: 10 },
      { code: 'casino', visible: true, sort: 20 },
      { code: 'lottery', visible: true, sort: 30, aliasZh: '彩票专区' },
      { code: 'sports', visible: false, sort: 40 },
    ],
    vendors: [
      ...slotsVendors.map((v, i) => ({
        categoryCode: 'slots',
        vendorCode: v.code,
        visible: i !== 3,
        sort: (i + 1) * 10,
      })),
      ...casinoVendors.map((v, i) => ({
        categoryCode: 'casino',
        vendorCode: v.code,
        visible: true,
        sort: (i + 1) * 10,
      })),
    ],
    games: [],
    categoryGames: [],
  };
  // 给前两个 slots 厂商各挂它们池里真实存在的游戏
  slotsVendors.slice(0, 2).forEach((v) => {
    subgamesByVendor(v.code)
      .slice(0, 5)
      .forEach((g, i) => {
        c1.games.push({ vendorCode: v.code, gameId: g.gameId, visible: i !== 2, sort: (i + 1) * 10 });
      });
  });
  STORE[m1.id] = c1;

  // 商户 2：只启用 2 个大类、厂商挂得少 —— 与商户 1 明显不同（R32）
  if (m2) {
    const fish = GAME_VENDOR_POOL.filter((v) => v.categoryType === 'fishing').slice(0, 2);
    STORE[m2.id] = {
      merchantId: m2.id,
      layoutTemplate: 'cards',
      categories: [
        { code: 'fishing', visible: true, sort: 10, icon: '🐟' },
        { code: 'chess', visible: true, sort: 20 },
      ],
      vendors: fish.map((v, i) => ({
        categoryCode: 'fishing',
        vendorCode: v.code,
        visible: true,
        sort: (i + 1) * 10,
      })),
      games: [],
      categoryGames: [],
    };
  }
}
seed();

/** 策展特殊大类（2026-07-18 用户定「预置 推荐/热门/精选」）：不在游戏大类池、curation:true，
 *  选中时厂商/游戏栏取全平台全部。每个商户配置都补齐这 3 个（含旧样板）。 */
export const SPECIAL_CATEGORIES: { code: string; name: string }[] = [
  { code: 'sp_recommend', name: '推荐' },
  { code: 'sp_hot', name: '热门' },
  { code: 'sp_featured', name: '精选' },
];
function ensureSpecial(cfg: MerchantDisplayConfig): MerchantDisplayConfig {
  const have = new Set(cfg.categories.map((c) => c.code));
  const missing = SPECIAL_CATEGORIES.filter((s) => !have.has(s.code));
  if (!missing.length) return cfg;
  const maxSort = Math.max(0, ...cfg.categories.map((c) => c.sort));
  cfg.categories = [
    ...cfg.categories,
    ...missing.map((s, i) => ({ code: s.code, visible: true, sort: maxSort + (i + 1) * 10, aliasZh: s.name, curation: true as const })),
  ];
  return cfg;
}

/** 取某商户的展示配置；从未配过 → 返回默认（内置 7 大类）；总补齐 3 个策展特殊大类 */
export function getMerchantDisplay(merchantId: number): MerchantDisplayConfig {
  if (!STORE[merchantId]) STORE[merchantId] = defaultConfig(merchantId);
  return ensureSpecial(STORE[merchantId]);
}

/** 覆盖保存某商户的展示配置 */
export function saveMerchantDisplay(merchantId: number, cfg: MerchantDisplayConfig): void {
  STORE[merchantId] = { ...cfg, merchantId };
}
