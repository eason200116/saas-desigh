// 游戏映射池 —— 唯一真源：「自营子游戏 ↔ 三方厂商游戏」的映射关系。
// 总控端 game/mapping（游戏映射管理）与 game/subgame（子游戏管理·映射配置列/编辑弹窗）
// 都从这里取映射数据，保证两页完全一致。
// （此前两页各写各的假数据：映射页 systemGameId 90101~90104 / 游戏名「麻将胡了2·五福临门…」，
//   子游戏页 id 1~20 / 游戏名「超级 ACE·麻将胡了…」，ID、游戏名、厂商全对不上，
//   子游戏页的「映射配置」只能显示假的 isMapping 0/1 —— 用户 2026-07-14 指出并拍板打通。）
//
// 语义（对齐 SIT /game/mapping 双栏映射配置页）：选一个三方厂商 → 把该厂商的子游戏映射到自营子游戏。
// 依赖方向：本文件（无依赖） → views/game/subgame/data.ts → views/game/mapping/data.ts（不成环）。

export interface GameMappingDef {
  id: number;
  /** 关联「子游戏管理」的真实自营游戏 id（SUB_GAMES.id） */
  subGameId: number;
  /** 目标三方厂商 */
  targetVendor: string;
  /** 目标三方游戏数字 ID（子游戏管理「映射配置」Tag 里括号内展示的游戏ID） */
  targetGameId: number;
  /** 目标三方游戏编码 */
  targetGameCode: string;
  /** 目标三方游戏名称 */
  targetGameName: string;
  /** 映射状态 1=启用 0=禁用 */
  mappingState: 0 | 1;
  lastUpdateMan: string;
  lastUpdateTime: string;
}

/** 目标三方厂商池（弹窗「映射配置 · 厂商」下拉；厂商名对齐 SIT 三方厂商下拉） */
export const TARGET_VENDOR_POOL: string[] = [
  'PG电子',
  'PP电子',
  'JDB电子',
  'FC电子',
  'BNG电子',
  'CQ9电子',
  'AG电子',
  'AG视讯',
  'ARBET体育',
  'BGAMING电子',
];

/** 各三方厂商旗下可映射的官方（三方）游戏。
 *  id = 目标三方游戏的数字 ID，供子游戏列表「映射配置」Tag 展示「厂商-游戏名（游戏ID）」，
 *  也是子游戏编辑弹窗「映射配置」检索结果单选项展示的「英文名-(游戏ID)」（照 SIT 源站，如 Safari King-(408)）。
 *
 * 【2026-07-20 · 总-2 扩容】子游戏编辑弹窗映射配置由只读改为可编辑（照 SIT 源站：查询+单选+分页），
 * 原池每厂商仅 1~3 款、按厂商筛完凑不满一页、分页形同虚设。本次**只加不改**（原 18 款 id/code/name 全部保留、
 * 原 8 条映射引用不受影响）、按各厂商真实调性补到 39 款，让「查询结果单选 + 分页」真的能翻页，贴近源站。
 * 新增 id 均在原有 id 之外、全局唯一（映射弹窗单选项 value 按 id 取，必须唯一）。R45：纯 mock 演示数据。 */
export const TARGET_GAME_POOL: Record<string, Array<{ id: number; code: string; name: string }>> = {
  PG电子: [
    { id: 586, code: 'PG-MJ-2001', name: 'Mahjong Ways 2' },
    { id: 612, code: 'PG-FT-3021', name: 'Fortune Tiger' },
    { id: 498, code: 'PG-AZ-1088', name: 'Treasures of Aztec' },
    { id: 505, code: 'PG-WB-3088', name: 'Wild Bandito' },
    { id: 523, code: 'PG-CB-2077', name: 'Captain Bounty' },
    { id: 544, code: 'PG-GG-3155', name: 'Ganesha Gold' },
  ],
  PP电子: [
    { id: 731, code: 'PP-GOO-001', name: 'Gates of Olympus' },
    { id: 742, code: 'PP-SB-002', name: 'Sweet Bonanza' },
    { id: 755, code: 'PP-BB-003', name: 'Big Bass Bonanza' },
    { id: 768, code: 'PP-SP-004', name: 'Starlight Princess' },
    { id: 779, code: 'PP-WW-005', name: 'Wild West Gold' },
  ],
  JDB电子: [
    { id: 205, code: 'JDB-FLM-088', name: 'Fortune Gods' },
    { id: 219, code: 'JDB-LM-155', name: 'Lucky Miner' },
    { id: 233, code: 'JDB-DW-201', name: 'Dragon Warrior' },
    { id: 247, code: 'JDB-MU-302', name: 'Mummy Treasure' },
  ],
  FC电子: [
    { id: 360, code: 'FC-BUF-320', name: 'Super Buffalo' },
    { id: 377, code: 'FC-KOI-210', name: 'Fortune Koi' },
    { id: 388, code: 'FC-DG-401', name: 'Dragon Gate' },
  ],
  BNG电子: [
    { id: 814, code: 'BNG-CJ-777', name: 'Lucky Treasure' },
    { id: 829, code: 'BNG-BOS-410', name: 'Book of Sirens' },
    { id: 841, code: 'BNG-DR-511', name: 'Dragon Reels' },
  ],
  CQ9电子: [
    { id: 118, code: 'CQ9-WFLM-018', name: '五福临门' },
    { id: 126, code: 'CQ9-TGG-025', name: '跳高高' },
    { id: 137, code: 'CQ9-GM-030', name: 'Gold Miner' },
    { id: 148, code: 'CQ9-RUS-052', name: 'Rave Jump' },
  ],
  AG电子: [
    { id: 940, code: 'AG-GD-101', name: 'Golden Dragon' },
    { id: 951, code: 'AG-FT-102', name: 'Fortune Tree' },
  ],
  AG视讯: [
    { id: 301, code: 'AGL-BAC-A01', name: '百家乐 A' },
    { id: 315, code: 'AGL-ROU-01', name: '轮盘' },
  ],
  ARBET体育: [{ id: 452, code: 'ARB-FB-001', name: '足球主盘' }],
  BGAMING电子: [
    { id: 677, code: 'BG-EF-777', name: 'Elvis Frog' },
    { id: 688, code: 'BG-JB-778', name: 'Johnny Cash' },
  ],
};

/** 按「厂商 + 目标游戏编码」找目标游戏（含数字 ID）；找不到返回 undefined */
export function findTargetGame(
  targetVendor: string,
  targetGameCode: string,
): { id: number; code: string; name: string } | undefined {
  return (TARGET_GAME_POOL[targetVendor] ?? []).find((g) => g.code === targetGameCode);
}

// 映射关系（subGameId 均指向「子游戏管理」真实存在的自营游戏 id，且按品类合理配对；
// 只映射一部分 → 列表里既有已映射的、也有显示「--」的，数据多样 R32）。
//
// ⚠️ subGameId 是**按位置硬指**的：= SUB_GAMES 的 id = config/gameSubgamePool 里的下标+1。
// 池子一旦增删游戏或调整排列顺序，这里 8 条就会静默指到别的游戏上（不报错，页面数据全错）。
// 动池序必须回来核对本表。
//
// 【2026-07-15 重指】子游戏管理页从私有小表（5 家假厂商 × 4 款 = 20 款）接上共享池（46 家 / 214 款）后，
// 原 id 1/3/5/6/8/9/10/13 指向的游戏全变了，其中 3 条还跨了品类（百家乐→老虎机、足球滚球→老虎机）。
// 本次按「同厂商 + 同品类 + 尽量同名」在新池里逐条重指，语义与改造前保持一致。
export const GAME_MAPPING_POOL: GameMappingDef[] = [
  // 14 超级王牌（JILI电子·老虎机）—— 原指 id 1「超级 ACE」，接池后同厂商最接近的一款
  {
    id: 10001,
    subGameId: 14,
    targetVendor: 'PG电子',
    targetGameId: 612,
    targetGameCode: 'PG-FT-3021',
    targetGameName: 'Fortune Tiger',
    mappingState: 1,
    lastUpdateMan: 'wangqiang',
    lastUpdateTime: '2026-06-18 14:22:10',
  },
  // 16 金色帝国（JILI电子·老虎机）—— 原指 id 3「黄金帝国」
  {
    id: 10002,
    subGameId: 16,
    targetVendor: 'AG电子',
    targetGameId: 940,
    targetGameCode: 'AG-GD-101',
    targetGameName: 'Golden Dragon',
    mappingState: 1,
    lastUpdateMan: 'admin001',
    lastUpdateTime: '2026-07-02 20:05:33',
  },
  // 18 麻将胡了（PG电子·老虎机）—— 原指 id 5，同名同厂，接池后位置从 5 挪到 18
  {
    id: 10003,
    subGameId: 18,
    targetVendor: 'PG电子',
    targetGameId: 586,
    targetGameCode: 'PG-MJ-2001',
    targetGameName: 'Mahjong Ways 2',
    mappingState: 1,
    lastUpdateMan: 'lizhi',
    lastUpdateTime: '2026-05-30 09:10:45',
  },
  // 20 寻龙记（PG电子·老虎机）—— 原指 id 6「寻龙宝藏」
  {
    id: 10004,
    subGameId: 20,
    targetVendor: 'PP电子',
    targetGameId: 731,
    targetGameCode: 'PP-GOO-001',
    targetGameName: 'Gates of Olympus',
    mappingState: 0,
    lastUpdateMan: 'chenmeng',
    lastUpdateTime: '2026-04-12 11:48:00',
  },
  // 21 冰雪女王（PG电子·老虎机）—— 原指 id 8「宝石之轮」
  {
    id: 10005,
    subGameId: 21,
    targetVendor: 'BNG电子',
    targetGameId: 829,
    targetGameCode: 'BNG-BOS-410',
    targetGameName: 'Book of Sirens',
    mappingState: 1,
    lastUpdateMan: 'tony01',
    lastUpdateTime: '2026-06-25 16:30:12',
  },
  // 22 经典百家乐（EVO视讯·真人视讯）—— 原指 id 9「百家乐 A 厅」。
  // ⚠️ 不接池的话这条会指到「聚宝盆JP」(CQ9·老虎机) —— 视讯映射成老虎机，跨品类错配
  {
    id: 10006,
    subGameId: 22,
    targetVendor: 'AG视讯',
    targetGameId: 301,
    targetGameCode: 'AGL-BAC-A01',
    targetGameName: '百家乐 A',
    mappingState: 1,
    lastUpdateMan: 'luna00',
    lastUpdateTime: '2026-06-30 18:02:41',
  },
  // 23 极速轮盘（EVO视讯·真人视讯）—— 原指 id 10「轮盘 VIP」
  {
    id: 10007,
    subGameId: 23,
    targetVendor: 'AG视讯',
    targetGameId: 315,
    targetGameCode: 'AGL-ROU-01',
    targetGameName: '轮盘',
    mappingState: 1,
    lastUpdateMan: 'luna00',
    lastUpdateTime: '2026-07-05 10:14:09',
  },
  // 34 足球滚球（CMD体育·体育）—— 原指 id 13，同名，接池后厂商由已退役的 SBO 变为池里的 CMD
  {
    id: 10008,
    subGameId: 34,
    targetVendor: 'ARBET体育',
    targetGameId: 452,
    targetGameCode: 'ARB-FB-001',
    targetGameName: '足球主盘',
    mappingState: 0,
    lastUpdateMan: 'daman01',
    lastUpdateTime: '2026-05-14 11:05:27',
  },
];

/** 按自营子游戏 id 取映射（子游戏管理「映射配置」列 / 编辑弹窗回显用）；无映射返回 undefined */
export function findMappingBySubGameId(subGameId: number): GameMappingDef | undefined {
  return GAME_MAPPING_POOL.find((m) => m.subGameId === Number(subGameId));
}

/** 写入/更新某自营子游戏的映射（编辑弹窗保存用）；targetVendor 传空 = 解除映射 */
export function upsertMapping(
  subGameId: number,
  targetVendor: string,
  targetGameCode: string,
  operator = 'current_user',
): void {
  const id = Number(subGameId);
  const idx = GAME_MAPPING_POOL.findIndex((m) => m.subGameId === id);

  // 解除映射
  if (!targetVendor || !targetGameCode) {
    if (idx >= 0) GAME_MAPPING_POOL.splice(idx, 1);
    return;
  }

  const target = findTargetGame(targetVendor, targetGameCode);
  if (!target) return;

  if (idx >= 0) {
    GAME_MAPPING_POOL[idx] = {
      ...GAME_MAPPING_POOL[idx],
      targetVendor,
      targetGameId: target.id,
      targetGameCode: target.code,
      targetGameName: target.name,
      lastUpdateMan: operator,
      lastUpdateTime: '2026-07-14 10:00:00',
    };
    return;
  }

  const newId = GAME_MAPPING_POOL.reduce((max, m) => Math.max(max, m.id), 10000) + 1;
  GAME_MAPPING_POOL.push({
    id: newId,
    subGameId: id,
    targetVendor,
    targetGameId: target.id,
    targetGameCode: target.code,
    targetGameName: target.name,
    mappingState: 1,
    lastUpdateMan: operator,
    lastUpdateTime: '2026-07-14 10:00:00',
  });
}
