export type AppRole = 'admin' | 'tenant';

export const APP_CONFIG = {
  title: 'AR 原型平台',
  publicPath: '/',
  uploadUrl: '/cdn/upload',
  imgUrl: '/cdn',
  defaultRole: 'tenant' as AppRole,
  defaultLocale: 'zh' as const,
  port: 3100,
  dropConsole: false,
} as const;
