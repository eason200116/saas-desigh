// 游戏主类型池 —— 唯一真源，打通「总控定池 → 商户挑选 → C 端展示」三端。
// 编码以 C 端玩家站为准（站点预览 index.html 的分类 key）：内置 7 类 + 平台扩展类 chess/live。
// 总控端 game/mainType（定义/管理整池）与商户端 game/merchant/mainType（池内挑选+排序）都从这里取值，
// 保证三端主类型编码完全一致（此前总控用 electronic/live/chess 旧 5 类、商户用 minigames，与 C 端对不上）。

export interface GameMainTypeDef {
  /** 主类型编码（三端一致，等于 C 端分类 key） */
  code: string;
  /** 中文名 */
  zh: string;
  /** 英文名 */
  en: string;
  /** 默认排序（越小越靠前） */
  sort: number;
  /** true=内置默认类（商户端必显、不可关） false=平台扩展类（商户可选） */
  builtin: boolean;
}

export const GAME_MAIN_TYPE_POOL: GameMainTypeDef[] = [
  { code: 'slots', zh: '老虎机', en: 'Slots', sort: 10, builtin: true },
  { code: 'lottery', zh: '彩票', en: 'Lottery', sort: 20, builtin: true },
  { code: 'sports', zh: '体育', en: 'Sports', sort: 30, builtin: true },
  { code: 'casino', zh: '真人娱乐场', en: 'Casino', sort: 40, builtin: true },
  { code: 'pvc', zh: '竞技游戏', en: 'PVC', sort: 50, builtin: true },
  { code: 'fishing', zh: '捕鱼', en: 'Fishing', sort: 60, builtin: true },
  { code: 'mini', zh: '小游戏', en: 'Mini games', sort: 70, builtin: true },
  // ↓ 平台扩展类（总控提供、商户可选），对齐 C 端 index.html 的 chess/live
  { code: 'chess', zh: '棋牌', en: 'Chess', sort: 80, builtin: false },
  { code: 'live', zh: '视讯直播', en: 'Live', sort: 90, builtin: false },
  // ↓ 用户 2026-07-15 指定新增的 3 类（热门/精选/推荐）。
  //   builtin 有意设 false：该字段现实语义＝「商户端必显、不可关」(BUILTIN_MAIN_TYPE_CODES 被商户端消费)，
  //   本需求双端归属＝总控 only、且「默认/自定义之分」用户明确暂不调整，故不把这 3 类强推进商户端（R64 端间隔离）。
  { code: 'hot', zh: '热门', en: 'Hot', sort: 100, builtin: false },
  { code: 'featured', zh: '精选', en: 'Featured', sort: 110, builtin: false },
  { code: 'recommend', zh: '推荐', en: 'Recommended', sort: 120, builtin: false },
];

/** 内置默认主类型编码（商户端必显、不可关） */
export const BUILTIN_MAIN_TYPE_CODES = GAME_MAIN_TYPE_POOL.filter((t) => t.builtin).map(
  (t) => t.code,
);

// 旧值 → code 兼容映射（迁移 mock 用；含历史中文变体 + 旧数字枚举 0-4）
export const LEGACY_CATEGORY_TO_CODE: Record<string, string> = {
  电子: 'slots', 电子游戏: 'slots', 老虎机: 'slots',
  彩票: 'lottery',
  体育: 'sports', 体育竞技: 'sports', 体育博彩: 'sports',
  真人: 'casino', 真人视讯: 'casino', 视讯: 'casino', 真人娱乐场: 'casino',
  竞技对战: 'pvc', 竞技游戏: 'pvc', 电竞: 'pvc',
  热门: 'hot', 精选: 'featured', 推荐: 'recommend',
  捕鱼: 'fishing',
  小游戏: 'mini',
  棋牌: 'chess',
  视讯直播: 'live', 直播: 'live',
  '0': 'slots', '1': 'casino', '2': 'sports', '3': 'lottery', '4': 'chess',
};

const CODE_SET = new Set(GAME_MAIN_TYPE_POOL.map((t) => t.code));

/** 归一：接受 code / 旧中文 / 旧数字，返回标准 code（无法识别则原样返回字符串） */
export function normalizeMainTypeCode(input: string | number): string {
  const s = String(input ?? '').trim();
  if (CODE_SET.has(s)) return s;
  return LEGACY_CATEGORY_TO_CODE[s] ?? s;
}

/** 显示：code/旧值 → 「中文（英文）」；查不到回退原值 */
export function mainTypeLabel(input: string | number): string {
  const code = normalizeMainTypeCode(input);
  const def = GAME_MAIN_TYPE_POOL.find((t) => t.code === code);
  return def ? `${def.zh}（${def.en}）` : String(input ?? '');
}

/** 选项：label=中文（英文），value=code，按 sort */
export function mainTypeOptions(): { label: string; value: string }[] {
  return [...GAME_MAIN_TYPE_POOL]
    .sort((a, b) => a.sort - b.sort)
    .map((t) => ({ label: `${t.zh}（${t.en}）`, value: t.code }));
}
