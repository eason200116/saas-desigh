// 游戏版块商户名单 —— 商户端「多商户模式」各游戏配置页共用（商户筛选/选择器、各页 mock 的商户维度）。
//
// 【2026-07-15 全面换成全局商户源 · 用户拍板】
// 原此处自造 4 家（阿尔法娱乐 / 贝塔平台 / 伽马体育 / 德尔塔电竞，id 1001~1004），与全站真实商户
// （daman / 91club / fun88…，id 1050 / 1048 / 1052…）**ID 与名称双双对不上** —— 同一个「商户」概念
// 在游戏版块和其余版块（会员/财务等）是两套人马：游戏页显示「阿尔法娱乐」，会员页显示「daman」。
// 现改为直接引用全站商户名单 @/config/merchantList（其数据即 api/index.ts 对外服务的 organizationGetSelectList），
// **全站一份、不再有第二份**（造第二份必分叉——本日已因同类问题踩过一次：厂商池改码后弹窗私有小表全查不上）。
//
// 影响面：本名单被 7 处消费（商户端 merchant/game、merchant/subgame、merchant/mainType + 总控端 game/game），
// 各页 mock 里的 merchantId 已同步重映射到真实商户ID，映射关系见各 data.ts 的 COMBOS 注释。

import { MERCHANT_LIST, type MerchantDef } from './merchantList';

export type GameMerchant = MerchantDef;

/** 游戏版块可选商户 = 全站商户名单（16 家，跨 4 个集团）。不再自造子集，避免与全站分叉。 */
export const GAME_MERCHANT_LIST: GameMerchant[] = MERCHANT_LIST;

/** 顶部选择器 / 搜索项用的下拉项 */
export const GAME_MERCHANT_OPTIONS = GAME_MERCHANT_LIST.map((m) => ({
  label: m.name,
  value: m.id,
}));

// ===================== 商户币种（一商户一币种） =====================
// 【2026-07-20 用户拍板】商户端不存在多币种：每个商户开站时由商户后台配置唯一固定币种
// （区别于 @/config/gameVendorPool 的 currencyList——那是「厂商」全局支持哪些币种，两个概念不同轴，
// 互不影响、不要混用）。仅供商户端「厂商游戏管理」(merchant/game)、「子游戏管理」(merchant/subgame)
// 两页展示；总控端 game/platform / game/subgame / game/game / game/balance 仍按厂商多币种走，不受影响（R64）。
// 币种码沿用 @/config/gameLocalePool 的币种池；本表覆盖全站 16 家真实商户，按品牌名/所属地区归属指定，
// 未逐一核实真实运营币种（原型 mock，R32 多样化）。
export const GAME_MERCHANT_CURRENCY: Record<number, string> = {
  1050: 'INR', // daman（亚太集团）
  1048: 'INR', // 91club（亚太集团）
  1052: 'THB', // fun88（亚太集团）
  1054: 'MMK', // jeetwin（亚太集团）
  1021: 'INR', // 55club（南亚集团）
  1040: 'IDR', // ugame（南亚集团）
  1038: 'IDR', // pop888（南亚集团）
  1042: 'BRL', // betbra（南亚集团）
  1070: 'BDT', // bdggame（东南亚集团）
  1090: 'PKR', // tirgame（东南亚集团）
  1030: 'THB', // thaifortune（东南亚集团）
  1036: 'VND', // vn168（东南亚集团）
  1072: 'THB', // thaiwin（东南亚集团）
  1080: 'USD', // euroking（欧美集团）
  1082: 'USD', // vegas88（欧美集团）
  1099: 'MXN', // globalbet（欧美集团）
};

/** 商户币种码（查不到回退默认 INR，不吞值） */
export function merchantCurrency(merchantId: number): string {
  return GAME_MERCHANT_CURRENCY[merchantId] ?? 'INR';
}
