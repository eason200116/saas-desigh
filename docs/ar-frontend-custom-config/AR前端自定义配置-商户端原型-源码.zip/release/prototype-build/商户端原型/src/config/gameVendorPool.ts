// 游戏厂商池 —— 唯一真源，打通「第三方厂商 → 总控接入 → 商户配置」。
// 总控端 game/platform（游戏厂商管理，接入/定义整池）与商户端 game/merchant/game（商户游戏管理，
// 在池内为各商户挑选启用）都从这里取厂商身份，保证两端厂商编码/名称/大类/语言/币种完全一致。
//
// 【2026-07-15 全量对齐源站 · 用户拍板】13 家 → 43 家。
//  · 原 13 家里只有 7 家是源站真有的（CQ9/PP/JILI/PG/EVO/AG/SEXY），另 6 家
//    （KM棋牌/IBC体育/GPI彩票/TF电竞/BG捕鱼/SPB小游戏）是当初为「让 9 个大类每类都有厂商」造的样板，
//    源站根本不存在 → 本次删 5 家、**只保留 TF电竞**（用户选方案 B：源站无电竞厂商，删了 pvc 大类会空）。
//  · 【2026-07-15 后续】用户新增「热门/精选/推荐」3 个主类型（见 gameMainTypePool），源站同样无对应厂商，
//    用户拍板「补·同 TF 破例」→ 又加 HOT/FEA/REC 3 家样板厂商。**故非源站厂商现共 4 家**（TF/HOT/FEA/REC），
//    池子总数 43 → 46。除这 4 家外其余均为源站真实厂商。
//  · 42 家全部取自镜像 sit-admin-mirror/game-platform-vendor-mgmt.html（2026-07-10 线上只读实采），
//    名称/编码/供应商/大类/币种/语言均为真值，未臆造。
//  · **编码改用源站码**：EVO→EVO_Video、AG→AG_Video、SEXY→SEXY_Video（源站一个品牌按大类拆多条，
//    如 AG_Electronic + AG_Video；V3 原为一家一条撑不住）。CQ9/PP/JILI/PG 本就一致、未动。
//  · **中文名以用户 2026-07-15 实拍截图为准**：镜像是 07-10 采的，其后源站把 9 家做了中文化
//    （HeiBao_*→黑豹-*、SaBa体育→沙巴体育、TB电子→TB小游戏、BOAN_*→BOAN-*），已按新图对齐。
//  · **en 由 code 机械派生**（下划线转空格）——镜像无英文名字段，不臆造品牌全称（R45）。
//  · **大类映射**：源站只有 5 大类（电子游戏/真人视讯/体育竞技/彩票/棋牌），V3 有 9 个。按语义细化：
//    MG捕鱼→fishing；SPRIBE 系 + TB电子→mini（Spribe 是 crash 类小游戏）；SEXY/WM/DG 视讯→live，
//    其余真人视讯→casino。故 42 家覆盖 8/9 大类，pvc 由保留的 TF电竞 补齐 → 9 类全有厂商。

export interface GameVendorDef {
  /** 厂商编码（两端一致） */
  code: string;
  /** 厂商名称(中文) */
  zh: string;
  /** 厂商名称(英文) */
  en: string;
  /** 使用供应商 */
  provider: string;
  /** 厂商类型：电子游戏/真人视讯/体育/棋牌 */
  vendorType: string;
  /** 游戏大类：code，对齐 src/config/gameMainTypePool.ts（slots/lottery/sports/casino/pvc/fishing/mini/chess/live） */
  categoryType: string;
  /** 厂商支持语言 */
  languageList: string[];
  /** 厂商支持币种 */
  currencyList: string[];
  /** 厂商 logo（图片 URL 或 dataURL）；空串 = 未设置。
   *  2026-07-16 新增：源站与镜像均无此字段，系用户拍板新增（商户端可传、总控端厂商页同步显示/编辑）。
   *  加在池子里而非商户级覆盖，是因用户明确要「真改总控厂商池」= 全站生效。
   *  2026-07-16 追加：池内字面量保持 logo: ''（可读的「未设置」语义），模块加载时由文件末尾的
   *  fill 循环为空值统一生成占位图（用户定「logo 列要加上图」）；上传真图运行时覆盖 def.logo。 */
  logo: string;
}

export const GAME_VENDOR_POOL: GameVendorDef[] = [
  { code: 'AG_Electronic', zh: 'AG电子', en: 'AG Electronic', provider: 'ZhiFeng', vendorType: '电子游戏', categoryType: 'slots', languageList: ['en', 'id', 'pt', 'th', 'vi', 'zh', 'zhw'], currencyList: ['BDT', 'INR', 'PKR', 'VND'], logo: '' },
  { code: 'AG_Video', zh: 'AG视讯', en: 'AG Video', provider: 'ZhiFeng', vendorType: '真人视讯', categoryType: 'casino', languageList: ['en', 'id', 'pt', 'th', 'vi', 'zh', 'zhw'], currencyList: ['BDT', 'INR', 'PKR', 'VND'], logo: '' },
  { code: 'ARBET', zh: 'ARBET体育', en: 'ARBET', provider: 'Official', vendorType: '体育竞技', categoryType: 'sports', languageList: ['en', 'zh'], currencyList: ['BDT', 'INR', 'PKR', 'VND'], logo: '' },
  { code: 'ARLottery', zh: 'AR彩票', en: 'ARLottery', provider: 'Official', vendorType: '彩票', categoryType: 'lottery', languageList: ['ar', 'bn', 'en', 'es', 'hi', 'id', 'ms', 'my', 'pt', 'th', 'ur', 'vi', 'zh'], currencyList: ['BDT', 'BRL', 'IDR', 'INR', 'MMK', 'MXN', 'PKR', 'THB', 'VND'], logo: '' },
  { code: 'ART', zh: 'ART电子', en: 'ART', provider: 'Official', vendorType: '电子游戏', categoryType: 'slots', languageList: ['en'], currencyList: ['BDT', 'INR'], logo: '' },
  { code: 'BGAMING', zh: 'BGAMING电子', en: 'BGAMING', provider: 'DengFeng', vendorType: '电子游戏', categoryType: 'slots', languageList: ['en', 'es', 'id', 'pt', 'th', 'vi'], currencyList: ['BDT', 'BRL', 'INR', 'MXN', 'PKR', 'VND'], logo: '' },
  { code: 'BOAN_INOUT', zh: 'BOAN-INOUT电子', en: 'BOAN INOUT', provider: 'DengFeng', vendorType: '电子游戏', categoryType: 'slots', languageList: [], currencyList: ['BDT', 'INR'], logo: '' },
  { code: 'BOAN_SPRIBE', zh: 'BOAN-SPRIBE电子', en: 'BOAN SPRIBE', provider: 'DengFeng', vendorType: '电子游戏', categoryType: 'mini', languageList: ['en', 'hi', 'id', 'pt', 'th', 'vi'], currencyList: ['BDT', 'BRL', 'INR', 'PKR', 'VND'], logo: '' },
  { code: 'Card365', zh: '365棋牌', en: 'Card365', provider: 'ZhiFeng', vendorType: '棋牌', categoryType: 'chess', languageList: ['en', 'th', 'zh'], currencyList: ['BDT', 'INR', 'MXN', 'PKR', 'VND'], logo: '' },
  { code: 'CMD', zh: 'CMD体育', en: 'CMD', provider: 'ZhiFeng', vendorType: '体育竞技', categoryType: 'sports', languageList: ['en', 'id', 'pt', 'th', 'vi', 'zh', 'zhw'], currencyList: ['BDT', 'INR', 'PKR'], logo: '' },
  { code: 'CQ9', zh: 'CQ9电子', en: 'CQ9', provider: 'ZhiFeng', vendorType: '电子游戏', categoryType: 'slots', languageList: ['bn', 'en', 'es', 'hi', 'id', 'pt', 'th', 'vi', 'zh', 'zhw'], currencyList: ['BDT', 'BRL', 'CNY', 'EGP', 'IDR', 'INR', 'MMK', 'MXN', 'MYR', 'NGN', 'PKR', 'THB', 'USD', 'VND'], logo: '' },
  { code: 'DG_Video', zh: 'DG视讯', en: 'DG Video', provider: 'ZhiFeng', vendorType: '真人视讯', categoryType: 'live', languageList: ['en', 'id', 'pt', 'th', 'vi', 'zh', 'zhw'], currencyList: ['BDT', 'INR', 'PKR', 'VND'], logo: '' },
  { code: 'EVO_Electronic', zh: 'EVO电子', en: 'EVO Electronic', provider: 'Official', vendorType: '电子游戏', categoryType: 'slots', languageList: ['ar', 'bn', 'en', 'es', 'hi', 'id', 'ms', 'pt', 'th', 'vi', 'zh', 'zhw'], currencyList: ['BDT', 'BRL', 'INR', 'MXN', 'PKR', 'VND'], logo: '' },
  { code: 'EVO_Video', zh: 'EVO视讯', en: 'EVO Video', provider: 'Official', vendorType: '真人视讯', categoryType: 'casino', languageList: ['ar', 'bn', 'en', 'es', 'hi', 'id', 'ms', 'pt', 'th', 'vi', 'zh', 'zhw'], currencyList: ['BDT', 'BRL', 'INR', 'MXN', 'PKR', 'VND'], logo: '' },
  { code: '9G', zh: '9G电子', en: '9G', provider: 'Official', vendorType: '电子游戏', categoryType: 'slots', languageList: ['en', 'id', 'pt', 'th', 'vi'], currencyList: ['BDT', 'BRL', 'EGP', 'IDR', 'INR', 'MMK', 'MYR', 'NGN', 'PKR', 'THB', 'VND'], logo: '' },
  { code: 'GameBox', zh: 'GameBox电子', en: 'GameBox', provider: 'Official', vendorType: '电子游戏', categoryType: 'slots', languageList: ['en', 'id', 'my', 'pt', 'th', 'vi', 'zh'], currencyList: ['BDT', 'INR', 'PKR', 'VND'], logo: '' },
  { code: 'HeiBao_JDB', zh: '黑豹-JDB电子', en: 'HeiBao JDB', provider: 'Official', vendorType: '电子游戏', categoryType: 'slots', languageList: ['en', 'id', 'pt', 'th', 'vi'], currencyList: ['BDT', 'BRL', 'INR', 'PKR', 'VND'], logo: '' },
  { code: 'HeiBao_JILI', zh: '黑豹-JILI电子', en: 'HeiBao JILI', provider: 'Official', vendorType: '电子游戏', categoryType: 'slots', languageList: ['en', 'id', 'pt', 'th', 'vi'], currencyList: ['BDT', 'BRL', 'INR', 'PKR', 'VND'], logo: '' },
  { code: 'HeiBao_PG', zh: '黑豹-PG电子', en: 'HeiBao PG', provider: 'Official', vendorType: '电子游戏', categoryType: 'slots', languageList: ['en', 'id', 'pt', 'th', 'vi'], currencyList: ['BDT', 'BRL', 'INR', 'PKR', 'VND'], logo: '' },
  { code: 'HeiBao_PP', zh: '黑豹-PP电子', en: 'HeiBao PP', provider: 'Official', vendorType: '电子游戏', categoryType: 'slots', languageList: ['en', 'id', 'pt', 'th', 'vi'], currencyList: ['BDT', 'BRL', 'INR', 'PKR', 'VND'], logo: '' },
  { code: 'HeiBao_SPRIBE', zh: '黑豹-SPRIBE电子', en: 'HeiBao SPRIBE', provider: 'Official', vendorType: '电子游戏', categoryType: 'mini', languageList: ['en', 'id', 'pt', 'th', 'vi'], currencyList: ['BDT', 'BRL', 'INR', 'PKR', 'VND'], logo: '' },
  { code: 'IM', zh: 'IM体育', en: 'IM', provider: 'ZhiFeng', vendorType: '体育竞技', categoryType: 'sports', languageList: ['en', 'hi', 'id', 'pt', 'th', 'vi', 'zh', 'zhw'], currencyList: ['BDT', 'INR', 'PKR', 'VND'], logo: '' },
  { code: 'INOUT', zh: 'INOUT电子', en: 'INOUT', provider: 'DengFeng', vendorType: '电子游戏', categoryType: 'slots', languageList: ['bn', 'en', 'hi', 'id', 'pt'], currencyList: ['BDT', 'INR', 'PKR'], logo: '' },
  { code: 'JDB', zh: 'JDB电子', en: 'JDB', provider: 'DengFeng', vendorType: '电子游戏', categoryType: 'slots', languageList: ['ar', 'bn', 'en', 'es', 'id', 'pt', 'th', 'vi', 'zh'], currencyList: ['BDT', 'INR', 'MXN', 'PKR', 'VND'], logo: '' },
  { code: 'JILI', zh: 'JILI电子', en: 'JILI', provider: 'ZhiFeng', vendorType: '电子游戏', categoryType: 'slots', languageList: ['bn', 'en', 'es', 'hi', 'id', 'ms', 'my', 'pt', 'th', 'ur', 'vi', 'zh'], currencyList: ['BDT', 'BRL', 'EGP', 'IDR', 'INR', 'MMK', 'MXN', 'MYR', 'NGN', 'PKR', 'THB', 'VND'], logo: '' },
  { code: 'KB', zh: 'KB电子', en: 'KB', provider: 'Official', vendorType: '电子游戏', categoryType: 'slots', languageList: ['en', 'hi', 'id', 'ms', 'pt', 'th', 'vi'], currencyList: ['BDT', 'BRL', 'INR', 'PKR', 'VND'], logo: '' },
  { code: 'KoolBet', zh: 'KoolBet棋牌', en: 'KoolBet', provider: 'Official', vendorType: '棋牌', categoryType: 'chess', languageList: ['en'], currencyList: ['BDT', 'INR', 'PKR'], logo: '' },
  { code: 'MG', zh: 'MG电子', en: 'MG', provider: 'ZhiFeng', vendorType: '电子游戏', categoryType: 'slots', languageList: ['en', 'es', 'hi', 'id', 'pt', 'th', 'vi', 'zh', 'zhw'], currencyList: ['BDT', 'INR', 'MXN', 'PKR', 'VND'], logo: '' },
  { code: 'MG_Fish', zh: 'MG捕鱼', en: 'MG Fish', provider: 'ZhiFeng', vendorType: '电子游戏', categoryType: 'fishing', languageList: ['en', 'es'], currencyList: ['BDT', 'INR', 'MXN', 'PKR', 'VND'], logo: '' },
  { code: 'MG_Video', zh: 'MG视讯', en: 'MG Video', provider: 'ZhiFeng', vendorType: '真人视讯', categoryType: 'casino', languageList: ['en', 'es', 'hi', 'id', 'pt', 'th', 'vi', 'zh', 'zhw'], currencyList: ['BDT', 'INR', 'MXN', 'PKR', 'VND'], logo: '' },
  { code: 'NG', zh: 'NG电子', en: 'NG', provider: 'Official', vendorType: '电子游戏', categoryType: 'slots', languageList: ['en', 'es', 'id', 'ms', 'pt', 'th', 'ur'], currencyList: ['BDT', 'BRL', 'EGP', 'IDR', 'INR', 'MMK', 'MYR', 'NGN', 'PKR', 'THB', 'VND'], logo: '' },
  { code: 'PG', zh: 'PG电子', en: 'PG', provider: 'DengFeng', vendorType: '电子游戏', categoryType: 'slots', languageList: ['en', 'es', 'id', 'my', 'pt', 'th', 'vi', 'zh'], currencyList: ['BDT', 'BRL', 'IDR', 'INR', 'MMK', 'MXN', 'PKR', 'THB', 'VND'], logo: '' },
  { code: 'PP', zh: 'PP电子', en: 'PP', provider: 'ZhiFeng', vendorType: '电子游戏', categoryType: 'slots', languageList: ['en', 'es', 'id', 'ms', 'pt', 'th', 'vi', 'zh'], currencyList: ['BDT', 'BRL', 'EGP', 'IDR', 'INR', 'MMK', 'MXN', 'MYR', 'NGN', 'PKR', 'THB', 'VND'], logo: '' },
  { code: 'SaBa', zh: '沙巴体育', en: 'SaBa', provider: 'ZhiFeng', vendorType: '体育竞技', categoryType: 'sports', languageList: ['ar', 'bn', 'en', 'es', 'hi', 'id', 'ms', 'pt', 'th', 'vi', 'zh', 'zhw'], currencyList: ['BDT', 'INR', 'MXN', 'PKR', 'VND'], logo: '' },
  { code: 'SEXY_Video', zh: 'SEXY视讯', en: 'SEXY Video', provider: 'ZhiFeng', vendorType: '真人视讯', categoryType: 'live', languageList: ['en', 'th', 'vi', 'zh'], currencyList: ['BDT', 'BRL', 'INR', 'PKR', 'THB', 'VND'], logo: '' },
  { code: 'SPRIBE', zh: 'SPRIBE电子', en: 'SPRIBE', provider: 'DengFeng', vendorType: '电子游戏', categoryType: 'mini', languageList: ['bn', 'en', 'es', 'hi', 'id', 'pt', 'th', 'vi', 'zh'], currencyList: ['BDT', 'BRL', 'EGP', 'IDR', 'INR', 'MMK', 'MXN', 'MYR', 'NGN', 'PKR', 'THB', 'VND'], logo: '' },
  { code: 'TB_Chess', zh: 'TB小游戏', en: 'TB Chess', provider: 'Official', vendorType: '电子游戏', categoryType: 'mini', languageList: ['en', 'hi', 'id', 'ms', 'pt', 'th', 'vi'], currencyList: ['BDT', 'BRL', 'INR', 'PKR', 'THB', 'VND'], logo: '' },
  { code: 'TURBO', zh: 'TURBO电子', en: 'TURBO', provider: 'DengFeng', vendorType: '电子游戏', categoryType: 'slots', languageList: ['bn', 'en', 'hi', 'pt', 'th', 'vi'], currencyList: ['BDT', 'INR'], logo: '' },
  { code: 'UP', zh: 'UP电子', en: 'UP', provider: 'Official', vendorType: '电子游戏', categoryType: 'slots', languageList: ['en', 'id', 'my', 'pt', 'th', 'vi'], currencyList: ['BDT', 'BRL', 'INR', 'PKR'], logo: '' },
  { code: 'V8Card', zh: 'V8棋牌', en: 'V8Card', provider: 'ZhiFeng', vendorType: '棋牌', categoryType: 'chess', languageList: ['en', 'zh'], currencyList: ['BDT', 'BRL', 'EGP', 'IDR', 'INR', 'MMK', 'MYR', 'NGN', 'PKR', 'THB', 'VND'], logo: '' },
  { code: 'Wickets9', zh: '9Wickets体育', en: 'Wickets9', provider: 'Official', vendorType: '体育竞技', categoryType: 'sports', languageList: ['en'], currencyList: ['BDT', 'INR', 'PKR'], logo: '' },
  { code: 'WM_Video', zh: 'WM视讯', en: 'WM Video', provider: 'ZhiFeng', vendorType: '真人视讯', categoryType: 'live', languageList: ['en', 'hi', 'id', 'ms', 'th', 'vi', 'zh', 'zhw'], currencyList: ['BDT', 'BRL', 'INR', 'PKR', 'VND'], logo: '' },
  // ── 非源站厂商·破例保留（共 4 家，都是「源站没有该类厂商、但大类必须有数据」才留的）：
  // 1) TF电竞：源站无电竞厂商，删了 pvc 大类会 0 家（用户 2026-07-15 选方案 B）
  { code: 'TF', zh: 'TF电竞', en: 'TF Gaming', provider: 'ZhiFeng', vendorType: '竞技游戏', categoryType: 'pvc', languageList: ['zh', 'en'], currencyList: ['INR', 'BRL'], logo: '' },
  // 2-4) 热门/精选/推荐：用户 2026-07-15 新增这 3 个主类型，源站无对应厂商，
  //      不补则全站大类筛选选中它们必为空列表（R32）——用户拍板「补·同 TF 破例」。
  { code: 'HOT', zh: 'HOT热门', en: 'Hot Games', provider: 'Official', vendorType: '热门', categoryType: 'hot', languageList: ['zh', 'en', 'pt'], currencyList: ['INR', 'BRL'], logo: '' },
  { code: 'FEA', zh: 'FEA精选', en: 'Featured Studio', provider: 'DengFeng', vendorType: '精选', categoryType: 'featured', languageList: ['en', 'th', 'vi'], currencyList: ['VND', 'INR'], logo: '' },
  { code: 'REC', zh: 'REC推荐', en: 'Recommended Hub', provider: 'ZhiFeng', vendorType: '推荐', categoryType: 'recommend', languageList: ['zh', 'en', 'id'], currencyList: ['BRL', 'PKR'], logo: '' },
];

/** 编码 → 厂商定义，供两端 O(1) 取厂商身份 */
export const GAME_VENDOR_MAP: Record<string, GameVendorDef> = Object.fromEntries(
  GAME_VENDOR_POOL.map((v) => [v.code, v]),
);

// ─────────────────────────────────────────────────────────────────────────────
// 占位 Logo 种子（2026-07-16 用户定「logo 列要加上图」）：
// 原型无对象存储、也不能外链真图（CLAUDE.md 红线 1：无真实 HTTP 请求），故在模块加载时
// 为 logo 为空的厂商**确定性**生成「色块 + 字母缩写」SVG data URI——按编码稳定取色、
// 按英文名取缩写，46 家颜色/字母各不相同（R32 数据多样化），刷新/两端取值恒定不闪变。
// 运行时经编辑弹窗上传的真图直接覆盖 def.logo（写共享池），天然优先于占位图。
const LOGO_PALETTE = [
  '#009688', '#1E88E5', '#3949AB', '#8E24AA', '#D81B60', '#E53935',
  '#F4511E', '#FB8C00', '#7CB342', '#00897B', '#5D4037', '#546E7A',
];

function makeVendorLogo(v: GameVendorDef): string {
  // 取色：编码字符码求和 → 调色板取模（同码恒同色）
  const hash = [...v.code].reduce((sum, ch) => sum + ch.charCodeAt(0), 0);
  const bg = LOGO_PALETTE[hash % LOGO_PALETTE.length];
  // 缩写：首词 ≤3 字符整用（CQ9/TF/AG…），否则取前两词首字母（Featured Studio→FS）
  const words = v.en.split(/[^A-Za-z0-9]+/).filter(Boolean);
  const abbr = (
    words[0] && words[0].length <= 3
      ? words[0]
      : words.slice(0, 2).map((w) => w[0]).join('')
  ).toUpperCase();
  const fontSize = abbr.length >= 3 ? 22 : 26;
  const svg =
    `<svg xmlns="http://www.w3.org/2000/svg" width="64" height="64">` +
    `<rect width="64" height="64" rx="12" fill="${bg}"/>` +
    `<text x="32" y="${abbr.length >= 3 ? 40 : 41}" text-anchor="middle" ` +
    `font-family="Arial,Helvetica,sans-serif" font-size="${fontSize}" font-weight="bold" fill="#fff">${abbr}</text>` +
    `</svg>`;
  return `data:image/svg+xml,${encodeURIComponent(svg)}`;
}

GAME_VENDOR_POOL.forEach((v) => {
  if (!v.logo) v.logo = makeVendorLogo(v);
});
