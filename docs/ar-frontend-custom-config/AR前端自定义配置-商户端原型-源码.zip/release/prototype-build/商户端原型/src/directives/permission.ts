import type { App, Directive } from 'vue';

/**
 * 原型项目：权限指令降级为 no-op，所有按钮永远可见。
 * 保留指令注册以兼容视图层残留的 v-permission="[...]" 用法，
 * 避免 runtime "Failed to resolve directive: permission" warning。
 */
export const permission: Directive = {
  mounted() {
    // no-op
  },
  updated() {
    // no-op
  },
};

export function setupPermissionDirective(app: App) {
  app.directive('permission', permission);
  app.directive('per', permission);
}

export default permission;
