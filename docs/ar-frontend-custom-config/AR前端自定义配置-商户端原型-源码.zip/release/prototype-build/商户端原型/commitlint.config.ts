import type { RuleOutcome, UserConfig } from '@commitlint/types';

const SUBJECT_HAS_CJK = /[\u3400-\u9fff]/u;
const SUBJECT_CJK_EXEMPT_TYPES = new Set(['revert']);

function subjectHasCjk(parsed: { subject?: string | null; type?: string | null }): RuleOutcome {
  const subject = String(parsed.subject ?? '').trim();
  const type = String(parsed.type ?? '').trim();

  if (!subject || SUBJECT_CJK_EXEMPT_TYPES.has(type)) {
    return [true];
  }

  return [
    SUBJECT_HAS_CJK.test(subject),
    'subject 默认需包含简体中文，避免整句全英文；如需英文请先明确约定',
  ];
}

const config = {
  ignores: [(commit) => commit.includes('init')],
  extends: ['@commitlint/config-conventional'],
  plugins: [
    {
      rules: {
        'subject-has-cjk': subjectHasCjk,
      },
    },
  ],
  parserPreset: {
    parserOpts: {
      headerPattern: /^(\w*|[\u4e00-\u9fa5]*)(?:[(（](.*)[)）])?[:：] (.*)/,
      headerCorrespondence: ['type', 'scope', 'subject'],
      referenceActions: [
        'close',
        'closes',
        'closed',
        'fix',
        'fixes',
        'fixed',
        'resolve',
        'resolves',
        'resolved',
      ],
      issuePrefixes: ['#'],
      noteKeywords: ['BREAKING CHANGE'],
      fieldPattern: /^-(.*?)-$/,
      revertPattern: /^Revert\s"([\s\S]*)"\s*This reverts commit (\w*)\./,
      revertCorrespondence: ['header', 'hash'],
      warn() {},
      mergePattern: null,
      mergeCorrespondence: null,
    },
  },
  rules: {
    'body-leading-blank': [2, 'always'],
    'footer-leading-blank': [1, 'always'],
    'header-max-length': [2, 'always', 108],
    'subject-empty': [2, 'never'],
    'subject-has-cjk': [2, 'always'],
    'type-empty': [2, 'never'],
    'type-enum': [
      2,
      'always',
      [
        'feat',
        'fix',
        'perf',
        'style',
        'docs',
        'test',
        'refactor',
        'build',
        'ci',
        'chore',
        'revert',
        'wip',
        'workflow',
        'types',
        'release',
      ],
    ],
  },
} satisfies UserConfig;

export default config;
