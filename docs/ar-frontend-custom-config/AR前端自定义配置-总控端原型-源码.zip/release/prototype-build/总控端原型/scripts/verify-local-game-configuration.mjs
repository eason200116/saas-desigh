const controlBaseUrl = process.env.AR_CONTROL_BASE_URL || 'http://127.0.0.1:3200';
const merchantBaseUrl = process.env.AR_MERCHANT_BASE_URL || 'http://127.0.0.1:3100';

const languageCatalog = [
  ['zh', '中文'],
  ['en', '英语'],
  ['hi', '印地语'],
  ['th', '泰语'],
  ['ar', '阿拉伯语'],
  ['pt', '葡萄牙语'],
  ['es', '西班牙语'],
  ['vi', '越南语'],
  ['ur', '乌尔都语'],
  ['bn', '孟加拉语'],
];

const scenarios = {
  1050: {
    merchantId: 'merchant-daman',
    merchantCode: '1050',
    tenantScopes: ['1050', 'daman-demo'],
    enabledLanguages: ['zh', 'en', 'hi'],
    layoutStatus: 'assigned',
  },
  1048: {
    merchantId: 'merchant-91club',
    merchantCode: '1048',
    tenantScopes: ['1048'],
    enabledLanguages: ['en', 'hi'],
    layoutStatus: 'assigned',
  },
  1052: {
    merchantId: 'merchant-fun88',
    merchantCode: '1052',
    tenantScopes: ['1052'],
    enabledLanguages: ['en', 'th'],
    layoutStatus: 'unassigned',
  },
  1054: {
    merchantId: 'merchant-jeetwin',
    merchantCode: '1054',
    tenantScopes: ['1054'],
    enabledLanguages: ['zh', 'en'],
    layoutStatus: 'assigned',
  },
};

const assert = (condition, message) => {
  if (!condition) throw new Error(message);
};

const request = async (baseUrl, tenantId, options = {}) => {
  const response = await fetch(
    `${baseUrl}/__local-api/game-configuration/v1/tenants/${encodeURIComponent(tenantId)}/published`,
    {
      ...options,
      headers: {
        'X-AR-Tenant-Id': tenantId,
        ...(options.body ? { 'Content-Type': 'application/json' } : {}),
        ...options.headers,
      },
    },
  );
  const body = await response.json();
  return { response, body };
};

const buildPayload = (tenantId, scenario) => {
  const assigned = scenario.layoutStatus === 'assigned';
  const buildGame = ({ index, name, nameZh, providerCode, masterGameCode, status }) => ({
    id: `game-${tenantId}-${providerCode.toLowerCase()}-${index}`,
    name,
    providerCode,
    internalGameId: Number(`${scenario.merchantCode}${String(index).padStart(2, '0')}`),
    internalGameCode: `${providerCode}-${tenantId}-${String(index).padStart(2, '0')}`,
    providerGameCode: `${providerCode.toLowerCase()}-${tenantId}-${index}`,
    displayName: { zh: nameZh, en: name },
    masterGameCode,
    status,
    enabled: status === 'active',
  });
  const buildCategory = ({ id, name, masterGameCode, games }) => ({
    id: `category-${tenantId}-${id}`,
    name,
    masterGameId: `master-${id}`,
    masterGameCode,
    displayName: name,
    enabled: games.some((game) => game.enabled),
    games,
  });
  const buildVenue = ({ id, name, providerCode, categories }) => ({
    id: `venue-${tenantId}-${id}`,
    name,
    providerCode,
    enabled: categories.some((category) => category.enabled),
    categories,
  });

  const spribeCrashGames = [
    buildGame({
      index: 1,
      name: 'Aviator',
      nameZh: '飛行員',
      providerCode: 'SPRIBE',
      masterGameCode: 'CRASH',
      status: 'active',
    }),
    buildGame({
      index: 2,
      name: 'Mines',
      nameZh: '地雷',
      providerCode: 'SPRIBE',
      masterGameCode: 'CRASH',
      status: 'maintenance',
    }),
    buildGame({
      index: 3,
      name: 'Dice',
      nameZh: '骰子',
      providerCode: 'SPRIBE',
      masterGameCode: 'CRASH',
      status: 'disabled',
    }),
    buildGame({
      index: 4,
      name: 'Plinko',
      nameZh: '彈珠',
      providerCode: 'SPRIBE',
      masterGameCode: 'CRASH',
      status: 'unavailable',
    }),
  ];
  const jiliSlotGames = [
    buildGame({
      index: 5,
      name: 'Fortune Gems',
      nameZh: '幸運寶石',
      providerCode: 'JILI',
      masterGameCode: 'SLOTS',
      status: 'active',
    }),
    buildGame({
      index: 6,
      name: 'Super Ace',
      nameZh: '超級王牌',
      providerCode: 'JILI',
      masterGameCode: 'SLOTS',
      status: 'active',
    }),
    buildGame({
      index: 7,
      name: 'Golden Empire',
      nameZh: '黃金帝國',
      providerCode: 'JILI',
      masterGameCode: 'SLOTS',
      status: 'maintenance',
    }),
    buildGame({
      index: 8,
      name: 'Pharaoh Treasure',
      nameZh: '法老寶藏',
      providerCode: 'JILI',
      masterGameCode: 'SLOTS',
      status: 'unavailable',
    }),
  ];
  return {
    controlTenantId: scenario.merchantId,
    merchantCode: scenario.merchantCode,
    merchantMapping: {
      source: 'merchantManage',
      merchantId: scenario.merchantId,
      merchantCode: scenario.merchantCode,
      merchantManageCode: Number(scenario.merchantCode),
      tenantScopes: scenario.tenantScopes,
      status: 'matched',
    },
    layoutAssignment: { status: scenario.layoutStatus },
    domainIds: assigned ? [`${scenario.merchantId}:tenant-${tenantId}.example.com`] : [],
    domainUrls: assigned ? [`tenant-${tenantId}.example.com`] : [],
    source: {
      application: 'ar-total-control-3200',
      layoutId: assigned ? `layout-${tenantId}` : null,
      templateId: assigned ? `template-${tenantId}` : null,
      publicationVersion: `local-acceptance-${tenantId}-R1`,
    },
    enabledLanguages: languageCatalog.map(([code, label]) => ({
      code,
      label,
      enabled: scenario.enabledLanguages.includes(code),
      default: null,
    })),
    venues: [
      buildVenue({
        id: 'spribe',
        name: 'SPRIBE',
        providerCode: 'SPRIBE',
        categories: [
          buildCategory({
            id: 'crash',
            name: 'Crash Games',
            masterGameCode: 'CRASH',
            games: spribeCrashGames,
          }),
        ],
      }),
      buildVenue({
        id: 'jili',
        name: 'JILI',
        providerCode: 'JILI',
        categories: [
          buildCategory({
            id: 'slots',
            name: 'Slots',
            masterGameCode: 'SLOTS',
            games: jiliSlotGames,
          }),
        ],
      }),
    ],
  };
};

const isVerifierOwnedSnapshot = (snapshot) =>
  snapshot?.source?.publicationVersion?.startsWith('local-acceptance-') ||
  snapshot?.source?.layoutId === 'local-integration-layout';

const publishMissingOrVerifierOwned = async (tenantId, scenario) => {
  const existing = await request(controlBaseUrl, tenantId);
  if (existing.response.status === 200 && !isVerifierOwnedSnapshot(existing.body.data)) {
    return 'preserved-existing-seed';
  }
  assert(
    existing.response.status === 200 || existing.response.status === 404,
    `${tenantId} preflight expected 200 or 404`,
  );
  const payload = buildPayload(tenantId, scenario);
  const published = await request(controlBaseUrl, tenantId, {
    method: 'PUT',
    body: JSON.stringify(payload),
  });
  assert(published.response.status === 200, `${tenantId} PUT expected 200`);
  assert(published.body.data.tenantId === tenantId, `${tenantId} PUT tenant mismatch`);
  return existing.response.status === 404 ? 'seeded-missing' : 'refreshed-verifier-owned';
};

const seedActions = {};
for (const [tenantId, scenario] of Object.entries(scenarios)) {
  seedActions[tenantId] = await publishMissingOrVerifierOwned(tenantId, scenario);
}

seedActions['daman-demo'] = await publishMissingOrVerifierOwned('daman-demo', scenarios[1050]);

for (const [tenantId, scenario] of Object.entries(scenarios)) {
  const direct = await request(controlBaseUrl, tenantId);
  const proxied = await request(merchantBaseUrl, tenantId);
  assert(direct.response.status === 200, `${tenantId} direct GET expected 200`);
  assert(proxied.response.status === 200, `${tenantId} proxy GET expected 200`);
  assert(proxied.body.data.tenantId === tenantId, `${tenantId} proxy tenant mismatch`);
  assert(
    proxied.body.data.merchantMapping.merchantManageCode === Number(tenantId),
    `${tenantId} merchantManage mapping mismatch`,
  );
  assert(
    proxied.body.data.merchantMapping.tenantScopes.includes(tenantId),
    `${tenantId} mapping scope missing`,
  );
  assert(
    proxied.body.data.enabledLanguages.every((language) =>
      scenario.enabledLanguages.includes(language.code) ? language.enabled : !language.enabled,
    ),
    `${tenantId} language enabled/disabled mismatch`,
  );
  const statuses = proxied.body.data.venues[0].categories[0].games.map((game) => game.status);
  assert(
    ['active', 'maintenance', 'disabled', 'unavailable'].every((status) =>
      statuses.includes(status),
    ),
    `${tenantId} game status coverage mismatch`,
  );
}

const tenant1052 = (await request(merchantBaseUrl, '1052')).body.data;
assert(tenant1052.layoutAssignment.status === 'unassigned', '1052 layout must be unassigned');
assert(tenant1052.domainIds.length === 0, '1052 domainIds must be empty');
assert(tenant1052.domainUrls.length === 0, '1052 domainUrls must be empty');
assert(tenant1052.source.layoutId === null, '1052 layoutId must be null');
assert(tenant1052.source.templateId === null, '1052 templateId must be null');
assert(
  JSON.stringify(tenant1052).includes('tenant-1050.example.com') === false,
  '1052 leaked 1050 layout data',
);

const wrongScope = await request(controlBaseUrl, '1050', {
  headers: { 'X-AR-Tenant-Id': '1048' },
});
assert(wrongScope.response.status === 403, 'wrong tenant header expected 403');

const wrongScopeViaProxy = await request(merchantBaseUrl, '1050', {
  headers: { 'X-AR-Tenant-Id': '1048' },
});
assert(wrongScopeViaProxy.response.status === 403, 'proxy wrong tenant header expected 403');

const empty = await request(merchantBaseUrl, 'tenant-empty-acceptance');
assert(empty.response.status === 404, 'unpublished tenant expected 404');

const invalidUnassigned = buildPayload('1052', scenarios[1052]);
invalidUnassigned.domainIds = ['merchant-daman:daman.example.com'];
invalidUnassigned.domainUrls = ['daman.example.com'];
const invalid = await request(controlBaseUrl, '1052', {
  method: 'PUT',
  body: JSON.stringify(invalidUnassigned),
});
assert(invalid.response.status === 422, 'unassigned layout with domains expected 422');

const mismatchedMapping = buildPayload('1052', scenarios[1052]);
mismatchedMapping.merchantMapping.tenantScopes = ['1050'];
const forbiddenMapping = await request(controlBaseUrl, '1052', {
  method: 'PUT',
  body: JSON.stringify(mismatchedMapping),
});
assert(forbiddenMapping.response.status === 403, 'mapping/path mismatch expected 403');

console.log(
  JSON.stringify(
    {
      ok: true,
      tenants: Object.keys(scenarios),
      alias: 'daman-demo',
      seedActions,
      verifiedStates: ['success', 'empty', 'error-422', 'forbidden-403'],
      gameStatuses: ['active', 'maintenance', 'disabled', 'unavailable'],
      tenant1052Layout: 'unassigned',
    },
    null,
    2,
  ),
);
