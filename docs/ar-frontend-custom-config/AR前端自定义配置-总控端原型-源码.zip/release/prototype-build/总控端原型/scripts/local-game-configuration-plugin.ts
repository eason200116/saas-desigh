import { existsSync, mkdirSync, readFileSync, renameSync, writeFileSync } from 'node:fs';
import { dirname } from 'node:path';
import type { IncomingMessage, ServerResponse } from 'node:http';
import type { Plugin } from 'vite';

export const LOCAL_GAME_CONFIGURATION_PREFIX = '/__local-api/game-configuration/v1';
export const LOCAL_GAME_CONFIGURATION_STATUS = 'UNOFFICIAL_LOCAL_ONLY' as const;

interface LocalGame {
  id: string;
  name: string;
  providerCode: string;
  internalGameId: number;
  internalGameCode: string;
  providerGameCode: string | null;
  displayName: { zh: string; en: string };
  masterGameCode: string;
  status: 'active' | 'maintenance' | 'disabled' | 'unavailable';
  enabled: boolean;
}

interface LocalCategory {
  id: string;
  name: string;
  masterGameId: string;
  masterGameCode: string;
  displayName: string;
  enabled: boolean;
  games: LocalGame[];
}

interface LocalVenue {
  id: string;
  name: string;
  providerCode: string;
  enabled: boolean;
  categories: LocalCategory[];
}

interface LocalLanguage {
  code: string;
  label: string;
  enabled: boolean;
  default: boolean | null;
}

interface LocalMerchantMapping {
  source: 'merchantManage';
  merchantId: string;
  merchantCode: string;
  merchantManageCode: number | null;
  tenantScopes: string[];
  status: 'matched' | 'unmapped';
}

interface PublishPayload {
  controlTenantId: string;
  merchantCode: string;
  merchantMapping: LocalMerchantMapping;
  layoutAssignment: {
    status: 'assigned' | 'unassigned';
  };
  domainIds: string[];
  domainUrls: string[];
  source: {
    application: 'ar-total-control-3200';
    layoutId: string | null;
    templateId: string | null;
    publicationVersion: string;
  };
  enabledLanguages: LocalLanguage[];
  venues: LocalVenue[];
}

export interface LocalGameConfigurationSnapshot extends PublishPayload {
  schemaVersion: 'local.game-configuration.v1';
  interfaceStatus: typeof LOCAL_GAME_CONFIGURATION_STATUS;
  tenantId: string;
  revision: number;
  publishedAt: string;
}

interface StoreFile {
  schemaVersion: 'local.game-configuration.store.v1';
  tenants: Record<string, LocalGameConfigurationSnapshot>;
}

const defaultStorePath = '/private/tmp/ar-local-game-configuration.v1.json';
const tenantPattern = /^[A-Za-z0-9][A-Za-z0-9._-]{0,127}$/;

const emptyStore = (): StoreFile => ({
  schemaVersion: 'local.game-configuration.store.v1',
  tenants: {},
});

const readStore = (storePath: string): StoreFile => {
  try {
    if (!existsSync(storePath)) return emptyStore();
    const parsed = JSON.parse(readFileSync(storePath, 'utf8')) as StoreFile;
    if (parsed?.schemaVersion !== 'local.game-configuration.store.v1' || !parsed.tenants) {
      return emptyStore();
    }
    return parsed;
  } catch {
    return emptyStore();
  }
};

const writeStore = (storePath: string, store: StoreFile) => {
  mkdirSync(dirname(storePath), { recursive: true });
  const temporaryPath = `${storePath}.${process.pid}.${Date.now()}.tmp`;
  writeFileSync(temporaryPath, `${JSON.stringify(store, null, 2)}\n`, 'utf8');
  renameSync(temporaryPath, storePath);
};

const sendJson = (res: ServerResponse, statusCode: number, body: unknown) => {
  res.statusCode = statusCode;
  res.setHeader('Content-Type', 'application/json; charset=utf-8');
  res.setHeader('Cache-Control', 'no-store');
  res.end(JSON.stringify(body));
};

const sendError = (res: ServerResponse, statusCode: number, code: string, message: string) =>
  sendJson(res, statusCode, {
    ok: false,
    interfaceStatus: LOCAL_GAME_CONFIGURATION_STATUS,
    error: { code, message },
  });

const readBody = (req: IncomingMessage): Promise<unknown> =>
  new Promise((resolve, reject) => {
    let body = '';
    req.on('data', (chunk) => {
      body += chunk;
      if (body.length > 2_000_000) reject(new Error('PAYLOAD_TOO_LARGE'));
    });
    req.on('end', () => {
      try {
        resolve(JSON.parse(body || '{}'));
      } catch {
        reject(new Error('INVALID_JSON'));
      }
    });
    req.on('error', reject);
  });

const isNonEmptyString = (value: unknown): value is string =>
  typeof value === 'string' && Boolean(value.trim());

const isStringArray = (value: unknown): value is string[] =>
  Array.isArray(value) && value.every((item) => typeof item === 'string');

const isLanguage = (value: unknown): value is LocalLanguage => {
  if (!value || typeof value !== 'object') return false;
  const language = value as Partial<LocalLanguage>;
  return (
    isNonEmptyString(language.code) &&
    isNonEmptyString(language.label) &&
    typeof language.enabled === 'boolean' &&
    (typeof language.default === 'boolean' || language.default === null)
  );
};

const isMerchantMapping = (value: unknown): value is LocalMerchantMapping => {
  if (!value || typeof value !== 'object') return false;
  const mapping = value as Partial<LocalMerchantMapping>;
  return (
    mapping.source === 'merchantManage' &&
    isNonEmptyString(mapping.merchantId) &&
    isNonEmptyString(mapping.merchantCode) &&
    isStringArray(mapping.tenantScopes) &&
    mapping.tenantScopes.length > 0 &&
    mapping.tenantScopes.every(isNonEmptyString) &&
    new Set(mapping.tenantScopes).size === mapping.tenantScopes.length &&
    ['matched', 'unmapped'].includes(String(mapping.status)) &&
    (typeof mapping.merchantManageCode === 'number' || mapping.merchantManageCode === null) &&
    (mapping.status !== 'matched' ||
      (typeof mapping.merchantManageCode === 'number' &&
        String(mapping.merchantManageCode) === mapping.merchantCode)) &&
    (mapping.status !== 'unmapped' || mapping.merchantManageCode === null)
  );
};

const isGame = (value: unknown): value is LocalGame => {
  if (!value || typeof value !== 'object') return false;
  const game = value as Partial<LocalGame>;
  return (
    isNonEmptyString(game.id) &&
    isNonEmptyString(game.name) &&
    isNonEmptyString(game.providerCode) &&
    typeof game.internalGameId === 'number' &&
    Number.isInteger(game.internalGameId) &&
    isNonEmptyString(game.internalGameCode) &&
    (game.providerGameCode === null || isNonEmptyString(game.providerGameCode)) &&
    isNonEmptyString(game.displayName?.zh) &&
    isNonEmptyString(game.displayName?.en) &&
    isNonEmptyString(game.masterGameCode) &&
    ['active', 'maintenance', 'disabled', 'unavailable'].includes(String(game.status)) &&
    typeof game.enabled === 'boolean' &&
    game.enabled === (game.status === 'active')
  );
};

const isCategory = (value: unknown): value is LocalCategory => {
  if (!value || typeof value !== 'object') return false;
  const category = value as Partial<LocalCategory>;
  return (
    isNonEmptyString(category.id) &&
    isNonEmptyString(category.name) &&
    isNonEmptyString(category.masterGameId) &&
    isNonEmptyString(category.masterGameCode) &&
    isNonEmptyString(category.displayName) &&
    typeof category.enabled === 'boolean' &&
    Array.isArray(category.games) &&
    category.games.every(isGame) &&
    category.enabled === category.games.some((game) => game.enabled)
  );
};

const isVenue = (value: unknown): value is LocalVenue => {
  if (!value || typeof value !== 'object') return false;
  const venue = value as Partial<LocalVenue>;
  return (
    isNonEmptyString(venue.id) &&
    isNonEmptyString(venue.name) &&
    isNonEmptyString(venue.providerCode) &&
    typeof venue.enabled === 'boolean' &&
    Array.isArray(venue.categories) &&
    venue.categories.every(isCategory) &&
    venue.enabled === venue.categories.some((category) => category.enabled)
  );
};

export const isPublishPayload = (value: unknown): value is PublishPayload => {
  if (!value || typeof value !== 'object') return false;
  const payload = value as Partial<PublishPayload>;
  const source = payload.source as Partial<PublishPayload['source']> | undefined;
  return (
    isNonEmptyString(payload.controlTenantId) &&
    isNonEmptyString(payload.merchantCode) &&
    isMerchantMapping(payload.merchantMapping) &&
    payload.merchantMapping.merchantId === payload.controlTenantId &&
    payload.merchantMapping.merchantCode === payload.merchantCode &&
    ['assigned', 'unassigned'].includes(String(payload.layoutAssignment?.status)) &&
    isStringArray(payload.domainIds) &&
    isStringArray(payload.domainUrls) &&
    payload.domainIds.length === payload.domainUrls.length &&
    source?.application === 'ar-total-control-3200' &&
    (payload.layoutAssignment?.status === 'assigned'
      ? payload.domainIds.length > 0 &&
        isNonEmptyString(source.layoutId) &&
        isNonEmptyString(source.templateId)
      : payload.domainIds.length === 0 && source.layoutId === null && source.templateId === null) &&
    isNonEmptyString(source.publicationVersion) &&
    Array.isArray(payload.enabledLanguages) &&
    payload.enabledLanguages.every(isLanguage) &&
    new Set(payload.enabledLanguages.map((language) => language.code)).size ===
      payload.enabledLanguages.length &&
    Array.isArray(payload.venues) &&
    payload.venues.every(isVenue)
  );
};

const setCorsHeaders = (req: IncomingMessage, res: ServerResponse) => {
  const origin = String(req.headers.origin || '');
  if (['http://127.0.0.1:3100', 'http://localhost:3100'].includes(origin)) {
    res.setHeader('Access-Control-Allow-Origin', origin);
    res.setHeader('Vary', 'Origin');
  }
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, X-AR-Tenant-Id');
  res.setHeader('Access-Control-Allow-Methods', 'GET, PUT, OPTIONS');
};

/**
 * 開發原型專用共享接口。它復用總控端既有 Vite server，並以檔案保存跨 port 狀態；
 * 不是正式後端、沒有正式身份驗證，也不可部署為生產 API。
 */
export const localGameConfigurationPlugin = (): Plugin => ({
  name: 'ar-local-game-configuration',
  apply: 'serve',
  configureServer(server) {
    const storePath = process.env.AR_LOCAL_GAME_CONFIG_STORE || defaultStorePath;
    server.middlewares.use(async (req, res, next) => {
      const pathname = new URL(req.url || '/', 'http://local').pathname;
      const match = pathname.match(
        /^\/__local-api\/game-configuration\/v1\/tenants\/([^/]+)\/published\/?$/,
      );
      if (!match) return next();
      setCorsHeaders(req, res);
      if (req.method === 'OPTIONS') {
        res.statusCode = 204;
        res.end();
        return;
      }

      const tenantId = decodeURIComponent(match[1]);
      if (!tenantPattern.test(tenantId)) {
        sendError(res, 400, 'LOCAL_GAME_CONFIG_INVALID_TENANT', 'tenantId 格式無效。');
        return;
      }
      if (String(req.headers['x-ar-tenant-id'] || '') !== tenantId) {
        sendError(
          res,
          403,
          'LOCAL_GAME_CONFIG_TENANT_SCOPE_MISMATCH',
          '請求 tenant scope 與路徑 tenantId 不一致。',
        );
        return;
      }

      if (req.method === 'GET') {
        const snapshot = readStore(storePath).tenants[tenantId];
        if (!snapshot) {
          sendError(
            res,
            404,
            'LOCAL_GAME_CONFIG_NOT_PUBLISHED',
            '總控端尚未為此 tenant 發布本機遊戲配置。',
          );
          return;
        }
        sendJson(res, 200, { ok: true, data: snapshot });
        return;
      }

      if (req.method !== 'PUT') {
        sendError(res, 405, 'LOCAL_GAME_CONFIG_METHOD_NOT_ALLOWED', '僅允許 GET、PUT。');
        return;
      }

      try {
        const payload = await readBody(req);
        if (!isPublishPayload(payload)) {
          sendError(res, 422, 'LOCAL_GAME_CONFIG_INVALID_PAYLOAD', '發布欄位或層級格式無效。');
          return;
        }
        if (!payload.merchantMapping.tenantScopes.includes(tenantId)) {
          sendError(
            res,
            403,
            'LOCAL_GAME_CONFIG_TENANT_MAPPING_MISMATCH',
            '發布資料的 merchant mapping 不包含路徑 tenantId。',
          );
          return;
        }
        const store = readStore(storePath);
        const snapshot: LocalGameConfigurationSnapshot = {
          schemaVersion: 'local.game-configuration.v1',
          interfaceStatus: LOCAL_GAME_CONFIGURATION_STATUS,
          tenantId,
          ...payload,
          revision: (store.tenants[tenantId]?.revision || 0) + 1,
          publishedAt: new Date().toISOString(),
        };
        store.tenants[tenantId] = snapshot;
        writeStore(storePath, store);
        sendJson(res, 200, { ok: true, data: snapshot });
      } catch (error) {
        const code = error instanceof Error ? error.message : 'UNKNOWN';
        const statusCode = code === 'PAYLOAD_TOO_LARGE' ? 413 : 400;
        sendError(res, statusCode, `LOCAL_GAME_CONFIG_${code}`, '無法解析發布內容。');
      }
    });
  },
});
