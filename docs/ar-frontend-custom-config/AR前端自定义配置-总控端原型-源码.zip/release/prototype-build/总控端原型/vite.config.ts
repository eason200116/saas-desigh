import { defineConfig, type Plugin } from 'vite';
import vue from '@vitejs/plugin-vue';
import vueJsx from '@vitejs/plugin-vue-jsx';
import tailwindcss from '@tailwindcss/vite';
import Components from 'unplugin-vue-components/vite';
import { NaiveUiResolver } from 'unplugin-vue-components/resolvers';
import VueI18nPlugin from '@intlify/unplugin-vue-i18n/vite';
import vueInspector from 'vite-plugin-vue-inspector';
import { resolve, dirname } from 'node:path';
import { readdirSync, readFileSync, writeFileSync } from 'node:fs';
import { localGameConfigurationPlugin } from './scripts/local-game-configuration-plugin';

/**
 * dev-only：右键「改文字」写回中间件。收 POST /__dev-text-edit，
 * 在 src/i18n/locales/zh/*.json 里按「原文精确匹配」反查值所在的键，写回新文案。
 * 只改值、不改键名，不碰 en/ 目录。契约与 src/dev/contextMenu.ts 对应，改动需两边同步。
 *
 * 2026-07-23 新增「本页自动锁定」：前端随请求带上被点元素的源码文件路径（sourceFile，来自
 * vite-plugin-vue-inspector 的 data-v-inspector 标注），命中多个候选键时，读该源文件 + 同目录
 * data.ts + components/ 下文件做交集过滤——只有 1 个交集就直接写回不弹选择列表；多个交集只呈现
 * 这几个（标「本页」，排最前）；空交集回落到全量列表（原行为）。同时把候选列表中文化，不再直接
 * 甩英文键名路径给用户看（键名路径降级为每条下面的小字备查）。
 */
function devTextEditPlugin(): Plugin {
  const zhDir = resolve(process.cwd(), 'src/i18n/locales/zh');

  type Hit = { file: string; keyPath: string[] };

  // 递归遍历一个 JSON 对象，收集值严格等于 target 的所有叶子路径
  function findHits(obj: any, target: string, path: string[], out: Hit[], file: string) {
    if (obj == null || typeof obj !== 'object') return;
    for (const k of Object.keys(obj)) {
      const v = obj[k];
      if (typeof v === 'string') {
        if (v === target) out.push({ file, keyPath: [...path, k] });
      } else if (v && typeof v === 'object') {
        findHits(v, target, [...path, k], out, file);
      }
    }
  }

  function readJsonFile(file: string): any {
    return JSON.parse(readFileSync(resolve(zhDir, file), 'utf-8'));
  }

  function writeAtPath(obj: any, keyPath: string[], value: string) {
    let cur = obj;
    for (let i = 0; i < keyPath.length - 1; i++) cur = cur[keyPath[i]];
    cur[keyPath[keyPath.length - 1]] = value;
  }

  function readAtPath(obj: any, keyPath: string[]): any {
    let cur = obj;
    for (const k of keyPath) {
      if (cur == null) return undefined;
      cur = cur[k];
    }
    return cur;
  }

  // 键名末段 → 人话位置：没命中就显示原段（英文），不硬翻
  const POSITION_MAP: Record<string, string> = {
    search: '搜索区',
    columns: '列表列',
    form: '表单',
    actions: '操作',
    title: '标题',
    placeholder: '提示文案',
  };

  function positionLabel(keyPath: string[]): string {
    const parent = keyPath[keyPath.length - 2];
    const leaf = keyPath[keyPath.length - 1];
    return POSITION_MAP[parent || ''] || POSITION_MAP[leaf || ''] || parent || leaf || '';
  }

  // 读被点元素的源文件 + 同目录 data.ts + components/ 下文件，拼成一份用于交集判断的语料
  function buildPageCorpus(sourceFile: string): string {
    if (!sourceFile.startsWith('src/')) return '';
    let corpus = '';
    const tryRead = (p: string) => {
      try {
        corpus += '\n' + readFileSync(p, 'utf-8');
      } catch {
        /* 文件不存在，跳过 */
      }
    };
    const abs = resolve(process.cwd(), sourceFile);
    const dir = dirname(abs);
    tryRead(abs);
    tryRead(resolve(dir, 'data.ts'));
    const compDir = resolve(dir, 'components');
    try {
      const walk = (d: string) => {
        for (const entry of readdirSync(d, { withFileTypes: true })) {
          const full = resolve(d, entry.name);
          if (entry.isDirectory()) walk(full);
          else if (/\.(vue|ts|tsx)$/.test(entry.name)) tryRead(full);
        }
      };
      walk(compDir);
    } catch {
      /* 没有 components 目录，跳过 */
    }
    return corpus;
  }

  // 候选键是否在语料里被引用：键路径可能带最外层命名空间前缀，也可能不带，两种都试
  function keyIsReferenced(corpus: string, keyPath: string[]): boolean {
    const full = keyPath.join('.');
    const stripped = keyPath.slice(1).join('.');
    const candidates = [full, stripped].filter(Boolean);
    return candidates.some(
      (p) =>
        corpus.includes(`'${p}'`) || corpus.includes(`"${p}"`) || corpus.includes('`' + p + '`'),
    );
  }

  // 通用 i18n key（如 'menu.game_merchant_game'）→ 中文值；找不到返回 null
  function resolveI18nValue(fullKey: string): string | null {
    try {
      const parts = fullKey.split('.');
      if (!parts.length) return null;
      const data = readJsonFile(`${parts[0]}.json`);
      const val = readAtPath(data, parts);
      return typeof val === 'string' ? val : null;
    } catch {
      return null;
    }
  }

  // 由 sourceFile 反查它在路由里挂的页面中文名：在 router/modules/*.ts 里找 import(该文件) 那一段，
  // 往前找最近的 title: 'xxx.yyy'，再解析成中文；反查不到返回 null（前端会兜底显示英文模块名）
  function resolvePageTitleZh(sourceFile: string): string | null {
    if (!sourceFile.startsWith('src/')) return null;
    try {
      const componentImportPath = '@/' + sourceFile.slice('src/'.length);
      const routerDir = resolve(process.cwd(), 'src/router/modules');
      const files = readdirSync(routerDir).filter((f) => f.endsWith('.ts'));
      for (const f of files) {
        const content = readFileSync(resolve(routerDir, f), 'utf-8');
        const idx = content.indexOf(`import('${componentImportPath}')`);
        if (idx === -1) continue;
        const before = content.slice(Math.max(0, idx - 2000), idx);
        const matches = [...before.matchAll(/title:\s*['"]([^'"]+)['"]/g)];
        if (!matches.length) continue;
        const titleKey = matches[matches.length - 1][1];
        const zh = resolveI18nValue(titleKey);
        if (zh) return zh;
      }
      return null;
    } catch {
      return null;
    }
  }

  interface CandidateMeta extends Hit {
    key: string;
    inPage: boolean;
    moduleLabel: string;
    positionLabel: string;
  }

  function buildCandidateMeta(h: Hit, inPage: boolean, pageTitleZh: string | null): CandidateMeta {
    const moduleLabel =
      (inPage && pageTitleZh) || h.keyPath[1] || h.keyPath[0] || h.file.replace(/\.json$/, '');
    return {
      file: h.file,
      keyPath: h.keyPath,
      key: h.keyPath.join('.'),
      inPage,
      moduleLabel,
      positionLabel: positionLabel(h.keyPath),
    };
  }

  return {
    name: 'dev-text-edit',
    apply: 'serve',
    configureServer(server) {
      server.middlewares.use('/__dev-text-edit', (req, res) => {
        if (req.method !== 'POST') {
          res.statusCode = 405;
          res.end('Method Not Allowed');
          return;
        }
        let body = '';
        req.on('data', (chunk) => (body += chunk));
        req.on('end', () => {
          res.setHeader('Content-Type', 'application/json; charset=utf-8');
          try {
            const payload = JSON.parse(body || '{}') as {
              original?: string;
              updated?: string;
              choice?: { file: string; keyPath: string[] };
              sourceFile?: string; // 被点元素的源码文件相对路径（如 src/views/game/.../index.vue），用于本页自动锁定
            };
            const original = payload.original ?? '';
            const updated = payload.updated ?? '';
            const sourceFile = payload.sourceFile ?? '';

            // 红线4：JSON 值里不允许 HTML 标签，保存前拒绝含 < > 的输入
            if (/[<>]/.test(updated)) {
              res.end(
                JSON.stringify({
                  status: 'rejected',
                  reason: 'JSON 值不允许包含 HTML 标签（< 或 >）',
                }),
              );
              return;
            }

            const files = readdirSync(zhDir).filter((f) => f.endsWith('.json'));

            // 已选定候选（多命中场景第二次调用）：直接按 choice 写回，不再搜索
            if (payload.choice) {
              const { file, keyPath } = payload.choice;
              const data = readJsonFile(file);
              writeAtPath(data, keyPath, updated);
              writeFileSync(resolve(zhDir, file), JSON.stringify(data, null, 2) + '\n', 'utf-8');
              res.end(JSON.stringify({ status: 'ok', jsonFile: file, key: keyPath.join('.') }));
              return;
            }

            const hits: Hit[] = [];
            for (const file of files) {
              const data = readJsonFile(file);
              findHits(data, original, [], hits, file);
            }

            if (hits.length === 0) {
              res.end(JSON.stringify({ status: 'notfound' }));
              return;
            }

            if (hits.length > 1) {
              // 本页自动锁定：用被点元素的源文件 + 同目录 data.ts/components 语料，与候选键交集
              const corpus = sourceFile ? buildPageCorpus(sourceFile) : '';
              const inPageFlags = corpus
                ? hits.map((h) => keyIsReferenced(corpus, h.keyPath))
                : hits.map(() => false);
              const inPageHits = hits.filter((_, i) => inPageFlags[i]);

              if (inPageHits.length === 1) {
                // 交集恰好 1 个：直接写回，不弹选择列表
                const only = inPageHits[0];
                const data = readJsonFile(only.file);
                if (readAtPath(data, only.keyPath) !== original) {
                  res.end(JSON.stringify({ status: 'notfound' }));
                  return;
                }
                writeAtPath(data, only.keyPath, updated);
                writeFileSync(
                  resolve(zhDir, only.file),
                  JSON.stringify(data, null, 2) + '\n',
                  'utf-8',
                );
                res.end(
                  JSON.stringify({
                    status: 'ok',
                    jsonFile: only.file,
                    key: only.keyPath.join('.'),
                  }),
                );
                return;
              }

              // 交集为空或有多个：弹中文化列表，「本页」命中排最前 + 打标，其余折叠兜底
              const pageTitleZh =
                inPageHits.length > 0 && sourceFile ? resolvePageTitleZh(sourceFile) : null;
              const candidates = hits
                .map((h, i) => buildCandidateMeta(h, inPageFlags[i], pageTitleZh))
                .sort((a, b) => Number(b.inPage) - Number(a.inPage));
              res.end(JSON.stringify({ status: 'ambiguous', candidates }));
              return;
            }

            const only = hits[0];
            const data = readJsonFile(only.file);
            // 防御：写回前确认该路径当前值仍与 original 一致（避免并发编辑覆盖别处改动）
            if (readAtPath(data, only.keyPath) !== original) {
              res.end(JSON.stringify({ status: 'notfound' }));
              return;
            }
            writeAtPath(data, only.keyPath, updated);
            writeFileSync(resolve(zhDir, only.file), JSON.stringify(data, null, 2) + '\n', 'utf-8');
            res.end(
              JSON.stringify({ status: 'ok', jsonFile: only.file, key: only.keyPath.join('.') }),
            );
          } catch (err: any) {
            res.statusCode = 500;
            res.end(JSON.stringify({ status: 'rejected', reason: String(err?.message || err) }));
          }
        });
      });
    },
  };
}

export default defineConfig(({ command }) => ({
  base: '/',
  resolve: {
    alias: {
      '@': resolve(process.cwd(), 'src'),
      '/#': resolve(process.cwd(), 'types'),
    },
  },
  server: {
    port: 3100,
    strictPort: true, // 端口锁死 3100：被占用即报错，绝不静默漂到 3101（避免预览链接扑空）
    host: '0.0.0.0',
    open: false,
    // 改动经常不生效、要手动重启 dev 的根治：macOS 大型项目 fsevents 可能漏触发 / 超文件句柄上限
    // 导致 watcher 静默失效。改用轮询侦测，确保保存 .vue / i18n JSON 后能被检测到并热更。
    watch: {
      usePolling: true,
      interval: 120,
      // 轮询模式默认会扫描整棵目录树；.claude/worktrees 下堆了十几份完整项目副本（各自带 node_modules），
      // 不排除的话每 120ms 轮询一次会把这些副本也扫一遍，长期占满 CPU（实测两个 dev server 进程常驻 200%+），
      // 且轮询本身跑不过来时反而会漏检/延迟 HMR，表现为"改了文件页面不更新"。此处排除跟当前项目无关的目录。
      ignored: [
        '**/.claude/worktrees/**',
        '**/node_modules/**',
        '**/.git/**',
        '**/dist/**',
        '**/*.log',
      ],
    },
  },
  plugins: [
    tailwindcss(),
    vue(),
    vueJsx(),
    Components({
      dts: true,
      resolvers: [NaiveUiResolver()],
    }),
    VueI18nPlugin({
      include: [resolve(process.cwd(), 'src/i18n/locales/**')],
      runtimeOnly: true,
      compositionOnly: true,
      // dev 保留运行时消息编译器：让「改文案/新增 key」的运行时 mergeLocaleMessage 能即时编译生效，
      // 不再乱码、不用重启 dev；仅生产 build 才删编译器（线上体积优化不变）。（2026-07-18 根治）
      dropMessageCompiler: command === 'build',
    }),
    // 仅 dev：给元素注入 data-v-inspector="文件:行:列" 源码定位标注 + 复用 Vite 内置 /__open-in-editor。
    // 不启用其自带的模式开关/组合键 UI，入口统一走 src/dev/contextMenu.ts 的右键菜单。
    vueInspector({ enabled: false, toggleComboKey: false, toggleButtonVisibility: 'never' }),
    // 仅 dev：右键「改文字」写回 zh i18n 源文件的中间件，见函数定义处注释
    ...(command === 'serve' ? [devTextEditPlugin(), localGameConfigurationPlugin()] : []),
  ],
  build: {
    target: 'es2022',
    sourcemap: false,
    rollupOptions: {
      // 多页入口：index.html=3100 主应用（原样不动）；h5.html=独立手机 H5（与主应用零耦合）
      input: {
        main: resolve(process.cwd(), 'index.html'),
        h5: resolve(process.cwd(), 'h5.html'),
      },
      output: {
        manualChunks(id) {
          if (id.includes('node_modules/vue/')) return 'vendor-vue';
          if (id.includes('node_modules/naive-ui')) return 'vendor-naive';
          if (id.includes('node_modules/echarts')) return 'vendor-echarts';
          if (id.includes('node_modules/xlsx')) return 'vendor-xlsx';
          if (id.includes('node_modules/@tiptap')) return 'vendor-editor';
          if (id.includes('node_modules/@codemirror')) return 'vendor-codemirror';
          if (id.includes('node_modules/lodash-es')) return 'vendor-lodash';
        },
      },
    },
  },
}));
