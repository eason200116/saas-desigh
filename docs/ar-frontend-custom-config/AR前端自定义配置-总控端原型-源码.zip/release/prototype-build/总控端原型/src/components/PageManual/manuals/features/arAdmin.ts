import type { ManualFeaturePoint } from '../../types';

// PRD 对照只存在内容数据层；prdSection / prdFeatureId 不会传给前台展示。
export const adminTemplateLibraryZh: ManualFeaturePoint[] = [
  {
    prdSection: '第 10 节／总控端／版面列表查询',
    title: '查看与搜索版面',
    details: {
      purpose: '按版面名称、ID及默认状态找到目标版面，并查看模板、工作流状态、下派主域名与修改信息。',
      prerequisites: '需要“版面查看”，且只能读取当前账号获授权的总控数据。',
      areas: '使用搜索区、版面列表及状态栏；总控状态仅有草稿、已预览、已发布。',
      workflow: '输入名称或 ID，选择默认状态后搜索；清空条件可恢复完整列表。',
      permissions: '仅有查看权限时仍可搜索、查看、预览及读取记录，配置与发布动作不可用。',
      recovery: '加载失败时重试并保留上次成功数据；数据过期时刷新后再操作。',
    },
  },
  {
    prdSection: '第 10 节／总控端／新增版面',
    title: '新增版面',
    details: {
      purpose: '建立新的总控版面草稿，供后续编辑、预览、发布与下派。',
      prerequisites: '需要“版面查看＋配置管理”，并选择代码已提供的模板引用与主题。',
      workflow: '点击新增，填写版面数据并建立草稿，再进入编辑器完成内容。',
      permissions: '无配置管理时新增入口隐藏或禁用。',
      effects: '新增只建立草稿，不产生已发布基准，也不会自动下派到商户。',
      unavailable: '代码未提供模板引用或必填数据不完整时不能建立；模板不可在后台新增或编辑。',
      recovery: '建立失败时保留已填内容，依提示修正后再提交。',
    },
  },
  {
    prdSection: '第 10 节／总控端／复制版面',
    title: '复制版面',
    details: {
      purpose: '将现有总控版面立即复制为新 ID、新名称的独立草稿。',
      prerequisites: '需要“版面查看＋配置管理”，来源版面必须仍可读取。',
      workflow: '在目标版面选择复制，填写并确认新名称；建立成功后直接进入新版面编辑页。',
      permissions: '无配置管理时不能复制。',
      effects: '新草稿完整带入来源版面的模板、主题、结构、全部配置与基准内容；不承接下派关系与域名、发布状态、默认状态、排程或操作记录。',
      unavailable: '来源数据过期或正在发生冲突更新时不能直接复制。',
      recovery: '刷新来源版面后重试；仍失败时先确认来源状态。',
    },
  },
  {
    prdSection: '第 10 节／总控端／设为默认',
    title: '设为默认版面',
    details: {
      purpose: '指定总控默认版面，作为新主域名建议与安全回退候选。',
      prerequisites: '需要“版面查看＋配置管理”，目标版面必须已发布。',
      workflow: '在已发布版面的操作中选择设为默认并确认。',
      permissions: '无配置管理时不能变更默认状态。',
      effects: '同一范围只保留一个默认版面；设为默认不会自动绑定现有域名。',
      unavailable: '草稿或仅已预览版面不能设为默认。',
      recovery: '状态已被其他操作改变时重新加载，再确认新的默认版面。',
    },
  },
  {
    prdSection: '第 10 节／总控端／首次下派',
    title: '首次下派版面',
    details: {
      purpose: '把已发布版面作为可直接渲染的保底内容下派给指定商户及其有效主域名。',
      prerequisites: '需要“版面查看＋配置管理”；基准已发布，目标商户至少有一个已验证且有效的主域名。',
      areas: '在下派／域名管理选择商户、主域名并查看下派结果。',
      workflow: '选择商户与至少一个有效主域名，确认后建立下派关系，再回列表核对记录。',
      permissions: '只有配置管理可建立下派；查看权限可读取下派记录。',
      effects: '商户立即取得含排版、模块数量与游戏的完整保底；同一版面可同时应用多个有效主域名，每个主域名同一时间只能绑定一个版面；没有有效商户覆盖时直接展示该保底。',
      unavailable: '未发布基准、非主域名、未验证或无效域名均不可下派；已绑定主域名必须先解除既有关系，不能直接切换到其他版面。',
      recovery: '域名不可选时检查类型、验证、有效与绑定状态；需要应用其他版面时，先解除既有关系，再另行选择目标版面绑定。',
    },
  },
  {
    prdSection: '第 10 节／总控端／取消下派',
    title: '取消下派',
    details: {
      purpose: '解除版面与指定商户主域名的下派关系。',
      prerequisites: '需要“版面查看＋配置管理”，并确认该关系没有待执行排程。',
      workflow: '打开下派／域名管理，选择既有关系并确认取消。',
      permissions: '无配置管理时只能查看关系，不能取消。',
      effects: '相关主域名停止使用该自定义内容并成为未绑定状态，可再独立绑定其他合资格版面；历史操作记录保留。',
      unavailable: '存在待执行排程时必须先处理排程，不能直接取消。',
      recovery: '取消失败时维持原绑定；刷新关系状态并处理阻挡项目后重试。',
    },
  },
  {
    prdSection: '第 10 节／总控端／删除与封存',
    title: '删除或封存版面',
    details: {
      purpose: '依版面生命周期移除未使用草稿，或停止继续使用已有历史的版面。',
      prerequisites: '需要“版面查看＋配置管理”，并先检查发布、下派、绑定与排程状态。',
      workflow: '对符合条件的未使用草稿执行删除；已有发布或下派历史时改用封存。',
      permissions: '无配置管理时不能删除或封存。',
      effects: '删除移除未使用草稿；封存保留历史与操作记录但不再供新操作使用。',
      unavailable: '曾发布、曾下派、仍有绑定或排程的版面不能删除。',
      recovery: '条件不符时先处理绑定或排程，再按页面允许的封存路径操作。',
    },
  },
  {
    prdSection: '第 10 节／总控端／下派记录与操作记录',
    title: '查看下派与操作记录',
    details: {
      purpose: '追踪版面、商户、主域名、操作者、时间、动作及结果。',
      prerequisites: '需要“版面查看”，且记录范围受账号与商户授权限制。',
      areas: '使用版面下派记录与操作记录查看来源端、变更摘要和失败原因。',
      workflow: '从列表打开记录，按目标版面或商户核对操作结果。',
      permissions: '记录为只读帮助数据；只有查看权限即可读取授权范围内内容。',
      effects: '查看记录不改变版面、下派、筛选或页面状态。',
      recovery: '记录加载失败时重试；跨页变更最迟在刷新或重新进入后显示。',
    },
  },
];


export const adminLayoutEditorZh: ManualFeaturePoint[] = [
  { prdSection: '第 10 节／总控端／版面身份与模板主题', title: '确认版面身份、模板与主题', details: { purpose: '确认名称、ID、代码固定模板、主题、工作流状态及下派主域名后再开始编辑。', prerequisites: '进入与查看需要“版面查看”；模板骨架由前后端代码定义，不属于后台编辑内容。', areas: '页首显示版面身份、只读模板引用、主题、域名与草稿／已预览／已发布状态。', workflow: '先核对身份与代码模板来源，再编辑版面内的模块、数量、排序与游戏。', permissions: '查看权限可读取数据；配置管理才可变更允许的版面草稿字段。', effects: '模板更新只应用新代码骨架与能力；主题只改变视觉变量，两者都不覆盖商户覆盖内容。', unavailable: '代码模板不提供后台新增、删除或编辑。', recovery: '身份或状态过期时重新加载，避免编辑错误版本。' } },
  { prdSection: '第 10 节／总控端／内容结构配置', title: '配置内容结构', details: { purpose: '维护代码模板允许的导航、分类、区块、显示状态、模块数量与同层排序。', prerequisites: '需要“版面查看＋配置管理”，且只能使用代码模板已定义的组件与必备插槽。', areas: '在内容结构区选择导航、分类与区块并调整允许的层级内容。', workflow: '逐层选择目标组件，设置显示状态、数量和同层顺序，再保存草稿。', permissions: '无配置管理时结构保持只读。', effects: '发布后只更新已下派的保底快照；稳定组件 ID 对应的商户覆盖保留且不被覆盖。', unavailable: '代码模板未提供的组件不可新增，必备插槽不可移除。', recovery: '校验失败时按区块提示还原必备结构并重新保存。' } },
  { prdSection: '第 10 节／总控端／英文基准与素材', title: '维护英文基准与素材限制', details: { purpose: '维护导航、分类、区块的英文标题、说明、图片／图标与允许链接。', prerequisites: '需要“版面查看＋配置管理”；总控只维护英文基准，不编辑商户本地化文案。', areas: '在区块配置编辑英文内容、样式与素材限制。', workflow: '选择区块，填写英文必填内容并配置允许素材／链接，然后保存。', permissions: '无配置管理时内容只读。', effects: '英文基准成为商户目标语言和默认语言都缺失时的最终回退。', unavailable: '必填英文内容或素材校验未通过时不能完成发布前预览。', recovery: '依字段与素材提示逐项修正后重新保存。' } },
  { prdSection: '第 10 节／总控端／游戏允许池', title: '配置游戏允许池', details: { purpose: '定义商户可选择的场馆、游戏分类与子游戏范围。', prerequisites: '需要“版面查看＋配置管理”，游戏数据必须处于可用于新配置的状态。', areas: '在游戏区块维护场馆、分类及子游戏允许池。', workflow: '选择场馆、分类与子游戏，确认必备区块至少一个有效子游戏并保存。', permissions: '无配置管理时游戏范围只读。', effects: '商户只能从总控允许池与自身已开通范围的交集中选择。', unavailable: '停用或不可用游戏不能进入新发布；每区块最多 50 个。', recovery: '没有可选游戏时检查允许池、商户开通范围与游戏状态。' } },
  { prdSection: '第 10 节／总控端／保存草稿', title: '保存草稿', details: { purpose: '保存当前结构与内容变更，不改变已发布基准。', prerequisites: '需要“版面查看＋配置管理”，并通过保存阶段的字段校验。', workflow: '完成当前编辑后点击保存草稿，确认保存结果再继续预览。', permissions: '无配置管理时不能保存；权限撤销后未保存内容只供复制。', effects: '仅更新草稿；已发布基准和商户线上内容保持不变。', unavailable: '必填格式错误或并发版本冲突时不能保存。', recovery: '依提示修正；冲突时重新加载或复制为新草稿。' } },
  { prdSection: '第 10 节／总控端／多端预览', title: '执行多端预览', details: { purpose: '以发布相同渲染方式检查当前草稿的设备、语言、域名与回退结果。', prerequisites: '需要“版面查看”，草稿须满足预览校验。', areas: '手机端以 375×812 预览；PC 端以 1920 为基准宽度并依画面可用宽度自适应，高度随内容延伸且不限制。', workflow: '保存后打开预览，逐一切换设备、语言与域名检查，再关闭返回编辑。', permissions: '查看权限可预览，不需要配置或发布权限。', effects: '预览不写入线上；成功预览使工作流成为“已预览”。', unavailable: '必填内容、结构、素材或游戏校验不通过时不能完成有效预览。', recovery: '按区块提示修正、保存并重新预览；切换预览条件不会清除编辑内容。' } },
  { prdSection: '第 10 节／总控端／发布基准', title: '发布总控保底版面', details: { purpose: '把已预览且校验通过的草稿发布为新的可下派保底快照。', prerequisites: '需要“版面查看＋发布管理”，当前状态为已预览且全部校验通过。', workflow: '完成预览后点击发布，确认发布结果，再回列表执行下派或查看记录。', permissions: '配置管理可编辑但不能发布；发布管理可复核、预览与发布。', effects: '已下派商户自动应用新保底快照，不需商户确认；仅更新保底，不覆盖或删除商户草稿与已发布覆盖。', unavailable: '草稿、预览后又修改或仍有校验错误时不能发布。', recovery: '发布失败时原保底快照与当前草稿均保留；修正或重试后再次发布。' } },
  { prdSection: '第 10 节／总控端／未保存与并发处理', title: '处理未保存内容与并发更新', details: { purpose: '避免离开、权限变化或多人编辑时遗失当前工作。', prerequisites: '适用于有未保存变更或数据版本已过期的编辑状态。', workflow: '离开时选择保存、放弃或取消；发生冲突时重新加载或复制为新草稿。', permissions: '配置权限撤销后页面转只读，未保存内容保留供复制但不能提交。', effects: '取消离开会保留原表单、选区与未保存内容。', unavailable: '版本冲突时禁止直接覆盖他人最新变更。', recovery: '先复制需要保留的内容，再加载最新版本或另存副本。' } },
];


const ADMIN_PRD_REFERENCE: Record<string, string> = {
  'ADM-00': '2.1／ADM-00｜总控端产品边界',
  'ADM-01': '3.1／ADM-01｜版面列表、建立与复制',
  'ADM-02': '3.1／ADM-02｜总控编辑与草稿保存',
  'ADM-03': '3.1／ADM-03｜总控预览与校验',
  'ADM-04': '3.1／ADM-04｜总控发布与停用',
  'DSP-01': '3.2／DSP-01｜首次下派',
  'DSP-03': '3.2／DSP-03｜取消下派',
  'AUD-01': '5.5／AUD-01｜审计查询与保留',
  'PERM-01': '2.2／PERM-01｜角色权限与入口',
};

function bindAdminPrdReferences(points: ManualFeaturePoint[], ids: string[]) {
  if (points.length !== ids.length) throw new Error('PageManual PRD mapping count mismatch');
  points.forEach((point, index) => {
    const prdFeatureId = ids[index];
    point.prdFeatureId = prdFeatureId;
    point.prdSection = ADMIN_PRD_REFERENCE[prdFeatureId];
  });
}

// 同一 PRD 功能点若含多个不连续画面操作，前台仍分段说明；数据层共用官方编号追溯。
adminTemplateLibraryZh.unshift(
  { prdSection: '', prdFeatureId: 'ADM-00', title: '理解总控端边界', details: { purpose: '在代码固定模板骨架内建立、编辑、发布并下派可直接渲染的保底版面。', prerequisites: '管理员已登录并具相应查看、编辑或发布管理权限。', areas: '模板是代码定义的页面骨架；版面包含排版、模块数量、排序与游戏保底内容。', workflow: '从列表建立或编辑版面，预览并发布，再按需要下派。', permissions: '查看、编辑与发布管理分别控制入口和操作。', effects: '下派保底可直接展示；后续模板或版面更新只更新骨架能力与保底快照，不覆盖商户覆盖。', unavailable: '校验失败维持草稿；数据更新时须重新加载。', recovery: '修正草稿或加载最新数据，确认保底发布失败不影响商户覆盖。' } },
  { prdSection: '', prdFeatureId: 'PERM-01', title: '按角色权限使用功能', details: { purpose: '依查看、编辑与发布管理权限控制入口与操作。', prerequisites: '角色权限已由 V3 角色管理配置。', areas: '入口、按钮、只读状态与受保护操作会同步反映权限。', workflow: '先确认可见入口，再执行获授权操作；权限不足时联系管理员。', permissions: '有版面查看即可打开本说明书；编辑、发布、下派与取消需相应权限。', effects: '阅读说明或查看数据不会改变角色设置。', unavailable: '无查看权限时入口与直接地址均受阻挡；权限收回后后续操作立即失效。', recovery: '由管理员补齐权限后重新进入，不沿用失效操作。' } },
);

const adminListPrdIds = ['ADM-00', 'PERM-01', 'ADM-01', 'ADM-01', 'ADM-01', 'ADM-04', 'DSP-01', 'DSP-03', 'ADM-04', 'AUD-01'];
const adminEditorPrdIds = ['ADM-02', 'ADM-02', 'ADM-02', 'ADM-02', 'ADM-02', 'ADM-03', 'ADM-04', 'ADM-02'];

bindAdminPrdReferences(adminTemplateLibraryZh, adminListPrdIds);
bindAdminPrdReferences(adminLayoutEditorZh, adminEditorPrdIds);
