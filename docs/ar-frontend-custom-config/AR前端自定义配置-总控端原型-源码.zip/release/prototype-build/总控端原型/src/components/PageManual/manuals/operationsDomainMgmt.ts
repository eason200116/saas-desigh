// 域名管理（商户端 tenant · operations_domainMgmt）功能说明书。
// 锚定 src/views/operations/domainMgmt/index.vue + DomainMgmtFormModal.vue + data.ts 真实控件（R53 实证、不臆造）。

import type { PageManual } from '../types';

const manual: PageManual = {
  route: 'operations_domainMgmt',
  title: '域名管理',
  overview:
    '商户端「运营管理 › 域名管理」页，维护平台各类域名（主域名/推广域名/防封谷歌页）的基础信息与启用状态。' +
    '2026-07-22核实代码发现两处值得记录的情况：' +
    '①行操作只有"编辑"1个按钮，没有"删除"或"详情"——但 data.ts 的行数据模型(DomainRecord)实际还定义了' +
    '节点/CDN/解析状态/跳转域名/落地指向/防封开关/关联渠道 共7个字段，且组件目录下已经建好了对应的只读详情弹窗' +
    '(DomainDetailModal.vue，n-descriptions两列展示上述全部字段)和防封配置弹窗(AntiBlockConfigModal.vue，' +
    '对应mock方法setDomainAntiBlock/saveDomainAntiBlockConfig)——但这2个弹窗组件在index.vue里完全没有被' +
    '导入或触发（全仓grep确认零引用），列表列也没有展示这7个字段，等于"做好了但没接上"，7个字段+2个弹窗对最终' +
    '用户来说都不可见/不可达；②新增/编辑保存(saveDomain)与状态修改(setDomainState)的mock均只返回成功、不真正' +
    '写回底层数组（虽然save比较特殊——它连业务含义上真实生效与否都无法验证，因为压根没有独立的"仅改状态"入口）。' +
    '如实记录，未修复。',
  items: [
    {
      anchor: 'merchant',
      name: '商户',
      group: '搜索',
      interaction: '下拉筛选。',
    },
    {
      anchor: 'domainType',
      name: '域名类型',
      group: '搜索',
      interaction: '下拉单选，可清空；选项：主域名/推广域名/防封谷歌页。',
    },
    {
      anchor: 'domainUrl',
      name: '域名',
      group: '搜索',
      interaction: '文本框，可清空，按域名URL模糊匹配。',
    },
    {
      anchor: 'reset',
      name: '重置',
      group: '搜索',
      interaction: 'ProCrudTable内置重置按钮。',
    },
    {
      anchor: 'act_add',
      name: '新增',
      group: '操作',
      interaction: '主色按钮，点击打开新增弹窗（600px宽）。',
      logic:
        '弹窗字段：商户(单选，编辑态置灰) → 域名类型(下拉) → 域名(文本框，必须以https://开头，≤50字符，' +
        '保存前会调用唯一性校验接口，重复则拦截) → 状态(开关) → 备注(多行文本，≤500字)。',
    },
    {
      anchor: 'act_edit',
      name: '编辑',
      group: '操作',
      interaction: '每行常驻，点击打开编辑弹窗（字段同新增，回显当前值）。',
    },
  ],
  fields: [
    { name: '商户（列）', def: '该域名所属商户，标签展示。' },
    { name: '域名ID', def: '该域名记录的唯一编号（取行数据id）。' },
    { name: '域名类型', def: '主域名/推广域名/防封谷歌页三态Tag。' },
    { name: '域名', def: '完整域名URL。' },
    { name: '状态', def: '启用/禁用，只读Tag。' },
    { name: '创建时间', def: '该域名记录的创建时间。' },
    { name: '创建人', def: '创建该域名记录的操作人账号。' },
    { name: '修改时间', def: '该域名记录最近一次编辑的时间。' },
    { name: '最后修改人', def: '最近一次编辑该域名记录的操作人账号。' },
    { name: '备注', def: '补充说明信息，为空展示"-"。' },
  ],
};

export default manual;
