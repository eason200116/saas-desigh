import type { PageManual } from '../types';
import { adminLayoutEditorZh } from './features/arAdmin';

const manual: PageManual = {
  prdManualFeatureId: 'HELP-01',
  route: 'tenant_templateLibrary_layoutConfig',
  title: '总控版面编辑',
  overview: '在代码模板提供的页面骨架内建立可直接展示的版面，配置模块、显示数量、英文内容与游戏；发布后可作为商户下派保底。',
  featurePoints: adminLayoutEditorZh,
  sections: [
    { key: 'purpose', content: '模板由前后端代码定义顶部导航、底部导航、Banner、跑马灯、插槽及能力边界；编辑器不修改模板。总控在模板范围内建立版面，配置模块增减、同层排序、显示数量、英文内容、素材及场馆／分类／子游戏，形成完整保底展示。' },
    { key: 'prerequisites', content: '“版面查看”可进入并预览；“配置管理”可编辑与保存；“发布管理”可发布。已下派或已发布版面不能直接替换模板，需要先复制为新草稿。发布前需完成有效预览及全部校验。' },
    { key: 'areas', content: '页首显示名称、ID、模板、主题、下派主域名与草稿／已预览／已发布状态。内容结构用于选择和排序导航、分类及区块；区块配置维护英文基准、样式、素材限制和游戏允许池；多端预览使用与发布相同的渲染方式。手机端固定以 375×812 检查，PC 端以 1920 为基准宽度并随画面可用宽度自适应，高度随内容延伸且不限制。' },
    { key: 'workflow', content: '1. 选择草稿并确认模板、主题及结构。\n2. 配置英文导航、分类、区块与允许的素材／链接。\n3. 为必备游戏区块建立场馆、分类及子游戏允许池。\n4. 保存草稿；用多端预览检查设备、语言、域名与回退结果。\n5. 修正校验问题并再次预览，使状态成为“已预览”。\n6. 具备发布权限后发布基准，再从列表完成下派。' },
    { key: 'permissions', content: '仅查看时所有配置保持只读，可查看说明书和预览。有配置管理但无发布管理时可保存草稿，发布操作不可用。有发布管理的复核人员可在不修改配置的情况下预览并发布。若编辑期间配置权限被撤销，页面转为只读并保留未保存内容供复制，但不能保存。' },
    { key: 'effects', content: '保存只更新草稿，预览不写入线上。发布后形成可下派版面；下派快照含完整基本排版与游戏内容，可立即作为商户保底展示。商户成功发布后以覆盖层展示；商户配置失效时自动切回这份保底快照。' },
    { key: 'unavailable', content: '存在必填英文内容、必备结构、素材或游戏校验问题时不能预览／发布。必备游戏区块至少需要一个有效子游戏，停用或不可用游戏不能进入新发布内容，每区块最多 50 个。已预览后再次修改会回到草稿。模板未提供的组件不可新增；主题变更不得清除内容或改变组件识别。' },
    { key: 'recovery', content: '校验失败时按区块提示逐项修正后重新保存与预览。游戏无可选结果时检查总控允许池与游戏状态。数据更新失败时保留上次成功数据并重试。若其他人员或页签已更新，系统禁止覆盖；重新加载最新内容，或复制为新草稿。离开有未保存内容的编辑页时选择保存、放弃或取消离开。' },
  ],
  items: [
    { anchor: 'backToLayouts', name: '返回', group: '操作', interaction: '返回版面列表；有未保存内容时先处理离开提示。' },
    { anchor: 'layoutIdentity', name: '名称／ID／状态', group: '其它', interaction: '查看版面身份与当前工作流状态；名称可否编辑依权限与版面状态决定。' },
    { anchor: 'template', name: '模板', group: '操作', interaction: '查看版面的结构来源。', limit: '已发布或已下派版面不得直接更换模板。' },
    { anchor: 'theme', name: '主题', group: '操作', interaction: '在草稿中切换视觉变量，不改变组件识别或内容。' },
    { anchor: 'applicationDomains', name: '下派主域名', group: '操作', interaction: '查看或选择可下派的商户有效主域名。' },
    { anchor: 'contentStructure', name: '内容结构', group: '其它', interaction: '维护导航、分类、区块、层级、显示状态与同层排序。' },
    { anchor: 'semanticConfig', name: '区块配置', group: '其它', interaction: '维护英文基准内容、素材限制与场馆／分类／子游戏允许池。' },
    { anchor: 'h5Preview', name: '多端预览', group: '其它', interaction: '手机端固定以 375×812 预览；PC 端以 1920 为基准宽度并随画面自适应，高度不限制。切换设备、语言或域名不会重置编辑内容。' },
    { anchor: 'saveDraft', name: '保存草稿', group: '操作', interaction: '保存当前配置，不自动发布。' },
    { anchor: 'previewDraft', name: '预览', group: '操作', interaction: '执行发布前校验并查看当前草稿，不写入线上内容。' },
    { anchor: 'publishLayout', name: '发布', group: '操作', interaction: '发布已预览且校验通过的总控基准。', limit: '需要发布管理权限。' },
  ],
  fields: [
    { name: '模板', def: '前后端代码内建的页面骨架、组件类型、层级、必备插槽与能力边界；编辑器只读。' },
    { name: '模块显示数量', def: '版面层配置的模块可见项目数量；须通过模板上限与游戏有效性校验。' },
    { name: '主题', def: '色彩、字体、圆角与间距等视觉变量。' },
    { name: '英文基准', def: '总控维护的导航、分类及区块英文内容，也是商户文案的最终回退来源。' },
    { name: '游戏允许池', def: '商户可用场馆、分类及子游戏的总控范围。' },
    { name: '工作流状态', def: '草稿、已预览或已发布。' },
  ],
};

export default manual;
