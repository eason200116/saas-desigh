import type { PageManual } from '../types';
import { adminTemplateLibraryZh } from './features/arAdmin';

const manual: PageManual = {
  prdManualFeatureId: 'HELP-01',
  route: 'tenant_templateLibrary',
  routeAliases: ['tenant_styleManage:templateLibrary'],
  title: '版面列表／下派管理',
  overview: '管理总控版面、保底下派、主域名绑定与操作记录。模板是前后端代码内建的页面骨架；版面才是此页可建立、命名、编辑、复制与停用的配置对象。',
  featurePoints: adminTemplateLibraryZh,
  sections: [
    { key: 'purpose', content: '集中管理版面与下派关系。模板由前后端代码共同定义，固定提供顶部导航、底部导航、Banner、跑马灯等页面骨架与可用插槽，不在后台新增、复制或停用；版面引用模板后，配置模块、数量、顺序、游戏及内容。' },
    { key: 'prerequisites', content: '进入页面需要“版面查看”。新增、复制、下派、取消、设为默认及封存需要“配置管理”；发布需要“发布管理”。首次下派前，版面基准必须已发布，并且目标商户至少有一个已验证且有效的主域名。' },
    { key: 'areas', content: '搜索区按版面名称／ID及默认状态筛选。列表显示版面名称、ID、模板、工作流状态、下派主域名、创建信息、最后修改与操作。总控状态只有草稿、已预览、已发布；已发布内容再次编辑时，线上基准仍维持上次发布结果。下派记录保留版面、商户、主域名、操作者、时间与结果。' },
    { key: 'workflow', content: '1. 搜索、建立或复制目标版面，并选择代码内已提供的模板。\n2. 进入编辑器配置基本排版、模块显示数量与游戏内容。\n3. 保存、预览并发布为可直接展示的版面。\n4. 在域名管理选择商户及有效主域名下派；下派结果即为该商户的保底展示。\n5. 已绑定域名若要使用其他版面，必须先完成解除绑定，再另行建立新绑定；不可直接切换。' },
    { key: 'permissions', content: '仅有“版面查看”时可查看列表、预览与记录，配置动作隐藏或禁用。有“查看＋配置”可维护草稿与下派但不能发布；有“查看＋发布”可复核与发布但不能改配置。权限撤销后，下一次受保护操作前会改为只读或离开页面。' },
    { key: 'effects', content: '下派会同时提供可直接渲染的基本排版与游戏内容，作为商户前台保底版面。商户成功发布自定义配置后，以商户覆盖层展示；商户配置加载、校验、发布或渲染失败时，自动忽略失效覆盖并切回下派保底版面。取消下派后才改用平台默认。' },
    { key: 'unavailable', content: '缺少基本排版或有效游戏内容的版面不能下派。一个有效主域名同一时间只能绑定一个版面；已有绑定时不得直接选择其他版面或模板，必须先解除成功。有待执行排程时先处理排程。非主域名不可选择；曾发布或下派的版面只能停用／封存。' },
    { key: 'recovery', content: '列表加载失败时使用重试并保留上次成功数据；数据可能不是最新时先刷新。主域名不可选时，检查其是否为已验证、有效的主域名。下派或同步失败时不要重复建立关系，确认失败原因后重试；跨页更新最迟应在 3 秒内或重新进入页面后可见。发生编辑冲突时重新加载，或复制为新草稿继续。' },
  ],
  items: [
    { anchor: 'layoutKeyword', name: '版面名称／版面 ID', group: '搜索', interaction: '输入名称或 ID 搜索版面；不会改变其他筛选条件。' },
    { anchor: 'defaultStatus', name: '默认状态', group: '搜索', interaction: '筛选默认或非默认版面；清空表示不限制。' },
    { anchor: 'resetFilters', name: '重置', group: '操作', interaction: '清空当前搜索条件并回到第一页。' },
    { anchor: 'searchLayouts', name: '搜索', group: '操作', interaction: '按当前条件查询并回到第一页。' },
    { anchor: 'dispatchLog', name: '版面下派记录', group: '操作', interaction: '查看版面与主域名的下派结果及操作信息。' },
    { anchor: 'act_addLayout', name: '新增版面', group: '操作', interaction: '建立新的总控版面草稿。', limit: '需要配置管理权限。' },
    { anchor: 'layoutTable', name: '版面列表', group: '列', interaction: '查看状态并进入编辑、域名管理、复制、设为默认或允许的删除／封存操作。' },
    { anchor: 'domainManagement', name: '下派／域名管理', group: '操作', interaction: '选择商户有效主域名建立、取消或调整下派关系。', limit: '首次下派至少选择一个主域名。' },
  ],
  fields: [
    { name: '版面名称', def: '辨识该版面配置实例的名称。' },
    { name: '版面 ID', def: '版面的唯一识别值；复制后会产生新 ID。' },
    { name: '模板', def: '前后端代码内建的页面骨架与能力定义，只供版面引用，后台不可新增、编辑、复制或停用。' },
    { name: '工作流状态', def: '总控版面的草稿、已预览或已发布状态。' },
    { name: '下派主域名', def: '当前由该版面基准下派的商户有效主域名。' },
    { name: '创建信息', def: '建立人员与时间。' },
    { name: '最后修改', def: '最近修改人员与时间。' },
  ],
};

export default manual;
