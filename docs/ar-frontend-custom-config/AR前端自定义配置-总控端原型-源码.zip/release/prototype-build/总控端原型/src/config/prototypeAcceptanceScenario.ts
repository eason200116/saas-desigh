export const PROTOTYPE_ACCEPTANCE_TENANT_IDS = ['1050', '1048', '1052', '1054'] as const;
export type PrototypeAcceptanceTenantId = (typeof PROTOTYPE_ACCEPTANCE_TENANT_IDS)[number];
export type PrototypeFixtureMode = 'ready' | 'loading' | 'empty' | 'error' | 'stale';
export type PrototypeFixtureSource = 'merchant' | 'layout' | 'domain' | 'gameVenue' | 'gameCategory' | 'language';

export interface PrototypeLayoutScenario {
  layoutId: string;
  layoutName: string;
  domainId: string;
  domainUrl: string;
  isDefault: boolean;
  configurationStatus: 'unconfigured' | 'draft' | 'published';
  scheduleStatus: 'none' | 'scheduled';
  publishStatus: 'normal' | 'success' | 'auto-rolled-back';
  domainStatus: 'enabled' | 'disabled';
  historyVersions: string[];
  hasRollbackAudit: boolean;
}

export interface PrototypeAcceptanceScenario {
  tenantId: PrototypeAcceptanceTenantId;
  merchant: { code: number; name: string; brandName: string; country: string; currency: string; state: 0 | 1; buildState: 'configuring' | 'online'; adminDomain: string; webDomain: string; languageLabels: string[] };
  layoutAssignment: 'assigned' | 'unassigned';
  layouts: PrototypeLayoutScenario[];
  domains: Array<{ domainId: string; domainUrl: string; domainType: 'main' | 'secondary'; resolveState: 'active' | 'invalid'; state: 0 | 1; layoutId: string; currentLayout: boolean }>;
  games: { expectedStates: Array<'active' | 'maintenance' | 'disabled' | 'unavailable'> };
  languages: { enabled: string[]; defaultLanguage: string; disabledExistingContent: string[] };
}

const layout = (tenantId: PrototypeAcceptanceTenantId, suffix: string, input: Partial<PrototypeLayoutScenario> = {}): PrototypeLayoutScenario => ({
  layoutId: `layout-${tenantId}-${suffix}`,
  layoutName: `${tenantId} ${suffix === 'home' ? '首页' : suffix === 'promo' ? '推广' : suffix === 'event' ? '活动' : '待配置'}版面`,
  domainId: `domain-${tenantId}-${suffix === 'home' ? 'main' : 'alt'}`,
  domainUrl: `${suffix === 'home' ? 'www' : suffix}.${tenantId}.test`,
  isDefault: suffix === 'home',
  configurationStatus: 'published',
  scheduleStatus: 'none',
  publishStatus: 'success',
  domainStatus: suffix === 'home' ? 'enabled' : 'disabled',
  historyVersions: [`TEN-${tenantId}-002`, `TEN-${tenantId}-001`],
  hasRollbackAudit: false,
  ...input,
});
const domainsFor = (tenantId: PrototypeAcceptanceTenantId, layouts: PrototypeLayoutScenario[]) => layouts.map((entry, index) => ({
  domainId: entry.domainId,
  domainUrl: entry.domainUrl,
  domainType: (index === 0 ? 'main' : 'secondary') as 'main' | 'secondary',
  resolveState: (index ? 'invalid' : 'active') as 'active' | 'invalid',
  state: (index ? 0 : 1) as 0 | 1,
  layoutId: entry.layoutId,
  currentLayout: index === 0,
}));
const commonGameStates = ['active', 'maintenance', 'disabled', 'unavailable'] as const;
const createScenario = (
  tenantId: PrototypeAcceptanceTenantId,
  merchant: PrototypeAcceptanceScenario['merchant'],
  layouts: PrototypeLayoutScenario[],
  languages: PrototypeAcceptanceScenario['languages'],
): PrototypeAcceptanceScenario => ({
  tenantId,
  merchant,
  layoutAssignment: layouts.length ? 'assigned' : 'unassigned',
  layouts,
  domains: layouts.length ? domainsFor(tenantId, layouts) : [
    { domainId: `domain-${tenantId}-main`, domainUrl: `www.${tenantId}.test`, domainType: 'main', resolveState: 'active', state: 1, layoutId: '', currentLayout: false },
    { domainId: `domain-${tenantId}-alt`, domainUrl: `m.${tenantId}.test`, domainType: 'secondary', resolveState: 'invalid', state: 0, layoutId: '', currentLayout: false },
  ],
  games: { expectedStates: [...commonGameStates] },
  languages,
});

const layouts1050 = [
  layout('1050', 'home', { configurationStatus: 'draft', scheduleStatus: 'scheduled', historyVersions: ['TEN-1050-003', 'TEN-1050-002'] }),
  layout('1050', 'event'),
];
const layouts1048 = [
  layout('1048', 'home', { publishStatus: 'auto-rolled-back', historyVersions: ['TEN-1048-009', 'TEN-1048-008'], hasRollbackAudit: true }),
  layout('1048', 'promo', { configurationStatus: 'draft', publishStatus: 'normal', historyVersions: [] }),
];
const layouts1052 = [
  layout('1052', 'home'),
  layout('1052', 'promo', { configurationStatus: 'draft', publishStatus: 'normal', historyVersions: [] }),
];
const layouts1054 = [
  layout('1054', 'home'),
  layout('1054', 'new', { configurationStatus: 'unconfigured', publishStatus: 'normal', historyVersions: [] }),
];

export const prototypeAcceptanceScenarios: PrototypeAcceptanceScenario[] = [
  createScenario('1050', { code: 1050, name: 'daman', brandName: 'daman', country: '印度', currency: 'INR', state: 1, buildState: 'online', adminDomain: 'admin.1050.test', webDomain: 'www.1050.test', languageLabels: ['繁体中文', '英语', '阿拉伯语'] }, layouts1050, { enabled: ['zh-Hant', 'en', 'ar'], defaultLanguage: 'zh-Hant', disabledExistingContent: ['hi'] }),
  createScenario('1048', { code: 1048, name: '91club', brandName: '91club', country: '印度', currency: 'INR', state: 0, buildState: 'online', adminDomain: 'admin.1048.test', webDomain: 'www.1048.test', languageLabels: ['英语', '印尼语'] }, layouts1048, { enabled: ['en', 'id'], defaultLanguage: 'en', disabledExistingContent: ['zh'] }),
  createScenario('1052', { code: 1052, name: 'fun88', brandName: 'fun88', country: '印度', currency: 'INR', state: 1, buildState: 'configuring', adminDomain: 'admin.1052.test', webDomain: 'www.1052.test', languageLabels: ['英语', '泰语', '越南语'] }, layouts1052, { enabled: ['en', 'tha', 'vi'], defaultLanguage: 'tha', disabledExistingContent: ['hi'] }),
  createScenario('1054', { code: 1054, name: 'jeetwin', brandName: 'jeetwin', country: '印度', currency: 'INR', state: 0, buildState: 'configuring', adminDomain: 'admin.1054.test', webDomain: 'www.1054.test', languageLabels: ['英语', '孟加拉语'] }, layouts1054, { enabled: ['en', 'bd'], defaultLanguage: 'en', disabledExistingContent: ['ar'] }),
];

export const getPrototypeAcceptanceScenario = (tenantId: string | number) => prototypeAcceptanceScenarios.find((row) => row.tenantId === String(tenantId));
export const normalizePrototypeTenantScope = (tenantId: unknown) => {
  const scope = String(tenantId ?? '').trim();
  return scope === 'daman-demo' ? '1050' : scope;
};

interface PrototypeStorage { getItem(key: string): string | null; setItem(key: string, value: string): void; removeItem(key: string): void }
const FIXTURE_STORAGE_PREFIX = 'ar-prototype-acceptance-scenario:v1:';
const defaultModes = (): Record<PrototypeFixtureSource, PrototypeFixtureMode> => ({ merchant: 'ready', layout: 'ready', domain: 'ready', gameVenue: 'ready', gameCategory: 'ready', language: 'ready' });
const storageFor = (): PrototypeStorage | undefined => {
  if (typeof window === 'undefined') return undefined;
  try { return window.localStorage; } catch { return undefined; }
};
const fixtureKey = (tenantId: PrototypeAcceptanceTenantId) => `${FIXTURE_STORAGE_PREFIX}${encodeURIComponent(tenantId)}`;

export const getPrototypeFixtureModes = (tenantId: string | number, targetStorage: PrototypeStorage | undefined = storageFor()): Record<PrototypeFixtureSource, PrototypeFixtureMode> => {
  const scenario = getPrototypeAcceptanceScenario(tenantId);
  if (!scenario || !targetStorage) return defaultModes();
  try {
    const value = JSON.parse(targetStorage.getItem(fixtureKey(scenario.tenantId)) || 'null') as { version?: number; tenantId?: string; modes?: Partial<Record<PrototypeFixtureSource, PrototypeFixtureMode>> } | null;
    if (value?.version !== 1 || value.tenantId !== scenario.tenantId || !value.modes) return defaultModes();
    const modes = defaultModes();
    const valid = new Set<PrototypeFixtureMode>(['ready', 'loading', 'empty', 'error', 'stale']);
    Object.keys(modes).forEach((source) => {
      const candidate = value.modes?.[source as PrototypeFixtureSource];
      if (candidate && valid.has(candidate)) modes[source as PrototypeFixtureSource] = candidate;
    });
    return modes;
  } catch { return defaultModes(); }
};

export const setPrototypeFixtureMode = (tenantId: string | number, source: PrototypeFixtureSource, mode: PrototypeFixtureMode, targetStorage: PrototypeStorage | undefined = storageFor()) => {
  const scenario = getPrototypeAcceptanceScenario(tenantId);
  if (!scenario || !targetStorage) return false;
  const modes = getPrototypeFixtureModes(scenario.tenantId, targetStorage);
  modes[source] = mode;
  targetStorage.setItem(fixtureKey(scenario.tenantId), JSON.stringify({ version: 1, tenantId: scenario.tenantId, modes }));
  return true;
};
export const preparePrototypeFixture = async (tenantId: string | number, source: PrototypeFixtureSource, targetStorage: PrototypeStorage | undefined = storageFor()) => {
  const mode = getPrototypeFixtureModes(tenantId, targetStorage)[source];
  if (mode === 'loading') await new Promise((resolve) => setTimeout(resolve, 450));
  return mode;
};

const removeTenantPersistence = (storage: PrototypeStorage, tenantId: PrototypeAcceptanceTenantId) => {
  storage.removeItem(fixtureKey(tenantId));
  storage.removeItem(`ar-merchant-layout-prototype:management:${encodeURIComponent(tenantId)}`);
  storage.removeItem(`ar-merchant-layout-prototype:prototype:${encodeURIComponent(tenantId)}`);
  getPrototypeAcceptanceScenario(tenantId)?.layouts.forEach((entry) => {
    storage.removeItem(`admin-layout-editor:current-draft:${encodeURIComponent(entry.layoutId)}`);
    storage.removeItem(`p0b-layout-config:${entry.layoutId}`);
    storage.removeItem(`p0b-h5-config:${entry.layoutId}`);
  });
};
export const resetTestData = (tenantId?: string | number, targetStorage: PrototypeStorage | undefined = storageFor()) => {
  if (!targetStorage) return { resetTenantIds: [] as string[], reloadRequired: false };
  const ids = tenantId === undefined ? [...PROTOTYPE_ACCEPTANCE_TENANT_IDS] : getPrototypeAcceptanceScenario(tenantId) ? [String(tenantId) as PrototypeAcceptanceTenantId] : [];
  ids.forEach((id) => removeTenantPersistence(targetStorage, id));
  return { resetTenantIds: ids, reloadRequired: typeof window !== 'undefined' };
};

if (typeof window !== 'undefined') Object.assign(window as unknown as Record<string, unknown>, { __AR_PROTOTYPE_SCENARIO__: { scenarios: prototypeAcceptanceScenarios, getFixtureModes: getPrototypeFixtureModes, setFixtureMode: setPrototypeFixtureMode, resetTestData } });
