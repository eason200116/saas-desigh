/**
 * 从 route.meta.tabs 读取 Tab 配置，按权限和 show 字段过滤，
 * 管理 activeTab 与 URL query 同步。
 */
import { computed, defineAsyncComponent, ref, watch, markRaw, type Component, type Ref } from 'vue';
import { useRoute, useRouter, type RouteRecordName } from 'vue-router';
import { useI18n } from 'vue-i18n';
import { useTabQuery } from './useTabQuery';
import { usePermission } from './usePermission';
import { useUserStore } from '@/store/modules/user';
import type { RouteTabMeta } from '@/router/types';

export interface RouteTabItem {
  /** Tab 唯一标识 */
  key: string;
  /** Tab 翻译后的标题 */
  label: string;
  /** Tab 组件（已 markRaw） */
  component: Component;
  /** 是否 KeepAlive */
  keepAlive: boolean;
}

export interface UseRouteTabsOptions {
  /** 嵌入模式（弹窗内使用），不同步 URL query */
  embed?: boolean;
  /**
   * 指定读取 meta.tabs 的路由名；用于页面被嵌入到非自身路由时仍按标准路由配置取 tabs。
   * 因为 useRoute() 返回的是宿主路由（如 /finance/withdrawOrder），
   * 它的 meta.tabs 不是当前组件需要的 tab 列表，导致 tabs 为空白。
   * 传入本组件对应路由的 name（如 'game_order' / 'member_bank_card'），
   * 即可从 router 表里取到正确的 meta.tabs。
   */
  sourceRouteName?: RouteRecordName;
}

export function useRouteTabs(defaultTab: string, options?: UseRouteTabsOptions) {
  const { embed = false, sourceRouteName } = options ?? {};
  const route = useRoute();
  const router = useRouter();
  const { t } = useI18n();
  const userStore = useUserStore();
  const { hasPermission } = usePermission();

  // 从 route.meta 读取原始 Tab 配置；显式指定 sourceRouteName 时从 router 表取对应路由的 meta
  const sourceRoute = sourceRouteName
    ? router.getRoutes().find((item) => item.name === sourceRouteName)
    : undefined;
  const rawTabs = (sourceRoute?.meta?.tabs ?? route.meta?.tabs ?? []) as RouteTabMeta[];

  // 预先将异步导入函数转为 defineAsyncComponent 并缓存，避免 computed 重复创建
  const componentCache = new Map<string, Component>();
  for (const tab of rawTabs) {
    const comp =
      typeof tab.component === 'function'
        ? defineAsyncComponent(tab.component as () => Promise<Component>)
        : tab.component;
    componentCache.set(tab.key, markRaw(comp) as Component);
  }

  // 按 show 和 permissions 过滤后的可见 Tab 列表
  const tabs = computed<RouteTabItem[]>(() =>
    rawTabs
      .filter((tab) => {
        const showValue = tab.show ?? true;
        const visible = typeof showValue === 'function' ? showValue(userStore) : showValue;
        if (!visible) return false;
        return !tab.permissions?.length || hasPermission(tab.permissions);
      })
      .map((tab) => ({
        key: tab.key,
        label: t(tab.title),
        component: componentCache.get(tab.key)!,
        keepAlive: tab.keepAlive !== false,
      })),
  );

  // embed 模式用本地 ref，否则用 useTabQuery 同步 URL
  const localTab = ref(defaultTab);
  const queryResult = embed ? null : useTabQuery(defaultTab);
  const activeTab: Ref<string> = embed ? localTab : queryResult!.activeTab;

  const setTab = (v: string) => {
    if (embed) {
      localTab.value = v;
    } else {
      queryResult!.setTab(v);
    }
  };

  // 当前激活 Tab 无权限或不可见时，自动切到第一个可见 Tab
  watch(
    [tabs, activeTab],
    ([list, current]) => {
      if (!list.length) return;
      if (!list.some((tab) => tab.key === current)) {
        setTab(list[0].key);
      }
    },
    { immediate: true },
  );

  // 当前激活 Tab 的完整配置项
  const activeTabItem = computed(
    () => tabs.value.find((tab) => tab.key === activeTab.value) ?? tabs.value[0] ?? null,
  );

  // 当前激活 Tab 对应的组件
  const activeComponent = computed(() => activeTabItem.value?.component ?? null);

  // 需要 KeepAlive 的 Tab key 列表
  const keepAliveKeys = computed(() =>
    tabs.value.filter((tab) => tab.keepAlive).map((tab) => tab.key),
  );

  // Tab 切换回调，供模板 @update:value 绑定
  function handleTabUpdate(value: string) {
    setTab(value);
  }

  return {
    /** 经权限和 show 过滤后的可见 Tab 列表 */
    tabs,
    /** 当前激活的 Tab key */
    activeTab,
    /** 当前激活的 Tab 配置项 */
    activeTabItem,
    /** 当前激活的组件 */
    activeComponent,
    /** 需要 KeepAlive 的 Tab key 列表 */
    keepAliveKeys,
    /** Tab 切换回调 */
    handleTabUpdate,
  };
}
