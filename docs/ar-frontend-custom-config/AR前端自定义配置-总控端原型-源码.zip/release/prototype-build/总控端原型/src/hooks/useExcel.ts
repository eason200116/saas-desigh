import { ref } from 'vue';

interface ColumnMapping {
  key: string;
  index?: number;
  transform?: (value: any) => any;
}

interface UseExcelOptions {
  columnMapping?: ColumnMapping[];
  onSuccess?: (data: any[]) => void;
  onError?: (error: Error) => void;
}

/**
 * Excel 文件处理 Hook
 */
export function useExcel(options: UseExcelOptions = {}) {
  const loading = ref(false);
  const data = ref<any[]>([]);
  const error = ref<Error | null>(null);

  /**
   * 触发文件选择上传
   */
  const handleUploadClick = () => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.xlsx,.xls,.csv';
    input.onchange = async (e) => {
      const file = (e.target as HTMLInputElement).files?.[0];
      if (file) {
        await parseExcelFile(file);
      }
    };
    input.click();
  };

  /**
   * 解析 Excel 文件
   */
  const parseExcelFile = async (file: File): Promise<any[]> => {
    loading.value = true;
    error.value = null;

    try {
      // 动态导入 xlsx 库
      const XLSX = await import('xlsx').catch(() => null);

      if (!XLSX) {
        throw new Error('xlsx library not available');
      }

      return new Promise((resolve, reject) => {
        const reader = new FileReader();

        reader.onload = (e) => {
          try {
            const arrayBuffer = e.target?.result;
            const workbook = XLSX.read(arrayBuffer, { type: 'array' });
            const firstSheetName = workbook.SheetNames[0];
            const worksheet = workbook.Sheets[firstSheetName];
            const jsonData = XLSX.utils.sheet_to_json(worksheet, { header: 1 });

            // 应用列映射
            const mappedData = mapColumns(jsonData as any[][], options.columnMapping);
            data.value = mappedData;

            options.onSuccess?.(mappedData);
            resolve(mappedData);
          } catch (err) {
            const parseError = err instanceof Error ? err : new Error('Parse error');
            error.value = parseError;
            options.onError?.(parseError);
            reject(parseError);
          } finally {
            loading.value = false;
          }
        };

        reader.onerror = () => {
          const readError = new Error('File read error');
          error.value = readError;
          options.onError?.(readError);
          loading.value = false;
          reject(readError);
        };

        reader.readAsArrayBuffer(file);
      });
    } catch (err) {
      loading.value = false;
      const importError = err instanceof Error ? err : new Error('Import error');
      error.value = importError;
      options.onError?.(importError);
      return [];
    }
  };

  /**
   * 列映射处理
   */
  const mapColumns = (rawData: any[][], columnMapping?: ColumnMapping[]): any[] => {
    if (!columnMapping || rawData.length < 2) {
      return rawData.slice(1).map((row) => row);
    }

    // 跳过表头行
    return rawData.slice(1).map((row) => {
      const mappedRow: Record<string, any> = {};
      columnMapping.forEach((mapping, idx) => {
        const colIndex = mapping.index ?? idx;
        let value = row[colIndex];
        if (mapping.transform) {
          value = mapping.transform(value);
        }
        mappedRow[mapping.key] = value;
      });
      return mappedRow;
    });
  };

  return {
    loading,
    data,
    error,
    handleUploadClick,
    parseExcelFile,
  };
}
